"""Execute the inspected native local integration stages and retain actual receipts."""

import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

PREP = Path("/private/tmp/pathwaymech-next-243-local-integration-preparation-20261012")
ROOT = Path("/private/tmp/pathwaymech-next-243-local-20261012")
OUT = Path("/private/tmp/pathwaymech-next-243-local-native-execution-20261012")
EXPECTED_STAGE = '56fc10ece82d03a96332a589af5e93c631ed309e22ca1b4c923219dd2434a1d3'
EXPECTED_HANDOFF = 'b8c0dbef6666556b2351b124a9254c54d92ad238eb1d106d546fb843c9972ff0'
EXPECTED_PLAN = '770b2209ff95ccbb7fb0305a631cdcc44e3d41d587dbd2d22ced332badf68744'
EXPECTED_SEMANTIC = 'bc9b9ab77c25548a57b5a5a73fbd7560dcbfcaf48897e4b5fa70c7cc9d63852d'
EXPECTED_APPROVAL = 'c25d3612b3e9060c3d7f89fca186a3ebb1f3d277d3e35779d71b980ffbd57c33'
EXPECTED_BASELINE = 'a287d4efda8e35b601c0b255fbfef654c2fb3ec86d92143bd03e8c4119419bb4'
PHASES = ("history-and-generation", "remaining-offline-gates", "vendored-gate", "final-gates")


def pin(path):
    assert not path.is_symlink() and path.is_file(), path
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def check_histories(expected_count):
    assert pin(PREP / "baseline-files.json")["sha256"] == EXPECTED_BASELINE
    baseline = json.loads((PREP / "baseline-files.json").read_bytes())
    old = {
        r["path"]: r
        for r in baseline
        if r["path"].startswith("history/") and r["path"].endswith(".yaml")
    }
    assert len(old) == 410
    current = {p.relative_to(ROOT).as_posix(): pin(p) for p in (ROOT / "history").rglob("*.yaml")}
    assert len(current) == expected_count
    for name, row in old.items():
        assert (current[name]["bytes"], current[name]["sha256"]) == (row["bytes"], row["sha256"])
    return {
        "old_histories": 410,
        "total_histories": len(current),
        "old_whole_history_bytes_exact": True,
        "new_histories": [row for name, row in sorted(current.items()) if name not in old],
    }


def verify_sssom(old_body, actual_body, semantic):
    import csv
    from collections import Counter

    assert hashlib.sha256(old_body).hexdigest() == semantic["before"]["sha256"]
    old_lines, actual = old_body.decode().splitlines(), actual_body.decode().splitlines()
    assert [line for line in actual if line.startswith("#")] == semantic["exact_header_lines"]

    def rows(lines):
        reader = csv.DictReader(
            [line for line in lines if not line.startswith("#")], delimiter="\t"
        )
        result = list(reader)
        return reader.fieldnames, [tuple(row[k] for k in reader.fieldnames) for row in result]

    keys, old_order = rows(old_lines)
    new_keys, new_order = rows(actual)
    before, after = Counter(old_order), Counter(new_order)
    expected = Counter(tuple(row[k] for k in keys) for row in semantic["expected_added_rows"])
    assert keys == new_keys and after == before + expected
    assert sum(before.values()) == 66 and sum(expected.values()) == 4 and sum(after.values()) == 70
    assert not (before & expected)
    assert [row for row in new_order if row in before] == old_order
    return {
        "old_rows": 66,
        "added_rows": 4,
        "total_rows": 70,
        "all_headers_cells_multiplicities_exact": True,
        "old_row_relative_order_exact": True,
        "whole_bytes_expected_to_change": True,
    }


def main():
    assert len(sys.argv) == 2 and sys.argv[1] in PHASES
    phase = sys.argv[1]
    assert len(EXPECTED_APPROVAL) == 64, "Exact root acceptance remains pending"
    runner_at_start = pin(Path(__file__))
    runner_body = Path(__file__).read_bytes()
    assert hashlib.sha256(runner_body).hexdigest() == runner_at_start["sha256"]
    assert pin(PREP / "stages.json")["sha256"] == EXPECTED_STAGE
    assert pin(PREP / "handoff.json")["sha256"] == EXPECTED_HANDOFF
    assert pin(PREP / "plan.json")["sha256"] == EXPECTED_PLAN
    assert pin(PREP / "semantic-preservation.json")["sha256"] == EXPECTED_SEMANTIC
    stages = json.loads((PREP / "stages.json").read_bytes())
    plan = json.loads((PREP / "plan.json").read_bytes())
    adoption = Path("/private/tmp/pathwaymech-next-243-local-adoption-20261012/receipt.json")
    adoption_at_start = pin(adoption)
    state = json.loads(adoption.read_bytes())
    assert state["status"] == "local_adoption_complete_no_history_gates_or_publication"
    assert state["target"] == str(ROOT) and state["publication_performed"] is False
    assert len(state["changes"]) == 12
    assert state["changes"] == [row["destination"] for row in plan["changes"]]
    assert state["handoff"] == pin(PREP / "handoff.json")
    approval = Path(state["approval"]["path"])
    assert pin(approval) == state["approval"]
    accepted = json.loads(approval.read_bytes())
    assert accepted["status"] == "accepted_exact_baesr243_local_integration_for_adoption"
    assert state["approval"]["sha256"] == (EXPECTED_APPROVAL)
    assert accepted["handoff"] == pin(PREP / "handoff.json")
    assert accepted["target"] == str(ROOT)
    assert accepted["commit"] == state["baseline_commit"]
    assert accepted["tree"] == state["baseline_tree"]
    assert accepted["publication_authorized"] is False and accepted["local_only"] is True
    assert (
        subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        == "63bc0ba99c63e4d4cdbdf70b8fb3f6f8417eeacf"
    )
    records = list((ROOT / "data/pathways").rglob("*.yaml"))
    assert len(records) == 242 and all(not p.is_symlink() for p in records)
    assert pin(ROOT / "data/pathways/baesr-two-component-signal-transduction.yaml")["sha256"] == (
        "1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824"
    )
    history_before = check_histories(410 if phase == "history-and-generation" else 412)
    env = {**os.environ, **stages["environment"]}
    if phase == "history-and-generation":
        commands = [
            {"name": "history-" + str(i + 1), "argv": argv}
            for i, argv in enumerate(stages["history_commands"])
        ]
        commands += stages["before_first_render_after_history"]
        commands += stages["nine_fresh_gates"][:2]
    elif phase in ("remaining-offline-gates", "vendored-gate", "final-gates"):
        previous = {
            "remaining-offline-gates": "history-and-generation",
            "vendored-gate": "remaining-offline-gates",
            "final-gates": "vendored-gate",
        }[phase]
        prior = json.loads((OUT / previous / "completion.json").read_bytes())
        assert prior["status"] == "phase_passed"
        assert prior["runner"] == runner_at_start
        assert prior["adoption"] == adoption_at_start
        assert prior["stage_plan"] == pin(PREP / "stages.json")
        assert pin(Path(prior["phase_start"]["path"])) == prior["phase_start"]
        for receipt in prior["receipts"]:
            assert receipt["exit_code"] == 0 and receipt["runner_at_start"] == runner_at_start
            assert pin(Path(receipt["stdout"]["path"])) == receipt["stdout"]
            assert pin(Path(receipt["stderr"]["path"])) == receipt["stderr"]
        for origin in prior["receipt_origins"]:
            assert pin(Path(origin["path"])) == origin
        span = {
            "remaining-offline-gates": slice(2, 6),
            "vendored-gate": slice(6, 7),
            "final-gates": slice(7, None),
        }[phase]
        commands = stages["nine_fresh_gates"][span]
    else:
        raise ValueError("Unknown explicit phase")
    OUT.mkdir(exist_ok=True)
    folder = OUT / phase
    folder.mkdir(exist_ok=False)
    with (folder / "runner-at-start.py").open("xb") as stream:
        stream.write(runner_body)
    phase_start = {
        "phase": phase,
        "started_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "runner": runner_at_start,
        "retained_runner": pin(folder / "runner-at-start.py"),
        "adoption": adoption_at_start,
        "stage_plan": pin(PREP / "stages.json"),
        "plan": pin(PREP / "plan.json"),
        "commands": commands,
        "record_count": len(records),
        "history_before_phase": history_before,
        "cwd": str(ROOT),
        "environment": stages["environment"],
    }
    write(folder / "phase-start.json", phase_start)
    phase_origin = pin(folder / "phase-start.json")
    receipts = []
    receipt_origins = []
    for item in commands:
        name, argv = item["name"], item["argv"]
        assert pin(Path(__file__)) == runner_at_start
        start = datetime.datetime.now(datetime.UTC).isoformat()
        clock = time.monotonic()
        with (
            (folder / (name + ".stdout")).open("xb") as stdout,
            (folder / (name + ".stderr")).open("xb") as stderr,
        ):
            proc = subprocess.run(
                argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False
            )
        receipt = {
            "name": name,
            "argv": argv,
            "cwd": str(ROOT),
            "environment": stages["environment"],
            "started_at": start,
            "finished_at": datetime.datetime.now(datetime.UTC).isoformat(),
            "seconds": time.monotonic() - clock,
            "exit_code": proc.returncode,
            "stdout": pin(folder / (name + ".stdout")),
            "stderr": pin(folder / (name + ".stderr")),
            "runner_at_start": runner_at_start,
            "phase_start": phase_origin,
        }
        write(folder / (name + ".execution.json"), receipt)
        receipt_origins.append(pin(folder / (name + ".execution.json")))
        receipts.append(receipt)
        print(
            json.dumps({"name": name, "exit_code": proc.returncode, "seconds": receipt["seconds"]}),
            flush=True,
        )
        if proc.returncode:
            write(
                folder / "failure.json",
                {"status": "phase_failed", "receipts": receipts, "remaining_not_run": True},
            )
            raise SystemExit(proc.returncode)
        if name == "history-2":
            history_after = check_histories(412)
            assert len(history_after["new_histories"]) == 2
            write(folder / "histories-before-generation.json", history_after)
        if name == "sssom":
            semantic = json.loads((PREP / "semantic-preservation.json").read_bytes())["SSSOM"]
            old_body = subprocess.check_output(
                ["git", "show", "HEAD:output/sssom/source_mappings.sssom.tsv"], cwd=ROOT
            )
            path = ROOT / "output/sssom/source_mappings.sssom.tsv"
            result = verify_sssom(old_body, path.read_bytes(), semantic)
            write(folder / "sssom-preservation.json", {"actual": pin(path), **result})
    assert pin(Path(__file__)) == runner_at_start
    check_histories(412)
    assert pin(adoption) == adoption_at_start
    assert pin(approval) == state["approval"]
    assert pin(PREP / "stages.json")["sha256"] == EXPECTED_STAGE
    assert pin(folder / "phase-start.json") == phase_origin
    assert (folder / "runner-at-start.py").read_bytes() == runner_body
    for receipt, origin in zip(receipts, receipt_origins, strict=True):
        assert pin(Path(origin["path"])) == origin
        assert pin(Path(receipt["stdout"]["path"])) == receipt["stdout"]
        assert pin(Path(receipt["stderr"]["path"])) == receipt["stderr"]
    write(
        folder / "completion.json",
        {
            "status": "phase_passed",
            "phase": phase,
            "receipts": receipts,
            "adoption": adoption_at_start,
            "stage_plan": pin(PREP / "stages.json"),
            "runner": runner_at_start,
            "phase_start": phase_origin,
            "receipt_origins": receipt_origins,
            "finished_at": datetime.datetime.now(datetime.UTC).isoformat(),
        },
    )


if __name__ == "__main__":
    main()
