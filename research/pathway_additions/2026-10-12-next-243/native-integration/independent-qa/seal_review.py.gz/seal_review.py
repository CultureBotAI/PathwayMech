"""Rebase240 complete external SCI sealing; no maintained save or mutation."""
import datetime,hashlib,json,os,stat
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-243-local-20261012')
Q=Path(json.loads((H/'final-shared-QA-binding.json').read_text())['handoff']['path']).parent
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(n,v):(H/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def read(n):return json.loads((H/n).read_text())
assert read('native-validation.execution.json')['exit_code']==0
proposal=H/'completed-review.yaml';assert pin(proposal)==read('native-validation.execution.json')['proposal_at_start']
(H/'completed-review-ready.yaml').write_bytes(proposal.read_bytes());x=yaml.safe_load(proposal.read_text())
for v in x['source']['inputs']:assert pin(R/v['path'])['sha256']==v['sha256']
for v in x['evidence']:
 prefix='research/pathway_additions/2026-10-12-next-243/native-integration/';path=v['reference']
 if path.startswith(prefix+'independent-qa/'):p=H/path.removeprefix(prefix+'independent-qa/')
 elif path.startswith(prefix+'independent-tech-review/'):p=Q/path.removeprefix(prefix+'independent-tech-review/')
 else:p=R/path
 assert pin(p)['sha256']==v['snapshot_sha256'],path
execution_rows=[]
for p in sorted((H/'executions').glob('*/completion.json')):
 d=json.loads(p.read_text())
 for k in ['preserved_executed_helper','stdout','stderr']:assert pin(Path(d[k]['path']))==d[k]
 assert d['executed_helper']['sha256']==d['preserved_executed_helper']['sha256']
 execution_rows.append({'receipt':pin(p),'exit_code':d['exit_code'],'executed_helper_hash':d['executed_helper']['sha256']})
copy=read('actual-native-copy.json')
for row in copy['files']:
 for k in ['source','destination']:assert pin(Path(row[k]['path']))==row[k]
summary=read('final-review-summary.json');native=read('actual-native/execution-summary.json');reading=read('accepted-reading.json')
dump('sealing-currentness.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_native_inputs_still_exact':len(x['source']['inputs']),'durable_evidence_whole_hashes':len(x['evidence']),'executed_helper_bodies_and_streams':execution_rows,'all_native_original_and_copy_bytes_unchanged':len(copy['files']),'no_native_save':True})
dump('read-coverage-final.json',{'reviewer':'/root/adapter_continue','fresh_reading':read('read-coverage.json'),'current_scientific_judgment':pin(H/'scientific-judgment.json'),'accepted_root_paper_reading':reading['prior_read_coverage'],'reading_boundary':read('scientific-judgment.json')['limitations'],'accepted_reading_binding':pin(H/'accepted-reading.json'),'currentness':pin(H/'final-current-bindings.json'),'native_inputs':len(x['source']['inputs']),'shared_QA':pin(Q/'handoff.json'),'mechanical_QA_attribution':'Deoxy separately performed complete maintained page/graph/export/checkout checks. Root visual interpretation is attributed exactly in final-shared-QA-binding.json; no personal browser/figure-pixel reading claimed.'})
report=f"""The exact maintained PathBank:SMP0002123 BaeSR record passes independent scientific review with stated limitations. All13 paragraphs,15 whole edges,8 endpoint qualifiers,12 identities,18 references,4 mappings and31 locators preserve accepted scientific meaning. The target remains34,636bytes/SHA2561cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824. No actionable scientific finding or required product edit was identified. Root will make the final acceptance decision.

This reviewer authored neither243 scientific record/editorial correction nor integration implementation. Nitrate authored the scientific record; Aceto prepared integration. My earlier source/native-identity, design, actual-output and integration-compatibility audits are inherited explicitly. Root personally read the complete1993,2002,2011 primary papers and ten image bodies. I freshly read the complete maintained record and all root paragraph/edge rationales and assessed their current application. The serialized inherited rationales explicitly retain root attribution, including their historical first-person or then-pending wording. Unchanged papers were not reread and no new network fetch occurred.

The two-event scope retains all six native formal sides and two explicitly interpreted BaeS donor-state sides. Nil component coefficients, one-chain drawings and formal coefficients do not establish native oligomers. Flattened BaeR, repeated BaeS modification and reciprocal BindingFeatures remain encoding conflicts, not a noncovalent phosphate assembly. Native phosphate stays isolated with its neutral-acid/trianion conflict; no acid/free-Pi/protein-bound-phosphoryl equivalence is introduced. ATP/ADP exact stereo mappings do not specify assay protonation. Current467 versus historical466 BaeS sequence and PROSITE-inferred H250/D61 sites remain qualified. The1993 enriched fractions,2002 altered/intact/purification constructs and2011 condition-specific reporters retain their limits; no purified-pair kinetics, mandatory phosphorylation for all promoter binding, direct ligand binding or universal phenotype follows. Corrected GO compartments and species/K12 scope remain distinct from erroneous native annotation. Inaccessible2005 full text remains annotation-attributed; raw PWML and reversible reading derivative are separate.

Fresh currentness passes for48 received acquisition-body entries,48 relevant receipts and three native-original entries, reconstructed from eight maintained portable owners. These received rows include comparison/error bodies and are not48 scientific supports; the index retains all68 acquisition attempts. All18 exact reference objects and their whole-body/receipt bindings, all31 evidence strings and four mappings remain exact. Earlier matched-node/source-identity replay is inherited; current originals are freshly compared in full. The complete hidden/ignored-inclusive census parsed126 structured review YAMLs and found no target predecessor. All13 current inspection contracts match previously read240 bytes. Earlier full packet closures are inherited through exact accepted pins rather than represented as repeated paper or whole historical audits.

Deoxy separately owns fresh complete maintained page/graph/export/authority/checkout/cache QA. Its exact sealed packet was completely closed, relevant report/results read and bound, and native inputs bind the actual generated representation. Visual attribution is: {read('final-shared-QA-binding.json')['visual_attribution']} Root owns the actual native execution. {native['tests_summary'].strip()} All{len(copy['successful_commands'])} successful native commands and{len(copy['historical_failures'])} historical failed phase attempts are retained. The complete{len(copy['files'])}-file native packet, original seals, first-origin receipts/helpers/outer captures and streams are copied unchanged. No native gate was rerun by this reviewer.

The maintained SCI currentness and census checks passed first attempt. Earlier independent mechanics-check Rhea-role failure, preparation syntax/lint failures and source/acquisition failures remain retained in their original packets; none is rewritten as a first-attempt success. The Rhea832-byte effective maintained CLI input stays separate from the796-byte historical runtime snapshot. No new SQL full hash, SQL query or ontology builder is claimed. Scientific-judgment and preparatory JSON retain their original pending-state timestamps; final currentness/native/shared-QA evidence establishes completion. Any actual later SCI helper failure is retained in this packet with its original receipt and streams.

The external proposal has{summary['assessments']} assessments,{summary['checks']} checks,{summary['evidence']} evidence items and{len(x['source']['inputs'])} original native inputs. Shared native-serializer validation passed; all original input/evidence hashes remain exact. completed-review-ready.yaml is byte-identical to the validated proposal. Root may later extend source inputs only through explicit inspected durable evidence adoption while preserving every original descriptor, judgment, reviewer identity and timestamp. Audit Python bodies may be retained as deterministic lossless gzip with original/stored bindings; directly cited evidence paths remain exact. This reviewer performed no maintained edit, cache/history mutation, native review save, Git/public action, licensing clearance or source-exhaustion claim.
"""
(H/'REPORT.md').write_text(report)
dump('durable-adoption-instructions.json',{'prefix':'research/pathway_additions/2026-10-12-next-243/native-integration/independent-qa','whole_packet_required':True,'audit_python_storage':'Exact original bodies may be stored losslessly as .py.gz with explicit original path/bytes/hash and stored path/bytes/hash; whole reconstructed closure must pass.','references':'All directly cited JSON/YAML/REPORT paths and hashes unchanged; independent-tech-review is separately accepted.','native_proposal':pin(H/'completed-review-ready.yaml'),'preserve':'Every original source descriptor, scientific judgment, reviewer identity, original reading claim and timestamp; only explicit native inspected additional source inputs may be added.'})
files=[];dirs=[]
for base,ds,fs in os.walk(H,followlinks=False):
 for name in ds:
  p=Path(base)/name;assert stat.S_ISDIR(p.lstat().st_mode);dirs.append(str(p.relative_to(H)))
 for name in fs:
  p=Path(base)/name;assert stat.S_ISREG(p.lstat().st_mode)
  if p.parent==H and p.name in ['artifact-manifest.json','handoff.json']:continue
  files.append(pin(p)|{'relative_path':str(p.relative_to(H)),'kind':'regular_file'})
files.sort(key=lambda v:v['relative_path']);dirs.sort()
dump('artifact-manifest.json',{'files':files,'directories':dirs,'walk':'literal os.walk, hidden/ignored included; symlinks and special objects rejected'})
dump('handoff.json',{'status':'independent_maintained_scientific_review_pass_with_limitations_validated_not_saved','sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'directories':len(dirs),'proposal':pin(H/'completed-review-ready.yaml'),'validated_proposal':pin(proposal),'native_validation':pin(H/'native-validation.execution.json'),'target_sha256':'1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824','shared_QA':pin(Q/'handoff.json'),'native_original_handoff':pin(H/'actual-native/handoff.json'),'evidence_destination':'research/pathway_additions/2026-10-12-next-243/native-integration/independent-qa','reviewer':'/root/adapter_continue','inherited_original_scientific_reviewer':'Codex /root full primary reading; this reviewer prior source/native-identity audit','native_save_performed':False,'required_findings':[]})
for row in files:assert pin(Path(row['path']))['sha256']==row['sha256']
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'proposal':pin(H/'completed-review-ready.yaml'),'artifacts':len(files),'directories':len(dirs)},indent=2))
