"""Read-only native schema/semantic review validation, preserving original argv and streams."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
H=Path(__file__).resolve().parent
p=json.loads((H/'planned-native-commands.json').read_text())
def pin(x):
 b=x.read_bytes();return {'path':str(x),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
r={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':p['validate'],'cwd':p['cwd'],'environment':p['environment'],'helper':pin(Path(__file__)),'proposal_at_start':pin(H/'completed-review.yaml'),'planned_argv_unchanged':True}
with (H/'native-validation.stdout').open('wb') as o,(H/'native-validation.stderr').open('wb') as e:
 q=subprocess.run(r['argv'],cwd=r['cwd'],env=os.environ|r['environment'],stdout=o,stderr=e,check=False)
r.update(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=q.returncode,stdout=pin(H/'native-validation.stdout'),stderr=pin(H/'native-validation.stderr'))
(H/'native-validation.execution.json').write_text(json.dumps(r,indent=2)+'\n')
print((H/'native-validation.stdout').read_text());print((H/'native-validation.stderr').read_text());assert q.returncode==0
assert pin(H/'completed-review.yaml')==r['proposal_at_start']
for x in json.loads((H/'native-inspection.json').read_text())['source']['inputs']:
 assert pin(Path(p['cwd'])/x['path'])['sha256']==x['sha256'],x['path']
print('PASS native validation and all original inputs still exact; no save')
