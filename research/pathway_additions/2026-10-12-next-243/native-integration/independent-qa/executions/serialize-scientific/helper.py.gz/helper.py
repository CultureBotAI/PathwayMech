"""Bounded 239 native SCI serialization rebase; external proposal only, never save."""
import datetime,hashlib,json,os,shlex,stat
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-243-local-20261012')
Q=Path(json.loads((H/'final-shared-QA-binding.json').read_text())['handoff']['path']).parent
N=Path('/private/tmp/pathwaymech-next-243-local-native-execution-20261012')
PREFIX='research/pathway_additions/2026-10-12-next-243/native-integration/independent-qa/'
QPREFIX=json.loads((H/'final-shared-QA-binding.json').read_text())['durable_prefix']
ID='PathBank:SMP0002123'
def read(p):return json.loads(p.read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(n,x):(H/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def check(x):
 p=Path(x['path']);y=pin(p);assert (y['sha256'],y['bytes'])==(x['sha256'],x['bytes']),str(p);return y
now=datetime.datetime.now(datetime.timezone.utc);stamp=now.strftime('%Y-%m-%dT%H:%M:%SZ')
b=read(H/'final-shared-QA-binding.json')
for key in ['handoff','manifest']:check(b[key])
assert Path(b['handoff']['path'])==Q/'handoff.json'
m=read(Q/'artifact-manifest.json');rows=m.get('artifacts',m.get('files'));assert rows is not None
files=[];dirs=[]
for base,ds,fs in os.walk(Q,followlinks=False):
 for n in ds:
  p=Path(base)/n;assert stat.S_ISDIR(p.lstat().st_mode);dirs.append(str(p.relative_to(Q)))
 for n in fs:
  p=Path(base)/n;assert stat.S_ISREG(p.lstat().st_mode);files.append(str(p.relative_to(Q)))
assert set(files)=={str(Path(x['path']).relative_to(Q)) for x in rows}|{'artifact-manifest.json','handoff.json'}
assert sorted(dirs)==sorted(x for x in m['directories'] if x!='.')
for x in rows:check(x)
for x in b['read_evidence']:check(x)
dump('shared-QA-currentness.json',{'at':stamp,'handoff':pin(Q/'handoff.json'),'manifest':pin(Q/'artifact-manifest.json'),'complete_artifacts':len(rows),'whole_report':(Q/'REPORT.md').read_text(),'reviewed_results':b['read_evidence'],'attribution':'Fresh structural and technical QA performed by the separately assigned reviewer; this independent SCI reviewer reads and binds those exact results. No personal interactive browser or pixel review is claimed.'})
inspection=read(H/'native-inspection.json');current=[]
for x in inspection['source']['inputs']:
 p=R/x['path'];assert pin(p)['sha256']==x['sha256'];current.append(pin(p))
assert pin(R/inspection['targets'][0]['path'])['sha256']=='1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824'
sources=read(H/'whole-source-closure.json')
for x in sources['originals']:check(x['original'])
for x in sources['native_originals']:check(x['original'])
for x in sources['unique_receipts']:check(x['original'])
for x in sources['maintained_portable_owners']:check(x)
search=read(H/'prior-native-review-search.json');assert search['exact_target_matches']==[]
for x in search['yaml_files']:assert pin(R/x['path'])['sha256']==x['sha256']
dump('final-current-bindings.json',{'at':stamp,'native_inputs':current,'whole_scientific_originals':sources['source_count'],'native_original_entries':sources['native_original_count'],'unique_receipts':sources['receipt_count'],'portable_owners_unchanged':sources['maintained_portable_owners'],'decoded_basis':pin(H/'whole-source-closure.json'),'all_prior_native_reviews_still_exact':len(search['yaml_files']),'source_interpretation':'Accepted root full1993/2002/2011 paper reading and this reviewer prior source/native audits inherited; fresh whole record and original-byte reconciliation only.'})
judgment=read(H/'scientific-judgment.json');paras=read(H/'paragraph-appraisals.json');edges=read(H/'edge-appraisals.json');quals=read(H/'qualifier-appraisals.json')
checks=[];evidence=[];assessments=[]
def ev(eid,kind,p,summary,search_scope=None):
 p=Path(p) if Path(p).is_absolute() else H/p
 if p.is_relative_to(H):ref=PREFIX+str(p.relative_to(H))
 elif p.is_relative_to(Q):ref=QPREFIX+str(p.relative_to(Q))
 else:ref=str(p.relative_to(R))
 v={'evidence_id':eid,'kind':kind,'reference':ref,'accessed_at':stamp,'support':'supports','summary':summary,'snapshot_sha256':pin(p)['sha256']}
 if search_scope:v['search_scope']=search_scope
 evidence.append(v)
ev('current-record','record_content',R/inspection['targets'][0]['path'],'Exact complete maintained scientific owner; all accepted scoped draft bytes unchanged.')
for eid,kind,p,summary in [
 ('paragraphs','prior_review','paragraph-appraisals.json','All13 whole current paragraphs, earlier independent rationale and fresh current reassessment.'),
 ('edges','prior_review','edge-appraisals.json','All15 complete current edges and exact accepted editorial successor with earlier independent rationale.'),
 ('qualifiers','prior_review','qualifier-appraisals.json','All8 complete endpoint qualifiers and inherited scientific rationale.'),
 ('identities','prior_review','identity-appraisals.json','All12 current identities and exact prior native identity judgments, with accepted document scope.'),
 ('references','primary_source','reference-appraisals.json','All18 exact reference objects and whole original/receipt bindings.'),
 ('mappings','validation','mapping-appraisals.json','All4 protein/ATP/ADP source mappings exact; no phosphate or erroneous GO equivalence.'),
 ('scope-currentness','validation','locator-currentness.json','All31 evidence locator/reference/assertion strings match prior accepted evidence; endpoint-specific qualifier scope preserved. Earlier matched-node replay is inherited.'),
 ('source-closure','database','whole-source-closure.json','All source-derived scientific whole originals/receipts and native entries match current decoded portable representations.'),
 ('accepted-reading','prior_review','accepted-reading.json','Original science and scope successor reports/read coverage, exact roots and whole acceptance receipts; inherited scientific reading explicitly attributed.'),
 ('currentness','validation','final-current-bindings.json','Every original native input, scientific source/receipt and portable owner remains exact at final serialization.'),
 ('shared-closure','validation','shared-QA-currentness.json','Fresh complete shared QA packet closure and exact read results; separate ownership of technical and structural checks.'),
 ('native-copy','validation','actual-native-copy.json','Exact whole native execution packet, including original seals, receipt origins and all failed attempts if present.'),
 ('scientific-judgment','prior_review','scientific-judgment.json','Independent current scientific judgment and precise inherited-reading limits; original then-pending stage wording remains historical.')]:ev(eid,kind,p,summary)
ev('shared-QA','prior_review',Q/'REPORT.md','Shared fresh page/graph/export/physical/cache assessment; root visual reading remains inherited as stated in that report.')
ev('prior-search','search','prior-native-review-search.json','No exact target predecessor native review in the complete current structured YAML inventory.',search['scope'])
for p in paras:
 assessments.append({'assessment_id':'paragraph-'+str(p['ordinal']),'area':'evidence','topic':'Whole narrative paragraph '+str(p['ordinal']),'outcome':'supported','summary':'Inherited root appraisal (historical wording retained): '+p['earlier_appraisal']['assessment']+' '+p['current_reassessment'],'target_ids':[ID],'evidence_ids':['current-record','paragraphs','source-closure','accepted-reading'],'details':'Whole exact current paragraph SHA256 '+p['current_sha256']+'. Root supplied the inherited source reading; this reviewer confirms its current application.'})
for e in edges:
 assessments.append({'assessment_id':'edge-'+str(e['ordinal']),'area':'graph','topic':e['edge_id'],'outcome':'supported','summary':'Inherited root appraisal (historical wording retained): '+e['earlier_appraisal']['assessment']+' '+e['current_reassessment'],'target_ids':[ID],'evidence_ids':['current-record','edges','source-closure','scope-currentness','shared-QA'],'details':'Complete current edge SHA256 '+e['current_sha256']+'; exact qualifier/evidence objects preserved. Shared structural QA separately binds maintained generated representation.'})
for i,q in enumerate(quals,1):
 assessments.append({'assessment_id':'qualifier-'+str(i),'area':'graph','topic':q['edge']+' complete endpoint qualifier','outcome':'supported','summary':q['rationale'],'target_ids':[ID],'evidence_ids':['qualifiers','edges','source-closure','accepted-reading'],'details':'Whole qualifier SHA256 '+q['whole_qualifier_sha256']+'. Accepted qualifier text and complete source evidence unchanged.'})
for v in judgment['summaries']:
 assessments.append(v|{'outcome':'supported','target_ids':[ID]})
for step in read(H/'completed-helper-steps.json')['steps']:
 p=H/'executions'/step/'completion.json';r=read(p);eid='execution-'+step;ev(eid,'validation',p,'Actual bounded helper receipt with exact original helper and streams; any failed original attempts remain explicitly retained.')
 checks.append({'check_id':eid,'name':step,'status':'passed' if r['exit_code']==0 else 'failed','required':r['exit_code']==0,'summary':'Bounded currentness or final native inspection passed.' if r['exit_code']==0 else 'Historical failed helper attempt is preserved; its exact failure and successor disposition must be recorded separately.','target_ids':[ID],'command':shlex.join(r['command']),'exit_code':r['exit_code'],'expected_exit_code':0,'evidence_ids':[eid]})
copy=read(H/'actual-native-copy.json')
for row in copy['successful_commands']:
 r=row['content'];rel=str(Path(row['receipt']['path']).relative_to(N));eid='native-'+r['name'];ev(eid,'validation',H/'actual-native'/rel,'Root actual native execution, independently rebound with whole original helper/origin/streams; no broad gate rerun by this SCI reviewer.')
 checks.append({'check_id':eid,'name':r['name'],'status':'passed','required':True,'summary':'Actual authorized native command passed.','target_ids':[ID],'command':shlex.join(r['argv']),'exit_code':0,'expected_exit_code':0,'evidence_ids':[eid]})
for i,row in enumerate(copy['historical_failures'],1):
 rel=str(Path(row['receipt']['path']).relative_to(N));p=H/'actual-native'/rel;r=next(x for x in row['content']['receipts'] if x['exit_code']!=0);eid='native-failed-attempt-'+str(i);ev(eid,'validation',p,'Original failed native attempt retained unchanged; final successful phase is separately bound.')
 checks.append({'check_id':eid,'name':'historical native attempt '+str(i),'status':'failed','required':False,'summary':'Original failed attempt remains failed; later actual passing command supersedes it.','target_ids':[ID],'command':shlex.join(r['argv']),'exit_code':r['exit_code'],'expected_exit_code':0,'evidence_ids':[eid]})
limits=list(judgment['limitations']);limits[3]=b['visual_attribution']
start=datetime.datetime.fromisoformat(read(H/'native-inspection.execution.json')['started_at']).strftime('%Y-%m-%dT%H:%M:%SZ')
review={'schema_version':'1.0.0','review_id':now.strftime('%Y%m%dT%H%M%SZ')+'-baesr243-scientific','kind':'record','repository':'CultureBotAI/PathwayMech','title':'BaeSR Two-Component Signal Transduction: maintained scientific review','started_at':start,'finished_at':stamp,'reviewer':{'identity':'Codex /root/adapter_continue','kind':'agent','independence':'independent','independence_basis':judgment['role']},'skill':'.claude/skills/review-yaml-record/SKILL.md','completion':'completed','verdict':'pass_with_limitations','scientific_review':True,'summary':'The exact maintained complete current PathBank map preserves all accepted scientific meaning and qualifications:13 paragraphs,15 whole edges,8 qualifiers,12 identities,18 references and4 mappings. Fresh whole-source/current-record checks pass; complete root primary-paper and this reviewer earlier native/source reading is transparently inherited. Separate structural page/graph/export/checkout QA and root actual native gates pass. No actionable scientific defect found.','source':inspection['source'],'scope':{'description':'One whole exact maintained SMP0002123 record, all scientific narrative/edges/identities and source boundaries; generated representation checked by separately attributed mechanical QA.','selection':'Exact root-assigned accepted scoped scientific target; no sampling.','coverage':'full','population_size':1,'reviewed_target_ids':[ID]},'targets':[{'target_id':ID,'path':inspection['targets'][0]['path'],'label':inspection['targets'][0]['label'],'kind':'maintained','ownership_note':'Scientific maintained YAML owner; this reviewer made no maintained edits.'}],'checks':checks,'evidence':evidence,'assessments':assessments,'findings':[],'actions':[],'limitations':limits,'notes':['Original proposal inputs and every judgment/timestamp must remain unchanged during later authorized durable evidence adoption, apart from an explicit native source-input extension. No native save performed here.','Preparatory reports and JSON retain their earlier pending-state assertions. Final native and shared QA bindings establish current completion without rewriting historical records.','Earlier three editorial substitutions are resolved and explicitly inherited; no nonexistent native predecessor review is asserted. No public release or licensing clearance is claimed.'],'tags':['scientific-review','maintained-record','baesr243','source-scope']}
class NoAliasDumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
(H/'completed-review.yaml').write_text(yaml.dump(review,Dumper=NoAliasDumper,sort_keys=False,allow_unicode=True,width=110))
dump('final-review-summary.json',{'status':'scientific_proposal_ready_for_native_validation','proposal':pin(H/'completed-review.yaml'),'assessments':len(assessments),'checks':len(checks),'evidence':len(evidence),'native_inputs':len(current),'actual_native_copy_files':len(copy['files']),'shared_QA':pin(Q/'handoff.json'),'limitations':limits,'native_save_performed':False})
print('PASS: proposal',len(assessments),'assessments',len(checks),'checks',len(evidence),'evidence',len(current),'native inputs; all sources unchanged and shared QA packet closed')
