"""Write 243 TECH only after real maintained QA, native gates and inspection."""
import datetime
import hashlib
import json
import re
import shlex
import shutil
from pathlib import Path

H = Path(__file__).parent
R = Path('/private/tmp/pathwaymech-next-243-local-20261012')
N = Path('/private/tmp/pathwaymech-next-243-local-native-execution-20261012')
P = Path('/private/tmp/pathwaymech-next-243-local-integration-preparation-20261012')
PREFIX = 'research/pathway_additions/2026-10-12-next-243/native-integration/'
LOCAL = PREFIX + 'independent-tech-review/'


def load(p):
    return json.loads(Path(p).read_bytes())


def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


now = datetime.datetime.now(datetime.UTC)
finished = now.strftime('%Y-%m-%dT%H:%M:%SZ')
inspection = load(H / 'technical-inspect.stdout')
assert inspection['status'] == 'inspection_only'
for row in inspection['source']['inputs']:
    assert pin(R / row['path'])['sha256'] == row['sha256'], row['path']
for name in ('target.execution.json', 'checkout.execution.json', 'technical-inspect.execution.json'):
    assert load(H / name)['exit_code'] == 0
intake = load(H / 'native-execution-intake.json')
assert intake['status'] == 'whole_native_packet_and_all_phase_streams_verified'
assert pin(N / 'handoff.json') == intake['handoff']
assert pin(N / 'artifact-manifest.json') == intake['manifest']
packaging = load(P / 'packaging-summary.json')
plan = load(P / 'plan.json')
retention = load(H / 'post-package-evidence-retention.json')
assert retention['status'] == 'post_package_review_evidence_retained_whole_exact'
for row in retention['file_mappings']:
    assert pin(row['original']['path']) == row['original']
    assert pin(row['retained']['path']) == row['retained']
assert len(retention['file_mappings']) == 14
for key in ('original', 'retained'):
    assert pin(retention['sealer_template_review'][key]['path']) == retention['sealer_template_review'][key]

for source, dest in [
    ('/private/tmp/pathwaymech-next-243-root-canonical-output-acceptance-20261012.json', 'canonical-acceptance.json'),
    ('/private/tmp/pathwaymech-next-243-root-integration-acceptance-20261012.json', 'integration-acceptance.json'),
    ('/private/tmp/pathwaymech-next-243-root-scientific-scope-acceptance-20261012.json', 'scientific-scope-acceptance.json'),
    ('/private/tmp/pathwaymech-next-243-canonical-output-independent-review-20261012/handoff.json', 'prior-actual-review-handoff.json'),
    ('/private/tmp/pathwaymech-next-243-root-scientific-review-20261012/handoff.json', 'root-scientific-review-handoff.json'),
    ('/private/tmp/pathwaymech-next-243-graph-preview-20261012/visual-assessment.json', 'visual-assessment.json'),
]:
    assert not (H / dest).exists()
    shutil.copyfile(source, H / dest)

target_ids = [t['target_id'] for t in inspection['targets']]
assert len(target_ids) == 2
assert {t['path'] for t in inspection['targets']} == {'conf/identifier_sources.json', 'data/identifier_authorities/sources.json'}
evidence, checks = [], []


def ev(eid, path, reference, summary, kind='validation'):
    evidence.append({'evidence_id': eid, 'kind': kind, 'reference': reference,
                     'accessed_at': finished, 'support': 'supports', 'summary': summary,
                     'snapshot_sha256': pin(path)['sha256']})


for phase in ['history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates']:
    completion = load(N / phase / 'completion.json')
    assert completion['status'] == 'phase_passed'
    for receipt in completion['receipts']:
        assert receipt['exit_code'] == 0
        for stream in ('stdout', 'stderr'):
            assert pin(receipt[stream]['path'])['sha256'] == receipt[stream]['sha256']
        eid = 'native-' + receipt['name']
        path = N / phase / (receipt['name'] + '.execution.json')
        ev(eid, path, PREFIX + 'independent-qa/actual-native/' + phase + '/' + path.name,
           'Actual native command and complete original streams verified. Executed by root; this reviewer did not repeat it.')
        checks.append({'check_id': eid, 'name': 'Actual native ' + receipt['name'],
                       'status': 'passed', 'required': not receipt['name'].startswith('history-'),
                       'summary': 'Actual recorded process exited 0; scientific interpretation is separately reviewed.',
                       'target_ids': target_ids, 'command': shlex.join(receipt['argv']),
                       'exit_code': 0, 'expected_exit_code': 0, 'evidence_ids': [eid]})
        if receipt['name'] == 'tests':
            matches = re.findall(r'(\d+) passed, (\d+) skipped, (\d+) warnings?', Path(receipt['stdout']['path']).read_text())
            assert len(matches) == 1
            passed, skipped, warnings = map(int, matches[0])

for name in ('target', 'checkout'):
    receipt = load(H / (name + '.execution.json'))
    assert receipt['exit_code'] == 0
    ev('independent-' + name, H / (name + '.execution.json'), LOCAL + name + '.execution.json',
       'This reviewer executed complete current target/render/export or physical checkout/cache checks after native gates completed.')
    checks.append({'check_id': 'independent-' + name, 'name': 'Independent maintained ' + name + ' QA',
                   'status': 'passed', 'required': True, 'summary': 'Whole maintained check passed after all native gates.',
                   'target_ids': target_ids, 'command': shlex.join(receipt['argv']),
                   'exit_code': 0, 'expected_exit_code': 0, 'evidence_ids': ['independent-' + name]})

for eid, name, summary, kind in [
    ('target-helper-correction', 'target-helper-correction.json', 'Initial external target QA failed on an append-only context assumption. Exact helper, receipt, streams and partial checks are retained; the bounded corrected check requires whole canonical KGX equality, every old context as an exact ordered subsequence and precisely the accepted target contexts/multiplicity. Checkout and all native gates passed first attempt and were not repeated.', 'validation'),
    ('native-packet', 'native-execution-intake.json', f'Fresh no-follow complete closure of {intake["artifacts"]} native artifacts plus two seals, including hidden/ignored paths and every complete phase stream.', 'validation'),
    ('canonical', 'canonical-acceptance.json', 'Root accepted one native source builder and byte-exact inherited ontology; all prior objects/order, first owners and six exact added graph contexts survive.', 'prior_review'),
    ('prior-actual-audit', 'prior-actual-review-handoff.json', 'Distinct Adapter independent audit checked all 1922 actual artifacts plus two seals, all 242 scientific records, complete source objects/order and KGX. That accepted audit is inherited; I audited earlier canonical preparation, not this actual execution.', 'prior_review'),
    ('integration', 'integration-acceptance.json', f'Root accepted the exact three primary owners and {len(plan["changes"])} complete planned destinations with guarded native stages. The preparer whole {packaging["unique_bodies"]}-body portable replay is inherited.', 'prior_review'),
    ('integration-compatibility', 'integration-compatibility-review/handoff.json', 'Complete distinct 14-file compatibility review is retained with both seals, original Rhea-role assertion failure, exact failed/successor helpers and full streams. Its accepted mechanics appraisal is inherited, not repeated.', 'prior_review'),
    ('sealer-template', 'native-sealer-template-review.json', 'This reviewer read the whole bounded native sealer template and exact predecessor diff; receipt-origin/stream/closure controls remain unchanged. Static template review is distinct from root actual native execution and final runner binding.', 'prior_review'),
    ('post-package-retention', 'post-package-evidence-retention.json', 'Whole post-package compatibility and template-review bodies are retained with exact original paths, sizes, hashes and modes. These reviews postdate the scientific portable package and are retained separately here.', 'validation'),
    ('target-results', 'target-qa.json', 'Whole accepted YAML, 15 arrows, 18 display nodes, eight qualifiers, 12 identities, 18 references and all 31 evidence occurrences match. Current graph equals accepted outputs and the root-viewed static preview; mappings retain 66 old plus four new rows.', 'validation'),
    ('checkout-results', 'checkout-preservation.json', 'Complete physical inventory includes hidden/ignored paths. All 241 old records/pages, 126 review pairs, 410 histories and 800 cache entries remain exact outside the accepted scope.', 'validation'),
    ('visual', 'visual-assessment.json', 'Original preview assessment by Nitrate; root independently viewed this same whole raster as documented in the root scientific review. Current whole SVG/CSS/JS equality binds it. No personal new visual or browser assessment is claimed here.', 'prior_review'),
    ('science-scope', 'scientific-scope-acceptance.json', 'Exact accepted corrected scientific target and complete source-state/sequence/taxon/chemical/GO limitations are inherited. Separate maintained SCI judgment belongs to Adapter.', 'prior_review'),
    ('root-preview-reading', 'root-scientific-review-handoff.json', 'Root scientific review explicitly documents personal full static-raster reading, including disconnected phosphate and overlap/truncation/blank-space limitations.', 'prior_review'),
]:
    ev(eid, H / name, LOCAL + name, summary, kind)

assessments = []


def assess(aid, area, topic, summary, ids, evs):
    assessments.append({'assessment_id': aid, 'area': area, 'topic': topic, 'outcome': 'supported',
                        'summary': summary, 'target_ids': ids, 'evidence_ids': evs})


for target in inspection['targets']:
    assess(target['target_id'], 'ownership', target['path'],
           'The whole maintained source manifest or source-authority snapshot equals the exact accepted actual output. One ordinary PathBank source entry adds six selected terms; product runtime and ontology remain unchanged. Identity/name projection does not assert typed biochemical context.',
           [target['target_id']], ['canonical', 'prior-actual-audit', 'independent-target', 'integration'])
assess('prior-preservation', 'provenance', 'Whole authority and checkout preservation',
       'The 893-row manifest retains all 892 prior rows. All 2688 old source terms/711 owners and their nested encounter order survive in 2694 terms/712 owners. Ontology remains 2016 terms/five owners with exact old bytes. All 241 old scientific records/pages, 126 review pairs and 410 histories remain exact; two new histories precede SSSOM/render.',
       target_ids, ['canonical', 'prior-actual-audit', 'checkout-results', 'native-history-1', 'native-history-2'])
assess('graph-exports', 'graph', 'Whole graph, exact contexts and encounter order',
       'All 15 arrows, 18 display nodes, eight qualifiers, 18 references and 12 identities resolve. Whole current KGX equals accepted 4363 nodes/12125 edges. Every prior edge payload and relative order and every prior node aggregate/context survives. Six exact target contexts are inserted at the accepted positions, preserving every prior context in exact relative order and whole payload. The complete old-node vector equals the accepted ATP/ADP encounter permutation; removing those two IDs preserves all other relative order. Phosphate remains unconnected.',
       target_ids, ['canonical', 'prior-actual-audit', 'target-results', 'target-helper-correction', 'visual'])
assess('mapping-export', 'representation', 'Complete source mappings',
       'Native SSSOM preserves its complete header and all 66 old rows, cells, multiplicity and relative order, adding four exact mappings for 70 total.',
       target_ids, ['native-sssom', 'target-results'])
assess('native-gates', 'schema', 'Fresh maintained validation',
       f'All nine native gates passed for 242 records: {passed} tests passed, {skipped} skipped and {warnings} warnings retained. Root executed those commands; this reviewer verified exact receipts and streams without repeating passing broad gates.',
       target_ids, ['native-packet', 'native-validate', 'native-tests', 'native-lint', 'native-kgx', 'native-vendored', 'native-diff-check', 'native-site-current'])
assess('portable-evidence', 'completeness', 'Whole source and review provenance',
       f'Accepted preparation retains {packaging["unique_bodies"]} whole portable bodies. Its complete replay is inherited; maintained dossier/index bodies and all 18 reference-hash bindings are fresh. Ordinary source identity/name support remains separate from scientific assembly, donor-state, site, phosphate and strain interpretation.',
       target_ids, ['integration', 'integration-compatibility', 'sealer-template', 'post-package-retention', 'canonical', 'science-scope', 'independent-target', 'checkout-results'])

started = datetime.datetime.fromisoformat(load(H / 'technical-inspect.execution.json')['started_at']).astimezone(datetime.UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
value = {
    'schema_version': '1.0.0', 'review_id': now.strftime('%Y%m%dT%H%M%SZ') + '-baesr243-technical',
    'kind': 'repository', 'repository': 'CultureBotAI/PathwayMech',
    'title': 'Technical review of BaeSR source-authority integration',
    'started_at': started, 'finished_at': finished,
    'reviewer': {'identity': 'Codex /root/deoxy237_science_review', 'kind': 'agent', 'independence': 'independent',
                 'independence_basis': 'Authored the accepted 240 baseline and independently audited 243 canonical preparation. Did not author the 243 scientific record, authority design, canonical execution, maintained integration or native gates. Distinct Adapter actual-output audit and root scientific reading are inherited. Separate maintained SCI belongs to Adapter. This review judges the 243 source-only delta and whole maintained preservation, not a new independent review of the authored 240 baseline.'},
    'skill': '.claude/skills/review-yaml-record/SKILL.md', 'completion': 'completed',
    'verdict': 'pass_with_limitations', 'scientific_review': False,
    'summary': 'Two source-authority owners pass current maintained review. Runtime and ontology are unchanged; complete prior payloads, accepted graph ordering, mappings and cache are preserved. Actual native gates pass with inherited scientific and static-preview limitations.',
    'source': inspection['source'],
    'scope': {'description': 'Two source manifest/snapshot owners after completed record 243 gates, with complete maintained context.',
              'selection': 'Both nonrecord primary owners from clean committed 240 baseline 63bc0ba99c63e4d4cdbdf70b8fb3f6f8417eeacf; no sampling.',
              'coverage': 'full', 'population_size': 2, 'reviewed_target_ids': target_ids,
              'exclusions': [{'target': 'New primary scientific judgment', 'reason': 'Separate independent maintained SCI.'},
                             {'target': 'Publication and browser interaction', 'reason': 'Outside this local technical review.'}]},
    'targets': inspection['targets'], 'checks': checks, 'evidence': evidence,
    'assessments': assessments, 'findings': [], 'actions': [],
    'limitations': [
        'One external target-QA attempt failed because its helper required new contexts to append. The exact failed helper/streams/partial report are retained. A narrow helper correction passed; no product, accepted native output or native gate was changed. Complete checkout passed once and was not repeated.',
        'Prior distinct actual-output audit, accepted scientific reading and integration portable replay are inherited. Fresh scope is maintained record/page/export/owner preservation, full physical inventory/cache and native receipt/stream currentness. No paper reread or broad test rerun.',
        'Only one source builder ran for the accepted canonical output. Ontology was reused byte exactly. Historical SQL descriptors retain obsolete rehash prose; no new SQL hash/query or ontology builder is claimed.',
        'The root personally viewed static light preview is inherited after exact whole current SVG/CSS/JS equality. Dense convergence, long return paths, overlapping/truncated labels and tall blank canvas remain. No personal new visual, interactive, responsive, keyboard, dark or print check.',
        f'Actual regression retains {skipped} skips and {warnings} warnings with {passed} passes.',
        'Evidence references name concrete proposed dossier destinations. Exact-byte adoption and current input inspection/validation are required before native save; this external proposal itself is not saved.',
    ],
    'notes': ['Every native input hash was rechecked after actual gates and fresh maintained QA, before this proposal.',
              'The technical review uses the native repository review contract and does not claim the separate full scientific skill workflow.',
              'No maintained product edit, review save, public action or licensing clearance was performed.'],
    'links': [], 'tags': ['baesr', 'pathbank', 'technical-review', 'local-only'],
}
with (H / 'technical-proposal.json').open('x') as f:
    json.dump(value, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps({'proposal': pin(H / 'technical-proposal.json'), 'targets': len(target_ids),
                  'assessments': len(assessments), 'checks': len(checks), 'inputs': len(inspection['source']['inputs'])}))
