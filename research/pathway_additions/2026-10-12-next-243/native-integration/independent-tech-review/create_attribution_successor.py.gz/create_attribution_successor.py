import datetime,difflib,hashlib,json,os,shutil,stat
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-243-independent-maintained-tech-20261012');H=Path('/private/tmp/pathwaymech-next-243-tech-attribution-successor-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(n,v):
 with (H/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
assert not H.exists();om=json.loads((O/'artifact-manifest.json').read_bytes());allfiles=[]
for root,ds,fs in os.walk(O,followlinks=False):
 p=Path(root);assert all(not(p/d).is_symlink() for d in ds)
 for n in fs:
  q=p/n;assert stat.S_ISREG(q.lstat().st_mode);allfiles.append(q)
assert len(allfiles)==66
for r in om['artifacts']:assert pin(Path(r['path']))['sha256']==r['sha256']
shutil.copytree(O,H);history=H/'history/original-sealed-review';shutil.copytree(O,history)
for n in ('artifact-manifest.json','handoff.json','technical-validate.execution.json','technical-validate.stdout','technical-validate.stderr'):(H/n).unlink()
shutil.copy2(Path(__file__),H/'create_attribution_successor.py')
changed=[];patch=''
for n in ('technical-proposal.json','REPORT.md','write_technical_proposal.py','seal_review.py'):
 p=H/n;old=p.read_text();assert 'Distinct Aceto' in old;new=old.replace('Distinct Aceto','Distinct Adapter');p.write_text(new)
 changed.append({'path':n,'original':pin(O/n),'successor':pin(p),'exact_substitutions':old.count('Distinct Aceto')})
 patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='original/'+n,tofile='attribution-successor/'+n))
old=json.loads((O/'technical-proposal.json').read_bytes());new=json.loads((H/'technical-proposal.json').read_bytes())
assert new['reviewer']['independence_basis']==old['reviewer']['independence_basis'].replace('Distinct Aceto','Distinct Adapter')
old['reviewer']['independence_basis']=new['reviewer']['independence_basis']
for a,b in zip(old['evidence'],new['evidence']):
 if a['evidence_id']=='prior-actual-audit':a['summary']=a['summary'].replace('Distinct Aceto','Distinct Adapter')
assert old==new
at=datetime.datetime.now(datetime.UTC).isoformat()
with (H/'REPORT.md').open('a') as f:f.write('\nAttribution-only successor at '+at+'. The prior actual 243 output auditor was Codex /root/adapter_continue (Adapter), not Aceto; Aceto authored maintained integration. Original review ID, judgments, input descriptors and original review timestamps remain unchanged. The complete original sealed 64 + 2 packet is retained byte exactly under history/original-sealed-review and its source directory remains untouched. This correction reruns only native proposal validation, not QA, native gates or scientific reading. Current helper wording is corrected without executing proposal-generation or original sealer helpers again. Original false wording in historical evidence/diffs is retained as history.\n')
(H/'attribution-correction.patch').write_text(patch)
mp=[]
for q in allfiles:
 r=history/q.relative_to(O);assert q.read_bytes()==r.read_bytes();mp.append({'original':pin(q),'retained':pin(r)})
save('attribution-correction.json',{'finding_id':'baesr243-actual-audit-reviewer-attribution','corrected_at':at,'correction':'Actual 243 canonical-output reviewer is Adapter /root/adapter_continue; Aceto prepared maintained integration. Underlying accepted audit pins and all substantive judgments unchanged.','original_handoff':pin(O/'handoff.json'),'original_manifest':pin(O/'artifact-manifest.json'),'actual_audit_handoff':pin(Path('/private/tmp/pathwaymech-next-243-canonical-output-independent-review-20261012/handoff.json')),'current_attribution_changes':changed,'proposal_scope':'Exactly two string replacements, independence_basis and prior-actual-audit evidence summary; all other bytes and parsed fields exact.','original_packet_retention':mp,'root_original_closure':'476691/0','fresh_direct_audit_identity_read':'8a6ca7/0','QA_or_native_gates_reexecuted':False})
print(json.dumps({'path':str(H),'proposal':pin(H/'technical-proposal.json'),'retained_original_files':len(mp),'changes':[(r['path'],r['exact_substitutions']) for r in changed]}))
