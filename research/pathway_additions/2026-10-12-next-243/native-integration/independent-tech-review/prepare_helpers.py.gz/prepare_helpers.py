"""Prepare bounded 243 technical review helpers; never execute maintained QA."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

H = Path(__file__).parent
OLD = Path('/private/tmp/pathwaymech-next-240-independent-maintained-tech-20261012')
BASE = '63bc0ba99c63e4d4cdbdf70b8fb3f6f8417eeacf'


def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


lineage, patch = [], []
for name in ['check_target.py', 'check_checkout.py', 'run_qa.py', 'inspect_technical.py', 'validate_technical.py']:
    original = (OLD / name).read_text()
    s = original.replace('pathwaymech-next-240', 'pathwaymech-next-243').replace('2026-10-12-next-240', '2026-10-12-next-243')
    s = s.replace('5eb77a4b8039e98d9b53a61d09af52fa9f5b3d7a', BASE)
    s = s.replace('spermidine-biosynthesis-and-metabolism-escherichia-coli', 'baesr-two-component-signal-transduction').replace('SMP0002097', 'SMP0002123')
    if name == 'check_target.py':
        s = s.replace('0adef1da2d818af7c62d7e3952b2115585b47b8f132ec189cde2b435d2721680', '1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824')
        s = s.replace('243-scope-successor', '243-editorial-successor').replace('243-scoped-graph-preview', '243-graph-preview')
        s = s.replace("'18 complete paragraphs',len(pars)==18", "'13 complete paragraphs',len(pars)==13")
        s = s.replace("'58 complete edges',len(d['mechanistic_edges'])==58", "'15 complete edges',len(d['mechanistic_edges'])==15")
        s = s.replace("'four qualified endpoints'", "'eight qualified endpoints'").replace("for e in d['mechanistic_edges'])==4)", "for e in d['mechanistic_edges'])==8)")
        s = s.replace("'100 edge and qualifier evidence occurrences'", "'31 edge and qualifier evidence occurrences'").replace("for e in d['mechanistic_edges'])==100)", "for e in d['mechanistic_edges'])==31)")
        s = s.replace("'240 old records'", "'241 old records'").replace("for r in baseline)==240)", "for r in baseline)==241)")
        s = s.replace("'240 old pages',counts['pages/records/']==240", "'241 old pages',counts['pages/records/']==241")
        s = s.replace("'124 old review pairs',counts['reviews/structured/']==248", "'126 old review pairs',counts['reviews/structured/']==252")
        s = s.replace("'58 graph arrows',len(graph)==58", "'15 graph arrows',len(graph)==15")
        s = s.replace("'44 graph nodes:40 non-taxon identities plus4 qualified endpoints',len(nodes)==44", "'18 graph nodes:10 non-taxon identities plus8 qualified endpoints',len(nodes)==18")
        s = s.replace("'43 named identities',len(named)==43", "'12 named identities',len(named)==12")
        s = s.replace('len(nrows)==4357 and len(erows)==12110', 'len(nrows)==4363 and len(erows)==12125')
        s = s.replace("'SSSOM62old4new66total',len(oldrows)==62 and sum(added.values())==4 and len(newrows)==66", "'SSSOM66old4new70total',len(oldrows)==66 and sum(added.values())==4 and len(newrows)==70")
        anchor = " check('actual KGX counts',len(nrows)==4363 and len(erows)==12125)\n"
        s = s.replace(anchor, anchor + ''' # Exact accepted ordering and all old contexts are checked against the maintained baseline.
 oldnodes=tsv(gitbody('output/kgx/nodes.tsv')); oldedges=tsv(gitbody('output/kgx/edges.tsv'))
 oldmap={r['id']:r for r in oldnodes}; newmap={r['id']:r for r in nrows}
 order=json.loads(Path('/private/tmp/pathwaymech-next-243-canonical-preparation-20261012/graph-order-permutation.json').read_bytes())
 check('whole old node vector equals accepted baseline',[r['id'] for r in oldnodes]==order['old_4357_node_ids_in_actual_order'])
 check('exact ATP ADP encounter permutation',[r['id'] for r in nrows if r['id'] in oldmap]==order['expected_existing_node_ids_in_native_order'])
 accepted_output=json.loads(Path('/private/tmp/pathwaymech-next-243-root-canonical-output-acceptance-20261012.json').read_bytes())
 additions={r['id']:r['contexts'] for r in accepted_output['shared_context_additions']}
 check('six exact context additions',len(additions)==6)
 for nid,old in oldmap.items():
  new=newmap[nid]
  check('old node aggregate preserved '+nid,{k:v for k,v in old.items() if k!='source_contexts'}=={k:v for k,v in new.items() if k!='source_contexts'})
  check('old contexts and exact target additions '+nid,json.loads(new['source_contexts'])==json.loads(old['source_contexts'])+additions.get(nid,[]))
 oldedge_ids={e['id'] for e in oldedges}
 check('all prior edge payloads and relative order exact',[r for r in erows if r['id'] in oldedge_ids]==oldedges)
 runtime=json.loads((prep/'runtime-owner-map.json').read_bytes())
 check('280 runtime owners reconciled',len(runtime['runtime'])==280)
 for row in runtime['runtime']:
  rel=row['relative_path'];check('effective runtime owner '+rel,pin(ROOT/rel)['sha256']==row['effective_integration']['sha256'])
  if rel!='conf/identifier_sources.json':check('unchanged baseline runtime '+rel,pin(ROOT/rel)['sha256']==row['before']['sha256'])
 check('whole ontology unchanged from baseline',(ROOT/'data/identifier_authorities/ontology.json').read_bytes()==gitbody('data/identifier_authorities/ontology.json'))
 marker='PathBank:SMP0002123/Compound/PW_C001104'
 check('native phosphate marker remains unconnected',all(marker not in (e['subject'],e['object']) for e in d['mechanistic_edges']))
''')
    if name == 'check_checkout.py':
        anchor = "value={'status':'complete_checkout_preservation_after_native_gates_passed'"
        s = s.replace(anchor, '''# Require complete immutable native evidence before final maintained review.
handoff=c.load(receipts/'handoff.json');c.verify(handoff['manifest'],receipts/'artifact-manifest.json')
manifest=c.load(receipts/'artifact-manifest.json');rows=manifest.get('artifacts',manifest.get('files'));declared=set()
for row in rows:
 rel=row.get('relative_path') or str(Path(row['path']).relative_to(receipts));c.relative(rel);assert rel not in declared;declared.add(rel);c.verify(row,receipts/rel)
actual,native_dirs=c.inventory(receipts);assert all(r['type']=='regular' for r in actual)
assert {r['path'] for r in actual}==declared|{'handoff.json','artifact-manifest.json'}
assert set(native_dirs)==set(manifest['directories'])-{'.'}
intake={'status':'whole_native_packet_and_all_phase_streams_verified','handoff':c.pin(receipts/'handoff.json'),'manifest':c.pin(receipts/'artifact-manifest.json'),'artifacts':len(rows),'seals':2,'descendant_directories':len(native_dirs),'hidden_ignored_included':True,'directory_aliases_followed':False}
with (out/'native-execution-intake.json').open('x') as f:json.dump(intake,f,indent=2);f.write('\\n')
''' + anchor)
    if name == 'inspect_technical.py':
        s = s.replace('all 240 gates', 'all 243 gates').replace('assert len(paths) == 8', "assert set(paths) == {'conf/identifier_sources.json','data/identifier_authorities/sources.json'}")
        s = s.replace('Exact adopted source configuration, reviewed runtime/fixture/test, or native authority snapshot.', 'Exact adopted source manifest or native source-authority snapshot; product runtime and ontology are unchanged.')
    ast.parse(s)
    with (H / name).open('x') as f:
        f.write(s)
    lineage.append({'helper': name, 'predecessor': pin(OLD/name), 'prepared': pin(H/name)})
    patch.extend(difflib.unified_diff(original.splitlines(True), s.splitlines(True), fromfile='240/'+name, tofile='243/'+name))
(H/'helper-lineage.json').write_text(json.dumps(lineage, indent=2)+'\n')
(H/'helper-rebase.patch').write_text(''.join(patch))
print('Five technical QA helpers prepared and AST parsed; no helper executed.')
