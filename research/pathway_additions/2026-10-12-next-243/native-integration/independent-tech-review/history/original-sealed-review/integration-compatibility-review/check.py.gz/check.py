"""Bounded read-only compatibility appraisal; external outputs only."""
import ast,datetime,hashlib,json,os,stat,sys
from pathlib import Path
H=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-243-local-integration-preparation-20261012')
O=Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012')
sys.path.insert(0,str(P))
import common as c
from package_evidence import Store

def pin(p):
 assert stat.S_ISREG(p.lstat().st_mode),p
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(p.read_bytes())
def equal_ast(a,b):return ast.dump(ast.parse(a))==ast.dump(ast.parse(b))
def funcs(p):return {n.name:ast.dump(n) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
handoff=pin(P/'handoff.json');manifest=pin(P/'artifact-manifest.json');h=load(P/'handoff.json');m=load(P/'artifact-manifest.json')
assert h['manifest']==manifest
rows=m['artifacts'];expected={r['relative_path']:r for r in rows};assert len(rows)==len(expected)
seen=set();dirs=[]
for base,ds,fs in os.walk(P,followlinks=False):
 for name in ds:
  p=Path(base)/name;assert stat.S_ISDIR(p.lstat().st_mode);dirs.append(str(p.relative_to(P)))
 for name in fs:
  p=Path(base)/name;bound=pin(p);rel=str(p.relative_to(P));seen.add(rel)
  if rel not in ['handoff.json','artifact-manifest.json']:
   r=expected[rel];assert all(bound[k]==r[k] for k in ['path','bytes','sha256'])
assert seen==set(expected)|{'handoff.json','artifact-manifest.json'}
assert sorted(dirs)==sorted(m['directories'])
# The compatibility dialect is the only packet closure-function change.
a=(O/'package_evidence.py').read_text();b=(P/'package_evidence.py').read_text()
def methods(s):
 cls=next(n for n in ast.parse(s).body if isinstance(n,ast.ClassDef) and n.name=='Store')
 return {n.name:ast.dump(n) for n in cls.body if isinstance(n,ast.FunctionDef)}
a=a.replace('expected = {locate_member_name(r, root): r for r in m["artifacts"]}\n        assert len(expected) == len(m["artifacts"])','assert ("artifacts" in m) != ("files" in m), "Exactly one manifest collection is required"\n        manifest_rows = m["artifacts"] if "artifacts" in m else m["files"]\n        expected = {locate_member_name(r, root): r for r in manifest_rows}\n        assert len(expected) == len(manifest_rows)')
ma,mb=methods(a),methods(b)
for name in ['packet','owner','retrieve','put','close']:assert ma[name]==mb[name],name
fa,fb=funcs(O/'common.py'),funcs(P/'common.py')
for name in set(fa)-{'approval_check'}:assert fa[name]==fb[name],name
assert fa['approval_check'].replace('pathbank240','baesr243')==fb['approval_check']
assert equal_ast((O/'adopt.py').read_text().replace('next-240','next-243').replace('pathbank240','baesr243'),(P/'adopt.py').read_text())
for name in ['verify_portable.py','split_archive.py']:assert (O/name).read_bytes()==(P/name).read_bytes(),name
# Replay the producer's two tiny physical controls without creating fixtures or package outputs.
class Sink:
 def put(self,body):return hashlib.sha256(body).hexdigest()
 def owner(self,path,expected=None):return Store.owner(self,path,expected)
controls=[]
for name in ['valid-files','ambiguous']:
 try:packet,closure=Store.packet(Sink(),P/'manifest-collection-fixtures'/name)
 except AssertionError as exc:
  assert name=='ambiguous' and str(exc)=='Exactly one manifest collection is required'
  controls.append({'case':name,'outcome':'rejected_before_traversal'})
 else:
  assert name=='valid-files' and closure['declared_artifacts']==1 and closure['physical_files']==3 and not closure['declared_followed_views_not_traversed']
  controls.append({'case':name,'outcome':'complete_physical_type_hash_closure_passed'})
plan=load(P/'plan.json');c.scope_check(plan)
primary={r['destination'] for r in plan['changes'] if not r['destination'].startswith(c.DOSSIER+'/')}
assert primary=={'conf/identifier_sources.json','data/identifier_authorities/sources.json','data/pathways/baesr-two-component-signal-transduction.yaml'}
assert len(primary)==3
runtime=load(P/'runtime-owner-map.json');assert runtime['runtime_count']==len(runtime['runtime'])==280
assert [r['relative_path'] for r in runtime['runtime'] if r['changed']]==['conf/identifier_sources.json']
for r in runtime['runtime']:
 assert len({(r[k]['sha256'],r[k]['bytes']) for k in ['accepted','effective_preparation','actual_runtime']})==1
 if not r['changed']:
  assert (r['effective_integration']['sha256'],r['effective_integration']['bytes'])==(r['before']['sha256'],r['before']['bytes'])
  if r['relative_path']=='conf/rhea_identifier_updates.json':
   assert r['override_reason']=='Exact explicit configuration consumed by accepted native CLI'
   assert r['effective_integration']==runtime['explicit_native_configuration_inputs'][r['relative_path']]
   assert r['before']['sha256']=='5c6a356a56a4b4df882ac2898587576216895a07fc2b455082da136ebd91a49d'
  else:assert len({(r[k]['sha256'],r[k]['bytes']) for k in ['accepted','effective_preparation','actual_runtime','effective_integration','before']})==1
assert runtime['explicit_native_configuration_inputs']['conf/identifier_sources.json']['sha256']=='066b504bc00b8fd3b2bb15d9833524277dccf2ce4961c70e00d68dfbd324aed3'
assert len({(r['sha256'],r['bytes']) for r in runtime['unchanged_ontology_not_adopted'].values()})==1
baseline=load(P/'baseline-files.json');assert len({r['path'] for r in baseline})==len(baseline)
semantic=load(P/'semantic-preservation.json');assert semantic['old_records']==241 and semantic['old_review_yaml']==semantic['old_review_markdown']==126 and semantic['old_history_yaml']==410
assert semantic['all_old_manifest_fields_order_exact'] and semantic['manifest_prefix_rows']==892 and semantic['manifest_after_rows']==893
assert semantic['exact_aggregate_changes']==[] and semantic['all_other_old_nodes_relative_order_exact'] and semantic['old_node_encounter_relative_order_exact'] is False
accepted=load(Path('/private/tmp/pathwaymech-next-243-root-canonical-output-acceptance-20261012.json'))
assert semantic['exact_old_node_order_exception']==accepted['node_order_exception']['exact_full_vectors']
c.verify(semantic['exact_old_node_order_exception'])
assert semantic['existing_node_added_contexts']==6
replay=load(P/'receipts/portable-replay.stdout');summary=load(P/'packaging-summary.json')
assert replay['status']=='all_portable_evidence_bodies_retrieved_and_verified'
assert replay['unique_bodies']==summary['unique_bodies']==2421
assert replay['originals']==summary['original_group_counts']
assert replay['originals']['whole_scientific_originals']==48 and replay['originals']['scientific_native_originals']==3
read_receipts={}
for n in ['baseline','collection-controls','evidence-package','semantic','portable-replay']:
 receipt=load(P/'receipts'/f'{n}.json');assert receipt['exit_code']==0
 read_receipts[n]=pin(P/'receipts'/f'{n}.json')
assert pin(P/'handoff.json')==handoff and pin(P/'artifact-manifest.json')==manifest
result={'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'bounded_compatibility_checks_passed','subject':{'handoff':handoff,'manifest':manifest,'artifacts':len(rows),'directories_including_root':len(dirs)+1},'primary_owners':sorted(primary),'planned_owners':len(plan['changes']),'runtime_map_rows':280,'runtime_map_changed_configuration_only':['conf/identifier_sources.json'],'source_code_and_ontology_unchanged':True,'unchanged_effective_Rhea_config_override':'Historical runtime796B; accepted explicit CLI input and unchanged maintained baseline832B. No Rhea payload owner.','complete_external_preparation_closure_fresh':True,'guard_methods_AST_unchanged_except_declared_rebase':sorted(fa),'packet_method_only_XOR_collection_change':True,'unchanged_Store_methods':['owner','retrieve','put','close'],'decoder_and_archive_splitter_byte_identical':True,'fresh_collection_replays':controls,'inherited_complete_physical_preservation_receipts':read_receipts,'baseline_files':len(baseline),'baseline_directories':len(load(P/'baseline-directories.json')),'native_permutation_exact_pin':semantic['exact_old_node_order_exception'],'portable_bodies':2421,'portable_decoded_bytes':replay['unique_body_bytes'],'portable_replay_inherited_not_rerun':True,'scientific_body_rows_preservation_not_support':48,'native_body_rows':3,'cited_references':18,'controls_inherited':{'guard_tests':42,'alias_type_tests':6},'code_pins':[pin(P/n) for n in ['common.py','adopt.py','capture.py','package_evidence.py','prepare_plan.py','finish.py','verify_portable.py','split_archive.py','complete-helper-rebase.patch']],'limits':['No maintained inventory/cache/full portable replay repeated: actual author baseline/package/final-preflight receipts and unchanged reviewed controls are inherited.','Own previous accepted243 actual audit establishes full old KGX rows and exact ATP/ADP permutation; no native builder/full corpus gate/SQL hash repeated.','This mechanics review performs no maintained adoption, native gate or SCI judgment.'],'findings':[]}
(H/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['status','subject','primary_owners','planned_owners','baseline_files','baseline_directories','portable_bodies','findings']},indent=2))
