import datetime,difflib,hashlib,json,os,stat
from pathlib import Path
H=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-243-local-20261012');O=Path('/private/tmp/pathwaymech-next-240-independent-maintained-tech-20261012')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'file_type':'regular','link_text':None,'resolved_path':str(p.resolve())}
def save(n,x):
 with (H/n).open('x') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
def basic(p):return {k:v for k,v in pin(p).items() if k in ('path','bytes','sha256')}
proposal=load(H/'technical-proposal.json');validate=load(H/'technical-validate.execution.json');assert validate['exit_code']==0
assert basic(H/'technical-proposal.json')==validate['content']
for row in proposal['source']['inputs']:
 assert basic(R/row['path'])['sha256']==row['sha256']
assert len(proposal['source']['inputs'])==25
assert not proposal['findings'] and len(proposal['assessments'])==7
qa=load(H/'target-qa.json');assert len(qa['checks'])==15294 and all(x['passed'] for x in qa['checks'])
ret=load(H/'post-package-evidence-retention.json')
for row in ret['file_mappings']:
 for key in ('original','retained'):assert basic(row[key]['path'])==row[key]
for key in ('original','retained'):assert basic(ret['sealer_template_review'][key]['path'])==ret['sealer_template_review'][key]
compat=H/'integration-compatibility-review';cm=load(compat/'artifact-manifest.json');expected=set()
for row in cm['artifacts']:
 q=compat/Path(row['path']).name;assert basic(q)['sha256']==row['sha256'];expected.add(q.name)
assert {p.name for p in compat.iterdir()}==expected|{'artifact-manifest.json','handoff.json'}
for row in load(H/'target-helper-correction.json')['retained']:
 assert basic(row['retained'])['sha256']==row['sha256']
helpers=['check_target.py','check_checkout.py','run_qa.py','inspect_technical.py','write_technical_proposal.py','validate_technical.py']
patch='';lineage=[]
for n in helpers:
 patch+=''.join(difflib.unified_diff((O/n).read_text().splitlines(True),(H/n).read_text().splitlines(True),fromfile='accepted240/'+n,tofile='final243/'+n))
 lineage.append({'name':n,'accepted_predecessor':pin(O/n),'final':pin(H/n)})
(H/'final-helper-rebase.patch').write_text(patch)
save('final-helper-lineage.json',{'scope':'Prepared historical bindings remain unchanged; these final helpers include the bounded target assertion correction and truthful proposal wording. Initial generator historical bytes were not retained; initial actually executed target helper and wrapper were retained exactly.','helpers':lineage,'target_correction':pin(H/'target-helper-correction.json')})
save('actual-review-tools.json',{'target_initial':{'tool':'b3f914','session':67852,'completion':'16998c','exit_code':1,'receipt':pin(H/'history/target-initial/target.execution.json')},'target_correction_execution':{'tool':'24dfc3','session':95150,'completion':'9a9539','exit_code':0,'receipt':pin(H/'target.execution.json')},'checkout':{'tool':'223f28','session':28168,'completion':'06b2ca','exit_code':0,'receipt':pin(H/'checkout.execution.json')},'inspect':{'tool':'2d2526','session':74821,'completion':'344da5','exit_code':0,'receipt':pin(H/'technical-inspect.execution.json')},'proposal':{'tool':'306d24','exit_code':0,'helper':pin(H/'write_technical_proposal.py'),'body':pin(H/'technical-proposal.json')},'validate':{'tool':'915168','session':97101,'completion':'7fe509','exit_code':0,'receipt':pin(H/'technical-validate.execution.json')},'native_execution':'Root owned all native gates; original root packet remains unchanged and all phases passed first attempt.'})
report='''Independent maintained TECH review passes with limitations and no current findings. Both nonrecord primary owners, the source manifest and source-authority snapshot, equal accepted actual 243 outputs. Runtime code and ontology are unchanged. This reviewer authored the accepted 240 baseline and independently audited 243 canonical preparation and the bounded native evidence-sealer template. The reviewer did not author the 243 scientific record, authority design, canonical execution, maintained integration or native gates. Distinct Adapter actual-output audit and root scientific reading are inherited. Separate maintained SCI belongs to Adapter.

Fresh target QA passed 15,294 recorded checks. The complete maintained YAML equals accepted 34,636-byte draft 1cf9262a…; all 13 paragraphs, 15 graph arrows and table rows, 18 display nodes, eight qualifiers, 12 identities, 18 references, four mappings and 31 evidence occurrences/links are reconciled. The complete SVG and style/CSS/JS bodies equal the previously root-viewed static light preview. Root’s visual reading is inherited; this reviewer makes no new visual/browser claim. Dense convergence, long returns, overlapping and truncated labels, and tall blank canvas remain; no interactive, mobile, keyboard, dark-mode or print assessment. The native phosphate marker remains disconnected.

Both complete CLI and downloadable KGX exports equal accepted actual 243 bytes: 4,363 nodes and 12,125 edges. The exact whole prior-node encounter vector admits only the accepted ATP/ADP permutation. All prior node aggregate fields, every whole prior context in exact relative order, six exact added target contexts/multiplicity, and all prior edge payloads/relative order survive. Native SSSOM preserves the whole header and 66 prior rows/cells/multiplicity/order plus four exact new rows, for 70. Whole maintained authorities equal canonical outputs: 2,694 source terms/712 owners and unchanged 2,016 ontology terms/five owners. The distinct accepted canonical audit is inherited for complete old nested source objects/order and source-first-owner preservation; no new native builders, ontology queries/hashes or broad suites were run.

One external target-check attempt failed because its helper required new contexts to append at the end. Actual canonical output inserts this record at its accepted encounter position. The original 12,794-byte executed helper, wrapper, failure receipt, stderr/stdout and complete partial check report are retained under history/target-initial. The narrow successor checks exact old ordered contexts and precisely the six accepted additions, still requiring whole KGX byte equality to frozen accepted 243. It passed on its next execution. This was a review-helper correction, not a product or native-gate failure. The separate checkout check passed first attempt and was not repeated. Native inspect, proposal creation and native serializer validation each passed first attempt.

The full physical checkout inventory includes hidden/ignored files without following directory links: 13,504 old files to 13,517 current, 2,117 to 2,121 directories. All 241 old scientific YAMLs/pages, 126 review pairs and 410 history YAMLs remain exact outside the plan. All 12 adopted owners are exact; only declared generated files and two new histories are allowed. All 800 cache identities/bodies are unchanged. Both histories precede SSSOM/render. Raw group counts also include ancillary README files and are not record/history-YAML counts.

All 81 native artifacts plus two seals, 11 descendant directories and every recorded phase stream were freshly closed. All four phases and nine native gates passed first attempt: 4,773 tests passed, three skipped and three warnings. Root executed those commands; this reviewer verified receipts and streams. Integration’s 2,421-body portable replay is inherited; maintained dossier/index bodies and all 18 reference hash bindings are fresh. All 14 post-package compatibility review files, including original failure, failed/successor helpers, streams and both seals, are retained byte exactly under integration-compatibility-review. The native sealer-template review receipt and whole original-to-retained mappings also remain exact. That distinct compatibility review’s Rhea-role assertion failure was external and did not alter product bytes.

Six established helpers were boundedly rebased; final complete diffs and helper lineage are retained. The pre-execution preparation-status and helper-lineage files describe their historical point in time, not the final executed state. The initially invoked generator’s pre-refinement body was not preserved; the actual failed target helper and actual final helpers are preserved. No historical body is reconstructed or claimed exact when unavailable. Native inspect captured two targets and 23 additional inputs (25 total); all current input hashes were rechecked before proposal creation and before sealing. The proposal contains seven supported assessments, 14 checks, no findings and scientific_review:false. Native validate returned valid_reviews1/exit0 with only the shared topClass deprecation diagnostic. Original judgments/timestamps must remain unchanged during any authorized evidence-input extension.

This is an external validated proposal, not a saved native review. Proposed durable prefix is research/pathway_additions/2026-10-12-next-243/native-integration/independent-tech-review/; native execution references use independent-qa/actual-native/. Root must appraise exact evidence/current inputs before save. No maintained edit, review save, Git/public action or licensing clearance was performed. Actual UTC timestamps are 2026-10-13; historical task paths retain 20261012 without backdating.
'''
(H/'REPORT.md').write_text(report)
save('review-result.json',{'status':'pass_with_limitations','reviewer':'Codex /root/deoxy237_science_review','scientific_review':False,'required_findings':[],'target_checks':len(qa['checks']),'technical_targets':2,'native_inputs':25,'assessments':7,'checks':14,'evidence':len(proposal['evidence']),'target_QA':pin(H/'target-qa.json'),'checkout_QA':pin(H/'checkout-preservation.json'),'native_packet_intake':pin(H/'native-execution-intake.json'),'technical_proposal':pin(H/'technical-proposal.json'),'technical_native_validation':pin(H/'technical-validate.execution.json'),'external_helper_failure_retained':pin(H/'target-helper-correction.json'),'post_package_complete_retention':pin(H/'post-package-evidence-retention.json'),'fresh_vs_inherited':proposal['limitations'],'native_review_saved':False,'maintained_edits':False})
artifacts=[];dirs=[]
for root,ds,fs in os.walk(H,followlinks=False):
 root=Path(root);dirs.append(root.relative_to(H).as_posix());assert all(not(root/d).is_symlink() for d in ds)
 for n in fs:
  p=root/n
  if p.parent==H and n in ('handoff.json','artifact-manifest.json'):continue
  artifacts.append(pin(p))
artifacts.sort(key=lambda r:r['path']);dirs.sort()
save('artifact-manifest.json',{'artifacts':artifacts,'directories':dirs,'hidden_ignored_included':True})
save('handoff.json',{'status':'independent_maintained_technical_proposal_validated_pending_root_acceptance','at':datetime.datetime.now(datetime.UTC).isoformat(),'reviewer':'Codex /root/deoxy237_science_review','manifest':pin(H/'artifact-manifest.json'),'artifacts':len(artifacts),'seals':2,'directories':len(dirs),'report':pin(H/'REPORT.md'),'result':pin(H/'review-result.json'),'technical_proposal':pin(H/'technical-proposal.json'),'technical_native_validation':pin(H/'technical-validate.execution.json'),'target_QA':pin(H/'target-qa.json'),'checkout_QA':pin(H/'checkout-preservation.json'),'scientific_review':False,'native_review_saved':False,'maintained_edits':False,'root_final_acceptance_required':True,'publication_authorized':False})
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(artifacts),'directories':len(dirs),'proposal':pin(H/'technical-proposal.json'),'validation':pin(H/'technical-validate.execution.json')}))
