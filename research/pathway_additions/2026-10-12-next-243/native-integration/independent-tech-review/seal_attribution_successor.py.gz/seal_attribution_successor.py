import datetime,hashlib,json,os,stat
from pathlib import Path
H=Path(__file__).parent;O=Path('/private/tmp/pathwaymech-next-243-independent-maintained-tech-20261012');R=Path('/private/tmp/pathwaymech-next-243-local-20261012')
def load(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'file_type':'regular','link_text':None,'resolved_path':str(p.resolve())}
def basic(p):return {k:v for k,v in pin(p).items() if k in ('path','bytes','sha256')}
def save(n,v):
 with (H/n).open('w') as f:json.dump(v,f,indent=2);f.write('\n')
p=load(H/'technical-proposal.json');o=load(O/'technical-proposal.json');v=load(H/'technical-validate.execution.json');c=load(H/'attribution-correction.json')
assert v['exit_code']==0 and v['content']==basic(H/'technical-proposal.json')
expected=(O/'technical-proposal.json').read_bytes().replace(b'Distinct Aceto',b'Distinct Adapter');assert expected==(H/'technical-proposal.json').read_bytes()
for k in ('review_id','started_at','finished_at','assessments','checks','findings','actions','source','targets','verdict'):assert p[k]==o[k]
for row in p['source']['inputs']:assert pin(R/row['path'])['sha256']==row['sha256']
for row in c['original_packet_retention']:
 for key in ('original','retained'):assert basic(row[key]['path'])==row[key]
assert len(c['original_packet_retention'])==66
assert load(H/'prior-actual-review-handoff.json')['reviewer']=='Codex /root/adapter_continue'
# Unaffected original bodies and old seals remain exact; modified current claims are enumerated.
changed={'technical-proposal.json','REPORT.md','write_technical_proposal.py','seal_review.py','review-result.json','technical-validate.execution.json','technical-validate.stdout','technical-validate.stderr'}
for r in load(O/'artifact-manifest.json')['artifacts']:
 rel=Path(r['path']).relative_to(O)
 if str(rel) not in changed:assert (H/rel).read_bytes()==(O/rel).read_bytes(),rel
res=load(O/'review-result.json');res['technical_proposal']=pin(H/'technical-proposal.json');res['technical_native_validation']=pin(H/'technical-validate.execution.json');res['attribution_successor']={'corrected_at':c['corrected_at'],'finding_id':c['finding_id'],'actual_output_auditor':'Codex /root/adapter_continue','root_cause':'Reviewer attribution transcription error; all inherited audit hashes were already correct.','lineage':pin(H/'attribution-correction.json'),'original_sealed_handoff':pin(O/'handoff.json'),'original_packet_retained_whole':66,'review_judgments_ID_original_times_inputs_unchanged':True,'QA_native_gates_rerun':False};save('review-result.json',res)
save('attribution-successor-result.json',{'status':'attribution_only_corrected_and_native_validated','at':datetime.datetime.now(datetime.UTC).isoformat(),'exact_proposal_string_changes':2,'all_other_proposal_bytes_unchanged':True,'original_review_ID_times_judgments_unchanged':True,'current_inputs_freshly_rechecked':25,'original_packet_retained_files':66,'native_validation':pin(H/'technical-validate.execution.json'),'actual_tool':'e48808/session7862 -> 4ab34e/0','scope':'Only proposal native validation rerun; initial QA/native/compatibility evidence and executed helper receipts remain original evidence. Original final-helper-lineage/patch and actual-review-tools describe the original execution, not this correction. Current attribution changes are enumerated separately.','current_corrected_helpers':[pin(H/'write_technical_proposal.py'),pin(H/'seal_review.py')],'root_acceptance_pending':True})
files=[];dirs=[]
for root,ds,fs in os.walk(H,followlinks=False):
 root=Path(root);dirs.append(root.relative_to(H).as_posix());assert all(not(root/d).is_symlink() for d in ds)
 for n in fs:
  if root==H and n in ('artifact-manifest.json','handoff.json'):continue
  files.append(pin(root/n))
files.sort(key=lambda r:r['path']);dirs.sort();save('artifact-manifest.json',{'artifacts':files,'directories':dirs,'hidden_ignored_included':True})
h=load(O/'handoff.json');h.update({'at':datetime.datetime.now(datetime.UTC).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'directories':len(dirs),'report':pin(H/'REPORT.md'),'result':pin(H/'review-result.json'),'technical_proposal':pin(H/'technical-proposal.json'),'technical_native_validation':pin(H/'technical-validate.execution.json'),'target_QA':pin(H/'target-qa.json'),'checkout_QA':pin(H/'checkout-preservation.json'),'attribution_successor':pin(H/'attribution-successor-result.json'),'original_handoff':pin(O/'handoff.json')});save('handoff.json',h)
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'proposal':pin(H/'technical-proposal.json'),'validate':pin(H/'technical-validate.execution.json'),'report':pin(H/'REPORT.md'),'result':pin(H/'review-result.json'),'artifacts':len(files),'directories':len(dirs)}))
