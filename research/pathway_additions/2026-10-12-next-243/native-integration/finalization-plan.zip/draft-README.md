# 243 finalization helper skeleton

Draft helpers only. The exact completed240 pipeline is reused with243 paths and review counts126→128. `finalize_native_inputs.py` is byte identical (SHA256313422118bfc726ca607ce2fb184bbbf34f998ae63507719967fcd72db2497a4). The three execution helper diffs alter only paths/prose and saved-pair counts; receipt/stream/current-input and original judgment/identity/time preservation logic is unchanged.

SCI uses `native-integration/independent-qa`; TECH uses `native-integration/independent-tech-review`. The four phases remain evidence adoption, native input extension/validation, two serializer saves/append-only checks, and complete execution-evidence retention/preservation. Expected maintained counts after gates are242 records and412 histories, with126 old review pairs before two new reviews.

Final source packet/proposal hashes, actual native execution evidence, original descriptor counts, complete copy plan, gzip/identity storage ledger and root combined judgment remain pending. No final seal or execution authorization is claimed. No evidence has been adopted, review saved, file staged or commit made by this skeleton. There are no new tests, builders or review judgments.
