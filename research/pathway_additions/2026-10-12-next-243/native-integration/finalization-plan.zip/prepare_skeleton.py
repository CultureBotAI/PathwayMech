"""Bounded final240 helper reuse; exact review evidence remains pending."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

H = Path(__file__).parent
OLD = Path('/private/tmp/pathwaymech-next-240-finalization-preparation-20261012')
PRE = Path('/private/tmp/pathwaymech-next-243-local-integration-preparation-20261012')
ROOT = Path('/private/tmp/pathwaymech-next-243-local-20261012')

def pin(path):
    b = path.read_bytes()
    return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

rows=[]
for name in ['adopt_evidence.py','save_reviews.py','retain_finalization.py','finalize_native_inputs.py']:
    before=(OLD/name).read_text()
    after=before
    if name!='finalize_native_inputs.py':
        after=after.replace('pathwaymech-next-240','pathwaymech-next-243')
        after=after.replace('approved240','approved243').replace('native240','native243').replace('Exact 240 native-review','Exact 243 native-review')
        if name=='save_reviews.py':
            assert "==126" in after and "'old_pairs_preserved':124,'total_pairs':126" in after
            after=after.replace('==126','==128').replace("'old_pairs_preserved':124,'total_pairs':126","'old_pairs_preserved':126,'total_pairs':128")
    ast.parse(after)
    (H/name).write_text(after)
    difference=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='240/'+name,tofile='243/'+name))
    (H/(name+'.diff')).write_text(difference)
    rows.append({'helper':name,'predecessor':pin(OLD/name),'prepared':pin(H/name),'exact_byte_identity':before==after,'exact_diff':pin(H/(name+'.diff')),'scope':'Paths/prose only; save count126→128 with126 old pairs. All original review preservation logic unchanged.' if name!='finalize_native_inputs.py' else 'Byte-identical native input finalizer.'})
assert (H/'finalize_native_inputs.py').read_bytes()==(OLD/'finalize_native_inputs.py').read_bytes()
assert pin(H/'finalize_native_inputs.py')['sha256']=='313422118bfc726ca607ce2fb184bbbf34f998ae63507719967fcd72db2497a4'
wrapper=PRE/'native-capture-wrapper.py'
(H/'capture-wrapper.py').write_bytes(wrapper.read_bytes())
rows.append({'helper':'capture-wrapper.py','predecessor':pin(wrapper),'prepared':pin(H/'capture-wrapper.py'),'exact_byte_identity':True})
(H/'helper-lineage.json').write_text(json.dumps(rows,indent=2)+'\n')
plan=json.loads((OLD/'plan.json').read_bytes())
commands=json.loads(json.dumps(plan['commands_in_order']).replace('pathwaymech-next-240','pathwaymech-next-243'))
status={
 'status':'draft_helpers_only_pending_actual_reviews_and_root_judgment',
 'target':str(ROOT),
 'base_commit':'63bc0ba99c63e4d4cdbdf70b8fb3f6f8417eeacf',
 'base_tree':'e2b94367c9c487e656d35acb554b87f333c41570',
 'integration_preparation':pin(PRE/'handoff.json'),
 'durable_prefixes':{'scientific':'research/pathway_additions/2026-10-12-next-243/native-integration/independent-qa','technical':'research/pathway_additions/2026-10-12-next-243/native-integration/independent-tech-review'},
 'expected_after_native_gates':{'records':242,'histories':412,'review_pairs_before':126,'review_pairs_after':128},
 'pending_source_derived_bindings':['Sealed scientific proposal/packet and original native descriptors','Sealed technical proposal/packet and original native descriptors','Whole actual native execution packet and failure provenance','Combined root judgment receipt','Exact body counts, deterministic .py.gz owners, direct evidence paths, complete decoded packet closures and current source inputs'],
 'commands_in_order_not_executed':commands,
 'native_input_extension':'Byte-identical finalizer; preserve original descriptors and all non-source judgments/identity/times, then exact current inspect/validate. Save helper separately requires every original source field except added inputs unchanged.',
 'storage':'Proven lossless deterministic .py.gz and identity copy map; final copy-plan and storage-ledger not created until actual sealed inputs exist.',
 'preservation':'Whole old owners/physical directories/cache; decode all originals; preload bytes; four native review files only; exact whole saved input currentness and append-only native check.',
 'roles':{'preparer':'/root/aceto236_design_acceptance_review; 243 integration preparer, no new independent judgment','scientific':'/root/adapter_continue','technical':'/root/deoxy237_science_review'},
 'not_executed':['Evidence adoption','Native input extension','Native review saves','Stage','Commit','Publication'],
 'no_execution_acceptance_claimed':True
}
(H/'draft-status.json').write_text(json.dumps(status,indent=2)+'\n')
(H/'README.md').write_text('''# 243 finalization helper skeleton

Draft helpers only. The exact completed240 pipeline is reused with243 paths and review counts126→128. `finalize_native_inputs.py` is byte identical (SHA256313422118bfc726ca607ce2fb184bbbf34f998ae63507719967fcd72db2497a4). The three execution helper diffs alter only paths/prose and saved-pair counts; receipt/stream/current-input and original judgment/identity/time preservation logic is unchanged.

SCI uses `native-integration/independent-qa`; TECH uses `native-integration/independent-tech-review`. The four phases remain evidence adoption, native input extension/validation, two serializer saves/append-only checks, and complete execution-evidence retention/preservation. Expected maintained counts after gates are242 records and412 histories, with126 old review pairs before two new reviews.

Final source packet/proposal hashes, actual native execution evidence, original descriptor counts, complete copy plan, gzip/identity storage ledger and root combined judgment remain pending. No final seal or execution authorization is claimed. No evidence has been adopted, review saved, file staged or commit made by this skeleton. There are no new tests, builders or review judgments.
''')
print(json.dumps({'status':status['status'],'helpers':len(rows),'finalizer':pin(H/'finalize_native_inputs.py'),'draft_status':pin(H/'draft-status.json')},indent=2))
