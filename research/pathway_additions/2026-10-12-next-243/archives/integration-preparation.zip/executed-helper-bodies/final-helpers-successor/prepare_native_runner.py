"""Retain inert accepted240 phase runner with bounded BaeSR bindings."""
import ast
import difflib
from pathlib import Path
import common as c
H = c.HERE
old = Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012/native-runner-template.py')
s = old.read_text().replace('pathwaymech-next-240','pathwaymech-next-243').replace('pathbank240','baesr243').replace('5eb77a4b8039e98d9b53a61d09af52fa9f5b3d7a', c.BASE).replace('spermidine-biosynthesis-and-metabolism-escherichia-coli','baesr-two-component-signal-transduction').replace('0adef1da2d818af7c62d7e3952b2115585b47b8f132ec189cde2b435d2721680','1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824')
for a,b in [('assert len(old) == 408','assert len(old) == 410'),('"old_histories": 408','"old_histories": 410'),('check_histories(408 if phase == "history-and-generation" else 410)','check_histories(410 if phase == "history-and-generation" else 412)'),('check_histories(410)','check_histories(412)'),('sum(before.values()) == 62 and sum(expected.values()) == 4 and sum(after.values()) == 66','sum(before.values()) == 66 and sum(expected.values()) == 4 and sum(after.values()) == 70'),('"old_rows": 62','"old_rows": 66'),('"total_rows": 66','"total_rows": 70'),('len(state["changes"]) == 18','len(state["changes"]) == 12'),('assert len(records) == 241','assert len(records) == 242')]:
    assert a in s,a
    s=s.replace(a,b)
values={'EXPECTED_STAGE':c.pin(H/'stages.json')['sha256'],'EXPECTED_HANDOFF':'','EXPECTED_PLAN':'','EXPECTED_SEMANTIC':c.pin(H/'semantic-preservation.json')['sha256'],'EXPECTED_APPROVAL':'','EXPECTED_BASELINE':c.pin(H/'baseline-files.json')['sha256']}
t=ast.parse(s);lines=s.splitlines(True)
for n in reversed(t.body):
    if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in values:
        lines[n.lineno-1:n.end_lineno]=[n.targets[0].id+' = '+repr(values[n.targets[0].id])+'\n']
s=''.join(lines);ast.parse(s)
(H/'native-runner-template.py').write_text(s)
wrapper=old.parent/'native-capture-wrapper.py'
(H/'native-capture-wrapper.py').write_text(wrapper.read_text().replace('pathwaymech-next-240','pathwaymech-next-243'))
(H/'native-runner-rebase.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile='240/native-runner-template.py',tofile='243/native-runner-template.py')))
c.write_new(H/'native-runner-plan.json', {'status':'prepared_not_executed_pending_exact_root_acceptance_and_seal_pins','predecessor':c.pin(old),'template':c.pin(H/'native-runner-template.py'),'capture_predecessor':c.pin(wrapper),'capture':c.pin(H/'native-capture-wrapper.py'),'pending_bindings':['EXPECTED_HANDOFF','EXPECTED_PLAN','EXPECTED_APPROVAL'],'expected_payload_owners':12,'old_records':241,'new_records':242,'old_histories':410,'after_histories':412,'SSSOM':[66,4,70],'phases':['history-and-generation','remaining-offline-gates','vendored-gate','final-gates'],'inherited_logic':'Accepted240 phase receipt/stream origins and inherited238 seven SSSOM controls; no new runner logic or tests.','execution_performed':False})
print('Prepared inert 243 native runner; no history or gates executed.')
