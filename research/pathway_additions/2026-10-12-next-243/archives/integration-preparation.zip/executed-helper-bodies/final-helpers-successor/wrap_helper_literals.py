"""Preserve exact helper AST while wrapping only overlong literal values."""
import ast,io,json,tokenize
from pathlib import Path
H=Path(__file__).parent
proof=[]
for name in ['package_evidence.py','prepare_plan.py']:
 p=H/name;s=p.read_text();lines=s.splitlines(True);before=ast.dump(ast.parse(s));edits=[]
 for tok in tokenize.generate_tokens(io.StringIO(s).readline):
  if tok.type!=tokenize.STRING or tok.start[0]!=tok.end[0] or len(lines[tok.start[0]-1].rstrip('\n'))<=100 or len(tok.string)<65:continue
  value=ast.literal_eval(tok.string)
  if not isinstance(value,str):continue
  remaining=value;chunks=[]
  while len(remaining)>65:
   cut=remaining.rfind(' ',0,65)+1
   if cut<=0:cut=65
   chunks.append(remaining[:cut]);remaining=remaining[cut:]
  chunks.append(remaining)
  assert ''.join(chunks)==value
  indent=' '*(len(lines[tok.start[0]-1])-len(lines[tok.start[0]-1].lstrip())+4)
  replacement='(\n'+''.join(indent+repr(x)+'\n' for x in chunks)+indent[:-4]+')'
  edits.append((tok.start[0]-1,tok.start[1],tok.end[1],replacement))
 for line,a,b,replacement in reversed(edits):lines[line]=lines[line][:a]+replacement+lines[line][b:]
 out=''.join(lines);assert ast.dump(ast.parse(out))==before;p.write_text(out);proof.append({'helper':name,'exact_AST_equal':True,'wrapped_literal_count':len(edits)})
(H/'helper-literal-wrap-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
