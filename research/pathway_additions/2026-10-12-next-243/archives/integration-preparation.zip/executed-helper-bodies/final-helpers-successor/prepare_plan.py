"Compare complete accepted deltas and prepare concrete root-owned native stages."

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import yaml

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-243-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-243-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
RID = "PathBank:SMP0002123"


def stable(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before, after = (
            c.load(c.ROOT / rel),
            c.load(PAY / rel if (PAY / rel).exists() else c.ROOT / rel),
        )
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [k for k in new if k in old] == list(old)
                for ident, value in old.items():
                    assert stable(value) == stable(new[ident]), (name, key, ident)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [k for k in new if k not in old],
                    "all_old_whole_objects_and_nested_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(BUILD / (name + ".json")),
            "adopted_owner": (PAY / rel).exists(),
            "sections": sections,
        }
    oldmanifest = c.load(c.ROOT / "conf/identifier_sources.json")
    newmanifest = c.load(PAY / "conf/identifier_sources.json")
    assert len(oldmanifest) == 892 and len(newmanifest) == 893
    assert stable(newmanifest[:892]) == stable(oldmanifest)
    assert c.regular_bytes(c.ROOT / "conf/rhea_identifier_updates.json") == c.regular_bytes(
        BUILD / "rhea-updates.json"
    )
    bn, an = rows(c.ROOT / "output/kgx/nodes.tsv"), rows(BUILD / "actual-kgx/nodes.tsv")
    be, ae = rows(c.ROOT / "output/kgx/edges.tsv"), rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = {r["id"]: r for r in be}
    assert [r for r in ae if r["id"] in oldedges] == be
    oldnodes, newnodes = {r["id"]: r for r in bn}, {r["id"]: r for r in an}
    changes, aggregate = [], []
    contexts = additions = 0
    for ident, old in oldnodes.items():
        new = newnodes[ident]
        prior = json.loads(old["source_contexts"])
        current = json.loads(new["source_contexts"])
        assert [v for v in current if v["record_id"] != RID] == prior
        delta_contexts = [v for v in current if v["record_id"] == RID]
        contexts += len(prior)
        additions += len(delta_contexts)
        delta = {
            key: {"before": value, "after": new[key]}
            for key, value in old.items()
            if key != "source_contexts" and value != new[key]
        }
        if delta:
            aggregate.append({"id": ident, "fields": delta})
        if old != new:
            changes.append({"id": ident, "before": old, "after": new})
    accepted = c.load(
        "/private/tmp/pathwaymech-next-243-root-canonical-output-acceptance-20261012.json"
    )
    assert not aggregate
    permutation_pin = accepted["node_order_exception"]["exact_full_vectors"]
    c.verify(permutation_pin)
    permutation = c.load(permutation_pin["path"])
    assert list(oldnodes) == permutation["old_4357_node_ids_in_actual_order"]
    actual_old_order = [r["id"] for r in an if r["id"] in oldnodes]
    assert actual_old_order == permutation["expected_existing_node_ids_in_native_order"]
    moved = {"CHEBI:15422", "CHEBI:16761"}
    assert [i for i in actual_old_order if i not in moved] == [
        i for i in oldnodes if i not in moved
    ]
    actual_contexts = {
        r["id"]: [v for v in json.loads(r["after"]["source_contexts"]) if v["record_id"] == RID]
        for r in changes
    }
    assert actual_contexts == {r["id"]: r["contexts"] for r in accepted["shared_context_additions"]}
    assert len(changes) == additions == 6
    assert (len(bn), len(be), len(an), len(ae)) == (4357, 12110, 4363, 12125)
    record = yaml.safe_load(
        c.regular_bytes(PAY / "data/pathways/baesr-two-component-signal-transduction.yaml")
    )
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for mapping in record.get("source_mappings", []):
        row = {k: mapping[k] for k in cols if k != "comment"}
        row["comment"] = (
            f"source_pathway_id={mapping['source_pathway_id']}; "
            f"source_element_id={mapping['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(row[k])).strip() for k in cols})
    existing = Counter(stable(r) for r in oldss)
    assert len(oldss) == 66 and all(n == 1 for n in existing.values())
    added = [r for r in newss if stable(r) not in existing]
    assert len(added) == len(newss) == 4
    files = c.load(H / "baseline-files.json")

    def count(prefix, suffix):
        return sum(r["path"].startswith(prefix) and r["path"].endswith(suffix) for r in files)

    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": count("data/pathways/", ".yaml"),
        "old_review_yaml": count("reviews/", ".yaml"),
        "old_review_markdown": count("reviews/", ".md"),
        "old_history_yaml": count("history/", ".yaml"),
        "native_authorities": native,
        "manifest_prefix_rows": 892,
        "manifest_after_rows": 893,
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_order_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": True,
        "old_node_encounter_relative_order_exact": False,
        "exact_old_node_order_exception": permutation_pin,
        "all_other_old_nodes_relative_order_exact": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_changes": aggregate,
        "aggregate_display_scope": (
            'No aggregate changes. Six exact new target contexts only. Exact '
            'accepted ATP/ADP first-encounter permutation; all other old node '
            'order preserved.'
        ),
        "old_authority_object_exceptions": [],
        "planning_decisions": [permutation_pin],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = json.loads(
        json.dumps(c.load(OLD / "stages.json"))
        .replace("pathwaymech-next-240", "pathwaymech-next-243")
        .replace(
            "spermidine-biosynthesis-and-metabolism-escherichia-coli",
            "baesr-two-component-signal-transduction",
        )
        .replace("PathBank_SMP0002097", "PathBank_SMP0002123")
    )
    findings = []
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="conf/identifier_sources.json",
        description=(
            'One ordinary PathBank source manifest append and accepted source '
            'snapshot; inherited runtime code and ontology unchanged.'
        ),
        issue_lineage=[],
    )

    def history(kind, slug, owner, event, summary, details):
        return [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            kind,
            "--slug",
            slug,
            *owner,
            "--event",
            event,
            "--outcome",
            "changed",
            "--summary",
            summary,
            "--details",
            details,
            "--actor-name",
            "codex",
            "--agent-tool",
            "codex",
            "--model",
            "gpt-6",
        ]

    stages["history_commands"] = [
        history(
            "record",
            "baesr-two-component-signal-transduction",
            ["--target-root", "data/pathways"],
            "CREATE",
            "Add evidence-backed E. coli BaeSR signal transduction.",
            (
                'Exact accepted PathBank:SMP0002123: 13 paragraphs, 15 edges, 8 '
                'qualifiers, 12 IDs, 18 references, 4 mappings. Preserve complete '
                'native states, two phosphorylation events, six formal sides and '
                'two interpreted donor sides, '
                'construct/sequence/site/chemical/access limitations. Whole '
                'originals, receipts and prior failed attempts retained in '
                'research/pathway_additions/2026-10-12-next-243. Maintained gates '
                'and native reviews pending.'
            ),
        ),
        history(
            "infrastructure",
            "baesr243-native-authority",
            ["--path", "conf/identifier_sources.json"],
            "EDIT",
            "Add BaeSR ordinary PathBank identity authority and source snapshot.",
            (
                'Manifest 892-row prefix retained with one append, source 2694 '
                'terms/712 owners; all old authority objects and first owners '
                'exact. Runtime code and ontology unchanged. Old KGX edge '
                'payloads/order and contexts retained; six contexts added and '
                'exact accepted ATP/ADP node encounter permutation. Histories '
                'precede SSSOM/render; maintained gates/native reviews pending.'
            ),
        ),
    ]
    stages["after_gates"] = [
        (
            'Inspect actual BaeSR page/graph, all 13 paragraphs, 15 edges, 8 '
            'qualifiers, 12 IDs, 18 references, 4 mappings and 31 locators '
            'against accepted science and access limits.'
        ),
        (
            'Scientific author Nitrate; maintained SCI reviewer Adapter '
            'inherits root full-paper reading explicitly. Deoxy owns '
            'independent TECH. Save native reviews only after exact '
            'current-input inspection and root acceptance.'
        ),
        (
            'Preserve 241 old records/pages, 126 review pairs, 410 histories, '
            'all old authority objects/order and 12110 old KGX whole '
            'edges/contexts. Only exact accepted ATP/ADP node permutation and '
            'six target contexts allowed.'
        ),
        (
            'SSSOM preserves 66 old complete rows/header/relative order plus '
            '4 exact whole rows by multiset, total70; native subject sorting '
            'accepted.'
        ),
        (
            'Recheck 800 cache identities and ignored-inclusive checkout '
            'outside exact scope. No publication.'
        ),
    ]
    stages["before_first_render_after_history"][0].update(
        reason="Export 4 target mappings after histories and before rendering/tests.",
        preservation=(
            'All 66 old whole rows/order/header; 4 new rows by whole-row '
            'multiset, total70.'
        ),
    )
    interfaces = stages["native_review_interfaces"]
    interfaces["inherited_science_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-243-root-scientific-review-20261012/handoff.json"
    )
    interfaces.pop("active_scope_successor_review", None)
    interfaces["source_identity_review"] = c.pin(
        "/private/tmp/pathwaymech-next-243-source-identity-independent-review-20261012/REPORT.md"
    )
    interfaces["actual_native_review_handoff"] = c.pin(
        
            '/private/tmp/pathwaymech-next-243-canonical-output-independent-re'
            'view-20261012/handoff.json'
        
    )
    interfaces["save_template"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "save",
        "--content",
        "<independently-reviewed-completed-review.json>",
    ]
    interfaces["check_after_save"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "check",
        "--require-reviews",
        "--base",
        c.BASE,
    ]
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    assert stages["preservation_counts"] == {
        "old_records": 241,
        "old_review_yaml": 126,
        "old_review_markdown": 126,
        "old_history_yaml": 410,
    }
    c.write_new(H / "stages.json", stages)
    selection = c.load(H / "baseline-selection.json")
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Clean committed240 local branch; not merged main",
            "primary_owners": len(c.PRIMARY),
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(
                PAY / "data/pathways/baesr-two-component-signal-transduction.yaml"
            ),
            "actual_native_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-243-root-canonical-output-acceptance-20261012.json"
            ),
            "baseline_postcommit_acceptance": selection["commit_receipt"],
            "local_findings": findings,
            "remaining": [
                "root concrete preparation check",
                "guarded local adoption",
                "two histories before SSSOM/render",
                "native gates",
                "actual page and independent native reviews",
                "preservation and local commit",
            ],
            "source_exhaustion": False,
            "licensing": "Public-release licensing remains deferred; publication not authorized.",
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_records",
                    "old_review_yaml",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                    "exact_aggregate_changes",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
