"""Two bounded controls for the exclusive manifest collection dialect."""
import hashlib
import json
from pathlib import Path

import common as c
from package_evidence import Store

H = Path(__file__).parent
fixture = H / 'manifest-collection-fixtures'
fixture.mkdir()

class Sink:
    def put(self, body):
        return hashlib.sha256(body).hexdigest()

    def owner(self, path, expected=None):
        return Store.owner(self, path, expected)

checks = []
for both in [False, True]:
    root = fixture / ('ambiguous' if both else 'valid-files')
    root.mkdir()
    body = root / 'whole.txt'
    body.write_bytes(b'whole original\n')
    row = {**c.pin(body), 'relative_path': body.name, 'file_type': 'file'}
    manifest = {'files': [row]}
    if both:
        manifest['artifacts'] = [row]
    c.write_new(root / 'artifact-manifest.json', manifest)
    c.write_new(root / 'handoff.json', {'manifest': c.pin(root / 'artifact-manifest.json')})
    try:
        packet, closure = Store.packet(Sink(), root)
    except AssertionError as exc:
        assert both and str(exc) == 'Exactly one manifest collection is required'
        checks.append({'case': 'both collections rejected before body traversal', 'passed': True})
    else:
        assert not both
        assert closure['declared_artifacts'] == 1 and closure['physical_files'] == 3
        assert not closure['declared_followed_views_not_traversed']
        assert packet['sealed_declared_file_views'][0]['sha256'] == row['sha256']
        checks.append({'case': 'files accepted with exact complete path/type/hash closure', 'passed': True})
c.write_new(H / 'manifest-collection-checks.json', {'scope': 'two collection controls; existing file/type/link/hash checks unchanged', 'checks': checks})
print(json.dumps({'controls': len(checks), 'passed': True}))
