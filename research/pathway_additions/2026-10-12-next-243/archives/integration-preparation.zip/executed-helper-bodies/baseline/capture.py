"Read-only clean-target baseline capture and accepted external payload copies."

import datetime
from pathlib import Path

import common as c

H = c.HERE
BUILD = Path("/private/tmp/pathwaymech-next-243-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-243-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012")
ACCEPT = Path("/private/tmp/pathwaymech-next-243-root-canonical-output-acceptance-20261012.json")


def main():
    assert (
        c.pin(ACCEPT)["sha256"]
        == "5e97f64c23ccb7d12a1fd198b49d2325fa937bd1b41a25d454507197aafe1f13"
    )
    accepted = c.load(ACCEPT)
    c.verify(accepted["actual"]["handoff.json"])
    c.verify(accepted["actual"]["artifact-manifest.json"])
    c.verify(accepted["independent_actual_review"]["handoff.json"])
    c.verify(accepted["independent_actual_review"]["artifact-manifest.json"])
    c.git_check(True)
    files, dirs = c.inventory(c.ROOT, exclude_git=True)
    c.write_new(H / "baseline-files.json", files)
    c.write_new(H / "baseline-directories.json", dirs)
    c.write_new(H / "cache-baseline.json", c.load(OLD / "cache-baseline.json"))
    c.cache_check()
    before = {r["path"]: r for r in files}
    owners = c.load(H / "runtime-owner-map.json")
    for row in owners["runtime"]:
        for key in ["accepted", "effective_preparation", "actual_runtime", "effective_integration"]:
            c.verify(row[key])
        if row["before"] is not None:
            c.verify(row["before"])
        if row["changed"]:
            dest = H / "payload" / row["relative_path"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(c.regular_bytes(row["effective_integration"]["path"]))
            dest.chmod(0o755 if before.get(row["relative_path"], {}).get("executable") else 0o644)
    selected = [
        (
            Path(
                
                    "/private/tmp/pathwaymech-next-243-editorial-successor-20261012/draft/"
                    "baesr-two-component-signal-transduction.yaml"
                
            ),
            "data/pathways/baesr-two-component-signal-transduction.yaml",
            "1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824",
        ),
        (
            BUILD / "sources.json",
            "data/identifier_authorities/sources.json",
            "aa22a12f65bfe5a0d24123fbac324cd19c0258230c7fc51f1bbea841984d4fa1",
        ),
    ]
    assert c.regular_bytes(BUILD / "ontology.json") == c.regular_bytes(
        c.ROOT / "data/identifier_authorities/ontology.json"
    )
    for src, rel, digest in selected:
        assert c.pin(src)["sha256"] == digest
        dest = H / "payload" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(c.regular_bytes(src))
        dest.chmod(0o644)
    assert {r["path"] for r in c.inventory(H / "payload")[0]} == c.PRIMARY
    old_science = [
        r for r in files if r["path"].startswith("data/pathways/") and r["path"].endswith(".yaml")
    ]
    assert len(old_science) == 241
    for row in old_science:
        assert c.pin(BUILD / "corpus" / Path(row["path"]).name)["sha256"] == row["sha256"]
    selection = c.load(H / "baseline-selection.json")
    inputs = [ACCEPT, H / "root-target.json", Path(selection["commit_receipt"]["path"])] + [
        Path("/private/tmp") / ("pathwaymech-next-243-root-" + name + "-acceptance-20261012.json")
        for name in ["scientific-scope", "authority-design", "canonical-preparation"]
    ]
    c.write_new(H / "accepted-inputs.json", [c.pin(p) for p in inputs])
    c.write_new(
        H / "baseline-receipt.json",
        {
            "at": datetime.datetime.now(datetime.UTC).isoformat(),
            "target": str(c.ROOT),
            "commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "git_clean": True,
            "files": len(files),
            "directories": len(dirs),
            "hidden_ignored_included": True,
            "cache_entries": 800,
            "exact_primary_owners": len(c.PRIMARY),
            "old_real_records": len(old_science),
            "all_old_science_matches_accepted_actual_corpus": True,
            "actual_native_acceptance": c.pin(ACCEPT),
            "configuration": (
                "Use exact explicit accepted native manifest893; unchanged inherited "
                "Rhea config remains outside payload. No stale runtime892 config "
                "adoption."
            ),
        },
    )
    print(c.load(H / "baseline-receipt.json"))


if __name__ == "__main__":
    main()
