"""Bind clean committed240 target and minimally rebase accepted integration helpers."""
import ast,datetime,difflib,hashlib,json,os,subprocess
from pathlib import Path
H=Path(__file__).parent;OLD=Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012');R=Path('/private/tmp/pathwaymech-next-243-local-20261012');PRE=Path('/private/tmp/pathwaymech-next-243-canonical-preparation-20261012');BUILD=Path('/private/tmp/pathwaymech-next-243-canonical-build-20261012')
SLUG='baesr-two-component-signal-transduction'
selection=json.loads((H/'baseline-selection.json').read_text());BASE=selection['commit'];TREE=selection['tree'];BRANCH='feat/pathway-next-243-local-20261012'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):
 with (H/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip()
assert git('rev-parse','HEAD')==BASE and git('rev-parse','HEAD^{tree}')==TREE and git('branch','--show-current')==BRANCH and not git('status','--porcelain=v1','--untracked-files=all')
write('root-target.json',{'target':str(R),'commit':BASE,'tree':TREE,'branch':BRANCH,'clean':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'captured_by':'Codex /root/aceto236_design_acceptance_review after root-authorized isolated worktree creation','root_local_commit':selection['commit_receipt'],'worktree_tool_provenance':selection['worktree_tool_provenance'],'baseline_selection':pin(H/'baseline-selection.json')})
inputs=json.loads((PRE/'input-bindings.json').read_bytes());plan=json.loads((PRE/'execution-plan.json').read_bytes());overrides={'conf/identifier_sources.json':BUILD/'manifest.json','conf/rhea_identifier_updates.json':BUILD/'rhea-updates.json'}
argv=plan['commands']['source_builder'];assert Path(argv[argv.index('--manifest')+1])==overrides['conf/identifier_sources.json']
assert 'ontology_builder' not in plan['commands']
assert pin(BUILD/'ontology.json')['sha256']=='f155aeff12118e7aa7176c58f32ea231ad61fa25cd43a1c90aa6ff6f383ef9e2'
rows=[]
for row in inputs['runtime']:
 rel=str(Path(row['staged']['path']).relative_to(PRE/'runtime'));actual=BUILD/'runtime'/rel
 for d in [row['origin'],row['staged']]:assert (pin(Path(d['path']))['bytes'],pin(Path(d['path']))['sha256'])==(d['bytes'],d['sha256'])
 assert pin(actual)['sha256']==row['origin']['sha256'];effective=overrides.get(rel,actual);before=pin(R/rel) if (R/rel).exists() else None;bound=pin(effective)
 rows.append({'relative_path':rel,'accepted':row['origin'],'effective_preparation':pin(Path(row['staged']['path'])),'actual_runtime':pin(actual),'effective_integration':bound,'override_reason':'Exact explicit configuration consumed by accepted native CLI' if rel in overrides else None,'before':before,'changed':before is None or before['sha256']!=bound['sha256']})
assert len(rows)==280
changed=sorted(r['relative_path'] for r in rows if r['changed']);assert changed==['conf/identifier_sources.json'] and 'conf/identifier_sources.json' in changed and 'conf/rhea_identifier_updates.json' not in changed
assert pin(R/'data/identifier_authorities/ontology.json')['sha256']==pin(BUILD/'ontology.json')['sha256']
primary=sorted(changed+['data/pathways/'+SLUG+'.yaml','data/identifier_authorities/sources.json']);assert len(primary)==3
write('runtime-owner-map.json',{'runtime':rows,'runtime_count':280,'changed_runtime':len(changed),'primary':primary,'unchanged_ontology_not_adopted':{'before':pin(R/'data/identifier_authorities/ontology.json'),'accepted_actual':pin(BUILD/'ontology.json')},'explicit_native_configuration_inputs':{k:pin(v) for k,v in overrides.items()}})
print(json.dumps({'runtime':280,'changed_runtime':changed,'primary_owners':3,'primary':primary},indent=2))
