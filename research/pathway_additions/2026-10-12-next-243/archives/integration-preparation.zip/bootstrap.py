import hashlib,json,ast
from pathlib import Path
H=Path(__file__).parent
OLD=Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012')
BASE='63bc0ba99c63e4d4cdbdf70b8fb3f6f8417eeacf';TREE='e2b94367c9c487e656d35acb554b87f333c41570'
SLUG='baesr-two-component-signal-transduction'
def rebase(s):
 for a,b in [('pathwaymech-next-240','__CURRENT__'),('pathwaymech-next-239','pathwaymech-next-240'),('__CURRENT__','pathwaymech-next-243'),('2026-10-12-next-240','__DOSSIER__'),('2026-10-12-next-239','2026-10-12-next-240'),('__DOSSIER__','2026-10-12-next-243'),('feat/pathway-next-240','feat/pathway-next-243'),('5eb77a4b8039e98d9b53a61d09af52fa9f5b3d7a',BASE),('db61cc9f49a87a9d3efc098ae98acb1dbf22a6932',TREE),('pathbank240','baesr243'),('spermidine-biosynthesis-and-metabolism-escherichia-coli',SLUG),('PathBank:SMP0002097','PathBank:SMP0002123'),('PathBank_SMP0002097','PathBank_SMP0002123')]:s=s.replace(a,b)
 return s
for name in ['common.py','adopt.py','verify_portable.py','split_archive.py','run_step.py','test_controls.py','archive_controls.py','capture.py','package_evidence.py','prepare_plan.py','finish.py','create_worktree.py','start_preparation.py']:
 s=rebase((OLD/name).read_text())
 if name=='common.py':
  t=ast.parse(s);lines=s.splitlines(True)
  values={'BASE':repr(BASE),'TREE':repr(TREE),'PRIMARY':"frozenset(['conf/identifier_sources.json', 'data/identifier_authorities/sources.json', 'data/pathways/"+SLUG+".yaml'])"}
  edits=[]
  for n in t.body:
   if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in values:edits.append((n.lineno,n.end_lineno,n.targets[0].id))
  for a,b,k in reversed(edits):lines[a-1:b]=[f'{k} = {values[k]}\n']
  s=''.join(lines)
 if name=='create_worktree.py':s=s.replace('8c33c048b78cb9336204fddeee6588157ff27664a88ab45836e2bc806e413540','0dcbf63b3d8429de2a38ccb34848254d10d8a4bf26e2704c4835be21396cd716')
 (H/name).write_text(s)
print('Final 240 helper bodies copied with declared 243 path rebases; configuration pending.')
