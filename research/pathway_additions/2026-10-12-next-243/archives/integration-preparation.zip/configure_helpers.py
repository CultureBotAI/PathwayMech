"""Bounded rebase of final accepted240 helpers; source-only BaeSR scope."""
import ast,json,hashlib,difflib
from pathlib import Path
H=Path(__file__).parent;OLD=Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012')
BASE='63bc0ba99c63e4d4cdbdf70b8fb3f6f8417eeacf';TREE='e2b94367c9c487e656d35acb554b87f333c41570'
def pin(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def edit(n,f):
 p=H/n;s=f(p.read_text());ast.parse(s);p.write_text(s)
receipt=Path('/private/tmp/pathwaymech-next-240-local-commit-20261012/completion.json')
(H/'baseline-selection.json').write_text(json.dumps({'commit':BASE,'tree':TREE,'commit_receipt':pin(receipt),'worktree_tool_provenance':{'initial':'f8133b','session_id':80054,'completion':'9d80f8','exit_code':0,'receipt':pin(H/'worktree-creation.json')}},indent=2)+'\n')
def start(s):
 s=s.replace('Bind clean committed239','Bind clean committed240').replace('Codex /root/deoxy237_science_review','Codex /root/aceto236_design_acceptance_review')
 a=s.index('for key,arg in');b=s.index('rows=[]',a)
 s=s[:a]+'''argv=plan['commands']['source_builder'];assert Path(argv[argv.index('--manifest')+1])==overrides['conf/identifier_sources.json']
assert 'ontology_builder' not in plan['commands']
assert pin(BUILD/'ontology.json')['sha256']=='f155aeff12118e7aa7176c58f32ea231ad61fa25cd43a1c90aa6ff6f383ef9e2'
'''+s[b:]
 s=s.replace("len(changed)==7", "changed==['conf/identifier_sources.json']").replace('len(primary)==9','len(primary)==3').replace("'primary_owners':9","'primary_owners':3")
 a=s.index('def rebase(s):');s=s[:a]+"print(json.dumps({'runtime':280,'changed_runtime':changed,'primary_owners':3,'primary':primary},indent=2))\n"
 return s
# start helper was already configured and actually passed; no rewrite.
def capture(s):
 s=s.replace('951053a78a7123c8ac43019db578873877bd89d5b1c177dbb9543675fb3c4938','5e97f64c23ccb7d12a1fd198b49d2325fa937bd1b41a25d454507197aafe1f13').replace('accepted["actual_output"]["handoff"]','accepted["actual"]["handoff.json"]').replace('accepted["actual_output"]["manifest"]','accepted["actual"]["artifact-manifest.json"]').replace('accepted["independent_review"]["handoff"]','accepted["independent_actual_review"]["handoff.json"]').replace('accepted["independent_review"]["manifest"]','accepted["independent_actual_review"]["artifact-manifest.json"]')
 s=s.replace('243-scope-successor','243-editorial-successor').replace('0adef1da2d818af7c62d7e3952b2115585b47b8f132ec189cde2b435d2721680','1cf9262a0df376a19517b3f55ccaac67dacc8af8ce58bd8a1b2046e93a951824').replace('6bb6f0e5b7def56b35cd94fc5828e9429e9c7025a1f93da5248f7838e91f2391','aa22a12f65bfe5a0d24123fbac324cd19c0258230c7fc51f1bbea841984d4fa1').replace('len(old_science) == 240','len(old_science) == 241')
 a=s.index('        for name in [');b=s.index('    c.write_new(H / "accepted-inputs.json"',a)
 s=s[:a]+'''        for name in ["scientific-scope", "authority-design", "canonical-preparation"]
    ]
'''+s[b:]
 s=s.replace('native manifest892','native manifest893').replace('runtime831','runtime892')
 return s
edit('capture.py',capture)
def package(s):
 s=s.replace('# The 239 index','# The 240 index').replace('groups["inherited239_"','groups["inherited240_"').replace('"inherited239_index"','"inherited240_index"')
 s=s.replace('        expected = {locate_member_name(r, root): r for r in m["artifacts"]}\n        assert len(expected) == len(m["artifacts"])','''        assert ("artifacts" in m) != ("files" in m), "Exactly one manifest collection is required"
        manifest_rows = m["artifacts"] if "artifacts" in m else m["files"]
        expected = {locate_member_name(r, root): r for r in manifest_rows}
        assert len(expected) == len(manifest_rows)''')
 a=s.index('    suffixes = [');b=s.index('    for suffix in suffixes:',a)
 s=s[:a]+'''    suffixes = ["preflight", "author", "editorial-successor", "root-scientific-review", "graph-preview", "authority-design", "authority-design-independent-review", "canonical-preparation", "canonical-preparation-independent-review", "canonical-build", "canonical-output-independent-review"]
'''+s[b:]
 a=s.index('    for directory in [');b=s.index('        root = Path',a)
 s=s[:a]+'''    for directory in ["canonical-execution", "source-identity-independent-review", "root-primary-reading"]:
'''+s[b:]
 a=s.index('    attempts = scientific_binding[');b=s.index('    # Every complete receipt descriptor',a)
 s=s[:a]+'''    preflight = Path("/private/tmp/pathwaymech-next-243-preflight-20261012")
    preflight_binding = c.load(preflight / "source-bindings.json")
    attempts = preflight_binding["receipts"] + scientific_binding["new_network_attempts"]
    assert len(attempts) == 68
    scientific = [{"original": row["body"], "acquisition": row} for row in attempts if row.get("body")]
    native_originals = [
        {"role": role, "whole_original": c.pin(preflight / rel)}
        for role, rel in [("whole_current_BioPAX", "baesr-public/SMP0002123.owl"), ("whole_current_PWML_unmodified", "baesr-public/SMP0002123.pwml"), ("whole_archived_BioPAX_member", "originals/PW002111.owl")]
    ]
'''+s[b:]
 s=s.replace('and "/requests/" in value["path"]','and value["path"].endswith(".receipt.json")')
 a=s.index('    archive_intake =');b=s.index('    groups = {}',a)
 s=s[:a]+'''    archive_intake = c.load(preflight / "archive-member-reconciliation.json")
    for key in ["lineage", "archive"]:
        standalone.append(store.owner(archive_intake[key]["path"], archive_intake[key]))
'''+s[b:]
 s=s.replace('len(groups["manifest_originals"]) == 891','len(groups["manifest_originals"]) == 892').replace('len(groups["whole_scientific_originals"]) == 66','len(groups["whole_scientific_originals"]) == len(scientific)').replace('len(record["references"]) == 42','len(record["references"]) == 18').replace('"current_reference_hashes_all_bound": 42','"current_reference_hashes_all_bound": 18').replace('No current240 packet omissions. Earlier239','No current243 packet omissions. Earlier240')
 s=s.replace('        "current_scientific_acquisition_attempts": attempts,','''        "current_scientific_acquisition_attempts": attempts,
        "acquisition_group_scope": "All 68 retained preflight/author attempts, including comparison candidates and non-evidence error bodies; preservation is not a scientific support claim. Exact 18 cited reference bindings remain in whole author packet.",''')
 return s
edit('package_evidence.py',package)
def semantic(s):
 for a,b in [('len(oldmanifest) == 887 and len(newmanifest) == 892','len(oldmanifest) == 892 and len(newmanifest) == 893'),('newmanifest[:887]','newmanifest[:892]'),('(4320, 12052, 4357, 12110)','(4357, 12110, 4363, 12125)'),('len(oldss) == 62','len(oldss) == 66'),('"manifest_prefix_rows": 887','"manifest_prefix_rows": 892'),('"manifest_after_rows": 892','"manifest_after_rows": 893')]:s=s.replace(a,b)
 a=s.index('    expected_delta = [');b=s.index('    assert len(changes)',a)
 s=s[:a]+'''    assert not aggregate
    permutation_pin = accepted["node_order_exception"]["exact_full_vectors"]
    c.verify(permutation_pin)
    permutation = c.load(permutation_pin["path"])
    assert list(oldnodes) == permutation["old_4357_node_ids_in_actual_order"]
    actual_old_order = [r["id"] for r in an if r["id"] in oldnodes]
    assert actual_old_order == permutation["expected_existing_node_ids_in_native_order"]
    moved = {"CHEBI:15422", "CHEBI:16761"}
    assert [i for i in actual_old_order if i not in moved] == [i for i in oldnodes if i not in moved]
    actual_contexts = {r["id"]: [v for v in json.loads(r["after"]["source_contexts"]) if v["record_id"] == RID] for r in changes}
    assert actual_contexts == {r["id"]: r["contexts"] for r in accepted["shared_context_additions"]}
'''+s[b:]
 s=s.replace('"old_node_row_positions_may_move_by_native_first_encounter": False','"old_node_row_positions_may_move_by_native_first_encounter": True').replace('"old_node_encounter_relative_order_exact": True','"old_node_encounter_relative_order_exact": False,\n        "exact_old_node_order_exception": permutation_pin,\n        "all_other_old_nodes_relative_order_exact": True')
 a=s.index('        "aggregate_display_scope": (');b=s.index('        "actual_native_KGX":',a)
 s=s[:a]+'''        "aggregate_display_scope": "No aggregate changes. Six exact new target contexts only. Exact accepted ATP/ADP first-encounter permutation; all other old node order preserved.",
        "old_authority_object_exceptions": [],
        "planning_decisions": [permutation_pin],
'''+s[b:]
 a=s.index('    stages = c.load(OLD / "stages.json")');b=s.index('    def history(',a)
 s=s[:a]+'''    stages = json.loads(json.dumps(c.load(OLD / "stages.json")).replace("pathwaymech-next-240", "pathwaymech-next-243").replace("spermidine-biosynthesis-and-metabolism-escherichia-coli", "baesr-two-component-signal-transduction").replace("PathBank_SMP0002097", "PathBank_SMP0002123"))
    findings = []
    stages["history_before_first_render"]["required_infrastructure_event"].update(owner="conf/identifier_sources.json", description="One ordinary PathBank source manifest append and accepted source snapshot; inherited runtime code and ontology unchanged.", issue_lineage=[])
'''+s[b:]
 a=s.index('    stages["history_commands"] = [');b=s.index('    interfaces["save_template"]',a)
 s=s[:a]+'''    stages["history_commands"] = [
        history("record", "baesr-two-component-signal-transduction", ["--target-root", "data/pathways"], "CREATE", "Add evidence-backed E. coli BaeSR signal transduction.", "Exact accepted PathBank:SMP0002123: 13 paragraphs, 15 edges, 8 qualifiers, 12 IDs, 18 references, 4 mappings. Preserve complete native states, two phosphorylation events, six formal sides and two interpreted donor sides, construct/sequence/site/chemical/access limitations. Whole originals, receipts and prior failed attempts retained in research/pathway_additions/2026-10-12-next-243. Maintained gates and native reviews pending."),
        history("infrastructure", "baesr243-native-authority", ["--path", "conf/identifier_sources.json"], "EDIT", "Add BaeSR ordinary PathBank identity authority and source snapshot.", "Manifest 892-row prefix retained with one append, source 2694 terms/712 owners; all old authority objects and first owners exact. Runtime code and ontology unchanged. Old KGX edge payloads/order and contexts retained; six contexts added and exact accepted ATP/ADP node encounter permutation. Histories precede SSSOM/render; maintained gates/native reviews pending.")
    ]
    stages["after_gates"] = [
        "Inspect actual BaeSR page/graph, all 13 paragraphs, 15 edges, 8 qualifiers, 12 IDs, 18 references, 4 mappings and 31 locators against accepted science and access limits.",
        "Scientific author Nitrate; maintained SCI reviewer Adapter inherits root full-paper reading explicitly. Deoxy owns independent TECH. Save native reviews only after exact current-input inspection and root acceptance.",
        "Preserve 241 old records/pages, 126 review pairs, 410 histories, all old authority objects/order and 12110 old KGX whole edges/contexts. Only exact accepted ATP/ADP node permutation and six target contexts allowed.",
        "SSSOM preserves 66 old complete rows/header/relative order plus 4 exact whole rows by multiset, total70; native subject sorting accepted.",
        "Recheck 800 cache identities and ignored-inclusive checkout outside exact scope. No publication."
    ]
    stages["before_first_render_after_history"][0].update(reason="Export 4 target mappings after histories and before rendering/tests.", preservation="All 66 old whole rows/order/header; 4 new rows by whole-row multiset, total70.")
    interfaces = stages["native_review_interfaces"]
    interfaces["inherited_science_handoff"] = c.pin("/private/tmp/pathwaymech-next-243-root-scientific-review-20261012/handoff.json")
    interfaces.pop("active_scope_successor_review", None)
    interfaces["source_identity_review"] = c.pin("/private/tmp/pathwaymech-next-243-source-identity-independent-review-20261012/REPORT.md")
    interfaces["actual_native_review_handoff"] = c.pin("/private/tmp/pathwaymech-next-243-canonical-output-independent-review-20261012/handoff.json")
'''+s[b:]
 s=s.replace('"old_records": 240','"old_records": 241').replace('"old_review_yaml": 124','"old_review_yaml": 126').replace('"old_review_markdown": 124','"old_review_markdown": 126').replace('"old_history_yaml": 408','"old_history_yaml": 410').replace('Clean committed239','Clean committed240')
 return s
edit('prepare_plan.py',semantic)
def finish(s):
 a=s.index('    replacements = {');b=s.index('    patch = []',a)
 s=s[:a]+'''    replacements = {
        "/pathwaymech-next-240-local-20261012": "/pathwaymech-next-243-local-20261012",
        "5eb77a4b8039e98d9b53a61d09af52fa9f5b3d7a": c.BASE,
        "db61cc9f4d31f59ca6c1d509f52334dbe9e7b79a": c.TREE,
        "feat/pathway-next-240-local-20261012": c.BRANCH,
        "2026-10-12-next-240": "2026-10-12-next-243",
        "pathbank240": "baesr243",
        "pathwaymech-next-240-local-adoption-": "pathwaymech-next-243-local-adoption-",
    }
'''+s[b:]
 # Tree constant replaced dynamically from the actual final predecessor AST, never assumed.
 s=s.replace('    patch = []','''    previous_tree = next(n.value.value for n in ast.parse((OLD / "common.py").read_text()).body if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id == "TREE")
    replacements[previous_tree] = c.TREE
    patch = []''')
 s=s.replace('replay["originals"]["manifest_originals"] == 891','replay["originals"]["manifest_originals"] == 892').replace('replay["originals"]["whole_scientific_originals"] == 66','replay["originals"]["whole_scientific_originals"] == summary["original_group_counts"]["whole_scientific_originals"]').replace('Six bounded manifest spelling/type/hash checks only; ','Two bounded collection-key controls only; ').replace('manifest-alias-checks.json','manifest-collection-checks.json')
 return s
edit('finish.py',finish)
patch=[]
for name in ['common.py','adopt.py','verify_portable.py','split_archive.py','capture.py','package_evidence.py','prepare_plan.py','finish.py']:
 patch.extend(difflib.unified_diff((OLD/name).read_text().splitlines(True),(H/name).read_text().splitlines(True),fromfile='240/'+name,tofile='243/'+name))
(H/'complete-helper-rebase.patch').write_text(''.join(patch))
print('Source-only constants, evidence dialect and exact graph permutation configured.')
