import datetime,hashlib,json,os,subprocess
from pathlib import Path
H=Path(__file__).parent
old=Path('/private/tmp/pathwaymech-next-240-local-20261012');new=Path('/private/tmp/pathwaymech-next-243-local-20261012')
receipt=Path('/private/tmp/pathwaymech-next-240-local-commit-20261012/completion.json')
b=receipt.read_bytes();assert hashlib.sha256(b).hexdigest()=='0dcbf63b3d8429de2a38ccb34848254d10d8a4bf26e2704c4835be21396cd716';r=json.loads(b)
env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=env).decode().strip()
assert git(old,'rev-parse','HEAD')==r['commit'] and git(old,'rev-parse','HEAD^{tree}')==r['tree'] and not git(old,'status','--porcelain=v1','--untracked-files=all')
assert not new.exists()
argv=['git','-C',str(old),'worktree','add','-b','feat/pathway-next-243-local-20261012',str(new),r['commit']]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,env=env,capture_output=True,check=False)
(H/'worktree.stdout').write_bytes(p.stdout);(H/'worktree.stderr').write_bytes(p.stderr)
assert p.returncode==0,(p.returncode,p.stderr.decode())
assert git(new,'rev-parse','HEAD')==r['commit'] and git(new,'rev-parse','HEAD^{tree}')==r['tree'] and not git(new,'status','--porcelain=v1','--untracked-files=all')
result={'argv':argv,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0,'commit':r['commit'],'tree':r['tree'],'branch':git(new,'branch','--show-current'),'git_common_dir':git(new,'rev-parse','--git-common-dir'),'clean':True,'root_authorized_isolated_worktree_only':True,'maintained_payload_adopted':False}
(H/'worktree-creation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
