import concurrent.futures,urllib.request,urllib.error,json,hashlib,datetime,pathlib,sys
root=pathlib.Path('/private/tmp/pathwaymech-next-264-primary')
def fetch(item):
 name,url=item; now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
 r={'name':name,'url':url,'started_utc':now()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PathwayMech source research (public evidence; Python urllib)'}),timeout=55) as x:
   b=x.read();r.update(status=x.status,final_url=x.url,content_type=x.headers.get('content-type'))
 except urllib.error.HTTPError as e: b=e.read();r.update(status=e.code,error=str(e),content_type=e.headers.get('content-type'))
 except Exception as e:b=b'';r.update(error=repr(e))
 p=root/'originals'/name;p.write_bytes(b);r.update(path=str(p.relative_to(root)),sha256=hashlib.sha256(b).hexdigest(),bytes=len(b),starts_pdf=b.startswith(b'%PDF'),finished_utc=now());return r
items=json.loads(pathlib.Path(sys.argv[1]).read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:r=list(ex.map(fetch,items))
(root/sys.argv[2]).write_text(json.dumps(r,indent=2)+'\n')
for x in r:print(x['name'],x.get('status'),x['bytes'],x['starts_pdf'],x.get('error',''))
