# A1501 benzoate-entry source follow-up

This package authors a new, bounded assessment of PMID20137101 (DOI 10.1186/1471-2180-10-36) for MetaCyc:PWY-2503. It is not independent acceptance of these new claims, a canonical review, or a maintained-record edit. The frozen next264 design contains 20 publication dispositions and no row for this paper. Prior next263 evidence retained the complete article but concentrated on downstream cat/pca biology. This supplement supplies the missing entry-route assessment without changing either predecessor.

The experimental preparation is Pseudomonas stutzeri A1501, identified in Table 1 as Chinese culture CGMCC 0351. It is distinct from the native and primary preparations JMP222, H16, 335, B9, C1 and RW1. Other strains in Figure 2 are sequence and gene-organization comparisons. Their proteins, activities and regulatory mechanisms are not assigned to A1501.

## Supported entry claims

The benR insertion mutant A1601 loses benzoate utilization but retains catechol growth. Methods describes a nonpolar pK18mob insertion designed to preserve downstream transcription; it is not a scarless deletion. A1608 carries pLbenR in that mutant, with a 1041 bp benR/native-promoter fragment in pLAFR3. The authors report restoration of growth on benzoate after complementation, explicitly as data not shown. This supports genetic involvement in benzoate entry, not purified catalysis.

RT-PCR products span benA-benB, benB-benC and benC-benD in the benzoate condition. The tested benR-benA and benD-benK boundaries lack products. Figure 5 therefore supports a benABCD transcription unit. The quantitative expression assay measured a 186 bp internal benA amplicon in native transcripts, with wild type and the benR insertion mutant compared in Figure 6B. It was not a promoter-reporter construct. Benzoate strongly induced the wild type, whereas the mutant had much lower benA expression. A native BenR-to-benA expression-regulation relation is supported by this genetic evidence, with the operon context stated explicitly. Separate quantitative measurements of benB, benC and benD should not be invented.

Figure 6A's BenR site, promoter and start features are putative predictions from sequence comparison. The full Methods and Results contain no A1501 physical-binding assay. BenR–DNA binding, ligand binding and direct enzyme activation cannot be assigned from this source. The separate complementation construct also must not qualify the wild-type native-transcript expression relation.

Figure 7A directly measures lower benA expression with glucose or acetate than with lactate or succinate in benzoate-induced cells. The succinate/glucose and succinate/acetate mixtures also lower benA expression relative to succinate alone. Cultures received 4 mM benzoate during logarithmic growth and were incubated for 2 h at 30°C. Methods lists final 4 mM additions of each named non-inducing carbon source when required. These are expression effects, not direct inhibition of BenR, BenABC or BenD protein activity. The article does not specify glucose or lactate stereochemistry. One Results sentence incorrectly cites Figure 8 for this experiment; the actual transcript plots and caption are Figure 7.

The presence of a Crc-like sequence does not establish its role. The authors explicitly call for an A1501 Crc mutant to investigate that mechanism. Figure 1's Crc symbols and cited P. putida mechanisms must remain hypothesis/background rather than A1501 causal edges.

With 4 mM benzoate, adding 0.4 mM 4-hydroxybenzoate shortened the growth lag and accelerated depletion of benzoate in Figure 8. The authors report depletion by 18 h in the mixture versus 26 h with benzoate alone, without discernible consumption of 4-hydroxybenzoate. At 0.8 mM 4-hydroxybenzoate, growth was strongly restricted. These concentration-specific whole-cell observations do not identify a molecular target, establish benA induction by 4-hydroxybenzoate, or turn 4-hydroxybenzoate into a formal substrate of the two-step entry route. The suggested downstream PcaD-induction explanation is expressly potential.

## Assay and source limits

Methods and the Figure 8 caption establish HPLC analysis of culture supernatant. Cells were centrifuged out, residual cells removed with a 0.22 μm filter, and 20 μl filtrate injected. The abstract and some Results/contribution prose use “intracellular” terminology, but this package follows the actual sampling method and does not assert intracellular metabolite concentrations.

The original Figure 4 and supplement assign the peak near 2.38 min to cis,cis-muconate and the peak near 3.33 min to catechol. Methods instead lists standard retention times of 2.388 min for catechol and 3.358 min for muconate. These assignments cannot both be used as independent peak-identity verification. The reported metabolite observations remain author assignments with this conflict; they do not establish chemical structure identity or formal reaction mapping. Benzoate depletion near 6 min and the independent growth curves are separately observable. Lower material assigned as catechol in Figure 8C also cannot distinguish accelerated entry from downstream clearance.

Figure 3's benzoate-only growth curve plateaus near OD600 0.37, while the prose says 0.5 at 24 h. This assessment uses qualitative growth support rather than selecting an exact number. The supplementary time course shows disappearance of benzoate at 24 h, whereas the separate Figure 8 experiment reports depletion at 26 h without 4-hydroxybenzoate. Those experiments are retained separately. Very low plotted growth at restrictive doses is described as restriction rather than literal zero biomass, despite “completely inhibited” source wording.

No purified A1501 BenABC/BenD, isolated intermediate, absolute stereochemistry, formal stoichiometry, cofactor inventory or oligomer measurement is supplied by this paper. Its two-step route description and sequence assignments accompany regulation and whole-cell genetics. Other independently assessed sources must support those chemical and enzymatic details.

## Finite coverage and reuse

The complete EPMC JATS, publisher PDF, supplement PDF and seven original figure JPEGs were reused byte-for-byte from the frozen next263 primary package. All 14 main PDF pages, the single supplement page, all eight main figures and both tables were visually read. The seven separately retained JPEGs were also read. Figure 3 has no separate retained JPEG, but its original full PDF content is available and inspected. The PMC HTML challenge page is retained for provenance and excluded as scientific evidence.

The prior263 search enumerated hidden and ignored files in the actual next264 worktree, including gzip-decoded contents. The stale user checkout predates next263 and is not used to claim that its evidence was missing. No fresh network access was required for this primary article. Original acquisition receipts and complete frozen-package bindings are retained.

The 25 authored claim/disposition rows and 47 paragraph/table/figure unit dispositions cover the finite primary source. The complete bibliography was read as citation context; it does not mean that every referenced publication was acquired or assessed. Downstream catBC regulation, pca mutant phenotypes, the protocatechuate branch, transport hypotheses and comparative evolution remain explicit context or exclusions. None expands the formal two-step entry route automatically.

The exact issuing identity supplement is separate author evidence. Its final binding and any primer-size discrepancies must accompany integration. Independent source acceptance and final maintained source-to-graph review remain required; mechanical quote/hash checks cannot substitute for them.

## Final issuing identity binding

The exact issuing supplement is frozen at `/private/tmp/pathwaymech-next-264-authority/a1501-issuing` (manifest `b9821e185dd728262a31b6abb9ca45d6c0d840aefd3b5cea151e3494fce50afd`). The selected targets are `NCBIProtein:ABP79350.1` (BenR), `KEGG:psa:PST_1667` (benA gene) and `NCBITaxon:379731` (Stutzerimonas stutzeri A1501). Complete original genome, protein batch, gene and taxon responses, acquisitions, identity proof and failed/successor replay history are retained under `source-context/a1501-issuing`. No claim of independent acceptance is attached to this coauthored evidence.

The exact benA qPCR primers map uniquely to deposited CP000304.1 and yield the printed 186 bp amplicon inside PST_1667. The optional RT1/RT2/RT3/RT5 junction primers yield 786/453/500/598 bp versus printed 782/456/503/610 bp; RT4 yields the printed 546 bp. This source discrepancy does not change the exact measured benA identity. Operon context remains qualitative original RT-PCR evidence, without a claim that every printed junction length reproduces.
