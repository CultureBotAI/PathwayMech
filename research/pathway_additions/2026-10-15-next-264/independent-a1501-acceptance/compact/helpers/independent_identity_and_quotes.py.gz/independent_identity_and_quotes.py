"""Independent reviewer parser; never imports or executes author identity helpers."""
from pathlib import Path
from xml.etree import ElementTree as ET
from collections import defaultdict
import datetime, gzip, hashlib, json, re

ROOT = Path('/private/tmp/pathwaymech-next-264-independent-final-review/a1501')
ISSUER = Path('/private/tmp/pathwaymech-next-264-authority/a1501-issuing')
PRIMARY = Path('/private/tmp/pathwaymech-next-264-a1501-primary-followup')
def sha(b): return hashlib.sha256(b).hexdigest()
def text(n): return ' '.join(''.join(n.itertext()).split())
def quals(f):
    d=defaultdict(list)
    for q in f.findall('GBFeature_quals/GBQualifier'):
        d[q.findtext('GBQualifier_name')].append(q.findtext('GBQualifier_value'))
    return dict(d)
def flatfile(path):
    d=defaultdict(list); key=None
    for line in path.read_text().splitlines():
        if line=='///': break
        if line[:12].strip(): key=line[:12].strip()
        d[key].append(line[12:].strip())
    return dict(d)
def hits(seq, needle): return [m.start()+1 for m in re.finditer('(?='+needle+')',seq)]
def rc(s): return s.translate(str.maketrans('ACGT','TGCA'))[::-1]
proof={'reviewer':'/root/next264_technical_review','time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'Independent A1501 original source identity and quotation replay; not a final record verdict','package_integrity':[]}
for package in [ISSUER,PRIMARY]:
    raw=(package/'artifact-manifest.json').read_bytes(); man=json.loads(raw); rows=man.get('artifacts',man.get('files'))
    actual={str(p.relative_to(package)) for p in package.rglob('*') if p.is_file() and p.name!='artifact-manifest.json'}
    # Nested manifests remain inventoried: exclude only the outer manifest.
    actual={str(p.relative_to(package)) for p in package.rglob('*') if p.is_file() and p!=package/'artifact-manifest.json'}
    assert actual=={x['path'] for x in rows}, (package,actual^{x['path'] for x in rows})
    for row in rows:
        b=(package/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],row
    compact=json.loads((package/'compact-retention-manifest.json').read_text());pairs=compact.get('pairs',compact.get('files'))
    for row in pairs:
        raw=(package/row['original_path']).read_bytes(); packed=(package/row['stored_path']).read_bytes()
        assert len(raw)==row['original_bytes'] and sha(raw)==row['original_sha256']
        assert len(packed)==row['stored_bytes'] and sha(packed)==row['stored_sha256'] and gzip.decompress(packed)==raw
    proof['package_integrity'].append({'path':str(package),'manifest_sha256':sha((package/'artifact-manifest.json').read_bytes()),'files':len(rows),'pairs':len(pairs),'complete_hidden_inclusive_inventory':True})

orig=ISSUER/'originals'; gen=ET.parse(orig/'NCBI-CP000304.1.xml').getroot().find('GBSeq')
assert gen.findtext('GBSeq_accession-version')=='CP000304.1'
genome=gen.findtext('GBSeq_sequence').upper();assert len(genome)==int(gen.findtext('GBSeq_length'))==4567418
proteins={x.findtext('GBSeq_accession-version'):x for x in ET.parse(orig/'NCBI-ben-proteins.xml').getroot()};assert len(proteins)==5
codons=[''.join((a,b,c)) for a in 'TCAG' for b in 'TCAG' for c in 'TCAG']
code=dict(zip(codons,'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'))
selected={f'PST_{1666+i}':(name,f'ABP{79350+i}.1') for i,name in enumerate(['benR','benA','benB','benC','benD'])}
proof['cds']=[]
for f in gen.findall('.//GBFeature'):
    if f.findtext('GBFeature_key')!='CDS':continue
    q=quals(f); tag=q.get('locus_tag',[None])[0]
    if tag not in selected: continue
    gene,acc=selected[tag];assert q['gene']==[gene] and q['protein_id']==[acc] and q['transl_table']==['11'] and q['codon_start']==['1']
    loc=f.findtext('GBFeature_location');m=re.fullmatch(r'(\d+)\.\.(\d+)',loc);assert m,loc
    start,end=map(int,m.groups());dna=genome[start-1:end];assert dna[:3] in ['ATG','GTG','TTG'] and len(dna)%3==0
    aa=''.join(code[dna[i:i+3]] for i in range(0,len(dna),3));aa='M'+aa[1:];assert aa.endswith('*') and '*' not in aa[:-1]
    aa=aa[:-1];p=proteins[acc];assert aa==q['translation'][0]==p.findtext('GBSeq_sequence').upper()
    ps=next(x for x in p.findall('.//GBFeature') if x.findtext('GBFeature_key')=='source');assert quals(ps)['db_xref']==['taxon:379731'] and quals(ps)['strain']==['A1501']
    pc=next(x for x in p.findall('.//GBFeature') if x.findtext('GBFeature_key')=='CDS');pq=quals(pc);assert pq['coded_by']==['CP000304.1:'+loc] and pq['gene']==[gene] and pq['locus_tag']==[tag]
    item={'gene':gene,'locus_tag':tag,'protein':acc,'genome_location':loc,'nt_length':len(dna),'aa_length':len(aa),'nt_sha256':sha(dna.encode()),'aa_sha256':sha(aa.encode()),'full_translation_equal':True}
    if gene!='benR':
        k=flatfile(orig/f'KEGG-psa-{tag}.txt');assert k['ENTRY'][0].split()[0]==tag and k['ORGANISM'][0]=='psa  Stutzerimonas stutzeri A1501' and k['POSITION']==[loc] and k['SYMBOL']==[gene]
        assert ''.join(k['NTSEQ'][1:]).upper()==dna and ''.join(k['AASEQ'][1:])==aa
        assert int(k['NTSEQ'][0])==len(dna) and int(k['AASEQ'][0])==len(aa)
        assert 'NCBI-ProteinID: '+acc.split('.')[0] in k['DBLINKS'];item['kegg_full_dna_and_aa_equal']=True
    proof['cds'].append(item)
assert len(proof['cds'])==5
k=flatfile(orig/'KEGG-genome-T00511.txt');assert k['ENTRY'][0].split()[0]=='T00511' and k['ORG_CODE']==['psa'] and k['TAXONOMY']==['TAX:379731'] and k['CHROMOSOME']==['Circular (GB:CP000304)']
t=ET.parse(orig/'NCBI-taxonomy-379731.xml').getroot().find('Taxon');assert t.findtext('TaxId')=='379731' and t.findtext('ScientificName')=='Stutzerimonas stutzeri A1501' and t.findtext('Rank')=='strain' and t.findtext('OtherNames/Synonym')=='Pseudomonas stutzeri A1501'
proof['taxon_genome_crosswalk']={'taxon':'379731','rank':'strain','name':t.findtext('ScientificName'),'historical_synonym':t.findtext('OtherNames/Synonym'),'kegg_genome':'T00511','kegg_code':'psa','genome':'CP000304.1','scope':'Live issuing corroboration; no pinned taxonomy authority refresh claimed.'}

article=ET.parse(ROOT/'inputs/PMC2907835-epmc-full.xml').getroot()
rows=[[text(x) for x in tr] for tr in article.findall('.//table-wrap[@id="T2"]//tr')][1:]
primer={r[1]:(r[2],r[3]) for r in rows};proof['primers']=[]
for name in ['RT1','RT2','RT3','RT4','RT5','benA']:
    f,fragment=primer[name+"-5'"]; rev=primer[name+"-3'"][0]
    fh=hits(genome,f);rh=hits(genome,rc(rev));assert len(fh)==len(rh)==1
    reverse_f=hits(genome,rc(f));reverse_r=hits(genome,rev)
    length=rh[0]+len(rev)-fh[0];printed=int(fragment.split()[0]);assert length>0
    item={'name':name,'forward':f,'reverse':rev,'forward_hits':fh,'reverse_complement_hits':rh,'opposite_orientation_forward_hits':reverse_f,'opposite_orientation_reverse_hits':reverse_r,'genomic_product_bp':length,'printed_product_bp':printed,'printed_length_matches':length==printed}
    if name=='benA':assert length==186 and 1786195<=fh[0]<rh[0]+len(rev)-1<=1787445;item['within_exact_benA_cds']=True
    proof['primers'].append(item)
assert [(x['name'],x['genomic_product_bp']) for x in proof['primers'] if not x['printed_length_matches']]==[('RT1',786),('RT2',453),('RT3',500),('RT5',598)]

claims=json.loads((PRIMARY/'claim-evidence-ledger.json').read_text())['claims'];proof['claim_evidence']=[]
for c in claims:
    ev=[]
    for e in c['evidence']:
        loc=e['source_locator'];path='.'+loc[len('/article'):];nodes=article.findall(path);assert len(nodes)==1,(c['id'],loc,len(nodes))
        s=text(nodes[0]);quote=e.get('quote');assert not quote or quote in s,(c['id'],quote)
        ev.append({'locator':loc,'quote_exact':True if quote else None,'source_assertion_requires_human_visual_review':not bool(quote),'source_text_sha256':sha(s.encode())})
    proof['claim_evidence'].append({'claim_id':c['id'],'evidence':ev})
proof['original_bindings']=[{'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}for p in sorted(orig.iterdir()) if p.is_file()]
proof['independence']='Reviewer authored parser directly from inspected XML/KEGG/JATS, manual codon table and source Table 2; no source-author verifier imported or run. Mechanical hashes and exact sequence replay do not themselves prove scientific claims.'
proof['result']='passed; four optional published junction size discrepancies confirmed and bounded'
(ROOT/'independent-identity-and-quote-replay.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'result':proof['result'],'packages':proof['package_integrity'],'cds':proof['cds'],'primers':proof['primers'],'claims':len(claims)},indent=2))
