import Foundation
import PDFKit
import AppKit
let a=CommandLine.arguments
let source=URL(fileURLWithPath:a[1]); let out=URL(fileURLWithPath:a[2],isDirectory:true)
try FileManager.default.createDirectory(at:out,withIntermediateDirectories:true)
guard let d=PDFDocument(url:source) else {fatalError("bad pdf")}
var all=""
for i in 0..<d.pageCount {
 guard let p=d.page(at:i) else {fatalError("missing page")}
 let bounds=p.bounds(for:.mediaBox); let scale:CGFloat=1.7
 let img=NSImage(size:NSSize(width:bounds.width*scale,height:bounds.height*scale))
 img.lockFocus();NSColor.white.setFill();NSRect(origin:.zero,size:img.size).fill()
 let ctx=NSGraphicsContext.current!.cgContext;ctx.scaleBy(x:scale,y:scale);p.draw(with:.mediaBox,to:ctx);img.unlockFocus()
 let rep=NSBitmapImageRep(data:img.tiffRepresentation!)!
 try rep.representation(using:.png,properties:[:])!.write(to:out.appendingPathComponent("page-\(i+1).png"))
 let t=p.string ?? "";try t.write(to:out.appendingPathComponent("page-\(i+1).txt"),atomically:true,encoding:.utf8);all += "===PDF page \(i+1)===\n"+t+"\n"
}
try all.write(to:out.appendingPathComponent("all-pages.txt"),atomically:true,encoding:.utf8)
print("rendered \(d.pageCount) pages")
