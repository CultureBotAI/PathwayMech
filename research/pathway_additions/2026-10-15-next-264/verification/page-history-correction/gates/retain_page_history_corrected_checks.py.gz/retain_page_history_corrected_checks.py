from pathlib import Path
import datetime, gzip, hashlib, json

ROOT=Path('/private/tmp/pathwaymech-next-264-20261015')
CI=Path('/private/tmp/pathwaymech-next-264-ci')
CHECKS=Path('/private/tmp/pathwaymech-next-264-checks-page-history-correction')
DEST=ROOT/'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction'
REVIEW=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review/pre-gate-acceptance')

def sha(b): return hashlib.sha256(b).hexdigest()

def retain(paths,dest,scope):
    assert not dest.exists()
    dest.mkdir()
    rows=[]
    for source in sorted(paths):
        body=source.read_bytes()
        readable=source.name in {'receipts.json','environment.json','final-input-preservation.json','native-render-delta.json','HANDOFF.md','manifest.json','repair-acceptance.json'}
        name=source.name if readable else source.name+'.gz'
        encoded=body if readable else gzip.compress(body,mtime=0)
        target=dest/name; assert not target.exists();target.write_bytes(encoded)
        assert (encoded if readable else gzip.decompress(encoded))==body
        rows.append({'original_path':str(source),'original_sha256':sha(body),'original_bytes':len(body),'stored_path':name,'stored_sha256':sha(encoded),'stored_bytes':len(encoded),'encoding':'identity' if readable else 'gzip'})
    manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':scope,'pairs':rows}
    p=dest/'retention-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
    return {'path':str(dest),'manifest_sha256':sha(p.read_bytes()),'pairs':len(rows)}

def main():
    receipts=json.loads((CHECKS/'receipts.json').read_bytes())
    commands=[['just','render-pages'],['just','validate'],['just','test'],['just','lint'],['just','vendored-check'],['git','diff','--check'],['git','diff','--cached','--check']]
    assert [r['command'] for r in receipts]==commands
    assert all(r['exit_code']==0 for r in receipts)
    for row in receipts: assert sha(Path(row['log_path']).read_bytes())==row['log_sha256']
    assert json.loads((CHECKS/'final-input-preservation.json').read_bytes())['all_unchanged']
    inputs=json.loads((CHECKS/'tested-core-input-hashes.json').read_bytes())
    for path,digest in inputs.items(): assert sha((ROOT/path).read_bytes())==digest,path
    assert sha((REVIEW/'manifest.json').read_bytes())=='eb43456fde9974622b42f5f830a930ac84f69d7c9fd76710cc2b17bd61c5d8f1'
    artifacts=json.loads((REVIEW/'manifest.json').read_bytes())['artifacts']
    assert {p.name for p in REVIEW.iterdir()}=={r['path'] for r in artifacts}|{'manifest.json'}
    for row in artifacts:
        b=(REVIEW/row['path']).read_bytes(); assert sha(b)==row['sha256'] and len(b)==row['size']
    results=[retain(list(CHECKS.iterdir())+[CI/'run_page_history_correction_checks.py',Path(__file__)],DEST/'gates','Completed native render and required gates against corrected page and complete record history; all scoped tested inputs preserved during run.'),retain(list(REVIEW.iterdir()),DEST/'independent-pre-gate-acceptance','Independent canonical preinspection and exact page/history/graph/input acceptance; full gate verdict remains separate.')]
    out=CI/'page-history-corrected-checks-retention.json';assert not out.exists()
    out.write_text(json.dumps({'retained':results,'tested_input_count':len(inputs)},indent=2)+'\n')
    print(out.read_text())

if __name__=='__main__': main()
