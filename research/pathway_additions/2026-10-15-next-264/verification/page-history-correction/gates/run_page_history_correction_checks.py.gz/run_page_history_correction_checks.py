"""Run corrected-page gates once after the actual CI failure, preserving exact receipts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/private/tmp/pathwaymech-next-264-20261015')
OUT = Path('/private/tmp/pathwaymech-next-264-checks-page-history-correction')
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
           UV_NO_SYNC='1', UV_CACHE_DIR='/private/tmp/pathwaymech-next-264-uv-cache',
           UV_PROJECT_ENVIRONMENT='/private/tmp/pathwaymech-next-263-verified-venv',
           PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT))
SCOPE = ['src', 'tests', 'conf', 'data', 'history', 'pages', 'scripts', 'schema', 'docs',
         'templates', 'reviews', 'curation', '.claude', '.github', 'pyproject.toml', 'uv.lock', 'justfile',
         'research/pathway_additions/2026-10-15-next-264']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    # Without --exclude-standard, git includes ignored untracked files as well.
    raw = subprocess.check_output(['git', 'ls-files', '-co', '-z', '--', *SCOPE], cwd=ROOT)
    names = sorted({p.decode() for p in raw.split(b'\0') if p})
    return {p: sha(ROOT / p) for p in names if (ROOT / p).is_file()
            and not {'__pycache__', '.pytest_cache', '.ruff_cache'} & set(Path(p).parts)}


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == 'e6da46ca8515c27d81ed528a13ed839a2bec797f'
    assert sha(ROOT / 'pages/records/MetaCyc_PWY-2503.html') == '98e5b35bd640e5292c70a7ea05412078e321ba0e19451a66e8c6e118f853544e'
    assert sha(ROOT / 'data/pathways/benzoate-degradation-i-aerobic.yaml') == '3f8bbb8eceaa4420fa822e87ce01cca6b9d1967908dc117628aba71f54030696'
    assert (ROOT / 'data/pathways/benzoate-degradation-i-aerobic.yaml').is_file()
    assert not OUT.exists(), 'Observe or preserve the existing run; never restart it implicitly.'
    OUT.mkdir()
    receipts = []

    def run(command):
        log = OUT / ('-'.join(command) + '.log')
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        with log.open('w') as stream:
            process = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        receipt = {'command': command, 'cwd': str(ROOT), 'started_utc': start,
                   'elapsed_seconds': round(time.monotonic() - clock, 2),
                   'exit_code': process.returncode, 'log_path': str(log), 'log_sha256': sha(log)}
        receipts.append(receipt)
        (OUT / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
        print(json.dumps(receipt), flush=True)
        if process.returncode:
            print(log.read_text()[-10000:], flush=True)
            raise SystemExit(process.returncode)

    prerender = inventory()
    run(['just', 'render-pages'])
    before = inventory()
    changes = [p for p in set(prerender) | set(before) if prerender.get(p) != before.get(p)]
    assert changes == ['pages/records/MetaCyc_PWY-2503.html'], changes
    assert before[changes[0]] == '4e637a583fc5bbccb0b2b25ccac95b1b2b03b0dfedaff2b267068f7c9c2d37fe'
    page_delta = {'changed_paths': changes, 'before_sha256': prerender[changes[0]], 'after_sha256': before[changes[0]], 'all_other_scoped_inputs_unchanged': True}
    (OUT / 'native-render-delta.json').write_text(json.dumps(page_delta, indent=2) + '\n')
    (OUT / 'tested-core-input-hashes.json').write_text(json.dumps(before, indent=2) + '\n')
    (OUT / 'environment.json').write_text(json.dumps({k: ENV[k] for k in
        ['PYTHONDONTWRITEBYTECODE', 'PYTHONNOUSERSITE', 'UV_NO_SYNC', 'UV_CACHE_DIR',
         'UV_PROJECT_ENVIRONMENT', 'PYTHONPATH']}, indent=2) + '\n')
    for command in [['just', 'validate'], ['just', 'test'], ['just', 'lint'],
                    ['just', 'vendored-check'], ['git', 'diff', '--check'],
                    ['git', 'diff', '--cached', '--check']]:
        run(command)
    after = inventory()
    assert before == after, 'Core inventory changed while checks were running.'
    result = {'tested_core_files': len(before), 'all_unchanged': True,
              'scope': SCOPE, 'ignored_and_hidden_included': True,
              'excluded_runtime_caches': ['__pycache__', '.pytest_cache', '.ruff_cache'],
              'record_sha256': sha(ROOT / 'data/pathways/benzoate-degradation-i-aerobic.yaml')}
    (OUT / 'final-input-preservation.json').write_text(json.dumps(result, indent=2) + '\n')
    print('All seven corrected-page commands passed; complete scoped core inventory unchanged.', flush=True)


if __name__ == '__main__':
    main()
