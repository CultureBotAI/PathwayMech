"""Read-only repair acceptance; run only after canonical inspection/readiness."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys

ROOT=Path('/private/tmp/pathwaymech-next-264-20261015')
OUT=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review')
DIAG=Path('/private/tmp/pathwaymech-next-264-render-ci-review')
HEAD='e6da46ca8515c27d81ed528a13ed839a2bec797f'
PAGE='pages/records/MetaCyc_PWY-2503.html'
RECORD='data/pathways/benzoate-degradation-i-aerobic.yaml'

def digest(b): return hashlib.sha256(b).hexdigest()

def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)

def graph(data):
    start=data.index(b'<section id="pathway-network"')
    closing=b'</svg></div></section>'
    end=data.index(closing,start)+len(closing)
    return data[start:end]

def main():
    assert (OUT/'inspect.json').is_file(), 'Inspect actual maintained inputs before acceptance.'
    assert not (OUT/'repair-acceptance.json').exists(), 'Preserve completed observations.'
    sys.path.insert(0,str(ROOT/'src'))
    from pathwaymech.cli import _record_page
    from pathwaymech.schema import validate_record
    from pathwaymech.site_display import load_site_history
    from pathwaymech.yaml_io import load_yaml_file
    start=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
    inspection=json.loads((OUT/'inspect.json').read_text())
    assert inspection['source']['git_revision']==git('rev-parse','HEAD').decode().strip()
    for item in inspection['source']['inputs']:
        assert digest((ROOT/item['path']).read_bytes())==item['sha256'], item['path']
    source=load_yaml_file(ROOT/RECORD)
    record=validate_record(source)
    sessions=load_site_history(ROOT)[RECORD]
    expected=_record_page(record,RECORD,sessions).encode()
    actual=(ROOT/PAGE).read_bytes()
    old=git('show',f'{HEAD}:{PAGE}')
    assert actual==expected==(DIAG/'rendered-current-history.html').read_bytes()
    assert old==(DIAG/'committed.html').read_bytes()
    insertion=(DIAG/'exact-inserted-history.html').read_bytes()
    point=expected.index(b'<li><time>2026-10-15T10:22:11Z</time>')
    assert old[:point]+insertion+old[point:]==actual
    assert graph(old)==graph(actual)
    assert len(sessions)==2
    assert digest((ROOT/RECORD).read_bytes())=='3f8bbb8eceaa4420fa822e87ce01cca6b9d1967908dc117628aba71f54030696'
    scope=['src','tests','conf','data','schema','pages/downloads','history/records']
    unchanged=subprocess.run(['git','diff','--exit-code',HEAD,'--',*scope],cwd=ROOT,capture_output=True)
    (OUT/'unchanged-scientific-inputs.stdout.log').write_bytes(unchanged.stdout)
    (OUT/'unchanged-scientific-inputs.stderr.log').write_bytes(unchanged.stderr)
    assert unchanged.returncode==0
    raw=git('ls-files','--others','-z','--',*scope)
    extra=[p.decode() for p in raw.split(b'\0') if p and not {'__pycache__','.pytest_cache','.ruff_cache'} & set(Path(p.decode()).parts)]
    assert not extra, extra
    scientific_names=[p.decode() for p in git('ls-files','-z','--',*scope).split(b'\0') if p]
    snapshots={p:digest((ROOT/p).read_bytes()) for p in scientific_names if (ROOT/p).is_file()}
    (OUT/'unchanged-scientific-inputs.json').write_text(json.dumps(snapshots,indent=2)+'\n')
    record_names=[p for p in snapshots if p.startswith('data/pathways/') and p.endswith('.yaml')]
    page_changed=git('diff','--name-only',HEAD,'--','pages').decode().splitlines()
    assert page_changed==[PAGE],page_changed
    assert len(record.mechanistic_edges)==54 and len(record.references)==101
    result={
        'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),
        'failed_pr_head':HEAD,'current_head':git('rev-parse','HEAD').decode().strip(),
        'old_page_sha256':digest(old),'corrected_page_sha256':digest(actual),
        'expected_native_render_sha256':digest(expected),'exact_insertion_size':len(insertion),
        'exact_insertion_offset':point,'exact_insertion_sha256':digest(insertion),
        'graph_sha256':digest(graph(actual)),'graph_byte_identical':True,
        'record_sha256':digest((ROOT/RECORD).read_bytes()),'mechanistic_edges':len(record.mechanistic_edges),'references':len(record.references),
        'targeted_history':[{'path':s['source_path'],'sha256':digest((ROOT/s['source_path']).read_bytes())} for s in sessions],
        'unchanged_tracked_scientific_files':len(snapshots),'unchanged_pathway_records':len(record_names),
        'unchanged_scope':scope,'unexpected_untracked_inputs':extra,'untracked_search_includes_ignored':True,
        'only_changed_generated_page':page_changed,
        'limits':'Bounded page-history technical repair review. No new scientific interpretation, authority replay, or browser interaction; byte-preserved graph/source/KGX content inherits only the explicitly declared scope of earlier reviews.'
    }
    (OUT/'repair-acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__': main()
