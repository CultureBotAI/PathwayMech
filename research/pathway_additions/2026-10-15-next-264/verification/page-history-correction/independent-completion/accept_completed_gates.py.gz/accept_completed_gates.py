"""Read actual terminal gate evidence; no corpus gate execution."""
from pathlib import Path
import datetime,gzip,hashlib,json,re,subprocess
root=Path('/private/tmp/pathwaymech-next-264-20261015');out=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review')
base=root/'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction'
assert (out/'inspect-final.json').is_file()
assert not (out/'gate-acceptance.json').exists()
started=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
def sha(b):return hashlib.sha256(b).hexdigest()
def decode(folder,name):
 p=folder/name
 return gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
checked=[]
for folder in (base/'gates',base/'independent-pre-gate-acceptance'):
 m=json.loads((folder/'retention-manifest.json').read_bytes())
 for row in m['pairs']:
  stored=(folder/row['stored_path']).read_bytes(); assert sha(stored)==row['stored_sha256'] and len(stored)==row['stored_bytes']
  plain=gzip.decompress(stored) if row['encoding']=='gzip' else stored
  assert sha(plain)==row['original_sha256'] and len(plain)==row['original_bytes']
  assert plain==Path(row['original_path']).read_bytes()
 checked.append({'folder':str(folder.relative_to(root)),'pairs':len(m['pairs']),'manifest_sha256':sha((folder/'retention-manifest.json').read_bytes())})
gates=base/'gates'; receipts=json.loads(decode(gates,'receipts.json'))
commands=[['just','render-pages'],['just','validate'],['just','test'],['just','lint'],['just','vendored-check'],['git','diff','--check'],['git','diff','--cached','--check']]
assert [r['command'] for r in receipts]==commands
for row in receipts:
 assert row['exit_code']==0
 name=Path(row['log_path']).name+'.gz';actual=decode(gates,name)
 assert sha(actual)==row['log_sha256'] and actual==Path(row['log_path']).read_bytes()
assert 'pages/ is current with 261 pathway records' in decode(gates,'just-validate.log.gz').decode()
tests=decode(gates,'just-test.log.gz').decode()
summary=re.findall(r'\d+ passed, \d+ skipped, \d+ warnings in [^\n]+',tests)
assert len(summary)==1,summary
preserved=json.loads(decode(gates,'final-input-preservation.json'))
assert preserved['all_unchanged'] and preserved['ignored_and_hidden_included']
inputs=json.loads(decode(gates,'tested-core-input-hashes.json.gz'))
assert preserved['tested_core_files']==len(inputs)
changed=[]
for path,digest in inputs.items():
 assert (root/path).is_file(),path
 if sha((root/path).read_bytes())!=digest:changed.append(path)
assert not changed,changed
scope=preserved['scope']; paths=subprocess.check_output(['git','ls-files','-co','-z','--',*scope],cwd=root)
current={p.decode() for p in paths.split(b'\0') if p and (root/p.decode()).is_file() and not {'__pycache__','.pytest_cache','.ruff_cache'}&set(Path(p.decode()).parts)}
added=sorted(current-set(inputs)); allowed='research/pathway_additions/2026-10-15-next-264/verification/page-history-correction/'
assert all(p.startswith(allowed) for p in added),added
final=json.loads((out/'inspect-final.json').read_bytes())
for item in final['source']['inputs']:assert sha((root/item['path']).read_bytes())==item['sha256'],item['path']
result={'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),'retention':checked,'commands':receipts,'full_suite_summary':summary[0],'all_tested_inputs_currently_unchanged':True,'tested_input_count':len(inputs),'added_inputs':added,'added_input_scope':'Only retained correction evidence','final_inspected_inputs_unchanged':True,'limits':'Commands executed by root; independently read all actual logs, verified lossless retention and input hashes. No duplicate broad gate run; protected GitHub CI and canonical save/check remain root-owned.'}
(out/'gate-acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('commands','added_inputs')},indent=2))
