from pathlib import Path
import datetime,gzip,hashlib,json
root=Path('/private/tmp/pathwaymech-next-264-20261015'); out=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review')
base=root/'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction'
m=json.loads((base/'retention-manifest.json').read_bytes()); proofs=[]
for row in m['artifacts']:
 raw=(base/row['stored_path']).read_bytes()
 assert len(raw)==row['stored_bytes'] and hashlib.sha256(raw).hexdigest()==row['stored_sha256'],row['stored_path']
 decoded=gzip.decompress(raw) if row['encoding']=='gzip' else raw
 original=Path(row['original_path']).read_bytes()
 assert decoded==original and len(decoded)==row['original_bytes'] and hashlib.sha256(decoded).hexdigest()==row['original_sha256'],row['stored_path']
 proofs.append({'stored_path':row['stored_path'],'original_sha256':row['original_sha256'],'stored_sha256':row['stored_sha256'],'bytes':len(decoded)})
log=gzip.decompress((base/'pr575-first-ci-failure.log.gz').read_bytes()).decode()
assert '1 failed, 5250 passed, 7 skipped, 7 warnings' in log
assert 'pages/records/MetaCyc_PWY-2503.html: not what its record renders to' in log
assert 'Process completed with exit code 1.' in log
finding=json.loads((base/'diagnosis/finding.v2.json').read_bytes()); assert finding['severity']=='major'
issue=(base/'stale-history-page-issue.md').read_text()
print(issue)
r={'accessed_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),'retained_pairs':len(proofs),'all_stored_hashes_sizes_and_decoded_originals_match':True,'issue':m['issue'],'original_finding_severity':finding['severity'],'severity_scope_note':m['scope'],'failed_ci':{'exit_code':1,'failed':1,'passed':5250,'skipped':7,'warnings':7,'target':'pages/records/MetaCyc_PWY-2503.html'},'pairs':proofs}
(out/'diagnosis-retention-acceptance.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k!='pairs'},indent=2))
