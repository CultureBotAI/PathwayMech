"""Capture added immutable correction-gate context without refreshing earlier hashes."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,sys
root=Path('/private/tmp/pathwaymech-next-264-20261015'); out=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review')
base=root/'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction'
assert not (out/'inspect-final.json').exists()
old=json.loads((out/'inspect.json').read_bytes())
for item in old['source']['inputs']:
 assert hashlib.sha256((root/item['path']).read_bytes()).hexdigest()==item['sha256'],item['path']
inputs={r['path'] for r in old['source']['inputs']}
for name in ('gates','independent-pre-gate-acceptance'):
 folder=base/name; assert (folder/'retention-manifest.json').is_file()
 inputs|={str(p.relative_to(root)) for p in folder.rglob('*') if p.is_file()}
args=[sys.executable,'-B','scripts/record_review.py','inspect','--targets',str(out/'targets.yaml')]
for path in sorted(inputs):args+=['--input',path]
p=subprocess.run(args,cwd=root,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'))
(out/'inspect-final.json').write_bytes(p.stdout);(out/'inspect-final.stderr.log').write_bytes(p.stderr)
(out/'inspect-final-execution.json').write_text(json.dumps({'command':args,'returncode':p.returncode,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),'prior_inputs_exactly_preserved':True},indent=2)+'\n')
assert p.returncode==0,p.stderr.decode()
new=json.loads(p.stdout)
assert new['source']['git_revision']==old['source']['git_revision']
new_inputs={r['path']:r for r in new['source']['inputs']}
for item in old['source']['inputs']:assert item==new_inputs[item['path']]
print(json.dumps({'returncode':p.returncode,'previous_inputs':len(old['source']['inputs']),'final_inputs':len(new['source']['inputs']),'all_previous_bindings_unchanged':True}))
