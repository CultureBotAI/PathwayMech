from pathlib import Path
import datetime,json,os,subprocess,sys
root=Path('/private/tmp/pathwaymech-next-264-20261015'); out=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review')
assert not (out/'inspect.json').exists()
inputs=['CLAUDE.md','.claude/skills/review-yaml-record/SKILL.md','.claude/skills/add-pathway/SKILL.md','docs/record-reviews.md','docs/record-review-profile.md','conf/record_review.yaml','schema/record_review.yaml','scripts/record_review.py','src/pathwaymech/cli.py','src/pathwaymech/graph_view.py','src/pathwaymech/site_display.py','src/pathwaymech/yaml_io.py','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','conf/identifier_sources.json','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json','pages/records/MetaCyc_PWY-2503.html','pages/downloads/nodes.tsv','pages/downloads/edges.tsv','pages/downloads/manifest.json','reviews/structured/20261015T101912Z-next264-independent-technical/review.yaml','reviews/structured/20261015T101855Z-next264-independent-scientific/review.yaml','history/reports/benzoate-degradation-i-aerobic-source-preparation/2026-10-15T104605Z-Codex-834715.yaml']
inputs+=sorted(str(p.relative_to(root)) for p in (root/'history/records/benzoate-degradation-i-aerobic').glob('*.yaml'))
inputs+=sorted(str(p.relative_to(root)) for p in (root/'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction').rglob('*') if p.is_file())
args=[sys.executable,'-B','scripts/record_review.py','inspect','--targets',str(out/'targets.yaml')]
for p in sorted(set(inputs)): args+=['--input',p]
p=subprocess.run(args,cwd=root,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'))
(out/'inspect.json').write_bytes(p.stdout); (out/'inspect.stderr.log').write_bytes(p.stderr)
(out/'inspect-execution.json').write_text(json.dumps({'command':args,'returncode':p.returncode,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')},indent=2)+'\n')
print(json.dumps({'returncode':p.returncode,'input_count':len(json.loads(p.stdout)['source']['inputs']) if p.returncode==0 else None,'stderr':p.stderr.decode()}))
raise SystemExit(p.returncode)
