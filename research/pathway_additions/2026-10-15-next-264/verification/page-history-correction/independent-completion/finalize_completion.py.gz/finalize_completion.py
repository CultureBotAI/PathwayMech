from pathlib import Path
import datetime,hashlib,importlib.util,json,os,shutil,subprocess,sys,yaml
root=Path('/private/tmp/pathwaymech-next-264-20261015');out=Path('/private/tmp/pathwaymech-next-264-page-history-successor-review')
p=out/'review.yaml';review=yaml.safe_load(p.read_bytes())
assert hashlib.sha256(p.read_bytes()).hexdigest()=='7c9b276603991dbb291758f39c9fce0e2ddd23eba82523333c782c54f35f8e32'
assert json.loads((out/'validate.stdout.log').read_text())=={'valid_reviews':1}
args=[sys.executable,'-B','scripts/record_review.py','render','--content',str(p)]
r=subprocess.run(args,cwd=root,capture_output=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'))
(out/'review.preview.md').write_bytes(r.stdout);(out/'render.stderr.log').write_bytes(r.stderr)
assert r.returncode==0,r.stderr.decode()
spec=importlib.util.spec_from_file_location('canonical_record_review',root/'scripts/record_review.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.assert_current_source(root,review)
status=subprocess.check_output(['git','status','--short'],cwd=root,text=True)
(out/'final-source-freshness.json').write_text(json.dumps({'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z'),'canonical_assert_current_source_passed':True,'review_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'review_id':review['review_id'],'reviewed_inputs':len(review['source']['inputs']),'git_status_observation':status,'render_exit_code':r.returncode,'validate_exit_code':0,'maintained_writes_by_reviewer':False},indent=2)+'\n')
(out/'HANDOFF.md').write_text(f'''# Bounded page-history successor: ready for root persistence

Validated review: `{review['review_id']}`

Content: `/private/tmp/pathwaymech-next-264-page-history-successor-review/review.yaml`

SHA256: `7c9b276603991dbb291758f39c9fce0e2ddd23eba82523333c782c54f35f8e32`

`scientific_review: false`; `kind: record`; target kind maintained; one target with partial technical scope; verdict pass_with_limitations; zero findings. Issue 576's completed local correction is evidence-linked in assessments. Related reviews preserve prior observations; no fabricated canonical finding lineage is introduced.

All 90 canonical input bindings remain exact. The corrected page is the precise native current-history render; its sole 1,299-byte insertion restores the omitted review-history entry. All 821 scoped scientific inputs remain unchanged, including all 261 pathway records, authority snapshots, code, schemas, tests, record history and KGX downloads. The entire graph is byte-identical. All seven corrected local gates passed; 5,255 tests passed, 3 skipped and 7 warnings. All 4,754 tested inputs remain exact. All 14 gate retention pairs and 13 pre-gate retention pairs match originals. Initial failed Linux CI remains explicit historical evidence; new-head protected CI and actual merge are not claimed complete.

Root should use the canonical `save --content` command on the exact YAML above, then `check --base 3bd67d7cc30513e6b3cddc9b3696af0ef785fbdb`. The saver generates authoritative paired Markdown; `review.preview.md` is only a canonical render preview. No maintained writes were performed by this reviewer. README is deliberately not bound; no additional record-targeted history should be appended after the checked render. The root-owned final documentation helper must include current-site checking before push.

The original diagnosis, initial canonical review bundle and frozen pre-gate package remain unchanged. Completion evidence includes unsaved draft refinements transparently: prose spacing was improved, then its timestamp-prefixed ID was aligned with actual finished_at after a validation failure caught the mismatch. Final validation passes and source freshness was checked with canonical assert_current_source. No failed attempt is presented as successful.
''')
dest=out/'completion';assert not dest.exists();dest.mkdir()
for source in sorted(out.iterdir()):
 if source.is_file():shutil.copyfile(source,dest/source.name)
m={'schema':'independent-page-history-completion-v1','review_id':review['review_id'],'review_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Final bounded local technical acceptance before root canonical persistence and protected CI','artifacts':[{'path':x.name,'sha256':hashlib.sha256(x.read_bytes()).hexdigest(),'size':x.stat().st_size} for x in sorted(dest.iterdir()) if x.is_file()]}
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'completion_root':str(dest),'artifacts':len(m['artifacts']),'manifest_sha256':hashlib.sha256((dest/'manifest.json').read_bytes()).hexdigest(),'review_id':review['review_id'],'source_freshness':'passed','review_sha256':m['review_sha256']}))
