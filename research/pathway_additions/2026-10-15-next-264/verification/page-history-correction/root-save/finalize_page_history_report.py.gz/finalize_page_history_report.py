"""Record the accepted correction without changing record-page inputs."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import subprocess
import yaml

ROOT = Path('/private/tmp/pathwaymech-next-264-20261015')
CI = Path('/private/tmp/pathwaymech-next-264-ci')
REPORT = ROOT / 'research/pathway_additions/2026-10-15-next-264'
REVIEW = 'reviews/structured/20261015T111832Z-next264-page-history-technical-successor'
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    canonical = yaml.safe_load((ROOT / REVIEW / 'review.yaml').read_bytes())
    original = yaml.safe_load(Path('/private/tmp/pathwaymech-next-264-page-history-successor-review/review.yaml').read_bytes())
    assert canonical == original
    assert canonical['completion'] == 'completed' and canonical['verdict'] == 'pass_with_limitations'
    assert canonical['scientific_review'] is False and canonical['findings'] == []
    assert sha((ROOT / 'pages/records/MetaCyc_PWY-2503.html').read_bytes()) == '4e637a583fc5bbccb0b2b25ccac95b1b2b03b0dfedaff2b267068f7c9c2d37fe'
    readme = REPORT / 'README.md'
    text = readme.read_text()
    needle = ('The correction uses the native renderer with all record-history inputs\n'
              'present. Corrected-output gates and bounded independent acceptance are\n'
              'required before the new PR head can merge. Previous canonical scientific\n'
              'and technical reviews and frozen source packages remain unchanged.\n')
    assert text.count(needle) == 1
    replacement = ('The native renderer ran with all record-history inputs present. The\n'
        '[corrected gate receipts](verification/page-history-correction/gates/receipts.json)\n'
        'record successful rendering, validation, the full test suite (**5,255 passed,\n'
        'three skipped, seven warnings**), lint, vendored checks and whitespace checks.\n'
        'All 4,754 scoped tested inputs remained unchanged during the run.\n\n'
        f'The [independent correction review](../../../{REVIEW}/review.md)\n'
        'is saved as a completed bounded technical review with `pass_with_limitations`,\n'
        '`scientific_review: false` and zero remaining findings. It verifies the exact\n'
        'history insertion, unchanged full graph, 821 preserved scientific/code/output\n'
        'inputs, all corrected gate evidence and all 90 canonical input bindings.\n'
        'The [completion proof](verification/page-history-correction/independent-completion/HANDOFF.md)\n'
        'preserves the reviewer\'s original validation and freshness observations.\n\n'
        'Previous canonical reviews and frozen sources remain immutable. The canonical\n'
        'save and evidence retention are bound in the\n'
        '[root persistence receipt](verification/page-history-correction/root-save/retention-manifest.json).\n'
        'Final report/review checks include a new native site-current check; no further\n'
        'record-targeted history is appended after rendering. Updated protected GitHub\n'
        'CI and actual merge verification remain separate publication requirements.\n')
    readme.write_text(text.replace(needle, replacement))
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH=str(ROOT/'src')+':'+str(ROOT))
    command = [PYTHON, '-B', 'scripts/new_history_record.py', '--kind', 'report',
        '--slug', 'benzoate-degradation-i-aerobic-source-preparation',
        '--path', 'research/pathway_additions/2026-10-15-next-264/README.md',
        '--event', 'REVIEW', '--outcome', 'changed', '--actor-name', 'Codex', '--agent-tool', 'codex',
        '--issue', '576', '--pr', '575', '--summary', 'Retain independent acceptance of the page-history correction',
        '--details', 'Native rendering and all seven corrected local gates passed: 5255 tests passed, 3 skipped, 7 warnings; 4754 scoped tested inputs remained unchanged. Saved independent bounded technical review 20261015T111832Z-next264-page-history-technical-successor is completed/pass_with_limitations with scientific_review:false and no findings. It accepts exactly the omitted 1299-byte REVIEW history insertion, unchanged full graph and 821 scientific/code/output inputs, and all 90 canonical bindings. The failed original CI and earlier reviews remain immutable. Completion proof and canonical persistence receipts are retained. Final documentation/review/history/site-current checks and new-head protected CI/publication are subsequent gates, not claimed completed here. This report-only event does not add record-page history.']
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
    receipt = CI / 'page-history-final-report-history.json'
    assert not receipt.exists()
    receipt.write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}, indent=2)+'\n')
    assert result.returncode == 0, receipt.read_text()
    dest = REPORT / 'verification/page-history-correction/root-save'
    assert not dest.exists()
    dest.mkdir()
    pairs = []
    for source in [CI/'page-history-canonical-save.json', CI/'page-history-review-retention.json',
                   CI/'save_page_history_review.py', receipt, Path(__file__)]:
        body = source.read_bytes()
        readable = source.suffix == '.json'
        encoded = body if readable else gzip.compress(body, mtime=0)
        name = source.name if readable else source.name+'.gz'
        (dest/name).write_bytes(encoded)
        assert (encoded if readable else gzip.decompress(encoded)) == body
        pairs.append({'original_path': str(source), 'original_sha256': sha(body), 'original_bytes': len(body),
            'stored_path': name, 'stored_sha256': sha(encoded), 'stored_bytes': len(encoded), 'encoding': 'identity' if readable else 'gzip'})
    (dest/'retention-manifest.json').write_text(json.dumps({'scope': 'Canonical persistence and report-only provenance after independent acceptance; no record-history changes.', 'pairs': pairs},indent=2)+'\n')
    print(receipt.read_text(), flush=True)


if __name__ == '__main__':
    main()
