"""Persist the independent validated review and retain its immutable proof."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import subprocess

ROOT = Path('/private/tmp/pathwaymech-next-264-20261015')
CI = Path('/private/tmp/pathwaymech-next-264-ci')
SOURCE = Path('/private/tmp/pathwaymech-next-264-page-history-successor-review/completion')
CONTENT = SOURCE.parent / 'review.yaml'
DEST = ROOT / 'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction/independent-completion'
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'
REVIEW_ID = '20261015T111832Z-next264-page-history-technical-successor'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    manifest = SOURCE / 'manifest.json'
    assert sha(manifest.read_bytes()) == '866edffdbc91a6510e60282f22177b4847f36e1e35337e15c734a95382041ffc'
    rows = json.loads(manifest.read_bytes())['artifacts']
    assert {str(p.relative_to(SOURCE)) for p in SOURCE.rglob('*') if p.is_file()} == {r['path'] for r in rows} | {'manifest.json'}
    for row in rows:
        body = (SOURCE / row['path']).read_bytes()
        assert sha(body) == row['sha256'] and len(body) == row['size']
    assert CONTENT.read_bytes() == (SOURCE / 'review.yaml').read_bytes()
    assert sha(CONTENT.read_bytes()) == '7c9b276603991dbb291758f39c9fce0e2ddd23eba82523333c782c54f35f8e32'
    assert not DEST.exists() and not (ROOT / 'reviews/structured' / REVIEW_ID).exists()
    command = [PYTHON, '-B', 'scripts/record_review.py', 'save', '--content', str(CONTENT)]
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
               PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT))
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
    receipt = CI / 'page-history-canonical-save.json'
    assert not receipt.exists()
    receipt.write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
        'input_sha256': sha(CONTENT.read_bytes())}, indent=2) + '\n')
    print(receipt.read_text(), flush=True)
    assert result.returncode == 0
    bundle = ROOT / 'reviews/structured' / REVIEW_ID
    assert (bundle / 'review.yaml').is_file() and (bundle / 'review.md').is_file()
    copies = []
    for source in sorted(SOURCE.rglob('*')):
        if not source.is_file():
            continue
        body = source.read_bytes()
        relative = source.relative_to(SOURCE)
        readable = source.suffix in {'.json', '.md'}
        name = relative if readable else Path(str(relative) + '.gz')
        target = DEST / name
        encoded = body if readable else gzip.compress(body, mtime=0)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(encoded)
        assert (target.read_bytes() if readable else gzip.decompress(target.read_bytes())) == body
        copies.append({'original_path': str(source), 'original_sha256': sha(body), 'original_bytes': len(body),
                       'stored_path': str(name), 'stored_sha256': sha(encoded), 'stored_bytes': len(encoded),
                       'encoding': 'identity' if readable else 'gzip'})
    retained = DEST / 'retention-manifest.json'
    retained.write_text(json.dumps({'source_manifest_sha256': sha(manifest.read_bytes()),
        'scope': 'Independent bounded page-history correction acceptance, validated before canonical save; all failed preparatory attempts retained.',
        'pairs': copies}, indent=2) + '\n')
    binding = {'review_id': REVIEW_ID, 'source_manifest_sha256': sha(manifest.read_bytes()),
        'canonical_bundle': str(bundle.relative_to(ROOT)),
        'review_yaml_sha256': sha((bundle / 'review.yaml').read_bytes()),
        'review_md_sha256': sha((bundle / 'review.md').read_bytes()),
        'completion_retention_manifest_sha256': sha(retained.read_bytes()), 'retained_pairs': len(copies),
        'save_receipt_sha256': sha(receipt.read_bytes())}
    out = CI / 'page-history-review-retention.json'
    assert not out.exists()
    out.write_text(json.dumps(binding, indent=2) + '\n')
    print(out.read_text(), flush=True)


if __name__ == '__main__':
    main()
