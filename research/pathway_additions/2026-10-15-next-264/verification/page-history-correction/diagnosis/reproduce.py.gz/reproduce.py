import difflib, hashlib, json, os, platform, subprocess, sys
from pathlib import Path
root=Path('/private/tmp/pathwaymech-next-264-20261015')
out=Path('/private/tmp/pathwaymech-next-264-render-ci-review')
sys.path.insert(0,str(root/'src'))
from pathwaymech.cli import _record_page
from pathwaymech.schema import validate_record
from pathwaymech.site_display import load_site_history
from pathwaymech.yaml_io import load_yaml_file
source='data/pathways/benzoate-degradation-i-aerobic.yaml'
page='pages/records/MetaCyc_PWY-2503.html'
record=validate_record(load_yaml_file(root/source))
histories=load_site_history(root)
sessions=histories[source]
expected=_record_page(record,source,sessions).encode()
actual=(root/page).read_bytes()
(out/'committed.html').write_bytes(actual)
(out/'rendered-current-history.html').write_bytes(expected)
(out/'committed-vs-rendered.diff').write_text(''.join(difflib.unified_diff(actual.decode().splitlines(keepends=True),expected.decode().splitlines(keepends=True),fromfile='committed.html',tofile='rendered-current-history.html')))
prior=[s for s in sessions if not s['source_path'].endswith('2026-10-15T102211Z-Codex-c5acee.yaml')]
without_new=_record_page(record,source,prior).encode()
(out/'rendered-without-later-history.html').write_bytes(without_new)
result={
 'root':str(root), 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'python':sys.version, 'platform':platform.platform(), 'hash_seed':os.environ.get('PYTHONHASHSEED'),
 'input_hashes':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in [source,page,'src/pathwaymech/cli.py','src/pathwaymech/graph_view.py','src/pathwaymech/site_display.py']},
 'history':[{'source_path':s['source_path'],'sha256':hashlib.sha256((root/s['source_path']).read_bytes()).hexdigest()} for s in sessions],
 'actual_sha256':hashlib.sha256(actual).hexdigest(),'expected_sha256':hashlib.sha256(expected).hexdigest(),
 'prior_history_render_sha256':hashlib.sha256(without_new).hexdigest(),
 'current_matches':actual==expected,'excluding_later_review_history_matches':actual==without_new,
 'diff_size_bytes':(out/'committed-vs-rendered.diff').stat().st_size,
 'actual_size':len(actual),'expected_size':len(expected),
}
(out/'reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
