import hashlib,json
from pathlib import Path
out=Path('/private/tmp/pathwaymech-next-264-render-ci-review')
a=(out/'committed.html').read_bytes(); b=(out/'rendered-current-history.html').read_bytes()
start=next(i for i,(x,y) in enumerate(zip(a,b)) if x!=y)
suffix=next(i for i,(x,y) in enumerate(zip(reversed(a),reversed(b))) if x!=y)
suffix=min(suffix,len(a)-start,len(b)-start)
assert start==len(a)-suffix
inserted=b[start:len(b)-suffix]
assert a[:start]+inserted+a[start:]==b
# Prefer the semantic boundary immediately after the first history list entry.
marker=b'<li><time>2026-10-15T10:22:11Z</time>'
semantic_start=b.index(marker)
semantic_insert=b[semantic_start:semantic_start+len(b)-len(a)]
assert a[:semantic_start]+semantic_insert+a[semantic_start:]==b
(out/'exact-inserted-history.html').write_bytes(semantic_insert)
ops=[{'kind':'insert','offset':semantic_start,'inserted_size':len(semantic_insert),'inserted_sha256':hashlib.sha256(semantic_insert).hexdigest(),'content':semantic_insert.decode()}]
(out/'exact-byte-differences.v2.json').write_text(json.dumps(ops,indent=2)+'\n')
prior=json.loads((out/'diagnosis.json').read_text())
prior.update(operations=1,kinds=['insert'],only_history_review_inserted=True,exact_change='One 1299-byte history list entry inserted at byte337?' if False else f'One {len(semantic_insert)}-byte history list entry inserted at byte {semantic_start}',diagnostic_successor_note='Initial linear diff allowed overlapping common prefix and suffix because HTML closing markup repeats. This successor caps overlap and separately proves exact reconstruction at the semantic list-entry boundary. Original diagnostic result and helper preserved; this successor supersedes only its diff-operation classification.')
(out/'diagnosis.v2.json').write_text(json.dumps(prior,indent=2)+'\n')
print(json.dumps(prior,indent=2))
