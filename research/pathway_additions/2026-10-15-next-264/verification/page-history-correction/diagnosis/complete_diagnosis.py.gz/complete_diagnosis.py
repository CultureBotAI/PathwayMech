import hashlib, json, os, subprocess, sys
from pathlib import Path
out=Path('/private/tmp/pathwaymech-next-264-render-ci-review'); root=Path('/private/tmp/pathwaymech-next-264-20261015')
a=(out/'committed.html').read_bytes(); b=(out/'rendered-current-history.html').read_bytes()
start=next(i for i,(x,y) in enumerate(zip(a,b)) if x!=y)
suffix=next(i for i,(x,y) in enumerate(zip(reversed(a),reversed(b))) if x!=y)
ops=[{'kind':'insert' if start==len(a)-suffix else 'replace','actual_start':start,'actual_end':len(a)-suffix,'expected_start':start,'expected_end':len(b)-suffix,'actual':a[start:len(a)-suffix].decode(),'expected':b[start:len(b)-suffix].decode()}]
assert a[:start]+b[start:len(b)-suffix]+a[len(a)-suffix:]==b
(out/'exact-byte-differences.json').write_text(json.dumps(ops,indent=2)+'\n')
def graph(data):
 start=data.index(b'<section id="pathway-network"'); end=data.index(b'</svg></div></section>',start)+len(b'</svg></div></section>')
 return data[start:end]
assert graph(a)==graph(b)
code='''import sys,hashlib,json
from pathlib import Path
r=Path("/private/tmp/pathwaymech-next-264-20261015")
sys.path.insert(0,str(r/"src"))
from pathwaymech.cli import _record_page
from pathwaymech.schema import validate_record
from pathwaymech.site_display import load_site_history
from pathwaymech.yaml_io import load_yaml_file
p="data/pathways/benzoate-degradation-i-aerobic.yaml"
s=load_site_history(r)[p]
v=validate_record(load_yaml_file(r/p))
print(json.dumps({"rendered_sha256":hashlib.sha256(_record_page(v,p,s).encode()).hexdigest(),"prior_history_sha256":hashlib.sha256(_record_page(v,p,s[:1]).encode()).hexdigest()}))
'''
seeds=[]
for seed in ('0','1','12345'):
 env=os.environ.copy(); env.update({'PYTHONHASHSEED':seed,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
 p=subprocess.run([sys.executable,'-B','-c',code],env=env,capture_output=True,text=True,cwd=root)
 (out/f'hash-seed-{seed}.stdout.log').write_text(p.stdout)
 (out/f'hash-seed-{seed}.stderr.log').write_text(p.stderr)
 seeds.append({'seed':seed,'returncode':p.returncode,'result':json.loads(p.stdout) if p.returncode==0 else None})
result={'operations':len(ops),'kinds':[x['kind'] for x in ops],'changed_bytes':len(b)-len(a),'only_history_review_inserted':len(ops)==1 and ops[0]['kind']=='insert' and '2026-10-15T102211Z-Codex-c5acee.yaml' in ops[0]['expected'],'complete_graph_equal':True,'graph_sha256':hashlib.sha256(graph(a)).hexdigest(),'seed_checks':seeds,'limits':'Three explicitly selected hash seeds on macOS Python 3.13.12; no Linux run performed. The isolated omission of the later history entry reproduces committed bytes exactly and full graph bytes are unchanged.','diagnostic_process_note':'Original analyze.py was explicitly interrupted (session56773, exit130) while byte-level difflib SequenceMatcher was still running; no output artifacts existed from it. This successor uses linear prefix/suffix identification and proves exact byte reconstruction.'}
(out/'diagnosis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
