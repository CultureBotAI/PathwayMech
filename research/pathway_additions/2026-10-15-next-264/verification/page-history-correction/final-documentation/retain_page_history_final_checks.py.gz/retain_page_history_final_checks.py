"""Retain final site/review/history checks after their terminal completion."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json

ROOT = Path('/private/tmp/pathwaymech-next-264-20261015')
CI = Path('/private/tmp/pathwaymech-next-264-ci')
SOURCE = Path('/private/tmp/pathwaymech-next-264-checks-page-history-final')
DEST = ROOT / 'research/pathway_additions/2026-10-15-next-264/verification/page-history-correction/final-documentation'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def main():
    assert not DEST.exists()
    receipts = json.loads((SOURCE / 'receipts.json').read_bytes())
    assert len(receipts) == 7 and all(row['exit_code'] == 0 for row in receipts)
    assert receipts[0]['command'] == ['just', 'check-pages']
    for row in receipts:
        assert sha(Path(row['log_path']).read_bytes()) == row['log_sha256']
    assert json.loads((SOURCE / 'final-input-preservation.json').read_bytes())['all_unchanged']
    inputs = json.loads((SOURCE / 'checked-input-hashes.json').read_bytes())
    for name, digest in inputs.items():
        assert sha((ROOT / name).read_bytes()) == digest, name
    selected = list(SOURCE.iterdir()) + [CI / 'run_page_history_final_checks.py', Path(__file__)]
    assert all(p.is_file() for p in selected)
    assert len({p.name for p in selected}) == len(selected)
    DEST.mkdir()
    rows = []
    readable = {'receipts.json', 'delta-accounting.json', 'final-input-preservation.json'}
    for source in sorted(selected):
        body = source.read_bytes()
        encoding = 'identity' if source.name in readable else 'gzip'
        encoded = body if encoding == 'identity' else gzip.compress(body, mtime=0)
        name = source.name if encoding == 'identity' else source.name + '.gz'
        target = DEST / name
        target.write_bytes(encoded)
        assert (target.read_bytes() if encoding == 'identity' else gzip.decompress(target.read_bytes())) == body
        rows.append({'original_path': str(source), 'original_sha256': sha(body), 'original_bytes': len(body),
                     'stored_path': name, 'stored_sha256': sha(encoded), 'stored_bytes': len(encoded), 'encoding': encoding})
    manifest = DEST / 'retention-manifest.json'
    manifest.write_text(json.dumps({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'Final native site-current, review, history, documentation and whitespace checks after corrected full gates; no scientific or record-history changes.',
        'checked_inputs': len(inputs), 'pairs': rows}, indent=2) + '\n')
    receipt = CI / 'page-history-final-documentation-retention.json'
    assert not receipt.exists()
    receipt.write_text(json.dumps({'destination': str(DEST), 'manifest_sha256': sha(manifest.read_bytes()),
                                  'pairs': len(rows), 'checked_inputs': len(inputs)}, indent=2) + '\n')
    print(receipt.read_text())


if __name__ == '__main__':
    main()
