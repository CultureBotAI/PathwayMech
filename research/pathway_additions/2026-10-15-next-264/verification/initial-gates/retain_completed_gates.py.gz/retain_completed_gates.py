"""Retain completed gates without changing any tested pathway or generator input."""
from pathlib import Path
import datetime
import gzip
import hashlib
import json
import shutil

ROOT = Path('/private/tmp/pathwaymech-next-264-20261015')
SOURCE = Path('/private/tmp/pathwaymech-next-264-checks-initial')
DEST = ROOT / 'research/pathway_additions/2026-10-15-next-264/verification/initial-gates'
CI = Path('/private/tmp/pathwaymech-next-264-ci')


def digest(body):
    return hashlib.sha256(body).hexdigest()


def main():
    assert not DEST.exists()
    receipts = json.loads((SOURCE / 'receipts.json').read_bytes())
    expected = [['just', 'render-pages'], ['just', 'validate'], ['just', 'test'],
                ['just', 'lint'], ['just', 'vendored-check'],
                ['git', 'diff', '--check'], ['git', 'diff', '--cached', '--check']]
    assert [row['command'] for row in receipts] == expected
    assert all(row['exit_code'] == 0 for row in receipts)
    for row in receipts:
        assert digest(Path(row['log_path']).read_bytes()) == row['log_sha256']
    preserved = json.loads((SOURCE / 'final-input-preservation.json').read_bytes())
    assert preserved['all_unchanged'] is True
    inputs = json.loads((SOURCE / 'tested-core-input-hashes.json').read_bytes())
    for relative, sha in inputs.items():
        assert digest((ROOT / relative).read_bytes()) == sha, relative
    assert preserved['tested_core_files'] == len(inputs)
    selected = list(SOURCE.iterdir())
    assert all(p.is_file() for p in selected)
    selected.extend([CI / 'run_initial_checks.py', CI / 'retain_completed_gates.py'])
    pairs = []
    DEST.mkdir(parents=True)
    for source in sorted(selected):
        body = source.read_bytes()
        readable = source.name in {'receipts.json', 'environment.json', 'final-input-preservation.json'}
        name = source.name if readable else source.name + '.gz'
        encoded = body if readable else gzip.compress(body, mtime=0)
        (DEST / name).write_bytes(encoded)
        decoded = encoded if readable else gzip.decompress(encoded)
        assert decoded == body
        pairs.append({'original_path': str(source), 'original_sha256': digest(body),
                      'original_bytes': len(body), 'stored_path': name,
                      'stored_sha256': digest(encoded), 'stored_bytes': len(encoded),
                      'encoding': 'identity' if readable else 'gzip'})
    manifest = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'scope': 'Actual initial complete gates; source paths preserve execution locations. '
                         'Later evidence, history and canonical-review additions require separate bounded checks.',
                'tested_files_rechecked_before_retention': len(inputs), 'pairs': pairs}
    (DEST / 'retention-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    receipt = {'retained_path': str(DEST), 'retention_manifest_sha256':
               digest((DEST / 'retention-manifest.json').read_bytes()),
               'all_seven_commands_passed': True, 'tested_files_unchanged': len(inputs)}
    output = CI / 'completed-gates-retention.json'
    assert not output.exists()
    output.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
