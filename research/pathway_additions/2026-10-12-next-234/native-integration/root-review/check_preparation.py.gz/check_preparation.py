"""Root's independent bounded payload and historical-owner verification."""
import hashlib
import json
import os
import stat
import sys
from pathlib import Path

PREP = Path('/private/tmp/pathwaymech-next-234-local-integration-preparation-20261012')
ROOT = Path('/private/tmp/pathwaymech-next-234-local-20261012')
OUT = Path(__file__).parent


def pin(path):
    path = Path(path)
    assert stat.S_ISREG(path.lstat().st_mode), path
    for parent in path.parents:
        assert not parent.is_symlink(), parent
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def verify(row, path=None):
    got = pin(path or row['path'])
    assert (got['bytes'], got['sha256']) == (row['bytes'], row['sha256']), got
    return got


def load(path):
    return json.loads(Path(path).read_bytes())


def ordered(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def main():
    expected_handoff = sys.argv[1]
    handoff_pin = pin(PREP / 'handoff.json')
    assert handoff_pin['sha256'] == expected_handoff
    handoff = load(handoff_pin['path'])
    verify(handoff['manifest'], PREP / 'artifact-manifest.json')
    manifest = load(PREP / 'artifact-manifest.json')['artifacts']
    expected = {x['relative_path'] for x in manifest}
    assert len(expected) == len(manifest)
    actual = set()
    for base, ds, fs in os.walk(PREP, followlinks=False):
        for name in ds:
            assert stat.S_ISDIR((Path(base) / name).lstat().st_mode)
        for name in fs:
            p = Path(base) / name
            assert stat.S_ISREG(p.lstat().st_mode)
            actual.add(p.relative_to(PREP).as_posix())
    assert actual == expected | {'handoff.json', 'artifact-manifest.json'}
    for row in manifest:
        rel = Path(row['relative_path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        verify(row, PREP / rel)

    plan = load(PREP / 'plan.json')
    by = {x['destination']: x for x in plan['changes']}
    assert len(by) == len(plan['changes'])
    old = load('/private/tmp/pathwaymech-next-234-maintained-integration-preparation-20261012/provisional-owner-map.json')
    changed_runtime = []
    for row in old['runtime']:
        rel = row['relative_path']
        if row['disposition'] == 'unchanged':
            verify(row['candidate'], ROOT / rel)
        else:
            changed_runtime.append(rel)
            verify(row['candidate'], PREP / 'payload' / rel)
            assert by[rel]['payload']['sha256'] == row['candidate']['sha256']
    assert len(changed_runtime) == 14
    for row in old['corpus']:
        rel = 'data/pathways/' + row['relative_path']
        owner = ROOT if row['disposition'] == 'unchanged' else PREP / 'payload'
        verify(row['candidate'], owner / rel)
    native = {}
    for name, sha in [('sources', '7a52c5e586c508b17e82b716d97514f867e1461f7d92f5f82375b71a23b88cde'), ('ontology', 'd6835d49b48fa61e675aa0c134b28ad9377270da1098fdf781667b7706588b69')]:
        rel = f'data/identifier_authorities/{name}.json'
        after_pin = pin(PREP / 'payload' / rel)
        assert after_pin['sha256'] == sha
        before, after = load(ROOT / rel), load(after_pin['path'])
        assert list(before) == list(after)
        for key, value in before.items():
            if isinstance(value, dict):
                assert [k for k in after[key] if k in value] == list(value)
                for k, v in value.items():
                    assert ordered(v) == ordered(after[key][k]), (name, key, k)
            else:
                assert ordered(value) == ordered(after[key])
        native[name] = after_pin
    draft_rel = 'data/pathways/pyruvate-to-cytochrome-bd-oxidase-electron-transfer.yaml'
    draft_pin = pin(PREP / 'payload' / draft_rel)
    assert draft_pin['sha256'] == '0c5854f77ff0cf86215d7b8f1aa53cadec53bb7df673efd7cb7e2407c0f07f80'
    allowed_core = set(changed_runtime) | {draft_rel, 'data/identifier_authorities/sources.json', 'data/identifier_authorities/ontology.json'}
    assert {p for p in by if not p.startswith('research/pathway_additions/2026-10-12-next-234/')} == allowed_core
    for row in plan['accepted_inputs']:
        verify(row)
    # Run the reviewed helper's guards as an additional check, not an independent proof.
    sys.path.insert(0, str(PREP))
    import common
    import verify_portable
    common.check_inputs()
    portable = verify_portable.verify(ROOT, PREP / 'payload')
    result = {'status': 'root_exact_preparation_checks_passed', 'handoff': handoff_pin,
              'artifacts': len(manifest), 'seals': 2, 'changed_runtime_owners': changed_runtime,
              'whole_scientific_record': draft_pin, 'native_outputs': native,
              'portable': portable, 'hidden_ignored_included': True,
              'old_runtime_corpus_and_authority_order_preserved': True,
              'new_literature_review': False, 'target_or_cache_writes': False,
              'root_checker': pin(__file__)}
    with (OUT / 'checks.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
