from pathlib import Path
from lxml import html
import yaml,json,datetime
R=Path('/private/tmp/pathwaymech-next-234-local-20261012');O=Path(__file__).parent
r=yaml.safe_load((R/'data/pathways/pyruvate-to-cytochrome-bd-oxidase-electron-transfer.yaml').read_bytes());p=html.fromstring((R/'pages/records/MetaCyc_PWY-7545.html').read_bytes());expected=[('taxon',x) for x in r['taxa']]+[(x['category'].replace('_',' '),x) for k in ('participants','reactions') for x in r[k]]
rows=p.xpath('//tr[starts-with(@id,"component-")]');assert len(rows)==len(expected)==48
out=[]
for i,(row,(typ,node)) in enumerate(zip(rows,expected),1):
 cells=row.findall('td');assert len(cells)==3;assert cells[0].text==node['label'];assert cells[0].find('code').text==node['id'];assert ''.join(cells[1].itertext())==typ
 direction=''.join(cells[2].itertext());assert direction==node.get('direction','').replace('_',' ')
 out.append({'index':i,'id':node['id'],'label':node['label'],'category':typ,'direction':direction})
(O/'component-table-check.json').write_text(json.dumps({'status':'all_48_component_rows_exact','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':out},indent=2)+'\n');print('All48 component labels, identifiers, categories and directions exact.')
