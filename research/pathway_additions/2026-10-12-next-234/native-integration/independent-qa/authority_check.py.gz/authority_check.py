import json,hashlib,subprocess,datetime
from pathlib import Path
R=Path('/private/tmp/pathwaymech-next-234-local-20261012');O=Path(__file__).parent;BASE='8c871a5808c73b0f21a397a2561269d068ee7368'
def sha(b):return hashlib.sha256(b).hexdigest()
def ordered(v):
 if isinstance(v,dict):return [(k,ordered(x)) for k,x in v.items()]
 if isinstance(v,list):return [ordered(x) for x in v]
 return v
out={}
for name,exp in [('sources','7a52c5e586c508b17e82b716d97514f867e1461f7d92f5f82375b71a23b88cde'),('ontology','d6835d49b48fa61e675aa0c134b28ad9377270da1098fdf781667b7706588b69')]:
 p='data/identifier_authorities/'+name+'.json';b=(R/p).read_bytes();assert sha(b)==exp
 old=json.loads(subprocess.check_output(['git','show',BASE+':'+p],cwd=R));new=json.loads(b);result={}
 assert list(old)==list(new)
 for group in ('sources','terms'):
  assert [k for k in new[group] if k in old[group]]==list(old[group])
  assert all(ordered(v)==ordered(new[group][k]) for k,v in old[group].items())
  result[group]={'old':len(old[group]),'new':len(new[group]),'added':[k for k in new[group] if k not in old[group]]}
 out[name]=result
plan=json.loads(Path('/private/tmp/pathwaymech-next-234-local-integration-preparation-20261012/plan.json').read_text())
print(plan.keys())
for item in plan.get('changes',[]):print(item.keys());break
out.update(status='complete_old_authority_objects_and_order_preserved',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(O/'authority-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
