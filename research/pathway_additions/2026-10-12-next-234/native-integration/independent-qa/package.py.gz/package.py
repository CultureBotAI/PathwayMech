from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,yaml
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-234-local-20261012');G=Path('/private/tmp/pathwaymech-next-234-local-native-execution-20261012');V=Path('/private/tmp/pathwaymech-next-234-root-static-visual-20261012');D='research/pathway_additions/2026-10-12-next-234/native-integration/independent-qa'
sha=lambda b:hashlib.sha256(b).hexdigest()
# Native schemas are validated against actual existing maintained inputs; root adds newly adopted evidence inputs via guarded native inspect later.
py='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python';env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(R/'src')+':'+str(R)}
validation=[]
for typ in ('scientific','technical'):
 argv=[py,'-B','scripts/record_review.py','validate',str(O/(typ+'-review.yaml'))];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=R,env=env,capture_output=True)
 (O/(typ+'-validate.stdout')).write_bytes(r.stdout);(O/(typ+'-validate.stderr')).write_bytes(r.stderr)
 item={'argv':argv,'cwd':str(R),'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode};validation.append(item)
 (O/(typ+'-validate.execution.json')).write_text(json.dumps(item,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
qa=json.loads((O/'audit.json').read_text());cnt=len(qa['checks'])
report=f'''Accepted the actual local PWY-7545 integration with no new actionable finding.

The exact maintained record is SHA256 0c5854f77ff0cf86215d7b8f1aa53cadec53bb7df673efd7cb7e2407c0f07f80. I read all 2,274 YAML lines and the complete inherited 44-paragraph/69-edge dispositions. Original source interpretation is inherited from the sealed independent scientific review, not presented as a new primary-body inspection. Source-tier, taxon, construct, assay, heme, chemical-identity and obsolete-citation limitations remain explicit. Existing scientific issue corrections 476–478 and 482 are preserved; this review does not close GitHub issues or fabricate native predecessor finding records.

Fresh audit has {cnt:,} passing checks. Every graph arrow and evidence-table row, all 115 rendered reference entries, 48 component-table rows and the one cardiolipin experimental-construct endpoint match YAML. The 49 visual nodes comprise 48 route nodes and one qualified endpoint; the unconnected E. coli taxon remains in the component table. All local HTML links resolve and IDs are unique. Whole description text survives rendering.

All 13 cells of every 11,803 KGX edge rows and all seven cells of every 4,217 node rows were compared with all 235 YAML records, including exact reference metadata, complete qualifiers, directions and context multiplicities. CLI output and Pages downloads are byte-equal after the native export. All 11,734 old edge rows and all prior node-context multiplicities remain unchanged. The sole aggregate category addition is the separately accepted CHEBI:7896 SmallMolecule category. SSSOM retains all 15 prior rows and order and adds exactly six PWY-7545 rows, byte-equal to the independent native preview.

All 234 prior YAML records and record pages, 397 prior history files and 112 prior review pairs are byte-identical to the hidden/ignored-inclusive baseline. Both actual native authority outputs match their accepted hashes; every old object and nested/outer order is preserved. The exact 29 adopted owners match their accepted plan. Two native Codex history records preceded first rendering.

The complete portable replay freshly retrieved and hashed all 3,320 bodies (364,732,189 decoded bytes), covering 25 packets and 26,363 path views. It checked 828 manifest originals, 115 reference bindings, 28 bibliography originals, 116 prior reference bindings and two retired originals without external temporary original reads, extraction or recreated symlinks. Scientific source interpretation is not inferred from hashing.

All nine required root-owned maintained gates ultimately passed. The initial vendored attempt failed due sandbox DNS; its failure.json and streams remain distinct from the successful exact-command network retry. Tests report 3,705 passed, three skipped and three dependency deprecation warnings; lint is clean. I verified original command receipts and stdout/stderr hashes, not reran the complete suite. The final output parity and unchanged-input checks are in final-checks.json. Root's actual static full-graph and native-width crop inspection is inherited separately: dense labels overlap near junctions; no confirmed clipping was found. CUA exposed no browser, so no keyboard/JavaScript interaction is claimed.

Every initial checker failure and correction is retained in execution-notes.json and exact failed audit artifacts. These include system-Python setup, .gitkeep counting, the renderer's unconnected taxon rule, HTML bibliography hash expectations, pre-export CLI timing and SSSOM comment parsing. No failed run is relabeled successful. The final corrected audit and separate final parity checks both pass.

Two native review drafts validate through scripts/record_review.py: one scientific record review with 44 individual paragraph and 69 edge assessments plus scope/representation assessments, and one bounded technical repository review over 16 maintained/generated owners. They are external drafts, not saved native reviews. Root must adopt exact evidence owners, run finalize_native_inputs.py to bind the newly adopted QA/gate/visual bytes through native inspect, then separately save and check the bundles. This reviewer wrote only this external packet; no maintained/cache/Git/GitHub or publication action occurred.
'''
(O/'REPORT.md').write_text(report)
# Exclude output payload and final seals to avoid recursive packaging.
files=[p for p in O.rglob('*') if p.is_file() and 'payload' not in p.relative_to(O).parts and p.name not in {'copy-plan.json','artifact-manifest.json','handoff.json'}]
P=O/'payload';P.mkdir(exist_ok=False);rows=[]
for p in sorted(files):
 rel=p.relative_to(O).as_posix();raw=p.read_bytes();compressed=p.suffix=='.py';dest=rel+'.gz' if compressed else rel;body=gzip.compress(raw,mtime=0) if compressed else raw
 q=P/dest;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body)
 if compressed:assert gzip.decompress(body)==raw
 rows.append({'repository_path':D+'/'+dest,'payload_path':str(q),'bytes':len(body),'sha256':sha(body),'source_path':str(p),'decoded_sha256':sha(raw),'decoded_bytes':len(raw),'gzip_encoded':compressed})
index={'status':'ready_for_exact_root_adoption','durable_root':D,'files':[{k:v for k,v in x.items() if k not in ('payload_path','source_path')} for x in rows]};q=P/'package-index.json';q.write_text(json.dumps(index,indent=2)+'\n');b=q.read_bytes();rows.append({'repository_path':D+'/package-index.json','payload_path':str(q),'bytes':len(b),'sha256':sha(b),'gzip_encoded':False})
roots=[]
for p,rel in [(G/'history-and-generation/completion.json','gates/history-and-generation/completion.json'),(G/'remaining-gates/failure.json','gates/remaining-gates/failure.json'),(G/'network-resumption/completion.json','gates/network-resumption/completion.json'),(V/'observations.json','visual/observations.json')]:
 b=p.read_bytes();roots.append({'repository_path':'research/pathway_additions/2026-10-12-next-234/native-integration/'+rel,'source_path':str(p),'bytes':len(b),'sha256':sha(b)})
(O/'copy-plan.json').write_text(json.dumps({'durable_root':D,'files':rows,'root_evidence':roots,'native_save_performed':False,'maintained_writes_performed':False},indent=2)+'\n')
# Closed external manifest includes final payload, copy plan and every retained execution artifact.
allfiles=[p for p in O.rglob('*') if p.is_file() and p.name not in {'artifact-manifest.json','handoff.json'}];manifest={'artifacts':[{'path':p.relative_to(O).as_posix(),'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())} for p in sorted(allfiles)]}
mp=O/'artifact-manifest.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
hand={'status':'accepted_actual_local_integration_external_native_drafts_validated','reviewer':'Codex /root/pwy234_integrated_qa','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'findings':[],'artifact_count':len(allfiles),'manifest':{'path':str(mp),'bytes':mp.stat().st_size,'sha256':sha(mp.read_bytes())},'copy_plan':{'path':str(O/'copy-plan.json'),'bytes':(O/'copy-plan.json').stat().st_size,'sha256':sha((O/'copy-plan.json').read_bytes())},'report':{'path':str(O/'REPORT.md'),'bytes':(O/'REPORT.md').stat().st_size,'sha256':sha((O/'REPORT.md').read_bytes())},'native_drafts':[{ 'path':str(O/(t+'-review.yaml')),'bytes':(O/(t+'-review.yaml')).stat().st_size,'sha256':sha((O/(t+'-review.yaml')).read_bytes())} for t in ('scientific','technical')],'next':'Root adopt exact copy-plan evidence plus gates and visual directories, run guarded finalize_native_inputs.py with new output directory, then native save/check; no maintained save/publication by this reviewer.'}
(O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(hand,indent=2))
