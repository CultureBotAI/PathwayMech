from pathlib import Path
import json,gzip,hashlib,datetime
R=Path('/private/tmp/pathwaymech-next-234-local-20261012');O=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
idx=json.loads(gzip.decompress((R/'research/pathway_additions/2026-10-12-next-234/evidence-index.json.gz').read_bytes()))
plan=json.loads(Path('/private/tmp/pathwaymech-next-234-local-integration-preparation-20261012/plan.json').read_text())
rows=[]
for item in plan['changes']:
 p=R/item['destination'];b=p.read_bytes();exp=item['payload'];assert (len(b),sha(b))==(exp['bytes'],exp['sha256']);rows.append({'path':item['destination'],'bytes':len(b),'sha256':sha(b)})
prior={}
for name,path in {'scientific_review':'/private/tmp/pathwaymech-next-234-science-review-20261012/review.json','paragraph_assessments':'/private/tmp/pathwaymech-next-234-science-review-20261012/paragraph-assessments.json','edge_assessments':'/private/tmp/pathwaymech-next-234-science-review-20261012/edge-assessments.json','scientific_issue_dispositions':'/private/tmp/pathwaymech-next-234-science-review-20261012/existing-issue-dispositions.json','authority_output_review':'/private/tmp/pathwaymech-next-234-reference-selection-output-review-20261012/REPORT.md'}.items():
 p=Path(path);b=p.read_bytes();h=sha(b);assert h in idx['body_lookup'];prior[name]={'historical_path':path,'sha256':h,'bytes':len(b),'portable_owner':idx['body_lookup'][h]}
ph=Path('/private/tmp/pathwaymech-next-234-local-native-execution-20261012/history-and-generation/completion.json');phase=json.loads(ph.read_text());history=[]
for ex in phase['receipts']:
 assert ex['exit_code']==0
 for kind in ['stdout','stderr']:
  bound=ex[kind];b=Path(bound['path']).read_bytes();assert (len(b),sha(b))==(bound['bytes'],bound['sha256'])
 if ex['name'].startswith('history-'):
  rel=Path(ex['stdout']['path']).read_text().strip();print(rel)
  if rel.startswith('Created '):rel=rel.removeprefix('Created ')
  if (R/rel).is_file():history.append({'path':rel,'bytes':len((R/rel).read_bytes()),'sha256':sha((R/rel).read_bytes())})
out={'status':'29_adopted_owners_exact_and_complete_prior_review_retrievable','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'adopted_owners':rows,'prior_reviews':prior,'history_generation_receipts_verified':len(phase['receipts']),'new_history':history}
(O/'preparation-binding.json').write_text(json.dumps(out,indent=2)+'\n');print('All29 owners exact; prior review durable byte bindings complete.')
