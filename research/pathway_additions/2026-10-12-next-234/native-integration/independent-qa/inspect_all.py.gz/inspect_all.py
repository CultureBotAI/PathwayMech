from pathlib import Path
import json,subprocess,os,yaml,datetime
ROOT=Path('/private/tmp/pathwaymech-next-234-local-20261012');OUT=Path(__file__).parent
receipt=json.loads(Path('/private/tmp/pathwaymech-next-234-local-adoption-root-20261012/receipt.json').read_text())
primary=[p for p in receipt['changes'] if not p.startswith('research/') and not p.startswith('data/pathways/')]
targets=[]
for p in primary:
 t={'target_id':p,'path':p,'label':p,'kind':'maintained','ownership_note':'This maintained runtime/configuration owner is the correction surface.'}
 if p.startswith('data/identifier_authorities/'):
  owner='scripts/build_source_identifier_snapshot.py' if p.endswith('sources.json') else 'scripts/build_ontology_identifier_snapshot.py'
  t.update(kind='generated',owner_paths=[{'repository':'CultureBotAI/PathwayMech','path':owner,'role':'Native snapshot producer'}]);t.pop('ownership_note')
 targets.append(t)
(OUT/'technical-targets.yaml').write_text(yaml.safe_dump({'targets':targets},sort_keys=False))
inputs=[p for p in receipt['changes'] if p.startswith('research/')]+['pages/records/MetaCyc_PWY-7545.html','pages/downloads/nodes.tsv','pages/downloads/edges.tsv','output/sssom/source_mappings.sssom.tsv','docs/CAUSAL_GRAPHS.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/record-review-profile.md','schema/record_review.yaml','src/pathwaymech/kgx.py','src/pathwaymech/graph_view.py','src/pathwaymech/schema.py']
# Scientific inputs include every durable archive owner used to resolve inherited review and original bindings.
py='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python';env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(ROOT/'src')+':'+str(ROOT)}
for name,targetfile in [('scientific',OUT/'targets.yaml'),('technical',OUT/'technical-targets.yaml')]:
 argv=[py,'-B','scripts/record_review.py','inspect','--targets',str(targetfile)]
 for p in inputs+(['data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json'] if name=='scientific' else ['data/pathways/pyruvate-to-cytochrome-bd-oxidase-electron-transfer.yaml']):argv+=['--input',p]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True)
 (OUT/(name+'-inspect.json')).write_bytes(r.stdout);(OUT/(name+'-inspect.stderr')).write_bytes(r.stderr)
 (OUT/(name+'-inspect.execution.json')).write_text(json.dumps({'argv':argv,'cwd':str(ROOT),'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode},indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
 print(name,'inspected',len(targets) if name=='technical' else 1,'targets')
