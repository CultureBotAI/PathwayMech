"""Copy completed local evidence with lossless transport and exact path mapping."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/pathwaymech-next-234-local-20261012')
REL = Path('research/pathway_additions/2026-10-12-next-234/native-integration')
DEST = ROOT / REL
GATES = Path('/private/tmp/pathwaymech-next-234-local-native-execution-20261012')

def body_pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

assert json.loads((GATES / 'history-and-generation/completion.json').read_bytes())['status'] == 'phase_passed'
assert json.loads((GATES / 'network-resumption/completion.json').read_bytes())['status'] == 'phase_passed'
assert not DEST.exists()
groups = [
    (GATES, Path('gates')),
    (Path('/private/tmp/pathwaymech-next-234-root-static-visual-20261012'), Path('visual')),
    (Path('/private/tmp/pathwaymech-next-234-root-local-integration-review-20261012'), Path('root-review')),
    (Path('/private/tmp/pathwaymech-next-234-local-adoption-root-20261012'), Path('root-adoption')),
    (Path('/private/tmp/pathwaymech-next-234-local-baseline-20261012'), Path('baseline')),
]
sources = []
for source, target in groups:
    for p in sorted(source.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():
            sources.append((p, target / p.relative_to(source)))
sources += [
    (Path('/private/tmp/pathwaymech-next-234-root-local-adoption-acceptance-20261012.json'), Path('adoption-acceptance.json')),
    (Path('/private/tmp/pathwaymech-next-234-local-integration-final-verification-20261012.json'), Path('preparation-post-seal-verification.json')),
    (Path('/private/tmp/pathwaymech-next-234-resume-gates-20261012.py'), Path('network-resumption-runner.py')),
    (Path(__file__), Path('adopt-root-evidence.py')),
]
planned = []
for source, relative in sources:
    raw = source.read_bytes()
    compress = source.suffix in {'.py', '.stdout', '.stderr', '.svg'} or len(raw) > 100000 and source.suffix == '.json'
    body = gzip.compress(raw, mtime=0) if compress else raw
    relative = Path(str(relative) + '.gz') if compress else relative
    planned.append((source, relative, raw, body, compress))
assert len({str(x[1]) for x in planned}) == len(planned)
DEST.mkdir()
entries = []
for source, relative, raw, body, compressed in planned:
    p = DEST / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(body)
    stored = p.read_bytes()
    assert stored == body and (gzip.decompress(stored) if compressed else stored) == raw
    entries.append({'source': str(source), 'original': body_pin(raw), 'owner': str(REL / relative), 'encoding': 'gzip' if compressed else 'identity', 'stored': body_pin(stored)})
manifest = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'entries': entries, 'purpose': 'Lossless durable root execution/review evidence; paths inside unchanged originals are historical and resolve through this map.', 'hidden_and_ignored_files_included': True, 'public_publication': False}
with (DEST / 'root-storage-map.json').open('x') as f:
    json.dump(manifest, f, indent=2)
    f.write('\n')
readme = '''# Actual local integration evidence

Root adopted the separately reviewed complete PWY-7545 proposal against exact local THIO commit 8c871a5808c73b0f21a397a2561269d068ee7368. Native record and infrastructure histories preceded SSSOM export and page rendering.

All nine required gates passed: render, skills, strict validation, 3,705 tests (three skips and three dependency warnings), lint, KGX export, canonical vendored-file comparison, diff whitespace, and page freshness. The initial vendored attempt failed at sandbox DNS resolution. Its exact failed streams remain under gates/remaining-gates; gates/network-resumption contains the successful public-read retry and the two subsequent checks. Successful tests were not rerun for that network failure.

root-storage-map.json maps every retained external artifact to its durable repository owner and hashes both original and stored bytes. Compressed files are exact gzip transport, including historical Python helpers, streams and the SVG. The native gate receipts retain their actual external execution paths and times; those paths do not imply the temporary checkout is a publication artifact.

visual/ contains exact rendered SVG and PNG observations. The graph has 49 visual nodes and 69 arrows, with a complete evidence table. Dense junction labels remain a static readability limitation. No interactive browser test is claimed.

independent-qa/ is the separately reviewed preservation and native-review preparation packet. The original scientific review is retained by the parent dossier's portable evidence index; technical gates alone are not scientific validation. Native structured reviews are saved separately through scripts/record_review.py.

This is a local integration. Public push, PR and merge are not established by these receipts. No claim of source exhaustion or unrestricted redistribution is made.
'''
with (DEST / 'README.md').open('x') as f:
    f.write(readme)
print(json.dumps({'status': 'root_evidence_adopted', 'root': str(DEST), 'artifacts': len(entries), 'stored_bytes': sum(x['stored']['bytes'] for x in entries), 'storage_map': body_pin((DEST / 'root-storage-map.json').read_bytes())}))
