"""External preparation author: copy exact owners, package immutable evidence once."""

import gzip
import hashlib
import json
import os
import stat
import zipfile
from pathlib import Path

import common as c

OLD = Path("/private/tmp/pathwaymech-next-234-maintained-integration-preparation-20261012")
CANON = Path("/private/tmp/pathwaymech-next-234-canonical-preparation-20261012")
REPAIR = Path("/private/tmp/pathwaymech-next-234-reference-selection-repair-20261012")
BUILD = Path("/private/tmp/pathwaymech-next-234-reference-selection-build-20261012")
BASELINE = Path("/private/tmp/pathwaymech-next-234-local-baseline-20261012")
PAYLOAD = c.HERE / "payload"
DOSSIER = PAYLOAD / c.DOSSIER


def dump(path, obj):
    c.write_new(path, obj)


def copy(source, relative):
    target = PAYLOAD / c.relative(relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(c.regular_bytes(source))
    return c.pin(target)


def digest(body):
    return hashlib.sha256(body).hexdigest()


class Store:
    """Deduplicate lossless bodies; never recreate links, device nodes or FIFOs."""

    def __init__(self, baseline):
        self.lookup = {}
        self.members = {}
        self.existing = {}
        self.checked_archives = {}
        self.checked_existing = set()
        self.baseline = {x["path"]: x for x in baseline}
        for row in baseline:
            rel = row["path"]
            if (
                rel not in c.PRIMARY
                and not rel.startswith(("pages/", "output/"))
                and row["type"] == "regular"
            ):
                self.existing.setdefault(
                    row["sha256"],
                    {
                        "kind": "repository_file",
                        "repository_relative_path": rel,
                        "bytes": row["bytes"],
                        "sha256": row["sha256"],
                    },
                )
        amap = c.load(c.ROOT / "research/pathway_additions/2026-10-12-next-233/archive-map.json")
        for row in amap["archives"]:
            rel = row["repository_relative_path"]
            before = self.baseline[rel]
            c.verify(row["archive"], c.ROOT / rel)
            with zipfile.ZipFile(c.ROOT / rel) as z:
                names = z.namelist()
                if len(names) != len(set(names)):
                    raise ValueError("Duplicate baseline archive member")
                for info in z.infolist():
                    if info.filename.startswith("blobs/"):
                        sha = info.filename.removeprefix("blobs/")
                        if len(sha) != 64 or any(x not in "0123456789abcdef" for x in sha):
                            raise ValueError("Invalid existing CAS member")
                        self.existing.setdefault(
                            sha,
                            {
                                "kind": "repository_zip_member",
                                "repository_relative_path": rel,
                                "archive_bytes": before["bytes"],
                                "archive_sha256": before["sha256"],
                                "member": info.filename,
                                "bytes": info.file_size,
                                "sha256": sha,
                            },
                        )
        (DOSSIER / "archives").mkdir(parents=True)
        self.archive_rel = c.DOSSIER + "/archives/evidence-bodies.zip"
        self.archive = zipfile.ZipFile(
            PAYLOAD / self.archive_rel, "x", zipfile.ZIP_DEFLATED, compresslevel=9
        )

    def put(self, body):
        sha = digest(body)
        if sha in self.lookup:
            assert self.lookup[sha]["bytes"] == len(body)
            return sha
        if sha in self.existing:
            loc = self.existing[sha]
            if loc["kind"] == "repository_file":
                got = c.regular_bytes(c.ROOT / loc["repository_relative_path"])
            else:
                p = c.ROOT / loc["repository_relative_path"]
                with zipfile.ZipFile(p) as z:
                    got = z.read(loc["member"])
            if got != body:
                raise ValueError("Existing durable body differs")
            self.checked_existing.add(sha)
        else:
            member = "blobs/" + sha
            info = zipfile.ZipInfo(member, (2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            self.archive.writestr(info, body)
            loc = {
                "kind": "repository_zip_member",
                "repository_relative_path": self.archive_rel,
                "member": member,
                "bytes": len(body),
                "sha256": sha,
            }
            self.members[sha] = len(body)
        self.lookup[sha] = loc
        return sha

    def owner(self, path, expected=None):
        path = Path(path)
        mode = path.lstat().st_mode
        row = {"historical_path": str(path)}
        if stat.S_ISLNK(mode):
            row.update(type="symlink", link_text=os.readlink(path))
            try:
                resolved = path.resolve(strict=True)
            except OSError:
                row["resolution"] = "unresolved_literal_link_retained"
                return row
            row["resolved_path"] = str(resolved)
            if resolved.is_dir():
                row["resolution"] = "directory_alias_inert_not_recursively_followed"
                return row
            if not stat.S_ISREG(resolved.lstat().st_mode):
                row["resolution"] = "special_target_not_opened"
                return row
        elif stat.S_ISREG(mode):
            row.update(type="regular", executable=bool(mode & 0o111))
            resolved = path.resolve(strict=True)
        else:
            return {
                **row,
                "type": "special",
                "mode": stat.S_IFMT(mode),
                "device": path.lstat().st_rdev,
            }
        body = c.regular_bytes(resolved)
        if expected is not None:
            if (len(body), digest(body)) != (expected["bytes"], expected["sha256"]):
                raise ValueError(f"Changed expected source body: {path}")
            if "file_type" in expected and expected["file_type"] != row["type"]:
                raise ValueError(f"Changed expected source type: {path}")
            for key in ("link_text", "resolved_path"):
                actual = (
                    os.readlink(path)
                    if key == "link_text" and path.is_symlink()
                    else (None if key == "link_text" else str(resolved))
                )
                if key in expected and expected[key] != actual:
                    raise ValueError(f"Changed source identity {key}: {path}")
        row.update(bytes=len(body), sha256=self.put(body))
        return row

    def census(self, root):
        rows = []
        for base, dirs, files in os.walk(root, followlinks=False):
            dirs.sort()
            files.sort()
            for name in dirs + files:
                p = Path(base) / name
                if stat.S_ISDIR(p.lstat().st_mode):
                    row = {"type": "directory"}
                else:
                    row = self.owner(p)
                rows.append({"relative_path": p.relative_to(root).as_posix(), **row})
        return rows

    def packet(self, spec):
        root = Path(spec["source_directory"])
        rows = self.census(root)
        declared = []
        if "handoff" in spec:
            c.verify(spec["handoff"])
            c.verify(spec["manifest"])
            manifest = c.load(spec["manifest"]["path"])
            artifacts = manifest["artifacts"]
            names = set()
            for item in artifacts:
                name = item.get("relative_path")
                if name is None:
                    p = Path(item["path"])
                    name = p.relative_to(root).as_posix() if p.is_absolute() else p.as_posix()
                name = str(c.relative(name))
                if name in names:
                    raise ValueError("Duplicate declared artifact")
                names.add(name)
                declared.append({"relative_path": name, **self.owner(root / name, item)})
            # Physical aliases may have fewer paths than a sealed followed-view inventory.
            file_names = {
                x["relative_path"]
                for x in rows
                if x["type"] != "directory"
                and x.get("resolution") != "directory_alias_inert_not_recursively_followed"
            }
            if not file_names <= names | {
                Path(spec["handoff"]["path"]).name,
                Path(spec["manifest"]["path"]).name,
            }:
                raise ValueError(f"Undeclared physical packet file in {root}")
        return {
            "historical_root": str(root),
            "role": spec["role"],
            "physical_hidden_ignored_no_follow_inventory": rows,
            "sealed_declared_file_views": declared,
            "historical_seals": {k: spec[k] for k in ("handoff", "manifest") if k in spec},
        }

    def close(self):
        self.archive.close()
        bound = c.pin(PAYLOAD / self.archive_rel)
        for loc in self.lookup.values():
            if loc.get("repository_relative_path") == self.archive_rel:
                loc.update(archive_bytes=bound["bytes"], archive_sha256=bound["sha256"])
        return {
            "format": "lossless-content-addressed-evidence-v1",
            "bodies": self.lookup,
            "new_archive": {**bound, "repository_relative_path": self.archive_rel},
            "unique_bodies": len(self.lookup),
            "new_bodies": len(self.members),
            "unchanged_baseline_bodies_reused": len(self.checked_existing),
        }


def main():
    baseline = c.load(BASELINE / "files.json")
    c.verify(
        {
            "path": str(BASELINE / "files.json"),
            "bytes": 3063380,
            "sha256": "af0008cbe3e9c24ef7acdec78b1074bf2b545e6b4c2690dd832170a645e8389f",
        }
    )
    c.git_check(True)
    actual, dirs = c.inventory(c.ROOT, exclude_git=True)
    if actual != baseline:
        raise ValueError("Fresh local baseline differs from root capture")
    for source, name in (
        (BASELINE / "files.json", "baseline-files.json"),
        (BASELINE / "receipt.json", "baseline-receipt.json"),
    ):
        (c.HERE / name).write_bytes(c.regular_bytes(source))
    dump(c.HERE / "baseline-directories.json", dirs)
    closure = c.load(CANON / "source-closure.json")
    dump(c.HERE / "cache-baseline.json", closure["shared_cache"])
    c.cache_check()
    owners = c.load(OLD / "provisional-owner-map.json")
    for row in owners["runtime"]:
        c.verify(row["candidate"])
        rel = row["relative_path"]
        if row["disposition"] == "unchanged":
            c.verify(row["candidate"], c.ROOT / rel)
        else:
            copy(row["candidate"]["path"], rel)
    for row in owners["corpus"]:
        c.verify(row["candidate"])
        rel = "data/pathways/" + row["relative_path"]
        if row["disposition"] == "unchanged":
            c.verify(row["candidate"], c.ROOT / rel)
        else:
            copy(row["candidate"]["path"], rel)
    for name, sha in [
        ("sources", "7a52c5e586c508b17e82b716d97514f867e1461f7d92f5f82375b71a23b88cde"),
        ("ontology", "d6835d49b48fa61e675aa0c134b28ad9377270da1098fdf781667b7706588b69"),
    ]:
        p = BUILD / (name + ".json")
        assert c.pin(p)["sha256"] == sha
        copy(p, f"data/identifier_authorities/{name}.json")
    before = {x["path"]: x for x in baseline}
    for path in PAYLOAD.rglob("*"):
        if path.is_file():
            rel = path.relative_to(PAYLOAD).as_posix()
            path.chmod(0o755 if before.get(rel, {}).get("executable") else 0o644)
    evidence = c.load(OLD / "evidence-owner-plan.json")
    store = Store(baseline)
    packets = []
    for spec in evidence["packets"]:
        print("Preserving", Path(spec["source_directory"]).name, flush=True)
        packets.append(store.packet(spec))
    # Exact failed attempt remains failed; root had bound this full inventory before repair.
    failed = c.load(REPAIR / "initial-intake.json")["failed_output_files"]
    for row in failed:
        store.owner(row["path"], row)
    extras = [
        "reference-selection-output-review",
        "root-native-execution",
        "root-native-failure",
        "root-reference-repair-execution",
        "review-issues",
        "cydb-citation-issue",
        "output-preservation-issue",
        "maintained-integration-preparation",
    ]
    for suffix in extras:
        root = Path("/private/tmp/pathwaymech-next-234-" + suffix + "-20261012")
        packets.append(
            store.packet(
                {
                    "source_directory": str(root),
                    "role": "Actual accepted review/execution/issue or historical mapping evidence",
                }
            )
        )
    thio = Path("/private/tmp/pathwaymech-next-233-pr-adversarial-20261012")
    packets.append(
        store.packet(
            {
                "source_directory": str(thio),
                "role": "Exact committed THIO baseline independent adversarial review",
            }
        )
    )
    standalone = []
    accepted = list(evidence["root_acceptance_owners"])
    for path in [
        Path("/private/tmp/pathwaymech-next-234-root-actual-native-acceptance-20261012.json"),
        Path("/private/tmp/pathwaymech-next-234-root-actual-output-read-20261012.json"),
        BASELINE / "receipt.json",
        BASELINE / "files.json",
    ]:
        accepted.append(c.pin(path))
    for row in accepted:
        standalone.append(store.owner(row["path"], row))
    for p in sorted(
        Path("/private/tmp").glob("pathwaymech-next-234-obsolete-reference-issue*-20261012.*")
    ):
        standalone.append(store.owner(p))
    originals = {}
    for key in (
        "manifest_originals",
        "whole_reference_originals",
        "bibliographic_originals",
        "prior_reference_originals",
        "retired_originals_retained",
    ):
        values = closure[key]
        values = list(values.values()) if isinstance(values, dict) else values
        rows = []
        for row in values:
            original = row.get("old_whole_original", row)
            if "path" not in original:
                raise ValueError(f"Unrecognized original: {key} {row}")
            rows.append(
                {
                    "original_metadata": original,
                    "source_context": row,
                    "portable_body": store.owner(original["path"], original),
                }
            )
        originals[key] = rows
    index = store.close()
    inventory = {
        "format": index["format"],
        "packet_inventories": packets,
        "standalone_owners": standalone,
        "original_groups": originals,
        "body_lookup": index["bodies"],
        "active_external_path_dependencies": False,
        "links_and_specials": (
            "Inert metadata only; resolve file bodies through body_lookup, nev"
            "er recreate links or special objects"
        ),
        "historical_failures": "All original status/receipts retained; no failed attempt promoted",
    }
    inventory_bytes = (
        json.dumps(inventory, sort_keys=True, ensure_ascii=False, indent=2).encode() + b"\n"
    )
    (DOSSIER / "evidence-index.json.gz").write_bytes(gzip.compress(inventory_bytes, mtime=0))
    index.pop("bodies")
    dump(
        c.HERE / "packaging-summary.json",
        {
            **index,
            "packets": len(packets),
            "inventory_uncompressed_bytes": len(inventory_bytes),
            "original_group_counts": {k: len(v) for k, v in originals.items()},
            "physical_regular_files": sum(
                sum(
                    x["type"] == "regular" for x in p["physical_hidden_ignored_no_follow_inventory"]
                )
                for p in packets
            ),
            "sealed_declared_file_views": sum(
                len(p["sealed_declared_file_views"]) for p in packets
            ),
        },
    )
    dump(c.HERE / "accepted-inputs.json", accepted + [c.pin(thio / "handoff.json")])
    # Final recheck of author/source inputs is separate from the future maintained gates.
    if c.inventory(c.ROOT, exclude_git=True) != (baseline, dirs):
        raise ValueError("Local checkout changed during preparation")
    c.cache_check()
    print("Payload and lossless evidence complete; no maintained writes", flush=True)


if __name__ == "__main__":
    main()
