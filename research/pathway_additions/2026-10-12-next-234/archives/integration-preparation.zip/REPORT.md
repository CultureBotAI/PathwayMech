# PWY-7545 local integration preparation

This packet prepares an exact, reversible local adoption of the complete accepted
pyruvate to cytochrome bd-I oxidase electron-transfer record. It does not adopt
maintained files, run maintained builders or gates, save history or native review,
change the shared source cache, or mutate Git/GitHub. Root independent review and
exact acceptance remain required before execution.

The target is `/private/tmp/pathwaymech-next-234-local-20261012`, branch
`feat/pathway-next-234-local-20261012`, commit
`8c871a5808c73b0f21a397a2561269d068ee7368`, tree
`9e89d6330371d2d2834fec966af7e3e3edc35dca`. This is the reviewed local THIO
commit, not merged main. The earlier maintained-preparation assumption requiring
the THIO merge has been superseded by root only for local preparation/adoption.
No public publication approval is implied.

## Exact maintained owners

The plan contains precisely 17 primary owners: the 14 independently accepted
runtime/configuration/documentation/test changes, the complete scientific YAML,
and the two actual native authority snapshots. It additionally contains only
files within `research/pathway_additions/2026-10-12-next-234`.

The scientific YAML remains 138,031 bytes with SHA256
`0c5854f77ff0cf86215d7b8f1aa53cadec53bb7df673efd7cb7e2407c0f07f80`:
44 paragraphs, 69 edges, 49 named identities and 115 reference entries. The
scientific acceptance is inherited; this preparation is not a fresh scientific
review. Source access limits and conflicts remain in their original records.

Actual native sources remain SHA256
`7a52c5e586c508b17e82b716d97514f867e1461f7d92f5f82375b71a23b88cde`;
actual native ontology remains SHA256
`d6835d49b48fa61e675aa0c134b28ad9377270da1098fdf781667b7706588b69`.
The accepted actual ontology serialization is preserved, without replacing it by
the earlier semantically matching proposal. Source authorities have 2,565 terms
and 654 source owners; ontology has 1,999 terms and five source owners. The
existing manifest prefix of 814 rows remains exact within the 831-row result.

`semantic-preservation.json` records the complete prior native authority
objects, nested order and relative order; the 234 old records; 112 native review
YAMLs; 396 history YAMLs; and old KGX rows/context multiplicities. It preserves
all 11,734 old edges and all 7,828 old source contexts. The accepted native KGX
result has 4,217 nodes and 11,803 edges. The 17 added contexts on existing nodes
belong to PWY-7545. CHEBI:7896 has the separately accepted category change; there
is no wider category exception. These are comparisons to the accepted external
native output, not claims that maintained KGX has been regenerated.

## Portable evidence

The compressed evidence index records all 25 historical packets, including
9,681 physical regular files, 11,483 sealed declared file views, literal link
metadata and whole original body bindings. It resolves 3,320 unique bodies
totalling 364,732,189 decoded bytes. Exactly 1,030 bodies reuse committed THIO
owners and 2,290 occur in the new lossless content-addressed archive.

The original new ZIP is exactly 161,829,755 bytes, SHA256
`e1fd5da0ac984875dde043fad793c7373219148840e60104dd02ffabfaccae31`.
It is represented by five ordered parts of at most 33,554,432 bytes. The original
bytes are reconstructed in memory and hash-checked before ZIP interpretation.
The archive is a compression/deduplication representation only. It is not a
license decision or public-payload approval.

The final portable replay must retrieve every whole body from payload or
unchanged repository owners alone: no original `/private/tmp` source reads, no
extraction, and no recreation of links/FIFOs/device nodes. The index includes
828 manifest originals, 115 whole reference originals, 28 bibliography originals,
116 prior reference originals and two retired originals. Counts refer to source
bindings and may share content. Literal historical paths and link destinations
remain provenance metadata; they are not portable resolver instructions.

Failed original native extraction remains failed and issue #494's later repair
and successful native output remain separate. Both interrupted preparation
attempts, raw partial ZIP working copies, original helper versions and streams
are retained in this external sealed packet. The durable preparation archive
carries their streams, code, inventories and exact workcopy ZIP hashes. It does
not duplicate the two raw failed packaging ZIPs; these are working copies, not
unique scientific evidence owners. The complete source/evidence retrieval is
independent of those raw failed workcopies.

## Guarded local execution

`adopt.py --check-inputs` is read-only and creates no outputs. It requires the
closed preparation manifest, exact 17-owner scope plus dossier, exact baseline
commit/tree/branch, all 11,283 old files (including hidden/ignored files), empty
directories, types/modes, all accepted inputs, all destination before states and
the unchanged 800-entry cache including literal symlink identity.

`--execute` additionally requires an exact root acceptance binding this handoff
and the independent review. All payload bytes are preloaded and checked before
the first target write. Writes use exclusive sibling temporary files and atomic
replacement. A failure after the first write is recorded as a partial state with
completed destinations; it is never reported as success or silently rolled back.
The complete post-adoption inventory, cache, acceptance and preparation seals are
rechecked. Execution is intentionally separate from all later native stages.

The 42 isolated controls cover scope, baseline, path/type/mode/link identity,
same-byte cache retargeting, root acceptance, prewrite rejection, synthetic
roundtrip, explicit postwrite failure, portable ordered parts, corruption,
duplicate parts, linked parts, unsafe members, unresolved bodies and extra ZIP
members. Exact streams and exit codes are retained. These controls are not the
maintained test suite or independent reviewer acceptance.

## Root-owned next stages

Root must review final helper/payload bytes, accept the exact handoff, and then
execute local adoption. Native history must precede the first render; every
history command passes `--actor-name codex`. `stages.json` specifies concrete
history commands and the nine fresh maintained gates.

Root identified a missing SSSOM prerequisite during preparation review. Both
original stage contracts are retained; the successor now requires native
`export_sssom_main()` after history and before render/tests and permits
`output/sssom/source_mappings.sssom.tsv`. Preserve every old mapping row and cell,
including multiplicity; only the exact new PWY-7545 record mappings may be added.
This corrects the preparation plan without a duplicate issue or intentional
reproduction of the known #496 stale-output failure.

After the maintained gates, root must inspect the actual page/graph, save the
native integrator review with inherited independent scientific review named,
verify complete preservation, and perform a fresh final adversarial review.
Publication still requires its existing approval and actual merged-main
comparison. Source exhaustion remains false.

## Actual preparation deviations

The earlier explicit `py_compile` command wrote external bytecode despite `-B`;
its exact bytes remain in `retained-explicit-compile.pyc.gz`, with its original
hash/size and deviation receipt. No bytecode was added to the maintained target.

The finishing author's first lint command scanned the whole external directory
using inherited temporary-directory configuration and reported 23 errors,
including on unchanged accepted payload code. That failed stream/receipt is
preserved. Helper-only lint then used the exact target repository configuration;
its first attempt found one long line in the new finishing helper, corrected in
the successor. No accepted runtime bytes were modified by those lint commands.
The final configured helper check and final portable replay have separate exact
receipts in `final-helper-verification.json`. Initial shell inspections using
the wrong directory or prohibited `ps`, and the expired process handle check,
did not mutate files or establish source availability/absence.
