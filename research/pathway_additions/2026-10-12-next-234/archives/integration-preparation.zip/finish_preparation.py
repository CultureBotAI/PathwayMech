"""Complete the external author packet without adopting or invoking maintained gates."""

import datetime
import gzip
import json
import os
import subprocess
import zipfile

import common as c

PYTHON = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
DOSSIER = c.HERE / "payload" / c.DOSSIER
ENV = {
    **os.environ,
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONNOUSERSITE": "1",
    "UV_NO_SYNC": "1",
    "PYTHONPATH": str(c.HERE),
}


def check(name, arguments):
    before = datetime.datetime.now(datetime.UTC).isoformat()
    result = subprocess.run(arguments, cwd=c.HERE, env=ENV, capture_output=True, check=False)
    stdout, stderr = c.HERE / f"{name}.stdout", c.HERE / f"{name}.stderr"
    for path, body in ((stdout, result.stdout), (stderr, result.stderr)):
        with path.open("xb") as out:
            out.write(body)
    receipt = {
        "argv": arguments,
        "cwd": str(c.HERE),
        "environment": {
            key: ENV[key]
            for key in (
                "PYTHONDONTWRITEBYTECODE",
                "PYTHONNOUSERSITE",
                "UV_NO_SYNC",
                "PYTHONPATH",
            )
        },
        "started_utc": before,
        "finished_utc": datetime.datetime.now(datetime.UTC).isoformat(),
        "exit_code": result.returncode,
        "stdout": c.pin(stdout),
        "stderr": c.pin(stderr),
    }
    c.write_new(c.HERE / f"{name}.receipt.json", receipt)
    if result.returncode:
        raise RuntimeError(f"Failed external check {name}; exact receipt retained")
    return receipt


def correct_stages():
    old = []
    for name in ("future-stage-contract.json", "stages.json"):
        path = c.HERE / name
        before = c.regular_bytes(path)
        backup = c.HERE / (name + ".before-sssom-correction")
        with backup.open("xb") as out:
            out.write(before)
        old.append(c.pin(backup))
        stages = json.loads(before)
        stages["before_first_render_after_history"] = [
            {
                "name": "sssom",
                "argv": [
                    PYTHON,
                    "-B",
                    "-c",
                    (
                        "from pathwaymech.cli import export_sssom_main; "
                        "raise SystemExit(export_sssom_main())"
                    ),
                ],
                "reason": (
                    "New record source_mappings requires native SSSOM refresh "
                    "before freshness tests."
                ),
                "preservation": (
                    "Keep the complete old SSSOM header and all old row cells/multiplicities; "
                    "additional rows must be exactly the new MetaCyc:PWY-7545 record mappings."
                ),
            }
        ]
        stages["allowed_generated_paths"].append("output/sssom/source_mappings.sssom.tsv")
        stages["after_gates"].append(
            "SSSOM: preserve every old row/cell/multiplicity; only exact PWY-7545 mappings added"
        )
        path.write_text(json.dumps(stages, ensure_ascii=False, indent=2) + "\n")
    c.write_new(
        c.HERE / "sssom-preparation-correction.json",
        {
            "status": "root_review_finding_addressed_in_future_stage_plan_only",
            "reported_by": "Codex /root",
            "finding": (
                "Native SSSOM export and its output allowance were omitted from the future stages."
            ),
            "cause": (
                "The new record has source_mappings and the suite checks the committed output."
            ),
            "evidence": [
                c.pin(c.ROOT / p)
                for p in (
                    "src/pathwaymech/cli.py",
                    "tests/test_sssom_export.py",
                    "output/sssom/source_mappings.sssom.tsv",
                )
            ],
            "draft": c.pin(
                DOSSIER.parents[2]
                / "data/pathways/pyruvate-to-cytochrome-bd-oxidase-electron-transfer.yaml"
            ),
            "prior_stage_contracts_retained": old,
            "native_export_or_tests_executed": False,
            "duplicate_issue_created": False,
            "prior_related_issue": "https://github.com/CultureBotAI/PathwayMech/issues/496",
        },
    )


def controls():
    guards = c.load(c.HERE / "final-guard-tests.receipt.json")
    assert guards["exit_code"] == 0
    c.verify(guards["stdout"])
    c.verify(guards["stderr"])
    checks = [guards]
    checks.append(
        check(
            "final-helper-lint-configured-v2",
            [
                PYTHON,
                "-B",
                "-m",
                "ruff",
                "check",
                "--no-cache",
                "--config",
                str(c.ROOT / "pyproject.toml"),
                "common.py",
                "adopt.py",
                "verify_portable.py",
                "test_controls.py",
                "prepare_payload.py",
                "prepare_plan.py",
                "split_archive.py",
                "finish_preparation.py",
            ],
        )
    )
    checks.append(check("final-portable-retrieval", [PYTHON, "-B", "verify_portable.py"]))
    c.write_new(
        c.HERE / "final-helper-verification.json",
        {
            "status": "external_preparation_checks_passed_not_maintained_gates",
            "checks": checks,
            "maintained_files_written": False,
            "shared_cache_written": False,
            "native_history_review_or_builders_called": False,
            "git_or_github_mutation": False,
        },
    )


def package():
    # Failed partial packaging worktrees remain locally complete. Their raw ZIPs
    # are working copies, not source owners: all required source originals have
    # already passed the closed evidence-index retrieval. Preserve their exact
    # local pins and all failure streams durably without duplicating 171 MB.
    omitted = []
    selected = []
    for row in c.inventory(c.HERE)[0]:
        rel = row["path"]
        if rel.startswith("payload/"):
            continue
        if rel.endswith("partial-payload.zip"):
            omitted.append({**row, "historical_path": str(c.HERE / rel)})
        else:
            selected.append(rel)
    c.write_new(
        c.HERE / "failed-packaging-workcopy-retention.json",
        {
            "status": "all_failed_workcopies_retained_locally_and_hash_bound",
            "workcopies": omitted,
            "durable_policy": (
                "Failure streams, old code, and inventories are in the preparation archive. "
                "Both failed packaging ZIP working copies remain complete in the external sealed "
                "packet. They are not unique scientific/source owners. The independent portable "
                "retrieval covers every required whole source and historical evidence owner."
            ),
        },
    )
    selected.append("failed-packaging-workcopy-retention.json")
    archive = DOSSIER / "archives/integration-preparation.zip"
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in sorted(selected):
            info = zipfile.ZipInfo(rel, (2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, c.regular_bytes(c.HERE / rel))
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == len(selected)
        for rel in selected:
            assert z.read(rel) == c.regular_bytes(c.HERE / rel)
    for name in ("common.py", "verify_portable.py"):
        with (DOSSIER / (name + ".gz")).open("xb") as out:
            out.write(gzip.compress(c.regular_bytes(c.HERE / name), mtime=0))
    archive_pin = c.pin(archive)
    c.write_new(
        c.HERE / "preparation-archive-proof.json",
        {
            "archive": archive_pin,
            "members": [dict(c.pin(c.HERE / rel), archive_member=rel) for rel in sorted(selected)],
            "all_member_bytes_retrieved_and_equal": True,
            "failed_workcopy_zip_omissions_explicit": omitted,
            "plan_and_seals_not_recursive_archive_members": True,
        },
    )
    c.write_new(
        DOSSIER / "integration-preparation.json",
        {
            "status": "local_preparation_only_no_adoption_history_gates_or_publication",
            "archive": {
                **archive_pin,
                "repository_relative_path": archive.relative_to(c.HERE / "payload").as_posix(),
            },
            "archive_member_count": len(selected),
            "baseline_commit": c.BASE,
            "baseline_tree": c.TREE,
            "target_branch": c.BRANCH,
            "local_only": True,
            "shared_cache_mutation": False,
            "publication_authorized": False,
            "future_stages_archive_member": "stages.json",
            "preparation_checks_archive_member": "final-helper-verification.json",
            "source_evidence_index": "evidence-index.json.gz",
            "remaining": [
                "independent root review and acceptance",
                "local adoption",
                "native history before render",
                "native SSSOM export",
                "maintained gates",
                "page QA",
                "native saved review",
                "publication",
            ],
        },
    )


def plan():
    baseline = {x["path"]: x for x in c.load(c.HERE / "baseline-files.json")}
    changes = []
    for row in c.inventory(c.HERE / "payload")[0]:
        if row["type"] != "regular":
            raise ValueError("Only regular payload owners permitted")
        rel = row["path"]
        changes.append(
            {
                "destination": rel,
                "before": baseline.get(rel),
                "executable": row["executable"],
                "payload": c.pin(c.HERE / "payload" / rel),
            }
        )
    out = {
        "status": "exact_local_adoption_plan_pending_independent_root_acceptance",
        "target": str(c.ROOT),
        "baseline_commit": c.BASE,
        "baseline_tree": c.TREE,
        "branch": c.BRANCH,
        "local_only": True,
        "publication_authorized": False,
        "shared_cache_mutation": False,
        "accepted_inputs": c.load(c.HERE / "accepted-inputs.json"),
        "changes": changes,
        "history_before_first_render": True,
        "future_stages": c.pin(c.HERE / "stages.json"),
    }
    c.scope_check(out)
    c.checkout_check(out)
    c.cache_check()
    for row in out["accepted_inputs"]:
        c.verify(row)
    for row in changes:
        c.destination_check(row)
    c.write_new(c.HERE / "plan.json", out)
    c.write_new(
        c.HERE / "final-plan-preflight.json",
        {
            "status": "exact_full_baseline_payload_accepted_inputs_and_cache_verified_no_writes",
            "plan": c.pin(c.HERE / "plan.json"),
            "change_count": len(changes),
            "primary_owners": len(c.PRIMARY),
            "new_dossier_owners": len(changes) - len(c.PRIMARY),
            "old_file_count": len(baseline),
            "hidden_ignored_files_and_empty_directories_included": True,
            "shared_cache_entries": len(c.load(c.HERE / "cache-baseline.json")),
            "local_only": True,
        },
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("step", choices=("correct-stages", "controls", "package", "plan"))
    args = parser.parse_args()
    {
        "correct-stages": correct_stages,
        "controls": controls,
        "package": package,
        "plan": plan,
    }[args.step]()
