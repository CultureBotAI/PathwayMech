"""Bind concrete local-only operations and independently replay baseline preservation."""

import csv
import io
import json
from collections import Counter
from pathlib import Path

import common as c

OLD = Path("/private/tmp/pathwaymech-next-234-maintained-integration-preparation-20261012")
BUILD = Path("/private/tmp/pathwaymech-next-234-reference-selection-build-20261012")
PAYLOAD = c.HERE / "payload"
DOSSIER = PAYLOAD / c.DOSSIER
PYTHON = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"


def rows(path):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(path).decode()), delimiter="\t"))


def stable(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def main():
    exact = {
        "/private/tmp/pathwaymech-next-234-root-actual-native-acceptance-20261012.json": (
            "aae7f282180ca7d4fb701e56781e17fe9f64abac5c12ac5bce08a595278b8381"
        ),
        "/private/tmp/pathwaymech-next-233-pr-adversarial-20261012/handoff.json": (
            "bdc57d212f525af5a08c48d1f0e79991591d36b9f5266c3544e76e52c429cd45"
        ),
        "/private/tmp/pathwaymech-next-234-local-baseline-20261012/receipt.json": (
            "f81fcee339772aab7f67ce986688f54af8695a26f1810fd83a66a1d3dc688560"
        ),
    }
    for path, sha in exact.items():
        assert c.pin(path)["sha256"] == sha
    baseline = c.load(c.HERE / "baseline-files.json")
    owners = c.load(OLD / "provisional-owner-map.json")
    native = {}
    for name in ("sources", "ontology"):
        rel = f"data/identifier_authorities/{name}.json"
        before, after = c.load(c.ROOT / rel), c.load(PAYLOAD / rel)
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [x for x in new if x in old] == list(old)
                for identity in old:
                    assert stable(old[identity]) == stable(new[identity]), (name, key, identity)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added_keys": [x for x in new if x not in old],
                    "old_objects_and_nested_key_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(PAYLOAD / rel),
            "old_top_and_member_order_preserved": True,
            "sections": sections,
        }
    old_manifest = c.load(c.ROOT / "conf/identifier_sources.json")
    new_manifest = c.load(PAYLOAD / "conf/identifier_sources.json")
    assert new_manifest[: len(old_manifest)] == old_manifest
    before_nodes = rows(c.ROOT / "output/kgx/nodes.tsv")
    after_nodes = rows(BUILD / "actual-kgx/nodes.tsv")
    before_edges = rows(c.ROOT / "output/kgx/edges.tsv")
    after_edges = rows(BUILD / "actual-kgx/edges.tsv")
    old_edges = Counter(stable(x) for x in before_edges)
    new_edges = Counter(stable(x) for x in after_edges)
    assert not old_edges - new_edges
    old_nodes = {x["id"]: x for x in before_nodes}
    new_nodes = {x["id"]: x for x in after_nodes}
    category = c.load(OLD / "authority-config-KGX-map.json")["KGX"]["exact_CHEBI7896_node_change"]
    node_changes = []
    contexts_before = contexts_added = 0
    for identity, old in old_nodes.items():
        new = new_nodes[identity]
        if old != new:
            node_changes.append({"id": identity, "before": old, "after": new})
        for key in old:
            if key == "source_contexts":
                old_context = Counter(stable(x) for x in json.loads(old[key]))
                new_context = Counter(stable(x) for x in json.loads(new[key]))
                assert not old_context - new_context
                contexts_before += sum(old_context.values())
                contexts_added += sum((new_context - old_context).values())
                for value in new_context - old_context:
                    assert json.loads(value)["record_id"] == "MetaCyc:PWY-7545"
            elif identity == "CHEBI:7896":
                assert old == category["before"] and new == category["after"]
            else:
                assert old[key] == new[key], (identity, key)
    semantic = {
        "status": "exact_local_committed_baseline_and_accepted_native_delta_replayed",
        "local_only": True,
        "baseline_commit": c.BASE,
        "baseline_tree": c.TREE,
        "old_files": len(baseline),
        "old_records": len(list((c.ROOT / "data/pathways").glob("*.yaml"))),
        "old_review_yaml": len(list((c.ROOT / "reviews").rglob("*.yaml"))),
        "old_history_yaml": len(list((c.ROOT / "history").rglob("*.yaml"))),
        "runtime_owners": owners["runtime_count"],
        "runtime_changes": owners["expected_change_paths"],
        "old_runtime_other_owners_unchanged": True,
        "corpus_mapping": owners["corpus"],
        "native_authorities": native,
        "manifest_old_rows": len(old_manifest),
        "manifest_new_rows": len(new_manifest),
        "old_manifest_prefix_exact": True,
        "old_KGX": {
            "nodes": len(before_nodes),
            "edges": len(before_edges),
            "contexts": contexts_before,
        },
        "accepted_after_KGX": {"nodes": len(after_nodes), "edges": len(after_edges)},
        "all_old_edges_and_context_multiplicities_preserved": True,
        "old_node_changes": node_changes,
        "existing_node_added_contexts": contexts_added,
        "exact_category_exception": category,
        "category_acceptance": c.pin(
            "/private/tmp/pathwaymech-next-234-root-CHEBI7896-classification-acceptance-20261012.json"
        ),
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / n) for n in ("nodes.tsv", "edges.tsv")],
        "root_actual_native_acceptance": c.pin(next(iter(exact))),
        "actual_main_merge_or_publication_claimed": False,
    }
    c.write_new(c.HERE / "semantic-preservation.json", semantic)
    # This readable dossier decision supersedes only the old local-preparation merge prerequisite.
    c.write_new(
        DOSSIER / "local-integration-decision.json",
        {
            "role": "integration author; independent review/root adoption remain separate",
            "baseline_commit": c.BASE,
            "baseline_tree": c.TREE,
            "baseline_kind": "reviewed committed THIO branch, not merged main",
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "accepted_pathway_sha256": (
                "0c5854f77ff0cf86215d7b8f1aa53cadec53bb7df673efd7cb7e2407c0f07f80"
            ),
            "accepted_native_sources_sha256": native["sources"]["actual_after"]["sha256"],
            "accepted_native_ontology_sha256": native["ontology"]["actual_after"]["sha256"],
            "prior_requirements": c.pin(OLD / "REQUIREMENTS.md"),
            "supersession": (
                "Actual THIO merged-main prerequisite superseded only for this loc"
                "al reversible adoption. Historical documents remain unchanged. Ac"
                "tual merged-main refresh and public-payload approval remain prere"
                "quisites to any future publication."
            ),
            "portable_evidence": (
                "evidence-index.json.gz resolves every body through committed repo"
                "sitory files or exact ordered archive parts; historical /private/"
                "tmp paths are provenance, not live dependencies."
            ),
            "source_cache": (
                "All 800 cache identities preserved; 16 new originals are durable "
                "evidence only. No shared-cache copy is part of this adoption."
            ),
            "scientific_scope": (
                "Full accepted 44 paragraphs, 69 edges, 49 named identities and 11"
                "5 references; original source-access limits, conflicts and failed"
                " attempts retained."
            ),
            "remaining": [
                "independent helper review",
                "root exact approval",
                "local adoption",
                "native histories before render",
                "nine fresh maintained gates",
                "page/graph QA",
                "native saved integrator review with inherited independent science",
                "complete final preservation",
                "future merged-main and public-payload approval",
            ],
        },
    )
    stages = c.load(c.HERE / "future-stage-contract.json")
    c.write_new(c.HERE / "stages.json", stages)
    c.write_new(
        c.HERE / "failed-attempt-preservation.json",
        {
            "status": "historical_failed_native_attempt_retained_without_promotion",
            "failed_root": "/private/tmp/pathwaymech-next-234-canonical-build-20261012",
            "source_builder": "passed",
            "ontology_builder": "failed RHEA:29170 citation selection",
            "issue": "https://github.com/CultureBotAI/PathwayMech/issues/494",
            "later_success_is_distinct": str(BUILD),
            "lossless_inventory": "evidence-index.json.gz packet inventory",
        },
    )
    print("Semantic/local decision/stages written; plan waits final dossier helper archive")


if __name__ == "__main__":
    main()
