"""Read-only clean-target baseline capture and accepted external payload copies."""

import datetime
from pathlib import Path

import common as c

H = c.HERE
BUILD = Path('/private/tmp/pathwaymech-next-236-canonical-build-20261012')
PRE = Path('/private/tmp/pathwaymech-next-236-canonical-preparation-20261012')
OLD = Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
ACCEPT = Path('/private/tmp/pathwaymech-next-236-root-canonical-output-acceptance-20261012.json')


def main():
    assert c.pin(ACCEPT)['sha256'] == '94be6e5df1c8fee0b2dfd2e31a74eea213d2903c84835a518124ca79ef567ec7'
    accepted = c.load(ACCEPT)
    c.verify(accepted['actual_output']['handoff'])
    c.verify(accepted['actual_output']['manifest'])
    c.verify(accepted['independent_review']['handoff'])
    c.verify(accepted['independent_review']['manifest'])
    c.git_check(True)
    files, dirs = c.inventory(c.ROOT, exclude_git=True)
    c.write_new(H / 'baseline-files.json', files)
    c.write_new(H / 'baseline-directories.json', dirs)
    c.write_new(H / 'cache-baseline.json', c.load(OLD / 'cache-baseline.json'))
    c.cache_check()
    before = {r['path']: r for r in files}
    owners = c.load(H / 'runtime-owner-map.json')
    for row in owners['runtime']:
        for key in ['accepted', 'effective_preparation', 'actual_runtime', 'effective_integration']:
            c.verify(row[key])
        if row['before'] is not None:
            c.verify(row['before'])
        if row['changed']:
            dest = H / 'payload' / row['relative_path']
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(c.regular_bytes(row['effective_integration']['path']))
            dest.chmod(0o755 if before.get(row['relative_path'], {}).get('executable') else 0o644)
    selected = [
        (Path('/private/tmp/pathwaymech-next-236-author-20261012/draft/acetoacetate-degradation.yaml'), 'data/pathways/acetoacetate-degradation.yaml', 'c3e00916088b02b418c83e033ac1773bafc7aac036bc28eda30829e776e6779c'),
        (BUILD / 'sources.json', 'data/identifier_authorities/sources.json', '54f408f0fd1e10cbfa98280018b72d887b0b0ab16a1afbf0b070ffba1a31c2b5'),
        (BUILD / 'ontology.json', 'data/identifier_authorities/ontology.json', '5c2d6b2e7741bcd722bd6f5e37c3bda82becb9b2f447842e9e0a518fbf2bb9f7'),
    ]
    for src, rel, digest in selected:
        assert c.pin(src)['sha256'] == digest
        dest = H / 'payload' / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(c.regular_bytes(src))
        dest.chmod(0o644)
    assert {r['path'] for r in c.inventory(H / 'payload')[0]} == c.PRIMARY
    old_science = [r for r in files if r['path'].startswith('data/pathways/') and r['path'].endswith('.yaml')]
    assert len(old_science) == 236
    for row in old_science:
        assert c.pin(BUILD / 'corpus' / Path(row['path']).name)['sha256'] == row['sha256']
    inputs = [ACCEPT, H / 'root-target.json'] + [Path('/private/tmp') / f'pathwaymech-next-236-root-{name}-acceptance-20261012.json' for name in ['science', 'implementation', 'design', 'canonical-execution']]
    c.write_new(H / 'accepted-inputs.json', [c.pin(p) for p in inputs])
    c.write_new(H / 'baseline-receipt.json', {
        'at': datetime.datetime.now(datetime.UTC).isoformat(),
        'target': str(c.ROOT), 'commit': c.BASE, 'tree': c.TREE, 'branch': c.BRANCH,
        'git_clean': True, 'files': len(files), 'directories': len(dirs),
        'hidden_ignored_included': True, 'cache_entries': 800, 'exact_primary_owners': len(c.PRIMARY),
        'old_real_records': len(old_science), 'all_old_science_matches_accepted_actual_corpus': True,
        'actual_native_acceptance': c.pin(ACCEPT),
        'configuration': 'Use exact explicit accepted native manifest855; unchanged nitrate Rhea config remains outside payload. No stale runtime831 config adoption.',
    })
    print(c.load(H / 'baseline-receipt.json'))


if __name__ == '__main__':
    main()
