"""Use the reviewed lossless CAS format; bind reproducible fixture trees externally."""

import gzip
import hashlib
import io
import json
import os
import stat
import zipfile
from pathlib import Path

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
PRE = Path("/private/tmp/pathwaymech-next-236-canonical-preparation-20261012")


def digest(b):
    return hashlib.sha256(b).hexdigest()


def locate_member_name(row, root):
    name = row.get("relative_path", row.get("path"))
    p = Path(name)
    if p.is_absolute():
        p = p.relative_to(root)
    return str(c.relative(p.as_posix()))


class Store:
    def __init__(self):
        self.lookup = {}
        self.existing = {}
        self.archives = {}
        self.new = set()
        self.reused = set()
        for row in c.load(H / "baseline-files.json"):
            rel = row["path"]
            if (
                row["type"] == "regular"
                and rel not in c.PRIMARY
                and not rel.startswith(("pages/", "output/"))
            ):
                self.existing.setdefault(
                    row["sha256"],
                    {
                        "kind": "repository_file",
                        "repository_relative_path": rel,
                        "bytes": row["bytes"],
                        "sha256": row["sha256"],
                    },
                )
        # The 235 index already resolves earlier committed bodies, including ordered parts.
        index_path = (
            c.ROOT / "research/pathway_additions/2026-10-12-next-235/evidence-index.json.gz"
        )
        inherited = json.loads(gzip.decompress(c.regular_bytes(index_path)))
        for sha, loc in inherited["body_lookup"].items():
            self.existing.setdefault(sha, loc)
        amap = c.load(c.ROOT / "research/pathway_additions/2026-10-12-next-233/archive-map.json")
        for row in amap["archives"]:
            rel = row["repository_relative_path"]
            p = c.ROOT / rel
            c.verify(row["archive"], p)
            bound = c.pin(p)
            with zipfile.ZipFile(p) as z:
                assert len(z.namelist()) == len(set(z.namelist()))
                for entry in z.infolist():
                    if entry.filename.startswith("blobs/"):
                        sha = entry.filename[6:]
                        assert len(sha) == 64 and all(x in "0123456789abcdef" for x in sha)
                        self.existing.setdefault(
                            sha,
                            {
                                "kind": "repository_zip_member",
                                "repository_relative_path": rel,
                                "archive_bytes": bound["bytes"],
                                "archive_sha256": bound["sha256"],
                                "member": entry.filename,
                                "bytes": entry.file_size,
                                "sha256": sha,
                            },
                        )
        (DOS / "archives").mkdir(parents=True, exist_ok=True)
        self.archive_rel = c.DOSSIER + "/archives/evidence-bodies.zip"
        self.z = zipfile.ZipFile(PAY / self.archive_rel, "x", zipfile.ZIP_DEFLATED, compresslevel=9)

    def retrieve(self, loc):
        rel = loc["repository_relative_path"]
        if loc["kind"] == "repository_file":
            return c.regular_bytes(c.ROOT / rel)
        if rel not in self.archives:
            if loc["kind"] == "repository_chunked_zip_member":
                chunks = []
                for p in loc["archive_parts"]:
                    c.verify(p, c.ROOT / p["repository_relative_path"])
                    chunks.append(c.regular_bytes(c.ROOT / p["repository_relative_path"]))
                body = b"".join(chunks)
                assert (len(body), digest(body)) == (loc["archive_bytes"], loc["archive_sha256"])
                self.archives[rel] = zipfile.ZipFile(io.BytesIO(body))
            else:
                p = c.ROOT / rel
                c.verify({"bytes": loc["archive_bytes"], "sha256": loc["archive_sha256"]}, p)
                self.archives[rel] = zipfile.ZipFile(p)
        return self.archives[rel].read(loc["member"])

    def put(self, body):
        sha = digest(body)
        if sha in self.lookup:
            assert self.lookup[sha]["bytes"] == len(body)
            return sha
        if sha in self.existing:
            loc = self.existing[sha]
            assert self.retrieve(loc) == body
            self.reused.add(sha)
        else:
            info = zipfile.ZipInfo("blobs/" + sha, (2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            self.z.writestr(info, body)
            loc = {
                "kind": "repository_zip_member",
                "repository_relative_path": self.archive_rel,
                "member": info.filename,
                "bytes": len(body),
                "sha256": sha,
            }
            self.new.add(sha)
        self.lookup[sha] = loc
        return sha

    def owner(self, path, expected=None):
        p = Path(path)
        m = p.lstat().st_mode
        row = {"historical_path": str(p)}
        if stat.S_ISLNK(m):
            row.update(type="symlink", link_text=os.readlink(p))
            resolved = p.resolve(strict=True)
            row["resolved_path"] = str(resolved)
            if resolved.is_dir():
                return {**row, "resolution": "directory_alias_inert_not_recursively_followed"}
            if not stat.S_ISREG(resolved.lstat().st_mode):
                return {**row, "resolution": "special_target_not_opened"}
        elif stat.S_ISREG(m):
            row.update(type="regular", executable=bool(m & 0o111))
            resolved = p
        else:
            return {**row, "type": "special", "mode": stat.S_IFMT(m), "device": p.lstat().st_rdev}
        body = c.regular_bytes(resolved)
        if expected:
            assert (len(body), digest(body)) == (expected["bytes"], expected["sha256"]), p
            kind = expected.get("file_type", expected.get("type"))
            assert kind in [None, row["type"]], (p, kind)
            if "link_text" in expected:
                assert expected["link_text"] == row.get("link_text"), p
            if "resolved_path" in expected:
                assert expected["resolved_path"] == str(p.resolve(strict=True)), p
        return {**row, "bytes": len(body), "sha256": self.put(body)}

    def packet(self, root, omit=()):
        handoff = c.pin(root / "handoff.json")
        h = c.load(root / "handoff.json")
        manifest = h["manifest"]
        c.verify(manifest)
        assert Path(manifest["path"]) == root / "artifact-manifest.json"
        m = c.load(root / "artifact-manifest.json")
        expected = {locate_member_name(r, root): r for r in m["artifacts"]}
        assert len(expected) == len(m["artifacts"])
        physical = []
        omitted = []
        seen = set()
        dirs = []
        for here, children, names in os.walk(root, followlinks=False):
            for name in sorted(children + names):
                p = Path(here) / name
                rel = p.relative_to(root).as_posix()
                kind = p.lstat().st_mode
                if stat.S_ISDIR(kind):
                    dirs.append(rel)
                    continue
                seen.add(rel)
                if rel not in ["handoff.json", "artifact-manifest.json"]:
                    assert rel in expected, (root, rel)
                if any(rel == prefix or rel.startswith(prefix + "/") for prefix in omit):
                    row = expected[rel]
                    actual = {
                        "relative_path": rel,
                        "type": "symlink"
                        if stat.S_ISLNK(kind)
                        else "regular"
                        if stat.S_ISREG(kind)
                        else "special",
                        "declared_binding": row,
                        "current_stat_size": p.lstat().st_size,
                    }
                    if stat.S_ISLNK(kind):
                        actual["literal_link_text"] = os.readlink(p)
                    elif stat.S_ISREG(kind):
                        assert p.lstat().st_size == row["bytes"]
                    omitted.append(actual)
                else:
                    physical.append({"relative_path": rel, **self.owner(p, expected.get(rel))})
        # Declared followed views may exist through literal directory aliases; do not traverse them.
        declared_only = sorted(set(expected) - seen)
        declared = [
            {"relative_path": r, **self.owner(root / r, expected[r])}
            for r in sorted(expected)
            if r in seen and not any(r == p or r.startswith(p + "/") for p in omit)
        ]
        out = {
            "historical_root": str(root),
            "role": "Immutable scientific/runtime/review lineage; statuses and failures retained",
            "physical_hidden_ignored_no_follow_inventory": physical,
            "sealed_declared_file_views": declared,
            "historical_seals": {"handoff": handoff, "manifest": manifest},
            "physical_directory_membership": dirs,
            "portable_inventory_excludes_explicit_external_fixtures": bool(omit),
        }
        closure = {
            "root": str(root),
            "handoff": handoff,
            "manifest": manifest,
            "declared_artifacts": len(expected),
            "physical_files": len(seen),
            "directories": len(dirs),
            "external_fixture_prefixes": list(omit),
            "external_fixture_owners": omitted,
            "declared_followed_views_not_traversed": declared_only,
            "raw_fixture_hash_closure": (
                "Inherited exact sealed manifest, current physical membership/type"
                "/size observed; no fresh whole hash or portable-copy claim for om"
                "itted reproducible fixtures."
            ),
            "all_nonfixture_file_bodies_freshly_verified": True,
        }
        return out, closure

    def close(self):
        self.z.close()
        for z in self.archives.values():
            z.close()
        b = c.pin(PAY / self.archive_rel)
        for loc in self.lookup.values():
            if loc["repository_relative_path"] == self.archive_rel:
                loc.update(archive_bytes=b["bytes"], archive_sha256=b["sha256"])
        return b


def main():
    store = Store()
    packets = []
    closures = []
    omission = {
        "implementation-independent-review": (
            "focused-temp",
            "independent2-temp",
            "independent3-temp",
        ),
        "canonical-preparation-independent-review": ("variants",),
    }
    suffixes = [
        "preflight",
        "author",
        "science-review",
        "authority-design",
        "design-independent-review",
        "adapter-implementation",
        "implementation-independent-review",
        "cycle-successor",
        "cycle-independent-review",
        "canonical-preparation",
        "canonical-preparation-independent-review",
        "canonical-build",
        "canonical-output-independent-review",
    ]
    for suffix in suffixes:
        root = Path("/private/tmp") / f"pathwaymech-next-236-{suffix}-20261012"
        print("Bind", root.name, flush=True)
        packet, closure = store.packet(root, omission.get(suffix, ()))
        packets.append(packet)
        closures.append(closure)
    standalone = []
    for p in sorted(Path("/private/tmp").glob("pathwaymech-next-236-root-*.json")):
        standalone.append(store.owner(p))
    for p in sorted(Path("/private/tmp").glob("pathwaymech-next-236-root-run-canonical-*.py")):
        standalone.append(store.owner(p))
    for directory in ["root-canonical-execution", "graph-preview"]:
        root = Path("/private/tmp") / f"pathwaymech-next-236-{directory}-20261012"
        for here, _ds, names in os.walk(root, followlinks=False):
            for name in sorted(names):
                standalone.append(store.owner(Path(here) / name))
    for p in sorted(Path("/private/tmp").glob("pathwaymech-next-236-cycle-issue-*.json")):
        standalone.append(store.owner(p))
    source = c.load(PRE / "source-original-mapping.json")
    for key in [
        "scientific_reference_originals",
        "scientific_native_inventory",
        "prior_scientific_source_closure",
    ]:
        c.verify(source[key])
    references = c.load(source["scientific_reference_originals"]["path"])
    native = c.load(source["scientific_native_inventory"]["path"])
    prior = c.load(source["prior_scientific_source_closure"]["path"])
    specs = [
        ("manifest_originals", source["manifest_originals"]),
        (
            "whole_reference_originals",
            [{"reference_id": k, "original": v} for k, v in references.items()],
        ),
        ("scientific_native_originals", native),
    ]
    for key in [
        "whole_reference_originals",
        "bibliographic_originals",
        "prior_reference_originals",
        "retired_originals_retained",
    ]:
        if key in prior:
            specs.append(("inherited_nitrate_" + key, prior[key]))
    c.verify(prior["prior_reference_closure"])
    prior2 = c.load(prior["prior_reference_closure"]["path"])
    for key in [
        "whole_reference_originals",
        "bibliographic_originals",
        "prior_reference_originals",
        "retired_originals_retained",
    ]:
        if key in prior2:
            specs.append(("inherited_earlier_" + key, prior2[key]))
    groups = {}
    for key, values in specs:
        values = list(values.values()) if isinstance(values, dict) else values
        rows = []
        for row in values:
            original = row.get(
                "checked_original", row.get("original", row.get("old_whole_original", row))
            )
            assert "path" in original, (key, row)
            rows.append(
                {
                    "original_metadata": original,
                    "source_context": row,
                    "portable_body": store.owner(original["path"], original),
                }
            )
        groups[key] = rows
    assert len(groups["manifest_originals"]) == 854
    assert len(groups["whole_reference_originals"]) == 66
    assert len(groups["scientific_native_originals"]) == 38
    archive = store.close()
    index = {
        "format": "lossless-content-addressed-evidence-v1",
        "packet_inventories": packets,
        "standalone_owners": standalone,
        "original_groups": groups,
        "body_lookup": store.lookup,
        "active_external_path_dependencies": False,
        "links_and_specials": "Inert provenance metadata only; retrieve whole bodies by body_lookup, never recreate links or specials.",
        "external_fixture_policy": "Explicit synthetic fixture trees remain bound by exact original seals/manifests and complete physical/type/size inventories. Their raw hashes are inherited rather than rehashed or recopied. Scientific originals, control code, failures and actual streams remain portable.",
    }
    for name, value in [
        ("evidence-index.json.gz", index),
        ("external-packet-closures.json.gz", closures),
    ]:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n"
        (DOS / name).write_bytes(gzip.compress(raw, mtime=0))
    c.write_new(
        H / "packaging-summary.json",
        {
            "packets": len(packets),
            "unique_bodies": len(store.lookup),
            "unique_decoded_bytes": sum(v["bytes"] for v in store.lookup.values()),
            "new_bodies": len(store.new),
            "reused_committed_bodies": len(store.reused),
            "new_archive": archive,
            "original_group_counts": {k: len(v) for k, v in groups.items()},
            "omitted_reproducible_fixture_files": sum(
                len(x["external_fixture_owners"]) for x in closures
            ),
            "all_omissions_explicitly_bound": True,
            "all_scientific_originals_portable": True,
            "fixture_body_hashes_inherited_not_freshly_repeated": True,
        },
    )
    print(json.dumps(c.load(H / "packaging-summary.json"), indent=2), flush=True)
    assert c.inventory(c.ROOT, exclude_git=True) == (
        c.load(H / "baseline-files.json"),
        c.load(H / "baseline-directories.json"),
    )
    c.cache_check()


if __name__ == "__main__":
    main()
