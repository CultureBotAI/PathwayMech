"""Derive the exact accepted/effective aceto runtime bridge after root supplies a clean target."""

import ast
import difflib
import hashlib
import json
from pathlib import Path

H = Path(__file__).parent
OLD = Path("/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012")
BUILD = Path("/private/tmp/pathwaymech-next-236-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-236-canonical-preparation-20261012")


def pin(p):
    b = p.read_bytes()
    return {"path": str(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}


def main():
    target = json.loads((H / "root-target.json").read_bytes())
    root = Path(target["target"])
    assert root == Path("/private/tmp/pathwaymech-next-236-local-20261012")
    assert target["branch"] == "feat/pathway-next-236-local-20261012"
    assert target["clean"] is True
    inputs = json.loads((PRE / "input-bindings.json").read_bytes())
    actual_plan = json.loads((PRE / "execution-plan.json").read_bytes())
    source_args = actual_plan["commands"]["source_builder"]
    ontology_args = actual_plan["commands"]["ontology_builder"]
    overrides = {
        "conf/identifier_sources.json": Path(source_args[source_args.index("--manifest") + 1]),
        "conf/rhea_identifier_updates.json": Path(
            ontology_args[ontology_args.index("--rhea-updates") + 1]
        ),
    }
    assert overrides == {
        "conf/identifier_sources.json": BUILD / "manifest.json",
        "conf/rhea_identifier_updates.json": BUILD / "rhea-updates.json",
    }
    rows = []
    for row in inputs["runtime"]:
        rel = str(Path(row["staged"]["path"]).relative_to(PRE / "runtime"))
        actual = BUILD / "runtime" / rel
        for descriptor in (row["origin"], row["staged"]):
            bound = pin(Path(descriptor["path"]))
            assert (bound["bytes"], bound["sha256"]) == (descriptor["bytes"], descriptor["sha256"])
        assert pin(actual)["sha256"] == row["origin"]["sha256"]
        effective = overrides.get(rel, actual)
        before = pin(root / rel) if (root / rel).exists() else None
        bound = pin(effective)
        rows.append(
            {
                "relative_path": rel,
                "accepted": row["origin"],
                "effective_preparation": pin(Path(row["staged"]["path"])),
                "actual_runtime": pin(actual),
                "effective_integration": bound,
                "override_reason": "Exact explicit configuration consumed by accepted native CLI"
                if rel in overrides
                else None,
                "before": before,
                "changed": before is None or before["sha256"] != bound["sha256"],
            }
        )
    assert len(rows) == 270
    changed = sorted(r["relative_path"] for r in rows if r["changed"])
    assert len(changed) == 21
    assert "conf/identifier_sources.json" in changed
    assert "conf/rhea_identifier_updates.json" not in changed
    primary = sorted(
        changed
        + [
            "data/pathways/acetoacetate-degradation.yaml",
            "data/identifier_authorities/sources.json",
            "data/identifier_authorities/ontology.json",
        ]
    )
    assert len(primary) == 24
    (H / "runtime-owner-map.json").write_text(
        json.dumps(
            {
                "runtime": rows,
                "runtime_count": 270,
                "changed_runtime": len(changed),
                "primary": primary,
                "explicit_native_configuration_inputs": {k: pin(v) for k, v in overrides.items()},
            },
            indent=2,
        )
        + "\n"
    )
    replacements = {
        "/pathwaymech-next-235-local-20261012": str(root).removeprefix("/private/tmp"),
        "5ff01d7c59c61fd94b65b907edd50936193f7f17": target["commit"],
        "ead071a5b2a2a3bebcc54006b3cebbeec4f994ac": target["tree"],
        "feat/pathway-next-235-local-20261012": target["branch"],
        "2026-10-12-next-235": "2026-10-12-next-236",
        "nitrate235": "aceto236",
        "pathwaymech-next-235-local-adoption-": "pathwaymech-next-236-local-adoption-",
    }
    lineage = []
    patch = []
    for name in ["common.py", "adopt.py", "verify_portable.py", "split_archive.py"]:
        original = (OLD / name).read_text()
        text = original
        for old, new in replacements.items():
            text = text.replace(old, new)
        if name == "common.py":
            tree = ast.parse(text)
            node = next(
                n
                for n in tree.body
                if isinstance(n, ast.Assign)
                and any(isinstance(x, ast.Name) and x.id == "PRIMARY" for x in n.targets)
            )
            lines = text.splitlines(keepends=True)
            lines[node.lineno - 1 : node.end_lineno] = [
                "PRIMARY = frozenset(" + repr(primary) + ")\n"
            ]
            text = "".join(lines)
        (H / name).write_text(text)
        lineage.append(
            {
                "helper": name,
                "original": pin(OLD / name),
                "successor": pin(H / name),
                "change_scope": "Exact task path/commit/tree/branch/status token rebase; common PRIMARY uses24owner list. No guard logic changes.",
            }
        )
        patch.extend(
            difflib.unified_diff(
                original.splitlines(True),
                text.splitlines(True),
                fromfile="235/" + name,
                tofile="236/" + name,
            )
        )
    (H / "helper-lineage.json").write_text(json.dumps(lineage, indent=2) + "\n")
    (H / "helper-rebase.patch").write_text("".join(patch))
    print(
        json.dumps(
            {"runtime": len(rows), "effective_changes": changed, "primary": len(primary)}, indent=2
        )
    )


if __name__ == "__main__":
    main()
