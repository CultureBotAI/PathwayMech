"""Compare complete accepted deltas and prepare concrete root-owned native stages."""

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import common as c
import yaml

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-236-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-236-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
RID = "MetaCyc:ACETOACETATE-DEG-PWY"


def stable(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before, after = c.load(c.ROOT / rel), c.load(PAY / rel)
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [k for k in new if k in old] == list(old)
                for ident, value in old.items():
                    assert stable(value) == stable(new[ident]), (name, key, ident)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [k for k in new if k not in old],
                    "all_old_whole_objects_and_nested_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(PAY / rel),
            "sections": sections,
        }
    oldmanifest = c.load(c.ROOT / "conf/identifier_sources.json")
    newmanifest = c.load(PAY / "conf/identifier_sources.json")
    assert len(oldmanifest) == 844 and len(newmanifest) == 855
    assert stable(newmanifest[:844]) == stable(oldmanifest)
    assert c.regular_bytes(c.ROOT / "conf/rhea_identifier_updates.json") == c.regular_bytes(
        BUILD / "rhea-updates.json"
    )
    bn, an = rows(c.ROOT / "output/kgx/nodes.tsv"), rows(BUILD / "actual-kgx/nodes.tsv")
    be, ae = rows(c.ROOT / "output/kgx/edges.tsv"), rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = {r["id"]: r for r in be}
    assert [r for r in ae if r["id"] in oldedges] == be
    oldnodes, newnodes = {r["id"]: r for r in bn}, {r["id"]: r for r in an}
    changes, aggregate = [], []
    contexts = additions = 0
    for ident, old in oldnodes.items():
        new = newnodes[ident]
        prior = json.loads(old["source_contexts"])
        current = json.loads(new["source_contexts"])
        assert [v for v in current if v["record_id"] != RID] == prior
        delta_contexts = [v for v in current if v["record_id"] == RID]
        contexts += len(prior)
        additions += len(delta_contexts)
        delta = {
            key: {"before": value, "after": new[key]}
            for key, value in old.items()
            if key != "source_contexts" and value != new[key]
        }
        if delta:
            aggregate.append({"id": ident, "fields": delta})
        if old != new:
            changes.append({"id": ident, "before": old, "after": new})
    expected_delta = [
        {"id": "RHEA:21038", "fields": {"direction": {"before": "right_to_left", "after": ""}}}
    ]
    assert aggregate == expected_delta
    assert len(changes) == additions == 8
    assert (len(bn), len(be), len(an), len(ae)) == (4260, 11903, 4277, 11949)
    record = yaml.safe_load(c.regular_bytes(PAY / "data/pathways/acetoacetate-degradation.yaml"))
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for mapping in record["source_mappings"]:
        row = {k: mapping[k] for k in cols if k != "comment"}
        row["comment"] = (
            f"source_pathway_id={mapping['source_pathway_id']}; "
            f"source_element_id={mapping['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(row[k])).strip() for k in cols})
    existing = Counter(stable(r) for r in oldss)
    assert len(oldss) == 27 and all(n == 1 for n in existing.values())
    added = [r for r in newss if stable(r) not in existing]
    assert len(added) == len(newss) == 5
    files = c.load(H / "baseline-files.json")

    def count(prefix, suffix):
        return sum(r["path"].startswith(prefix) and r["path"].endswith(suffix) for r in files)

    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": count("data/pathways/", ".yaml"),
        "old_review_yaml": count("reviews/", ".yaml"),
        "old_review_markdown": count("reviews/", ".md"),
        "old_history_yaml": count("history/", ".yaml"),
        "native_authorities": native,
        "manifest_prefix_rows": 844,
        "manifest_after_rows": 855,
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_order_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_changes": aggregate,
        "aggregate_direction_scope": (
            "Only RHEA21038 aggregate cleared; old KEGG:M00374 and "
            "MetaCyc:PWY-5789 right_to_left contexts remain exact alongside new "
            "left_to_right aceto context."
        ),
        "old_authority_object_exceptions": [],
        "planning_decisions": [c.pin(PRE / "graph-planning-decision.json")],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = json.loads(
        json.dumps(c.load(OLD / "stages.json"))
        .replace("pathwaymech-next-235-local", "pathwaymech-next-236-local")
        .replace("nitrate-reduction-viii", "acetoacetate-degradation")
        .replace("PWY0-1352", "ACETOACETATE-DEG-PWY")
    )
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        description=(
            "Exact 20 accepted production/test/doc deltas, native 855manifest and "
            "two actual snapshots; whole typed aceto sources, nested "
            "assemblies/residue classes and issue 502 mixed-profile cycle guard. "
            "All old authority objects and first owners remain exact."
        ),
        issue_lineage=[502],
    )

    def history(kind, slug, owner_args, event, summary, details, issues=()):
        argv = [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            kind,
            "--slug",
            slug,
            *owner_args,
            "--event",
            event,
            "--outcome",
            "changed",
            "--summary",
            summary,
            "--details",
            details,
        ]
        for issue in issues:
            argv += ["--issue", str(issue)]
        return argv + ["--actor-name", "codex", "--agent-tool", "codex", "--model", "gpt-6"]

    stages["history_commands"] = [
        history(
            "record",
            "acetoacetate-degradation",
            ["--target-root", "data/pathways"],
            "CREATE",
            "Add the complete evidence-backed acetoacetate degradation record.",
            (
                "Adopted exact accepted MetaCyc:ACETOACETATE-DEG-PWY science: 29 "
                "paragraphs, 46 edges, 25 named identities, one construct qualifier, "
                "66 references and five mappings. Whole native pathways/reactions, "
                "nested Ato assemblies, generic protein-residue classes, "
                "mechanism/assay/source limits and rejected alternative equation "
                "preserved in research/pathway_additions/2026-10-12-next-236. Actual "
                "native outputs independently reviewed and accepted. Fresh maintained "
                "gates and saved native review remain pending."
            ),
        ),
        history(
            "infrastructure",
            "aceto-native-authority",
            ["--path", "scripts/build_source_identifier_snapshot.py"],
            "EDIT",
            "Integrate complete aceto authority contexts and accepted native snapshots.",
            (
                "Adopted 20 accepted runtime/documentation/test deltas and exact "
                "explicit 855-row manifest with two native snapshots. Keep nitrate "
                "Rhea updates unchanged; complete old objects/order and all 265 "
                "UniProt originals/first owners remain exact. Accepted issue 502 guard "
                "rejects mixed-profile cycles while preserving legacy-only behavior. "
                "RHEA21038 aggregate direction clears only because retained old and "
                "new source contexts disagree; no old context reverses. Local "
                "integration only; history precedes generation and native review/gates "
                "remain pending."
            ),
            [502],
        ),
    ]
    stages["after_gates"] = [
        (
            "Inspect the complete actual aceto page/graph, all 29 paragraphs/46 "
            "edges, 25 identities, one qualifier, 66 references and provenance "
            "against exact accepted science."
        ),
        (
            "Capture actual maintained inputs via native record_review.py inspect, "
            "draft truthful scientific and technical reviews distinguishing "
            "inherited full-source science from fresh maintained QA, then "
            "save/check with actual times."
        ),
        (
            "Verify all 236 prior records/pages, old review pairs and histories, "
            "every old authority object/order without exceptions, every 11,903 old "
            "KGX edge and whole old context payload/order/multiplicity. Only "
            "accepted RHEA21038 aggregate direction change."
        ),
        (
            "SSSOM preserves 27 old rows/order/header plus exactly five new rows; "
            "compare semantic-preservation.json."
        ),
        (
            "Replay all 800 shared-cache identities and complete hidden/ignored "
            "checkout inventory outside exact primary/dossier/native additions."
        ),
        (
            "Fresh final adversarial actual-tree review and append-only "
            "native-save verification; no public actions or issue closure from "
            "this plan."
        ),
    ]
    stages["native_review_interfaces"]["save_template"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "save",
        "--content",
        "<root-authored-completed-review.json>",
    ]
    stages["native_review_interfaces"]["check_after_save"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "check",
        "--require-reviews",
    ]
    stages["native_review_interfaces"]["inherited_science_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-236-science-review-20261012/handoff.json"
    )
    stages["native_review_interfaces"]["actual_native_review_handoff"] = c.pin(
        
            "/private/tmp/pathwaymech-next-236-canonical-output-independent-review-"
            "20261012/handoff.json"
        
    )
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    stages["before_first_render_after_history"][0]["preservation"] = (
        "Keep complete old SSSOM header and 27 old "
        "rows/cells/order/multiplicity; add exactly five rows in "
        "semantic-preservation.json. Planned only."
    )
    c.write_new(H / "stages.json", stages)
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Committed accepted nitrate local branch, not merged main",
            "primary_owners": len(c.PRIMARY),
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(PAY / "data/pathways/acetoacetate-degradation.yaml"),
            "actual_native_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-236-root-canonical-output-acceptance-20261012.json"
            ),
            "remaining": [
                "independent preparation review",
                "root exact acceptance",
                "local adoption",
                "two native histories before SSSOM/render",
                "nine maintained gates",
                "actual page/graph QA",
                "native saved reviews",
                "complete preservation and final adversarial review",
            ],
            "source_exhaustion": False,
            "licensing": (
                "Public-release licensing remains deferred; existing publication block unchanged."
            ),
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_files",
                    "old_records",
                    "old_review_yaml",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                    "exact_aggregate_changes",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
