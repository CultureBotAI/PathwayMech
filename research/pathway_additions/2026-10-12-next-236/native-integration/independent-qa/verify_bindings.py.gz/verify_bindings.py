"""Verify exact actual commands, native inspection inputs and retained lineages."""
import csv, io, json
from collections import Counter
from pathlib import Path
from run_qa import OUT, ROOT, ROOT_QA, NATIVE, pin, save, now

PREP = Path('/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012')

def load(p):
    return json.loads(Path(p).read_bytes())

def verify(d):
    actual = pin(d['path'])
    assert all(actual[k] == d[k] for k in ('sha256', 'bytes')), d
    return actual

stages = load(PREP / 'stages.json')
planned = {r['name']: r['argv'] for r in stages['nine_fresh_gates'] + stages['before_first_render_after_history']}
planned.update({f'history-{i}': argv for i, argv in enumerate(stages['history_commands'], 1)})
receipts, inputs = [], [pin(PREP / 'stages.json')]
for phase in ('history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates'):
    path = NATIVE / phase / 'completion.json'
    value = load(path)
    assert value['status'] == 'phase_passed' and value['phase'] == phase
    inputs.append(pin(path))
    for key in ('adoption', 'stage_plan', 'runner'):
        inputs.append(verify(value[key]))
    for r in value['receipts']:
        assert r['argv'] == planned[r['name']]
        assert r['environment'] == stages['environment'] and r['cwd'] == stages['cwd']
        assert r['exit_code'] == 0 and r['started_at'] <= r['finished_at']
        own = NATIVE / phase / (r['name'] + '.execution.json')
        assert load(own) == r
        inputs.extend([pin(own), verify(r['stdout']), verify(r['stderr'])])
        receipts.append({'phase': phase, 'name': r['name'], 'receipt': pin(own), 'exact_planned_command': True, 'seconds': r['seconds']})
assert [r['name'] for r in receipts] == ['history-1', 'history-2', 'sssom', 'render', 'skills', 'validate', 'tests', 'lint', 'kgx', 'vendored', 'diff-check', 'site-current']

adoption = load('/private/tmp/pathwaymech-next-236-local-adoption-root-20261012/receipt.json')
inputs.extend([verify(adoption['approval']), verify(adoption['handoff'])])
assert len(adoption['changes']) == 34 and adoption['target'] == str(ROOT)

inspections = []
for label, count in (('scientific', 1), ('technical', 23)):
    execution = ROOT_QA / (label + '-inspection.execution.json')
    stdout = ROOT_QA / (label + '-inspection.stdout')
    stderr = ROOT_QA / (label + '-inspection.stderr')
    targets = ROOT_QA / (label + '-targets.json')
    receipt, body = load(execution), load(stdout)
    assert receipt['exit_code'] == 0 and receipt['cwd'] == str(ROOT)
    assert body['status'] == 'inspection_only' and len(body['targets']) == count
    assert body['source']['git_revision'] == adoption['baseline_commit']
    checked = []
    for row in body['source']['inputs']:
        actual = pin(ROOT / row['path'])
        assert actual['sha256'] == row['sha256'], row
        checked.append(actual)
    inputs.extend([pin(execution), pin(stdout), pin(stderr), pin(targets)])
    inspections.append({'kind': label, 'target_count': count, 'inputs': checked, 'input_hashes_still_current': True, 'inspection_not_review': True})

visual = load(OUT / 'visual-inputs.json')
for descriptor in visual['inputs'] + visual['outputs']:
    verify(descriptor)

semantic = load(PREP / 'semantic-preservation.json')['SSSOM']
old_sssom = Path('/private/tmp/pathwaymech-next-235-local-20261012/output/sssom/source_mappings.sssom.tsv')
assert pin(old_sssom)['sha256'] == semantic['before']['sha256']
current_sssom = ROOT / 'output/sssom/source_mappings.sssom.tsv'
def rows(path):
    lines = path.read_text().splitlines()
    header = [line for line in lines if line.startswith('#')]
    reader = csv.DictReader(io.StringIO('\n'.join(line for line in lines if not line.startswith('#'))), delimiter='\t')
    return header, list(reader.fieldnames), list(reader)
old_header, old_fields, old_rows = rows(old_sssom)
header, fields, current_rows = rows(current_sssom)
assert header == old_header == semantic['exact_header_lines'] and fields == old_fields
marker = 'source_pathway_id=MetaCyc:ACETOACETATE-DEG-PWY;'
retained = [r for r in current_rows if marker not in r['comment']]
added = [r for r in current_rows if marker in r['comment']]
assert retained == old_rows and len(retained) == 27
normalize = lambda values: Counter(tuple(r[k] for k in fields) for r in values)
assert normalize(added) == normalize(semantic['expected_added_rows']) and len(added) == 5
sssom_receipt = NATIVE / 'history-and-generation/sssom-preservation.json'
verify(load(sssom_receipt)['actual'])
inputs.extend([pin(sssom_receipt),pin(old_sssom),pin(current_sssom),pin(PREP/'semantic-preservation.json')])

inherited = []
for path in (
    '/private/tmp/pathwaymech-next-236-science-review-20261012/handoff.json',
    '/private/tmp/pathwaymech-next-236-science-review-20261012/REPORT.md',
    '/private/tmp/pathwaymech-next-236-science-review-20261012/successor-scientific-assessments.json',
    '/private/tmp/pathwaymech-next-236-science-review-20261012/successor-identity-reference-assessments.json',
    '/private/tmp/pathwaymech-next-236-root-implementation-acceptance-20261012.json',
    '/private/tmp/pathwaymech-next-236-root-canonical-output-acceptance-20261012.json',
    '/private/tmp/pathwaymech-next-236-canonical-output-independent-review-20261012/handoff.json',
    '/private/tmp/pathwaymech-next-236-local-integration-independent-review-20261012/handoff.json',
    '/private/tmp/pathwaymech-next-236-local-integration-independent-review-20261012/REPORT.md',
):
    inherited.append(pin(path))
save('exact-bindings.json', {'status': 'passed', 'finished_at': now(), 'actual_commands': receipts, 'inspections': inspections, 'actual_native_inputs': inputs, 'inherited_review_bindings': inherited, 'visual_current': True, 'SSSOM': {'old_rows':27,'new_rows':5,'total_rows':32,'whole_header_fields_old_row_order_cells_multiplicity_preserved':True}, 'limitations': ['No scientific primary-source rereading in this maintained QA.', 'Native suites executed by root; exact actual receipts and streams verified here without rerunning them.', 'No native review save, Git mutation or public action by this reviewer.']})
print(json.dumps({'status': 'passed', 'actual_commands': len(receipts), 'scientific_inspection_targets': 1, 'technical_inspection_targets': 23}))
