"""Bounded read-only maintained QA; writes only beside this exact helper."""
import datetime, hashlib, json, os, re, subprocess, sys, time
from pathlib import Path
from lxml import etree

OUT = Path(__file__).parent
ROOT = Path('/private/tmp/pathwaymech-next-236-local-20261012')
ROOT_QA = Path('/private/tmp/pathwaymech-next-236-root-maintained-qa-20261012')
NATIVE = Path('/private/tmp/pathwaymech-next-236-local-native-execution-20261012')
PYTHON = '/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
PAGE = ROOT / 'pages/records/MetaCyc_ACETOACETATE-DEG-PWY.html'
YAML = ROOT / 'data/pathways/acetoacetate-degradation.yaml'
CSS = ROOT / 'pages/assets/pathway-network.css'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')

def run(name, argv):
    start, clock = now(), time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', UV_NO_SYNC='1')
    with (OUT / (name + '.stdout')).open('xb') as stdout, (OUT / (name + '.stderr')).open('xb') as stderr:
        p = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    receipt = {'command': argv, 'cwd': str(ROOT), 'started_at': start, 'finished_at': now(), 'elapsed_seconds': time.monotonic() - clock, 'exit_code': p.returncode, 'driver': pin(__file__), 'stdout': pin(OUT / (name + '.stdout')), 'stderr': pin(OUT / (name + '.stderr'))}
    if name in ('check_target', 'check_checkout'):
        receipt['helper'] = pin(OUT / (name + '.py'))
    save(name + '.execution.json', receipt)
    assert p.returncode == 0, (name, p.returncode)
    return receipt

def visual():
    before = [pin(p) for p in (PAGE, YAML, CSS)]
    raw = re.search(r'<svg\b[^>]*class="pathway-network-svg"[^>]*>.*?</svg>', PAGE.read_text(), re.S).group(0)
    with (OUT / 'actual-graph.svg').open('x') as f:
        f.write(raw)
    css = CSS.read_text().split('@media')[0]
    variables = dict(re.findall(r'(--graph-[a-z]+):\s*([^;]+);', css))
    for k, v in variables.items():
        css = css.replace('var(' + k + ')', v)
    svg = etree.fromstring(raw.encode())
    style = etree.Element('{http://www.w3.org/2000/svg}style')
    style.text = css
    svg.insert(0, style)
    with (OUT / 'light-static-graph.svg').open('xb') as f:
        f.write(etree.tostring(svg))
    receipt = run('rasterize_actual', ['/usr/local/bin/rsvg-convert', '-w', '1800', '-b', 'white', '-o', str(OUT / 'actual-graph.png'), str(OUT / 'light-static-graph.svg')])
    after = [pin(p) for p in (PAGE, YAML, CSS)]
    assert before == after
    save('visual-inputs.json', {'scope': 'Actual maintained SVG, rendered with the native light-theme CSS variables; static raster only. Human visual assessment is separate.', 'inputs': before, 'outputs': [pin(OUT / x) for x in ('actual-graph.svg', 'light-static-graph.svg', 'actual-graph.png')], 'render_receipt': receipt, 'inputs_preserved': True})

def final():
    phases = ('history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates')
    gates = []
    for phase in phases:
        p = NATIVE / phase / 'completion.json'
        body = json.loads(p.read_bytes())
        assert body['status'] == 'phase_passed'
        gates.append(pin(p))
    helpers = []
    for name in ('check_target', 'check_checkout'):
        own, original = OUT / (name + '.py'), ROOT_QA / (name + '.py')
        assert own.read_bytes() == original.read_bytes()
        helpers.append({'review_copy': pin(own), 'root_prepared_original': pin(original), 'byte_equal': True})
    save('final-intake.json', {'at': now(), 'gate_completions': gates, 'helpers': helpers, 'scope': 'Replayed exact root-prepared read-only helpers after independent complete helper inspection. No native gate or paper review rerun.'})
    receipts = [run(name, [PYTHON, '-B', str(OUT / (name + '.py'))]) for name in ('check_target', 'check_checkout')]
    save('final-execution.json', {'status': 'passed', 'receipts': receipts, 'finished_at': now()})

if __name__ == '__main__':
    assert len(sys.argv) == 2 and sys.argv[1] in ('visual', 'final')
    {'visual': visual, 'final': final}[sys.argv[1]]()
