"""Verify final drafts, make an exact root copy plan, and seal this external QA packet."""
import datetime, difflib, gzip, hashlib, json, os, stat
from pathlib import Path
import yaml
from run_qa import OUT as O, ROOT as R, pin, save

Q='research/pathway_additions/2026-10-12-next-236/native-integration/independent-qa'
def load(p):return json.loads(Path(p).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
assert load(O/'qa-and-drafts-completed.json')['status']=='passed'
results={}
for kind in ('scientific','technical'):
    doc=yaml.safe_load((O/(kind+'-review.yaml')).read_bytes())
    for row in doc['source']['inputs']:
        assert sha((R/row['path']).read_bytes())==row['sha256']
    for ev in doc['evidence']:
        path=O/ev['reference'][len(Q)+1:] if ev['reference'].startswith(Q+'/') else R/ev['reference']
        assert sha(path.read_bytes())==ev['snapshot_sha256'],ev['evidence_id']
    assert doc['completion']=='completed' and not doc['findings']
    assert all(c['status']=='passed' for c in doc['checks'] if c['required'])
    assert len(doc['targets'])==(1 if kind=='scientific' else 23)
    assert len(doc['assessments'])==(170 if kind=='scientific' else 28)
    receipt=load(O/(kind+'-validate.execution.json'))
    assert receipt['exit_code']==0
    for key in ('stdout','stderr'):
        assert pin(receipt[key]['path'])==receipt[key]
    results[kind]={'draft':pin(O/(kind+'-review.yaml')),'assessments':len(doc['assessments']),'targets':len(doc['targets']),'evidence_bindings':len(doc['evidence']),'current_inputs':len(doc['source']['inputs']),'native_schema_validated':True}
save('final-draft-check.json',{'status':'both_native_drafts_and_all_evidence_bindings_passed','results':results,'native_save_performed':False})
old=Path('/private/tmp/pathwaymech-next-235-maintained-independent-qa-20261012/finalize_native_inputs.py')
new=O/'finalize_native_inputs.py'
with (O/'finalizer-lineage.patch').open('x') as f:
    f.writelines(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile=str(old),tofile=str(new)))
save('finalizer-lineage.json',{'prior':pin(old),'current':pin(new),'scope':'Reuses source-input extension contract. Complete copied evidence set is hashed and added as native inputs, with safe relative regular paths, unchanged original inputs/judgments/times, and actual inspect/validate receipts. No save command. Prepared but not executed by this reviewer.'})
raw_map=load(O/'evidence-copy-bindings.json'); durable=[]
for row in raw_map['files']:
    copy=Path(row['copy']['path']); encoded=copy.suffix=='.py'
    expected=Q+'/'+copy.relative_to(O).as_posix()
    assert row['repository_path']==expected
    durable.append({**row,'repository_path':expected+'.gz' if encoded else expected,'gzip_encoded':encoded,'decoded_sha256':row['copy']['sha256']})
save('durable-evidence-bindings.json',{'files':durable,'plain_copy_map':pin(O/'evidence-copy-bindings.json'),'scope':'Final encoded payload paths. The earlier assembly map describes plain external copies; this successor appends .gz for the preserved root runner Python body. No source, judgment or command changes.'})
assert (O/'REPORT.md').is_file() and (O/'read-coverage.json').is_file()
save('package-execution.json',{'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'final_draft_binding_checks_passed_sealing_next','helper':pin(__file__),'actual_exit':'Outer tool result records process completion; no future completion is asserted here.'})
files=sorted(p for p in O.rglob('*') if p.is_file() and 'payload' not in p.relative_to(O).parts and p.relative_to(O).as_posix() not in ('copy-plan.json','artifact-manifest.json','handoff.json'))
payload=O/'payload';payload.mkdir();rows=[]
for p in files:
    assert stat.S_ISREG(p.lstat().st_mode)
    rel=p.relative_to(O).as_posix();raw=p.read_bytes();encoded=p.suffix=='.py'
    dest=rel+'.gz' if encoded else rel;body=gzip.compress(raw,mtime=0) if encoded else raw
    q=payload/dest;q.parent.mkdir(parents=True,exist_ok=True)
    with q.open('xb') as f:f.write(body)
    assert (gzip.decompress(body) if encoded else body)==raw
    rows.append({'repository_path':Q+'/'+dest,'payload_path':str(q),'bytes':len(body),'sha256':sha(body),'source_path':str(p),'decoded_sha256':sha(raw),'decoded_bytes':len(raw),'gzip_encoded':encoded})
index={'status':'ready_for_exact_root_adoption','durable_root':Q,'files':[{k:v for k,v in row.items() if k not in ('payload_path','source_path')} for row in rows]}
with (payload/'package-index.json').open('x') as f:json.dump(index,f,indent=2);f.write('\n')
row=pin(payload/'package-index.json');rows.append({'repository_path':Q+'/package-index.json','payload_path':row['path'],'bytes':row['bytes'],'sha256':row['sha256'],'gzip_encoded':False})
save('copy-plan.json',{'durable_root':Q,'files':rows,'root_evidence':[],'native_save_performed':False,'maintained_writes_performed':False,'after_adoption':'Root runs finalize_native_inputs.py into a new external output directory, then reviews/saves/checks both unchanged judgments. All payload files become native source inputs.'})
artifacts=[];directories=[]
for base,ds,fs in os.walk(O,followlinks=False):
    for name in ds:
        p=Path(base)/name;assert not p.is_symlink();directories.append(p.relative_to(O).as_posix())
    for name in fs:
        p=Path(base)/name;assert stat.S_ISREG(p.lstat().st_mode)
        if p.relative_to(O).as_posix() not in ('artifact-manifest.json','handoff.json'):
            row=pin(p);artifacts.append({'relative_path':p.relative_to(O).as_posix(),'type':'regular','bytes':row['bytes'],'sha256':row['sha256']})
save('artifact-manifest.json',{'artifacts':sorted(artifacts,key=lambda x:x['relative_path']),'count':len(artifacts),'directories':sorted(directories),'hidden_ignored_included':True,'aliases':0})
save('handoff.json',{'status':'actual_aceto_maintained_qa_pass_with_limitations_native_drafts_validated','reviewer':'Codex /root/deoxy237_science_review','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'findings':[],'artifacts':len(artifacts),'seals':2,'manifest':pin(O/'artifact-manifest.json'),'report':pin(O/'REPORT.md'),'copy_plan':pin(O/'copy-plan.json'),'native_drafts':[pin(O/(kind+'-review.yaml')) for kind in ('scientific','technical')],'target_qa':pin(O/'target-qa.json'),'checkout_preservation':pin(O/'checkout-preservation.json'),'limits':'Inherited complete scientific source and runtime interpretation; fresh current-record, graph/table, static visual, whole-tree and actual-gate receipt QA. No maintained writes or native review save by reviewer.','next':'Separate root acceptance, exact copy-plan adoption, guarded native input finalization, immutable native save/check and append-only verification.'})
print(json.dumps({'handoff':pin(O/'handoff.json'),'manifest':pin(O/'artifact-manifest.json'),'artifacts':len(artifacts),'payload_files':len(rows),'native_drafts':results},indent=2))
