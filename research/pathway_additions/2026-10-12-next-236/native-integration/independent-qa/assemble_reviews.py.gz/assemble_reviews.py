"""Prepare truthful native drafts and compact durable evidence; never save reviews."""
import datetime, gzip, hashlib, json, shlex
from pathlib import Path
import yaml
from run_qa import OUT as O, ROOT as R, ROOT_QA, PYTHON, pin, save, run

class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True

Q = 'research/pathway_additions/2026-10-12-next-236/native-integration/independent-qa'
S = Path('/private/tmp/pathwaymech-next-236-science-review-20261012')
P = 'data/pathways/acetoacetate-degradation.yaml'
def load(p): return json.loads(Path(p).read_bytes())
def sha(b): return hashlib.sha256(b).hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')

target = yaml.safe_load((R/P).read_bytes())
assert sha((R/P).read_bytes()) == 'c3e00916088b02b418c83e033ac1773bafc7aac036bc28eda30829e776e6779c'
qa, tree, bindings = [load(O/n) for n in ('target-qa.json','checkout-preservation.json','exact-bindings.json')]
assert qa['status'] == 'all_actual_maintained_target_and_preservation_checks_passed'
assert tree['status'] == 'complete_checkout_preservation_after_native_gates_passed'
assert bindings['status'] == 'passed'
science = load(S/'successor-scientific-assessments.json')
identities = load(S/'successor-identity-reference-assessments.json')
index = json.loads(gzip.decompress((R/'research/pathway_additions/2026-10-12-next-236/evidence-index.json.gz').read_bytes()))

# Compact receipts/reports only. Original primary bodies stay in the existing portable dossier.
mapping = {}
def retain(path, relative):
    path, dest = Path(path), O/relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('xb') as f: f.write(path.read_bytes())
    assert dest.read_bytes() == path.read_bytes()
    mapping[str(path)] = {'source': pin(path), 'copy': pin(dest), 'repository_path': Q+'/'+relative}

for descriptor in bindings['inherited_review_bindings']:
    p = Path(descriptor['path'])
    retain(p, 'inherited/'+p.parent.name+'/'+p.name)
for p in (S/'successor-identity-reference-assessments.json', Path('/private/tmp/pathwaymech-next-236-canonical-output-independent-review-20261012/REPORT.md')):
    if str(p) not in mapping: retain(p, 'inherited/'+p.parent.name+'/'+p.name)
for descriptor in bindings['actual_native_inputs']:
    p = Path(descriptor['path'])
    if str(p) in mapping: continue
    if '/pathwaymech-next-236-local-native-execution-20261012/' in str(p):
        rel = str(p).split('/pathwaymech-next-236-local-native-execution-20261012/',1)[1]
        retain(p, 'actual-root-execution/'+rel)
    else:
        retain(p, 'actual-root-inputs/'+p.relative_to('/private/tmp').as_posix())
save('evidence-copy-bindings.json', {'files': list(mapping.values()), 'primary_bodies_duplicated': False})

base = []
def evidence(eid, kind, reference, summary, digest, locator=None):
    e = dict(evidence_id=eid, kind=kind, reference=reference, accessed_at=utc(), support='supports', summary=summary, snapshot_sha256=digest)
    if locator: e['locator'] = locator
    base.append(e)

evidence('current-target','record_content',P,'Fresh complete reading of all 1,368 YAML lines. Exact accepted target has 29 paragraphs, 46 edges, 25 identities, one construct qualifier, 66 references and five mappings.',sha((R/P).read_bytes()))
for eid,name,summary in (
    ('fresh-target-qa','target-qa.json','Fresh complete graph/table/qualifier/reference and old scientific-owner comparison using exact reviewed root-prepared helper.'),
    ('fresh-tree-qa','checkout-preservation.json','Fresh hidden/ignored-inclusive complete physical tree and all 800 shared-cache identities, before evidence adoption or native review saves.'),
    ('exact-bindings','exact-bindings.json','Exact twelve native command receipts, streams, planned argv/environment and inspection source hashes verified after all four phases passed.'),
    ('static-visual','visual-assessment.json','Fresh static light raster extracted from the actual maintained SVG and personally viewed. Dense junction labels overlap; long construct label truncates.'),
): evidence(eid,'validation',Q+'/'+name,summary,sha((O/name).read_bytes()))

prior_ids = {
    S/'REPORT.md': 'inherited-science',
    S/'successor-scientific-assessments.json': 'inherited-claims',
    S/'successor-identity-reference-assessments.json': 'inherited-identities-references',
    Path('/private/tmp/pathwaymech-next-236-canonical-output-independent-review-20261012/REPORT.md'): 'inherited-native-output',
    Path('/private/tmp/pathwaymech-next-236-local-integration-independent-review-20261012/REPORT.md'): 'inherited-integration-preparation',
    Path('/private/tmp/pathwaymech-next-236-root-implementation-acceptance-20261012.json'): 'accepted-runtime',
}
for p,eid in prior_ids.items():
    row=mapping[str(p)]
    evidence(eid,'prior_review',row['repository_path'],'Exact accepted earlier interpretation is inherited and its complete report/dispositions read. Primary-source and production-runtime review are not represented as newly executed here.',row['source']['sha256'])

checks = []
required = {'render','skills','validate','tests','lint','kgx','vendored','diff-check','site-current'}
for row in bindings['actual_commands']:
    path=Path(row['receipt']['path']); rec=load(path); eid='root-'+row['name']
    evidence(eid,'validation',mapping[str(path)]['repository_path'],'Actual root execution passed; complete receipt and stdout/stderr hashes independently verified. No repeated native gate by this reviewer.',sha(path.read_bytes()))
    checks.append(dict(check_id=eid,name='Root-executed '+row['name'],status='passed',required=row['name'] in required,summary='Exact planned command and pinned environment passed; original receipt and streams retained.',target_ids=[],command=shlex.join(rec['argv']),exit_code=0,expected_exit_code=0,evidence_ids=[eid],scope_note='Actual root execution, not a second execution by this reviewer.'))
for name,eid in (('check_target','fresh-target-qa'),('check_checkout','fresh-tree-qa'),('verify-bindings','exact-bindings')):
    rec=load(O/(name+'.execution.json')); assert rec['exit_code']==0
    checks.append(dict(check_id=name,name='Fresh independent '+name,status='passed',required=True,summary='Exact read-only helper, output and actual stream receipt retained.',target_ids=[],command=shlex.join(rec['command']),exit_code=0,expected_exit_code=0,evidence_ids=[eid]))
checks.append(dict(check_id='static-raster',name='Actual graph static visual inspection',status='passed',required=True,summary='Actual maintained SVG raster freshly rendered and personally viewed; full DOM/evidence comparison also passes.',target_ids=[],evidence_ids=['static-visual','fresh-target-qa']))
checks.append(dict(check_id='browser-interaction',name='Interactive browser checks',status='unavailable',required=False,summary='No keyboard, JavaScript interaction, responsive or dark-theme behavior was tested. Static light raster and complete DOM correspondence were checked.',target_ids=[],evidence_ids=['static-visual']))

limits = [
    'Full scientific source interpretation is inherited from the accepted independent review. This review freshly reads the entire current YAML and all 29 paragraph, 46 edge, 25 identity and 66 reference dispositions and compares exact current claims; it does not reread primary papers.',
    'Inherited source depth remains three complete main papers (1975 thiolases, 2007 AtoC, 2022 YdiF), ten indexed abstracts and five metadata-only papers. Not all supplements or cited papers were read. No source-exhaustion or new whole-paper claim follows.',
    'Distinct wild-type B, constitutive mutant, K-12/MG1655, BL21 recombinant and O157:H7 ortholog contexts remain scoped. Exact supplement-only YdiF cloning details and unavailable historical assay contexts are not newly verified.',
    'Actual maintained static light SVG was freshly rasterized and viewed. Dense shared-junction labels overlap and the long construct node label truncates; the complete qualification and evidence remain in the checked tables. No browser interaction/responsive/dark-theme result is claimed.',
    'Production implementation, whole-source authority semantics and the issue502 cycle correction are inherited from accepted independent runtime/output reviews; current gates and exact output identity verify integration. This is not another line-by-line adapter review or full SQL rehash.',
    'The reviewer authored earlier external canonical preparation, but did not author this scientific record, production adapters, local-integration preparation or root maintained execution. Current independence is scoped to the latter maintained integration and inherited scientific adjudication; earlier self-authored planning is not independently certified here.',
    'No maintained record, native review, cache, Git state or GitHub object was changed by this reviewer. Root owns exact evidence adoption, guarded final native inspection, append-only save/check and any later local commit.',
]
start=datetime.datetime.fromisoformat(load(O/'rasterize_actual.execution.json')['started_at']).strftime('%Y-%m-%dT%H:%M:%SZ')
results={}
for kind in ('scientific','technical'):
    args=[PYTHON,'-B','scripts/record_review.py','inspect','--targets',str(ROOT_QA/(kind+'-targets.json'))]
    root_ins=load(ROOT_QA/(kind+'-inspection.stdout'))
    for row in root_ins['source']['inputs']:
        args+=['--input',row['path']]
    run(kind+'-inspect',args)
    ins=load(O/(kind+'-inspect.stdout'))
    assert ins['source']==root_ins['source'] and ins['targets']==root_ins['targets']
    tids=[t['target_id'] for t in ins['targets']]
    local_checks=json.loads(json.dumps(checks))
    for c in local_checks:c['target_ids']=tids
    assessments=[]
    def assess(aid,area,topic,summary,eids,details=None,target_ids=None):
        a=dict(assessment_id=aid,area=area,topic=topic,outcome='supported',summary=summary,target_ids=tids if target_ids is None else target_ids,evidence_ids=eids)
        if details:a['details']=details
        assessments.append(a)
    if kind=='scientific':
        for p,a in zip(target['description'].split('\n\n'),science['paragraphs']):
            assert sha(p.encode())==a['text_sha256']
            assess('paragraph-'+a['id'],'evidence',a['id'],'Inherited complete scientific judgment, freshly checked against current paragraph: '+a['assessment'],['current-target','inherited-claims','inherited-science'],'Current paragraph SHA256 '+a['text_sha256'])
        for e,a in zip(target['mechanistic_edges'],science['edges']):
            assert e['id']==a['id'] and sha(json.dumps(e,ensure_ascii=False,sort_keys=True).encode())==a['claim_sha256']
            assess('edge-'+a['id'],'graph',a['id'],'Inherited complete scientific judgment, freshly checked against current whole edge and its evidence: '+a['assessment'],['current-target','inherited-claims','inherited-science'],'Whole canonical edge SHA256 '+a['claim_sha256'])
        qualifiers=[(e['id'],q) for e in target['mechanistic_edges'] for q in e.get('endpoint_qualifiers',[])]
        assert len(qualifiers)==1
        assess('qualified-ydiF','scope','e046 experimental construct','The exact whole-edge assessment includes the subject qualifier: pET28a/BL21(lambdaDE3), nickel purification, 1 mM acetoacetyl-CoA plus 10 mM acetate, pH7, 35 C and 20 min. The reverse assay does not establish forward assimilation or growth necessity. Supplemental cloning remains unverified.',['current-target','inherited-claims','fresh-target-qa'],json.dumps(qualifiers[0],ensure_ascii=False))
        named={target['id']:{'id':target['id'],'label':target['label']},**{n['id']:n for group in ('taxa','participants','reactions') for n in target[group]}}
        assert len(named)==len(identities['selected_identities'])==25
        for i,a in enumerate(identities['selected_identities'],1):
            assert named[a['id']]['label']==a['label']
            assess('identity-'+str(i),'identity',a['id'],'Inherited issuing-identity judgment retained against the current complete target: '+a['assessment'],['current-target','inherited-identities-references','inherited-native-output'],'Historical wording that implementation was pending describes the earlier scientific-review stage; actual implementation/output acceptance and current native gates are separate later evidence.')
        refs={x['id']:x for x in target['references']}
        assert len(refs)==len(identities['references'])==66
        for i,a in enumerate(identities['references'],1):
            r=refs[a['id']]
            assert r['source_sha256']==a['original']['sha256'] and r['source_version']==a['source_version'] and r['source_sha256'] in index['body_lookup']
            assess('reference-'+str(i),'provenance',a['id'],'Inherited original-reference assessment retained with exact current source hash and source-version language: '+a['assessment'],['current-target','inherited-identities-references','fresh-target-qa'],r['source_version'])
        assess('route-boundary','scope','Two biological events and mechanistic decomposition','AtoDA transfer and AtoB cleavage yield one net acetyl-CoA. Rhea equations are alternative projections, and native cysteinyl half-reactions are decomposition context. Acetyl-CoA donor replacement is mass balance, without enzyme channeling. Incompatible PathBank thiolase chemistry is rejected.',['current-target','inherited-science'])
        assess('regulation-and-assemblies','scope','Expression, assemblies and residue classes','AtoA2AtoD2 nested assembly and separate AtoB4 retain whole-complex activity. Generic protein-bound cysteine states remain distinct from free cysteine or demonstrated Cys88 occupancy. AtoC is expression-level control; conditional native inhibition annotations do not become universal potency claims.',['current-target','inherited-science'])
        assess('rendered-completeness','representation','Actual complete graph and evidence table','All 46 arrows, 25 visual nodes, 25 named identities, one qualified construct and 66 references correspond to current YAML; all local anchors resolve and whole narrative text survives. Unconnected taxon remains in the component table.',['fresh-target-qa','static-visual'])
        title='Acetoacetate degradation: inherited full science and independent maintained QA'
        summary='Exact accepted acetoacetate science is retained. Current whole-record reading and individual inherited paragraph/edge/identity/reference assessments agree; fresh graph/table and preservation QA pass with explicit scientific-access and static-visual limitations.'
    else:
        assert len(tids)==23
        for i,t in enumerate(ins['targets'],1):
            h=next(x['sha256'] for x in ins['source']['inputs'] if x['path']==t['path'])
            assess('owner-'+str(i),'ownership',t['path'],'Exact current owner matches the independently accepted local-integration payload and actual runtime/output bodies. The current full native gates pass; production semantics are inherited from their separate accepted review.',['fresh-target-qa','fresh-tree-qa','inherited-integration-preparation','inherited-native-output','accepted-runtime'],'Current SHA256 '+h,[t['target_id']])
        assess('authority-and-config','grounding','Actual native authority bodies and effective configuration','Sources have 2,619 terms/678 owners and ontology 2,005 terms/five owners. Exact current files equal accepted native output. All prior objects/order and first-owner provenance remain preserved without exception. The 855-row actual manifest retains the complete prior 844-row prefix; retained 831-row runtime configuration is not substituted.',['fresh-target-qa','inherited-native-output','inherited-integration-preparation'])
        assess('prior-corpus','provenance','Whole old tree and history preservation','All 236 prior records/pages, 116 review pairs and 400 history records remain exact. Current hidden/ignored census permits only 34 planned owners, 10 generated owners and two new histories. All 800 cache identities remain unchanged.',['fresh-tree-qa','fresh-target-qa'])
        assess('kgx-and-sssom','representation','Whole graph contexts and mappings','Both current KGX surfaces equal accepted native 4,277 nodes/11,949 edges. All 11,903 old edge rows and 7,941 old node contexts retain payload/order/multiplicity. RHEA:21038 aggregate direction clears due to retained conflicting traversal contexts; old KEGG:M00374/PWY-5789 right-to-left contexts do not reverse. SSSOM preserves 27 old rows plus five exact new rows.',['fresh-target-qa','inherited-integration-preparation','inherited-native-output','exact-bindings'])
        assess('portable-evidence','provenance','Whole accepted original evidence and receipt closure','All 34 adopted owner bytes, including the ten-owner portable dossier, match the independently replayed preparation. Earlier fresh preparation replay covered 2,353 bodies/341,141,661 decoded bytes, with 5,260 explicitly excluded synthetic fixtures inherited. Current reference hashes resolve and all actual receipt/stream bodies are freshly checked. No primary-body or full SQL reread is claimed.',['fresh-target-qa','fresh-tree-qa','inherited-integration-preparation','exact-bindings'])
        assess('gates-and-histories','consistency','Actual root execution and chronological history','Both native histories precede SSSOM and first render. All nine required gates passed using exact approved commands and pinned environment across four chronological phases. Complete actual stdout/stderr receipts are retained.',['exact-bindings'])
        title='Aceto authority integration: independent maintained preservation review'
        summary='All 23 technical primary owners match accepted implementation and actual authority outputs. Fresh complete maintained content/tree/receipt checks pass, with exact old-object/context preservation and inherited implementation interpretation.'
    finish=utc(); prefix=finish.replace('-','').replace(':','')
    doc=dict(schema_version='1.0.0',review_id=prefix+'-aceto236-'+kind,kind='record' if kind=='scientific' else 'repository',repository='CultureBotAI/PathwayMech',title=title,started_at=start,finished_at=finish,reviewer=dict(identity='Codex /root/deoxy237_science_review',kind='agent',independence='independent',independence_basis=limits[5]),skill='.claude/skills/review-yaml-record/SKILL.md',completion='completed',verdict='pass_with_limitations',scientific_review=kind=='scientific',summary=summary,source=ins['source'],scope=dict(description=summary,selection='Exact aceto local integration on baseline9bd87745d842b0602d027f3d15d26bbc178474a6 before subsequent evidence adoption and native review save.',coverage='full',population_size=len(tids),reviewed_target_ids=tids,exclusions=[dict(target='Fresh primary-paper and production-runtime audit',reason='Accepted full scientific and runtime interpretations are inherited and exactly bound; current work assesses complete maintained content and integration.'),dict(target='Native review save and publication',reason='Later root-owned actions require guarded evidence adoption and current-input/append-only checks.')]),targets=ins['targets'],checks=local_checks,evidence=base,assessments=assessments,findings=[],actions=[],limitations=limits,notes=['The complete current YAML and all inherited paragraph/edge/identity/reference dispositions were read. Scientific access tiers describe the earlier source reviewers, not fresh primary-paper work here.','The captured interval starts with the first retained current-page raster execution; earlier contextual helper/report reads precede it.','Root-prepared exact deterministic checkers were reused after complete inspection. The independent reviewer separately inspected current scientific wording, inherited dispositions, the actual raster and exact native command/input bindings.','External drafts are schema validation inputs only. No native structured predecessor occurrence or issue closure is fabricated.'],links=['https://github.com/CultureBotAI/PathwayMech/issues/502'],tags=['acetoacetate','local-integration','independent-maintained-qa'])
    with (O/(kind+'-review.yaml')).open('x') as f: f.write(yaml.dump(doc,Dumper=NoAliasDumper,sort_keys=False,allow_unicode=True,width=100))
    results[kind]={'targets':len(tids),'assessments':len(assessments),'draft':pin(O/(kind+'-review.yaml'))}
save('draft-summary.json',results)
print(json.dumps(results,indent=2))
