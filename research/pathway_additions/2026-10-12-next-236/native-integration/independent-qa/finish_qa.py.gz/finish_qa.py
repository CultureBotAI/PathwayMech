"""Sequence only completed-gate checks, draft construction and native schema validation."""
import os
from run_qa import OUT, ROOT, PYTHON, run, final, pin, save
os.environ['PYTHONPATH']=str(ROOT/'src')+':'+str(ROOT)
helpers=[pin(OUT/n) for n in ('check_target.py','check_checkout.py','verify_bindings.py','assemble_reviews.py','run_qa.py')]
save('finish-helper-inputs.json', {'helpers':helpers,'driver':pin(__file__),'environment':{'PYTHONPATH':os.environ['PYTHONPATH'],'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'}})
final()
run('verify-bindings',[PYTHON,'-B',str(OUT/'verify_bindings.py')])
run('assemble-reviews',[PYTHON,'-B',str(OUT/'assemble_reviews.py')])
for kind in ('scientific','technical'):
    run(kind+'-validate',[PYTHON,'-B','scripts/record_review.py','validate',str(OUT/(kind+'-review.yaml'))])
save('qa-and-drafts-completed.json', {'status':'passed','native_save_performed':False,'drafts':[pin(OUT/(kind+'-review.yaml')) for kind in ('scientific','technical')]})
