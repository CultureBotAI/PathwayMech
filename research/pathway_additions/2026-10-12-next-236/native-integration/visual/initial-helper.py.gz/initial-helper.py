"""External exact native preview; no maintained adoption/history claims."""
import datetime,hashlib,json,re,subprocess,sys
from pathlib import Path
from lxml import etree,html
import yaml
BASE=Path('/private/tmp/pathwaymech-next-236-canonical-build-20261012')
OUT=Path('/private/tmp/pathwaymech-next-236-graph-preview-20261012')
sys.path[:0]=[str(BASE/'runtime/src'),str(BASE/'runtime')]
from pathwaymech.schema import validate_record
from pathwaymech.cli import _record_page,_slug
p=BASE/'corpus/acetoacetate-degradation.yaml'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='c3e00916088b02b418c83e033ac1773bafc7aac036bc28eda30829e776e6779c'
d=yaml.safe_load(p.read_bytes());r=validate_record(d)
OUT.mkdir();(OUT/'records').mkdir();(OUT/'assets').mkdir()
page=_record_page(r,'data/pathways/'+p.name,[])
(OUT/'records'/(_slug(r.id)+'.html')).write_text(page)
for n in ('pathway-network.css','pathway-network.js'):
 (OUT/'assets'/n).write_bytes((BASE/'runtime/src/pathwaymech/assets'/n).read_bytes())
css=(OUT/'assets/pathway-network.css').read_text().split('@media')[0]
vars=dict(re.findall(r'(--graph-[a-z]+):\s*([^;]+);',css))
for k,v in vars.items():css=css.replace('var('+k+')',v)
svg=re.search(r'<svg class="pathway-network-svg".*?</svg>',page,re.S).group()
svg=svg.replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" ',1)
root=etree.fromstring(svg.encode());style=etree.Element('{http://www.w3.org/2000/svg}style');style.text=css;root.insert(0,style)
(OUT/'graph.svg').write_bytes(etree.tostring(root))
dom=html.fromstring(page);ids=dom.xpath('//*[@id]/@id')
assert len(ids)==len(set(ids))
for href in dom.xpath('//*[@href]/@href'):
 if href.startswith('#'):assert href[1:] in ids
nodes=dom.xpath('//a[contains(concat(" ",@class," ")," graph-node ")]')
edges=dom.xpath('//a[contains(concat(" ",@class," ")," graph-edge ")]')
assert len(edges)==len(d['mechanistic_edges'])==46
for i,(e,a) in enumerate(zip(d['mechanistic_edges'],edges),1):
 assert a.get('href')=='#mechanism-edge-'+str(i) and a.get('data-predicate')==e['predicate']
 assert a.get('data-subject-id')==e['subject'] and a.get('data-object-id')==e['object']
argv=['/usr/local/bin/rsvg-convert','-w','1800','-b','white','-o',str(OUT/'graph.png'),str(OUT/'graph.svg')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
proc=subprocess.run(argv,capture_output=True)
(OUT/'render.stdout').write_bytes(proc.stdout);(OUT/'render.stderr').write_bytes(proc.stderr)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
report={'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'external_exact_native_record_preview','target':pin(p),'helper':pin(Path(__file__)),'graph_nodes':len(nodes),'graph_edges':len(edges),'references':len(d['references']),'qualifiers':sum(len(e.get('endpoint_qualifiers',[])) for e in d['mechanistic_edges']),'all_local_anchors_resolve':True,'command':argv,'exit_code':proc.returncode,'browser_interaction':'unavailable from prior CUA result; not attempted here','history':[],'maintained_adoption':False,'style':'Actual native light CSS with graph variables resolved for static raster; responsive, print and dark media styles excluded.'}
(OUT/'qa.json').write_text(json.dumps(report,indent=2)+'\n')
assert proc.returncode==0
print(json.dumps(report))
