"""Seal completed root QA and bind actual receipts; do not rerun any gate."""
from pathlib import Path
import datetime, hashlib, json, os, stat

Q=Path('/private/tmp/pathwaymech-next-236-root-maintained-qa-20261012')
G=Path('/private/tmp/pathwaymech-next-236-local-native-execution-20261012')
def pin(p):
    b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,v):
    with p.open('x') as f: json.dump(v,f,indent=2); f.write('\n')
def verify(v):
    assert pin(Path(v['path']))==v,v
receipts=[]
for name in ['target','checkout']:
    r=json.loads((Q/(name+'.execution.json')).read_bytes());assert r['exit_code']==0
    verify(r['helper_at_start']);verify(r['stdout']);verify(r['stderr']);receipts.append(r)
target=json.loads((Q/'target-qa.json').read_bytes())
assert all(x['passed'] for x in target['checks'])
checkout=json.loads((Q/'checkout-preservation.json').read_bytes())
assert (checkout['current_files'],checkout['current_directories'],checkout['cache_entries_unchanged'])==(11820,1918,800)
gates=[]
for phase in ['history-and-generation','remaining-offline-gates','vendored-gate','final-gates']:
    d=json.loads((G/phase/'completion.json').read_bytes());assert d['status']=='phase_passed'
    for r in d['receipts']:
        assert r['exit_code']==0; verify(r['stdout']);verify(r['stderr']);gates.append(r)
assert len(gates)==12 and all(a['finished_at']<=b['started_at'] for a,b in zip(gates,gates[1:]))
assert '4273 passed, 3 skipped, 3 warnings' in (G/'remaining-offline-gates/tests.stdout').read_text()
report='''# Acetoacetate maintained integration checks

The exact accepted acetoacetate degradation YAML is maintained locally on baseline commit 9bd87745d842b0602d027f3d15d26bbc178474a6. Native scientific and technical input inspections preceded the root assessment. Full scientific interpretation is inherited from the accepted complete-source independent scientific review; this root assessment and its later sealing are not fresh primary-literature reviews.

All 29 current paragraphs and 46 complete edge objects match the accepted assessments. Every graph arrow and evidence table endpoint, predicate, description, evidence assertion/quote/locator, qualifier, reference metadata/link and local anchor agrees with the current YAML. The page has 25 visual nodes, 46 arrows, one qualified construct, 25 named identities and 66 references. The unconnected taxon is retained in the component table. The entire narrative survives rendering; HTML IDs are unique. Actual SVG DOM serialization equals the previously statically inspected preview. Static-preview visual limits remain: dense junction labels overlap and the construct label truncates, with full text preserved in the table. No browser interaction is claimed. Actual native history is rendered.

Both authority bodies and both downloaded/CLI KGX surfaces exactly equal accepted actual native outputs. There are 4,277 KGX nodes and 11,949 edges. The previously independently assessed aggregate direction change for RHEA:21038 is inherited, with old contextual directions retained. All 236 old records/pages, 116 old review pairs and 400 old history YAMLs remain byte-exact. Generic target-qa.json counters include README or .gitkeep owners and are not scientific-record denominators. The current corpus contains 237 records.

The complete physical inventory includes hidden and ignored entries, excluding Git administration. Against 11,789 files and 1,913 directories, exactly 34 adopted owners, ten permitted generated paths and two new histories produce 11,820 files and 1,918 directories. Every old owner outside this declared scope, every adopted byte/mode and all 800 shared-cache identities are unchanged. This census precedes subsequent evidence adoption and review saves; final append-only verification remains required.

All four actual native execution phases passed. Twelve command receipts cover two histories, SSSOM, and nine gates: render, skills, validation, tests (4,273 passed, three skipped, three dependency warnings), lint, KGX, vendored sync, whitespace and page freshness. All twelve command exits and retained stdout/stderr hashes pass verification. Histories preceded SSSOM and first render. Vendored sync passed in the approved read-only phase; there was no initial 236 DNS failure. SSSOM has five accepted additions to all 27 prior rows; that complete ordered semantic comparison is independently recorded in maintained QA.

Root target QA executed 2026-10-12T21:01:07.415670Z through 21:01:09.117986Z, exit 0. Root checkout QA executed 21:01:55.909603Z through 21:02:06.225014Z, exit 0. The helpers and original complete streams remain unchanged. helper-lineage.json records their earlier prepared-not-executed state; the later execution receipts establish completion. This sealing operation rechecks receipt/body identity only and reruns no gate, scientific review, native builder, broad tests or SQL hash.

Independent maintained QA, native input extension/save/check and final local commit are separately authorized lifecycle steps. No publication, PR, issue closure, merge, branch deletion, licensing clearance or source-exhaustion claim is made by this report.
'''
with (Q/'REPORT.md').open('x') as f:f.write(report)
write(Q/'sealing-receipt.json',{'sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':pin(Path(__file__)),'target_and_checkout_receipts':[pin(Q/(n+'.execution.json')) for n in ['target','checkout']],'gate_commands':len(gates),'all_original_streams_verified':True,'root_execution_inherited':True,'gate_reruns':0,'scientific_reading':'inherited','hidden_and_ignored_included':True})
rows=[];dirs=[]
for base,ds,fs in os.walk(Q,followlinks=False):
    rel=str(Path(base).relative_to(Q));dirs.append(rel)
    assert all(not (Path(base)/n).is_symlink() for n in ds)
    for n in fs:
        p=Path(base)/n;assert stat.S_ISREG(p.lstat().st_mode)
        v=pin(p);rows.append({'relative_path':str(p.relative_to(Q)),'type':'regular','bytes':v['bytes'],'sha256':v['sha256']})
rows.sort(key=lambda r:r['relative_path']);dirs.sort()
write(Q/'artifact-manifest.json',{'artifacts':rows,'directories':dirs,'hidden_ignored_included':True,'aliases':0})
write(Q/'handoff.json',{'status':'completed_root_qa_sealed_without_reruns','manifest':pin(Q/'artifact-manifest.json'),'report':pin(Q/'REPORT.md'),'artifacts':len(rows),'seals':2,'findings':[]})
actual={str(p.relative_to(Q)) for p in Q.rglob('*') if p.is_file()}
assert actual=={r['relative_path'] for r in rows}|{'artifact-manifest.json','handoff.json'}
print(json.dumps({'handoff':pin(Q/'handoff.json'),'manifest':pin(Q/'artifact-manifest.json'),'artifacts':len(rows),'seals':2}))
