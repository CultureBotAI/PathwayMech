"""Add exact original-byte whitespace diagnostics and independent appraisal only."""
from pathlib import Path
import gzip,hashlib,json,sys,datetime
R=Path('/private/tmp/pathwaymech-next-236-local-20261012');REL=Path('research/pathway_additions/2026-10-12-next-236/native-integration/staged-whitespace');D=R/REL
O=Path('/private/tmp/pathwaymech-next-236-staged-precommit-20261012');A=Path(sys.argv[1]);expected=sys.argv[2]
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert not D.exists() and pin(A.read_bytes())['sha256']==expected
scope=json.loads((O/'staged-whitespace-scope.json').read_bytes());assert scope['original_full_staged_exit']==2 and scope['authored_scope']['exit_code']==0
sources=[(O/'staged-whitespace-scope.json','scope.json',False),(A,'independent-appraisal.json',False),(A.with_suffix('.py'),'independent-appraisal.py.gz',True),(Path('/private/tmp/pathwaymech-next-236-whitespace-scope-20261012.py'),'scope-helper.py.gz',True),(Path(__file__),'adopt-helper.py.gz',True)]
for group in ['unscoped','authored']:
 for stream in ['stdout','stderr']:sources.append((O/('whitespace-'+group+'.'+stream),group+'.'+stream+'.gz',True))
entries=[];payload=[]
for p,rel,compressed in sources:
 assert p.is_file() and not p.is_symlink();raw=p.read_bytes();b=gzip.compress(raw,mtime=0) if compressed else raw
 payload.append((D/rel,b));entries.append({'source':str(p),'owner':str(REL/rel),'encoding':'gzip' if compressed else 'identity','original':pin(raw),'stored':pin(b)})
readme='''# Exact staged whitespace scope

The complete staged `git diff --cached --check` returned 2 with nine trailing-whitespace diagnostics on exactly eight retained original-byte paths. Five are accepted upstream XML originals, one is the exact successful pytest output, and two are retained unified-diff lineage artifacts whose blank context lines contain the format's single-space marker. Every body matches its accepted payload or source map and exact staged blob.

The additional authored-file staged check excludes only those eight literal paths and returns 0. The independent appraisal, full original failure and complete scoped command/streams are retained here. No original body or repository whitespace setting was changed. The original unscoped failure remains a reported scope limitation; it is not relabeled as a full whitespace pass. Prior successful native unstaged diff checks retain their actual scope.
'''
payload.append((D/'README.md',readme.encode()))
for p,b in payload:
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 assert p.read_bytes()==b
with (D/'storage-map.json').open('x') as f:json.dump({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries,'additional_document':'README.md','readme':pin(readme.encode())},f,indent=2);f.write('\n')
print(json.dumps({'files':len(payload)+1,'storage_map':pin((D/'storage-map.json').read_bytes())}))
