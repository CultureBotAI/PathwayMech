from pathlib import Path
import json,hashlib,subprocess,re
from datetime import datetime,timezone
wt=Path('/private/tmp/pathwaymech-next-236-local-20261012');stage=Path('/private/tmp/pathwaymech-next-236-staged-precommit-20261012')
def desc(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
d=json.loads((stage/'staged-verification.json').read_text());raw=(stage/'whitespace-unscoped.stdout').read_bytes();assert hashlib.sha256(raw).hexdigest()==d['unscoped_stdout_sha256'];assert d['full_whitespace_exit_code']==2
warning=d['whitespace_diagnostics'];assert len(warning)==9;paths=sorted({r['path'] for r in warning});assert len(paths)==8
planp=Path('/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012/plan.json');assert desc(planp)['sha256']=='106c79e7be2f0d86f1ce3719bcf06a5f7a64cc77a6383ddaf5cb7702e430b683'
plan={r['destination']:r for r in json.loads(planp.read_text())['changes']}
peerp=Path('/private/tmp/pathwaymech-next-236-maintained-independent-qa-20261012/copy-plan.json');assert desc(peerp)['sha256']=='c49d04a0e199e26768426fd5fe33ff91088ae2268df560cfd7a97dbace232c59'
peer={r['repository_path']:r for r in json.loads(peerp.read_text())['files']}
mapfile=wt/'research/pathway_additions/2026-10-12-next-236/native-integration/root-storage-map.json';rootmap={r['owner']:r for r in json.loads(mapfile.read_text())['entries']}
rows=[]
for p in paths:
 actual=wt/p;assert actual.is_file() and not actual.is_symlink();b=actual.read_bytes();sha=hashlib.sha256(b).hexdigest()
 staged=subprocess.run(['git','show',':'+p],cwd=wt,capture_output=True,check=True).stdout;assert b==staged
 if p in plan:
  r=plan[p]['payload'];assert sha==r['sha256'] and len(b)==r['bytes'] and b==Path(r['path']).read_bytes();authority=desc(planp);kind='unaltered accepted upstream XML fixture'
 elif p in peer:
  r=peer[p];assert not r['gzip_encoded'];assert sha==r['sha256'] and len(b)==r['bytes'];assert b==Path(r['payload_path']).read_bytes()==Path(r['source_path']).read_bytes();authority=desc(peerp);kind='exact test stdout' if p.endswith('.stdout') else 'unaltered preserved unified diff'
 else:
  r=rootmap[p];assert r['encoding']=='identity';assert sha==r['stored']['sha256']==r['original']['sha256'];assert len(b)==r['stored']['bytes']==r['original']['bytes'];assert b==Path(r['source']).read_bytes();authority=desc(mapfile);kind='unaltered preserved unified diff'
 observed=[]
 for w in warning:
  if w['path']!=p:continue
  line=b.splitlines()[w['line']-1];assert w['kind']=='trailing whitespace.' and line.endswith(b' ')
  if p.endswith('.patch'):assert line==b' '
  if p.endswith('.stdout'):assert line==b'  '
  if p.endswith('.xml'):assert b'<comment datatype=' in line and b'Ron Caspi received his PhD' in line
  observed.append({'line':w['line'],'kind':w['kind'],'line_sha256':hashlib.sha256(line).hexdigest()})
 rows.append({'path':p,'bytes':len(b),'sha256':sha,'staged_equals_worktree_and_accepted_source':True,'classification':kind,'authority':authority,'warnings':observed})
argv=['git','diff','--cached','--check','--','.']+[':(exclude,literal)'+p for p in paths];r=subprocess.run(argv,cwd=wt,capture_output=True);assert r.returncode==0 and r.stdout==b'' and r.stderr==b''
result={'status':'accept_exact_original_byte_whitespace_exceptions_only','reviewer':'Codex /root','at':datetime.now(timezone.utc).isoformat(),'full_staged_check_exit_code':2,'full_diagnostics':desc(stage/'whitespace-unscoped.stdout'),'excluded_paths':rows,'authored_scope':{'argv':argv,'cwd':str(wt),'exit_code':r.returncode,'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr)},'judgment':'Nine diagnostics in eight exact files are source fidelity and preserved execution/patch syntax, not authored product whitespace defects. Exclude only these eight literal paths for authored-file check; keep full failed check and exact originals. The unrestricted staged check has not passed.','no_source_normalization_or_git_settings_change':True,'scope':'Independent narrow appraisal, not broad gate rerun or public-push approval.'}
p=Path('/private/tmp/pathwaymech-next-236-root-whitespace-appraisal-20261012.json');assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(desc(p)))
