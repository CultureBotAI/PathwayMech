"""Persist successful native review finalization/save/check evidence losslessly."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,sys
sys.path.insert(0,'/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012');import common as c
R=c.ROOT;REL=Path(c.DOSSIER)/'native-integration/finalization';D=R/REL
assert c.load('/private/tmp/pathwaymech-next-236-native-review-save-20261012/completion.json')['status']=='all_native_review_save_and_checks_passed'
assert not D.exists()
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for source,sub in [(Path('/private/tmp/pathwaymech-next-236-root-native-finalized-20261012'),'native-inputs'),(Path('/private/tmp/pathwaymech-next-236-root-native-finalization-execution-20261012'),'finalize-execution'),(Path('/private/tmp/pathwaymech-next-236-native-review-save-20261012'),'save-and-check'),(Path('/private/tmp/pathwaymech-next-236-native-review-save-execution-20261012'),'save-wrapper')]:
 for base,dirs,files in os.walk(source,followlinks=False):
  assert all(not (Path(base)/n).is_symlink() for n in dirs)
  for n in files:
   p=Path(base)/n;rows.append((p,Path(sub)/p.relative_to(source)))
for name in ['save-native-reviews','adopt-finalization','run-local-step']:
 p=Path('/private/tmp/pathwaymech-next-236-'+name+'-20261012.py');rows.append((p,Path(name+'.py')))
rows += [(Path('/private/tmp/pathwaymech-next-236-save-native-reviews-20261012.py.patch'),Path('save-native-reviews-lineage.patch')),(Path('/private/tmp/pathwaymech-next-236-evidence-adoption-receipt-20261012.json'),Path('evidence-adoption-receipt.json'))]
entries=[];payload=[]
for p,rel in rows:
 b=c.regular_bytes(p);enc=p.suffix in ['.py','.yaml','.stdout','.stderr'] or p.name in ['stdout','stderr'];stored=gzip.compress(b,mtime=0) if enc else b
 dest=Path(str(rel)+'.gz') if enc else rel;payload.append((D/dest,stored));entries.append({'source':str(p),'owner':str(REL/dest),'encoding':'gzip' if enc else 'identity','original':pin(b),'stored':pin(stored)})
assert len({p for p,b in payload})==len(payload)
for p,b in payload:
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 assert c.regular_bytes(p)==b
c.write_new(D/'storage-map.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual native input inspection/validation, two immutable saves, append-only review check, lint and unstaged diff-check. All peer judgments unchanged. No publication.','entries':entries})
print(json.dumps({'artifacts':len(entries),'storage_map':c.pin(D/'storage-map.json')}))
