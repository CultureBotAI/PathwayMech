import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
import yaml
ROOT=Path('/private/tmp/pathwaymech-next-236-local-20261012');DRAFT=Path('/private/tmp/pathwaymech-next-236-maintained-independent-qa-20261012');FINAL=Path('/private/tmp/pathwaymech-next-236-root-native-finalized-20261012');OUT=Path('/private/tmp/pathwaymech-next-236-native-review-save-20261012');OUT.mkdir()
PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
ENV={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(ROOT/'src')+':'+str(ROOT)}
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
commands=[]
for kind in ['scientific','technical']:
 before=yaml.safe_load((DRAFT/(kind+'-review.yaml')).read_bytes());after=yaml.safe_load((FINAL/(kind+'-review.yaml')).read_bytes())
 assert {k:v for k,v in before.items() if k!='source'}=={k:v for k,v in after.items() if k!='source'}
 assert after['source']['git_revision']=='9bd87745d842b0602d027f3d15d26bbc178474a6'
 commands.append((kind+'-save',[PY,'-B','scripts/record_review.py','save','--content',str(FINAL/(kind+'-review.yaml'))]))
commands += [('review-check',[PY,'-B','scripts/record_review.py','check','--base','9bd87745d842b0602d027f3d15d26bbc178474a6']),('lint',[PY,'-B','-m','ruff','check','--no-cache','.']),('diff-check',['git','diff','--check'])]
results=[]
for name,argv in commands:
 v={'name':name,'argv':argv,'cwd':str(ROOT),'environment':ENV,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':pin(Path(__file__))};t=time.monotonic()
 with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=ROOT,env={**os.environ,**ENV},stdout=out,stderr=err)
 v.update(exit_code=p.returncode,seconds=time.monotonic()-t,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout=pin(OUT/(name+'.stdout')),stderr=pin(OUT/(name+'.stderr')))
 (OUT/(name+'.execution.json')).write_text(json.dumps(v,indent=2)+'\n');results.append(v);print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(OUT/'completion.json').write_text(json.dumps({'status':'all_native_review_save_and_checks_passed','results':results},indent=2)+'\n')
