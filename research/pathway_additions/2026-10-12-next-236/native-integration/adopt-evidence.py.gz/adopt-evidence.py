"""Verify complete sealed inputs; adopt reviewed QA and actual root evidence losslessly."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,stat,sys
P=Path('/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012')
sys.path.insert(0,str(P));import common as c
R=c.ROOT;REL=Path(c.DOSSIER)/'native-integration';D=R/REL
QA=Path('/private/tmp/pathwaymech-next-236-maintained-independent-qa-20261012')
RQ=Path('/private/tmp/pathwaymech-next-236-root-maintained-qa-20261012')
A=Path('/private/tmp/pathwaymech-next-236-root-maintained-review-acceptance-20261012.json')
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 assert c.regular_bytes(p)==b
def js(v):return (json.dumps(v,indent=2)+'\n').encode()
def closure(root,hsha,msha,count,dirs_count=None):
 assert c.pin(root/'handoff.json')['sha256']==hsha
 h=c.load(root/'handoff.json');m=c.load(root/'artifact-manifest.json')
 assert c.pin(root/'artifact-manifest.json')['sha256']==msha==h['manifest']['sha256']
 seen=set();ds=set()
 for base,dirs,files in os.walk(root,followlinks=False):
  ds.add(str(Path(base).relative_to(root)))
  assert all(not (Path(base)/n).is_symlink() for n in dirs)
  seen.update(str((Path(base)/n).relative_to(root)) for n in files)
 assert seen=={x['relative_path'] for x in m['artifacts']}|{'handoff.json','artifact-manifest.json'}
 assert ds==set(m['directories'])|{'.'}
 assert len(m['artifacts'])==count
 if dirs_count is not None:assert len(ds-{'.'})==dirs_count
 for x in m['artifacts']:c.verify(x,root/c.relative(x['relative_path']))
 return h
assert not D.exists()
assert c.pin(A)['sha256']=='8d4d91d42ffdd9ba42ab6a439283b6a1f5e2a8a68b61bda79244f7f77d2b4262'
accept=c.load(A);assert not accept['findings']
h=closure(QA,'eb683e307adeb0d8bb7929220d4921f63901d83e93380ddd79420550ae068f2e','e163cb1de17a35e855689031e9c7bf0de6f39e4c3f22af50b63eea88717d942c',252,41)
closure(RQ,'afc0c22ecaa35094ad907d369f86114a9e9c5914d9732b88ae0f6e6d4dcb4c40','f5e60f5bb246f04cd80caff185aeaabfe61bb9c387b4180118a5cc75176fa826',26)
G=Path('/private/tmp/pathwaymech-next-236-local-native-execution-20261012')
for phase in ['history-and-generation','remaining-offline-gates','vendored-gate','final-gates']:
 assert c.load(G/phase/'completion.json')['status']=='phase_passed'
groups=[(G,Path('gates')),(Path('/private/tmp/pathwaymech-next-236-graph-preview-20261012'),Path('visual')),(RQ,Path('root-review')),(Path('/private/tmp/pathwaymech-next-236-local-adoption-root-20261012'),Path('root-adoption')),(Path('/private/tmp/pathwaymech-next-236-local-integration-independent-review-20261012'),Path('preparation-independent-review'))]
sources=[]
for source,target in groups:
 for base,dirs,files in os.walk(source,followlinks=False):
  assert all(not (Path(base)/n).is_symlink() for n in dirs)
  for n in sorted(files):
   p=Path(base)/n;sources.append((p,target/p.relative_to(source)))
sources += [(Path('/private/tmp/pathwaymech-next-236-root-local-adoption-acceptance-20261012.json'),Path('adoption-acceptance.json')),(A,Path('qa-acceptance.json')),(Path('/private/tmp/pathwaymech-next-236-root-run-native-20261012.py'),Path('native-stage-runner.py')),(Path('/private/tmp/pathwaymech-next-236-seal-root-qa-20261012.py'),Path('seal-root-qa.py')),(Path(__file__),Path('adopt-evidence.py'))]
payload=[];entries=[]
for source,relative in sources:
 raw=c.regular_bytes(source);compress=source.suffix in {'.py','.stdout','.stderr','.svg'} or len(raw)>100000 and source.suffix=='.json'
 body=gzip.compress(raw,mtime=0) if compress else raw
 rel=Path(str(relative)+'.gz') if compress else relative
 payload.append((D/rel,body));entries.append({'source':str(source),'original':pin(raw),'owner':str(REL/rel),'encoding':'gzip' if compress else 'identity','stored':pin(body)})
plan=c.load(QA/'copy-plan.json');c.verify(h['copy_plan'],QA/'copy-plan.json');assert len(plan['files'])==126
for x in plan['files']:
 p=Path(x['payload_path']);b=c.regular_bytes(p);assert pin(b)=={'bytes':x['bytes'],'sha256':x['sha256']}
 if 'source_path' in x:
  raw=gzip.decompress(b) if x['gzip_encoded'] else b
  assert pin(raw)=={'bytes':x['decoded_bytes'],'sha256':x['decoded_sha256']}
  assert raw==c.regular_bytes(Path(x['source_path']))
 else:assert p==QA/'payload/package-index.json' and not x['gzip_encoded']
 dest=R/c.relative(x['repository_path']);assert dest.is_relative_to(D/'independent-qa');payload.append((dest,b))
for n in ['artifact-manifest.json','handoff.json','copy-plan.json']:
 payload.append((D/'independent-qa'/('external-'+n),c.regular_bytes(QA/n)))
readme='''# Actual local acetoacetate integration evidence

The accepted acetoacetate degradation record and authority adapter are integrated on local baseline 9bd87745d842b0602d027f3d15d26bbc178474a6. Two native histories preceded SSSOM and first render. All nine required gates passed, including 4,273 tests (three skips and three dependency warnings). Four phase receipts preserve twelve successful commands and exact streams; no initial DNS failure occurred in this execution.

Root and independent maintained QA passed. Current graph/table QA covers all 25 visual nodes, 46 arrows, one qualified construct, 25 named identities and 66 references. Static light-theme limitations remain dense label overlap and one truncated construct label, whose whole text and evidence are in the table. No browser interaction is claimed. Complete scientific interpretation is inherited explicitly from accepted source reviews. Historical identity dispositions preserve their earlier planning status; current implementation and actual native outputs passed separately.

The hidden/ignored physical census before this evidence adoption preserves all old owners outside the exact integration plan, all 800 shared-cache identities, 236 old records/pages, 116 review pairs and 400 old histories. Current corpus size is 237. Source and ontology snapshots, both KGX surfaces and the five new SSSOM rows equal accepted outputs; previous authority objects and graph contexts remain intact. RHEA:21038 clears only its aggregate direction while preserving earlier contextual directions.

root-storage-map.json maps complete original root execution/review/visual bodies to exact durable owners. Gzip is lossless transport, and historical absolute paths inside originals resolve through that map. The independent-qa copy plan separately binds every reviewed payload. Primary scientific originals remain available through the parent portable index without duplication. Native review input extension, save and append-only checking are recorded later under finalization. No source normalization, scientific status promotion or new history is implied by saving reviews.

This is a local integration only. No push, PR, merge, branch deletion, issue closure, licensing clearance or source-exhaustion claim is made.
'''
payload.append((D/'README.md',readme.encode()))
storage={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries,'purpose':'Complete lossless root receipts and accepted judgment authorization; historical source paths resolve through this map.','hidden_and_ignored_files_included':True,'publication':False}
payload.append((D/'root-storage-map.json',js(storage)))
assert len({p for p,b in payload})==len(payload) and all(not p.exists() for p,b in payload)
for p,b in payload:write(p,b)
out={'status':'exact_root_and_independent_evidence_adopted','root_storage_entries':len(entries),'independent_payload_owners':126,'total_files':len(payload),'stored_bytes':sum(len(b) for p,b in payload),'root_storage_map':c.pin(D/'root-storage-map.json'),'review_acceptance':c.pin(A),'no_judgment_changes':True}
c.write_new('/private/tmp/pathwaymech-next-236-evidence-adoption-receipt-20261012.json',out)
print(json.dumps(out))
