"""Record exact root maintained QA executions; no scientific or product edits."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
P=Path(__file__).parent
ROOT=Path('/private/tmp/pathwaymech-next-236-local-20261012')
name=sys.argv[1]
assert name in ('target','checkout')
script=P/('check_target.py' if name=='target' else 'check_checkout.py')
argv=['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B',str(script)]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'}
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic();body=pin(script)
with (P/(name+'.stdout')).open('xb') as out,(P/(name+'.stderr')).open('xb') as err:
 r=subprocess.run(argv,cwd=ROOT,env={**os.environ,**env},stdout=out,stderr=err)
v={'argv':argv,'cwd':str(ROOT),'environment':env,'helper_at_start':body,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':time.monotonic()-tick,'exit_code':r.returncode,'stdout':pin(P/(name+'.stdout')),'stderr':pin(P/(name+'.stderr'))}
assert pin(script)==body
with (P/(name+'.execution.json')).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
print(json.dumps(v));raise SystemExit(r.returncode)
