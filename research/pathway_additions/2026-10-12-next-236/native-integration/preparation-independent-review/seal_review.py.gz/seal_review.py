"""Seal only this bounded independent review; preserve synthetic fixtures inertly."""
import datetime,hashlib,json,os,shutil,stat,zipfile
from pathlib import Path
R=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012')
def bind(p):
 p=Path(p);mode=p.lstat().st_mode;assert stat.S_ISREG(mode)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def load(p):return json.loads(Path(p).read_bytes())
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def inventory(root):
 files=[];dirs=[]
 for here,children,names in os.walk(root,followlinks=False):
  here=Path(here);dirs.append(str(here.relative_to(root)));assert all(not (here/n).is_symlink() for n in children)
  files.extend(here/n for n in names)
 return sorted(files),sorted(dirs)
root=R/'fixtures';archive=R/'fixtures.zip';rows=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for here,dirs,names in os.walk(root,followlinks=False):
  for name in sorted(dirs+names):
   p=Path(here,name);mode=p.lstat().st_mode;directory=stat.S_ISDIR(mode);alias=stat.S_ISLNK(mode);fifo=stat.S_ISFIFO(mode)
   assert directory or alias or fifo or stat.S_ISREG(mode)
   rel=str(p.relative_to(root))+('/' if directory else '');body=b'' if directory or fifo else os.readlink(p).encode() if alias else p.read_bytes()
   info=zipfile.ZipInfo(rel);info.create_system=3;info.external_attr=mode<<16;z.writestr(info,body)
   rows.append({'member':rel,'mode':mode,'type':'directory' if directory else 'literal_symlink' if alias else 'FIFO_placeholder' if fifo else 'regular','bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'literal_target':body.decode() if alias else None})
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())=={r['member'] for r in rows}
 for row in rows:
  info=z.getinfo(row['member']);body=z.read(info);assert info.external_attr>>16==row['mode'] and len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
  if row['literal_target'] is not None:assert body.decode()==row['literal_target']
write(R/'fixture-accounting.json',{'archive':bind(archive),'original_root':str(root),'members':rows,'literal_aliases':sum(r['type']=='literal_symlink' for r in rows),'FIFO_placeholders':sum(r['type']=='FIFO_placeholder' for r in rows),'complete_type_membership_body_verification':True})
shutil.rmtree(root)
write(R/'read-coverage.json',{'reviewer':'Codex /root/deoxy237_science_review','independence':'Independent of local integration preparation author; earlier canonical preparation authored by this agent is disclosed and inherited, not independently rereviewed as science.',
 'complete_helper_report_stage_reads':[bind(P/n) for n in ['REPORT.md','common.py','adopt.py','verify_portable.py','split_archive.py','bootstrap.py','capture.py','package_evidence.py','prepare_plan.py','finish.py','run_step.py','archive_controls.py','helper-lineage.json','helper-rebase.patch','stages.json']],
 'full_scope_and_programmatic_objects':['plan: complete target, accepted inputs and destination scope read; complete hashes/before state/modes compared in audit','whole manifest','baseline files/directories','cache baseline','270 runtime owner map','semantic preservation','portable body/index inventories','preparation archive proof','actual author receipt/helper lineage'],
 'native_sources_read':[bind(Path('/private/tmp/pathwaymech-next-236-local-20261012')/n) for n in ['src/pathwaymech/sssom.py','scripts/new_history_record.py']],
 'guard_source':bind(Path('/private/tmp/pathwaymech-next-235-local-integration-independent-review-20261012/test_controls.py')),
 'science_and_runtime':'Inherited accepted science and actual output review; no new paper, SQL or production gate claim',
 'diagnostics':['Unrelated /private/tmp/codex-daemon-501 permission denial in directory discovery; not an exhaustive absence conclusion.','Combined text output truncated; affected native history tail and plan scope reread separately.']})
assert load(R/'audit.json')['exit_code']==load(R/'reused-guards.json')['exit_code']==0
assert (R/'audit.stderr').stat().st_size==(R/'reused-guards.stderr').stat().st_size==0
result=load(R/'audit-results.json');assert result['status']=='passed'
assert bind(P/'handoff.json')['sha256']=='7455f6b4e0f57ca519e8ed5c8eb134f190d61e34ad1da1abece467d1bca5288d'
assert bind(P/'artifact-manifest.json')['sha256']=='ae7ea8b87504aec49dd894c118294a40ce458fc8ccb04b19395a5b8d70dba52e'
m=load(P/'artifact-manifest.json');files,dirs=inventory(P)
assert set(files)=={P/r['relative_path'] for r in m['artifacts']}|{P/'handoff.json',P/'artifact-manifest.json'}
assert [d for d in dirs if d!='.']==m['directories']
for row in m['artifacts']:
 got=bind(P/row['relative_path']);assert all(got[k]==row[k] for k in got)
write(R/'disposition.json',{'status':'exact_local_integration_preparation_independently_accepted_pending_root_adoption_approval','findings':[],
 'reviewer':'Codex /root/deoxy237_science_review','started_at':'2026-10-12T20:40:16Z','finished_at':datetime.datetime.now(datetime.UTC).isoformat(),
 'subject_handoff':bind(P/'handoff.json'),'subject_manifest':bind(P/'artifact-manifest.json'),'final_fresh_subject_closure':{'artifacts':335,'seals':2,'directories_including_root':len(dirs),'hidden_ignored_included':True},
 'exact_primary_owners':24,'dossier_owners':10,'reused_guard_tests_passed':42,'portable_bodies_verified':2353,'SSSOM_additions':5,'effective_configuration_bridge':'Actual855 manifest; unchanged native Rhea override; retained runtime831 not adopted',
 'baseline_and_cache_pre_post_exact':True,'Git_identity':'inherited bound clean capture; no fresh Git command','science':'inherited exact accepted interpretation and actual outputs',
 'actual_adoption_native_gates_history_Git_GitHub_SQL_read':False,'publication_authorized':False,'next':'Separate exact root adoption acceptance, then native histories/SSSOM before render/gates, actual maintained QA and native reviews.'})
files,dirs=inventory(R);rows=[bind(p) for p in files]
write(R/'artifact-manifest.json',{'artifacts':rows,'count':len(rows),'directories':dirs,'hidden_ignored_included':True})
manifest=bind(R/'artifact-manifest.json')
write(R/'handoff.json',{'status':'exact_local_integration_preparation_independently_accepted_pending_root_adoption_approval','manifest':manifest,'artifacts':len(rows),'seals':2,
 'report':bind(R/'REPORT.md'),'disposition':bind(R/'disposition.json'),'subject':bind(P/'handoff.json'),'findings':[],
 'results':bind(R/'audit-results.json'),'checks':[bind(R/n) for n in ['audit.json','reused-guards.json']],
 'fixture_accounting':bind(R/'fixture-accounting.json'),'scope':'Bounded integration preparation audit; science inherited; no maintained adoption/history/gates/Git/GitHub/SQL reads.'})
files2,dirs2=inventory(R);assert dirs2==dirs and set(files2)=={Path(r['path']) for r in rows}|{R/'artifact-manifest.json',R/'handoff.json'}
for row in rows:assert bind(row['path'])==row
assert bind(R/'artifact-manifest.json')==manifest
print(json.dumps({'handoff':bind(R/'handoff.json'),'manifest':manifest,'artifacts':len(rows),'seals':2,'directories':len(dirs)},indent=2))
