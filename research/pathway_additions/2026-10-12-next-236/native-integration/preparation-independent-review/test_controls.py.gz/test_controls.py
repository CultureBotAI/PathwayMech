"""Isolated negative controls for the local-only adoption and portable resolver."""

import copy
import gzip
import hashlib
import io
import json
import os
import zipfile

import pytest

import adopt
import common as c
import verify_portable as portable


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    root = tmp_path / "checkout"
    package = tmp_path / "package"
    root.mkdir()
    (package / "payload").mkdir(parents=True)
    (root / "owner.txt").write_text("before\n")
    (package / "payload/owner.txt").write_text("after\n")
    monkeypatch.setattr(c, "ROOT", root)
    monkeypatch.setattr(c, "HERE", package)
    monkeypatch.setattr(c, "PRIMARY", frozenset({"owner.txt"}))
    before, dirs = c.inventory(root)
    c.write_new(package / "baseline-files.json", before)
    c.write_new(package / "baseline-directories.json", dirs)
    row = {
        "destination": "owner.txt",
        "before": before[0],
        "executable": False,
        "payload": c.pin(package / "payload/owner.txt"),
    }
    plan = {
        "target": str(root),
        "baseline_commit": c.BASE,
        "baseline_tree": c.TREE,
        "branch": c.BRANCH,
        "local_only": True,
        "publication_authorized": False,
        "shared_cache_mutation": False,
        "changes": [row],
    }
    monkeypatch.setattr(c, "git_check", lambda clean: None)
    return root, package, plan


def test_exact_scope_and_baseline(fixture):
    _, _, plan = fixture
    assert len(c.scope_check(plan)) == 1
    c.checkout_check(plan)


@pytest.mark.parametrize(
    "key,value",
    [
        ("baseline_commit", "wrong"),
        ("baseline_tree", "wrong"),
        ("branch", "wrong"),
        ("target", "/private/tmp/wrong"),
        ("local_only", False),
        ("publication_authorized", True),
        ("shared_cache_mutation", True),
    ],
)
def test_wrong_contract(fixture, key, value):
    _, _, plan = fixture
    plan[key] = value
    with pytest.raises(ValueError, match="contract"):
        c.scope_check(plan)


def test_duplicate_destination(fixture):
    _, _, plan = fixture
    plan["changes"].append(copy.deepcopy(plan["changes"][0]))
    with pytest.raises(ValueError, match="Duplicate"):
        c.scope_check(plan)


def test_unplanned_payload(fixture):
    _, package, plan = fixture
    (package / "payload/unexpected").write_text("extra")
    with pytest.raises(ValueError, match="population"):
        c.scope_check(plan)


def test_wrong_payload_owner(fixture):
    _, _, plan = fixture
    plan["changes"][0]["payload"]["path"] += ".other"
    with pytest.raises(ValueError, match="owner path"):
        c.scope_check(plan)


def test_wrong_before_identity(fixture):
    _, _, plan = fixture
    plan["changes"][0]["before"]["path"] = "different.txt"
    with pytest.raises(ValueError, match="before owner"):
        c.scope_check(plan)


@pytest.mark.parametrize("name", [".hidden", "ignored.pyc", "unexpected-dir"])
def test_full_hidden_ignored_and_empty_dir_scope(fixture, name):
    root, _, plan = fixture
    p = root / name
    p.mkdir() if name.endswith("dir") else p.write_text("extra")
    with pytest.raises(ValueError, match="Full local"):
        c.checkout_check(plan)


def test_executable_drift(fixture):
    root, _, plan = fixture
    (root / "owner.txt").chmod(0o755)
    with pytest.raises(ValueError, match="inventory"):
        c.checkout_check(plan)


@pytest.mark.parametrize("kind", ["symlink", "fifo", "directory"])
def test_type_before_read(tmp_path, kind):
    p = tmp_path / "owner"
    if kind == "symlink":
        target = tmp_path / "target"
        target.write_text("same")
        p.symlink_to(target)
    elif kind == "fifo":
        os.mkfifo(p)
    else:
        p.mkdir()
    with pytest.raises(ValueError):
        c.regular_bytes(p)


def test_parent_link_before_read(tmp_path):
    d = tmp_path / "directory"
    d.mkdir()
    (d / "owner").write_text("body")
    link = tmp_path / "alias"
    link.symlink_to(d, target_is_directory=True)
    with pytest.raises(ValueError, match="Literal link"):
        c.regular_bytes(link / "owner")


@pytest.mark.parametrize(
    "value", ["../escape", "/absolute", "a/../b", "./a", "a//b", "."]
)
def test_unsafe_relative(value):
    with pytest.raises(ValueError):
        c.relative(value)


def test_cache_same_byte_retarget(tmp_path, monkeypatch):
    cache = tmp_path / "cache"
    cache.mkdir()
    a, b = tmp_path / "a", tmp_path / "b"
    a.write_text("same")
    b.write_bytes(a.read_bytes())
    link = cache / "source"
    link.symlink_to(a)
    row = {
        **c.pin(a),
        "path": str(link),
        "file_type": "symlink",
        "link_text": str(a),
        "resolved_path": str(a),
    }
    c.write_new(tmp_path / "cache-baseline.json", [row])
    monkeypatch.setattr(c, "HERE", tmp_path)
    monkeypatch.setattr(c, "CACHE", cache)
    c.cache_check()
    link.unlink()
    link.symlink_to(b)
    with pytest.raises(ValueError, match="literal cache link"):
        c.cache_check()


def test_approval_exact_handoff_and_review(fixture):
    root, package, _ = fixture
    c.write_new(package / "handoff.json", {"stage": "local-only"})
    (package / "review.json").write_text("{}\n")
    a = {
        "status": "accepted_exact_aceto236_local_integration_for_adoption",
        "reviewer": "Codex /root",
        "local_only": True,
        "publication_authorized": False,
        "shared_cache_mutation": False,
        "history_before_first_render": True,
        "target": str(root),
        "commit": c.BASE,
        "tree": c.TREE,
        "handoff": c.pin(package / "handoff.json"),
        "independent_review": c.pin(package / "review.json"),
    }
    p = package / "approval.json"
    c.write_new(p, a)
    c.approval_check(p, c.load(package / "handoff.json"))
    for key in (
        "status",
        "reviewer",
        "local_only",
        "publication_authorized",
        "shared_cache_mutation",
        "history_before_first_render",
        "target",
        "commit",
        "tree",
    ):
        bad = {**a, key: "wrong"}
        p.write_text(json.dumps(bad))
        with pytest.raises(ValueError, match="contract"):
            c.approval_check(p, c.load(package / "handoff.json"))
    p.write_text(json.dumps(a))
    (package / "review.json").write_text("changed")
    with pytest.raises(ValueError, match="Changed body"):
        c.approval_check(p, c.load(package / "handoff.json"))


def test_execute_prewrite_rejection(fixture, monkeypatch, tmp_path):
    root, _, plan = fixture
    approval = tmp_path / "approval"
    approval.write_text("receipt")
    output = tmp_path / "new-output"

    def fail():
        raise ValueError("Synthetic cache drift")

    monkeypatch.setattr(c, "cache_check", fail)
    with pytest.raises(ValueError, match="Synthetic"):
        adopt.execute(plan, c.pin(approval), output)
    assert (root / "owner.txt").read_text() == "before\n"
    assert not output.exists()


def test_execute_exact_isolated_roundtrip(fixture, monkeypatch, tmp_path):
    root, package, plan = fixture
    approval = tmp_path / "approval"
    approval.write_text("receipt")
    c.write_new(package / "handoff.json", {"synthetic": True})
    monkeypatch.setattr(c, "cache_check", lambda: None)
    monkeypatch.setattr(c, "sealed_check", lambda: None)
    output = tmp_path / "execution"
    adopt.execute(plan, c.pin(approval), output)
    assert (root / "owner.txt").read_text() == "after\n"
    assert c.load(output / "receipt.json")["publication_performed"] is False
    c.checkout_check(plan, adopted=True)


def test_existing_output_rejected(tmp_path):
    with pytest.raises(ValueError):
        adopt.output_check(str(tmp_path))


@pytest.fixture
def portable_fixture(tmp_path):
    root = tmp_path / "portable-checkout"
    archive = root / c.DOSSIER / "archives"
    archive.mkdir(parents=True)
    body = b"whole source body\n"
    sha = hashlib.sha256(body).hexdigest()
    virtual = c.DOSSIER + "/archives/evidence-bodies.zip"
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("blobs/" + sha, body)
    archive_body = stream.getvalue()
    part_rows = []
    split = len(archive_body) // 2
    for index, part_body in enumerate((archive_body[:split], archive_body[split:]), 1):
        p = archive / f"evidence-bodies.zip.part-{index:03d}"
        p.write_bytes(part_body)
        part_rows.append(
            {
                "repository_relative_path": p.relative_to(root).as_posix(),
                "bytes": len(part_body),
                "sha256": hashlib.sha256(part_body).hexdigest(),
            }
        )
    index = {
        "format": "lossless-content-addressed-evidence-v1",
        "body_lookup": {
            sha: {
                "kind": "repository_chunked_zip_member",
                "repository_relative_path": virtual,
                "archive_bytes": len(archive_body),
                "archive_sha256": hashlib.sha256(archive_body).hexdigest(),
                "archive_parts": part_rows,
                "member": "blobs/" + sha,
                "sha256": sha,
                "bytes": len(body),
            }
        },
        "packet_inventories": [],
        "standalone_owners": [],
        "original_groups": {},
    }

    def save():
        (root / c.DOSSIER / "evidence-index.json.gz").write_bytes(
            gzip.compress(json.dumps(index).encode(), mtime=0)
        )

    save()
    return root, index, sha, save


def test_portable_roundtrip_requires_no_external_originals(portable_fixture):
    root, _, _, _ = portable_fixture
    got = portable.verify(root)
    assert got["unique_bodies"] == 1
    assert got["external_tmp_original_reads"] is False
    assert got["extracted_files"] == 0


@pytest.mark.parametrize("mode", ["reordered", "duplicate", "corrupted", "symlink"])
def test_portable_part_identity_controls(portable_fixture, mode):
    root, index, sha, save = portable_fixture
    parts = index["body_lookup"][sha]["archive_parts"]
    if mode == "reordered":
        parts.reverse()
    elif mode == "duplicate":
        parts.append(copy.deepcopy(parts[0]))
    else:
        p = root / parts[0]["repository_relative_path"]
        if mode == "corrupted":
            p.write_bytes(p.read_bytes() + b"changed")
        else:
            target = root / "same-body"
            target.write_bytes(p.read_bytes())
            p.unlink()
            p.symlink_to(target)
    save()
    with pytest.raises(ValueError):
        portable.verify(root)


@pytest.mark.parametrize("mode", ["wrong_sha", "noncanonical_member", "unsafe_part"])
def test_portable_owner_identity_controls(portable_fixture, mode):
    root, index, sha, save = portable_fixture
    loc = index["body_lookup"][sha]
    if mode == "wrong_sha":
        loc["sha256"] = "0" * 64
    elif mode == "noncanonical_member":
        loc["member"] = "../source"
    else:
        loc["archive_parts"][0]["repository_relative_path"] = "../escape"
    save()
    with pytest.raises(ValueError):
        portable.verify(root)


def test_portable_original_cannot_omit_its_body(portable_fixture):
    root, index, _, save = portable_fixture
    index["standalone_owners"] = [{"type": "regular", "sha256": "0" * 64, "bytes": 17}]
    save()
    with pytest.raises(ValueError, match="Unresolvable"):
        portable.verify(root)


def test_portable_archive_rejects_unindexed_members(portable_fixture):
    root, index, sha, save = portable_fixture
    loc = index["body_lookup"][sha]
    body = b"".join(
        (root / p["repository_relative_path"]).read_bytes()
        for p in loc["archive_parts"]
    )
    stream = io.BytesIO(body)
    with zipfile.ZipFile(stream, "a") as z:
        z.writestr("blobs/" + "0" * 64, b"unindexed")
    changed = stream.getvalue()
    p = root / loc["archive_parts"][0]["repository_relative_path"]
    p.write_bytes(changed)
    loc["archive_parts"] = [
        {
            "repository_relative_path": p.relative_to(root).as_posix(),
            "bytes": len(changed),
            "sha256": hashlib.sha256(changed).hexdigest(),
        }
    ]
    loc["archive_bytes"] = len(changed)
    loc["archive_sha256"] = hashlib.sha256(changed).hexdigest()
    save()
    with pytest.raises(ValueError, match="Extra or omitted"):
        portable.verify(root)


def test_partial_execution_failure_is_explicit(fixture, monkeypatch, tmp_path):
    root, _, plan = fixture
    approval = tmp_path / "approval"
    approval.write_text("receipt")
    monkeypatch.setattr(c, "cache_check", lambda: None)

    def fail_after_adoption():
        raise ValueError("Synthetic post-adoption seal drift")

    monkeypatch.setattr(c, "sealed_check", fail_after_adoption)
    output = tmp_path / "failed-execution"
    with pytest.raises(ValueError, match="Synthetic"):
        adopt.execute(plan, c.pin(approval), output)
    assert (root / "owner.txt").read_text() == "after\n"
    receipt = c.load(output / "failure.json")
    assert receipt["status"] == "failed_partial_state_must_be_inspected"
    assert receipt["completed_destinations"] == ["owner.txt"]
    assert not (output / "receipt.json").exists()
