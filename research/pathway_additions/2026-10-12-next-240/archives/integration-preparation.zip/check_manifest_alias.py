"""Focused checks for only the historical file/regular manifest spelling."""
import hashlib,json,os
from pathlib import Path
from package_evidence import Store
H=Path(__file__).parent
fixture=H/'manifest-alias-fixture';fixture.mkdir()
p=fixture/'body';p.write_bytes(b'whole original\n');alias=fixture/'alias';alias.symlink_to('body')
class Sink:
    def put(self,b):return hashlib.sha256(b).hexdigest()
s=Sink();binding={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
checks=[]
for typ in ['file','regular']:
 r=Store.owner(s,p,{**binding,'file_type':typ});assert r['type']=='regular';checks.append({'case':typ+' accepted for actual regular','passed':True})
for target,extra in [(alias,{'file_type':'file'}),(p,{'file_type':'symlink'}),(p,{'file_type':'file','sha256':'0'*64})]:
 try:Store.owner(s,target,{**binding,**extra})
 except AssertionError:checks.append({'case':str(target.name)+' rejects '+json.dumps(extra,sort_keys=True),'passed':True})
 else:raise AssertionError('incorrect type/hash accepted')
r=Store.owner(s,alias,{**binding,'file_type':'symlink','link_text':'body'});assert r['type']=='symlink' and r['link_text']=='body';checks.append({'case':'literal symlink remains distinct and exact','passed':True})
(H/'manifest-alias-checks.json').write_text(json.dumps({'scope':'six bounded spelling/type/hash controls; no guard framework or product change','checks':checks},indent=2)+'\n')
print(json.dumps({'controls':len(checks),'passed':True}))
