"""Bind exact240 whole-source scope into the unchanged239 integration mechanism."""
import ast,json
from pathlib import Path
H=Path(__file__).parent
SLUG='spermidine-biosynthesis-and-metabolism-escherichia-coli'
def edit(name,fn):
 p=H/name;s=fn(p.read_text());ast.parse(s);p.write_text(s)
def capture(s):
 s=s.replace('1e66867ec9eb4041e97ba03744f2891f1812ee653a40c17f2c28600152b8e7c8','951053a78a7123c8ac43019db578873877bd89d5b1c177dbb9543675fb3c4938')
 a=s.index('    selected = [');b=s.index('    for src, rel, digest in selected:',a)
 s=s[:a]+'''    selected = [
        (Path('/private/tmp/pathwaymech-next-240-scope-successor-20261012/draft/SLUG.yaml'), 'data/pathways/SLUG.yaml', '0adef1da2d818af7c62d7e3952b2115585b47b8f132ec189cde2b435d2721680'),
        (BUILD/'sources.json', 'data/identifier_authorities/sources.json', '6bb6f0e5b7def56b35cd94fc5828e9429e9c7025a1f93da5248f7838e91f2391'),
    ]
    assert c.regular_bytes(BUILD/'ontology.json') == c.regular_bytes(c.ROOT/'data/identifier_authorities/ontology.json')
'''.replace('SLUG',SLUG)+s[b:]
 s=s.replace('len(old_science) == 239','len(old_science) == 240')
 a=s.index('    inputs = [');b=s.index('    c.write_new(H / "accepted-inputs.json"',a)
 s=s[:a]+'''    selection=c.load(H/'baseline-selection.json')
    inputs=[ACCEPT,H/'root-target.json',Path(selection['commit_receipt']['path'])]+[
        Path('/private/tmp')/('pathwaymech-next-240-root-'+name+'-acceptance-20261012.json')
        for name in ['scientific','scope-successor','scoped-preview','authority-design','implementation','order','canonical-preparation']
    ]
'''+s[b:]
 s=s.replace('manifest887','manifest892');return s
edit('capture.py',capture)
def package(s):
 a=s.index('    suffixes = [');b=s.index('    for suffix in suffixes:',a)
 suffixes=['discovery','author','science-review','provisional-authority-feasibility','scope-successor','scope-successor-independent-review','scoped-graph-preview','authority-design','context-implementation','context-successor','context-order-successor','canonical-preparation','canonical-build','canonical-output-independent-review']
 s=s[:a]+'    suffixes = '+repr(suffixes)+'\n'+s[b:]
 s=s.replace('"pathwaymech-next-240-root-run-canonical-*.py",','"pathwaymech-next-240-run-canonical-*.py",\n        "pathwaymech-next-240-run-canonical-*.patch",')
 s=s.replace('for directory in ["root-canonical-execution"]:', '''for directory in ["canonical-execution", "context-independent-review", "context-order-probe", "root-context-finding", "root-order-review", "root-preparation-review", "graph-preview"]:''')
 a=s.index('    scientific = scientific_binding[');b=s.index('    # Every complete receipt descriptor',a)
 s=s[:a]+'''    attempts=scientific_binding['requests']
    assert len(attempts)==92
    scientific=[{'original':row['body'],'acquisition':row} for row in attempts if row.get('body')]
    assert len(scientific)==66
    native_originals=[
        {'role':'whole_current_BioPAX','whole_original':c.pin(Path('/private/tmp/pathwaymech-next-240-discovery-20261012/network-public/raw/SMP0002097.owl'))},
        {'role':'whole_current_PWML_unmodified','whole_original':c.pin(Path('/private/tmp/pathwaymech-next-240-discovery-20261012/network-public/raw/SMP0002097.pwml'))},
        {'role':'whole_archived_BioPAX_member','whole_original':c.pin(Path('/private/tmp/pathwaymech-next-240-discovery-20261012/archived/PW002085.owl'))},
    ]
'''+s[b:]
 s=s.replace('bind_receipts(scientific)','bind_receipts(attempts)')
 s=s.replace('    groups = {}', '''    archive_intake=c.load('/private/tmp/pathwaymech-next-240-discovery-20261012/intake.json')
    standalone.append(store.owner(archive_intake['acquisition']['path'],archive_intake['acquisition']))
    standalone.append(store.owner(archive_intake['archive']['path'],archive_intake['archive']))
    groups = {}''')
 s=s.replace('len(groups["manifest_originals"]) == 886','len(groups["manifest_originals"]) == 891').replace('len(groups["whole_scientific_originals"]) == 98','len(groups["whole_scientific_originals"]) == 66').replace('len(groups["scientific_native_originals"]) == 8','len(groups["scientific_native_originals"]) == 3').replace('len(record["references"]) == 93','len(record["references"]) == 42').replace('"current_reference_hashes_all_bound": 93','"current_reference_hashes_all_bound": 42')
 s=s.replace('"inherited238_"','"inherited239_"').replace('"inherited238_index"','"inherited239_index"').replace('No current239','No current240').replace('Earlier238','Earlier239')
 s=s.replace('"original_groups": groups,','"original_groups": groups,\n        "current_scientific_acquisition_attempts": attempts,\n        "current_acquisition_receipts": [r["receipt"] for r in attempts],')
 return s
edit('package_evidence.py',package)
def prepare(s):
 s=s.replace('before, after = c.load(c.ROOT / rel), c.load(PAY / rel)','before, after = c.load(c.ROOT / rel), c.load(PAY / rel if (PAY / rel).exists() else c.ROOT / rel)')
 s=s.replace('"actual_after": c.pin(PAY / rel),','"actual_after": c.pin(BUILD / (name + ".json")),\n            "adopted_owner": (PAY / rel).exists(),')
 s=s.replace('len(oldmanifest) == 874 and len(newmanifest) == 887','len(oldmanifest) == 887 and len(newmanifest) == 892').replace('newmanifest[:874]','newmanifest[:887]').replace('"manifest_prefix_rows": 874','"manifest_prefix_rows": 887').replace('"manifest_after_rows": 887','"manifest_after_rows": 892')
 s=s.replace('len(changes) == additions == 21','len(changes) == additions == 6').replace('(4303, 12008, 4320, 12052)','(4320, 12052, 4357, 12110)').replace('len(oldss) == 42','len(oldss) == 62').replace('len(added) == len(newss) == 20','len(added) == len(newss) == 4')
 a=s.index('        "aggregate_display_scope":');b=s.index('        "old_authority_object_exceptions"',a)
 s=s[:a]+'''        "aggregate_display_scope": "No aggregate field changes. Six existing nodes gain only exact accepted target source contexts; all old contexts and row order remain unchanged.",
'''+s[b:]
 a=s.index('    stages = c.load(')
 s=s[:a]+'''    stages=c.load(OLD/'stages.json')
    raw=json.dumps(stages).replace('pathwaymech-next-239','pathwaymech-next-240').replace('s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii','SLUG').replace('MetaCyc_PWY-8132','PathBank_SMP0002097')
    stages=json.loads(raw)
    findings=[{'local_key':key,'status':'resolved_in_accepted_successor','public_issue':None} for key in ['pathbank240-incomplete-interface-context','pathbank240-context-owner-order']]
    stages['history_before_first_render']['required_infrastructure_event'].update(owner='scripts/build_source_identifier_snapshot.py',description='Accepted280-file complete PathBank context runtime with deterministic ordering,892-row manifest and actual source snapshot; ontology unchanged.',issue_lineage=findings)
    def history(kind,slug,owner,event,summary,details):
        return [PY,'-B','scripts/new_history_record.py','--kind',kind,'--slug',slug,*owner,'--event',event,'--outcome','changed','--summary',summary,'--details',details,'--actor-name','codex','--agent-tool','codex','--model','gpt-6']
    stages['history_commands']=[
        history('record','SLUG',['--target-root','data/pathways'],'CREATE','Add complete evidence-backed E. coli spermidine biosynthesis and metabolism.','Exact accepted scoped PathBank:SMP0002097:18 paragraphs,58 edges,4 qualifiers,43 IDs,42 references and4 mappings; all four biochemical events plus transport,22 sides and generic SAM interface retained. Native assembly, taxon/construct, chemical-identity, transport and source-access limits remain. Whole original bodies and all92 acquisition attempts retained in research/pathway_additions/2026-10-12-next-240. Maintained gates/native review remain pending.'),
        history('infrastructure','pathbank240-native-authority',['--path','scripts/build_source_identifier_snapshot.py'],'EDIT','Integrate complete typed PathBank context and deterministic owner serialization.','Adopt reviewed280-file runtime via exact seven changed effective owners,892-row manifest retaining887 old entries, and actual source snapshot; ontology remains byte identical. Preserve both local findings pathbank240-incomplete-interface-context and pathbank240-context-owner-order, original failures and accepted dispositions. All old authority objects, first owners, graph rows and contexts remain exact. No aggregate field changes. Both histories precede SSSOM/render; maintained gates/native reviews remain pending.')]
    stages['after_gates']=[
        'Inspect actual PathBank:SMP0002097 page/graph and all18 paragraphs,58 edges,4 qualifiers,43 IDs,42 references and4 mappings against exact accepted scoped science and limits.',
        'Save independent scientific and technical native reviews after current inputs are inspected. Scientific author/preparation implementer is /root/deoxy237_science_review; fresh independent scientific review must be performed by a distinct reviewer, preserving inherited versus fresh readings.',
        'Preserve240 prior records/pages,124 review pairs,408 histories, every old authority object/order and all12052 old KGX edge/context payloads. Six shared nodes gain target contexts only; no aggregate or old row-order changes.',
        'Native SSSOM retains62 old complete rows and relative order plus4 exact target mappings by whole-row multiset,66 total. Native subject sorting is accepted.',
        'Recheck800 cache identities and full hidden/ignored checkout outside exact primary/dossier/history/generated/review scope; no publication.']
    stages['before_first_render_after_history'][0].update(reason='Export4 target mappings after both histories and before rendering/tests.',preservation='All62 old rows/cells/order/header exact;4 added whole rows and66 total. Compare additions by whole-row multiplicity.')
    interfaces=stages['native_review_interfaces']
    interfaces['inherited_science_handoff']=c.pin('/private/tmp/pathwaymech-next-240-science-review-20261012/handoff.json')
    interfaces['active_scope_successor_review']=c.pin('/private/tmp/pathwaymech-next-240-scope-successor-independent-review-20261012/handoff.json')
    interfaces['actual_native_review_handoff']=c.pin('/private/tmp/pathwaymech-next-240-canonical-output-independent-review-20261012/handoff.json')
    interfaces['save_template']=[PY,'-B','scripts/record_review.py','--repo-root',str(c.ROOT),'save','--content','<independently-reviewed-completed-review.json>']
    interfaces['check_after_save']=[PY,'-B','scripts/record_review.py','--repo-root',str(c.ROOT),'check','--require-reviews','--base',c.BASE]
    stages['preservation_counts']={k:semantic[k] for k in ['old_records','old_review_yaml','old_review_markdown','old_history_yaml']}
    assert stages['preservation_counts']=={'old_records':240,'old_review_yaml':124,'old_review_markdown':124,'old_history_yaml':408}
    c.write_new(H/'stages.json',stages)
    selection=c.load(H/'baseline-selection.json')
    DOS.mkdir(parents=True,exist_ok=True)
    c.write_new(DOS/'local-integration-decision.json',{'baseline_commit':c.BASE,'tree':c.TREE,'branch':c.BRANCH,'baseline_kind':'Clean committed239 local branch; not merged main','primary_owners':len(c.PRIMARY),'local_only':True,'publication_authorized':False,'shared_cache_mutation':False,'scientific_target':c.pin(PAY/'data/pathways/SLUG.yaml'),'actual_native_acceptance':c.pin('/private/tmp/pathwaymech-next-240-root-canonical-output-acceptance-20261012.json'),'baseline_postcommit_acceptance':selection['commit_receipt'],'local_findings':findings,'remaining':['root concrete preparation check','guarded local adoption','two histories before SSSOM/render','native gates','actual page and independent native reviews','preservation and local commit'],'source_exhaustion':False,'licensing':'Public-release licensing remains deferred; publication not authorized.'})
    print(json.dumps({k:semantic[k] for k in ['old_records','old_review_yaml','old_history_yaml','old_KGX','actual_after_KGX','exact_aggregate_changes']},indent=2))
    print('SSSOM planned additions',len(added))

if __name__=='__main__':main()
'''.replace('SLUG',SLUG)
 return s
edit('prepare_plan.py',prepare)
def finish(s):
 # The42controls last executed at238;239 inherited them. Preserve exact committed238 evidence.
 s=s.replace('"research/pathway_additions/2026-10-12-next-239/archives/integration-preparation.zip"','"research/pathway_additions/2026-10-12-next-238/archives/integration-preparation.zip"')
 s=s.replace('    with zipfile.ZipFile(inherited_archive) as z:', '    guard_origin = Path("/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012")\n    with zipfile.ZipFile(inherited_archive) as z:')
 s=s.replace('c.regular_bytes(OLD / member)','c.regular_bytes(guard_origin / member)').replace('c.load(OLD / "receipts/guard-controls.json")','c.load(guard_origin / "receipts/guard-controls.json")').replace('c.regular_bytes(OLD / "receipts/guard-controls.stdout")','c.regular_bytes(guard_origin / "receipts/guard-controls.stdout")').replace('c.pin(OLD / "receipts/guard-controls.json")','c.pin(guard_origin / "receipts/guard-controls.json")')
 s=s.replace('replay["originals"]["manifest_originals"] == 886','replay["originals"]["manifest_originals"] == 891').replace('replay["originals"]["whole_scientific_originals"] == 98','replay["originals"]["whole_scientific_originals"] == 66').replace('replay["originals"]["scientific_native_originals"] == 8','replay["originals"]["scientific_native_originals"] == 3')
 # Exact original239guard constants, not the older238 constants from its own lineage.
 a=s.index('    replacements = {');b=s.index('    patch = []',a)
 s=s[:a]+'''    replacements={
        '/pathwaymech-next-239-local-20261012':'/pathwaymech-next-240-local-20261012',
        '12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449':c.BASE,
        '67408fa8b7c7f46cf9014455d9b66c7a2458ebf5':c.TREE,
        'feat/pathway-next-239-local-20261012':c.BRANCH,
        '2026-10-12-next-239':'2026-10-12-next-240',
        'mar239':'pathbank240',
        'pathwaymech-next-239-local-adoption-':'pathwaymech-next-240-local-adoption-',
    }
'''+s[b:]
 return s
edit('finish.py',finish)
print('Configured bounded240 capture/whole portable evidence/semantic stages; no maintained writes.')
