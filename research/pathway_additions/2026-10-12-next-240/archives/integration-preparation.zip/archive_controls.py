"Retain small synthetic fixtures literally; special owners are inert metadata."

import json
import os
import stat
import zipfile
from pathlib import Path

import common as c


def main():
    root = Path("/private/tmp/pathwaymech-next-240-local-integration-controls-20261012")
    entries = []
    archive = c.HERE / "controls-fixtures.zip"
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for here, directories, names in os.walk(root, followlinks=False):
            for name in sorted(directories + names):
                path = Path(here) / name
                rel = path.relative_to(root).as_posix()
                mode = path.lstat().st_mode
                row = {"path": rel, "mode": mode}
                if stat.S_ISDIR(mode):
                    row["type"] = "directory"
                    body = b""
                    member = rel + "/"
                elif stat.S_ISREG(mode):
                    row.update(
                        type="regular", **{k: v for k, v in c.pin(path).items() if k != "path"}
                    )
                    body = c.regular_bytes(path)
                    member = rel
                elif stat.S_ISLNK(mode):
                    row.update(type="symlink", link_text=os.readlink(path))
                    body = row["link_text"].encode()
                    member = rel
                else:
                    row.update(
                        type="special", representation="metadata_only_not_opened_or_recreated"
                    )
                    entries.append(row)
                    continue
                info = zipfile.ZipInfo(member, (2026, 10, 12, 0, 0, 0))
                info.create_system = 3
                info.external_attr = mode << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, body)
                entries.append(row)
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist()))
        for row in entries:
            if row["type"] == "regular":
                assert z.read(row["path"]) == c.regular_bytes(root / row["path"])
            elif row["type"] == "symlink":
                assert z.read(row["path"]).decode() == row["link_text"]
    c.write_new(
        c.HERE / "controls-fixtures.json",
        {
            "root": str(root),
            "archive": c.pin(archive),
            "entries": entries,
            "all_regular_and_literal_link_archive_bytes_verified": True,
            "specials_metadata_only": True,
            "raw_synthetic_root_retained": True,
        },
    )
    print(json.dumps({"entries": len(entries), "archive": c.pin(archive)}))


if __name__ == "__main__":
    main()
