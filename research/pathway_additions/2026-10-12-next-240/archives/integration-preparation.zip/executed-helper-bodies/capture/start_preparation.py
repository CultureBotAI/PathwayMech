"""Bind clean committed239 target and minimally rebase accepted integration helpers."""
import ast,datetime,difflib,hashlib,json,os,subprocess
from pathlib import Path
H=Path(__file__).parent;OLD=Path('/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012');R=Path('/private/tmp/pathwaymech-next-240-local-20261012');PRE=Path('/private/tmp/pathwaymech-next-240-canonical-preparation-20261012');BUILD=Path('/private/tmp/pathwaymech-next-240-canonical-build-20261012')
SLUG='spermidine-biosynthesis-and-metabolism-escherichia-coli'
selection=json.loads((H/'baseline-selection.json').read_text());BASE=selection['commit'];TREE=selection['tree'];BRANCH='feat/pathway-next-240-local-20261012'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):
 with (H/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}).decode().strip()
assert git('rev-parse','HEAD')==BASE and git('rev-parse','HEAD^{tree}')==TREE and git('branch','--show-current')==BRANCH and not git('status','--porcelain=v1','--untracked-files=all')
write('root-target.json',{'target':str(R),'commit':BASE,'tree':TREE,'branch':BRANCH,'clean':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'captured_by':'Codex /root/deoxy237_science_review after root-authorized isolated worktree creation','root_local_commit':selection['commit_receipt'],'worktree_tool_provenance':selection['worktree_tool_provenance'],'baseline_selection':pin(H/'baseline-selection.json')})
inputs=json.loads((PRE/'input-bindings.json').read_bytes());plan=json.loads((PRE/'execution-plan.json').read_bytes());overrides={'conf/identifier_sources.json':BUILD/'manifest.json','conf/rhea_identifier_updates.json':BUILD/'rhea-updates.json'}
for key,arg in [('source_builder','--manifest'),('ontology_builder','--rhea-updates')]:
 argv=plan['commands'][key];assert Path(argv[argv.index(arg)+1]) in overrides.values()
rows=[]
for row in inputs['runtime']:
 rel=str(Path(row['staged']['path']).relative_to(PRE/'runtime'));actual=BUILD/'runtime'/rel
 for d in [row['origin'],row['staged']]:assert (pin(Path(d['path']))['bytes'],pin(Path(d['path']))['sha256'])==(d['bytes'],d['sha256'])
 assert pin(actual)['sha256']==row['origin']['sha256'];effective=overrides.get(rel,actual);before=pin(R/rel) if (R/rel).exists() else None;bound=pin(effective)
 rows.append({'relative_path':rel,'accepted':row['origin'],'effective_preparation':pin(Path(row['staged']['path'])),'actual_runtime':pin(actual),'effective_integration':bound,'override_reason':'Exact explicit configuration consumed by accepted native CLI' if rel in overrides else None,'before':before,'changed':before is None or before['sha256']!=bound['sha256']})
assert len(rows)==280
changed=sorted(r['relative_path'] for r in rows if r['changed']);assert len(changed)==7 and 'conf/identifier_sources.json' in changed and 'conf/rhea_identifier_updates.json' not in changed
assert pin(R/'data/identifier_authorities/ontology.json')['sha256']==pin(BUILD/'ontology.json')['sha256']
primary=sorted(changed+['data/pathways/'+SLUG+'.yaml','data/identifier_authorities/sources.json']);assert len(primary)==9
write('runtime-owner-map.json',{'runtime':rows,'runtime_count':280,'changed_runtime':len(changed),'primary':primary,'unchanged_ontology_not_adopted':{'before':pin(R/'data/identifier_authorities/ontology.json'),'accepted_actual':pin(BUILD/'ontology.json')},'explicit_native_configuration_inputs':{k:pin(v) for k,v in overrides.items()}})
def rebase(s):
 for a,b in [('pathwaymech-next-239','__CURRENT__'),('pathwaymech-next-238','pathwaymech-next-239'),('__CURRENT__','pathwaymech-next-240'),('2026-10-12-next-239','__DOSSIER__'),('2026-10-12-next-238','2026-10-12-next-239'),('__DOSSIER__','2026-10-12-next-240'),('feat/pathway-next-239','feat/pathway-next-240'),('12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449',BASE),('67408fa8b7c7f46cf9014455d9b66c7a2458ebf5',TREE),('mar239','pathbank240'),('s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii',SLUG),('MetaCyc:PWY-8132','PathBank:SMP0002097')]:s=s.replace(a,b)
 return s
lineage=[];patch=[]
for name in ['common.py','adopt.py','verify_portable.py','split_archive.py','run_step.py','test_controls.py','archive_controls.py','capture.py','package_evidence.py','prepare_plan.py','finish.py']:
 original=(OLD/name).read_text();s=rebase(original)
 if name=='common.py':
  tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PRIMARY' for t in n.targets));lines=s.splitlines(True);lines[n.lineno-1:n.end_lineno]=['PRIMARY = frozenset('+repr(primary)+')\n'];s=''.join(lines)
 ast.parse(s)
 with (H/name).open('x') as f:f.write(s)
 lineage.append({'name':name,'predecessor':pin(OLD/name),'initial_rebased':pin(H/name)})
 patch.extend(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='239/'+name,tofile='240/'+name))
write('initial-helper-lineage.json',lineage);(H/'initial-rebase.patch').write_text(''.join(patch))
print(json.dumps({'runtime':280,'changed_runtime':changed,'primary_owners':9,'primary':primary},indent=2))
