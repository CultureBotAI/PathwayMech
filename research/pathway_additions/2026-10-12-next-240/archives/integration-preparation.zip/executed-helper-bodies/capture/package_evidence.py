"Use the reviewed lossless CAS format; bind reproducible fixture trees externally."

import gzip
import hashlib
import io
import json
import os
import stat
import zipfile
from pathlib import Path

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
PRE = Path("/private/tmp/pathwaymech-next-240-canonical-preparation-20261012")


def digest(b):
    return hashlib.sha256(b).hexdigest()


def locate_member_name(row, root):
    name = row.get("relative_path", row.get("path"))
    p = Path(name)
    if p.is_absolute():
        p = p.relative_to(root)
    return str(c.relative(p.as_posix()))


class Store:
    def __init__(self):
        self.lookup = {}
        self.existing = {}
        self.archives = {}
        self.new = set()
        self.reused = set()
        for row in c.load(H / "baseline-files.json"):
            rel = row["path"]
            if (
                row["type"] == "regular"
                and rel not in c.PRIMARY
                and not rel.startswith(("pages/", "output/"))
            ):
                self.existing.setdefault(
                    row["sha256"],
                    {
                        "kind": "repository_file",
                        "repository_relative_path": rel,
                        "bytes": row["bytes"],
                        "sha256": row["sha256"],
                    },
                )
        # The 238 index already resolves earlier committed bodies, including ordered parts.
        index_path = (
            c.ROOT / "research/pathway_additions/2026-10-12-next-239/evidence-index.json.gz"
        )
        inherited = json.loads(gzip.decompress(c.regular_bytes(index_path)))
        for sha, loc in inherited["body_lookup"].items():
            self.existing.setdefault(sha, loc)
        amap = c.load(c.ROOT / "research/pathway_additions/2026-10-12-next-233/archive-map.json")
        for row in amap["archives"]:
            rel = row["repository_relative_path"]
            p = c.ROOT / rel
            c.verify(row["archive"], p)
            bound = c.pin(p)
            with zipfile.ZipFile(p) as z:
                assert len(z.namelist()) == len(set(z.namelist()))
                for entry in z.infolist():
                    if entry.filename.startswith("blobs/"):
                        sha = entry.filename[6:]
                        assert len(sha) == 64 and all(x in "0123456789abcdef" for x in sha)
                        self.existing.setdefault(
                            sha,
                            {
                                "kind": "repository_zip_member",
                                "repository_relative_path": rel,
                                "archive_bytes": bound["bytes"],
                                "archive_sha256": bound["sha256"],
                                "member": entry.filename,
                                "bytes": entry.file_size,
                                "sha256": sha,
                            },
                        )
        (DOS / "archives").mkdir(parents=True, exist_ok=True)
        self.archive_rel = c.DOSSIER + "/archives/evidence-bodies.zip"
        self.z = zipfile.ZipFile(PAY / self.archive_rel, "x", zipfile.ZIP_DEFLATED, compresslevel=9)

    def retrieve(self, loc):
        rel = loc["repository_relative_path"]
        if loc["kind"] == "repository_file":
            return c.regular_bytes(c.ROOT / rel)
        if rel not in self.archives:
            if loc["kind"] == "repository_chunked_zip_member":
                chunks = []
                for p in loc["archive_parts"]:
                    c.verify(p, c.ROOT / p["repository_relative_path"])
                    chunks.append(c.regular_bytes(c.ROOT / p["repository_relative_path"]))
                body = b"".join(chunks)
                assert (len(body), digest(body)) == (loc["archive_bytes"], loc["archive_sha256"])
                self.archives[rel] = zipfile.ZipFile(io.BytesIO(body))
            else:
                p = c.ROOT / rel
                c.verify({"bytes": loc["archive_bytes"], "sha256": loc["archive_sha256"]}, p)
                self.archives[rel] = zipfile.ZipFile(p)
        return self.archives[rel].read(loc["member"])

    def put(self, body):
        sha = digest(body)
        if sha in self.lookup:
            assert self.lookup[sha]["bytes"] == len(body)
            return sha
        if sha in self.existing:
            loc = self.existing[sha]
            assert self.retrieve(loc) == body
            self.reused.add(sha)
        else:
            info = zipfile.ZipInfo("blobs/" + sha, (2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            self.z.writestr(info, body)
            loc = {
                "kind": "repository_zip_member",
                "repository_relative_path": self.archive_rel,
                "member": info.filename,
                "bytes": len(body),
                "sha256": sha,
            }
            self.new.add(sha)
        self.lookup[sha] = loc
        return sha

    def owner(self, path, expected=None):
        p = Path(path)
        m = p.lstat().st_mode
        row = {"historical_path": str(p)}
        if stat.S_ISLNK(m):
            row.update(type="symlink", link_text=os.readlink(p))
            resolved = p.resolve(strict=True)
            row["resolved_path"] = str(resolved)
            if resolved.is_dir():
                return {**row, "resolution": "directory_alias_inert_not_recursively_followed"}
            if not stat.S_ISREG(resolved.lstat().st_mode):
                return {**row, "resolution": "special_target_not_opened"}
        elif stat.S_ISREG(m):
            row.update(type="regular", executable=bool(m & 0o111))
            resolved = p
        else:
            return {**row, "type": "special", "mode": stat.S_IFMT(m), "device": p.lstat().st_rdev}
        body = c.regular_bytes(resolved)
        if expected:
            assert (len(body), digest(body)) == (expected["bytes"], expected["sha256"]), p
            kind = expected.get("file_type", expected.get("type"))
            assert kind in [None, row["type"]], (p, kind)
            if "link_text" in expected:
                assert expected["link_text"] == row.get("link_text"), p
            if "resolved_path" in expected:
                assert expected["resolved_path"] == str(p.resolve(strict=True)), p
        return {**row, "bytes": len(body), "sha256": self.put(body)}

    def packet(self, root, omit=()):
        handoff = c.pin(root / "handoff.json")
        h = c.load(root / "handoff.json")
        manifest = h["manifest"]
        c.verify(manifest)
        assert Path(manifest["path"]) == root / "artifact-manifest.json"
        m = c.load(root / "artifact-manifest.json")
        expected = {locate_member_name(r, root): r for r in m["artifacts"]}
        assert len(expected) == len(m["artifacts"])
        physical = []
        omitted = []
        seen = set()
        dirs = []
        for here, children, names in os.walk(root, followlinks=False):
            for name in sorted(children + names):
                p = Path(here) / name
                rel = p.relative_to(root).as_posix()
                kind = p.lstat().st_mode
                if stat.S_ISDIR(kind):
                    dirs.append(rel)
                    continue
                seen.add(rel)
                if rel not in ["handoff.json", "artifact-manifest.json"]:
                    assert rel in expected, (root, rel)
                if any(rel == prefix or rel.startswith(prefix + "/") for prefix in omit):
                    row = expected[rel]
                    actual = {
                        "relative_path": rel,
                        "type": "symlink"
                        if stat.S_ISLNK(kind)
                        else "regular"
                        if stat.S_ISREG(kind)
                        else "special",
                        "declared_binding": row,
                        "current_stat_size": p.lstat().st_size,
                    }
                    if stat.S_ISLNK(kind):
                        actual["literal_link_text"] = os.readlink(p)
                    elif stat.S_ISREG(kind):
                        assert p.lstat().st_size == row["bytes"]
                    omitted.append(actual)
                else:
                    physical.append({"relative_path": rel, **self.owner(p, expected.get(rel))})
        # Declared followed views may exist through literal directory aliases; do not traverse them.
        declared_only = sorted(set(expected) - seen)
        declared = [
            {"relative_path": r, **self.owner(root / r, expected[r])}
            for r in sorted(expected)
            if r in seen and not any(r == p or r.startswith(p + "/") for p in omit)
        ]
        out = {
            "historical_root": str(root),
            "role": "Immutable scientific/runtime/review lineage; statuses and failures retained",
            "physical_hidden_ignored_no_follow_inventory": physical,
            "sealed_declared_file_views": declared,
            "historical_seals": {"handoff": handoff, "manifest": manifest},
            "physical_directory_membership": dirs,
            "portable_inventory_excludes_explicit_external_fixtures": bool(omit),
        }
        closure = {
            "root": str(root),
            "handoff": handoff,
            "manifest": manifest,
            "declared_artifacts": len(expected),
            "physical_files": len(seen),
            "directories": len(dirs),
            "external_fixture_prefixes": list(omit),
            "external_fixture_owners": omitted,
            "declared_followed_views_not_traversed": declared_only,
            "raw_fixture_hash_closure": (
                "Inherited exact sealed manifest, current physical membership/type"
                "/size observed; no fresh whole hash or portable-copy claim for om"
                "itted reproducible fixtures."
            ),
            "all_nonfixture_file_bodies_freshly_verified": True,
        }
        return out, closure

    def close(self):
        self.z.close()
        for z in self.archives.values():
            z.close()
        b = c.pin(PAY / self.archive_rel)
        for loc in self.lookup.values():
            if loc["repository_relative_path"] == self.archive_rel:
                loc.update(archive_bytes=b["bytes"], archive_sha256=b["sha256"])
        return b


def main():
    import yaml

    store = Store()
    packets, closures = [], []
    suffixes = [
        "discovery",
        "author",
        "science-review",
        "provisional-authority-feasibility",
        "scope-successor",
        "scope-successor-independent-review",
        "scoped-graph-preview",
        "authority-design",
        "context-implementation",
        "context-successor",
        "context-order-successor",
        "canonical-preparation",
        "canonical-build",
        "canonical-output-independent-review",
    ]
    for suffix in suffixes:
        root = Path("/private/tmp") / f"pathwaymech-next-240-{suffix}-20261012"
        print("Bind", root.name, flush=True)
        packet, closure = store.packet(root)
        assert not closure["declared_followed_views_not_traversed"]
        packets.append(packet)
        closures.append(closure)
    standalone = []
    for pattern in [
        "pathwaymech-next-240-root-*.json",
        "pathwaymech-next-240-run-canonical-*.py",
        "pathwaymech-next-240-run-canonical-*.patch",
    ]:
        for p in sorted(Path("/private/tmp").glob(pattern)):
            standalone.append(store.owner(p))
    for directory in [
        "canonical-execution",
        "context-independent-review",
        "context-order-probe",
        "root-context-finding",
        "root-order-review",
        "root-preparation-review",
        "graph-preview",
    ]:
        root = Path("/private/tmp") / f"pathwaymech-next-240-{directory}-20261012"
        for here, ds, names in os.walk(root, followlinks=False):
            assert all(not (Path(here) / n).is_symlink() for n in ds)
            for n in sorted(names):
                standalone.append(store.owner(Path(here) / n))
    source = c.load(PRE / "source-original-mapping.json")
    for key in [
        "scientific_reference_originals",
        "scientific_native_inventory",
        "prior_scientific_source_closure",
    ]:
        c.verify(source[key])
    scientific_binding = c.load(source["scientific_reference_originals"]["path"])
    attempts = scientific_binding["requests"]
    assert len(attempts) == 92
    scientific = [
        {"original": row["body"], "acquisition": row} for row in attempts if row.get("body")
    ]
    assert len(scientific) == 66
    native_originals = [
        {
            "role": "whole_current_BioPAX",
            "whole_original": c.pin(
                Path(
                    (
                        "/private/tmp/pathwaymech-next-240-discovery-20261012/network-publ"
                        "ic/raw/SMP0002097.owl"
                    )
                )
            ),
        },
        {
            "role": "whole_current_PWML_unmodified",
            "whole_original": c.pin(
                Path(
                    (
                        "/private/tmp/pathwaymech-next-240-discovery-20261012/network-publ"
                        "ic/raw/SMP0002097.pwml"
                    )
                )
            ),
        },
        {
            "role": "whole_archived_BioPAX_member",
            "whole_original": c.pin(
                Path("/private/tmp/pathwaymech-next-240-discovery-20261012/archived/PW002085.owl")
            ),
        },
    ]
    # Every complete receipt descriptor is kept, including archive parents and
    # inherited lineage; descriptor traversal does not reinterpret the science.
    receipt_descriptors = {}

    def bind_receipts(value):
        if isinstance(value, dict):
            if {"path", "bytes", "sha256"} <= set(value) and "/requests/" in value["path"]:
                receipt_descriptors[value["path"]] = value
            for child in value.values():
                bind_receipts(child)
        elif isinstance(value, list):
            for child in value:
                bind_receipts(child)

    bind_receipts(attempts)
    for row in receipt_descriptors.values():
        standalone.append(store.owner(row["path"], row))
    archive_intake = c.load("/private/tmp/pathwaymech-next-240-discovery-20261012/intake.json")
    standalone.append(
        store.owner(archive_intake["acquisition"]["path"], archive_intake["acquisition"])
    )
    standalone.append(store.owner(archive_intake["archive"]["path"], archive_intake["archive"]))
    groups = {}
    specs = [
        ("manifest_originals", source["manifest_originals"], "original"),
        ("whole_scientific_originals", scientific, "original"),
        ("scientific_native_originals", native_originals, "whole_original"),
    ]
    for key, values, field in specs:
        rows = []
        for row in values:
            original = row[field] if field else row
            rows.append(
                {
                    "original_metadata": original,
                    "source_context": row,
                    "portable_body": store.owner(original["path"], original),
                }
            )
        groups[key] = rows
    # Replay whole prior scientific originals through their accepted committed portable owners.
    prior_index_path = (
        c.ROOT / "research/pathway_additions/2026-10-12-next-239/evidence-index.json.gz"
    )
    prior_index = json.loads(gzip.decompress(c.regular_bytes(prior_index_path)))
    for key, rows in prior_index["original_groups"].items():
        inherited = []
        for row in rows:
            bodyrow = row["portable_body"]
            body = store.retrieve(prior_index["body_lookup"][bodyrow["sha256"]])
            assert (len(body), digest(body)) == (bodyrow["bytes"], bodyrow["sha256"])
            assert store.put(body) == bodyrow["sha256"]
            inherited.append(row)
        groups["inherited239_" + key] = inherited
    assert len(groups["manifest_originals"]) == 891
    assert len(groups["whole_scientific_originals"]) == 66
    assert len(groups["scientific_native_originals"]) == 3
    record = yaml.safe_load(
        c.regular_bytes(
            PAY / "data/pathways/spermidine-biosynthesis-and-metabolism-escherichia-coli.yaml"
        )
    )
    assert len(record["references"]) == 42
    assert all(ref["source_sha256"] in store.lookup for ref in record["references"])
    archive = store.close()
    index = {
        "format": "lossless-content-addressed-evidence-v1",
        "packet_inventories": packets,
        "standalone_owners": standalone,
        "original_groups": groups,
        "current_scientific_acquisition_attempts": attempts,
        "current_acquisition_receipts": [r["receipt"] for r in attempts],
        "body_lookup": store.lookup,
        "active_external_path_dependencies": False,
        ("links_and_specials"): (
            "Inert provenance metadata; retrieve whole bodies through body_lo"
            "okup, never recreate links or specials."
        ),
        ("external_fixture_policy"): (
            "No current240 packet omissions. Earlier239 synthetic-fixture exc"
            "lusions remain explicitly inherited in the committed predecessor"
            " index; no new whole-hash claim for them."
        ),
        "inherited239_index": c.pin(prior_index_path),
    }
    for name, value in [
        ("evidence-index.json.gz", index),
        ("external-packet-closures.json.gz", closures),
    ]:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode() + b"\n"
        (DOS / name).write_bytes(gzip.compress(raw, mtime=0))
    c.write_new(
        H / "packaging-summary.json",
        {
            "packets": len(packets),
            "unique_bodies": len(store.lookup),
            "unique_decoded_bytes": sum(v["bytes"] for v in store.lookup.values()),
            "new_bodies": len(store.new),
            "reused_committed_bodies": len(store.reused),
            "new_archive": archive,
            "original_group_counts": {k: len(v) for k, v in groups.items()},
            "omitted_reproducible_fixture_files": 0,
            "all_omissions_explicitly_bound": True,
            "all_scientific_originals_portable": True,
            "prior_fixture_body_hashes_inherited_not_freshly_repeated": True,
            "current_reference_hashes_all_bound": 42,
        },
    )
    print(json.dumps(c.load(H / "packaging-summary.json"), indent=2), flush=True)
    assert c.inventory(c.ROOT, exclude_git=True) == (
        c.load(H / "baseline-files.json"),
        c.load(H / "baseline-directories.json"),
    )
    c.cache_check()


if __name__ == "__main__":
    main()
