"""Retain narrow preparation corrections and literal standalone directory coverage."""
import difflib,gzip,json,os,stat
from pathlib import Path
import common as c
H=c.HERE;OLD=Path('/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012')
index=json.loads(gzip.decompress(c.regular_bytes(H/'payload'/c.DOSSIER/'evidence-index.json.gz')))
actual={r['historical_path']:r for r in index['standalone_owners']}
counts={'directories':0,'literal_directory_aliases':0,'regular':0}
for suffix in ['canonical-execution','context-independent-review','context-order-probe','root-context-finding','root-order-review','root-preparation-review','graph-preview']:
 root=Path('/private/tmp')/f'pathwaymech-next-240-{suffix}-20261012';expected=set()
 for here,ds,names in os.walk(root,followlinks=False):
  expected.add(here);assert actual[here]['type']=='directory';counts['directories']+=1
  for n in sorted(ds+names):
   p=Path(here)/n;m=p.lstat().st_mode
   if stat.S_ISDIR(m):continue
   expected.add(str(p));row=actual[str(p)]
   if stat.S_ISLNK(m):
    assert row['type']=='symlink' and row['link_text']==os.readlink(p)
    assert row['resolution']=='directory_alias_inert_not_recursively_followed'
    assert not any(q.startswith(str(p)+'/') for q in actual)
    counts['literal_directory_aliases']+=1
   else:assert row['type']=='regular';counts['regular']+=1
 observed={p for p in actual if p==str(root) or p.startswith(str(root)+'/')};assert observed==expected,(root,observed^expected)
assert counts['literal_directory_aliases']==12
c.write_new(H/'standalone-directory-check.json',{'scope':'Complete no-follow membership/type/literal alias checks for all seven standalone evidence roots; whole bodies separately covered by portable replay','counts':counts,'passed':True})
corrections=[]
for name,reason,fix in [('package-evidence','Discovery and author manifests spell regular-file type as file; inherited helper required regular.','Normalize only file to regular; six focused valid/invalid type/hash controls passed.'),('package-evidence-corrected','Independent review pytest evidence contains twelve current directory aliases; old standalone loop asserted no aliases.','Retain literal aliases inertly without recursion plus all real directory membership; fresh whole membership check passed.')]:
 corrections.append({'failed_receipt':c.pin(H/'receipts'/f'{name}.json'),'exact_executed_helper':c.pin(H/'executed-helper-bodies'/name/'package_evidence.py'),'reason':reason,'correction':fix})
c.write_new(H/'preparation-corrections.json',{'changes':corrections,'scope':'External packaging only; no maintained/runtime/scientific content changes','focused_controls':c.pin(H/'manifest-alias-checks.json'),'directory_coverage':c.pin(H/'standalone-directory-check.json'),'raw_partial_workcopies_retained_locally':True,'tiny_control_fixture_zip':c.pin(H/'manifest-alias-fixture.zip'),'original_accepted_packets_unchanged':True})
names=['common.py','adopt.py','verify_portable.py','split_archive.py','run_step.py','test_controls.py','archive_controls.py','capture.py','package_evidence.py','prepare_plan.py','finish.py']
patch=''.join(''.join(difflib.unified_diff((OLD/n).read_text().splitlines(True),(H/n).read_text().splitlines(True),fromfile='239/'+n,tofile='240/'+n)) for n in names)
(H/'helper-changes.patch').write_text(patch)
print(json.dumps({'standalone':counts,'packaging_corrections':2,'complete_helper_diff_bytes':len(patch.encode())}))
