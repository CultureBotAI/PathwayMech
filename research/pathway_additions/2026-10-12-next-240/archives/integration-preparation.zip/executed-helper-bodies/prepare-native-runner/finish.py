"""Finish the external packet; no adoption or maintained command execution."""

import ast
import datetime
import difflib
import gzip
import json
import os
import subprocess
import zipfile
from pathlib import Path

import common as c

PYTHON = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
OLD = Path("/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012")
DOS = c.HERE / "payload" / c.DOSSIER
HELPERS = [
    "common.py",
    "adopt.py",
    "verify_portable.py",
    "split_archive.py",
    "capture.py",
    "package_evidence.py",
    "prepare_plan.py",
    "finish.py",
    "run_step.py",
    "test_controls.py",
    "archive_controls.py",
]


def run_check(name, argv):
    start = datetime.datetime.now(datetime.UTC).isoformat()
    env = {
        **os.environ,
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
        "UV_NO_SYNC": "1",
        "PYTHONPATH": str(c.HERE),
    }
    result = subprocess.run(argv, cwd=c.HERE, env=env, capture_output=True, check=False)
    paths = []
    for kind, body in [("stdout", result.stdout), ("stderr", result.stderr)]:
        p = c.HERE / f"{name}.{kind}"
        with p.open("xb") as f:
            f.write(body)
        paths.append(c.pin(p))
    receipt = {
        "argv": argv,
        "cwd": str(c.HERE),
        "started_at": start,
        "finished_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "environment": {
            k: env[k]
            for k in ["PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE", "UV_NO_SYNC", "PYTHONPATH"]
        },
        "exit_code": result.returncode,
        "stdout": paths[0],
        "stderr": paths[1],
        "helpers": [c.pin(c.HERE / p) for p in HELPERS],
    }
    c.write_new(c.HERE / f"{name}.receipt.json", receipt)
    if result.returncode:
        raise RuntimeError(f"Failed {name}; exact streams and receipt retained")
    return receipt


def helpers():
    replacements = {
        "/pathwaymech-next-239-local-20261012": "/pathwaymech-next-240-local-20261012",
        "12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449": c.BASE,
        "67408fa8b7c7f46cf9014455d9b66c7a2458ebf5": c.TREE,
        "feat/pathway-next-239-local-20261012": c.BRANCH,
        "2026-10-12-next-239": "2026-10-12-next-240",
        "mar239": "pathbank240",
        "pathwaymech-next-239-local-adoption-": "pathwaymech-next-240-local-adoption-",
    }
    patch = []
    lineage = []
    for name in HELPERS[:4]:
        original = (OLD / name).read_text()
        expected = original
        for before, after in replacements.items():
            expected = expected.replace(before, after)
        left, right = ast.parse(expected), ast.parse((c.HERE / name).read_text())
        if name == "common.py":

            def primary(tree):
                return next(
                    n
                    for n in tree.body
                    if isinstance(n, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "PRIMARY" for t in n.targets)
                )

            primary(left).value = primary(right).value
        assert ast.dump(left) == ast.dump(right), name
        lineage.append(
            {
                "helper": name,
                "original": c.pin(OLD / name),
                "successor": c.pin(c.HERE / name),
                "guard_AST_equal_after_declared_rebase": True,
            }
        )
        patch.extend(
            difflib.unified_diff(
                original.splitlines(True),
                (c.HERE / name).read_text().splitlines(True),
                fromfile="239/" + name,
                tofile="240/" + name,
            )
        )
    (c.HERE / "helper-lineage.json").write_text(json.dumps(lineage, indent=2) + "\n")
    (c.HERE / "helper-rebase.patch").write_text("".join(patch))
    run_check(
        "configured-helper-lint-final",
        [
            PYTHON,
            "-B",
            "-m",
            "ruff",
            "check",
            "--no-cache",
            "--config",
            str(c.ROOT / "pyproject.toml"),
            *HELPERS,
        ],
    )
    inherited_archive = c.ROOT / (
        "research/pathway_additions/2026-10-12-next-238/archives/integration-preparation.zip"
    )
    guard_origin = Path("/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012")
    with zipfile.ZipFile(inherited_archive) as z:
        for member in [
            "receipts/guard-controls.json",
            "receipts/guard-controls.stdout",
            "receipts/guard-controls.stderr",
            "test_controls.py",
            "controls-fixtures.zip",
        ]:
            assert z.read(member) == c.regular_bytes(guard_origin / member), member
    inherited = c.load(guard_origin / "receipts/guard-controls.json")
    assert inherited["exit_code"] == 0
    assert "42 passed" in c.regular_bytes(guard_origin / "receipts/guard-controls.stdout").decode()
    c.write_new(
        c.HERE / "inherited-guard-coverage.json",
        {
            "tests": 42,
            "freshly_executed": False,
            "reason": (
                "Guard AST and portable decoder logic unchanged after declared pat"
                "h and primary-owner rebase; accepted predecessor coverage inherit"
                "ed."
            ),
            "durable_archive": c.pin(inherited_archive),
            "receipt_member": "receipts/guard-controls.json",
            "receipt": c.pin(guard_origin / "receipts/guard-controls.json"),
            "source_and_complete_streams_and_literal_fixtures_equal_committed_archive": True,
        },
    )
    replay = c.load(c.HERE / "receipts/portable-replay.stdout")
    assert replay["status"] == "all_portable_evidence_bodies_retrieved_and_verified"
    summary = c.load(c.HERE / "packaging-summary.json")
    assert replay["unique_bodies"] == summary["unique_bodies"]
    assert replay["originals"]["manifest_originals"] == 891
    assert replay["originals"]["whole_scientific_originals"] == 66
    assert replay["originals"]["scientific_native_originals"] == 3
    c.write_new(
        c.HERE / "final-helper-verification.json",
        {
            "helper_lineage": c.pin(c.HERE / "helper-lineage.json"),
            "lint": c.pin(c.HERE / "configured-helper-lint-final.receipt.json"),
            "portable_replay": c.pin(c.HERE / "receipts/portable-replay.json"),
            "new_synthetic_helper_tests_authored": True,
            "changed_control_scope": (
                "Six bounded manifest spelling/type/hash checks only; "
                "no new guard framework."
            ),
            "changed_packaging_controls": c.pin(c.HERE / "manifest-alias-checks.json"),
            "guard_tests_inherited_not_rerun": c.load(c.HERE / "inherited-guard-coverage.json"),
            "maintained_gates_or_adoption_executed": False,
        },
    )


def package():
    omitted = []
    selected = []
    for row in c.inventory(c.HERE)[0]:
        rel = row["path"]
        if rel.startswith("payload/") or rel in [
            "plan.json",
            "handoff.json",
            "artifact-manifest.json",
        ]:
            continue
        if rel.endswith("partial-evidence-bodies.zip"):
            omitted.append({**row, "historical_path": str(c.HERE / rel)})
        else:
            selected.append(rel)
    c.write_new(
        c.HERE / "partial-workcopy-retention.json",
        {
            "workcopies": omitted,
            "raw_workcopies_retained_locally": True,
            "durable_policy": "All failure code/streams and workcopy whole hashes retained. "
            "Raw packaging workcopy omitted from durable archive; successful "
            "portable replay covers every scientific original independently.",
        },
    )
    selected.append("partial-workcopy-retention.json")
    archive = DOS / "archives/integration-preparation.zip"
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in sorted(selected):
            info = zipfile.ZipInfo(rel, (2026, 10, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, c.regular_bytes(c.HERE / rel))
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == len(selected)
        for rel in selected:
            assert z.read(rel) == c.regular_bytes(c.HERE / rel)
    for name in ["common.py", "verify_portable.py"]:
        (DOS / (name + ".gz")).write_bytes(gzip.compress(c.regular_bytes(c.HERE / name), mtime=0))
    (DOS / "README.md").write_bytes(c.regular_bytes(c.HERE / "REPORT.md"))
    c.write_new(
        c.HERE / "preparation-archive-proof.json",
        {
            "archive": c.pin(archive),
            "members": [dict(c.pin(c.HERE / p), archive_member=p) for p in sorted(selected)],
            "all_member_bytes_retrieved_equal": True,
            "omitted_workcopies": omitted,
        },
    )
    c.write_new(
        DOS / "integration-preparation.json",
        {
            "status": "local_preparation_only_pending_review_and_root_adoption",
            "archive": {
                **c.pin(archive),
                "repository_relative_path": archive.relative_to(c.HERE / "payload").as_posix(),
            },
            "archive_members": len(selected),
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "history_before_first_render": True,
            "SSSOM_before_render_tests": True,
            "future_stage_member": "stages.json",
            "source_evidence_index": "evidence-index.json.gz",
            "external_fixture_bindings": "external-packet-closures.json.gz",
        },
    )


def plan_and_seal():
    before = {r["path"]: r for r in c.load(c.HERE / "baseline-files.json")}
    changes = []
    for row in c.inventory(c.HERE / "payload")[0]:
        assert row["type"] == "regular"
        rel = row["path"]
        changes.append(
            {
                "destination": rel,
                "before": before.get(rel),
                "executable": row["executable"],
                "payload": c.pin(c.HERE / "payload" / rel),
            }
        )
    inputs = c.load(c.HERE / "accepted-inputs.json")
    closed = json.loads(gzip.decompress(c.regular_bytes(DOS / "external-packet-closures.json.gz")))
    for row in closed:
        inputs.extend([row["handoff"], row["manifest"]])
    plan = {
        "status": "exact_local_plan_pending_independent_root_acceptance",
        "target": str(c.ROOT),
        "baseline_commit": c.BASE,
        "baseline_tree": c.TREE,
        "branch": c.BRANCH,
        "local_only": True,
        "publication_authorized": False,
        "shared_cache_mutation": False,
        "accepted_inputs": inputs,
        "changes": changes,
        "history_before_first_render": True,
        "future_stages": c.pin(c.HERE / "stages.json"),
    }
    c.scope_check(plan)
    c.checkout_check(plan)
    c.cache_check()
    for row in inputs:
        c.verify(row)
    for row in changes:
        c.destination_check(row)
    c.write_new(c.HERE / "plan.json", plan)
    c.write_new(
        c.HERE / "final-plan-preflight.json",
        {
            "status": "exact_baseline_payload_inputs_cache_verified_no_writes",
            "at": datetime.datetime.now(datetime.UTC).isoformat(),
            "plan": c.pin(c.HERE / "plan.json"),
            "primary_owners": len(c.PRIMARY),
            "all_planned_owners": len(changes),
            "new_dossier_owners": len(changes) - len(c.PRIMARY),
            "old_file_count": len(before),
            "cache_entries": 800,
            "hidden_ignored_files_types_modes_empty_directories_included": True,
        },
    )
    rows, dirs = c.inventory(c.HERE)
    assert all(r["type"] == "regular" for r in rows)
    artifacts = [{**c.pin(c.HERE / r["path"]), "relative_path": r["path"]} for r in rows]
    c.write_new(
        c.HERE / "artifact-manifest.json",
        {
            "root": str(c.HERE),
            "artifacts": artifacts,
            "directories": dirs,
            "hidden_ignored_included": True,
            "excluded_seals": ["handoff.json", "artifact-manifest.json"],
        },
    )
    c.write_new(
        c.HERE / "handoff.json",
        {
            "status": "complete_local_integration_preparation_pending_independent_review",
            "role": "integration preparation author; not independent reviewer",
            "target": str(c.ROOT),
            "baseline_commit": c.BASE,
            "baseline_tree": c.TREE,
            "branch": c.BRANCH,
            "manifest": c.pin(c.HERE / "artifact-manifest.json"),
            "artifacts": len(artifacts),
            "seals": 2,
            "plan": c.pin(c.HERE / "plan.json"),
            "stages": c.pin(c.HERE / "stages.json"),
            "report": c.pin(c.HERE / "REPORT.md"),
            "primary_owners": len(c.PRIMARY),
            "planned_total_owners": len(changes),
            "portable_bodies": c.load(c.HERE / "packaging-summary.json")["unique_bodies"],
            "reused_committed_bodies": c.load(c.HERE / "packaging-summary.json")[
                "reused_committed_bodies"
            ],
            "external_reproducible_fixture_files": c.load(c.HERE / "packaging-summary.json")[
                "omitted_reproducible_fixture_files"
            ],
            "fixture_whole_hash_closure_inherited_not_fresh": True,
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "maintained_adoption_performed": False,
            "native_history_review_or_gates_performed": False,
            "preparation_git_github_mutation": False,
            "authorized_clean_worktree_creation_preceded_preparation": c.pin(
                c.HERE / "root-target.json"
            ),
        },
    )
    c.sealed_check()
    print(
        json.dumps(
            {
                "handoff": c.pin(c.HERE / "handoff.json"),
                "manifest": c.pin(c.HERE / "artifact-manifest.json"),
                "artifacts": len(artifacts),
                "planned_owners": len(changes),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["helpers", "package", "seal"])
    args = parser.parse_args()
    {"helpers": helpers, "package": package, "seal": plan_and_seal}[args.stage]()
