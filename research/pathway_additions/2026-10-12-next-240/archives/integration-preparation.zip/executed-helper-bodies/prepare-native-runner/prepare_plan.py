"Compare complete accepted deltas and prepare concrete root-owned native stages."

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import yaml

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-240-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-240-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
RID = "PathBank:SMP0002097"


def stable(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before, after = (
            c.load(c.ROOT / rel),
            c.load(PAY / rel if (PAY / rel).exists() else c.ROOT / rel),
        )
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [k for k in new if k in old] == list(old)
                for ident, value in old.items():
                    assert stable(value) == stable(new[ident]), (name, key, ident)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [k for k in new if k not in old],
                    "all_old_whole_objects_and_nested_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(BUILD / (name + ".json")),
            "adopted_owner": (PAY / rel).exists(),
            "sections": sections,
        }
    oldmanifest = c.load(c.ROOT / "conf/identifier_sources.json")
    newmanifest = c.load(PAY / "conf/identifier_sources.json")
    assert len(oldmanifest) == 887 and len(newmanifest) == 892
    assert stable(newmanifest[:887]) == stable(oldmanifest)
    assert c.regular_bytes(c.ROOT / "conf/rhea_identifier_updates.json") == c.regular_bytes(
        BUILD / "rhea-updates.json"
    )
    bn, an = rows(c.ROOT / "output/kgx/nodes.tsv"), rows(BUILD / "actual-kgx/nodes.tsv")
    be, ae = rows(c.ROOT / "output/kgx/edges.tsv"), rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = {r["id"]: r for r in be}
    assert [r for r in ae if r["id"] in oldedges] == be
    oldnodes, newnodes = {r["id"]: r for r in bn}, {r["id"]: r for r in an}
    changes, aggregate = [], []
    contexts = additions = 0
    for ident, old in oldnodes.items():
        new = newnodes[ident]
        prior = json.loads(old["source_contexts"])
        current = json.loads(new["source_contexts"])
        assert [v for v in current if v["record_id"] != RID] == prior
        delta_contexts = [v for v in current if v["record_id"] == RID]
        contexts += len(prior)
        additions += len(delta_contexts)
        delta = {
            key: {"before": value, "after": new[key]}
            for key, value in old.items()
            if key != "source_contexts" and value != new[key]
        }
        if delta:
            aggregate.append({"id": ident, "fields": delta})
        if old != new:
            changes.append({"id": ident, "before": old, "after": new})
    accepted = c.load(
        "/private/tmp/pathwaymech-next-240-root-canonical-output-acceptance-20261012.json"
    )
    expected_delta = [
        {"id": r["id"], "fields": r["fields"]} for r in accepted["exact_aggregate_changes"]
    ]
    assert {r["id"]: r["fields"] for r in aggregate} == {
        r["id"]: r["fields"] for r in expected_delta
    }
    assert [r["id"] for r in an if r["id"] in oldnodes] == list(oldnodes)
    assert len(changes) == additions == 6
    assert (len(bn), len(be), len(an), len(ae)) == (4320, 12052, 4357, 12110)
    record = yaml.safe_load(
        c.regular_bytes(
            PAY / "data/pathways/spermidine-biosynthesis-and-metabolism-escherichia-coli.yaml"
        )
    )
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for mapping in record.get("source_mappings", []):
        row = {k: mapping[k] for k in cols if k != "comment"}
        row["comment"] = (
            f"source_pathway_id={mapping['source_pathway_id']}; "
            f"source_element_id={mapping['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(row[k])).strip() for k in cols})
    existing = Counter(stable(r) for r in oldss)
    assert len(oldss) == 62 and all(n == 1 for n in existing.values())
    added = [r for r in newss if stable(r) not in existing]
    assert len(added) == len(newss) == 4
    files = c.load(H / "baseline-files.json")

    def count(prefix, suffix):
        return sum(r["path"].startswith(prefix) and r["path"].endswith(suffix) for r in files)

    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": count("data/pathways/", ".yaml"),
        "old_review_yaml": count("reviews/", ".yaml"),
        "old_review_markdown": count("reviews/", ".md"),
        "old_history_yaml": count("history/", ".yaml"),
        "native_authorities": native,
        "manifest_prefix_rows": 887,
        "manifest_after_rows": 892,
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_order_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": False,
        "old_node_encounter_relative_order_exact": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_changes": aggregate,
        "aggregate_display_scope": (
            "No aggregate field changes. Six existing nodes gain only exact ac"
            "cepted target source contexts; all old contexts and row order rem"
            "ain unchanged."
        ),
        "old_authority_object_exceptions": [],
        "planning_decisions": [c.pin(PRE / "graph-planning-decision.json")],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = c.load(OLD / "stages.json")
    raw = (
        json.dumps(stages)
        .replace("pathwaymech-next-239", "pathwaymech-next-240")
        .replace(
            "s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii",
            "spermidine-biosynthesis-and-metabolism-escherichia-coli",
        )
        .replace("MetaCyc_PWY-8132", "PathBank_SMP0002097")
    )
    stages = json.loads(raw)
    findings = [
        {"local_key": key, "status": "resolved_in_accepted_successor", "public_issue": None}
        for key in ["pathbank240-incomplete-interface-context", "pathbank240-context-owner-order"]
    ]
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="scripts/build_source_identifier_snapshot.py",
        description=(
            "Accepted280-file complete PathBank context runtime with determini"
            "stic ordering,892-row manifest and actual source snapshot; ontolo"
            "gy unchanged."
        ),
        issue_lineage=findings,
    )

    def history(kind, slug, owner, event, summary, details):
        return [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            kind,
            "--slug",
            slug,
            *owner,
            "--event",
            event,
            "--outcome",
            "changed",
            "--summary",
            summary,
            "--details",
            details,
            "--actor-name",
            "codex",
            "--agent-tool",
            "codex",
            "--model",
            "gpt-6",
        ]

    stages["history_commands"] = [
        history(
            "record",
            "spermidine-biosynthesis-and-metabolism-escherichia-coli",
            ["--target-root", "data/pathways"],
            "CREATE",
            "Add complete evidence-backed E. coli spermidine biosynthesis and metabolism.",
            (
                "Exact accepted scoped PathBank:SMP0002097:18 paragraphs,58 edges,"
                "4 qualifiers,43 IDs,42 references and4 mappings; all four biochem"
                "ical events plus transport,22 sides and generic SAM interface ret"
                "ained. Native assembly, taxon/construct, chemical-identity, trans"
                "port and source-access limits remain. Whole original bodies and a"
                "ll92 acquisition attempts retained in research/pathway_additions/"
                "2026-10-12-next-240. Maintained gates/native review remain pendin"
                "g."
            ),
        ),
        history(
            "infrastructure",
            "pathbank240-native-authority",
            ["--path", "scripts/build_source_identifier_snapshot.py"],
            "EDIT",
            ("Integrate complete typed PathBank context and deterministic owner serialization."),
            (
                "Adopt reviewed280-file runtime via exact seven changed effective "
                "owners,892-row manifest retaining887 old entries, and actual sour"
                "ce snapshot; ontology remains byte identical. Preserve both local"
                " findings pathbank240-incomplete-interface-context and pathbank24"
                "0-context-owner-order, original failures and accepted disposition"
                "s. All old authority objects, first owners, graph rows and contex"
                "ts remain exact. No aggregate field changes. Both histories prece"
                "de SSSOM/render; maintained gates/native reviews remain pending."
            ),
        ),
    ]
    stages["after_gates"] = [
        (
            "Inspect actual PathBank:SMP0002097 page/graph and all18 paragraph"
            "s,58 edges,4 qualifiers,43 IDs,42 references and4 mappings agains"
            "t exact accepted scoped science and limits."
        ),
        (
            "Save independent scientific and technical native reviews after cu"
            "rrent inputs are inspected. Scientific author/preparation impleme"
            "nter is /root/deoxy237_science_review; fresh independent scientif"
            "ic review must be performed by a distinct reviewer, preserving in"
            "herited versus fresh readings."
        ),
        (
            "Preserve240 prior records/pages,124 review pairs,408 histories, e"
            "very old authority object/order and all12052 old KGX edge/context"
            " payloads. Six shared nodes gain target contexts only; no aggrega"
            "te or old row-order changes."
        ),
        (
            "Native SSSOM retains62 old complete rows and relative order plus4"
            " exact target mappings by whole-row multiset,66 total. Native sub"
            "ject sorting is accepted."
        ),
        (
            "Recheck800 cache identities and full hidden/ignored checkout outs"
            "ide exact primary/dossier/history/generated/review scope; no publ"
            "ication."
        ),
    ]
    stages["before_first_render_after_history"][0].update(
        reason="Export4 target mappings after both histories and before rendering/tests.",
        preservation=(
            "All62 old rows/cells/order/header exact;4 added whole rows and66 "
            "total. Compare additions by whole-row multiplicity."
        ),
    )
    interfaces = stages["native_review_interfaces"]
    interfaces["inherited_science_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-240-science-review-20261012/handoff.json"
    )
    interfaces["active_scope_successor_review"] = c.pin(
        
            "/private/tmp/pathwaymech-next-240-scope-successor-independent-rev"
            "iew-20261012/handoff.json"
        
    )
    interfaces["actual_native_review_handoff"] = c.pin(
        
            "/private/tmp/pathwaymech-next-240-canonical-output-independent-re"
            "view-20261012/handoff.json"
        
    )
    interfaces["save_template"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "save",
        "--content",
        "<independently-reviewed-completed-review.json>",
    ]
    interfaces["check_after_save"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "check",
        "--require-reviews",
        "--base",
        c.BASE,
    ]
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    assert stages["preservation_counts"] == {
        "old_records": 240,
        "old_review_yaml": 124,
        "old_review_markdown": 124,
        "old_history_yaml": 408,
    }
    c.write_new(H / "stages.json", stages)
    selection = c.load(H / "baseline-selection.json")
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Clean committed239 local branch; not merged main",
            "primary_owners": len(c.PRIMARY),
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(
                PAY / "data/pathways/spermidine-biosynthesis-and-metabolism-escherichia-coli.yaml"
            ),
            "actual_native_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-240-root-canonical-output-acceptance-20261012.json"
            ),
            "baseline_postcommit_acceptance": selection["commit_receipt"],
            "local_findings": findings,
            "remaining": [
                "root concrete preparation check",
                "guarded local adoption",
                "two histories before SSSOM/render",
                "native gates",
                "actual page and independent native reviews",
                "preservation and local commit",
            ],
            "source_exhaustion": False,
            "licensing": "Public-release licensing remains deferred; publication not authorized.",
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_records",
                    "old_review_yaml",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                    "exact_aggregate_changes",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
