"""Resolve formatting diagnostics while proving all parsed behavior is unchanged."""
import ast,json,subprocess
from pathlib import Path
H=Path(__file__).parent
names=['common.py','adopt.py','verify_portable.py','split_archive.py','capture.py','package_evidence.py','prepare_plan.py','finish.py','run_step.py','test_controls.py','archive_controls.py']
out=H/'history/helper-lint-initial';out.mkdir(parents=True)
before={n:(H/n).read_text() for n in names}
for n,s in before.items():(out/n).write_text(s)
p=H/'finish.py';s=p.read_text().replace('"changed_control_scope": "Six bounded manifest spelling/type/hash checks only; no new guard framework.",','"changed_control_scope": (\n                "Six bounded manifest spelling/type/hash checks only; "\n                "no new guard framework."\n            ),');p.write_text(s)
argv=['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B','-m','ruff','check','--no-cache','--config','/private/tmp/pathwaymech-next-240-local-20261012/pyproject.toml','--select','UP034','--fix',*names]
p=subprocess.run(argv,cwd=H,capture_output=True,check=False);assert p.returncode==0,p.stdout.decode()
proof=[]
for n,s in before.items():assert ast.dump(ast.parse(s))==ast.dump(ast.parse((H/n).read_text())),n;proof.append({'helper':n,'complete_AST_and_strings_unchanged':True})
(H/'helper-formatting-correction.json').write_text(json.dumps({'argv':argv,'stdout':p.stdout.decode(),'stderr':p.stderr.decode(),'exit_code':p.returncode,'proof':proof},indent=2)+'\n')
p=H/'finish.py';s=p.read_text().replace('configured-helper-lint-successor','configured-helper-lint-final');p.write_text(s)
print('All eleven helper ASTs unchanged; only final lint receipt name is advanced after preservation.')
