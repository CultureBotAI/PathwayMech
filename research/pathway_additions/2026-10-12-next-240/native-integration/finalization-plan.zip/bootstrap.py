"""Bounded239 finalization helper rebase; no maintained writes or helper execution."""
import ast,difflib,hashlib,json
from pathlib import Path
H=Path(__file__).parent;OLD=Path('/private/tmp/pathwaymech-next-239-finalization-preparation-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
lineage=[]
for name in ['finalize_native_inputs.py','adopt_evidence.py','save_reviews.py','retain_finalization.py','prepare.py']:
 raw=(OLD/name).read_text();s=raw if name=='finalize_native_inputs.py' else raw.replace('pathwaymech-next-239','pathwaymech-next-240').replace('2026-10-12-next-239','2026-10-12-next-240')
 if name=='adopt_evidence.py':
  s=s.replace('approved239','approved240').replace("['root-review','independent-qa']","['independent-tech-review','independent-qa']")
  a=s.index("readme=b'");b=s.index("\nextra('README.md'",a)
  s=s[:a]+"readme=b'Exact 240 native-review evidence. independent-tech-review and independent-qa preserve both complete independent packets, whole actual native execution and original seals. Audit Python owners use deterministic lossless .py.gz; storage-ledger.json binds original path, hash and mode to the stored owner. Decode before checking original packet manifests. Direct cited JSON evidence stays at its original path with exact bytes. Scientific and technical judgments, reviewer identities, timestamps and original native input hashes remain unchanged. No new scientific reading, source normalization, publication or licensing clearance is asserted.\\n'"+s[b:]
 if name=='save_reviews.py':
  s=s.replace('native239','native240').replace('==124','==126').replace("'old_pairs_preserved':122,'total_pairs':124","'old_pairs_preserved':124,'total_pairs':126")
 if name=='retain_finalization.py':s=s.replace('native239','native240')
 if name=='prepare.py':
  s=s.replace("ROOT_QA = Path('/private/tmp/pathwaymech-next-240-root-maintained-qa-20261012')","ROOT_QA = Path('/private/tmp/pathwaymech-next-240-independent-maintained-tech-20261012')")
  a=s.index('parser = argparse.ArgumentParser()');b=s.index('for row in native_files:',a)
  s=s[:a]+'''selection=c.load(H/'selection.json')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
root_closure,root_files=close(ROOT_QA,selection['technical']['handoff']['sha256'],selection['technical']['manifest']['sha256'])
sci_closure,sci_files=close(SCI_QA,selection['scientific']['handoff']['sha256'],selection['scientific']['manifest']['sha256'])
native_closure,native_files=close(NATIVE,selection['native']['handoff']['sha256'],selection['native']['manifest']['sha256'])
'''+s[b:]
  s=s.replace("[('root-review', ROOT_QA, root_files)","[('independent-tech-review', ROOT_QA, root_files)").replace("('root-review', 'independent-qa')","('independent-tech-review', 'independent-qa')")
  s=s.replace("SCI_QA / 'completed-review-ready.yaml'","SCI_QA / selection['scientific']['proposal_filename']")
  s=s.replace("ROOT_QA / 'technical-proposal.json'","ROOT_QA / selection['technical']['proposal_filename']")
  s=s.replace("len(runtime['runtime']) == 276 and runtime['changed_runtime'] == 9","len(runtime['runtime']) == 280 and runtime['changed_runtime'] == 7")
  s=s.replace("(12909, 2042, 800)","(selection['actual_checkout_files'], selection['actual_checkout_directories'], 800)")
  s=s.replace("pathwaymech-next-238-finalization-preparation-20261012/finalize_native_inputs.py","pathwaymech-next-239-finalization-preparation-20261012/finalize_native_inputs.py")
  s=s.replace("'root_qa': root_closure","'technical_qa': root_closure").replace("'runtime_files_exact': 276","'runtime_files_exact': 280")
 ast.parse(s);(H/name).write_text(s);lineage.append({'helper':name,'predecessor':pin(OLD/name),'prepared':pin(H/name),'exact_byte_identity':raw==s})
 if raw!=s:(H/(name+'.diff')).write_text(''.join(difflib.unified_diff(raw.splitlines(True),s.splitlines(True),fromfile='239/'+name,tofile='240/'+name)))
assert lineage[0]['exact_byte_identity']
(H/'helper-lineage.json').write_text(json.dumps(lineage,indent=2)+'\n')
print('Five helpers drafted, unchanged native input finalizer preserved; all execution waits exact sealed proposals/root acceptance.')
