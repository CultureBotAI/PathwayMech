"""Prepare one exact review/evidence plan; do not modify the checkout or save reviews."""
import argparse
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import sys
import yaml

H = Path(__file__).resolve().parent
PREP = Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012')
sys.path.insert(0, str(PREP))
import common as c

ROOT_QA = Path('/private/tmp/pathwaymech-next-240-independent-maintained-tech-20261012')
SCI_QA = Path('/private/tmp/pathwaymech-next-240-maintained-science-review-20261012')
NATIVE = Path('/private/tmp/pathwaymech-next-240-local-native-execution-20261012')
DURABLE = c.DOSSIER + '/native-integration'


def write(name, value):
    c.write_new(H / name, value)


def body_pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def close(root, handoff_sha, manifest_sha):
    handoff, manifest = c.pin(root / 'handoff.json'), c.pin(root / 'artifact-manifest.json')
    assert handoff['sha256'] == handoff_sha and manifest['sha256'] == manifest_sha
    declared_manifest = c.load(root / 'handoff.json')['manifest']
    assert {k: declared_manifest[k] for k in ('path', 'bytes', 'sha256')} == manifest
    assert declared_manifest.get('file_type', 'regular') == 'regular'
    assert declared_manifest.get('link_text') is None
    assert declared_manifest.get('resolved_path', str(root / 'artifact-manifest.json')) == str(root / 'artifact-manifest.json')
    data = c.load(root / 'artifact-manifest.json')
    rows = data.get('artifacts', data.get('files'))
    seen = set()
    for row in rows:
        rel = row.get('relative_path') or str(Path(row['path']).relative_to(root))
        c.relative(rel)
        assert rel not in seen
        seen.add(rel)
        c.verify(row, root / rel)
    actual, directories = c.inventory(root)
    assert all(row['type'] == 'regular' for row in actual)
    assert {row['path'] for row in actual} == seen | {'handoff.json', 'artifact-manifest.json'}
    assert set(directories) == set(data['directories']) - {'.'}
    return {'root': str(root), 'handoff': handoff, 'manifest': manifest,
            'artifacts': len(rows), 'seals': 2, 'directories': len(directories),
            'literal_hidden_ignored_closure_passed': True}, actual


selection=c.load(H/'selection.json')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
root_closure,root_files=close(ROOT_QA,selection['technical']['handoff']['sha256'],selection['technical']['manifest']['sha256'])
sci_closure,sci_files=close(SCI_QA,selection['scientific']['handoff']['sha256'],selection['scientific']['manifest']['sha256'])
native_closure,native_files=close(NATIVE,selection['native']['handoff']['sha256'],selection['native']['manifest']['sha256'])
for row in native_files:
    assert c.regular_bytes(NATIVE / row['path']) == c.regular_bytes(SCI_QA / 'actual-native' / row['path'])

copies, ledger = [], []
for prefix, packet, files in [('independent-tech-review', ROOT_QA, root_files), ('independent-qa', SCI_QA, sci_files)]:
    for row in files:
        source = packet / row['path']
        original = c.pin(source)
        raw = c.regular_bytes(source)
        original_dest = DURABLE + '/' + prefix + '/' + row['path']
        dest, stored_source, body, encoding = original_dest, source, raw, 'identity'
        if source.suffix == '.py':
            dest += '.gz'
            stored_source = H / 'payload' / prefix / (row['path'] + '.gz')
            stored_source.parent.mkdir(parents=True, exist_ok=True)
            body, encoding = gzip.compress(raw, mtime=0), 'gzip'
            with stored_source.open('xb') as stream:
                stream.write(body)
            assert gzip.decompress(body) == raw
        target = c.ROOT / c.relative(dest)
        assert not os.path.lexists(target)
        for parent in target.parents:
            if parent == c.ROOT:
                break
            assert not parent.is_symlink()
        copies.append({'source': str(stored_source), 'repository_path': dest,
                       **body_pin(body), 'encoding': encoding,
                       'executable': row['executable'] if encoding == 'identity' else False})
        ledger.append({'original_repository_path': original_dest, 'original_source': original,
                       'original_executable': row['executable'], 'stored_repository_path': dest,
                       'stored_source': c.pin(stored_source), 'encoding': encoding})
assert len({r['repository_path'] for r in copies}) == len(copies)

reconstructed = []
for prefix in ('independent-tech-review', 'independent-qa'):
    group = {r['original_repository_path'].split('/' + prefix + '/', 1)[1]: r
             for r in ledger if '/' + prefix + '/' in r['original_repository_path']}
    def decoded(rel):
        row = group[rel]
        body = c.regular_bytes(row['stored_source']['path'])
        assert body_pin(body) == {k: row['stored_source'][k] for k in ('bytes', 'sha256')}
        body = gzip.decompress(body) if row['encoding'] == 'gzip' else body
        assert body_pin(body) == {k: row['original_source'][k] for k in ('bytes', 'sha256')}
        return body
    manifest = json.loads(decoded('artifact-manifest.json'))
    original_root = Path(group['handoff.json']['original_source']['path']).parent
    expected = {'handoff.json', 'artifact-manifest.json'}
    for row in manifest.get('artifacts', manifest.get('files')):
        rel = row.get('relative_path') or str(Path(row['path']).relative_to(original_root))
        expected.add(rel)
        assert body_pin(decoded(rel)) == {k: row[k] for k in ('bytes', 'sha256')}
    assert set(group) == expected
    reconstructed.append({'prefix': prefix, 'whole_decoded_packet_closure_passed': True,
                          'owners': len(expected)})

by_dest = {r['repository_path']: r for r in copies}
drafts, inputs, evidence = {}, {}, []
for kind, source in [('scientific', SCI_QA / selection['scientific']['proposal_filename']),
                     ('technical', ROOT_QA / selection['technical']['proposal_filename'])]:
    raw = c.regular_bytes(source)
    doc = yaml.safe_load(raw)
    assert doc['source']['git_revision'] == c.BASE and doc['source']['state'] == 'working_tree'
    assert doc['completion'] == 'completed' and doc['findings'] == []
    assert doc['verdict'] in ('pass', 'pass_with_limitations')
    assert doc['scientific_review'] == (kind == 'scientific')
    assert not os.path.lexists(c.ROOT / 'reviews/structured' / doc['review_id'])
    for row in doc['source']['inputs']:
        assert c.pin(c.ROOT / row['path'])['sha256'] == row['sha256']
        if row['path'] in inputs:
            assert inputs[row['path']]['sha256'] == row['sha256']
        else:
            inputs[row['path']] = {'path': row['path'], 'sha256': row['sha256'], 'roles': {}}
        inputs[row['path']]['roles'][kind] = row.get('role')
    for item in doc['evidence']:
        ref = item.get('reference', '')
        binding = {'review': kind, 'evidence_id': item['evidence_id'], 'reference': ref}
        if ref.startswith(DURABLE + '/'):
            row = by_dest[ref]
            assert row['encoding'] == 'identity'
            assert item['snapshot_sha256'] == row['sha256']
            binding.update(whole_body_identity_copy=True, sha256=row['sha256'])
        else:
            binding['external_or_preexisting_reference'] = True
            current = c.ROOT / ref
            if not Path(ref).is_absolute() and current.is_file():
                assert item['snapshot_sha256'] == c.pin(current)['sha256']
        evidence.append(binding)
    destination = H / (kind + '-review.yaml')
    with destination.open('xb') as stream:
        stream.write(raw)
    drafts[kind] = {'original': c.pin(source), 'exact_copy': c.pin(destination),
                   'review_id': doc['review_id'], 'started_at': doc['started_at'],
                   'finished_at': doc['finished_at'], 'reviewer': doc['reviewer'],
                   'source_inputs': len(doc['source']['inputs']), 'assessments': len(doc['assessments']),
                   'checks': len(doc['checks']), 'evidence': len(doc['evidence']),
                   'target_ids': [r['target_id'] for r in doc['targets']],
                   'all_original_bytes_and_judgments_retained': True}

c.git_check(clean=False)
assert not c.git('diff', '--cached', '--name-only')
runtime = c.load(PREP / 'runtime-owner-map.json')
assert len(runtime['runtime']) == 280 and runtime['changed_runtime'] == 7
for row in runtime['runtime']:
    c.verify(row['effective_integration'], c.ROOT / row['relative_path'])
qa = c.load(ROOT_QA / 'checkout-preservation.json')
assert qa['status'] == 'complete_checkout_preservation_after_native_gates_passed'
assert (qa['current_files'], qa['current_directories'], qa['cache_entries_unchanged']) == (selection['actual_checkout_files'], selection['actual_checkout_directories'], 800)
finalizer = Path('/private/tmp/pathwaymech-next-239-finalization-preparation-20261012/finalize_native_inputs.py')
assert c.regular_bytes(H / 'finalize_native_inputs.py') == c.regular_bytes(finalizer)
gzip_count = sum(r['encoding'] == 'gzip' for r in copies)
write('copy-plan.json', {'status': 'proposed_only_no_maintained_writes', 'durable_root': DURABLE,
      'files': copies, 'original_owners': len(copies), 'gzip_owners': gzip_count,
      'identity_owners': len(copies) - gzip_count, 'stored_bytes': sum(r['bytes'] for r in copies),
      'original_bytes': sum(r['original_source']['bytes'] for r in ledger),
      'all_whole_packet_files_and_seals': True, 'source_normalization': False})
write('storage-ledger.json', {'status': 'all_whole_originals_preserved_with_lossless_script_storage',
      'entries': ledger, 'reconstructed_closures': reconstructed,
      'direct_evidence_references_unchanged': sum(bool(r.get('whole_body_identity_copy')) for r in evidence),
      'raw_originals_changed': False})
write('native-draft-bindings.json', drafts)
write('current-native-inputs.json', {'base': c.BASE, 'inputs': sorted(inputs.values(), key=lambda r: r['path']),
      'all_current_hashes_exact': True, 'no_input_rebound': True})
write('evidence-reference-bindings.json', evidence)
write('input-bindings.json', {'technical_qa': root_closure, 'scientific_qa': sci_closure, 'actual_native': native_closure,
      'native_in_scientific_packet_whole_byte_identity': True, 'unchanged_finalizer': c.pin(H / 'finalize_native_inputs.py'),
      'predecessor_finalizer': c.pin(finalizer), 'passed_root_checkout_guard': c.pin(ROOT_QA / 'check_checkout.py'),
      'passed_root_checkout_result': c.pin(ROOT_QA / 'checkout-preservation.json'),
      'integration_preparation_handoff': c.pin(PREP / 'handoff.json'), 'runtime_owner_map': c.pin(PREP / 'runtime-owner-map.json')})
write('preparation-checks.json', {'status': 'bounded_preparation_checks_passed', 'started_at': started,
      'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'copy_owners': len(copies),
      'gzip_owners': gzip_count, 'current_original_native_inputs': len(inputs), 'runtime_files_exact': 280,
      'head': c.BASE, 'branch': c.BRANCH, 'empty_index': True, 'source_packets_unmodified': True,
      'full_checkout_and_cache_QA_inherited_from_exact_root_receipt_not_rerun': True,
      'native_saves': 0, 'maintained_writes': 0, 'new_scientific_judgments': False})
print(json.dumps({'copy_owners': len(copies), 'gzip_owners': gzip_count, 'stored_bytes': sum(r['bytes'] for r in copies),
      'current_native_inputs': len(inputs), 'draft_assessments': {k: v['assessments'] for k, v in drafts.items()}}))
