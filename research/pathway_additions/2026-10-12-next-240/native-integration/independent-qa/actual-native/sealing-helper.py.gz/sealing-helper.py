"""Seal completed native execution evidence without rerunning any gate."""
import datetime
import hashlib
import json
import os
import re
from pathlib import Path

OUT = Path('/private/tmp/pathwaymech-next-240-local-native-execution-20261012')
ROOT = Path('/private/tmp/pathwaymech-next-240-local-20261012')
PREP = Path('/private/tmp/pathwaymech-next-240-local-integration-preparation-20261012')
RUNNER = Path('/private/tmp/pathwaymech-next-240-root-run-native-20261012.py')
PHASES = ('history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates')
OUTER_NAMES = dict(zip(PHASES, ('generation', 'offline', 'vendored', 'final'), strict=True))

def pin(p):
    assert p.is_file() and not p.is_symlink(), p
    body = p.read_bytes()
    return {'path': str(p), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write(p, value):
    with p.open('x') as s:
        json.dump(value, s, indent=2)
        s.write('\n')

def main():
    assert pin(RUNNER)['sha256'] == '26ab44c6f3b7f94e89a8678676ea734a9af77272b0f784d3ea46828e62a777d7'
    assert not any(p.name == 'failure.json' for p in OUT.rglob('*')), 'Unexpected failure requires retained successor handling before sealing'
    summary = []
    all_receipts = []
    completion_pins = []
    for phase in PHASES:
        folder = OUT / phase
        phase_runner = RUNNER
        completion = json.loads((folder / 'completion.json').read_bytes())
        assert completion['status'] == 'phase_passed' and completion['phase'] == phase
        assert completion['runner'] == pin(phase_runner)
        assert completion['stage_plan'] == pin(PREP / 'stages.json')
        assert pin(Path(completion['phase_start']['path'])) == completion['phase_start']
        assert (folder / 'runner-at-start.py').read_bytes() == phase_runner.read_bytes()
        for receipt, origin in zip(completion['receipts'], completion['receipt_origins'], strict=True):
            assert receipt['exit_code'] == 0 and receipt['runner_at_start'] == pin(phase_runner)
            assert receipt['phase_start'] == completion['phase_start']
            assert pin(Path(origin['path'])) == origin
            assert json.loads(Path(origin['path']).read_bytes()) == receipt
            for stream in ('stdout', 'stderr'):
                assert pin(Path(receipt[stream]['path'])) == receipt[stream]
            summary.append({key: receipt[key] for key in ('name', 'started_at', 'finished_at', 'seconds', 'exit_code')})
            all_receipts.append(receipt)
        completion_pins.append(pin(folder / 'completion.json'))
    assert [row['name'] for row in summary] == ['history-1', 'history-2', 'sssom', 'render', 'skills', 'validate', 'tests', 'lint', 'kgx', 'vendored', 'diff-check', 'site-current']
    for first, second in zip(summary, summary[1:], strict=False):
        assert datetime.datetime.fromisoformat(first['finished_at']) <= datetime.datetime.fromisoformat(second['started_at'])
    histories = []
    for receipt in all_receipts[:2]:
        relative = Path(receipt['stdout']['path']).read_text().strip()
        assert relative.startswith('history/') and relative.endswith('.yaml')
        histories.append(pin(ROOT / relative))
    sssom = json.loads((OUT / 'history-and-generation/sssom-preservation.json').read_bytes())
    assert sssom['old_row_relative_order_exact'] is True
    assert sssom['actual'] == pin(ROOT / 'output/sssom/source_mappings.sssom.tsv')
    assert (sssom['old_rows'], sssom['added_rows'], sssom['total_rows']) == (62, 4, 66)
    tests_body = (OUT / 'remaining-offline-gates/tests.stdout').read_text()
    test_summaries = [line for line in tests_body.splitlines() if re.search(r'\d+ passed', line)]
    assert len(test_summaries) == 1 and 'failed' not in test_summaries[0]
    histories_receipt = json.loads((OUT / 'history-and-generation/histories-before-generation.json').read_bytes())
    assert histories_receipt['old_histories'] == 408 and histories_receipt['total_histories'] == 410
    assert histories_receipt['old_whole_history_bytes_exact'] is True
    assert sorted(histories_receipt['new_histories'], key=lambda r:r['path']) == sorted(histories,key=lambda r:r['path'])
    wrappers = OUT / 'outer-tool-streams'
    wrappers.mkdir()
    wrapper_bindings = []
    for phase in (*PHASES, 'adoption'):
        phase_runner = PREP / 'adopt.py' if phase == 'adoption' else RUNNER
        source_root = (Path('/private/tmp/pathwaymech-next-240-local-adoption-execution-20261012') if phase == 'adoption' else Path('/private/tmp/pathwaymech-next-240-native-' + OUTER_NAMES[phase] + '-execution-20261012'))
        invocation = json.loads((source_root / 'execution.json').read_bytes())
        assert invocation['exit_code'] == 0
        assert invocation['helper_at_start'] == pin(phase_runner)
        expected_argv = ['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python', '-B', str(phase_runner)]
        expected_argv += ['--execute', '--root-acceptance', '/private/tmp/pathwaymech-next-240-root-integration-acceptance-20261012.json', '--output', '/private/tmp/pathwaymech-next-240-local-adoption-20261012'] if phase == 'adoption' else [phase]
        assert invocation['argv'] == expected_argv
        assert (source_root / 'helper-at-start.py').read_bytes() == phase_runner.read_bytes()
        assert pin(Path(invocation['runner']['path'])) == invocation['runner']
        for stream in ['stdout','stderr']:
            assert pin(source_root / stream) == invocation[stream]
        destination_root = wrappers / phase
        destination_root.mkdir()
        for name in ['execution.json','helper-at-start.py','stdout','stderr']:
            source = source_root / name
            destination = destination_root / name
            destination.write_bytes(source.read_bytes())
            wrapper_bindings.append({'source':pin(source),'retained':pin(destination)})
    wrapper = PREP / 'native-capture-wrapper.py'
    (wrappers / 'capture-wrapper.py').write_bytes(wrapper.read_bytes())
    provenance_source = Path('/private/tmp/pathwaymech-next-240-native-tool-provenance-20261012.json')
    provenance = json.loads(provenance_source.read_bytes())
    assert len(provenance['phase_invocations']) == 4
    assert [x['exit_code'] for x in provenance['phase_invocations']] == [0, 0, 0, 0]
    (OUT / 'actual-tool-provenance.json').write_bytes(provenance_source.read_bytes())
    (OUT / 'sealing-helper.py').write_bytes(Path(__file__).read_bytes())
    copied = OUT / 'input-receipts'
    copied.mkdir()
    bindings = []
    for name, source in [
        ('runner-binding.json', Path('/private/tmp/pathwaymech-next-240-root-native-runner-binding-20261012.json')),
        ('root-acceptance.json', Path('/private/tmp/pathwaymech-next-240-root-integration-acceptance-20261012.json')),
        ('adoption.json', Path('/private/tmp/pathwaymech-next-240-local-adoption-20261012/receipt.json')),
        ('stages.json', PREP / 'stages.json'),
        ('sealer-lineage.json', Path('/private/tmp/pathwaymech-next-240-native-sealer-lineage-20261012.json')),
        ('sealer-predecessor.patch', Path('/private/tmp/pathwaymech-next-240-native-sealer-predecessor-20261012.patch')),
    ]:
        destination = copied / name
        destination.write_bytes(source.read_bytes())
        bindings.append({'source': pin(source), 'retained': pin(destination)})
    result = {
        'status': 'all_nine_native_gates_passed_without_failed_attempts',
        'sealed_at': datetime.datetime.now(datetime.UTC).isoformat(),
        'runner': pin(RUNNER), 'failed_attempts': [], 'completions': completion_pins, 'commands': summary,
        'tests_summary': test_summaries[0], 'histories': histories, 'SSSOM': sssom,
        'input_bindings': bindings, 'outer_wrapper_bindings': wrapper_bindings,
        'histories_before_generation': histories_receipt,
        'outputs': [pin(ROOT / relative) for relative in ['data/pathways/spermidine-biosynthesis-and-metabolism-escherichia-coli.yaml', 'pages/records/PathBank_SMP0002097.html', 'output/kgx/nodes.tsv', 'output/kgx/edges.tsv']],
        'fresh_command_receipts_and_streams_exact': True,
        'history_before_SSSOM_and_render': True,
        'native_review_save_performed': False, 'git_commit_performed': False,
        'publication_performed': False, 'whole_checkout_QA_pending_separate_owner': True,
    }
    write(OUT / 'execution-summary.json', result)
    lines = ['The exact authorized 240 native stages completed in four successful phases. All nine gates and both history commands passed; no failed native attempts were observed in the completed packet. The two histories were created before SSSOM and rendering; the SSSOM output retains all62 prior rows, exact cells/header/multiplicity and relative order and adds the4 accepted mappings (66total rows). Its whole bytes change as expected.', '', test_summaries[0], '', 'Actual commands, start/end times, durations, helper bodies and stdout/stderr are retained. Fresh final evidence checks compare every execution receipt to its first-created origin hash and every stream to its recorded bytes. Exact acceptance/adoption/stages and runner binding are included. The four phase outer captures and the preceding adoption capture are preserved; actual tool handles are separately attributed to root in actual-tool-provenance.json. No gate is rerun by this seal.', '', 'This is execution evidence, not an independent maintained scientific or technical review. Root executes the native pipeline and this final sealer. Aceto rebased the earlier239 evidence-packaging helper without performing or authoring these native commands. Adapter owns independent TECH and whole checkout/cache/page/export QA; Aceto owns separate maintained SCI judgments with explicit inherited Nitrate source reading. No native review was authored or saved, no commit was created, and no public action occurred in this stage.', '', 'The sealing helper reuses239 origin/stream/full-packet checks with concrete240 paths, four successful phases, actual outer capture directories and expected counts. Historical239 failed fetch/retry handling is removed because it is not an observed240 event; unexpected240 failure.json would stop this helper. Scientific source/evidence bytes were not normalized. Root authorized exact adoption, histories and native gates in the integration acceptance. Earlier preparation diagnostics remain retained in their own packets.', '']
    (OUT / 'REPORT.md').write_text('\n'.join(lines))
    rows = []
    directories = []
    for current, dirs, files in os.walk(OUT, followlinks=False):
        for name in dirs:
            p = Path(current) / name
            assert not p.is_symlink()
            directories.append(str(p.relative_to(OUT)))
        for name in files:
            p = Path(current) / name
            assert name not in ('artifact-manifest.json', 'handoff.json')
            row = pin(p); row['relative_path'] = str(p.relative_to(OUT)); row['kind'] = 'regular_file'
            rows.append(row)
    rows.sort(key=lambda row: row['relative_path'])
    write(OUT / 'artifact-manifest.json', {'files': rows, 'directories': sorted(directories), 'walk': 'literal os.walk, ignored/hidden included, symlinks rejected'})
    write(OUT / 'handoff.json', {'status': result['status'], 'runner': pin(RUNNER), 'manifest': pin(OUT / 'artifact-manifest.json'), 'summary': pin(OUT / 'execution-summary.json'), 'artifacts': len(rows), 'directories': len(directories), 'native_review_and_commit_pending': True, 'publication_performed': False})
    print(json.dumps({'handoff': pin(OUT / 'handoff.json'), 'manifest': pin(OUT / 'artifact-manifest.json'), 'summary': pin(OUT / 'execution-summary.json'), 'tests': test_summaries[0], 'artifacts': len(rows)}, indent=2))

if __name__ == '__main__':
    main()
