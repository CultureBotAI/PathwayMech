"Root-only bounded local adoption; input checking has no output or target writes."

import argparse
import hashlib
import os
from pathlib import Path

import common as c


def output_check(value):
    p = Path(value)
    if (
        p.parent != Path("/private/tmp")
        or not p.name.startswith("pathwaymech-next-240-local-adoption-")
        or os.path.lexists(p)
    ):
        raise ValueError("Execution output must be a new direct bounded /private/tmp directory")
    return p


def execute(plan, approval, output):
    # Fix every byte before the first target mutation. Never learn a new payload path.
    loaded = []
    for row in c.scope_check(plan):
        body = c.regular_bytes(row["payload"]["path"])
        if (len(body), hashlib.sha256(body).hexdigest()) != (
            row["payload"]["bytes"],
            row["payload"]["sha256"],
        ):
            raise ValueError("Payload changed while preloading")
        loaded.append((row, body))
    c.checkout_check(plan)
    c.cache_check()
    for row, _ in loaded:
        c.destination_check(row)
    c.verify(approval)
    output.mkdir()
    done = []
    try:
        for row, body in loaded:
            dest = c.destination_check(row)
            dest.parent.mkdir(parents=True, exist_ok=True)
            temporary = dest.with_name("." + dest.name + ".pathbank240-local-adoption")
            with temporary.open("xb") as stream:
                stream.write(body)
                stream.flush()
                os.fsync(stream.fileno())
            temporary.chmod(0o755 if row["executable"] else 0o644)
            c.verify(row["payload"], temporary)
            os.replace(temporary, dest)
            done.append(row["destination"])
        c.checkout_check(plan, adopted=True)
        c.cache_check()
        c.verify(approval)
        c.sealed_check()
        c.write_new(
            output / "receipt.json",
            {
                "status": "local_adoption_complete_no_history_gates_or_publication",
                "approval": approval,
                "handoff": c.pin(c.HERE / "handoff.json"),
                "baseline_commit": c.BASE,
                "baseline_tree": c.TREE,
                "target": str(c.ROOT),
                "changes": done,
                "complete_old_inventory_preserved_outside_exact_plan": True,
                "shared_cache_mutation": False,
                "publication_performed": False,
                "history_gates_native_review_pending": True,
            },
        )
    except BaseException as exc:
        c.write_new(
            output / "failure.json",
            {
                "status": "failed_partial_state_must_be_inspected",
                "completed_destinations": done,
                "error_type": type(exc).__name__,
                "error": str(exc),
                "approval": approval,
            },
        )
        raise


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--check-inputs", action="store_true")
    p.add_argument("--execute", action="store_true")
    p.add_argument("--root-acceptance", type=Path)
    p.add_argument("--output")
    args = p.parse_args()
    if args.check_inputs == args.execute:
        p.error("Choose exactly one of --check-inputs and --execute")
    if args.check_inputs and (args.root_acceptance or args.output):
        p.error("Input checking is inert; no approval or output arguments")
    h, plan = c.check_inputs()
    if args.check_inputs:
        print("Exact local baseline, closed payload, inputs and cache verified; no writes.")
        return
    if not args.root_acceptance or not args.output:
        p.error("Execution requires root acceptance and new external output")
    output = output_check(args.output)
    approval = c.approval_check(args.root_acceptance, h)
    execute(plan, approval, output)
    print("Local adoption complete. History, gates, review and publication remain pending.")


if __name__ == "__main__":
    main()
