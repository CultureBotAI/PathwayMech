"""Capture exact authorized local lifecycle commands and all streams."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
OUT=Path(sys.argv[1]);OUT.mkdir()
ROOT=Path('/private/tmp/pathwaymech-next-240-local-20261012')
argv=sys.argv[2:]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(ROOT/'src')+':'+str(ROOT)}
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
v={'argv':argv,'cwd':str(ROOT),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runner':pin(Path(__file__))};helper=Path(argv[2]);assert helper.is_file();v['helper_at_start']=pin(helper);(OUT/'helper-at-start.py').write_bytes(helper.read_bytes());start=time.monotonic()
with (OUT/'stdout').open('xb') as out,(OUT/'stderr').open('xb') as err:
 r=subprocess.run(argv,cwd=ROOT,env={**os.environ,**env},stdout=out,stderr=err)
assert pin(helper)==v['helper_at_start']
v.update(exit_code=r.returncode,seconds=time.monotonic()-start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout=pin(OUT/'stdout'),stderr=pin(OUT/'stderr'))
(OUT/'execution.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v));raise SystemExit(r.returncode)
