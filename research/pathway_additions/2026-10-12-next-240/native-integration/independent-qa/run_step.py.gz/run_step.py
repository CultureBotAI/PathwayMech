"""Capture actual bounded author commands, preserving helper and stream origins."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

H = Path(__file__).resolve().parent
PY = '/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
step, helper = sys.argv[1:]
out = H / 'executions' / step
out.mkdir(parents=True, exist_ok=False)
source = H / helper
(out / 'helper.py').write_bytes(source.read_bytes())
record = {'step': step, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'wrapper': pin(Path(__file__)), 'executed_helper': pin(source),
          'preserved_executed_helper': pin(out / 'helper.py'),
          'command': [PY, '-B', str(source)], 'cwd': str(H),
          'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'}}
(out/'start.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'stdout').open('wb') as stdout, (out/'stderr').open('wb') as stderr:
    proc = subprocess.run(record['command'],cwd=H,env=os.environ|record['environment_overrides'],stdout=stdout,stderr=stderr,check=False)
record.update({'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':proc.returncode,
               'stdout':pin(out/'stdout'),'stderr':pin(out/'stderr')})
(out/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((out/'stdout').read_text())
print((out/'stderr').read_text(),file=sys.stderr)
sys.exit(proc.returncode)
