"""Rebase239 complete external SCI sealing; no maintained save or mutation."""
import datetime,hashlib,json,os,stat
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-240-local-20261012')
Q=Path('/private/tmp/pathwaymech-next-240-independent-maintained-tech-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(n,v):(H/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def read(n):return json.loads((H/n).read_text())
assert read('native-validation.execution.json')['exit_code']==0
proposal=H/'completed-review.yaml';assert pin(proposal)==read('native-validation.execution.json')['proposal_at_start']
(H/'completed-review-ready.yaml').write_bytes(proposal.read_bytes());x=yaml.safe_load(proposal.read_text())
for v in x['source']['inputs']:assert pin(R/v['path'])['sha256']==v['sha256']
for v in x['evidence']:
 prefix='research/pathway_additions/2026-10-12-next-240/native-integration/';path=v['reference']
 if path.startswith(prefix+'independent-qa/'):p=H/path.removeprefix(prefix+'independent-qa/')
 elif path.startswith(prefix+'independent-tech-review/'):p=Q/path.removeprefix(prefix+'independent-tech-review/')
 else:p=R/path
 assert pin(p)['sha256']==v['snapshot_sha256'],path
execution_rows=[]
for p in sorted((H/'executions').glob('*/completion.json')):
 d=json.loads(p.read_text())
 for k in ['preserved_executed_helper','stdout','stderr']:assert pin(Path(d[k]['path']))==d[k]
 assert d['executed_helper']['sha256']==d['preserved_executed_helper']['sha256']
 execution_rows.append({'receipt':pin(p),'exit_code':d['exit_code'],'executed_helper_hash':d['executed_helper']['sha256']})
copy=read('actual-native-copy.json')
for row in copy['files']:
 for k in ['source','destination']:assert pin(Path(row[k]['path']))==row[k]
summary=read('final-review-summary.json');native=read('actual-native/execution-summary.json');reading=read('accepted-reading.json')
dump('sealing-currentness.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_native_inputs_still_exact':len(x['source']['inputs']),'durable_evidence_whole_hashes':len(x['evidence']),'executed_helper_bodies_and_streams':execution_rows,'all_native_original_and_copy_bytes_unchanged':len(copy['files']),'no_native_save':True})
dump('read-coverage-final.json',{'reviewer':'/root/aceto236_design_acceptance_review','fresh':['Complete1373-line accepted scoped scientific record read in five bounded chunks; subsequent maintained bytes exactly equal.','Full earlier science/scope reports, all individual18 paragraph/58 edge/4 qualifier/43 identity rationales and whole current objects reconciled.','All42 reference objects and4 mapping rows,100 exact evidence locator/reference/assertion strings current; earlier XPath/native-match replay inherited.','All66 whole scientific bodies/66 acquisition receipts plus3 native-original entries equal maintained decoded portable representations;8 portable owners rebound.','Separate Adapter complete report and target/checkout results read and bound; structural/visual authorship explicitly separate.','Complete124 current structured review YAML files searched with ignored/hidden files included; no exact target predecessor.','Actual whole native execution packet and first-origin/stream bindings checked; no native gate rerun.'], 'inherited_from_Nitrate':['Three complete HTML primary texts PMID17124497/20530482/19542271;19 original figures;all five scanned1986 pages PMID3526348 including tables/figures/reference/note added in proof.','Fourteen complete available primary abstracts and metadata-only PMID4203512, at actual access tier.','Complete current208-object BioPAX,22 native sides, assemblies and context;86 selected biological PWML frames;four complete UniProt scientific frames and sequences;18 chemical originals/3 taxonomy XML;10 native kinetic groups and2006 Table1 including ten mutants.','Accepted document-scoping successor transforms32 declarations/97 endpoints across54 edges, preserves complete non-endpoint science and all four literal-source mappings.'], 'reading_boundary':read('scientific-judgment.json')['limitations'],'accepted_reading_binding':pin(H/'accepted-reading.json'),'currentness':pin(H/'final-current-bindings.json'),'native_inputs':len(x['source']['inputs']),'shared_QA':pin(Q/'handoff.json')})
report=f'''The exact maintained PathBank:SMP0002097 record passes independent scientific review with stated limitations. All18 paragraphs,58 complete edges,4 endpoint qualifiers,43 identities,42 references and4 mappings preserve accepted scientific meaning. The target remains79,673bytes/SHA2560adef1da2d818af7c62d7e3952b2115585b47b8f132ec189cde2b435d2721680. No actionable scientific finding or required product edit was identified.

This reviewer did not author240 preflight, scientific drafts, earlier science reviews or runtime implementation. Deoxy authored the record/runtime. Earlier independent reviewer Nitrate's complete primary/native reading is inherited explicitly; it is not this reviewer's personal fresh paper reading. The complete current scoped record and every earlier paragraph/edge/qualifier/identity rationale were freshly read and reconciled. Three complete HTML primary texts,19 original figures, five scanned1986 pages,14 available abstracts, the metadata-only1973 citation and the full selected native frames retain their actual reading/access tiers. Two inaccessible SI challenge bodies, unavailable export-paper full text, raw PWML parser accommodation and unreviewed unrelated frame detail remain explicit limits.

The record retains the complete current four chemical events plus transport and22 native sides, separate unresolved SAM interface, SpeD processing and conflicting assembly descriptions, alternative metal activation, Gss synthesis/amidase distinction, construct-specific kinetic values, native chemical mismatches and strain boundaries. Neither the unidentified transporter/coupling nor continuity links are elevated to established transport mechanisms or physical channeling. Deletion/oxygen/medium-specific phenotypes do not establish universal essentiality. All32 document-local PathBank declarations and97 corresponding endpoints use the independently accepted document scope; the original missed scoping defect and its external successor disposition are inherited transparently, without inventing a native predecessor.

Fresh byte-level and parsed whole-object checks cover all66 complete scientific bodies/66 acquisition receipts plus3 native-original entries, all42 reference objects,4 mapping rows and100 evidence strings. Eight maintained portable owners reproduce the whole originals. Earlier actual locator matched-node reading is inherited, while current strings and exact source bodies are freshly compared. Complete closures of author169+2, independentSCI62+2, scopedauthor20+2 and scopeindependentreview21+2 passed. The ignored/hidden-inclusive search read all124 current structured YAMLs and found no exact target predecessor.

Adapter separately owns fresh complete maintained page/graph/export/authority/checkout/cache and technical QA. Its sealed packet was fully closed, its report and actual relevant results read, and current native inputs bind the actual page/exports. Visual interpretation is attributed as stated there; this reviewer performed no personal interactive-browser or figure-pixel review. Root owns all actual native gates. {native['tests_summary'].strip()} All12 native commands ultimately passed; {len(copy['historical_failures'])} failed phase attempts are retained as actual history. The whole {len(copy['files'])}-file execution packet, original seals, first-origin receipt hashes, helper bodies, outer captures and streams are copied exactly. No gate was rerun. Aceto separately rebased the239 evidence-sealing helper at root request; root executed it. Evidence packaging is distinct from scientific judgment or native execution authorship.

One bounded review-helper failure is retained: the first locator comparison assumed scope qualifier instead of the original ledger's qualifier-1. Original helper, streams and seven partial outputs are preserved; the corrected helper passed without changing scientific sources or maintained bytes. Incidental top-level lookup limitations are recorded in prereading/provenance, not reported as scientific evidence absence. Preparatory JSON retains its original pending-state wording; final currentness/native/shared-QA receipts establish completion.

The external native proposal has{summary['assessments']}assessments,{summary['checks']}checks,{summary['evidence']}evidence items and{len(x['source']['inputs'])}original inputs. Native shared-serializer validation passed, and all native input/evidence hashes remain exact. completed-review-ready.yaml is byte-identical to the validated proposal. Concrete durable references use independent-qa and independent-tech-review. Root may later extend source inputs only through explicit inspected evidence adoption while preserving original inputs, judgments and timestamps. Audit Python bodies may be stored as deterministic lossless gzip with decoded path/hash bindings; directly cited JSON paths must remain exact. No maintained product/cache/history/native-review/Git/GitHub mutation or public release/license clearance was performed by this review.
'''
(H/'REPORT.md').write_text(report)
dump('durable-adoption-instructions.json',{'prefix':'research/pathway_additions/2026-10-12-next-240/native-integration/independent-qa','whole_packet_required':True,'audit_python_storage':'Exact original bodies may be stored losslessly as .py.gz with explicit original path/bytes/hash and stored path/bytes/hash; whole reconstructed closure must pass.','references':'All directly cited JSON/YAML/REPORT body paths and hashes unchanged; independent-tech-review is a separately accepted packet.','native_proposal':pin(H/'completed-review-ready.yaml'),'preserve':'Every original source descriptor, scientific judgment, reviewer identity, original reading claim and timestamp; only explicit native inspected additional source inputs may be added.'})
files=[];dirs=[]
for base,ds,fs in os.walk(H,followlinks=False):
 for name in ds:
  p=Path(base)/name;assert stat.S_ISDIR(p.lstat().st_mode);dirs.append(str(p.relative_to(H)))
 for name in fs:
  p=Path(base)/name;assert stat.S_ISREG(p.lstat().st_mode)
  if p.parent==H and p.name in ['artifact-manifest.json','handoff.json']:continue
  files.append(pin(p)|{'relative_path':str(p.relative_to(H)),'kind':'regular_file'})
files.sort(key=lambda v:v['relative_path']);dirs.sort()
dump('artifact-manifest.json',{'files':files,'directories':dirs,'walk':'literal os.walk, hidden/ignored included; symlinks and special objects rejected'})
dump('handoff.json',{'status':'independent_maintained_scientific_review_pass_with_limitations_validated_not_saved','sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'directories':len(dirs),'proposal':pin(H/'completed-review-ready.yaml'),'validated_proposal':pin(proposal),'native_validation':pin(H/'native-validation.execution.json'),'target_sha256':'0adef1da2d818af7c62d7e3952b2115585b47b8f132ec189cde2b435d2721680','shared_QA':pin(Q/'handoff.json'),'native_original_handoff':pin(H/'actual-native/handoff.json'),'evidence_destination':'research/pathway_additions/2026-10-12-next-240/native-integration/independent-qa','reviewer':'/root/aceto236_design_acceptance_review','inherited_original_scientific_reviewer':'/root/nitrate235_finish','native_save_performed':False,'required_findings':[]})
for row in files:assert pin(Path(row['path']))['sha256']==row['sha256']
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'proposal':pin(H/'completed-review-ready.yaml'),'artifacts':len(files),'directories':len(dirs)},indent=2))
