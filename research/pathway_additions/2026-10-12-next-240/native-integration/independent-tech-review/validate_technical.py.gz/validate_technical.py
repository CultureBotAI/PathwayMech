import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
H=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-240-local-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
cmd=['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B','scripts/record_review.py','--repo-root',str(R),'validate',str(H/'technical-proposal.json')]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'};start=datetime.datetime.now(datetime.UTC).isoformat();tick=time.monotonic()
with (H/'technical-validate.stdout').open('xb') as out,(H/'technical-validate.stderr').open('xb') as err:r=subprocess.run(cmd,cwd=R,env={**os.environ,**env},stdout=out,stderr=err)
receipt={'command':cmd,'cwd':str(R),'environment':env,'started_at':start,'finished_at':datetime.datetime.now(datetime.UTC).isoformat(),'seconds':time.monotonic()-tick,'exit_code':r.returncode,'helper':pin(Path(__file__)),'content':pin(H/'technical-proposal.json'),'stdout':pin(H/'technical-validate.stdout'),'stderr':pin(H/'technical-validate.stderr')}
(H/'technical-validate.execution.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(r.returncode)
