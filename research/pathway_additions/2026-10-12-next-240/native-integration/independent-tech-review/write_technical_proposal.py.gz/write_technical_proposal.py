"""Independent technical judgments after current maintained checks; no native save."""
import datetime
import hashlib
import json
import re
import shlex
import shutil
from pathlib import Path

H = Path(__file__).parent
R = Path('/private/tmp/pathwaymech-next-240-local-20261012')
N = Path('/private/tmp/pathwaymech-next-240-local-native-execution-20261012')
PREFIX = 'research/pathway_additions/2026-10-12-next-240/native-integration/'
LOCAL = PREFIX + 'independent-tech-review/'


def load(p):
    return json.loads(Path(p).read_bytes())


def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


now = datetime.datetime.now(datetime.UTC)
finished = now.strftime('%Y-%m-%dT%H:%M:%SZ')
inspection = load(H / 'technical-inspect.stdout')
assert inspection['status'] == 'inspection_only'
for row in inspection['source']['inputs']:
    assert pin(R / row['path'])['sha256'] == row['sha256'], row['path']

for source, dest in [
    ('/private/tmp/pathwaymech-next-240-root-canonical-output-acceptance-20261012.json', 'canonical-acceptance.json'),
    ('/private/tmp/pathwaymech-next-240-root-integration-acceptance-20261012.json', 'integration-acceptance.json'),
    ('/private/tmp/pathwaymech-next-240-root-implementation-acceptance-20261012.json', 'implementation-acceptance.json'),
    ('/private/tmp/pathwaymech-next-240-root-order-acceptance-20261012.json', 'order-acceptance.json'),
    ('/private/tmp/pathwaymech-next-240-root-scoped-preview-acceptance-20261012.json', 'preview-acceptance.json'),
    ('/private/tmp/pathwaymech-next-240-canonical-output-independent-review-20261012/handoff.json', 'prior-actual-review-handoff.json'),
]:
    assert not (H / dest).exists()
    shutil.copyfile(source, H / dest)

target_ids = [t['target_id'] for t in inspection['targets']]
assert len(target_ids) == 8
evidence = []
checks = []


def ev(eid, path, reference, summary, kind='validation'):
    evidence.append({'evidence_id': eid, 'kind': kind, 'reference': reference,
                     'accessed_at': finished, 'support': 'supports', 'summary': summary,
                     'snapshot_sha256': pin(path)['sha256']})


for phase in ['history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates']:
    completion = load(N / phase / 'completion.json')
    assert completion['status'] == 'phase_passed'
    for receipt in completion['receipts']:
        assert receipt['exit_code'] == 0
        for stream in ('stdout', 'stderr'):
            assert pin(receipt[stream]['path'])['sha256'] == receipt[stream]['sha256']
        eid = 'native-' + receipt['name']
        path = N / phase / (receipt['name'] + '.execution.json')
        ev(eid, path, PREFIX + 'independent-qa/actual-native/' + phase + '/' + path.name,
           'Actual native command and complete original streams verified. Executed by the integration agent; this reviewer did not repeat it.')
        checks.append({'check_id': eid, 'name': 'Actual native ' + receipt['name'],
                       'status': 'passed', 'required': not receipt['name'].startswith('history-'),
                       'summary': 'Actual recorded process exited 0; scientific interpretation is separately reviewed.',
                       'target_ids': target_ids, 'command': shlex.join(receipt['argv']),
                       'exit_code': 0, 'expected_exit_code': 0, 'evidence_ids': [eid]})
        if receipt['name'] == 'tests':
            matches = re.findall(r'(\d+) passed, (\d+) skipped, (\d+) warnings?', Path(receipt['stdout']['path']).read_text())
            assert len(matches) == 1
            passed, skipped, warnings = map(int, matches[0])

for name in ('target', 'checkout'):
    receipt = load(H / (name + '.execution.json'))
    assert receipt['exit_code'] == 0
    ev('independent-' + name, H / (name + '.execution.json'), LOCAL + name + '.execution.json',
       'This independent reviewer executed complete current target/render/export or physical checkout/cache checks after native gates completed.')
    checks.append({'check_id': 'independent-' + name, 'name': 'Independent maintained ' + name + ' QA',
                   'status': 'passed', 'required': True, 'summary': 'Whole maintained check passed after all native gates.',
                   'target_ids': target_ids, 'command': shlex.join(receipt['argv']),
                   'exit_code': 0, 'expected_exit_code': 0, 'evidence_ids': ['independent-' + name]})

for eid, name, summary, kind in [
    ('native-packet', 'native-execution-intake.json', 'Fresh ignored-inclusive no-follow closure of the exact sealed81-artifact native gate packet plus two seals; every complete receipt and stream remains byte bound.', 'validation'),
    ('canonical', 'canonical-acceptance.json', 'Root accepted whole native source/ontology outputs and independent old-object/order/KGX preservation review.', 'prior_review'),
    ('prior-actual-audit', 'prior-actual-review-handoff.json', 'This reviewer previously audited all 1921 actual artifacts plus two seals, whole scientific corpus, complete source objects/order, all selectors and complete KGX. That unchanged audit is inherited explicitly.', 'prior_review'),
    ('integration', 'integration-acceptance.json', 'Root accepted exact 18 destinations, nine primary owners, complete guards/native stages and hidden/ignored baseline/cache. The preparer 2761-body portable replay is inherited.', 'prior_review'),
    ('implementation', 'implementation-acceptance.json', 'The incomplete child PathWhiz/interface reference context finding is resolved; this reviewer previously ran 191 focused tests and 34 independent controls. That exact reviewed implementation contract is inherited.', 'prior_review'),
    ('ordering', 'order-acceptance.json', 'Root independently reproduced the old context-owner order defect and fixed deterministic serialization across five hash seeds. The only production correction is explicit metadata field order; prior identities, values and validation remain unchanged.', 'prior_review'),
    ('target-results', 'target-qa.json', 'Complete maintained scoped YAML, 58 arrows, 44 display nodes, four qualifiers, 43 identities, 42 references and rendered evidence checked. Authorities and whole exports equal accepted native bodies; SSSOM retains 62 old plus four new rows.', 'validation'),
    ('checkout-results', 'checkout-preservation.json', 'Ignored-inclusive complete physical owners/cache checked. All 240 old records/pages, 124 review pairs and 408 histories remain exact; only declared owners/generated files and two histories change.', 'validation'),
    ('visual', 'visual-assessment.json', 'Whole maintained SVG/CSS/JS equal the root-viewed scoped preview; root static visual appraisal is inherited explicitly, with dense junctions, truncated labels and blank canvas limitations.', 'validation'),
    ('preview', 'preview-acceptance.json', 'Root personally viewed the complete corrected-target static light graph; no browser interaction, responsive, dark or print acceptance.', 'prior_review'),
]:
    ev(eid, H / name, LOCAL + name, summary, kind)

assessments = []


def assess(aid, area, topic, summary, ids, evs):
    assessments.append({'assessment_id': aid, 'area': area, 'topic': topic, 'outcome': 'supported',
                        'summary': summary, 'target_ids': ids, 'evidence_ids': evs})


for target in inspection['targets']:
    assess(target['target_id'], 'ownership', target['path'],
           'Whole maintained owner equals the accepted deterministic runtime/configuration/native-output payload. The complete context contract and producer/consumer changes were independently reviewed upstream; current maintained integration and the actual full regression are verified here. Generated snapshot changes must be rebuilt from maintained configuration and adapters.',
           [target['target_id']], ['canonical', 'implementation', 'ordering', 'independent-target', 'integration'])
assess('prior-preservation', 'provenance', 'Whole authority and checkout preservation',
       'All prior authority objects, nested order and first owners survive. The 892-entry manifest preserves all 887 old rows; ontology and Rhea are unchanged. All 240 old records/pages, 124 review pairs and 408 histories remain exact. Two actual histories precede SSSOM and first rendering.',
       target_ids, ['prior-actual-audit', 'checkout-results', 'native-history-1', 'native-history-2'])
assess('graph-exports', 'graph', 'Whole graph and current page',
       'All 58 edges, 44 display nodes, four qualifiers, 42 references and 43 identities resolve. Current KGX has 4357 nodes/12110 edges and preserves all 12052 old edges plus prior node payloads/order. Only six shared nodes gain exact target contexts; no aggregate field or category-union changes.',
       target_ids, ['canonical', 'prior-actual-audit', 'target-results', 'visual'])
assess('mapping-export', 'representation', 'Complete source mappings',
       'Native SSSOM preserves complete header and 62 old rows, every cell, multiplicity and relative order; it adds four exact target mappings for 66 total, following native subject sorting.',
       target_ids, ['native-sssom', 'target-results'])
assess('native-gates', 'schema', 'Fresh maintained validation',
       f'All nine native gates passed for 241 records: {passed} tests passed, {skipped} skipped and {warnings} warnings retained. Render, skills, validation, lint, KGX, vendored, diff and site-current evidence is complete. Native execution was by the integration agent; this reviewer verified receipts and streams rather than rerunning passing broad gates.',
       target_ids, ['native-packet', 'native-validate', 'native-tests', 'native-lint', 'native-kgx', 'native-vendored', 'native-diff-check', 'native-site-current'])
assess('portable-evidence', 'completeness', 'Whole evidence provenance',
       'Accepted preparation retains 2761 whole bodies, 1844 reused and 917 new, across 14 current packets; 891 authority originals and all 92 acquisition attempts/66 received scientific bodies are retained. All 42 reference hashes resolve. The preparer complete portable replay is inherited; the maintained index and payload bytes are freshly bound. Both resolved local technical findings and original failures remain available.',
       target_ids, ['integration', 'implementation', 'ordering', 'independent-target', 'checkout-results'])

started = datetime.datetime.fromisoformat(load(H / 'technical-inspect.execution.json')['started_at']).astimezone(datetime.UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
value = {
    'schema_version': '1.0.0', 'review_id': now.strftime('%Y%m%dT%H%M%SZ') + '-pathbank240-technical',
    'kind': 'repository', 'repository': 'CultureBotAI/PathwayMech',
    'title': 'Technical review of E. coli spermidine PathBank context integration',
    'started_at': started, 'finished_at': finished,
    'reviewer': {'identity': 'Codex /root/adapter_continue', 'kind': 'agent', 'independence': 'independent',
                 'independence_basis': 'This reviewer did not author the scientific record, production adapter, canonical preparation/execution, maintained adoption or native gate execution. The reviewer previously independently audited the complete context implementation and actual canonical outputs, and authored only external review helpers/artifacts. The later ordering correction is inherited from distinct root independent review. Independent SCI review belongs to a separate agent.'},
    'skill': '.claude/skills/review-yaml-record/SKILL.md', 'completion': 'completed',
    'verdict': 'pass_with_limitations', 'scientific_review': False,
    'summary': 'Eight exact technical owners pass current maintained integration review. All old objects/files/cache, complete mappings and current graph are preserved; actual native gates pass. Both resolved local context findings, inherited science and static layout limits remain explicit.',
    'source': inspection['source'],
    'scope': {'description': 'Eight runtime/configuration/fixture/test/authority owners after completed record 240 gates, with complete maintained context.',
              'selection': 'All eight nonrecord primary owners from committed 239 baseline 5eb77a4b8039e98d9b53a61d09af52fa9f5b3d7a; no sampling.',
              'coverage': 'full', 'population_size': 8, 'reviewed_target_ids': target_ids,
              'exclusions': [{'target': 'New primary scientific judgment', 'reason': 'Separate independent maintained scientific review.'},
                             {'target': 'Publication and browser interaction', 'reason': 'Not performed or authorized within this local technical review.'}]},
    'targets': inspection['targets'], 'checks': checks, 'evidence': evidence,
    'assessments': assessments, 'findings': [], 'actions': [],
    'limitations': [
        'Prior complete implementation adversarial tests, actual canonical audit and accepted preparation portable replay are inherited explicitly; current maintained page, exports, owners, full physical inventory/cache and native gate receipt/streams are freshly checked.',
        'The root personally viewed static light scoped preview is inherited only after whole current SVG/CSS/JS equality. This reviewer claims no new visual or browser interaction test. Dense junctions, label truncation and blank canvas remain; responsive, keyboard, dark and print behavior are untested.',
        f'Actual regression retains {skipped} skips and {warnings} warnings with {passed} passes.',
        'Evidence references name planned concrete dossier destinations. Native save requires exact-byte evidence adoption and a current-input recheck; this external proposal is not a saved native review.',
    ],
    'notes': ['Native inspection followed completed gates and independent maintained QA; every captured current input hash was rechecked before this proposal.',
              'The technical review uses the native repository review schema/serialization contract; it does not claim the separate full scientific skill workflow.',
              'Original local findings pathbank240-incomplete-interface-context and pathbank240-context-owner-order remain distinct from their accepted successor dispositions; no GitHub issue is claimed.',
              'No SQL full hashes, broad test suites or native builders were repeated by this reviewer; no maintained product edit, native save, public action or licensing clearance occurred.'],
    'links': [], 'tags': ['spermidine', 'pathbank-context', 'technical-review', 'local-only'],
}
with (H / 'technical-proposal.json').open('x') as f:
    json.dump(value, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps({'proposal': pin(H / 'technical-proposal.json'), 'targets': len(target_ids),
                  'assessments': len(assessments), 'checks': len(checks), 'inputs': len(inspection['source']['inputs'])}))
