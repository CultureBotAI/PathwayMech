"Compare complete accepted deltas and prepare concrete root-owned native stages."

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import yaml

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-238-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-238-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
RID = "MetaCyc:PWY-8130"


def stable(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before, after = c.load(c.ROOT / rel), c.load(PAY / rel)
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [k for k in new if k in old] == list(old)
                for ident, value in old.items():
                    assert stable(value) == stable(new[ident]), (name, key, ident)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [k for k in new if k not in old],
                    "all_old_whole_objects_and_nested_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(PAY / rel),
            "sections": sections,
        }
    oldmanifest = c.load(c.ROOT / "conf/identifier_sources.json")
    newmanifest = c.load(PAY / "conf/identifier_sources.json")
    assert len(oldmanifest) == 869 and len(newmanifest) == 874
    assert stable(newmanifest[:869]) == stable(oldmanifest)
    assert c.regular_bytes(c.ROOT / "conf/rhea_identifier_updates.json") == c.regular_bytes(
        BUILD / "rhea-updates.json"
    )
    bn, an = rows(c.ROOT / "output/kgx/nodes.tsv"), rows(BUILD / "actual-kgx/nodes.tsv")
    be, ae = rows(c.ROOT / "output/kgx/edges.tsv"), rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = {r["id"]: r for r in be}
    assert [r for r in ae if r["id"] in oldedges] == be
    oldnodes, newnodes = {r["id"]: r for r in bn}, {r["id"]: r for r in an}
    changes, aggregate = [], []
    contexts = additions = 0
    for ident, old in oldnodes.items():
        new = newnodes[ident]
        prior = json.loads(old["source_contexts"])
        current = json.loads(new["source_contexts"])
        assert [v for v in current if v["record_id"] != RID] == prior
        delta_contexts = [v for v in current if v["record_id"] == RID]
        contexts += len(prior)
        additions += len(delta_contexts)
        delta = {
            key: {"before": value, "after": new[key]}
            for key, value in old.items()
            if key != "source_contexts" and value != new[key]
        }
        if delta:
            aggregate.append({"id": ident, "fields": delta})
        if old != new:
            changes.append({"id": ident, "before": old, "after": new})
    expected_delta = []
    assert aggregate == expected_delta
    assert len(changes) == additions == 14
    assert (len(bn), len(be), len(an), len(ae)) == (4297, 11987, 4303, 12008)
    record = yaml.safe_load(
        c.regular_bytes(PAY / "data/pathways/5-prime-deoxyadenosine-degradation-i.yaml")
    )
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for mapping in record.get("source_mappings", []):
        row = {k: mapping[k] for k in cols if k != "comment"}
        row["comment"] = (
            f"source_pathway_id={mapping['source_pathway_id']}; "
            f"source_element_id={mapping['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(row[k])).strip() for k in cols})
    existing = Counter(stable(r) for r in oldss)
    assert len(oldss) == 32 and all(n == 1 for n in existing.values())
    added = [r for r in newss if stable(r) not in existing]
    assert len(added) == len(newss) == 10
    files = c.load(H / "baseline-files.json")

    def count(prefix, suffix):
        return sum(r["path"].startswith(prefix) and r["path"].endswith(suffix) for r in files)

    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": count("data/pathways/", ".yaml"),
        "old_review_yaml": count("reviews/", ".yaml"),
        "old_review_markdown": count("reviews/", ".md"),
        "old_history_yaml": count("history/", ".yaml"),
        "native_authorities": native,
        "manifest_prefix_rows": 869,
        "manifest_after_rows": 874,
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_order_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_changes": aggregate,
        "aggregate_display_scope": (
            "No aggregate field changes. All old labels, categories, direction"
            "s and contexts remain exact."
        ),
        "old_authority_object_exceptions": [],
        "planning_decisions": [c.pin(PRE / "graph-planning-decision.json")],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = json.loads(
        json.dumps(c.load(OLD / "stages.json"))
        .replace("pathwaymech-next-237", "pathwaymech-next-238")
        .replace("5-prime-deoxyadenosine-degradation-ii", "5-prime-deoxyadenosine-degradation-i")
        .replace("PWY-8131", "PWY-8130")
    )
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="conf/identifier_sources.json",
        description=(
            "Exact accepted 874-row manifest and two actual snapshots with unc"
            "hanged 270-file runtime. Preserve all old authority objects, cont"
            "ext and first owners."
        ),
        issue_lineage=[],
    )

    def history(kind, slug, owner_args, event, summary, details):
        return [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            kind,
            "--slug",
            slug,
            *owner_args,
            "--event",
            event,
            "--outcome",
            "changed",
            "--summary",
            summary,
            "--details",
            details,
            "--actor-name",
            "codex",
            "--agent-tool",
            "codex",
            "--model",
            "gpt-6",
        ]

    stages["history_commands"] = [
        history(
            "record",
            "5-prime-deoxyadenosine-degradation-i",
            ["--target-root", "data/pathways"],
            "CREATE",
            "Add the complete evidence-backed 5-prime-deoxyadenosine degradation I record.",
            (
                "Adopted exact accepted MetaCyc:PWY-8130: 10 paragraphs, 21 edges,"
                " five endpoint qualifiers, 20 named identities, 42 references and"
                " ten source mappings. Complete three-event route, nine chemical-s"
                "ide occurrences, six kinetic slots, nested MtnP assembly and conf"
                "licting dimer label, shared Ald2 contexts, construct/taxon/metal "
                "evidence and source access limits retained in research/pathway_ad"
                "ditions/2026-10-12-next-238. Actual native outputs independently "
                "reviewed. Fresh maintained gates and native saved review remain p"
                "ending."
            ),
        ),
        history(
            "infrastructure",
            "deoxy238-native-authority",
            ["--path", "conf/identifier_sources.json"],
            "EDIT",
            "Integrate complete PWY-8130 authority sources and accepted native snapshots.",
            (
                "Adopted exact 874-row manifest retaining all 869 prior entries an"
                "d two actual native snapshots. Existing 270-file runtime and Rhea"
                " updates remain unchanged; whole old authority objects/order and "
                "first owners preserved. No aggregate graph label, category or dir"
                "ection changes; all old contexts remain exact. Local integration "
                "only; histories precede generation, and maintained gates/native r"
                "eview remain pending."
            ),
        ),
    ]
    stages["after_gates"] = [
        (
            "Inspect the complete actual PWY-8130 page/graph, all 10 paragraph"
            "s/21 edges, five qualifiers, 20 identities, 42 references and ten"
            " mappings against exact accepted science and original limitations"
            "."
        ),
        (
            "Native inspect actual maintained inputs before judgments; preserv"
            "e inherited complete-source review versus fresh maintained QA; va"
            "lidate/save/check two immutable scientific and technical reviews."
        ),
        (
            "Verify 238 prior records/pages, 120 review pairs and 404 old hist"
            "ories; preserve every old whole authority object/order, all 11987"
            " old KGX edges and old context payloads/order/multiplicity."
        ),
        (
            "No aggregate node field changes permitted. Expected native first-"
            "encounter node ordering is accepted; all old context labels remai"
            "n exact."
        ),
        (
            "Native SSSOM export must retain all 32 old rows/cells/order/heade"
            "r and add exactly the ten accepted target mappings, for 42 total "
            "rows."
        ),
        (
            "Recheck all 800 shared-cache identities and complete hidden/ignor"
            "ed checkout outside exact primary/dossier/history/generated/revie"
            "w additions; final independent actual-tree and append-only verifi"
            "cation before local commit."
        ),
    ]
    stages["before_first_render_after_history"][0].update(
        reason=(
            "Export the ten accepted source_mappings through the native serial"
            "izer after both histories and before rendering/tests."
        ),
        preservation=(
            "All 32 old SSSOM rows/cells/order/header exact; ten target additi"
            "ons and 42 total rows required."
        ),
    )
    interfaces = stages["native_review_interfaces"]
    interfaces.pop("accepted_provider_successor_handoff", None)
    interfaces["inherited_science_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-238-science-review-20261012/handoff.json"
    )
    interfaces["actual_native_review_handoff"] = c.pin(
        
            "/private/tmp/pathwaymech-next-238-canonical-output-independent-re"
            "view-20261012/handoff.json"
        
    )
    interfaces["save_template"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "save",
        "--content",
        "<independently-reviewed-completed-review.json>",
    ]
    interfaces["check_after_save"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "check",
        "--require-reviews",
        "--base",
        c.BASE,
    ]
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    assert stages["preservation_counts"] == {
        "old_records": 238,
        "old_review_yaml": 120,
        "old_review_markdown": 120,
        "old_history_yaml": 404,
    }
    c.write_new(H / "stages.json", stages)
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Committed accepted deoxy237 local branch; not merged main",
            "primary_owners": len(c.PRIMARY),
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(
                PAY / "data/pathways/5-prime-deoxyadenosine-degradation-i.yaml"
            ),
            "actual_native_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-238-root-canonical-output-acceptance-20261012.json"
            ),
            "baseline_postcommit_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-237-root-postcommit-acceptance-20261012.json"
            ),
            "remaining": [
                "independent preparation review",
                "root exact acceptance",
                "local adoption",
                "two native histories before SSSOM/render",
                "nine maintained gates",
                "actual page/graph QA",
                "native saved reviews",
                "complete preservation and final adversarial review",
            ],
            "source_exhaustion": False,
            "licensing": "Public-release licensing remains deferred; publication not authorized.",
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_files",
                    "old_records",
                    "old_review_yaml",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                    "exact_aggregate_changes",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
