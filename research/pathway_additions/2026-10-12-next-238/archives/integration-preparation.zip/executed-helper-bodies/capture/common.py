"""Exact local deoxy238 integration guards; no import-time I/O."""

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/pathwaymech-next-238-local-20261012")
BASE = "5d3198b18a4a0f82175a65df48dd8a63664cd32d"
TREE = "6ddc309c10e03cf9437ad0bdf13cead66b37606c"
BRANCH = "feat/pathway-next-238-local-20261012"
DOSSIER = "research/pathway_additions/2026-10-12-next-238"
CACHE = Path("/private/tmp/pathwaymech-curation-authorities/sources")
PRIMARY = frozenset(['conf/identifier_sources.json', 'data/identifier_authorities/ontology.json', 'data/identifier_authorities/sources.json', 'data/pathways/5-prime-deoxyadenosine-degradation-i.yaml'])


def relative(value):
    """Require an already normalized repository-relative POSIX path."""
    p = Path(value)
    if (
        not isinstance(value, str)
        or p.is_absolute()
        or ".." in p.parts
        or str(p) in {"", "."}
        or p.as_posix() != value
    ):
        raise ValueError(f"Unsafe relative path: {value}")
    return p


def regular_bytes(path):
    """Reject parent links and special objects before opening content."""
    path = Path(path)
    for ancestor in (path, *path.parents):
        mode = ancestor.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise ValueError(f"Literal link is not a regular owner: {ancestor}")
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError(f"Regular file required: {path}")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise ValueError(f"Regular opened file required: {path}")
        return stream.read()


def pin(path):
    b = regular_bytes(path)
    return {"path": str(path), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}


def verify(row, path=None):
    actual = pin(Path(path or row["path"]))
    if (actual["bytes"], actual["sha256"]) != (row["bytes"], row["sha256"]):
        raise ValueError(f"Changed body: {actual['path']}")
    return actual


def load(path):
    return json.loads(regular_bytes(path))


def write_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def inventory(root, exclude_git=False):
    """Full hidden/ignored census. Links and specials are never opened."""
    root = Path(root)
    rows = []
    directories = []
    for base, ds, fs in os.walk(root, followlinks=False):
        ds.sort()
        fs.sort()
        if exclude_git and Path(base) == root:
            ds[:] = [n for n in ds if n != ".git"]
            fs = [n for n in fs if n != ".git"]
        for name in ds + fs:
            p = Path(base) / name
            mode = p.lstat().st_mode
            rel = p.relative_to(root).as_posix()
            if stat.S_ISDIR(mode):
                directories.append(rel)
                continue
            if stat.S_ISLNK(mode):
                rows.append({"path": rel, "type": "symlink", "link_text": os.readlink(p)})
            elif stat.S_ISREG(mode):
                bound = pin(p)
                rows.append(
                    {
                        "path": rel,
                        "type": "regular",
                        "bytes": bound["bytes"],
                        "sha256": bound["sha256"],
                        "executable": bool(mode & 0o111),
                    }
                )
            else:
                rows.append({"path": rel, "type": "special", "mode": stat.S_IFMT(mode)})
    return sorted(rows, key=lambda r: r["path"]), sorted(directories)


def git(*args):
    p = subprocess.run(
        ["git", *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=True,
        env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"},
    )
    return p.stdout.strip()


def git_check(clean):
    if (
        git("rev-parse", "HEAD") != BASE
        or git("rev-parse", "HEAD^{tree}") != TREE
        or git("branch", "--show-current") != BRANCH
    ):
        raise ValueError("Wrong local baseline commit/tree/branch")
    if clean and git("status", "--porcelain=v1", "--untracked-files=all"):
        raise ValueError("Local checkout is not clean")


def cache_check():
    expected = load(HERE / "cache-baseline.json")
    actual, _ = inventory(CACHE)
    expected_paths = {Path(x["path"]).relative_to(CACHE).as_posix() for x in expected}
    if {x["path"] for x in actual} != expected_paths:
        raise ValueError("Shared cache membership changed; separate bridge required")
    for row in expected:
        p = Path(row["path"])
        mode = p.lstat().st_mode
        if row["file_type"] == "symlink":
            if not stat.S_ISLNK(mode) or os.readlink(p) != row["link_text"]:
                raise ValueError(f"Changed literal cache link: {p}")
            resolved = p.resolve(strict=True)
            if str(resolved) != row["resolved_path"]:
                raise ValueError(f"Changed cache destination: {p}")
            verify(row, resolved)
        elif row["file_type"] == "regular":
            if str(p.resolve(strict=True)) != row["resolved_path"]:
                raise ValueError(f"Changed regular cache destination: {p}")
            verify(row, p)
        else:
            raise ValueError("Unsupported cache entry type")


def scope_check(plan):
    changes = plan["changes"]
    names = [x["destination"] for x in changes]
    if len(names) != len(set(names)):
        raise ValueError("Duplicate planned destination")
    core = {x for x in names if not x.startswith(DOSSIER + "/")}
    if core != PRIMARY:
        raise ValueError("Wrong exact primary owner scope")
    if (
        plan["baseline_commit"] != BASE
        or plan["baseline_tree"] != TREE
        or plan["target"] != str(ROOT)
        or plan["branch"] != BRANCH
        or plan["local_only"] is not True
        or plan["publication_authorized"] is not False
        or plan["shared_cache_mutation"] is not False
    ):
        raise ValueError("Wrong local-only plan contract")
    payload_paths, _ = inventory(HERE / "payload")
    if {x["path"] for x in payload_paths} != set(names):
        raise ValueError("Payload population differs from fixed plan")
    for row in changes:
        rel = relative(row["destination"])
        if row["payload"]["path"] != str(HERE / "payload" / rel):
            raise ValueError("Wrong payload owner path")
        if not isinstance(row["executable"], bool):
            raise ValueError("Invalid planned executable mode")
        if row["before"] is not None and row["before"]["path"] != row["destination"]:
            raise ValueError("Wrong before owner")
        verify(row["payload"])
    return changes


def sealed_check():
    h = load(HERE / "handoff.json")
    verify(h["manifest"], HERE / "artifact-manifest.json")
    m = load(HERE / "artifact-manifest.json")
    rows, _ = inventory(HERE)
    if any(x["type"] != "regular" for x in rows):
        raise ValueError("Special or linked preparation artifact")
    expected = {x["relative_path"] for x in m["artifacts"]}
    if len(expected) != len(m["artifacts"]):
        raise ValueError("Duplicate artifact path")
    if {x["path"] for x in rows} != expected | {
        "handoff.json",
        "artifact-manifest.json",
    }:
        raise ValueError("Sealed package membership changed")
    for x in m["artifacts"]:
        verify(x, HERE / relative(x["relative_path"]))
    return h


def expected_state(plan, adopted):
    baseline = load(HERE / "baseline-files.json")
    by = {x["path"]: x for x in baseline}
    dirs = set(load(HERE / "baseline-directories.json"))
    if adopted:
        for row in plan["changes"]:
            rel = relative(row["destination"])
            by[str(rel)] = {
                "path": str(rel),
                "type": "regular",
                "bytes": row["payload"]["bytes"],
                "sha256": row["payload"]["sha256"],
                "executable": row["executable"],
            }
            dirs.update(str(p) for p in rel.parents if str(p) != ".")
    return sorted(by.values(), key=lambda r: r["path"]), sorted(dirs)


def checkout_check(plan, adopted=False):
    git_check(clean=not adopted)
    if inventory(ROOT, exclude_git=True) != expected_state(plan, adopted):
        raise ValueError("Full local checkout file/type/mode/directory inventory changed")


def destination_check(row):
    rel = relative(row["destination"])
    dest = ROOT / rel
    for parent in dest.parents:
        if parent == ROOT:
            break
        if parent.is_symlink() or (parent.exists() and not parent.is_dir()):
            raise ValueError(f"Unsafe destination parent: {parent}")
    before = row["before"]
    if before is None:
        if os.path.lexists(dest):
            raise ValueError(f"New destination already exists: {dest}")
    else:
        verify(before, dest)
        if bool(dest.stat().st_mode & 0o111) != before["executable"]:
            raise ValueError("Changed before executable mode")
    return dest


def check_inputs():
    h = sealed_check()
    plan = load(HERE / "plan.json")
    scope_check(plan)
    checkout_check(plan)
    cache_check()
    for row in plan["accepted_inputs"]:
        verify(row)
    for row in plan["changes"]:
        destination_check(row)
    return h, plan


def approval_check(path, handoff):
    approval_pin = pin(path)
    a = load(path)
    if (
        a.get("status") != "accepted_exact_deoxy238_local_integration_for_adoption"
        or a.get("reviewer") != "Codex /root"
        or a.get("local_only") is not True
        or a.get("publication_authorized") is not False
        or a.get("shared_cache_mutation") is not False
        or a.get("history_before_first_render") is not True
        or a.get("target") != str(ROOT)
        or a.get("commit") != BASE
        or a.get("tree") != TREE
    ):
        raise ValueError("Wrong root local-only acceptance contract")
    if a.get("handoff") != pin(HERE / "handoff.json"):
        raise ValueError("Approval binds a different preparation")
    verify(a["independent_review"])
    if handoff != load(HERE / "handoff.json"):
        raise ValueError("Handoff changed during approval intake")
    return approval_pin
