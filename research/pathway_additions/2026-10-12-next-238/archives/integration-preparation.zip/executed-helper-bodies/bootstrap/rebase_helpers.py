"""Author the bounded 238 preparation from the accepted 237 flow; no maintained writes."""
import ast
import json
from pathlib import Path

H=Path(__file__).parent
OLD=Path('/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012')
target=json.loads((H/'root-target.json').read_bytes())

def rebase(s):
    for old,new in [('237','__CURRENT__'),('236','__PREVIOUS__')]:
        s=s.replace(old,new)
    return s.replace('__CURRENT__','238').replace('__PREVIOUS__','237')

def write(name,text):
    ast.parse(text)
    with (H/name).open('x') as f: f.write(text)

for name in ['run_step.py','test_controls.py','archive_controls.py']:
    write(name,rebase((OLD/name).read_text()).replace('deoxy238','deoxy238'))
s=rebase((OLD/'bootstrap.py').read_text())
s=s.replace('9bd87745d842b0602d027f3d15d26bbc178474a6','290bd9781e43e473d88b9fd7c17f6f61da45092e').replace('8f511cd6f99173bc86f5aaa9f349a35af5fddfb3','ba9aea8a75901f872e86a30505448f1113c4d6da')
s=s.replace('"aceto237": "deoxy238"','"deoxy237": "deoxy238"').replace('5-prime-deoxyadenosine-degradation-ii.yaml','5-prime-deoxyadenosine-degradation-i.yaml')
write('bootstrap.py',s)
s=rebase((OLD/'capture.py').read_text())
s=s.replace('a91f4ca1ebcd6353ed93a87ff575fa234926b4428c7a8d209976a564fd823ef5','a3c44b644e540faf713849b91126141a4fd540df113a0adf8cdae039896031b2')
s=s.replace('238-provider-successor','238-author').replace('degradation-ii.yaml','degradation-i.yaml')
s=s.replace('a367fac8ac036416baaabc9d64ae1d9927e66e87ad1bb96e2883725fd14ce68b','c8ae12061fd62a5ff8c6861b6665e3ac6938b0fe611b9e3d8d6a1e11f33199a5')
s=s.replace('c8d440d5ca596070cfb5c988af5c2baea5f9d89a623d5deda24f329cc7d4f893','5d08b898e8fb4e097694c0aee7d191aaffb7d5df478ab50bfc9c54c3858233e1')
s=s.replace('555895ed839d0fccd2b85550ecbdc962b0ea1670b8bd3d1d70389d0bf1e7aa02','85d4225fed65885628c273ec07bc93f6d32fb313dacc7b04199dc13238255cc0')
s=s.replace('inputs = [ACCEPT, H / "root-target.json"]','inputs = [ACCEPT, H / "root-target.json", Path("/private/tmp/pathwaymech-next-237-root-postcommit-acceptance-20261012.json")]')
s=s.replace('manifest869','manifest874')
write('capture.py',s)
s=rebase((OLD/'package_evidence.py').read_text())
s=s.replace('        "provider-successor",\n        "provider-independent-review",\n','')
s=s.replace('    scientific = c.load(source["scientific_reference_originals"]["path"])','    scientific_binding = c.load(source["scientific_reference_originals"]["path"])\n    scientific = scientific_binding["sources"]\n    assert len(scientific) == len(scientific_binding["complete_originals"]) == 40')
s=s.replace('    groups = {}\n    specs = [','''    native_originals = [
        {"role": "whole_pathway_XML", "whole_original": native["whole_pathway_XML"]},
        {"role": "whole_HTML", "whole_original": native["whole_HTML"]},
        *[{"role": ident, "whole_original": row["original"], "native_context": row}
          for ident, row in native["MtnP_hierarchy"].items()],
        {"role": "Q2RXH9_mapping_only", "whole_original": native["Q2RXH9_mapping_only"]["original"],
         "native_context": native["Q2RXH9_mapping_only"]},
    ]
    # Preserve complete acquisition descriptors and receipt bodies in addition to all whole originals.
    for row in scientific:
        for lineage in row["receipt_lineage"]:
            standalone.append(store.owner(lineage["receipt"]["path"], lineage["receipt"]))
    groups = {}
    specs = [''')
s=s.replace('("whole_scientific_originals", scientific, None)','("whole_scientific_originals", scientific, "original")').replace('("scientific_native_originals", native, "whole_original")','("scientific_native_originals", native_originals, "whole_original")')
s=s.replace('== 868','== 873').replace('== 96','== 40').replace('== 14','== 6').replace('== 31','== 42').replace('": 31','": 42').replace('degradation-ii.yaml','degradation-i.yaml')
write('package_evidence.py',s)
s=rebase((OLD/'finish.py').read_text())
s=s.replace('9bd87745d842b0602d027f3d15d26bbc178474a6','290bd9781e43e473d88b9fd7c17f6f61da45092e').replace('8f511cd6f99173bc86f5aaa9f349a35af5fddfb3','ba9aea8a75901f872e86a30505448f1113c4d6da').replace('"aceto237": "deoxy238"','"deoxy237": "deoxy238"')
s=s.replace('== 868','== 873').replace('== 96','== 40').replace('== 14','== 6')
s=s.replace('"configured-helper-lint-successor"','"configured-helper-lint"').replace('configured-helper-lint-successor.receipt.json','configured-helper-lint.receipt.json')
write('finish.py',s)
s=rebase((OLD/'prepare_plan.py').read_text())
s=s.replace('PWY-8131','PWY-8130').replace('degradation-ii','degradation-i')
s=s.replace('len(oldmanifest) == 855 and len(newmanifest) == 869','len(oldmanifest) == 869 and len(newmanifest) == 874').replace('newmanifest[:855]','newmanifest[:869]')
s=s.replace('"manifest_prefix_rows": 855','"manifest_prefix_rows": 869').replace('"manifest_after_rows": 869','"manifest_after_rows": 874')
a=s.index('    expected_delta = [');b=s.index('    assert aggregate',a);s=s[:a]+'    expected_delta = []\n'+s[b:]
s=s.replace('len(changes) == additions == 15','len(changes) == additions == 14').replace('(4277, 11949, 4297, 11987)','(4297, 11987, 4303, 12008)').replace('len(added) == len(newss) == 0','len(added) == len(newss) == 10')
a=s.index('        ("aggregate_display_scope")');b=s.index('        "old_authority_object_exceptions"',a);s=s[:a]+'''        "aggregate_display_scope": "No aggregate field changes. All old labels, categories, directions and contexts remain exact.",
'''+s[b:]
a=s.index('    stages = json.loads(');s=s[:a]+'''    stages = json.loads(json.dumps(c.load(OLD / "stages.json"))
        .replace("pathwaymech-next-237", "pathwaymech-next-238")
        .replace("5-prime-deoxyadenosine-degradation-ii", "5-prime-deoxyadenosine-degradation-i")
        .replace("PWY-8131", "PWY-8130"))
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="conf/identifier_sources.json",
        description="Exact accepted 874-row manifest and two actual snapshots with unchanged 270-file runtime. Preserve all old authority objects, context and first owners.",
        issue_lineage=[])

    def history(kind, slug, owner_args, event, summary, details):
        return [PY, "-B", "scripts/new_history_record.py", "--kind", kind, "--slug", slug,
                *owner_args, "--event", event, "--outcome", "changed", "--summary", summary,
                "--details", details, "--actor-name", "codex", "--agent-tool", "codex", "--model", "gpt-6"]
    stages["history_commands"] = [
        history("record", "5-prime-deoxyadenosine-degradation-i", ["--target-root", "data/pathways"], "CREATE",
            "Add the complete evidence-backed 5-prime-deoxyadenosine degradation I record.",
            "Adopted exact accepted MetaCyc:PWY-8130: 10 paragraphs, 21 edges, five endpoint qualifiers, 20 named identities, 42 references and ten source mappings. Complete three-event route, nine chemical-side occurrences, six kinetic slots, nested MtnP assembly and conflicting dimer label, shared Ald2 contexts, construct/taxon/metal evidence and source access limits retained in research/pathway_additions/2026-10-12-next-238. Actual native outputs independently reviewed. Fresh maintained gates and native saved review remain pending."),
        history("infrastructure", "deoxy238-native-authority", ["--path", "conf/identifier_sources.json"], "EDIT",
            "Integrate complete PWY-8130 authority sources and accepted native snapshots.",
            "Adopted exact 874-row manifest retaining all 869 prior entries and two actual native snapshots. Existing 270-file runtime and Rhea updates remain unchanged; whole old authority objects/order and first owners preserved. No aggregate graph label, category or direction changes; all old contexts remain exact. Local integration only; histories precede generation, and maintained gates/native review remain pending.")]
    stages["after_gates"] = [
        "Inspect the complete actual PWY-8130 page/graph, all 10 paragraphs/21 edges, five qualifiers, 20 identities, 42 references and ten mappings against exact accepted science and original limitations.",
        "Native inspect actual maintained inputs before judgments; preserve inherited complete-source review versus fresh maintained QA; validate/save/check two immutable scientific and technical reviews.",
        "Verify 238 prior records/pages, 120 review pairs and 404 old histories; preserve every old whole authority object/order, all 11987 old KGX edges and old context payloads/order/multiplicity.",
        "No aggregate node field changes permitted. Expected native first-encounter node ordering is accepted; all old context labels remain exact.",
        "Native SSSOM export must retain all 32 old rows/cells/order/header and add exactly the ten accepted target mappings, for 42 total rows.",
        "Recheck all 800 shared-cache identities and complete hidden/ignored checkout outside exact primary/dossier/history/generated/review additions; final independent actual-tree and append-only verification before local commit."]
    stages["before_first_render_after_history"][0].update(
        reason="Export the ten accepted source_mappings through the native serializer after both histories and before rendering/tests.",
        preservation="All 32 old SSSOM rows/cells/order/header exact; ten target additions and 42 total rows required.")
    interfaces = stages["native_review_interfaces"]
    interfaces.pop("accepted_provider_successor_handoff", None)
    interfaces["inherited_science_handoff"] = c.pin("/private/tmp/pathwaymech-next-238-science-review-20261012/handoff.json")
    interfaces["actual_native_review_handoff"] = c.pin("/private/tmp/pathwaymech-next-238-canonical-output-independent-review-20261012/handoff.json")
    interfaces["save_template"] = [PY, "-B", "scripts/record_review.py", "--repo-root", str(c.ROOT), "save", "--content", "<independently-reviewed-completed-review.json>"]
    interfaces["check_after_save"] = [PY, "-B", "scripts/record_review.py", "--repo-root", str(c.ROOT), "check", "--require-reviews", "--base", c.BASE]
    stages["preservation_counts"] = {k: semantic[k] for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]}
    assert stages["preservation_counts"] == {"old_records":238,"old_review_yaml":120,"old_review_markdown":120,"old_history_yaml":404}
    c.write_new(H / "stages.json", stages)
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(DOS / "local-integration-decision.json", {
        "baseline_commit": c.BASE, "tree": c.TREE, "branch": c.BRANCH,
        "baseline_kind": "Committed accepted deoxy237 local branch; not merged main",
        "primary_owners": len(c.PRIMARY), "local_only": True, "publication_authorized": False,
        "shared_cache_mutation": False,
        "scientific_target": c.pin(PAY / "data/pathways/5-prime-deoxyadenosine-degradation-i.yaml"),
        "actual_native_acceptance": c.pin("/private/tmp/pathwaymech-next-238-root-canonical-output-acceptance-20261012.json"),
        "baseline_postcommit_acceptance": c.pin("/private/tmp/pathwaymech-next-237-root-postcommit-acceptance-20261012.json"),
        "remaining": ["independent preparation review", "root exact acceptance", "local adoption",
            "two native histories before SSSOM/render", "nine maintained gates", "actual page/graph QA",
            "native saved reviews", "complete preservation and final adversarial review"],
        "source_exhaustion": False, "licensing": "Public-release licensing remains deferred; publication not authorized."})
    print(json.dumps({k:semantic[k] for k in ["old_files","old_records","old_review_yaml","old_history_yaml","old_KGX","actual_after_KGX","exact_aggregate_changes"]},indent=2))
    print("SSSOM planned additions",len(added))

if __name__ == "__main__":
    main()
'''
write('prepare_plan.py',s)
print('Prepared eight rebased helpers plus receipt runner and controls; nothing executed')
