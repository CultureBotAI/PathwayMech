"""Prepare exact lossless audit-script storage; no maintained writes."""
import datetime,gzip,hashlib,json,os
from pathlib import Path

H=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-238-finalization-preparation-20261012')
F=Path('/private/tmp/pathwaymech-next-238-finalization-evidence-lint-preflight-20261012')
A=Path('/private/tmp/pathwaymech-next-238-root-maintained-review-acceptance-20261012.json')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,value):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as s:json.dump(value,s,indent=2);s.write('\n')
def verify(b,row):assert (len(b),hashlib.sha256(b).hexdigest())==(row['bytes'],row['sha256'])
assert pin(P/'handoff.json')['sha256']=='e6bc58f19243c4a87a82f8d6e46db3cfab928b7d4d93a6e8cef01b51fcd4107f'
assert pin(A)['sha256']=='34328d4d725b30706154ffb75f9401a4bb4c972b819fc063dd9b9753f25e6e3a'
plan=json.loads((P/'copy-plan.json').read_bytes());rows=[];ledger=[]
for original in plan['files']:
 source=Path(original['source']);assert not source.is_symlink();raw=source.read_bytes();verify(raw,original)
 row=dict(original);entry={'original_repository_path':original['repository_path'],'original_source':pin(source),'original_executable':original['executable']}
 if source.suffix=='.py':
  relative=Path(original['repository_path']).relative_to(plan['durable_root'])
  payload=H/'payload'/Path(str(relative)+'.gz');payload.parent.mkdir(parents=True,exist_ok=True)
  body=gzip.compress(raw,mtime=0)
  with payload.open('xb') as stream:stream.write(body)
  assert gzip.decompress(body)==raw
  row.update(source=str(payload),repository_path=original['repository_path']+'.gz',bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),encoding='gzip',executable=False)
 else:body=raw
 entry.update(stored_repository_path=row['repository_path'],stored_source=pin(Path(row['source'])),encoding=row['encoding'])
 rows.append(row);ledger.append(entry)
assert len(rows)==301 and sum(row['encoding']=='gzip' for row in rows)==45
assert len({r['repository_path'] for r in rows})==301
refs=json.loads((P/'evidence-reference-bindings.json').read_bytes());by={r['repository_path']:r for r in rows}
for ref in refs:
 if ref.get('whole_body_identity_copy'):
  assert by[ref['reference']]['encoding']=='identity' and by[ref['reference']]['sha256']==ref['sha256']
# Reconstruct each original packet logically and check every sealed artifact and seal.
closures=[]
for prefix in ['root-review','independent-qa']:
 group={r['original_repository_path'].split('/'+prefix+'/',1)[1]:r for r in ledger if '/'+prefix+'/' in r['original_repository_path']}
 def decoded(rel):
  x=group[rel];b=Path(x['stored_source']['path']).read_bytes();verify(b,x['stored_source']);b=gzip.decompress(b) if x['encoding']=='gzip' else b;verify(b,x['original_source']);return b
 manifest=json.loads(decoded('artifact-manifest.json'));artifacts=manifest['artifacts'] if 'artifacts' in manifest else manifest['files']
 original_root=Path(group['handoff.json']['original_source']['path']).parent
 expected={'handoff.json','artifact-manifest.json'}
 for r in artifacts:
  rel=r.get('relative_path') or str(Path(r['path']).relative_to(original_root));expected.add(rel);verify(decoded(rel),r)
 assert set(group)==expected
 closures.append({'packet':prefix,'artifacts':len(artifacts),'seals':2,'whole_decoded_closure':True})
plan.update(status='proposed_exact_lossless_storage_pending_root_digest',files=rows,identity_owners=256,gzip_owners=45,original_owners=301,original_bytes=sum(r['original_source']['bytes'] for r in ledger),stored_bytes=sum(r['bytes'] for r in rows),supersedes_storage_only_of=pin(P/'copy-plan.json'))
write(H/'copy-plan.json',plan)
write(H/'storage-ledger.json',{'status':'all_whole_originals_preserved_with45_lossless_script_encodings','entries':ledger,'reconstructed_closures':closures,'direct_evidence_references_unchanged':57,'raw_originals_changed':False})
write(H/'preflight-bindings.json',{'scope':'Before any maintained copies, root authorized bounded lint of original evidence .py bodies. Full failure remains failed, followed by explicit45-owner gzip storage decision.','root_original_acceptance':pin(A),'preflight_helper':pin(Path('/private/tmp/pathwaymech-next-238-finalization-evidence-lint-preflight-20261012.py')),'preflight_files':[pin(p) for p in sorted(F.iterdir())],'ruff_exit_code':1,'diagnostics':1118,'affected_files':37,'checked_helpers':45,'no_config_or_source_change':True})
(H/'REPORT.md').write_text('''# Narrow audit-script storage successor

This packet changes storage only for the exact45 audit `.py` originals from the approved301-owner finalization plan. Each is represented as deterministic gzip at `path.py.gz`;256 other bodies, including all original seals and all57 directly referenced JSON evidence paths, remain identity copies. The storage ledger binds every original path/size/hash/mode and actual stored path/size/hash. Both whole reconstructed root39+2 and SCI258+2 packet closures pass. Every decoded script is byte-exact; no code, judgment, native input, timestamp or source content is normalized.

The actual bounded Ruff preflight returned1 with1,118 diagnostics across37 of45 proposed original audit scripts. Full stdout JSON, stderr, command/helper/environment/timing and exact source scope are bound under preflight-bindings.json. This remains a failed preflight, not a passing lint gate. Root explicitly authorized this narrow lossless representation after reading the result; final concrete digest acceptance is still required before copying.

The original sealed finalization plan and initial root acceptance remain unchanged. Execution will use this actual stored-owner copy-plan with the unchanged finalizer. Before source-input extension it must rehash all stored bodies, decode all45 scripts, verify all301 originals and reconstruct both original packet closures. Concrete evidence references remain exact. Durable execution evidence must also retain this storage ledger, both root acceptance receipts, the original plan packet and complete preflight failure. No maintained write, native save, Git mutation or publication occurred here.
''')
files=[];dirs=[]
for base,ds,fs in os.walk(H,followlinks=False):
 ds.sort();fs.sort()
 for n in ds:
  p=Path(base)/n;assert not p.is_symlink();dirs.append(p.relative_to(H).as_posix())
 for n in fs:
  p=Path(base)/n;assert p.is_file() and not p.is_symlink();files.append({**pin(p),'relative_path':p.relative_to(H).as_posix()})
write(H/'artifact-manifest.json',{'artifacts':files,'directories':dirs,'hidden_ignored_included':True})
write(H/'handoff.json',{'status':'exact45_script_storage_prepared_pending_root_digest_acceptance','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'seals':2,'copy_plan':pin(H/'copy-plan.json'),'storage_ledger':pin(H/'storage-ledger.json'),'original_identity_plan':pin(P/'handoff.json'),'original_root_acceptance':pin(A),'publication_authorized':False,'maintained_writes':False})
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'copy_plan':pin(H/'copy-plan.json'),'ledger':pin(H/'storage-ledger.json'),'stored_bytes':plan['stored_bytes'],'gzip_owners':45,'identity_owners':256}))
