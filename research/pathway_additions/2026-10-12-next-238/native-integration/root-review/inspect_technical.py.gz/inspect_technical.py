"""Capture native technical-review provenance after completed native gates."""
import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
H=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-238-local-20261012');P=Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012')
PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
targets=[]
for i,path in enumerate(['conf/identifier_sources.json','data/identifier_authorities/ontology.json','data/identifier_authorities/sources.json'],1):
 targets.append({'target_id':'owner-'+str(i),'path':path,'label':path,'kind':'maintained','ownership_note':'Exact adopted source manifest or native authority snapshot. Future corrections belong to the manifest/source adapter or authority builder; generated snapshots must be rebuilt, not hand-patched.'})
(H/'technical-targets.json').write_text(json.dumps({'targets':targets},indent=2)+'\n')
inputs=[r['destination'] for r in json.loads((P/'plan.json').read_bytes())['changes'] if r['destination'] not in [t['path'] for t in targets]]
inputs+=['docs/record-reviews.md','docs/record-review-profile.md','schema/record_review.yaml','.claude/skills/review-yaml-record/SKILL.md','src/pathwaymech/schema.py','src/pathwaymech/identifiers.py','scripts/build_source_identifier_snapshot.py','scripts/build_ontology_identifier_snapshot.py','conf/identifier_policy.yaml','conf/rhea_identifier_updates.json','pages/records/MetaCyc_PWY-8130.html','output/sssom/source_mappings.sssom.tsv','output/kgx/nodes.tsv','output/kgx/edges.tsv']
inputs=list(dict.fromkeys(inputs));assert all((R/p).is_file() for p in inputs)
cmd=[PY,'-B','scripts/record_review.py','--repo-root',str(R),'inspect','--targets',str(H/'technical-targets.json')]
for path in inputs:cmd+=['--input',path]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'};start=datetime.datetime.now(datetime.UTC).isoformat();tick=time.monotonic()
with (H/'technical-inspect.stdout').open('xb') as out,(H/'technical-inspect.stderr').open('xb') as err:r=subprocess.run(cmd,cwd=R,env={**os.environ,**env},stdout=out,stderr=err)
receipt={'command':cmd,'cwd':str(R),'environment':env,'started_at':start,'finished_at':datetime.datetime.now(datetime.UTC).isoformat(),'seconds':time.monotonic()-tick,'exit_code':r.returncode,'helper':pin(Path(__file__)),'targets':pin(H/'technical-targets.json'),'stdout':pin(H/'technical-inspect.stdout'),'stderr':pin(H/'technical-inspect.stderr')}
(H/'technical-inspect.execution.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));raise SystemExit(r.returncode)
