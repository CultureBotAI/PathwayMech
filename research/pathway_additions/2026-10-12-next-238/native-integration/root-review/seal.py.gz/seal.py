import datetime,hashlib,json,os,stat
from pathlib import Path
H=Path(__file__).parent;N=Path('/private/tmp/pathwaymech-next-238-local-native-execution-20261012')
def pin(p):
 assert p.is_file() and not p.is_symlink(),p
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'file_type':'regular','link_text':None,'resolved_path':str(p.resolve())}
def write(name,v):
 with (H/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def walk(p):
 files=[];dirs=[]
 for base,children,names in os.walk(p,followlinks=False):
  dirs.append(str(Path(base).relative_to(p)))
  assert not any((Path(base)/c).is_symlink() for c in children)
  for name in names:
   f=Path(base)/name;assert stat.S_ISREG(f.lstat().st_mode);files.append(f)
 return sorted(files),sorted(dirs)
native=json.loads((N/'artifact-manifest.json').read_bytes());files,dirs=walk(N)
assert pin(N/'handoff.json')['sha256']=='8fb12b32116623085696f23943a74599bb0d50f269a91edc0a19d394cad7c2d8'
assert pin(N/'artifact-manifest.json')['sha256']=='15e471d4288233064e849d422ae05e1195eef35e524a8a38b37260ca7a283da2'
assert set(files)=={Path(r['path']) for r in native['files']}|{N/'handoff.json',N/'artifact-manifest.json'}
assert set(dirs)==set(native['directories'])|{'.'}
for row in native['files']:
 a=pin(Path(row['path']));assert a['sha256']==row['sha256'] and a['bytes']==row['bytes']
write('native-execution-intake.json',{'at':datetime.datetime.now(datetime.UTC).isoformat(),'handoff':pin(N/'handoff.json'),'manifest':pin(N/'artifact-manifest.json'),'whole_fresh_closure':True,'artifacts':len(native['files']),'directories':len(dirs),'hidden_ignored_included':True})
assert json.loads((H/'technical-validate.execution.json').read_bytes())['exit_code']==0
assert json.loads((H/'after-gates/target.execution.json').read_bytes())['exit_code']==0
assert json.loads((H/'after-gates/checkout.execution.json').read_bytes())['exit_code']==0
write('actual-root-tools.json',{'target_initial':'6f5830/session5711→44b07b/1; before KGX completed','target_after_gates':'067387/session15333→63f99a/0','checkout_after_gates':'fc5207/session47669→9523df/0','visual_binding':'6209d6/0; root personally viewed graph image in this turn','technical_inspect':'690163/session16835→ec5487/0','technical_proposal':'87b909/0','technical_validate':'8c92b1/session54529→239e36/0; one topClass deprecation diagnostic','root_record_or_product_edits':False,'native_review_saved':False})
(H/'REPORT.md').write_text('''Root maintained QA passed after all actual238 native gates. The complete record equals the accepted scientific draft. Every paragraph, identity, graph edge, qualifier, evidence item, reference and local anchor was checked against the current HTML. The native SVG and both graph assets match the personally viewed light preview. Its dense junctions, truncated long qualifier labels, small whole-image text and tall layout remain explicit limitations; no browser interaction, responsive, print or dark-mode verification is claimed.

Whole current authorities and both CLI/download KGX files equal the accepted actual native outputs. Current graph totals are4303nodes/12008edges. All32old SSSOM rows, cells, header, multiplicity and relative order are preserved, adding exactly10accepted target rows. All238old records/pages,120review pairs and404histories remain byte-exact; two histories were created before generation. Complete physical inventory including hidden/ignored files checks12507baseline files to12520current,2007to2011directories,13exact adopted owners and only the accepted generated/history changes. All800cache identities and bodies remain unchanged.

The first root target check ran before the native KGX command finished and correctly rejected old CLI nodes. Its helper, failed result and actual streams remain untouched. The exact same helper passed after gates; a separate after-gates directory retains that execution. This was a review timing error, not a product defect. An earlier preparation mapping-row ordering assumption and its correction remain inherited in the pinned root preparation audit, rather than rewritten as a clean first run.

The complete76+2 native execution packet was freshly closed here. All12actual commands and nine gates passed first attempt, including4273tests/3skips/3existing dependency warnings, lint, KGX, vendored, diff and current-page checks. These actual execution receipts are inherited from the integration agent and freshly verified, not rerun by this reviewer. Scientific interpretation remains separately owned by the maintained scientific reviewer.

Root captured a fresh native technical inspection of three primary owners and24context inputs after gates, then rechecked all27hashes and all three actual native owner bodies. The completed technical proposal contains8positive assessments,15checks, no findings and a qualified pass with scientific_review:false. Native validate passed with the shared topClass deprecation message. Durable evidence paths are concretely planned; native saving still requires exact-byte guarded evidence adoption and current input recheck. This external proposal has not been saved or committed. No public action occurred.
''')
files,dirs=walk(H);rows=[pin(p) for p in files]
write('artifact-manifest.json',{'artifacts':rows,'directories':dirs,'hidden_ignored_included':True})
write('handoff.json',{'status':'root_maintained_qa_and_native_technical_proposal_passed_pending_guarded_adoption_and_save','at':datetime.datetime.now(datetime.UTC).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(rows),'report':pin(H/'REPORT.md'),'technical_proposal':pin(H/'technical-proposal.json'),'technical_native_validation':pin(H/'technical-validate.execution.json'),'scientific_review':False,'native_review_saved':False,'publication_authorized':False})
files2,dirs2=walk(H);assert set(files2)==set(files)|{H/'artifact-manifest.json',H/'handoff.json'} and dirs2==dirs
for row in rows:assert pin(Path(row['path']))==row
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(rows),'directories':len(dirs)}))
