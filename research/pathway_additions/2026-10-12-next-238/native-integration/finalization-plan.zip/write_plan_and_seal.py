"""Describe the exact finalization scope and seal this external preparation."""
import datetime
import hashlib
import json
import os
from pathlib import Path

H = Path(__file__).resolve().parent
ROOT = '/private/tmp/pathwaymech-next-238-local-20261012'
BASE = '5d3198b18a4a0f82175a65df48dd8a63664cd32d'
PY = '/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
DURABLE = 'research/pathway_additions/2026-10-12-next-238/native-integration'
EXEC = '/private/tmp/pathwaymech-next-238-finalization-execution-inputs-20261012'
FINAL = '/private/tmp/pathwaymech-next-238-root-native-finalized-20261012'

def write(name, value):
    with (H / name).open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')

def pin(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

copy = json.loads((H / 'copy-plan.json').read_bytes())
drafts = json.loads((H / 'native-draft-bindings.json').read_bytes())
plan = {
    'status': 'prepared_only_pending_root_exact_acceptance',
    'target': ROOT, 'base_commit': BASE,
    'branch': 'feat/pathway-next-238-local-20261012',
    'scope': 'Whole QA evidence adoption, current native input extension, two native review saves, append-only and bounded verification; stop before staging or commit.',
    'copy_plan': pin(H / 'copy-plan.json'),
    'copies': len(copy['files']), 'copy_bytes': sum(r['bytes'] for r in copy['files']),
    'drafts': drafts,
    'pending_execution_binding': {
        'root_acceptance': '/private/tmp/pathwaymech-next-238-root-maintained-review-acceptance-20261012.json',
        'root_acceptance_sha256': None,
        'rule': 'Root must read and accept the exact scientific/technical contents and this handoff. Bind its actual acceptance digest in a separate immutable execution receipt. A null field or elapsed time never authorizes action; never rewrite this sealed plan.'
    },
    'steps': [
        {'step': 1, 'name': 'bind_root_acceptance_and_current_preconditions', 'write_scope': 'new external execution binding only', 'checks': [
            'Fresh complete literal/hidden/ignored closure of this plan, SCI258+2, rootQA39+2, and original native76+2 against root acceptance.',
            'Require exact base/branch and empty index. Recheck all original native input descriptors/hashes, target bytes, 270 effective runtime owners, and the complete old-owner/cache guard before first maintained write.',
            'Require both exact review IDs absent under ignored-inclusive review inventory; preserve all 120 old immutable pairs and all 406 current history YAMLs.',
            'Root acceptance must preserve disclosed prior authorship and independence limits. This plan author makes no new scientific judgments.'
        ]},
        {'step': 2, 'name': 'adopt_whole_exact_packets', 'write_scope': DURABLE + '/root-review and /independent-qa plus approval/adoption receipts', 'checks': [
            'Preload and rehash all 301 copy-plan sources, reject symlink/special parents, unsafe paths, duplicate destinations and any existing destination before writing.',
            'Copy every original packet file, including all original seals and failed helpers/streams, byte for byte at its exact repository_path. Preserve executable modes and all directories; no compression, normalized text, rewritten receipts or paths.',
            'The complete76+2 native packet is already inside SCI actual-native. Compare it to the original, then copy it once at independent-qa/actual-native.',
            'Retain the exact new root acceptance at native-integration/maintained-review-acceptance.json. In a new external execution copy-plan, append that one identity owner and an explicit adoption ledger if one is stored before final inspect; bind every added body and keep the sealed301-row plan unchanged.',
            'Create an external combined draft directory: byte-exact scientific-review.yaml and technical-review.yaml from this packet; technical JSON is valid YAML and is not rewritten. Its copy-plan contains the exact adopted evidence owners.',
            'Re-read and compare every complete copied body to its sealed original; audit all57 durable evidence references against exact snapshot hashes and the current-record reference against the reviewed YAML. This reassesses copy fidelity, not the underlying literature.',
            'Verify complete physical change scope is exactly the enumerated new evidence owners. All preexisting owners, caches and native input hashes remain exact.'
        ]},
        {'step': 3, 'name': 'extend_native_inputs_through_shared_inspection', 'write_scope': 'new external finalized drafts and actual receipts only', 'checks': [
            'Use the unchanged 237 finalize_native_inputs.py with the exact combined draft directory and adopted copy-plan.',
            'Its native inspect includes every original input and all adopted evidence. Every original input descriptor, including role and SHA256, must remain exact per review; no original source rebinding is permitted.',
            'Require original Git revision/state and targets unchanged. Only source.inputs may extend; reviewer identity, actual start/finish, all97 SCI and8 TECH assessments, all checks, evidence, findings, limitations and historical notes remain byte-equivalent in parsed content.',
            'Validate each finalized document through scripts/record_review.py. Preserve actual helper-at-start, command/cwd/environment, times, exit, stdout/stderr and all failures. No native save occurs in this step.'
        ]},
        {'step': 4, 'name': 'save_two_native_pairs_and_check_append_only_history', 'write_scope': 'exactly two new native YAML/Markdown pairs', 'checks': [
            'Immediately recheck root acceptance, exact finalized-content pins, all original and extended input hashes, base and unchanged judgments.',
            'Use shared scripts/record_review.py save --content for scientific then technical, never manually write review pairs or overwrite old bundles.',
            'Run shared check --require-reviews --base ' + BASE + '; expect120 old pairs plus2 new=122 and preserve whole old pairs.',
            'Run bounded required lint and unstaged git diff --check with retained actual receipts. No broad test, builder, render or history rerun is justified by evidence-only adoption.',
            'Whole-copy native finalization/save/check receipts via an explicit new storage map, then verify exact new-owner scope and complete old owner/cache preservation. Post-save execution receipts are later provenance; do not silently extend already saved review inputs.',
            'If copying original .py audit helpers introduces lint diagnostics, retain the full result and distinguish research artifacts from maintained runtime. Do not rewrite original sources or silently exempt paths; report to root for a bounded storage/scope decision.'
        ]},
        {'step': 5, 'name': 'stop_and_report_actual_result', 'write_scope': 'external completion report/seals', 'checks': [
            'Report actual saved IDs, input counts, unchanged judgments, concrete evidence owner count/bytes and append-only/lint/diff outcomes.',
            'Bind the complete current changed-file inventory for the subsequent local commit task, without staging or committing under this plan.',
            'Any full whitespace failure stays a failure. Future staged checks require exact source-byte exceptions and independent root appraisal; no normalization, broad extension exclusions or whitespace configuration changes.',
            'No network publication, PR, merge, branch deletion, GitHub issue action, or data-license clearance is included.'
        ]}
    ],
    'preserved_current_state': {'records':239, 'history_yaml':406, 'old_review_pairs':120, 'expected_after_save_review_pairs':122, 'source_terms':2638, 'source_owners':697, 'ontology_terms':2012, 'ontology_owners':5, 'effective_manifest_rows':874, 'baseline_manifest_prefix':869, 'source_originals':873, 'effective_runtime_owners':270, 'runtime_code_changes':0, 'only_runtime_map_baseline_change':'Approved conf/identifier_sources.json bridge to exact canonical manifest; Rhea configuration is unchanged.', 'KGX_nodes':4303, 'KGX_edges':12008, 'old_aggregate_deltas':0, 'new_shared_contexts':14, 'target_display_nodes':23, 'target_edges':21, 'target_qualifiers':5, 'target_references':42, 'SSSOM_rows':42, 'old_SSSOM_rows':32, 'new_SSSOM_rows':10, 'cache_entries':800},
    'execution_performed':False, 'staging_or_commit_authorized_by_plan':False, 'publication_authorized':False
}
write('plan.json', plan)
commands = {
    'status':'templates_only_not_executed', 'cwd':ROOT,
    'environment':{'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':ROOT+'/src:'+ROOT},
    'adoption':'Use a root-reviewed, exact-acceptance-bound adaptation of 237 adopt-evidence. It consumes copy-plan.json directly rather than compression heuristics; preverify all bodies before the first write. Exact helper and executed command must be retained before adoption.',
    'input_finalization':[PY,'-B',str(H/'finalize_native_inputs.py'),'--root',ROOT,'--draft-directory',EXEC,'--output',FINAL],
    'scientific_save':[PY,'-B','scripts/record_review.py','save','--content',FINAL+'/scientific-review.yaml'],
    'technical_save':[PY,'-B','scripts/record_review.py','save','--content',FINAL+'/technical-review.yaml'],
    'append_only_check':[PY,'-B','scripts/record_review.py','check','--require-reviews','--base',BASE],
    'lint':[PY,'-B','-m','ruff','check','--no-cache','.'],
    'diff_check':['git','diff','--check'],
    'receipt_contract':'Use retained positional run-local-step wrapper with a new absolute external output directory followed by complete command argv. It has no --help interface.',
    'no_direct_execution_from_this_file':True
}
write('command-templates.json', commands)
write('read-coverage.json', {
    'fresh_whole_reads':['Current CLAUDE.md; docs/record-reviews.md; docs/record-review-profile.md','Root QA full REPORT, TECH proposal including all8 assessments/15 checks and source metadata, complete checkout guard','SCI full REPORT, durable-adoption instructions, proposal identity/scope/limits/notes; all current source descriptors and complete proposed bytes parsed and hashed','Prior237 complete plan/REPORT, adopt-evidence, unchanged finalizer, save-native-reviews and adopt-finalization helpers'],
    'programmatic_complete_checks':['Every literal file/hash/directory in root39+2, SCI258+2 and native76+2; whole SCI actual-native equality','Every proposed identity-copy source and all57 future durable evidence references; current39 unique native input hashes, with per-review roles preserved','Complete current physical checkout and cache through unchanged root guard; all270 effective runtime owner hashes; exact Git base/branch/empty index'],
    'inherited_not_new':['Scientific97 judgments and material primary reading belong to nitrate reviewer; no fresh paper interpretation by this planning agent','Root whole target DOM/authority/KGX semantics, visual assessment and actual nine native gates; no redundant gate rerun'],
    'display_limits':['A multi-read output exceeded the display budget. SCI identity/scope/limitations/notes were reread in a bounded complete call; whole final-proposal binding and evidence tables are programmatically checked, not claimed as complete manual prose reading.'],
    'absence_search':'Current workspace and238 target AGENTS/CLAUDE search used rg --files --hidden --no-ignore with Git and virtualenv excluded explicitly; literal worktree/cache census includes hidden and ignored files, excluding Git administration only.'
})
(H/'REPORT.md').write_text('''# Record 238 finalization preparation

The exact final evidence-adoption and native-review-save plan is ready for root review. It has not been executed. The copy list contains 301 whole identity owners (3,438,456 bytes): all39+2 root QA files at `native-integration/root-review` and all258+2 independent SCI files at `native-integration/independent-qa`. The latter contains the original76+2 native execution packet, freshly compared byte for byte. All original failed checks, proposal validation attempts, original timestamps, nested seals and streams remain intact.

The scientific proposal is retained as its exact88,627-byte original with97 assessments; root’s technical JSON is copied byte for byte under a `.yaml` name (JSON is valid YAML), retaining its8 assessments. Neither review is rewritten. All57 future durable evidence references match the exact proposed source hashes; the remaining evidence reference is the current target YAML, itself among the checked original inputs. The39 distinct current native input bodies are exact across the two proposals; role differences remain review-specific.

Fresh bounded checks passed: all three literal packet closures, complete current checkout preservation (12,520 files/2,011 directories), all800 cache entries, exact HEAD/branch and empty index, and all270 effective runtime owners. The runtime map has one approved baseline delta: the exact874-row manifest bridge; there are no code changes. The complete checkout guard is byte-identical to root’s passed after-gates helper. Its fresh actual run took9.763 seconds. The assembly/check execution passed in1.344 seconds. No broad suite, native builder, render or history command was rerun.

The unchanged237 finalizer will run only after approval and whole evidence adoption. A distinct external execution draft directory will combine the exact original proposals with the adopted-owner copy plan and exact acceptance receipt. Fresh shared inspection must preserve every original descriptor and original Git source state, adding only explicitly verified evidence inputs. Every judgment, reviewer identity, timestamp, assessment, finding and limitation stays unchanged. Native save then creates exactly two new immutable pairs; append-only checking uses base237 `5d3198b18a4a0f82175a65df48dd8a63664cd32d`. This bounded plan stops before staging or commit.

Root must bind its actual approval in a separate immutable execution receipt; the pending path is not authorization. Adoption/save helpers must retain actual creation-time helper/argv/environment/timing/stream provenance. The copy plan uses identity storage to preserve concrete referenced paths and hashes. Original audit `.py` files may enter repository lint scope; any actual failure must be retained and returned to root for a bounded decision rather than rewriting source originals. Full and scoped whitespace outcomes must remain distinct in any later commit task.

Three planning diagnostics are retained: a display helper assumed the wrong native manifest key; another display attempted `len()` on a numeric count; and probing the positional wrapper with `--help` created one empty `--help` directory in the original workspace, then failed before invoking a subprocess or writing a file. The empty directory was removed with `rmdir`; the238 maintained worktree was unaffected. These are described from actual tool transcripts, not falsely presented as preexisting captured streams. The proper positional wrapper was subsequently read and used successfully with complete external receipts.

Scientific judgments and their primary-reading/access limits belong to the independent reviewers, not this planning task. No new primary-paper review is claimed. All source access, native assembly, database-attribution, static-only visualization and licensing limitations remain unchanged. No maintained file content, cache, Git index/history or sealed input packet was changed by this preparation. There was no review save, publication, PR, merge, branch deletion or issue action.
''')
files=[]; dirs=[]
for base, names, names_files in os.walk(H, followlinks=False):
    names.sort(); names_files.sort()
    for n in names:
        p=Path(base)/n; assert not p.is_symlink(); dirs.append(p.relative_to(H).as_posix())
    for n in names_files:
        p=Path(base)/n; assert p.is_file() and not p.is_symlink()
        assert n not in ('handoff.json','artifact-manifest.json')
        files.append({**pin(p),'relative_path':p.relative_to(H).as_posix()})
write('artifact-manifest.json', {'artifacts':files,'directories':sorted(dirs),'hidden_ignored_included':True,'excluded_seals':['handoff.json','artifact-manifest.json']})
write('handoff.json', {'status':'prepared_exact238_finalization_pending_root_acceptance','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'seals':2,'plan':pin(H/'plan.json'),'copy_plan':pin(H/'copy-plan.json'),'scientific_review':pin(H/'scientific-review.yaml'),'technical_review':pin(H/'technical-review.yaml'),'native_save_performed':False,'publication_authorized':False})
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'seals':2,'copy_owners':301,'copy_bytes':3438456}))
