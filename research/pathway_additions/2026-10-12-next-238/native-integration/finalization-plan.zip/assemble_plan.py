"""Prepare a sealed, read-only finalization plan; never adopt or save reviews."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import yaml

HERE = Path(__file__).resolve().parent
PREP = Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012')
sys.path.insert(0, str(PREP))
import common as c

ROOT_QA = Path('/private/tmp/pathwaymech-next-238-root-maintained-qa-20261012')
SCI_QA = Path('/private/tmp/pathwaymech-next-238-maintained-science-review-20261012')
NATIVE = Path('/private/tmp/pathwaymech-next-238-local-native-execution-20261012')
DURABLE = c.DOSSIER + '/native-integration'
PYTHON = '/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'

def write(name, value):
    c.write_new(HERE / name, value)

def close(root, handoff_sha, manifest_sha):
    h = c.pin(root / 'handoff.json')
    m = c.pin(root / 'artifact-manifest.json')
    assert h['sha256'] == handoff_sha and m['sha256'] == manifest_sha
    data = c.load(root / 'artifact-manifest.json')
    rows = data['artifacts'] if 'artifacts' in data else data['files']
    seen = {}
    for row in rows:
        rel = row.get('relative_path') or str(Path(row['path']).relative_to(root))
        c.relative(rel)
        assert rel not in seen
        c.verify(row, root / rel)
        seen[rel] = row
    actual, directories = c.inventory(root)
    assert all(row['type'] == 'regular' for row in actual)
    assert {row['path'] for row in actual} == set(seen) | {'handoff.json', 'artifact-manifest.json'}
    if 'directories' in data:
        assert set(directories) == set(data['directories']) - {'.'}
    return {'root': str(root), 'handoff': h, 'manifest': m, 'artifacts': len(rows), 'seals': 2, 'directories': len(directories), 'literal_full_closure_passed': True}, actual

parser = argparse.ArgumentParser()
parser.add_argument('--scientific-handoff-sha256', required=True)
parser.add_argument('--scientific-manifest-sha256', required=True)
a = parser.parse_args()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
root_closure, root_files = close(ROOT_QA, '83661b4c0b6deca94b171a824f3f723a2a666f8609e44550edd6c108015e4c89', '3ed2a617d045b559e7722b16f532d18e2323df1e28548638c9f1a07cfd20af2e')
sci_closure, sci_files = close(SCI_QA, a.scientific_handoff_sha256, a.scientific_manifest_sha256)
native_closure, native_files = close(NATIVE, '8fb12b32116623085696f23943a74599bb0d50f269a91edc0a19d394cad7c2d8', '15e471d4288233064e849d422ae05e1195eef35e524a8a38b37260ca7a283da2')
for row in native_files:
    assert c.regular_bytes(NATIVE / row['path']) == c.regular_bytes(SCI_QA / 'actual-native' / row['path'])

copies = []
for name, packet, files in [('root-review', ROOT_QA, root_files), ('independent-qa', SCI_QA, sci_files)]:
    for row in files:
        dest = DURABLE + '/' + name + '/' + row['path']
        target = c.ROOT / dest
        assert not target.exists() and not target.is_symlink(), target
        for parent in target.parents:
            if parent == c.ROOT:
                break
            assert not parent.is_symlink()
        copies.append({'source': str(packet / row['path']), 'repository_path': dest, 'bytes': row['bytes'], 'sha256': row['sha256'], 'encoding': 'identity', 'executable': row['executable']})
assert len({row['repository_path'] for row in copies}) == len(copies)
copy_plan = {'status': 'proposed_only_no_writes', 'durable_root': DURABLE, 'files': copies, 'all_whole_packet_files_and_seals': True, 'source_normalization': False, 'approval_receipt_extension': 'After root approval, append exactly the root acceptance body as native-integration/maintained-review-acceptance.json in a distinct execution copy-plan. Preserve this sealed static plan unchanged.'}
write('copy-plan.json', copy_plan)

originals = {'scientific': SCI_QA / 'completed-review-ready.yaml', 'technical': ROOT_QA / 'technical-proposal.json'}
drafts = {}
input_rows = {}
evidence_bindings = []
copy_by_path = {row['repository_path']: row for row in copies}
for kind, path in originals.items():
    raw = c.regular_bytes(path)
    doc = yaml.safe_load(raw)
    assert doc['source']['git_revision'] == c.BASE
    assert doc['source']['state'] == 'working_tree'
    assert doc['completion'] == 'completed'
    assert doc['verdict'] in ('pass', 'pass_with_limitations')
    assert doc['findings'] == []
    assert doc['scientific_review'] == (kind == 'scientific')
    for row in doc['source']['inputs']:
        b = c.regular_bytes(c.ROOT / row['path'])
        assert hashlib.sha256(b).hexdigest() == row['sha256'], row['path']
        if row['path'] in input_rows:
            assert input_rows[row['path']]['sha256'] == row['sha256']
        else:
            input_rows[row['path']] = {'path': row['path'], 'sha256': row['sha256'], 'review_roles': {}}
        input_rows[row['path']]['review_roles'][kind] = row.get('role')
    for item in doc['evidence']:
        ref = item.get('reference', '')
        if ref in copy_by_path:
            bound = copy_by_path[ref]
            assert item.get('snapshot_sha256') == bound['sha256'], (kind, item['evidence_id'])
            evidence_bindings.append({'review': kind, 'evidence_id': item['evidence_id'], 'reference': ref, 'sha256': bound['sha256'], 'whole_body_identity_copy': True})
        else:
            evidence_bindings.append({'review': kind, 'evidence_id': item['evidence_id'], 'reference': ref, 'external_or_preexisting_reference': True})
    out = HERE / (kind + '-review.yaml')
    with out.open('xb') as stream:
        stream.write(raw)
    assert yaml.safe_load(out.read_bytes()) == doc
    assert not (c.ROOT / 'reviews/structured' / doc['review_id']).exists()
    drafts[kind] = {'original': c.pin(path), 'exact_copy': c.pin(out), 'review_id': doc['review_id'], 'started_at': doc['started_at'], 'finished_at': doc['finished_at'], 'reviewer': doc['reviewer'], 'source_inputs': len(doc['source']['inputs']), 'assessments': len(doc['assessments']), 'checks': len(doc['checks']), 'evidence': len(doc['evidence']), 'target_ids': [r['target_id'] for r in doc['targets']], 'all_bytes_and_parsed_content_identical': True, 'science_reassessment_by_plan_author': False}

c.git_check(clean=False)
assert not c.git('diff', '--cached', '--name-only')
status = c.git('status', '--porcelain=v1', '--untracked-files=all')
(HERE / 'readonly-git-status.txt').write_text(status + '\n')
runtime = c.load(PREP / 'runtime-owner-map.json')
for row in runtime['runtime']:
    c.verify(row['effective_integration'], c.ROOT / row['relative_path'])
assert len(runtime['runtime']) == 270
assert [row['relative_path'] for row in runtime['runtime'] if row['changed']] == ['conf/identifier_sources.json']
assert c.load(HERE / 'checkout-preservation.json')['status'] == 'complete_checkout_preservation_after_native_gates_passed'

write('evidence-reference-bindings.json', evidence_bindings)
write('native-draft-bindings.json', drafts)
write('current-native-inputs.json', {'base': c.BASE, 'inputs': sorted(input_rows.values(), key=lambda r: r['path']), 'all_current_hashes_exact': True, 'no_input_rebound': True})
write('input-bindings.json', {'root_qa': root_closure, 'scientific_qa': sci_closure, 'actual_native': native_closure, 'native_in_scientific_packet_whole_byte_identity': True, 'unchanged_finalizer': c.pin(HERE / 'finalize_native_inputs.py'), 'predecessor_finalizer': c.pin('/private/tmp/pathwaymech-next-237-maintained-independent-qa-20261012/finalize_native_inputs.py'), 'checkout_guard': c.pin(HERE / 'check_checkout.py'), 'root_guard': c.pin(ROOT_QA / 'after-gates/check_checkout.py'), 'integration_preparation_handoff': c.pin(PREP / 'handoff.json'), 'runtime_owner_map': c.pin(PREP / 'runtime-owner-map.json'), 'review_contract': c.pin(c.ROOT / 'docs/record-reviews.md'), 'profile': c.pin(c.ROOT / 'docs/record-review-profile.md')})
assert c.regular_bytes(HERE / 'finalize_native_inputs.py') == c.regular_bytes('/private/tmp/pathwaymech-next-237-maintained-independent-qa-20261012/finalize_native_inputs.py')
assert c.regular_bytes(HERE / 'check_checkout.py') == c.regular_bytes(ROOT_QA / 'after-gates/check_checkout.py')
write('preparation-checks.json', {'status': 'bounded_read_only_plan_checks_passed', 'started_at': start, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'packets_closed': [root_closure['artifacts'], sci_closure['artifacts'], native_closure['artifacts']], 'copy_owners': len(copies), 'copy_bytes': sum(row['bytes'] for row in copies), 'current_original_native_inputs': len(input_rows), 'runtime_files_exact': 270, 'head': c.BASE, 'branch': c.BRANCH, 'index_empty': True, 'all_new_destinations_absent': True, 'source_packets_unmodified': True, 'current_checkout': c.pin(HERE / 'checkout-preservation.json'), 'native_saves': 0, 'maintained_file_writes': 0, 'whole_paper_reading': 'None in this finalization planning task; scientific judgments remain the independent reviewers\' original observations.'})
print(json.dumps({'copies': len(copies), 'bytes': sum(row['bytes'] for row in copies), 'native_original_inputs': len(input_rows), 'drafts': {k: {'id': v['review_id'], 'assessments': v['assessments']} for k, v in drafts.items()}}))
