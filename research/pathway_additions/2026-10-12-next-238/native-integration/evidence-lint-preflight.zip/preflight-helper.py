import collections,datetime,hashlib,json,os,subprocess,time
from pathlib import Path
H=Path('/private/tmp/pathwaymech-next-238-finalization-evidence-lint-preflight-20261012');H.mkdir()
P=Path('/private/tmp/pathwaymech-next-238-finalization-preparation-20261012');R=Path('/private/tmp/pathwaymech-next-238-local-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
a=Path('/private/tmp/pathwaymech-next-238-root-maintained-review-acceptance-20261012.json');assert pin(a)['sha256']=='34328d4d725b30706154ffb75f9401a4bb4c972b819fc063dd9b9753f25e6e3a'
rows=[x for x in json.loads((P/'copy-plan.json').read_bytes())['files'] if x['repository_path'].endswith('.py')]
for x in rows:assert pin(Path(x['source']))['sha256']==x['sha256']
argv=['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B','-m','ruff','check','--no-cache','--config',str(R/'pyproject.toml'),'--output-format','json',*[x['source'] for x in rows]]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'}
v={'argv':argv,'cwd':str(R),'environment':env,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':pin(Path(__file__))};start=time.monotonic()
with (H/'stdout.json').open('xb') as out,(H/'stderr').open('xb') as err:q=subprocess.run(argv,cwd=R,env={**os.environ,**env},stdout=out,stderr=err)
v.update(exit_code=q.returncode,seconds=time.monotonic()-start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout=pin(H/'stdout.json'),stderr=pin(H/'stderr'))
(H/'execution.json').write_text(json.dumps(v,indent=2)+'\n')
diagnostics=json.loads((H/'stdout.json').read_bytes());source_to_dest={x['source']:x['repository_path'] for x in rows}
summary={'status':'passed' if q.returncode==0 else 'failed_original_audit_helper_lint','copied_helper_files':len(rows),'diagnostics':len(diagnostics),'affected_files':len({x['filename'] for x in diagnostics}),'rules':dict(collections.Counter(x['code'] for x in diagnostics)),'file_counts':[{'source':f,'destination':source_to_dest[f],'diagnostics':n} for f,n in sorted(collections.Counter(x['filename'] for x in diagnostics).items())],'maintained_writes':False,'source_bytes_changed':False,'config_changed':False,'scope':'Exact proposed original audit .py evidence only, using current repository Ruff configuration; no broad gate rerun.'}
(H/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(H/'copy-helper-scope.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['file_counts']}));print(json.dumps({'execution':pin(H/'execution.json'),'summary':pin(H/'summary.json')}))
