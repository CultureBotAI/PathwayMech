"""Correct only rejected YAML alias serialization; preserve the original proposal."""
import hashlib,json
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
original=H/'completed-review.yaml';before=pin(original)
assert before['sha256']=='2e991f4a37f8ed45907ea6a4cb76cd03cf55a68da8953fbbd71993cd4e018830'
obj=yaml.safe_load(original.read_text())
class NoAliasDumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
target=H/'completed-review-aliasfree.yaml'
with target.open('x') as f:f.write(yaml.dump(obj,Dumper=NoAliasDumper,allow_unicode=True,sort_keys=False,width=100))
assert yaml.safe_load(target.read_text())==obj
assert not any(isinstance(t,(yaml.tokens.AliasToken,yaml.tokens.AnchorToken,yaml.tokens.TagToken)) for t in yaml.scan(target.read_text()))
assert pin(original)==before
(H/'alias-serialization-correction.json').write_text(json.dumps({'status':'serialization_only_successor','original':before,'successor':pin(target),'original_failure':pin(H/'native-validate-execution.json'),'reason':'Native validator forbids aliases. PyYAML safe_dump reused repeated target-ID list objects. NoAliasDumper serializes the identical whole logical review without aliases/anchors/tags.','whole_loaded_objects_equal':True,'all_judgments_timestamps_source_captures_and_evidence_unchanged':True,'original_preserved':True},indent=2)+'\n')
print('PASS: alias-free serialization; complete parsed proposal unchanged')
