"""Make the already completed prior-review search scope explicit in native metadata."""
import hashlib,json
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
original=H/'completed-review-final.yaml';before=pin(original);obj=yaml.safe_load(original.read_text())
items=[e for e in obj['evidence'] if e['kind']=='search'];assert len(items)==1 and items[0]['evidence_id']=='prior-search'
items[0]['search_scope']='All 120 native reviews/structured/**/*.yaml bodies in /private/tmp/pathwaymech-next-238-local-20261012, inventoried with ignored and hidden files included; exact target_id MetaCyc:PWY-8130 or target path data/pathways/5-prime-deoxyadenosine-degradation-i.yaml. Text-only references to PWY-8130 in other target reviews are not predecessor occurrences. External author/science/preflight packets are separately bound prior context.'
class NoAliasDumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
target=H/'completed-review-ready.yaml'
with target.open('x') as f:f.write(yaml.dump(obj,Dumper=NoAliasDumper,allow_unicode=True,sort_keys=False,width=100))
loaded=yaml.safe_load(target.read_text());del [e for e in loaded['evidence'] if e['evidence_id']=='prior-search'][0]['search_scope'];assert loaded==yaml.safe_load(original.read_text());assert pin(original)==before
(H/'search-scope-correction.json').write_text(json.dumps({'status':'search_scope_metadata_only_successor','original':before,'successor':pin(target),'original_failure':pin(H/'native-validate-final-execution.json'),'reason':'Native semantic validator requires search evidence.search_scope. The already recorded exact 120-body hidden/ignored-inclusive inventory and exact-target rule are now represented in that field. No new search or scientific disposition.','all_judgments_timestamps_source_captures_and_prior_evidence_fields_unchanged':True,'original_preserved':True},indent=2)+'\n')
print('PASS: only explicit bounded search_scope added')
