"""Fresh literal packet closure and actual native command origin/stream checks."""
import hashlib,json,os,stat
from pathlib import Path
H=Path(__file__).resolve().parent;N=Path('/private/tmp/pathwaymech-next-238-local-native-execution-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(x):
 actual=pin(Path(x['path']));assert actual['sha256']==x['sha256'] and actual['bytes']==x['bytes'],x;return actual
assert pin(N/'handoff.json')['sha256']=='8fb12b32116623085696f23943a74599bb0d50f269a91edc0a19d394cad7c2d8'
assert pin(N/'artifact-manifest.json')['sha256']=='15e471d4288233064e849d422ae05e1195eef35e524a8a38b37260ca7a283da2'
m=json.loads((N/'artifact-manifest.json').read_text());actual=[];dirs=[]
for base,ds,fs in os.walk(N,followlinks=False):
 for name in ds:dirs.append(str((Path(base)/name).relative_to(N)))
 for name in fs:
  p=Path(base)/name;assert stat.S_ISREG(p.lstat().st_mode),p
  actual.append(str(p.relative_to(N)))
assert set(actual)=={x['relative_path'] for x in m['files']}|{'artifact-manifest.json','handoff.json'}
for x in m['files']:verify(x)
summary=json.loads((N/'execution-summary.json').read_text());commands=[]
for c in summary['completions']:
 verify(c);cp=Path(c['path']);completion=json.loads(cp.read_text())
 for e in completion['receipts']:
  verify(e['stdout']);verify(e['stderr']);verify(e['runner_at_start']);verify(e['phase_start'])
  p=cp.parent/(e['name']+'.execution.json');assert json.loads(p.read_text())==e
  assert e['exit_code']==0 and e['cwd']=='/private/tmp/pathwaymech-next-238-local-20261012'
  commands.append({'receipt':pin(p),'actual':e})
for o in summary['outputs']:verify(o)
assert len(commands)==12
out={'status':'pass','inherited_actual_native_execution':True,'not_run_by_current_reviewer':True,'handoff':pin(N/'handoff.json'),'manifest':pin(N/'artifact-manifest.json'),'fresh_literal_complete_closure_files':len(m['files']),'directories':len(dirs),'complete_manifest':m,'commands':commands,'summary':pin(N/'execution-summary.json'),'tests_summary':summary['tests_summary'],'all_command_receipts_streams_runner_and_phase_start_bindings_match':True,'actual_command_count':12,'gate_count':9,'interpretation':'Source prose and science still reviewed separately; passing commands do not replace scientific evidence. Whole checkout/root QA remains separate.'}
(H/'native-gate-bindings.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS: fresh76+2 native closure and12 actual command receipt/stream/origin checks;9gates succeeded')
