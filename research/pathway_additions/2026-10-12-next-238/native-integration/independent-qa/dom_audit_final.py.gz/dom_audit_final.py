"""Read-only maintained DOM audit and external static raster from actual SVG/CSS."""
import hashlib,json,re,subprocess
from datetime import datetime,timezone
from pathlib import Path
from lxml import etree,html
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-238-local-20261012')
T=R/'data/pathways/5-prime-deoxyadenosine-degradation-i.yaml'
PAGE=R/'pages/records/MetaCyc_PWY-8130.html'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def norm(s):return ' '.join(s.split())
inputs=[T,PAGE,*[R/'pages/assets'/n for n in ('pathway-network.css','pathway-network.js')],R/'src/pathwaymech/graph_view.py',R/'src/pathwaymech/cli.py']
initial=[bind(p) for p in inputs]
d=yaml.safe_load(T.read_bytes());page=PAGE.read_text();dom=html.fromstring(page)
assert initial[0]['sha256']=='c8ae12061fd62a5ff8c6861b6665e3ac6938b0fe611b9e3d8d6a1e11f33199a5'
ids=dom.xpath('//*[@id]/@id');assert len(ids)==len(set(ids))
local=dom.xpath('//*[@href]/@href');local=[s[1:] for s in local if s.startswith('#')]
assert all(s in ids for s in local)
node=dom.xpath('//a[contains(concat(" ",@class," ")," graph-node ")]')
edge=dom.xpath('//a[contains(concat(" ",@class," ")," graph-edge ")]')
assert len(node)==23 and len(edge)==len(d['mechanistic_edges'])==21
assert len(dom.xpath('//*[@data-qualified="true"]'))==5
base={x.get('data-base-node-id',x.get('data-node-id')) for x in node}
assert base=={d['id'],*[n['id'] for n in d['participants']],*[n['id'] for n in d['reactions']]}
alltext=norm(dom.text_content());paragraphs=d['description'].split('\n\n')
for p in paragraphs:assert norm(p) in alltext
rows=[]
for i,(e,a) in enumerate(zip(d['mechanistic_edges'],edge),1):
 assert a.get('href')==f'#mechanism-edge-{i}' and a.get('data-predicate')==e['predicate']
 assert a.get('data-subject-id',a.get('data-subject'))==e['subject']
 assert a.get('data-object-id',a.get('data-object'))==e['object']
 row=dom.get_element_by_id(f'mechanism-edge-{i}');s=norm(row.text_content())
 assert e['subject'] in s and e['object'] in s and e['predicate'] in s
 assert norm(e.get('description','')) in s
 assert len(a.xpath('./path[@marker-end]'))==1
 for ev in e['evidence']:
  assert norm(ev.get('source_assertion',ev.get('quote',''))) in s
  if ev.get('source_locator'):assert norm(ev['source_locator']) in s
  assert ev['reference_id'] in s
 for q in e.get('endpoint_qualifiers',[]):
  qid=f'mechanism-edge-{i}-qualifier-{q["endpoint"]}'
  qrow=dom.get_element_by_id(qid);qs=norm(qrow.text_content())
  assert norm(q['description']) in qs
  display=[n for n in node if n.get('href')=='#'+qid];assert len(display)==1
  assert q['description'] in display[0].get('aria-label')
  assert display[0].get('data-base-node-id')==e[q['endpoint']]
  for ev in q['evidence']:
   assert norm(ev.get('source_assertion',ev.get('quote',''))) in qs
   assert ev['reference_id'] in qs
   if ev.get('source_locator'):assert norm(ev['source_locator']) in qs
 rows.append({'edge_id':e['id'],'subject':e['subject'],'predicate':e['predicate'],'object':e['object'],'evidence':len(e['evidence']),'qualifiers':len(e.get('endpoint_qualifiers',[])),'pass':True})
for i,n in enumerate(d['taxa']+d['participants']+d['reactions'],1):
 s=norm(dom.get_element_by_id(f'component-{i}').text_content())
 assert n['id'] in s and norm(n['label']) in s
 if n.get('direction'):assert n['direction'].replace('_',' ') in s
for i,ref in enumerate(d['references'],1):
 s=norm(dom.get_element_by_id(f'reference-{i}').text_content())
 assert ref['id'] in s
 if ref.get('url'):assert ref['url'] in dom.get_element_by_id(f'reference-{i}').xpath('.//a/@href')
 for k in ['title','citation','source_version']:
  if ref.get(k):assert norm(str(ref[k])) in s
assert len(dom.xpath('//blockquote'))==sum('quote' in e for edge in d['mechanistic_edges'] for e in edge['evidence'])+sum('quote' in ev for edge in d['mechanistic_edges'] for q in edge.get('endpoint_qualifiers',[]) for ev in q['evidence'])
svg=re.search(r'<svg\b[^>]*class="pathway-network-svg"[^>]*>.*?</svg>',page,re.S).group()
(H/'maintained-graph-original.svg').write_text(svg)
css=(R/'pages/assets/pathway-network.css').read_text().split('@media')[0]
variables=dict(re.findall(r'(--graph-[a-z]+):\s*([^;]+);',css))
for k,v in variables.items():css=css.replace('var('+k+')',v)
root=etree.fromstring(svg.encode());style=etree.Element('{http://www.w3.org/2000/svg}style');style.text=css;root.insert(0,style)
(H/'maintained-graph-light.svg').write_bytes(etree.tostring(root))
argv=['/usr/local/bin/rsvg-convert','-w','1800','-b','white','-o',str(H/'maintained-graph-light.png'),str(H/'maintained-graph-light.svg')]
start=datetime.now(timezone.utc).isoformat();proc=subprocess.run(argv,capture_output=True)
(H/'raster.stdout').write_bytes(proc.stdout);(H/'raster.stderr').write_bytes(proc.stderr)
receipt={'started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'argv':argv,'exit_code':proc.returncode,'renderer':bind(Path(argv[0])),'svg':bind(H/'maintained-graph-light.svg'),'stdout':bind(H/'raster.stdout'),'stderr':bind(H/'raster.stderr')}
(H/'raster-execution.json').write_text(json.dumps(receipt,indent=2)+'\n');assert proc.returncode==0
assert initial==[bind(p) for p in inputs]
old=Path('/private/tmp/pathwaymech-next-238-graph-preview-20261012/records/MetaCyc_PWY-8130.html')
oldsvg=re.search(r'<svg\b[^>]*class="pathway-network-svg"[^>]*>.*?</svg>',old.read_text(),re.S).group()
assert svg==oldsvg
result={'status':'pass','inputs_before_and_after':initial,'helper':bind(Path(__file__)),'paragraphs':len(paragraphs),'named_ids':20,'component_rows':19,'visual_nodes':len(node),'edges':rows,'qualified_instances':5,'references':42,'all_local_anchor_targets_resolve':len(local),'whole_qualifier_and_evidence_payloads_present':True,'old_static_preview_svg_byte_exact':bind(old),'raster_receipt':bind(H/'raster-execution.json'),'raster':bind(H/'maintained-graph-light.png'),'limits':['Static light SVG raster only; media queries excluded. No interactive browser, responsive or dark-mode claim.','No full site build or maintained input mutation.']}
(H/'dom-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: 10 paragraphs, 20 identities, 23 visual nodes, 21 complete edges, 5 qualifiers, 42 references; static raster produced')
