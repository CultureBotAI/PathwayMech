"""Bounded target export/authority/currentness review; no output generation to repository."""
import csv,hashlib,io,json,os,subprocess,sys
from dataclasses import asdict
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-238-local-20261012')
sys.path[:0]=[str(R/'src'),str(R)]
from pathwaymech.schema import validate_record
from pathwaymech.kgx import kgx_nodes,kgx_edges
from pathwaymech.sssom import sssom_rows
T=R/'data/pathways/5-prime-deoxyadenosine-degradation-i.yaml';d=yaml.safe_load(T.read_text());record=validate_record(d)
def pin(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def tsv(p):return list(csv.DictReader(io.StringIO('\n'.join(x for x in p.read_text().splitlines() if not x.startswith('#'))),delimiter='\t'))
paths=[R/'output/kgx/nodes.tsv',R/'output/kgx/edges.tsv',R/'output/sssom/source_mappings.sssom.tsv',R/'data/identifier_authorities/sources.json',R/'data/identifier_authorities/ontology.json']
initial=[pin(p) for p in paths]
nodes={x['id']:x for x in tsv(paths[0])};edges={x['id']:x for x in tsv(paths[1])};mapping=tsv(paths[2]);node_checks=[];edge_checks=[]
for expected in kgx_nodes([record]):
 actual=nodes[expected.id];ctx=json.loads(expected.source_contexts);actualctx=[x for x in json.loads(actual['source_contexts']) if x.get('record_id')==record.id]
 assert actualctx==ctx
 node_checks.append({'id':expected.id,'whole_local_contexts':ctx,'pass':True})
for expected in kgx_edges([record]):
 assert edges[expected.id]==asdict(expected)
 edge_checks.append({'id':expected.id,'whole_row_sha256':hashlib.sha256(json.dumps(edges[expected.id],sort_keys=True).encode()).hexdigest(),'pass':True})
expectedmaps=[asdict(x) for x in sssom_rows([record])];actualmaps=[x for x in mapping if 'source_pathway_id='+record.id+';' in x['comment']]
assert expectedmaps==actualmaps
terms={};authorities=[]
for p in paths[3:]:
 a=json.loads(p.read_text());terms.update(a['terms']);authorities.append({'source':pin(p),'terms':len(a['terms']),'owners':len(a['sources'])})
for row in node_checks:assert row['id'] in terms
ins=json.loads((H/'native-inspection.json').read_text());current=[]
for x in ins['source']['inputs']:
 b=pin(R/x['path']);assert b['sha256']==x['sha256'],x['path'];current.append(b)
cmd=['rg','--files','--no-ignore','--hidden',str(R/'reviews/structured')]
p=subprocess.run(cmd,capture_output=True,check=True);(H/'prior-review-files.stdout').write_bytes(p.stdout);(H/'prior-review-files.stderr').write_bytes(p.stderr)
prior=[];allreviews=[]
for name in p.stdout.decode().splitlines():
 f=Path(name)
 if f.suffix not in {'.yaml','.yml'}:continue
 y=yaml.safe_load(f.read_text());allreviews.append(pin(f))
 targets=y.get('targets',[]) if isinstance(y,dict) else []
 if any(x.get('target_id')==record.id or x.get('path')==str(T.relative_to(R)) for x in targets):prior.append({'file':pin(f),'targets':targets,'findings':y.get('findings',[])})
assert initial==[pin(p) for p in paths]
result={'status':'pass','target':pin(T),'exports_and_authorities_at_start_and_finish':initial,'authority_counts':authorities,'identities_checked':len(node_checks),'node_contexts':node_checks,'whole_edge_rows':edge_checks,'whole_source_mappings':actualmaps,'native_inspection_inputs_still_exact':current,'previous_review_search':{'argv':cmd,'exit_code':p.returncode,'hidden_ignored_included':True,'literal_symlink_policy':'rg inventory does not follow directory symlinks; no recursive alias traversal','yaml_reviews':len(allreviews),'files':allreviews,'exact_target_matches':prior},'scope':'Single-record projections compared against actual whole maintained exports. Whole-corpus gates are separately root owned.'}
(H/'exports-currentness.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: 20 authority IDs, 20 whole local node contexts, 21 whole edge rows, 10 SSSOM mappings, original native inspection current; prior exact target bundles',len(prior))
