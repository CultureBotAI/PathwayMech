"""Finish individual identity/reference judgments and exact prior-review inventory."""
import hashlib,json,subprocess
from pathlib import Path
from datetime import datetime,timezone
import yaml
H=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-238-local-20261012')
d=yaml.safe_load((R/'data/pathways/5-prime-deoxyadenosine-degradation-i.yaml').read_text())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def dump(n,v):(H/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
identities=[]
for row in json.loads((H/'identity-checks.json').read_text()):
 id=row['id']
 if id==d['id']:reason='Full native exact Pathway frame, label, three-member reaction list/layout/order, species/evidence and original request provenance establish PWY-8130; whole-pathway physiology narrowed by primary assay.'
 elif id=='NCBITaxon:269796':reason='Complete NCBI original identifies strain ATCC11170 under parent1085; full2020 Methods and reviewed UniProt strain agree.'
 elif id=='NCBITaxon:1085':reason='Complete NCBI species record and native protein/assembly species contexts agree; this rank does not replace strain-level physiological scope.'
 elif id.startswith('CHEBI:'):
  reason='Released current ChEBI identity, full InChI/stereochemistry and formal charge read against whole original; biological role comes from exact incident edges.'
  if id=='CHEBI:144504':reason+=' Malformed definition refers to ribose; retained ribulose label and ketose structure, not that prose, resolve identity.'
  elif id=='CHEBI:43474':reason+=' Native Pi explicitly uses hydrogenphosphate structure; no inference of universal intracellular speciation.'
  elif id in {'CHEBI:48828','CHEBI:49786'}:reason+=' This is the2+ion, used in a distinct recombinant Ald2 reconstitution state; no physiological occupancy claim.'
  else:reason+=' Native full structure comparison and Rhea family side traversal agree.'
 elif id.startswith('UniProtKB:'):reason='Current reviewed whole protein original, strain269796, locus and reciprocal native gene/protein mapping agree. Assay modifications remain endpoint qualifiers; broader inferred annotations do not become direct measurement.'
 elif id.startswith('MetaCyc:RXN-'):reason='Complete native reaction object and scientific sides/evidence/membership read. Exact chemical equation and reaction-class identity are preserved, with native direction distinct from physiological pathway layout.'
 elif id=='MetaCyc:CPLX-8605':reason='Full native typed protein complex with component coefficient2 toCPLX-8604, enzyme association and species1085; not synonymous with its chain. Direct topology is database assertion; physiological occupancy unknown.'
 elif id=='MetaCyc:CPLX-8604':reason='Full native typed complex with coefficient3 toMONOMER-17874 and backlink toCPLX-8605. Issuer dimer label conflicts with composition and is intentionally preserved.'
 else:reason='Full native typed polypeptide frame MONOMER-17874 and current reviewedQ2RXH9 reciprocal/locus/strain/sequence identity establish retained single chain; mapping-onlyQ2RXH9 does not create another participant.'
 identities.append({**row,'outcome':'supported_with_stated_limits','fresh_reviewer_rationale':reason})
dump('identity-appraisals.json',identities)
closure=json.loads((H/'whole-source-closure.json').read_text());bysha={x['original']['sha256']:x for x in closure['sources']};refs=[]
for r in d['references']:
 source=bysha[r['source_sha256']]
 if r['id'].startswith('PMID:'):reason='Exact citation/publication identity and complete material primary main text freshly read from NCBI BioC. Main captions/table are available; original figure bodies/SI access limits inherited from retained attempts, not silently promoted into full supplementary review.'
 elif r['id'].startswith('RHEA:'):reason='Shared full compressed release142 original is the cited artifact. Fresh stream scan checks all selected family/side/participant/compound descriptions including repeated subjects. Native direction remains independent; no unrelated whole-database interpretation claimed.'
 elif r['id'].startswith('MetaCyc:'):reason='Whole native original and exact META frame/version27 provenance bound; all material native contexts assessed. Database prose and its evidence/PMID links remain database attribution, not primary quotations. Full raw bodies remain available, beyond selected claims.'
 elif r['id'].startswith('UniProtKB:'):reason='Whole reviewed current entry original retained. All material function/catalytic/kinetic/construct/assembly/evidence/identity fields freshly read; annotation and sequence versions remain distinct. A database citation does not prove independent reading of every cited paper.'
 elif r['id'].startswith('NCBITaxon:'):reason='Complete issuing NCBI EFetch original freshly read; exact rank,parent,type/strain scope preserved.'
 else:reason='Whole current released ChEBI original retained. Exact chemical/stereo/charge/definition fields freshly read, with native structure comparisons. Current entry acquisition is not represented as a new pinned ontology release.'
 refs.append({'reference':r,'original':source['original'],'receipts':source['receipts'],'outcome':'supported_with_stated_limits','fresh_reviewer_rationale':reason})
dump('reference-appraisals.json',refs)
cmd=['rg','--files','--no-ignore','--hidden',str(R/'reviews/structured')]
p=subprocess.run(cmd,capture_output=True,check=True);(H/'prior-native-inventory.stdout').write_bytes(p.stdout);(H/'prior-native-inventory.stderr').write_bytes(p.stderr)
allreviews=[];matches=[]
for name in p.stdout.decode().splitlines():
 f=Path(name)
 if f.suffix not in {'.yaml','.yml'}:continue
 q=yaml.safe_load(f.read_text());allreviews.append(pin(f))
 if any(x.get('target_id')==d['id'] or x.get('path')=='data/pathways/5-prime-deoxyadenosine-degradation-i.yaml' for x in q.get('targets',[])):
  matches.append({'file':pin(f),'review_id':q.get('review_id'),'targets':q.get('targets'),'findings':q.get('findings')})
dump('prior-native-reviews.json',{'at':datetime.now(timezone.utc).isoformat(),'argv':cmd,'exit_code':p.returncode,'hidden_ignored_included':True,'literal_aliases_not_followed':True,'all_review_bodies':allreviews,'exact_target_matches':matches,'explanation':'Text mentions ofPWY8130 in preceding237 review context are not target ownership or predecessor findings. No native previous_occurrences is invented from external reports.'})
print('PASS: 20 individual identity appraisals, 42 original-bound reference appraisals; prior exact native target matches',len(matches),'among',len(allreviews),'review YAML bodies')
