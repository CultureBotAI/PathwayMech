"""Seal completed external SCI evidence; no maintained copy or native save."""
import hashlib,json,os,stat
from datetime import datetime,timezone
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-238-local-20261012')
PREFIX='research/pathway_additions/2026-10-12-next-238/native-integration/independent-qa'
Q=Path('/private/tmp/pathwaymech-next-238-root-maintained-qa-20261012')
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,obj):
 with (H/name).open('x') as f:f.write(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
assert not (H/'handoff.json').exists() and not (H/'artifact-manifest.json').exists()
ready=H/'completed-review-ready.yaml';review=yaml.safe_load(ready.read_text());validation=json.loads((H/'native-validate-ready-execution.json').read_text())
assert validation['exit_code']==0 and validation['inputs_at_start'][1]==pin(ready)
assert review['source']==json.loads((H/'native-inspection-after-gates.json').read_text())['source']
original=yaml.safe_load((H/'completed-review.yaml').read_text());expected=json.loads(json.dumps(original));expected['review_id']=review['review_id']
for e in expected['evidence']:
 if e['evidence_id']=='prior-search':e['search_scope']=next(x['search_scope'] for x in review['evidence'] if x['evidence_id']=='prior-search')
assert expected==review
inputs=[]
for i in review['source']['inputs']:
 p=R/i['path'];assert stat.S_ISREG(p.lstat().st_mode);b=pin(p);assert b['sha256']==i['sha256'];inputs.append(b)
assert len(inputs)==35
for name in ['dom_audit','dom_audit_corrected','exports_currentness']:
 assert json.loads((H/(name+'-execution.json')).read_text())['exit_code']==1
for name in ['native-validate','native-validate-aliasfree','native-validate-final']:
 assert json.loads((H/(name+'-execution.json')).read_text())['exit_code']==1
for name in ['audit','dom_audit_final','exports_currentness_after_gates','audit_gate_bindings','copy_native_evidence','close_root_qa']:
 assert json.loads((H/(name+'-execution.json')).read_text())['exit_code']==0
assert pin(Q/'handoff.json')['sha256']=='83661b4c0b6deca94b171a824f3f723a2a666f8609e44550edd6c108015e4c89'
# Fresh integrity check for every original review execution descriptor owned by this packet.
checked=[]
for p in sorted(H.glob('*execution.json')):
 j=json.loads(p.read_text())
 for key in ['stdout','stderr']:
  if key in j and isinstance(j[key],dict) and 'path' in j[key]:
   d=j[key];a=pin(d['path']);assert all(a[k]==d[k] for k in ('sha256','bytes')),(p,key)
 for d in j.get('inputs_at_start',[]):
  if 'path' in d:
   a=pin(d['path']);assert all(a[k]==d[k] for k in ('sha256','bytes')),(p,d)
 checked.append(pin(p))
now=datetime.now(timezone.utc).isoformat()
write('final-proposal-bindings.json',{'status':'native_validated_external_scientific_proposal_not_saved','at':now,'proposal':pin(ready),'native_validation':pin(H/'native-validate-ready-execution.json'),'native_inspection':pin(H/'native-inspection-after-gates.json'),'original_inspection':pin(H/'native-inspection.json'),'source_input_count':35,'current_source_inputs':inputs,'all_original_receipt_helpers_inputs_and_streams_match':checked,'root_qa_handoff':pin(Q/'handoff.json'),'root_qa_closure':pin(H/'root-qa-binding.json'),'assessments':97,'checks':21,'evidence':38,'new_required_findings':0,'complete_original_review_equal_except_native_review_id_and_explicit_prior_search_scope':True,'native_save_performed':False})
write('durable-adoption-instructions.json',{'status':'plan_only_not_executed','packet':str(H),'destination_prefix':PREFIX,'copy_rule':'Copy every literal file and directory enumerated by the final artifact manifest, plus the original manifest and handoff, byte-exact. Do not rewrite original absolute execution paths or receipt bodies. Preserve actual-native including its original nested seals; native-evidence-copy-bindings.json maps original bodies.','proposed_review':'completed-review-ready.yaml','original_capture':'native-inspection.json','after_gates_capture':'native-inspection-after-gates.json','original_source_inputs':35,'timestamps_rule':'Retain original scientific started_at/finished_at and all original inspection/execution timestamps. New evidence adoption/reinspection is a separate actual receipt, not a replacement original.','currentness_rule':'Before save, freshly inspect all original 35 inputs and require exact descriptors plus git_revision/state. Any source input extension for durable adopted evidence must be explicit, with original capture and whole judgment fields preserved. Do not silently replace source input bodies.','root_qa_prefix':'research/pathway_additions/2026-10-12-next-238/native-integration/root-review','save_authority':'Root must approve the concrete guarded adoption and native-save bundle; this packet does not authorize or perform either.'})
write('actual-finalization-tools.json',{'scope':'Actual tools visible during final proposal assembly; prior science/read/DOM/gate origins are retained separately.','root_closure':'17b0fb/0','proposal_assembly':'a4241e/0','first_native_validation':'0731d7/session25827 ->16ac3e/1; original aliases rejected','alias_only_correction':'3028c2/0','second_native_validation':'24b208/session40921 ->7fd648/1; review_id clock prefix mismatch','review_id_only_correction':'5ad561/0','third_native_validation':'443cf4/session3406 ->f09b23/1; bounded search_scope field omitted','search_scope_only_correction':'60c792/0','final_native_validation':'6e7086/session11162 ->8bb3ce/0','native_save_performed':False})
with (H/'REPORT-initial.md').open('xb') as f:f.write((H/'REPORT.md').read_bytes())
(H/'REPORT.md').write_text("""# Record 238 maintained scientific review

The exact maintained 5′-deoxyadenosine degradation I record passes this fresh scientific review with explicit source and visual limits. No supported new scientific defect was found. The external native proposal is `completed-review-ready.yaml`: 97 appraisals (10 paragraphs, 21 whole edges, 20 identities, 42 references and four scope/representation groups), 21 checks and 38 evidence entries. Native validation returned zero; no native review has been saved.

Deoxy authored the scientific draft and Aceto its prior full scientific review. This reviewer authored the earlier eligibility/source preflight, authority design and canonical preparation, but not the draft. Fresh scientific judgment is independent of draft authorship; root and separate peers retain technical acceptance of this reviewer's earlier preparation. Root's sealed QA/TECH proposal has a fresh 39+2 literal closure here. Its whole-checkout and full implementation judgments are inherited, not independently self-certified.

All 1,129 maintained YAML lines and all material available primary and native contexts were read. Fresh reading covers every available 2012 and 2020 BioC passage, full methods/results/discussion/captions/references, full 2020 Table 1 and footnotes; complete native pathway, reaction, nested assembly, enzyme/activity, gene and protein frames; all material UniProt scientific/identity fields; current complete chemical identity structures and taxon bodies. Read coverage records output truncations and the exact subsequent complete rereads. Whole-source closure freshly binds 40 original bodies and 39 unique acquisition receipts. Faithful reading aids do not replace complete originals. The bounded source audit passed all 328 native slots, 155 evidence locators, 34 Rhea subjects/45 blocks, nine chemical sides, two transfers, five qualifiers, six kinetic slots, 20 identities and ten mappings.

Scientific scope remains precise: phosphorolytic MtnP entry is distinct from hydrolysis/kinase entry; the native CPLX-8605 → 2 × CPLX-8604 → 3 × MONOMER-17874 hierarchy and conflicting dimer label are retained. Mapping-only Q2RXH9 is not a duplicate chain node. The older MtnP/MtnA kinetic provenance, source gene-label conflict, Ald2 efficiency arithmetic discrepancy, garbled ChEBI definition, source-native reversibility, recombinant constructs, strain versus species limits, and separate cobalt/nickel reconstitution conditions remain explicit. No physiological metal occupancy, channeling or independent chain catalysis is inferred.

Fresh actual maintained DOM checks pass all ten complete paragraphs, 20 named IDs, 23 display nodes, 21 arrows/predicates, five full qualifier descriptions and 42 references. All local anchors resolve. Complete evidence remains in the adjacent tables and graph accessibility text. The actual native SVG equals the accepted preview; a new light SVG/raster was generated from this actual page and personally viewed in full. Dense shared-junction labels, truncated state captions and tall whitespace remain. Fresh CUA inventory returned no enabled browser or native app; no interactive, keyboard, responsive, dark-mode or print verification is claimed.

The initial native capture at 22:18:35 UTC correctly bound the pre-phase2 KGX. A distinct after-gates inspection preserves that original capture and records exactly two KGX input changes. Current final KGX passes all 20 whole target node contexts and 21 whole edge payloads; all ten exact SSSOM rows pass. All 35 final native source inputs were freshly byte-checked again at sealing. An ignored/hidden-inclusive inventory and full parsing of all 120 native review YAML bodies found no exact target predecessor; mentions in other records are not fabricated prior findings.

All nine actual maintained gates passed on their first attempt, with 4,273 tests, three skips and three existing dependency warnings. This reviewer checked the complete original receipts/streams and all 12 native command origins rather than rerunning broad gates. Both actual histories preceded SSSOM and first render. The full 76+2 native packet is copied unchanged under `actual-native/`, retaining its original seals and receipt bodies, with a fresh whole source/destination ledger. Separate root after-gates QA preserves all old records/pages, 120 review pairs, 404 histories and the 800-entry cache, with the exact authorized owner changes; this technical conclusion is inherited and clearly separated from fresh science.

All failures remain intact. Two original DOM helpers expected raw direction spelling and reference hashes that the current UI does not display; narrow successor expectations retain complete biological and source-hash checks and pass. The initial export check ran before phase2 KGX and correctly rejected the old target-free export; after-gates capture and exact payload comparisons pass. Native proposal validation then rejected YAML aliases, a one-second difference between independently generated ID/finished-time clocks, and missing explicit search_scope metadata. Three separate narrow successors preserve every scientific judgment, actual timestamp, original source capture and prior evidence field; the last adds only the already executed bounded search scope. The final proposal validates successfully (only LinkML topClass deprecation). All original proposals, helpers, commands, stdout/stderr and correction descriptions are retained. `REPORT-initial.md` preserves the premature in-progress report unchanged.

Original figure bodies and supplementary files for the main 2012/2020 studies remain unavailable under the inherited acquisition record; no image-body/SI reading is claimed. Older 2017 and comparative 2018/2024/2025 interpretations are inherited rather than newly fully read; older tag details remain database-attributed. Full unrelated ontology/reaction databases, all producer implementations and all prior full-corpus science were not freshly interpreted. These limits are in the native proposal.

Durable SCI evidence destination is `research/pathway_additions/2026-10-12-next-238/native-integration/independent-qa`; separate root evidence belongs under `root-review`. The copy rule is literal, whole and byte-exact, preserving original nested seals, failure streams and timestamps. Root owns the guarded evidence adoption, separate source-extension reinspection and eventual native save. This sealed packet performs no maintained copy, native save, product/cache edit, Git/GitHub action or public release.
""")
files=[];dirs=[]
for base,ds,fs in os.walk(H,followlinks=False):
 for n in ds:
  p=Path(base)/n;assert not p.is_symlink();dirs.append(str(p.relative_to(H)))
 for n in fs:
  p=Path(base)/n;assert stat.S_ISREG(p.lstat().st_mode);files.append({**pin(p),'relative_path':str(p.relative_to(H)),'file_type':'regular'})
files.sort(key=lambda x:x['relative_path']);dirs.sort()
write('artifact-manifest.json',{'status':'sealed_complete_literal_packet','hidden_and_ignored_included':True,'symlinks':0,'files':files,'directories':dirs})
write('handoff.json',{'status':'maintained_scientific_review_pass_with_limitations_native_validated_pending_root_adoption_and_save','at':now,'packet':str(H),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'seals':2,'directories_below_root':len(dirs),'report':pin(H/'REPORT.md'),'proposal':pin(ready),'native_validation':pin(H/'native-validate-ready-execution.json'),'bindings':pin(H/'final-proposal-bindings.json'),'root_qa_handoff':pin(Q/'handoff.json'),'native_handoff':pin(H/'actual-native/handoff.json'),'native_scientific_review_saved':False,'new_required_findings':0,'durable_evidence_prefix':PREFIX,'adoption_instructions':pin(H/'durable-adoption-instructions.json')})
for f in files:assert pin(f['path'])['sha256']==f['sha256']
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'proposal':pin(ready),'artifacts':len(files),'seals':2,'directories_below_root':len(dirs)},indent=2))
