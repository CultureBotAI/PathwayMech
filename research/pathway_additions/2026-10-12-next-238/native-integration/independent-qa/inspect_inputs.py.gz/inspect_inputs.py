"""Execute the exact planned native read-only inspection, with actual receipt."""
import hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
H=Path(__file__).resolve().parent
PLAN=Path('/private/tmp/pathwaymech-next-238-maintained-science-review-plan-20261012')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def now():return datetime.now(timezone.utc).isoformat()
plan=json.loads((PLAN/'planned-commands.json').read_bytes());started=now();tick=time.monotonic()
inputs=[bind(PLAN/'handoff.json'),bind(PLAN/'planned-commands.json'),bind(PLAN/'targets.yaml'),bind(__file__),bind(plan['inspect'][2])]
with (H/'native-inspection.json').open('xb') as out,(H/'native-inspection.stderr').open('xb') as err:
 result=subprocess.run(plan['inspect'],cwd=plan['cwd'],env={**os.environ,**plan['environment']},stdout=out,stderr=err,check=False)
receipt={'started_at':started,'finished_at':now(),'seconds':time.monotonic()-tick,'argv':plan['inspect'],'cwd':plan['cwd'],'environment':plan['environment'],'exit_code':result.returncode,'inputs_at_start':inputs,'stdout':bind(H/'native-inspection.json'),'stderr':bind(H/'native-inspection.stderr'),'scope':'Native input capture only; no saved review or scientific verdict.'}
(H/'inspect-execution.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'exit_code':result.returncode,'receipt':bind(H/'inspect-execution.json')},indent=2));raise SystemExit(result.returncode)
