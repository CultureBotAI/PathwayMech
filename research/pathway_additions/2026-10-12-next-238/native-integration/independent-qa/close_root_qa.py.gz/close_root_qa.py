"""Fresh literal closure of separate root QA; no independent self-certification."""
import hashlib,json,os,stat
from pathlib import Path
H=Path(__file__).resolve().parent
Q=Path('/private/tmp/pathwaymech-next-238-root-maintained-qa-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert pin(Q/'handoff.json')['sha256']=='83661b4c0b6deca94b171a824f3f723a2a666f8609e44550edd6c108015e4c89'
assert pin(Q/'artifact-manifest.json')['sha256']=='3ed2a617d045b559e7722b16f532d18e2323df1e28548638c9f1a07cfd20af2e'
m=json.loads((Q/'artifact-manifest.json').read_text());files=[];dirs=[]
for base,ds,fs in os.walk(Q,followlinks=False):
 for n in ds:
  p=Path(base)/n;assert not p.is_symlink();dirs.append(str(p.relative_to(Q)))
 for n in fs:
  p=Path(base)/n;assert stat.S_ISREG(p.lstat().st_mode);files.append(str(p))
assert set(files)=={r['path'] for r in m['artifacts']}|{str(Q/'handoff.json'),str(Q/'artifact-manifest.json')}
assert len(m['artifacts'])==39
for r in m['artifacts']:
 a=pin(Path(r['path']));assert all(a[k]==r[k] for k in ('bytes','sha256'));assert r['file_type']=='regular'
target=json.loads((Q/'after-gates/target-qa.json').read_text())
assert all(c['passed'] for c in target['checks'])
checkout=json.loads((Q/'after-gates/checkout-preservation.json').read_text())
assert checkout['whole_old_owners_preserved_outside_exact_plan'] and checkout['cache_entries_unchanged']==800
proposal=json.loads((Q/'technical-proposal.json').read_text());assert proposal['scientific_review'] is False
validation=json.loads((Q/'technical-validate.execution.json').read_text());assert validation['exit_code']==0
out={'status':'pass','handoff':pin(Q/'handoff.json'),'manifest':pin(Q/'artifact-manifest.json'),'literal_complete_closure':{'artifacts':39,'seals':2,'directories_below_root':len(dirs),'hidden_and_ignored_included':True,'aliases':0},'whole_manifest':m,'target_check_count':len(target['checks']),'all_root_target_results_pass':True,'checkout_preservation':checkout,'technical_proposal':pin(Q/'technical-proposal.json'),'native_technical_validation':pin(Q/'technical-validate.execution.json'),'interpretation':'Root report, relevant target summary and complete technical appraisals/checks freshly read; full technical implementation and corpus checks are inherited, not an independent certification of this reviewer\'s earlier preparation. Fresh current single-record science/DOM/export checks are separately retained.'}
(H/'root-qa-binding.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: separate root QA literal39+2 closure, all recorded checks, native TECH validation and inherited-role boundary')
