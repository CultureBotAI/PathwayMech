"""Native validation only; never save, adopt or modify review content."""
import hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
H=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-238-local-20261012');P='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def now():return datetime.now(timezone.utc).isoformat()
argv=[P,'-B',str(R/'scripts/record_review.py'),'--repo-root',str(R),'--schema',str(R/'schema/record_review.yaml'),'validate',str(H/'completed-review-aliasfree.yaml')]
inputs=[pin(__file__),pin(H/'completed-review-aliasfree.yaml'),pin(R/'scripts/record_review.py'),pin(R/'schema/record_review.yaml')]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'};start=now();tick=time.monotonic()
with (H/'native-validate-aliasfree.stdout').open('xb') as out,(H/'native-validate-aliasfree.stderr').open('xb') as err:code=subprocess.run(argv,cwd=R,env={**os.environ,**env},stdout=out,stderr=err,check=False).returncode
(H/'native-validate-aliasfree-execution.json').write_text(json.dumps({'started_at':start,'finished_at':now(),'seconds':time.monotonic()-tick,'argv':argv,'cwd':str(R),'environment':env,'exit_code':code,'inputs_at_start':inputs,'stdout':pin(H/'native-validate-aliasfree.stdout'),'stderr':pin(H/'native-validate-aliasfree.stderr')},indent=2)+'\n')
assert pin(H/'completed-review-aliasfree.yaml')==inputs[1]
print('native validate only',code);raise SystemExit(code)
