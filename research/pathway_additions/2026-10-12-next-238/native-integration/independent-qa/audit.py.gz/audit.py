"""Independent bounded whole-original scientific consistency checks; no builders."""
from pathlib import Path
from collections import Counter, defaultdict
import json, hashlib, gzip, re, sys, html, datetime
from lxml import etree as E
import yaml
R=Path('/private/tmp/pathwaymech-next-238-maintained-science-review-20261012')
A=Path('/private/tmp/pathwaymech-next-238-author-20261012')
P=Path('/private/tmp/pathwaymech-next-238-preflight-20261012')
RT=Path('/private/tmp/pathwaymech-next-238-local-20261012')
sys.path.insert(0,str(RT/'src'))
from pathwaymech.schema import validate_record
from pathwaymech.strict import strict_errors
def sha(b): return hashlib.sha256(b).hexdigest()
def save(name,obj): (R/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def shape(e): return [e.tag,sorted(e.attrib.items()),e.text or '',[shape(c) for c in e]]
def clean(s):return html.unescape(re.sub('<[^>]*>','',s))
D=Path('/private/tmp/pathwaymech-next-238-local-20261012/data/pathways/5-prime-deoxyadenosine-degradation-i.yaml');d=yaml.safe_load(D.read_text())
validate_record(d); assert not strict_errors([D],RT)
refs={r['id']:r for r in d['references']}
bindings=json.loads((A/'source-bindings.json').read_text())['sources']
byhash={x['original']['sha256']:Path(x['original']['path']) for x in bindings}
trees={}; objects={}; paths={}; native={}
for rid,ref in refs.items():
 p=byhash[ref['source_sha256']]; paths[rid]=p
 assert sha(p.read_bytes())==ref['source_sha256']
 if p.suffix=='.xml':
  trees[rid]=E.parse(str(p))
  if rid.startswith('MetaCyc:'):
   ent=trees[rid].getroot()[1]; assert ent.get('frameid')==rid.split(':',1)[1]; native[rid]=ent
   assert trees[rid].getroot().get('ptools-version')=='27.0'
 elif p.suffix=='.json':objects[rid]=json.loads(p.read_text())
assert len(refs)==42 and len(byhash)==40
# Entire selected native structures, including every direct slot, match retained preflight.
np=json.loads((P/'ledgers/native-complete-projection.json').read_text())['originals']; slots=[]
for row in np:
 ent=E.parse(row['source']['path']).getroot()[1]
 assert len(ent)==len(row['direct_slots'])==row['direct_slot_count']
 for i,(a,b) in enumerate(zip(ent,row['direct_slots']),1):
  assert i==b['ordinal'] and a.tag==b['name'] and shape(a)==shape(E.fromstring(b['xml'].encode()))
 slots.append({'id':row['id'],'direct_slots':len(ent),'structural_sha256':sha(json.dumps(shape(ent)).encode())})
assert len(slots)==22 and sum(x['direct_slots'] for x in slots)==328
save('native-slot-checks.json',slots)
# Read the complete RDF stream; preserve every repeated selected description.
rp=json.loads((P/'ledgers/rhea142-complete-projection.json').read_text())
ns={'rdf':'http://www.w3.org/1999/02/22-rdf-syntax-ns#','rh':'http://rdf.rhea-db.org/'}
about='{'+ns['rdf']+'}about'; resource='{'+ns['rdf']+'}resource'
selected={x['uri']:x['blocks'] for x in rp['descriptions']}; found=defaultdict(list)
with gzip.open(rp['source']['path'],'rb') as f:
 for _,e in E.iterparse(f,events=('end',),tag='{'+ns['rdf']+'}Description'):
  uri=e.get(about)
  if uri in selected:found[uri].append(E.fromstring(E.tostring(e)))
  e.clear()
  while e.getprevious() is not None:del e.getparent()[0]
assert set(found)==set(selected)
rt=E.Element('{'+ns['rdf']+'}RDF',nsmap=ns)
for uri,blocks in found.items():
 assert [shape(x) for x in blocks]==[shape(E.fromstring(x.encode())) for x in selected[uri]]
 for x in blocks:rt.append(x)
for rid in refs:
 if rid.startswith('RHEA:'):trees[rid]=E.ElementTree(rt)
def values(uri,pred):
 return [c.get(resource) or c.text for e in found[uri] for c in e if c.tag=='{'+ns['rh']+'}'+pred]
def resolve(rid,loc):
 if loc.startswith('$.'):
  value=objects[rid]
  for key,n in re.findall(r'([A-Za-z_][A-Za-z_0-9]*)|\[([0-9]+)\]',loc[2:]):value=value[key] if key else value[int(n)]
  assert value is not None; return {'matches':1,'value_sha256':sha(json.dumps(value,sort_keys=True).encode())}
 hits=trees[rid].xpath(loc,namespaces=ns);assert hits,(rid,loc)
 return {'matches':len(hits),'structural_sha256':[sha(json.dumps(shape(e)).encode()) for e in hits]}
locrows=[]
for edge in d['mechanistic_edges']:
 for context,evs in [('edge',edge['evidence'])]+[(f'qualifier_{i+1}',q['evidence']) for i,q in enumerate(edge.get('endpoint_qualifiers',[]))]:
  for e in evs:locrows.append({'edge':edge['id'],'context':context,**e,**resolve(e['reference_id'],e['source_locator'])})
assert len(locrows)==115
paragraphs=json.loads((A/'paragraph-ledger.json').read_text()); assert [p['text'] for p in paragraphs]==d['description'].strip().split('\n\n')
pl=[]
for para in paragraphs:
 for b in para['source_bindings']:pl.append({'paragraph':para['paragraph'],**b,**resolve(b['reference_id'],b['source_locator'])})
assert len(pl)==40
save('evidence-resolution.json',{'edge_and_qualifier':locrows,'paragraphs':pl})
# Named identities and exact mappings are checked from originals, never from label similarity.
nodes=[{'id':d['id'],'label':d['label']}]+sum([d[x] for x in ('taxa','participants','reactions')],[])
ids=[]
for n in nodes:
 rid=n['id'];kind=rid.split(':')[0]
 if kind=='CHEBI':
  o=objects[rid];assert o['chebi_accession']==rid and o['is_released'];assert clean(o['name'])==n['label']
 elif kind=='UniProtKB':
  o=objects[rid];assert o['primaryAccession']==rid.split(':')[1] and o['entryType']=='UniProtKB reviewed (Swiss-Prot)'
  assert o['proteinDescription']['recommendedName']['fullName']['value']==n['label']
 elif kind=='NCBITaxon':
  t=trees[rid];assert t.findtext('Taxon/TaxId')==rid.split(':')[1] and t.findtext('Taxon/ScientificName')==n['label']
 else:
  e=native[rid]
  if not rid.startswith('MetaCyc:RXN'):assert clean(e.findtext('common-name'))==n['label']
 ids.append({'id':rid,'label':n['label'],'category':n.get('category'),'original':str(paths[rid]),'identity':'passed'})
assert len(ids)==len({n['id'] for n in nodes})==20
save('identity-checks.json',ids)
chemical={};mappings=[]
for m in d['source_mappings']:
 a,b=m['subject_id'],m['object_id'];assert m['predicate_id']=='skos:exactMatch'
 if b.startswith('CHEBI:'):
  e=native[a];o=objects[b];inchi=e.findtext('inchi');assert inchi==o['default_structure']['standard_inchi']
  assert e.findtext('inchi-key').replace('InChIKey=','')==o['default_structure']['standard_inchi_key']
  chemical[b]=o['chemical_data'];mappings.append({'subject':a,'object':b,'support':'Complete InChI and InChIKey equality','inchi':inchi,'formula':chemical[b]['formula'],'charge':chemical[b]['charge']})
 else:
  u=a if a.startswith('UniProtKB:') else b;ch=b if a==u else a; o=objects[u];e=native[ch]
  assert o['primaryAccession'] in e.xpath('./dblink[dblink-db="UNIPROT"]/dblink-oid/text()')
  assert ch in [x['id'] for x in o['uniProtKBCrossReferences'] if x['database']=='BioCyc']
  gene='MetaCyc:'+e.find('gene')[0].get('frameid');g=native[gene]
  assert g.find('product')[0].get('frameid')==ch.split(':')[1]
  assert o['genes'][0]['geneName']['value']==g.findtext('common-name')
  locus=o['genes'][0]['orderedLocusNames'][0]['value'];assert locus in E.tostring(g,encoding='unicode')
  assert o['organism']['taxonId']==269796 and len(o['sequence']['value'])==o['sequence']['length']
  assert hashlib.md5(o['sequence']['value'].encode()).hexdigest().upper()==o['sequence']['md5']
  mappings.append({'subject':a,'object':b,'support':'Reciprocal native/UniProt, gene/product/locus and strain','locus':locus,'sequence_sha256':sha(o['sequence']['value'].encode())})
save('mapping-checks.json',mappings)
assert len(chemical)==7 and len(mappings)==10
assert objects['CHEBI:48828']['chemical_data']['charge']==objects['CHEBI:49786']['chemical_data']['charge']==2
# Compare all native sides and the graph independently to directional Rhea sides, including multiplicity.
edges=d['mechanistic_edges'];sidechecks=[];families=[24869,61296,61300]
native_to_current={m['subject_id']:m['object_id'] for m in d['source_mappings']}
for reaction,family in zip(d['reactions'],families):
 rid=reaction['id'];ent=native[rid]
 expectdir='left_to_right' if family==24869 else 'reversible'
 assert reaction['direction']==expectdir
 assert ent.findtext('reaction-direction')==('PHYSIOL-LEFT-TO-RIGHT' if family==24869 else 'REVERSIBLE')
 atoms=Counter();charge=0
 for side,pred,link,sign in [('left','consumes','substrates',-1),('right','produces','products',1)]:
  expected=Counter()
  for s in ent.findall(side):
   cid=native_to_current['MetaCyc:'+s[0].get('frameid')];coef=int(s.findtext('coefficient','1'));expected[cid]+=coef
   assert coef==1
   for atom,n in re.findall(r'([A-Z][a-z]?)([0-9]*)',chemical[cid]['formula']):atoms[atom]+=sign*int(n or 1)
   charge+=sign*chemical[cid]['charge']
  actual=Counter((e['subject'] if pred=='consumes' else e['object']) for e in edges if e['predicate']==pred and (e['object'] if pred=='consumes' else e['subject'])==rid)
  assert actual==expected
  su=values(ns['rh']+str(family+1),link);assert len(su)==1
  participants=values(su[0],'contains');assert Counter(participants)==Counter(values(su[0],'contains1'))
  rhea=Counter()
  for part in participants:
   compounds=values(part,'compound');assert len(compounds)==1
   chebi=values(compounds[0],'chebi');assert len(chebi)==1
   rhea['CHEBI:'+chebi[0].rsplit('_',1)[1]]+=1
  assert rhea==expected
  sidechecks.append({'reaction':rid,'side':side,'participants':dict(expected),'native_graph_rhea_exact':True})
 assert not any(atoms.values()) and charge==0
assert sum(sum(x['participants'].values()) for x in sidechecks)==9
save('reaction-checks.json',{'sides':sidechecks,'all_three_atom_and_charge_balances':True,'selected_rhea_subjects':len(found),'selected_rhea_blocks':sum(len(v) for v in found.values()),'whole_rdf_scanned':True})
# Assembly hierarchy retains direct stoichiometry and reciprocal membership without monomer catalysis.
for parent,child,coefficient in [('CPLX-8605','CPLX-8604',2),('CPLX-8604','MONOMER-17874',3)]:
 p=native['MetaCyc:'+parent];c=native['MetaCyc:'+child]
 assert len(p.findall('component'))==1 and p.find('component')[0].get('frameid')==child
 assert int(p.findtext('component/coefficient'))==coefficient
 assert c.find('component-of')[0].get('frameid')==parent
 assert len([e for e in edges if e['subject']=='MetaCyc:'+child and e['object']=='MetaCyc:'+parent and e['predicate']=='part_of'])==1
assert [(e['subject'],e['object']) for e in edges if e['predicate']=='catalyzes']==[('MetaCyc:CPLX-8605','MetaCyc:RXN-14304'),('UniProtKB:Q2RXI0','MetaCyc:RXN-21315'),('UniProtKB:Q2RXI1','MetaCyc:RXN-21316')]
assert len([e for e in edges if e['predicate']=='provides_input_for'])==2
assert len([q for e in edges for q in e.get('endpoint_qualifiers',[])])==5
for activity,substrate,km,kcat in [('29275','CH33ADO',40,6.7),('29274','CPD-15199',171,.18),('29276','CPD-23219',229,1.94)]:
 e=native['MetaCyc:ENZRXN-'+activity]
 for slot,num in [('km',km),('kcat',kcat)]:
  assert float(e.findtext(slot+'/value'))==num and e.find(slot+'/substrate')[0].get('frameid')==substrate
  assert e.find(slot+'/citation')[0].get('frameid')=='PUB-31950558'
# Check all ledger entries correspond exactly to the draft, with no dropped assertions.
assert [r['reference'] for r in json.loads((A/'reference-ledger.json').read_text())]==d['references']
assert [r['mapping'] for r in json.loads((A/'mapping-ledger.json').read_text())]==d['source_mappings']
for t in json.loads((A/'taxon-scope-ledger.json').read_text()):
 for eid in t['retained_on_edges']:
  e=next(e for e in edges if e['id']==eid)
  assert all(ev in e['evidence'] for ev in t['evidence'])
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'draft_sha256':sha(D.read_bytes()),'schema':'passed','strict_errors':[],'references':42,'whole_originals':40,'named_identities':20,'paragraphs':10,'paragraph_locators':40,'edges':21,'qualifiers':5,'edge_qualifier_locators':115,'mappings':10,'native_entities':22,'native_direct_slots':328,'rhea_subjects':len(found),'rhea_blocks':sum(len(v) for v in found.values()),'native_side_occurrences':9,'kinetic_slots':6,'assembly_direct_coefficients':[2,3],'result':'all bounded checks passed','native_builders_run':False}
save('audit-results.json',result);print(json.dumps(result))
