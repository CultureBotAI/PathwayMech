"""Align native review ID to the already recorded finished time; no judgment changes."""
import hashlib,json
from datetime import datetime
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
original=H/'completed-review-aliasfree.yaml';before=pin(original);obj=yaml.safe_load(original.read_text());old_id=obj['review_id']
finished=obj['finished_at'];assert isinstance(finished,str)
obj['review_id']=datetime.fromisoformat(finished.replace('Z','+00:00')).strftime('%Y%m%dT%H%M%SZ')+'-deoxy238-scientific'
assert obj['review_id']!=old_id
class NoAliasDumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
target=H/'completed-review-final.yaml'
with target.open('x') as f:f.write(yaml.dump(obj,Dumper=NoAliasDumper,allow_unicode=True,sort_keys=False,width=100))
expected=yaml.safe_load(original.read_text());expected['review_id']=obj['review_id'];assert yaml.safe_load(target.read_text())==expected
assert pin(original)==before
(H/'review-id-correction.json').write_text(json.dumps({'status':'native_review_id_only_successor','original':before,'successor':pin(target),'original_failure':pin(H/'native-validate-aliasfree-execution.json'),'old_id':old_id,'new_id':obj['review_id'],'finished_at_unchanged':finished,'reason':'Assembler independently read clock for finished_at and review_id across a one-second boundary. Native contract requires review_id prefix equal the finished UTC timestamp. Only review_id corrected.','all_judgments_timestamps_source_captures_and_evidence_unchanged':True,'original_preserved':True},indent=2)+'\n')
print('PASS: only review_id aligned to original finished_at')
