"""Persist exact external review-check executions; never write maintained inputs."""
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
H=Path(__file__).resolve().parent;P='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def now():return datetime.now(timezone.utc).isoformat()
name=sys.argv[1];helper=H/(name+'.py');argv=[P,'-B',str(helper)];inputs=[bind(helper),bind(__file__)];env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'}
start=now();tick=time.monotonic()
with (H/(name+'.stdout')).open('xb') as out,(H/(name+'.stderr')).open('xb') as err:code=subprocess.run(argv,cwd=H,env={**os.environ,**env},stdout=out,stderr=err,check=False).returncode
(H/(name+'-execution.json')).write_text(json.dumps({'started_at':start,'finished_at':now(),'seconds':time.monotonic()-tick,'argv':argv,'cwd':str(H),'environment':env,'exit_code':code,'inputs_at_start':inputs,'stdout':bind(H/(name+'.stdout')),'stderr':bind(H/(name+'.stderr'))},indent=2)+'\n')
print(name,code,flush=True);raise SystemExit(code)
