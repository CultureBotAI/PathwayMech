"""Execute the final proposal assembler with exact root seal arguments."""
import hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
H=Path(__file__).resolve().parent;P='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
Q=Path('/private/tmp/pathwaymech-next-238-root-maintained-qa-20261012')
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def now():return datetime.now(timezone.utc).isoformat()
argv=[P,'-B',str(H/'build_proposal.py'),str(Q/'handoff.json'),'83661b4c0b6deca94b171a824f3f723a2a666f8609e44550edd6c108015e4c89']
inputs=[pin(__file__),pin(H/'build_proposal.py'),pin(H/'root-qa-binding.json'),pin(Q/'handoff.json')]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1'};start=now();tick=time.monotonic()
with (H/'build-proposal.stdout').open('xb') as out,(H/'build-proposal.stderr').open('xb') as err:code=subprocess.run(argv,cwd=H,env={**os.environ,**env},stdout=out,stderr=err,check=False).returncode
(H/'build-proposal-execution.json').write_text(json.dumps({'started_at':start,'finished_at':now(),'seconds':time.monotonic()-tick,'argv':argv,'cwd':str(H),'environment':env,'exit_code':code,'inputs_at_start':inputs,'stdout':pin(H/'build-proposal.stdout'),'stderr':pin(H/'build-proposal.stderr')},indent=2)+'\n')
print('proposal',code);raise SystemExit(code)
