"""Fresh whole frozen-source closure and faithful reading aids; no authority builder."""
import hashlib,json,os
from datetime import datetime,timezone
from pathlib import Path
from lxml import etree as E
H=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-238-author-20261012');S=Path('/private/tmp/pathwaymech-next-238-science-review-20261012');LOCAL=Path('/private/tmp/pathwaymech-next-238-local-20261012')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'literal_link':os.readlink(p) if p.is_symlink() else None,'resolved_path':str(p.resolve())}
def check(d):
 b=bind(d['path']);assert all(b[k]==v for k,v in d.items() if k in b);return b
source=json.loads((A/'source-bindings.json').read_bytes())['sources'];rows=[];reads=[];(H/'reading').mkdir()
for i,row in enumerate(source,1):
 original=check(row['original']);receipts=[check(r['receipt']) for r in row.get('receipt_lineage',[])];p=Path(original['path'])
 rows.append({'original':original,'receipts':receipts,'lineage':row.get('receipt_lineage',[])})
 if p.suffix=='.xml':
  tree=E.parse(str(p));passages=tree.findall('.//passage')
  if passages:
   out=H/'reading'/(p.stem+'.passages.txt');out.write_text('\n\n'.join(f'PASSAGE {n}\n'+''.join(x.itertext()) for n,x in enumerate(passages,1)));reads.append({'original':original,'reading':bind(out),'whole_passages':len(passages)})
  elif p.name.startswith('META-'):
   out=H/'reading'/p.name;out.write_bytes(E.tostring(tree,encoding='utf-8',pretty_print=True));reads.append({'original':original,'reading':bind(out),'scope':'Complete original XML reserialized for legibility; whole original remains authority.'})
  else:
   out=H/'reading'/p.name;out.write_bytes(p.read_bytes());reads.append({'original':original,'reading':bind(out),'scope':'Complete taxonomy original'})
 elif p.suffix=='.json':
  obj=json.loads(p.read_bytes())
  if p.name.startswith('UniProt-'):
   keys=['entryType','primaryAccession','entryAudit','proteinDescription','organism','genes','comments','sequence','references','features','uniProtKBCrossReferences']
  else:keys=['chebi_accession','name','is_released','definition','chemical_data','default_structure','secondary_ids']
  selected={k:obj[k] for k in keys if k in obj};selected['other_original_keys_parsed']=sorted(set(obj)-set(selected))
  out=H/'reading'/(p.stem+'.reading.json');out.write_text(json.dumps(selected,indent=2,ensure_ascii=False)+'\n');reads.append({'original':original,'reading':bind(out),'scope':'Scientific/identity fields from whole parsed JSON; unrelated fields not claimed freshly read.'})
assert len(rows)==40
(H/'whole-source-closure.json').write_text(json.dumps({'at':datetime.now(timezone.utc).isoformat(),'sources':rows,'whole_original_count':40,'unique_receipts':len({r['path'] for row in rows for r in row['receipts']}),'fresh_hashes':True,'readings':reads,'complete_sources_interpreted':False},indent=2)+'\n')
old=S/'audit.py';code=old.read_text().replace("R=Path('/private/tmp/pathwaymech-next-238-science-review-20261012')",f"R=Path('{H}')").replace("RT=Path('/private/tmp/pathwaymech-next-236-canonical-preparation-20261012/runtime')",f"RT=Path('{LOCAL}')").replace("D=A/'draft/5-prime-deoxyadenosine-degradation-i.yaml'",f"D=Path('{LOCAL}/data/pathways/5-prime-deoxyadenosine-degradation-i.yaml')")
(H/'audit.py').write_text(code)
(H/'audit-lineage.json').write_text(json.dumps({'inherited_helper':bind(old),'current_helper':bind(H/'audit.py'),'delta':'Output root and exact maintained target/runtime paths only; source ledger remains exact accepted scientific author. Independent biological judgment is separate from reused deterministic consistency methods.','native_builders':False},indent=2)+'\n')
print(json.dumps({'whole_originals':40,'readings':len(reads),'source_closure':bind(H/'whole-source-closure.json'),'reused_audit':bind(H/'audit.py')}))
