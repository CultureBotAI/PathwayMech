"""Seal completed native execution evidence without rerunning any gate."""
import datetime
import hashlib
import json
import os
import re
from pathlib import Path

OUT = Path('/private/tmp/pathwaymech-next-238-local-native-execution-20261012')
ROOT = Path('/private/tmp/pathwaymech-next-238-local-20261012')
PREP = Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012')
RUNNER = Path('/private/tmp/pathwaymech-next-238-root-run-native-20261012.py')
PHASES = ('history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates')

def pin(p):
    assert p.is_file() and not p.is_symlink(), p
    body = p.read_bytes()
    return {'path': str(p), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write(p, value):
    with p.open('x') as s:
        json.dump(value, s, indent=2)
        s.write('\n')

def main():
    assert pin(RUNNER)['sha256'] == 'd2e399e6535c205c87a95e2dae4e0d0e9d92e526d9d6f1c205303e408626e4bf'
    summary = []
    all_receipts = []
    completion_pins = []
    for phase in PHASES:
        folder = OUT / phase
        completion = json.loads((folder / 'completion.json').read_bytes())
        assert completion['status'] == 'phase_passed' and completion['phase'] == phase
        assert completion['runner'] == pin(RUNNER)
        assert completion['stage_plan'] == pin(PREP / 'stages.json')
        assert pin(Path(completion['phase_start']['path'])) == completion['phase_start']
        assert (folder / 'runner-at-start.py').read_bytes() == RUNNER.read_bytes()
        for receipt, origin in zip(completion['receipts'], completion['receipt_origins'], strict=True):
            assert receipt['exit_code'] == 0 and receipt['runner_at_start'] == pin(RUNNER)
            assert receipt['phase_start'] == completion['phase_start']
            assert pin(Path(origin['path'])) == origin
            assert json.loads(Path(origin['path']).read_bytes()) == receipt
            for stream in ('stdout', 'stderr'):
                assert pin(Path(receipt[stream]['path'])) == receipt[stream]
            summary.append({key: receipt[key] for key in ('name', 'started_at', 'finished_at', 'seconds', 'exit_code')})
            all_receipts.append(receipt)
        completion_pins.append(pin(folder / 'completion.json'))
    assert [row['name'] for row in summary] == ['history-1', 'history-2', 'sssom', 'render', 'skills', 'validate', 'tests', 'lint', 'kgx', 'vendored', 'diff-check', 'site-current']
    for first, second in zip(summary, summary[1:], strict=False):
        assert datetime.datetime.fromisoformat(first['finished_at']) <= datetime.datetime.fromisoformat(second['started_at'])
    histories = []
    for receipt in all_receipts[:2]:
        relative = Path(receipt['stdout']['path']).read_text().strip()
        assert relative.startswith('history/') and relative.endswith('.yaml')
        histories.append(pin(ROOT / relative))
    sssom = json.loads((OUT / 'history-and-generation/sssom-preservation.json').read_bytes())
    assert sssom['old_row_relative_order_exact'] is True
    assert sssom['actual'] == pin(ROOT / 'output/sssom/source_mappings.sssom.tsv')
    assert (sssom['old_rows'], sssom['added_rows'], sssom['total_rows']) == (32, 10, 42)
    tests_body = (OUT / 'remaining-offline-gates/tests.stdout').read_text()
    test_summaries = [line for line in tests_body.splitlines() if re.search(r'\d+ passed', line)]
    assert len(test_summaries) == 1 and 'failed' not in test_summaries[0]
    histories_receipt = json.loads((OUT / 'history-and-generation/histories-before-generation.json').read_bytes())
    assert histories_receipt['old_histories'] == 404 and histories_receipt['total_histories'] == 406
    assert histories_receipt['old_whole_history_bytes_exact'] is True
    assert sorted(histories_receipt['new_histories'], key=lambda r:r['path']) == sorted(histories,key=lambda r:r['path'])
    wrappers = OUT / 'outer-tool-streams'
    wrappers.mkdir()
    wrapper_bindings = []
    for phase in PHASES:
        source_root = Path('/private/tmp/pathwaymech-next-238-native-phase-execution-20261012') / phase
        invocation = json.loads((source_root / 'execution.json').read_bytes())
        assert invocation['exit_code'] == 0 and invocation['helper_at_start'] == pin(RUNNER)
        assert invocation['argv'] == ['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python', '-B', str(RUNNER), phase]
        assert (source_root / 'helper-at-start.py').read_bytes() == RUNNER.read_bytes()
        assert pin(Path(invocation['runner']['path'])) == invocation['runner']
        for stream in ['stdout','stderr']:
            assert pin(source_root / stream) == invocation[stream]
        destination_root = wrappers / phase
        destination_root.mkdir()
        for name in ['execution.json','helper-at-start.py','stdout','stderr']:
            source = source_root / name
            destination = destination_root / name
            destination.write_bytes(source.read_bytes())
            wrapper_bindings.append({'source':pin(source),'retained':pin(destination)})
    wrapper = Path('/private/tmp/pathwaymech-next-238-run-local-step-20261012.py')
    (wrappers / 'capture-wrapper.py').write_bytes(wrapper.read_bytes())
    provenance_source = Path('/private/tmp/pathwaymech-next-238-native-tool-provenance-20261012.json')
    provenance = json.loads(provenance_source.read_bytes())
    assert len(provenance['phase_invocations']) == 4
    assert all(x['exit_code'] == 0 for x in provenance['phase_invocations'])
    (OUT / 'actual-tool-provenance.json').write_bytes(provenance_source.read_bytes())
    (OUT / 'sealing-helper.py').write_bytes(Path(__file__).read_bytes())
    copied = OUT / 'input-receipts'
    copied.mkdir()
    bindings = []
    for name, source in [
        ('runner-preparation-handoff.json', Path('/private/tmp/pathwaymech-next-238-native-runner-preparation-20261012/handoff.json')),
        ('root-acceptance.json', Path('/private/tmp/pathwaymech-next-238-root-local-integration-acceptance-20261012.json')),
        ('root-native-execution-acceptance.json', Path('/private/tmp/pathwaymech-next-238-root-native-execution-acceptance-20261012.json')),
        ('adoption.json', Path('/private/tmp/pathwaymech-next-238-local-adoption-20261012/receipt.json')),
        ('stages.json', PREP / 'stages.json'),
    ]:
        destination = copied / name
        destination.write_bytes(source.read_bytes())
        bindings.append({'source': pin(source), 'retained': pin(destination)})
    result = {
        'status': 'all_four_phases_and_nine_native_gates_passed',
        'sealed_at': datetime.datetime.now(datetime.UTC).isoformat(),
        'runner': pin(RUNNER), 'completions': completion_pins, 'commands': summary,
        'tests_summary': test_summaries[0], 'histories': histories, 'SSSOM': sssom,
        'input_bindings': bindings, 'outer_wrapper_bindings': wrapper_bindings,
        'histories_before_generation': histories_receipt,
        'outputs': [pin(ROOT / relative) for relative in ['data/pathways/5-prime-deoxyadenosine-degradation-i.yaml', 'pages/records/MetaCyc_PWY-8130.html', 'output/kgx/nodes.tsv', 'output/kgx/edges.tsv']],
        'fresh_command_receipts_and_streams_exact': True,
        'history_before_SSSOM_and_render': True,
        'native_review_save_performed': False, 'git_commit_performed': False,
        'publication_performed': False, 'whole_checkout_QA_pending_separate_owner': True,
    }
    write(OUT / 'execution-summary.json', result)
    lines = ['The exact authorized 238 native stages completed successfully in four explicit phases. All nine gates and both history commands passed. The two histories were created before SSSOM and rendering; the SSSOM output retains all 32 prior rows, exact cells/header/multiplicity and relative order and adds the ten accepted mappings (42 total rows). Its whole bytes change as expected.', '', test_summaries[0], '', 'Actual commands, start/end times, durations, helper bodies and stdout/stderr are retained. Fresh final evidence checks compare every execution receipt to its first-created origin hash and every stream to its recorded bytes. The exact acceptance/adoption/stages and runner preparation are bound, and outer tool invocation provenance is recorded separately. No gate is rerun by this seal.', '', 'This is execution evidence, not an independent maintained scientific or technical review. Whole checkout/cache and complete target interpretation belong to the separate actual maintained QA. No native review was authored or saved, no commit was created, and no public action occurred in this stage. Scientific evidence coverage remains inherited from the accepted scientific and actual-output reviews; no fresh whole-primary-paper reading is claimed here.', '', 'See actual-tool-provenance.json for any execution or inspection limitations and original failures. Native source and evidence bytes were not normalized. The prepared runner passed lint and all seven isolated mapping controls; its provisional approval constant was replaced only after root acceptance. Separate integration-preparation formatting diagnostics remain retained in that earlier packet.', '']
    (OUT / 'REPORT.md').write_text('\n'.join(lines))
    rows = []
    directories = []
    for current, dirs, files in os.walk(OUT, followlinks=False):
        for name in dirs:
            p = Path(current) / name
            assert not p.is_symlink()
            directories.append(str(p.relative_to(OUT)))
        for name in files:
            p = Path(current) / name
            assert name not in ('artifact-manifest.json', 'handoff.json')
            row = pin(p); row['relative_path'] = str(p.relative_to(OUT)); row['kind'] = 'regular_file'
            rows.append(row)
    rows.sort(key=lambda row: row['relative_path'])
    write(OUT / 'artifact-manifest.json', {'files': rows, 'directories': sorted(directories), 'walk': 'literal os.walk, ignored/hidden included, symlinks rejected'})
    write(OUT / 'handoff.json', {'status': result['status'], 'runner': pin(RUNNER), 'manifest': pin(OUT / 'artifact-manifest.json'), 'summary': pin(OUT / 'execution-summary.json'), 'artifacts': len(rows), 'directories': len(directories), 'native_review_and_commit_pending': True, 'publication_performed': False})
    print(json.dumps({'handoff': pin(OUT / 'handoff.json'), 'manifest': pin(OUT / 'artifact-manifest.json'), 'summary': pin(OUT / 'execution-summary.json'), 'tests': test_summaries[0], 'artifacts': len(rows)}, indent=2))

if __name__ == '__main__':
    main()
