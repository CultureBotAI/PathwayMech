"""Copy the sealed actual native packet unchanged into external review evidence."""
import hashlib,json,os,shutil,stat
from pathlib import Path
H=Path(__file__).resolve().parent;S=Path('/private/tmp/pathwaymech-next-238-local-native-execution-20261012');D=H/'actual-native'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert pin(S/'handoff.json')['sha256']=='8fb12b32116623085696f23943a74599bb0d50f269a91edc0a19d394cad7c2d8'
assert pin(S/'artifact-manifest.json')['sha256']=='15e471d4288233064e849d422ae05e1195eef35e524a8a38b37260ca7a283da2'
expected={x['relative_path']:x for x in json.loads((S/'artifact-manifest.json').read_text())['files']}
for n in ['handoff.json','artifact-manifest.json']:expected[n]=pin(S/n)
D.mkdir();bindings=[];dirs=[]
for base,ds,fs in os.walk(S,followlinks=False):
 for n in ds:
  p=Path(base)/n;assert stat.S_ISDIR(p.lstat().st_mode);rel=p.relative_to(S);(D/rel).mkdir();dirs.append(str(rel))
 for n in fs:
  p=Path(base)/n;assert stat.S_ISREG(p.lstat().st_mode);rel=p.relative_to(S);before=pin(p);e=expected[str(rel)];assert (before['sha256'],before['bytes'])==(e['sha256'],e['bytes']);dst=D/rel;shutil.copyfile(p,dst);after=pin(p);q=pin(dst);assert before==after and (q['sha256'],q['bytes'])==(before['sha256'],before['bytes']);bindings.append({'relative_path':str(rel),'source_at_copy_start_and_finish':before,'destination':q})
assert len(bindings)==len(expected)==78
(H/'native-evidence-copy-bindings.json').write_text(json.dumps({'status':'whole_bodies_copied_byte_exact','original_packet_entries':76,'original_seals':2,'directories':dirs,'bindings':bindings,'receipt_body_rebasing':False,'source_absolute_paths_inside_original_receipts':'Retained exactly as original execution provenance. Durable copy locations are separately mapped here.'},indent=2)+'\n');print('PASS: all76+2 native bodies retained byte-exact in external actual-native/')
