"""Retain actual native238 finalization evidence and verify full current scope."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,subprocess,sys
import yaml
PREP=Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012');sys.path.insert(0,str(PREP));import common as c
R=c.ROOT;REL=Path(c.DOSSIER)/'native-integration/finalization';D=R/REL;OUT=Path('/private/tmp/pathwaymech-next-238-finalization-preservation-20261012')
assert c.load('/private/tmp/pathwaymech-next-238-native-review-save-20261012/completion.json')['status']=='all_native_review_save_and_checks_passed'
assert not D.exists() and not OUT.exists();c.git_check(clean=False);assert not c.git('diff','--cached','--name-only')
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for source,sub in [(Path('/private/tmp/pathwaymech-next-238-root-native-finalized-20261012'),'native-inputs'),(Path('/private/tmp/pathwaymech-next-238-native-finalization-execution-20261012'),'finalize-execution'),(Path('/private/tmp/pathwaymech-next-238-native-review-save-20261012'),'save-and-check'),(Path('/private/tmp/pathwaymech-next-238-native-review-save-execution-20261012'),'save-wrapper'),(Path('/private/tmp/pathwaymech-next-238-evidence-adoption-execution-20261012'),'evidence-adoption-execution'),(Path('/private/tmp/pathwaymech-next-238-evidence-adoption-20261012'),'evidence-adoption'),(Path('/private/tmp/pathwaymech-next-238-finalization-execution-inputs-20261012'),'original-execution-inputs')]:
 for base,dirs,files in os.walk(source,followlinks=False):
  assert all(not (Path(base)/n).is_symlink() for n in dirs)
  for n in files:
   p=Path(base)/n;rows.append((p,Path(sub)/p.relative_to(source)))
for name in ['adopt-final-evidence','save-native-reviews','adopt-finalization','run-local-step']:
 p=Path('/private/tmp/pathwaymech-next-238-'+name+'-20261012.py');rows.append((p,Path(name+'.py')))
entries=[];payload=[]
for p,rel in rows:
 b=c.regular_bytes(p);enc=p.suffix in ['.py','.yaml','.stdout','.stderr'] or p.name in ['stdout','stderr'];stored=gzip.compress(b,mtime=0) if enc else b
 if enc:assert gzip.decompress(stored)==b
 dest=Path(str(rel)+'.gz') if enc else rel;payload.append((D/dest,stored));entries.append({'source':str(p),'owner':str(REL/dest),'encoding':'gzip' if enc else 'identity','original':pin(b),'stored':pin(stored)})
assert len({p for p,b in payload})==len(payload)
map_body=(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual native input inspection/validation, two immutable saves, append-only review check, lint and unstaged diff-check. Both original reviewers and all judgments unchanged. These later execution receipts are provenance, not silently appended saved source inputs. No publication.','entries':entries},indent=2)+'\n').encode();payload.append((D/'storage-map.json',map_body))
before,dirs_before=c.inventory(R,exclude_git=True);old={r['path']:r for r in before};OUT.mkdir()
for p,b in payload:
 assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 assert c.regular_bytes(p)==b
new,dirs_after=c.inventory(R,exclude_git=True);by={r['path']:r for r in new};added={p.relative_to(R).as_posix() for p,b in payload};assert set(by)==set(old)|added
for p,row in old.items():assert by[p]==row
expected_dirs=set(dirs_before)
for p in added:expected_dirs.update(str(x) for x in Path(p).parents if str(x)!='.')
assert set(dirs_after)==expected_dirs
inputs={};saved=[]
for rid in c.load('/private/tmp/pathwaymech-next-238-native-review-save-20261012/completion.json')['review_ids']:
 path=R/'reviews/structured'/rid/'review.yaml';doc=yaml.safe_load(c.regular_bytes(path))
 for row in doc['source']['inputs']:
  assert c.pin(R/row['path'])['sha256']==row['sha256']
  inputs.setdefault(row['path'],row['sha256']);assert inputs[row['path']]==row['sha256']
 saved.append({'review_id':rid,'yaml':c.pin(path),'markdown':c.pin(path.with_name('review.md')),'native_inputs':len(doc['source']['inputs']),'findings':len(doc['findings']),'verdict':doc['verdict']})
c.cache_check()
baseline={r['path']:r for r in c.load(PREP/'baseline-files.json')};assert set(baseline)<=set(by)
changes=[{'path':p,'before':baseline.get(p),'after':r} for p,r in sorted(by.items()) if baseline.get(p)!=r]
def git_paths(args):
 return set(filter(None,subprocess.check_output(['git',*args],cwd=R).decode().split('\0')))
visible=git_paths(['diff','--name-only','-z'])|git_paths(['ls-files','--others','--exclude-standard','-z'])
assert visible=={r['path'] for r in changes}, {'physical_not_visible':sorted({r['path'] for r in changes}-visible),'visible_not_physical':sorted(visible-{r['path'] for r in changes})}
assert all(r['after']['type']=='regular' for r in changes)
c.write_new(OUT/'git-inputs.json',[r['after'] for r in changes])
(OUT/'pathspec.nul').write_bytes(b''.join(r['path'].encode()+b'\0' for r in changes))
c.write_new(OUT/'changed-files.json',{'base':c.BASE,'scope':'All physical changes including hidden/ignored files, excluding Git administration; not a staged inventory.','files':changes})
c.write_new(OUT/'native-inputs.json',{'base':c.BASE,'inputs':[{'path':p,'sha256':v} for p,v in sorted(inputs.items())],'all_exact':True})
c.write_new(OUT/'receipt.json',{'status':'actual_native_finalization_evidence_adopted_and_complete_preservation_passed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':c.pin(Path(__file__)),'receipt_owners':len(payload),'receipt_stored_bytes':sum(len(b) for p,b in payload),'storage_map':c.pin(D/'storage-map.json'),'physical_files':len(new),'physical_directories':len(dirs_after),'all_preexisting_owners_exact':True,'cache_entries_exact':800,'saved_reviews':saved,'unique_saved_native_inputs':len(inputs),'changed_files':len(changes),'changed_stored_bytes':sum(r['after'].get('bytes',0) for r in changes),'changed_inventory':c.pin(OUT/'changed-files.json'),'git_inputs':c.pin(OUT/'git-inputs.json'),'pathspec':c.pin(OUT/'pathspec.nul'),'all_physical_changes_equal_visible_git_candidates':True,'native_inputs':c.pin(OUT/'native-inputs.json'),'staging_performed':False,'commit_performed':False,'publication_authorized':False})
print(json.dumps(c.load(OUT/'receipt.json')))
