"""Exact approved238 evidence adoption; whole source fidelity and no review save."""
import argparse,datetime,gzip,hashlib,io,json,os,sys,zipfile
from pathlib import Path
import yaml

P=Path('/private/tmp/pathwaymech-next-238-finalization-preparation-20261012')
S=Path('/private/tmp/pathwaymech-next-238-finalization-storage-preparation-20261012')
PREP=Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012')
OUT=Path('/private/tmp/pathwaymech-next-238-evidence-adoption-20261012')
DRAFT=Path('/private/tmp/pathwaymech-next-238-finalization-execution-inputs-20261012')
sys.path.insert(0,str(PREP));import common as c
R=c.ROOT;PREFIX=c.DOSSIER+'/native-integration'
parser=argparse.ArgumentParser();parser.add_argument('--storage-acceptance',type=Path,required=True);parser.add_argument('--storage-acceptance-sha256',required=True);a=parser.parse_args()

def sha(b):return hashlib.sha256(b).hexdigest()
def data_pin(b):return {'bytes':len(b),'sha256':sha(b)}
def pin(p):return c.pin(p)
def close(root,hsha):
 assert pin(root/'handoff.json')['sha256']==hsha
 h=c.load(root/'handoff.json');c.verify(h['manifest'],root/'artifact-manifest.json');m=c.load(root/'artifact-manifest.json');rows=m['artifacts'] if 'artifacts' in m else m['files']
 expected=set()
 for row in rows:
  rel=row.get('relative_path') or str(Path(row['path']).relative_to(root));c.relative(rel);assert rel not in expected;expected.add(rel);c.verify(row,root/rel)
 actual,dirs=c.inventory(root);assert all(row['type']=='regular' for row in actual);assert {row['path'] for row in actual}==expected|{'handoff.json','artifact-manifest.json'}
 if 'directories' in m:assert set(dirs)==set(m['directories'])-{'.'}
 return actual

def archive(root,files):
 out=io.BytesIO()
 with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_STORED) as z:
  for rel in sorted(files):
   body=c.regular_bytes(root/rel);info=zipfile.ZipInfo(rel,(2026,10,12,0,0,0));info.external_attr=0o100644<<16;z.writestr(info,body)
 body=out.getvalue()
 with zipfile.ZipFile(io.BytesIO(body)) as z:
  assert set(z.namelist())==set(files)
  for rel in files:assert z.read(rel)==c.regular_bytes(root/rel)
 return body

initial=Path('/private/tmp/pathwaymech-next-238-root-maintained-review-acceptance-20261012.json')
assert pin(initial)['sha256']=='34328d4d725b30706154ffb75f9401a4bb4c972b819fc063dd9b9753f25e6e3a'
assert pin(a.storage_acceptance)['sha256']==a.storage_acceptance_sha256
approval=c.load(a.storage_acceptance)
# The root supplies the exact trusted digest in the executed argv. Bind the literal
# approved storage packet into its receipt; no filename/elapsed-time approval.
assert 'f0b20862bbc389ddf965e496322c7cc4db8393acea3a6e74bdd455965c099f6c' in json.dumps(approval)
pfiles=close(P,'e6bc58f19243c4a87a82f8d6e46db3cfab928b7d4d93a6e8cef01b51fcd4107f')
sfiles=close(S,'f0b20862bbc389ddf965e496322c7cc4db8393acea3a6e74bdd455965c099f6c')
for item in c.load(P/'input-bindings.json').values():
 if isinstance(item,dict) and 'root' in item and 'handoff' in item:close(Path(item['root']),item['handoff']['sha256'])
c.git_check(clean=False);assert not c.git('diff','--cached','--name-only');assert not OUT.exists() and not DRAFT.exists()
# Full prewrite physical preservation, using the exact accepted owner and generated sets.
before,dirs_before=c.inventory(R,exclude_git=True);by={x['path']:x for x in before};baseline={x['path']:x for x in c.load(PREP/'baseline-files.json')}
adopted={x['destination']:x for x in c.load(PREP/'plan.json')['changes']};generated=set(c.load(PREP/'stages.json')['allowed_generated_paths'])
histories={x for x in by if x.startswith('history/') and x.endswith('.yaml') and x not in baseline}
assert len(histories)==2 and set(by)==set(baseline)|set(adopted)|generated|histories
for rel,row in baseline.items():
 if rel not in adopted and rel not in generated:assert by[rel]==row
for rel,row in adopted.items():assert (by[rel]['bytes'],by[rel]['sha256'])==(row['payload']['bytes'],row['payload']['sha256'])
c.cache_check()
for row in c.load(PREP/'runtime-owner-map.json')['runtime']:c.verify(row['effective_integration'],R/row['relative_path'])
for kind in ['scientific','technical']:
 doc=yaml.safe_load(c.regular_bytes(P/(kind+'-review.yaml')))
 assert doc['source']['git_revision']==c.BASE and doc['source']['state']=='working_tree'
 for row in doc['source']['inputs']:assert pin(R/row['path'])['sha256']==row['sha256']
 assert not (R/'reviews/structured'/doc['review_id']).exists()

plan=c.load(S/'copy-plan.json');ledger=c.load(S/'storage-ledger.json');led={r['stored_repository_path']:r for r in ledger['entries']};payload={};entries=[]
for row in plan['files']:
 body=c.regular_bytes(row['source']);assert data_pin(body)=={'bytes':row['bytes'],'sha256':row['sha256']}
 orig=led[row['repository_path']];decoded=gzip.decompress(body) if row['encoding']=='gzip' else body
 assert data_pin(decoded)=={k:orig['original_source'][k] for k in ['bytes','sha256']}
 assert decoded==c.regular_bytes(orig['original_source']['path'])
 payload[row['repository_path']]=(body,row['executable']);entries.append(dict(row))
assert len(payload)==301 and sum(r['encoding']=='gzip' for r in plan['files'])==45
# Verify both complete original manifests using the decoded proposed owners.
for prefix in ['root-review','independent-qa']:
 group={r['original_repository_path'].split('/'+prefix+'/',1)[1]:r for r in ledger['entries'] if '/'+prefix+'/' in r['original_repository_path']}
 def decoded_original(rel):
  e=group[rel];b=payload[e['stored_repository_path']][0];return gzip.decompress(b) if e['encoding']=='gzip' else b
 m=json.loads(decoded_original('artifact-manifest.json'));expected={'handoff.json','artifact-manifest.json'};srcroot=Path(group['handoff.json']['original_source']['path']).parent
 for row in (m['artifacts'] if 'artifacts' in m else m['files']):
  rel=row.get('relative_path') or str(Path(row['path']).relative_to(srcroot));expected.add(rel);assert data_pin(decoded_original(rel))=={k:row[k] for k in ['bytes','sha256']}
 assert expected==set(group)

def extra(name,body,source):
 rel=PREFIX+'/'+name;assert rel not in payload;payload[rel]=(body,False);entries.append({'repository_path':rel,**data_pin(body),'encoding':'identity','source':source,'executable':False})
extra('maintained-review-acceptance.json',c.regular_bytes(initial),str(initial))
extra('storage-acceptance.json',c.regular_bytes(a.storage_acceptance),str(a.storage_acceptance))
extra('storage-ledger.json',c.regular_bytes(S/'storage-ledger.json'),str(S/'storage-ledger.json'))
extra('finalization-plan.zip',archive(P,[r['path'] for r in pfiles]),'Complete sealed original finalization preparation29+2')
extra('storage-preparation.zip',archive(S,[r['path'] for r in sfiles]),'Complete sealed storage successor50+2')
F=Path('/private/tmp/pathwaymech-next-238-finalization-evidence-lint-preflight-20261012');ff,fd=c.inventory(F);assert not fd and all(r['type']=='regular' for r in ff)
# Preflight archive includes original raw streams, scope, summary and its exact helper.
fbuf=io.BytesIO()
with zipfile.ZipFile(fbuf,'w',compression=zipfile.ZIP_STORED) as z:
 for row in ff:z.writestr(row['path'],c.regular_bytes(F/row['path']))
 z.writestr('preflight-helper.py',c.regular_bytes('/private/tmp/pathwaymech-next-238-finalization-evidence-lint-preflight-20261012.py'))
extra('evidence-lint-preflight.zip',fbuf.getvalue(),'Whole original failed preflight plus original helper')
readme=b'Exact238 native-review evidence. root-review and independent-qa retain whole original packets; exactly45 audit Python bodies are represented as deterministic lossless .py.gz. storage-ledger.json maps original path/hash/mode and stored owner/hash; decode before checking original packet manifests. All directly cited JSON bodies remain byte-exact at their original evidence paths. Both approval receipts, complete original finalization/storage packets and failed Ruff preflight are retained. These are historical observations: no new scientific reading, source normalization, publication or licensing clearance is asserted.\n'
extra('README.md',readme,'Derived storage explanation')
map_body=(json.dumps({'status':'all_original_evidence_losslessly_adopted','entries':entries,'original_packet_reconstruction_passed':True,'direct_evidence_json_identity':57,'initial_acceptance':pin(initial),'storage_acceptance':pin(a.storage_acceptance),'original_native_inputs_reassessed':'All descriptors and bodies remain unchanged; additions are complete exact copied evidence only.'},indent=2)+'\n').encode()
extra('root-storage-map.json',map_body,'Derived complete storage map; map itself listed in execution copy-plan')
assert len(payload)==len(entries)==309
for rel in payload:
 c.relative(rel);target=R/rel;assert not target.exists() and not target.is_symlink()
 for parent in target.parents:
  if parent==R:break
  assert not parent.is_symlink()
OUT.mkdir();DRAFT.mkdir()
c.write_new(OUT/'prewrite.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':pin(Path(__file__)),'approval':pin(a.storage_acceptance),'before_files':len(before),'before_directories':len(dirs_before),'cache_entries':800,'proposed_owners':len(entries),'all_original_native_inputs_exact':True})
# All bodies were read/checked before the first maintained write.
for rel,(body,executable) in payload.items():
 dest=R/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as stream:stream.write(body)
 dest.chmod(0o755 if executable else 0o644)
 assert c.regular_bytes(dest)==body
for kind in ['scientific','technical']:
 with (DRAFT/(kind+'-review.yaml')).open('xb') as stream:stream.write(c.regular_bytes(P/(kind+'-review.yaml')))
c.write_new(DRAFT/'copy-plan.json',{'durable_root':PREFIX,'files':entries,'static_plan':pin(P/'copy-plan.json'),'storage_plan':pin(S/'copy-plan.json'),'approved_storage':pin(a.storage_acceptance),'whole_originals_reconstructed_and_reassessed':True})
after,dirs_after=c.inventory(R,exclude_git=True);after_by={r['path']:r for r in after};assert set(after_by)==set(by)|set(payload)
for rel,row in by.items():assert after_by[rel]==row
expected_dirs=set(dirs_before)
for rel in payload:expected_dirs.update(str(p) for p in Path(rel).parents if str(p)!='.')
assert set(dirs_after)==expected_dirs
c.cache_check()
for r in c.load(P/'evidence-reference-bindings.json'):
 if r.get('whole_body_identity_copy'):assert pin(R/r['reference'])['sha256']==r['sha256']
c.write_new(OUT/'receipt.json',{'status':'exact_evidence_adoption_and_whole_copy_reassessment_passed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':pin(Path(__file__)),'owners':len(entries),'stored_bytes':sum(r['bytes'] for r in entries),'qa_originals':301,'gzip_originals':45,'all_preexisting_owners_exact':True,'cache_entries_exact':800,'after_files':len(after),'after_directories':len(dirs_after),'execution_copy_plan':pin(DRAFT/'copy-plan.json'),'scientific_review':pin(DRAFT/'scientific-review.yaml'),'technical_review':pin(DRAFT/'technical-review.yaml'),'native_review_saved':False,'publication_authorized':False})
print(json.dumps(c.load(OUT/'receipt.json')))
