"""Save exactly the two approved native238 reviews and verify narrow scope."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
import yaml
PREP=Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012');sys.path.insert(0,str(PREP));import common as c
ROOT=c.ROOT;DRAFT=Path('/private/tmp/pathwaymech-next-238-finalization-execution-inputs-20261012');FINAL=Path('/private/tmp/pathwaymech-next-238-root-native-finalized-20261012');OUT=Path('/private/tmp/pathwaymech-next-238-native-review-save-20261012')
PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python';ENV={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(ROOT/'src')+':'+str(ROOT)}
for p,digest in [('/private/tmp/pathwaymech-next-238-root-maintained-review-acceptance-20261012.json','34328d4d725b30706154ffb75f9401a4bb4c972b819fc063dd9b9753f25e6e3a'),('/private/tmp/pathwaymech-next-238-root-review-storage-acceptance-20261012.json','07035b7863cd109238eeb0feb3c90be3cc68a69d05fe119202f4913d73bfeac9')]:assert c.pin(p)['sha256']==digest
assert c.load('/private/tmp/pathwaymech-next-238-evidence-adoption-20261012/receipt.json')['status']=='exact_evidence_adoption_and_whole_copy_reassessment_passed'
assert c.load(FINAL/'completion.json')['status']=='fresh_native_inputs_extended_and_validated'
c.git_check(clean=False);assert not c.git('diff','--cached','--name-only')
commands=[];ids=[]
for kind in ['scientific','technical']:
 before=yaml.safe_load(c.regular_bytes(DRAFT/(kind+'-review.yaml')));after=yaml.safe_load(c.regular_bytes(FINAL/(kind+'-review.yaml')))
 assert {k:v for k,v in before.items() if k!='source'}=={k:v for k,v in after.items() if k!='source'}
 assert {k:v for k,v in before['source'].items() if k!='inputs'}=={k:v for k,v in after['source'].items() if k!='inputs'}
 assert after['source']['git_revision']==c.BASE and after['source']['state']=='working_tree'
 old={r['path']:r for r in before['source']['inputs']};new={r['path']:r for r in after['source']['inputs']};assert all(new[p]==r for p,r in old.items())
 for row in after['source']['inputs']:assert c.pin(ROOT/row['path'])['sha256']==row['sha256']
 assert not (ROOT/'reviews/structured'/after['review_id']).exists();ids.append(after['review_id'])
 commands.append((kind+'-save',[PY,'-B','scripts/record_review.py','save','--content',str(FINAL/(kind+'-review.yaml'))]))
commands += [('review-check',[PY,'-B','scripts/record_review.py','check','--require-reviews','--base',c.BASE]),('lint',[PY,'-B','-m','ruff','check','--no-cache','.']),('diff-check',['git','diff','--check'])]
before,dirs_before=c.inventory(ROOT,exclude_git=True);oldmap={r['path']:r for r in before}
OUT.mkdir();results=[]
for name,argv in commands:
 v={'name':name,'argv':argv,'cwd':str(ROOT),'environment':ENV,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'helper':c.pin(Path(__file__))};t=time.monotonic()
 with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=ROOT,env={**os.environ,**ENV},stdout=out,stderr=err)
 v.update(exit_code=p.returncode,seconds=time.monotonic()-t,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout=c.pin(OUT/(name+'.stdout')),stderr=c.pin(OUT/(name+'.stderr')))
 c.write_new(OUT/(name+'.execution.json'),v);results.append(v);print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
after,dirs_after=c.inventory(ROOT,exclude_git=True);newmap={r['path']:r for r in after}
expected={'reviews/structured/'+rid+'/'+name for rid in ids for name in ['review.yaml','review.md']}
assert set(newmap)==set(oldmap)|expected
for p,r in oldmap.items():assert newmap[p]==r
assert set(dirs_after)==set(dirs_before)|{'reviews/structured/'+rid for rid in ids}
assert len([p for p in newmap if p.startswith('reviews/structured/') and p.endswith('/review.yaml')])==122
c.cache_check()
c.write_new(OUT/'completion.json',{'status':'all_native_review_save_and_checks_passed','results':results,'review_ids':ids,'old_pairs_preserved':120,'total_pairs':122,'only_four_review_files_added':True,'cache_entries_unchanged':800,'all_other_physical_owners_and_directories_exact':True,'whole_actual_saved_pairs':[c.pin(ROOT/p) for p in sorted(expected)],'publication_authorized':False})
