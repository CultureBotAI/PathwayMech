"""Read-only closed retrieval of every evidence body using repository paths only."""

import argparse
import gzip
import hashlib
import io
import json
import re
import stat
import zipfile
from pathlib import Path

import common as c

SHA = re.compile(r"^[0-9a-f]{64}$")


def verify(root, overlay=None):
    owner_pins = {}

    def owner(rel):
        rel = c.relative(rel)
        candidate = (overlay / rel) if overlay is not None else root / rel
        if overlay is not None and not candidate.exists():
            candidate = root / rel
        if candidate not in owner_pins:
            owner_pins[candidate] = c.pin(candidate)  # Type guard precedes decoding.
        return candidate

    index_path = owner(c.DOSSIER + "/evidence-index.json.gz")
    index = json.loads(gzip.decompress(c.regular_bytes(index_path)))
    if index["format"] != "lossless-content-addressed-evidence-v1":
        raise ValueError("Wrong portable evidence format")
    lookup = index["body_lookup"]
    archives = {}
    used_members = {}
    total_bytes = 0
    for sha, loc in lookup.items():
        if not SHA.fullmatch(sha) or sha != loc["sha256"]:
            raise ValueError("Wrong body identity key")
        rel = loc["repository_relative_path"]
        if loc["kind"] == "repository_file":
            p = owner(rel)
            body = c.regular_bytes(p)
        elif loc["kind"] in {"repository_zip_member", "repository_chunked_zip_member"}:
            member = loc["member"]
            if member != "blobs/" + sha:
                raise ValueError("Non-canonical CAS member")
            expected = (loc["archive_bytes"], loc["archive_sha256"])
            if rel not in archives:
                if loc["kind"] == "repository_chunked_zip_member":
                    part_names = [x["repository_relative_path"] for x in loc["archive_parts"]]
                    if not part_names or len(part_names) != len(set(part_names)):
                        raise ValueError("Duplicate or empty ordered archive parts")
                    chunks = []
                    for part in loc["archive_parts"]:
                        part_path = owner(part["repository_relative_path"])
                        c.verify(part, part_path)
                        chunks.append(c.regular_bytes(part_path))
                    archive_body = b"".join(chunks)
                    if (
                        len(archive_body),
                        hashlib.sha256(archive_body).hexdigest(),
                    ) != expected:
                        raise ValueError("Changed ordered virtual archive body")
                    archive_source = io.BytesIO(archive_body)
                else:
                    p = owner(rel)
                    bound = c.pin(p)
                    if (bound["bytes"], bound["sha256"]) != expected:
                        raise ValueError("Changed portable archive body")
                    archive_source = p
                with zipfile.ZipFile(archive_source) as z:
                    names = z.namelist()
                    if len(names) != len(set(names)):
                        raise ValueError("Duplicate archive member")
                    for info in z.infolist():
                        c.relative(info.filename)
                        if stat.S_ISLNK(info.external_attr >> 16):
                            raise ValueError("Active archive symlink forbidden")
                    archives[rel] = {
                        "pin": expected,
                        "members": set(names),
                        "source": archive_source,
                        "parts": loc.get("archive_parts"),
                    }
            if archives[rel]["pin"] != expected or archives[rel]["parts"] != loc.get(
                "archive_parts"
            ):
                raise ValueError("Conflicting archive identity")
            with zipfile.ZipFile(archives[rel]["source"]) as z:
                body = z.read(member)
            used_members.setdefault(rel, set()).add(member)
        else:
            raise ValueError("Unsupported portable owner")
        if (len(body), hashlib.sha256(body).hexdigest()) != (loc["bytes"], sha):
            raise ValueError("Changed retrievable body")
        total_bytes += len(body)
    new_archive = c.DOSSIER + "/archives/evidence-bodies.zip"
    if archives[new_archive]["members"] != used_members[new_archive]:
        raise ValueError("Extra or omitted member in new evidence archive")
    counts = {
        "packet_inventories": len(index["packet_inventories"]),
        "path_views": 0,
        "literal_links": 0,
        "special_metadata": 0,
        "originals": {},
    }

    def check_row(row):
        if "relative_path" in row:
            c.relative(row["relative_path"])
        if "sha256" in row:
            if row["sha256"] not in lookup or row["bytes"] != lookup[row["sha256"]]["bytes"]:
                raise ValueError("Unresolvable inventory body")
        if row["type"] == "symlink":
            if not isinstance(row["link_text"], str):
                raise ValueError("Missing literal link metadata")
            counts["literal_links"] += 1
        elif row["type"] == "special":
            if "mode" not in row:
                raise ValueError("Missing special metadata")
            counts["special_metadata"] += 1
        elif row["type"] not in {"regular", "directory"}:
            raise ValueError("Unknown inventory type")
        counts["path_views"] += 1

    for packet in index["packet_inventories"]:
        for key in (
            "physical_hidden_ignored_no_follow_inventory",
            "sealed_declared_file_views",
        ):
            seen = set()
            for row in packet[key]:
                if row["relative_path"] in seen:
                    raise ValueError("Duplicate path view")
                seen.add(row["relative_path"])
                check_row(row)
    for row in index["standalone_owners"]:
        check_row(row)
    for key, rows in index["original_groups"].items():
        counts["originals"][key] = len(rows)
        for row in rows:
            check_row(row["portable_body"])
            old, new = row["original_metadata"], row["portable_body"]
            if (old["bytes"], old["sha256"]) != (new["bytes"], new["sha256"]):
                raise ValueError("Original source body changed")
    for bound in owner_pins.values():
        c.verify(bound)
    return {
        "status": "all_portable_evidence_bodies_retrieved_and_verified",
        "unique_bodies": len(lookup),
        "unique_body_bytes": total_bytes,
        "used_archives": len(archives),
        **counts,
        "external_tmp_original_reads": False,
        "extracted_files": 0,
        "original_links_devices_or_fifos_recreated": False,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--adopted", action="store_true")
    p.add_argument("--root", type=Path, default=c.ROOT)
    args = p.parse_args()
    print(json.dumps(verify(args.root, None if args.adopted else c.HERE / "payload"), indent=2))


if __name__ == "__main__":
    main()
