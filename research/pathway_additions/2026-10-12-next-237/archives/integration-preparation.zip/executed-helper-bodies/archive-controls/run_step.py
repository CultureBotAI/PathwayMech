"""Retain each actual author preparation command, executed bodies and complete streams."""

import datetime
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent


def pin(path):
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def main():
    name, *argv = sys.argv[1:]
    assert name and "/" not in name and argv
    receipts = HERE / "receipts"
    receipts.mkdir(exist_ok=True)
    assert not (receipts / (name + ".json")).exists()
    versions = HERE / "executed-helper-bodies" / name
    versions.mkdir(parents=True)
    executed = []
    for path in sorted(HERE.glob("*.py")):
        copy = versions / path.name
        copy.write_bytes(path.read_bytes())
        executed.append({"executed": pin(path), "retained": pin(copy)})
    env = {
        **os.environ,
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONNOUSERSITE": "1",
        "UV_NO_SYNC": "1",
        "PYTHONPATH": str(HERE),
    }
    start = datetime.datetime.now(datetime.UTC).isoformat()
    with (
        (receipts / (name + ".stdout")).open("xb") as stdout,
        (receipts / (name + ".stderr")).open("xb") as stderr,
    ):
        result = subprocess.run(argv, cwd=HERE, env=env, stdout=stdout, stderr=stderr, check=False)
    receipt = {
        "name": name,
        "argv": argv,
        "cwd": str(HERE),
        "started_at": start,
        "finished_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "exit_code": result.returncode,
        "environment": {
            k: env[k]
            for k in ["PYTHONDONTWRITEBYTECODE", "PYTHONNOUSERSITE", "UV_NO_SYNC", "PYTHONPATH"]
        },
        "helpers": executed,
        "stdout": pin(receipts / (name + ".stdout")),
        "stderr": pin(receipts / (name + ".stderr")),
        "maintained_execution": False,
    }
    (receipts / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
    print(
        json.dumps(
            {
                "name": name,
                "exit_code": result.returncode,
                "receipt": pin(receipts / (name + ".json")),
            }
        ),
        flush=True,
    )
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
