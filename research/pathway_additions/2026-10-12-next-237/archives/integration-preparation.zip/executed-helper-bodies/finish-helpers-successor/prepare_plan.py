"""Compare complete accepted deltas and prepare concrete root-owned native stages."""

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import yaml

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-237-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-237-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
RID = "MetaCyc:PWY-8131"


def stable(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before, after = c.load(c.ROOT / rel), c.load(PAY / rel)
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [k for k in new if k in old] == list(old)
                for ident, value in old.items():
                    assert stable(value) == stable(new[ident]), (name, key, ident)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [k for k in new if k not in old],
                    "all_old_whole_objects_and_nested_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(PAY / rel),
            "sections": sections,
        }
    oldmanifest = c.load(c.ROOT / "conf/identifier_sources.json")
    newmanifest = c.load(PAY / "conf/identifier_sources.json")
    assert len(oldmanifest) == 855 and len(newmanifest) == 869
    assert stable(newmanifest[:855]) == stable(oldmanifest)
    assert c.regular_bytes(c.ROOT / "conf/rhea_identifier_updates.json") == c.regular_bytes(
        BUILD / "rhea-updates.json"
    )
    bn, an = rows(c.ROOT / "output/kgx/nodes.tsv"), rows(BUILD / "actual-kgx/nodes.tsv")
    be, ae = rows(c.ROOT / "output/kgx/edges.tsv"), rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = {r["id"]: r for r in be}
    assert [r for r in ae if r["id"] in oldedges] == be
    oldnodes, newnodes = {r["id"]: r for r in bn}, {r["id"]: r for r in an}
    changes, aggregate = [], []
    contexts = additions = 0
    for ident, old in oldnodes.items():
        new = newnodes[ident]
        prior = json.loads(old["source_contexts"])
        current = json.loads(new["source_contexts"])
        assert [v for v in current if v["record_id"] != RID] == prior
        delta_contexts = [v for v in current if v["record_id"] == RID]
        contexts += len(prior)
        additions += len(delta_contexts)
        delta = {
            key: {"before": value, "after": new[key]}
            for key, value in old.items()
            if key != "source_contexts" and value != new[key]
        }
        if delta:
            aggregate.append({"id": ident, "fields": delta})
        if old != new:
            changes.append({"id": ident, "before": old, "after": new})
    expected_delta = [
        {
            "id": "CHEBI:57642",
            "fields": {
                "name": {"before": "glycerone phosphate(2-)", "after": "glycerone phosphate(2−)"}
            },
        }
    ]
    assert aggregate == expected_delta
    assert len(changes) == additions == 15
    assert (len(bn), len(be), len(an), len(ae)) == (4277, 11949, 4297, 11987)
    record = yaml.safe_load(
        c.regular_bytes(PAY / "data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml")
    )
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for mapping in record.get("source_mappings", []):
        row = {k: mapping[k] for k in cols if k != "comment"}
        row["comment"] = (
            f"source_pathway_id={mapping['source_pathway_id']}; "
            f"source_element_id={mapping['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(row[k])).strip() for k in cols})
    existing = Counter(stable(r) for r in oldss)
    assert len(oldss) == 32 and all(n == 1 for n in existing.values())
    added = [r for r in newss if stable(r) not in existing]
    assert len(added) == len(newss) == 0
    files = c.load(H / "baseline-files.json")

    def count(prefix, suffix):
        return sum(r["path"].startswith(prefix) and r["path"].endswith(suffix) for r in files)

    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": count("data/pathways/", ".yaml"),
        "old_review_yaml": count("reviews/", ".yaml"),
        "old_review_markdown": count("reviews/", ".md"),
        "old_history_yaml": count("history/", ".yaml"),
        "native_authorities": native,
        "manifest_prefix_rows": 855,
        "manifest_after_rows": 869,
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_order_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_changes": aggregate,
        ("aggregate_display_scope"): (
            "Only CHEBI:57642 aggregate display label uses Unicode minus; eve"
            "ry old context label and canonical authority object remains exac"
            "t. No category or direction change."
        ),
        "old_authority_object_exceptions": [],
        "planning_decisions": [c.pin(PRE / "graph-planning-decision.json")],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = json.loads(
        json.dumps(c.load(OLD / "stages.json"))
        .replace("pathwaymech-next-236", "pathwaymech-next-237")
        .replace("acetoacetate-degradation", "5-prime-deoxyadenosine-degradation-ii")
        .replace("ACETOACETATE-DEG-PWY", "PWY-8131")
    )
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="conf/identifier_sources.json",
        description=(
            "Exact accepted869-row manifest and two actual snapshots with unc"
            "hanged270-file runtime. Preserve all old authority objects, cont"
            "ext and first owners."
        ),
        issue_lineage=[],
    )

    def history(kind, slug, owner_args, event, summary, details, issues=()):
        argv = [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            kind,
            "--slug",
            slug,
            *owner_args,
            "--event",
            event,
            "--outcome",
            "changed",
            "--summary",
            summary,
            "--details",
            details,
        ]
        for issue in issues:
            argv += ["--issue", str(issue)]
        return argv + ["--actor-name", "codex", "--agent-tool", "codex", "--model", "gpt-6"]

    stages["history_commands"] = [
        history(
            "record",
            "5-prime-deoxyadenosine-degradation-ii",
            ["--target-root", "data/pathways"],
            "CREATE",
            "Add the complete evidence-backed 5-prime-deoxyadenosine degradation II record.",
            (
                "Adopted exact accepted MetaCyc:PWY-8131 provider successor:12 pa"
                "ragraphs,38 edges,15 endpoint qualifiers,35 named identities and"
                "31 references. Complete four-event route,14 chemical-side occurr"
                "ences,native assemblies,construct/strain/metal-specific evidence"
                " and source access limits retained in research/pathway_additions"
                "/2026-10-12-next-237. Accepted issue503 provider correction reta"
                "ined; issue closure is not asserted. Actual native outputs indep"
                "endently reviewed. Fresh maintained gates and native saved revie"
                "w remain pending."
            ),
            [503],
        ),
        history(
            "infrastructure",
            "deoxy237-native-authority",
            ["--path", "conf/identifier_sources.json"],
            "EDIT",
            "Integrate complete PWY-8131 authority sources and accepted native snapshots.",
            (
                "Adopted exact869-row manifest retaining all855 prior entries and"
                " two actual native snapshots. Existing270-file runtime and Rhea "
                "updates remain unchanged; whole old authority objects/order and "
                "first owners preserved. CHEBI:57642 aggregate label changes ASCI"
                "I minus to Unicode minus; all old graph contexts remain exact. N"
                "o category or direction change. Local integration only; historie"
                "s precede generation, and maintained gates/native review remain "
                "pending."
            ),
        ),
    ]
    stages["after_gates"] = [
        (
            "Inspect the complete actual PWY-8131 page/graph,all12 paragraphs"
            "/38 edges,15 qualifiers,35 identities and31 references against e"
            "xact accepted science and original limitations."
        ),
        (
            "Native inspect actual maintained inputs before judgments; preser"
            "ve inherited complete-source review versus fresh maintained QA; "
            "validate/save/check two immutable scientific and technical revie"
            "ws."
        ),
        (
            "Verify237 prior records/pages,118 review pairs and402 old histor"
            "ies; preserve every old whole authority object/order,all11949 ol"
            "d KGX edges and old context payloads/order/multiplicity."
        ),
        (
            "Permit only accepted CHEBI:57642 aggregate label ASCII-to-Unicod"
            "e-minus change and expected first-encounter node ordering. All o"
            "ld context labels remain exact."
        ),
        (
            "Native SSSOM export must remain byte-identical:32 old rows,zero "
            "new mappings,unchanged headers/cells/order/multiplicity."
        ),
        (
            "Recheck all800 shared-cache identities and complete hidden/ignor"
            "ed checkout outside exact primary/dossier/history/generated/revi"
            "ew additions; final independent actual-tree and append-only veri"
            "fication before local commit."
        ),
    ]
    stages["before_first_render_after_history"][0].update(
        reason=(
            "Retain the established native generation sequence; this record h"
            "as no source_mappings and the SSSOM output must remain unchanged"
            "."
        ),
        preservation=(
            "All32 old SSSOM rows/cells/order/header exact;zero additions and"
            " byte-identical output required."
        ),
    )
    stages["native_review_interfaces"]["inherited_science_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-237-science-review-20261012/handoff.json"
    )
    stages["native_review_interfaces"]["accepted_provider_successor_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-237-provider-independent-review-20261012/handoff.json"
    )
    stages["native_review_interfaces"]["actual_native_review_handoff"] = c.pin(
        
            "/private/tmp/pathwaymech-next-237-canonical-output-independent-r"
            "eview-20261012/handoff.json"
        
    )
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    stages["native_review_interfaces"]["save_template"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "save",
        "--content",
        "<root-authored-completed-review.json>",
    ]
    stages["native_review_interfaces"]["check_after_save"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "check",
        "--require-reviews",
        "--base",
        c.BASE,
    ]
    c.write_new(H / "stages.json", stages)
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Committed accepted aceto236 local branch; not merged main",
            "primary_owners": len(c.PRIMARY),
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(
                PAY / "data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml"
            ),
            "actual_native_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-237-root-canonical-output-acceptance-20261012.json"
            ),
            "remaining": [
                "independent preparation review",
                "root exact acceptance",
                "local adoption",
                "two native histories before SSSOM/render",
                "nine maintained gates",
                "actual page/graph QA",
                "native saved reviews",
                "complete preservation and final adversarial review",
            ],
            "source_exhaustion": False,
            "licensing": "Public-release licensing remains deferred;publication not authorized.",
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_files",
                    "old_records",
                    "old_review_yaml",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                    "exact_aggregate_changes",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
