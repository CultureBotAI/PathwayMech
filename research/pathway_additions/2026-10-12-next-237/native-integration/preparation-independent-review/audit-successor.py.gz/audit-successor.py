"""Bounded independent preparation audit; no adoption, Git, SQL or native gates."""
import ast,csv,gzip,hashlib,io,json,sys,zipfile
from collections import Counter
from dataclasses import asdict
from pathlib import Path
import yaml
import common as c
import verify_portable as portable
R=Path(__file__).resolve().parent;P=c.HERE;T=c.ROOT;D=P/'payload'/c.DOSSIER
B=Path('/private/tmp/pathwaymech-next-237-canonical-build-20261012')
PRE=Path('/private/tmp/pathwaymech-next-237-canonical-preparation-20261012')
OLD=Path('/private/tmp/pathwaymech-next-236-local-integration-preparation-20261012')
RID='MetaCyc:PWY-8131'
def stable(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def readrows(path):return list(csv.DictReader(io.StringIO(Path(path).read_text()),delimiter='\t'))
def check(row):return c.verify(row)
assert c.pin(P/'handoff.json')['sha256']=='9772c496a933fc83efe5f86bd0f4f5798cad621ed4486bf967716d87d995fbbe'
assert c.pin(P/'artifact-manifest.json')['sha256']=='497445055ba871bdad3f28fdd557b09cc3739b30405388b6072ed1ebfeddd22b'
c.sealed_check();m=c.load(P/'artifact-manifest.json');assert len(m['artifacts'])==276
assert c.inventory(P)[1]==m['directories']
plan=c.load(P/'plan.json');assert len(c.scope_check(plan))==13 and len(c.PRIMARY)==4
for row in plan['accepted_inputs']:check(row)
baseline_files=c.load(P/'baseline-files.json');baseline_dirs=c.load(P/'baseline-directories.json')
assert c.inventory(T,exclude_git=True)==(baseline_files,baseline_dirs)
c.cache_check()
for row in plan['changes']:c.destination_check(row)
baseline=c.load(P/'baseline-receipt.json');assert baseline['commit']==c.BASE and baseline['tree']==c.TREE and baseline['branch']==c.BRANCH
assert baseline['files']==12119 and baseline['directories']==1959
for row in baseline_files:
    if row['path'].startswith('data/pathways/') and row['path'].endswith('.yaml'):
        assert c.pin(B/'corpus'/Path(row['path']).name)['sha256']==row['sha256']
counts={name:sum(r['path'].startswith(prefix) and r['path'].endswith(suffix) for r in baseline_files)
 for name,prefix,suffix in [('records','data/pathways/','.yaml'),('review_yaml','reviews/','.yaml'),('review_md','reviews/','.md'),('histories','history/','.yaml')]}
assert counts=={'records':237,'review_yaml':118,'review_md':118,'histories':402}
owner=c.load(P/'runtime-owner-map.json');assert len(owner['runtime'])==270
execution=c.load(PRE/'execution-plan.json');overrides={}
for rel,kind,flag in [('conf/identifier_sources.json','source_builder','--manifest'),('conf/rhea_identifier_updates.json','ontology_builder','--rhea-updates')]:
    argv=execution['commands'][kind];overrides[rel]=Path(argv[argv.index(flag)+1])
assert overrides=={'conf/identifier_sources.json':B/'manifest.json','conf/rhea_identifier_updates.json':B/'rhea-updates.json'}
changed=[]
for row in owner['runtime']:
    for name in ['accepted','effective_preparation','actual_runtime','effective_integration']:check(row[name])
    assert row['actual_runtime']['sha256']==row['effective_preparation']['sha256']==row['accepted']['sha256']
    rel=row['relative_path'];source=B/'runtime'/rel;assert c.pin(source)==row['actual_runtime']
    effective=overrides.get(rel,source);assert c.pin(effective)==row['effective_integration']
    dest=T/rel;before=c.pin(dest) if dest.exists() else None;assert before==row['before']
    assert row['changed']==(before is None or before['sha256']!=row['effective_integration']['sha256'])
    if row['changed']:
        changed.append(rel);assert (P/'payload'/rel).read_bytes()==effective.read_bytes()
assert len(changed)==1 and 'conf/identifier_sources.json' in changed and 'conf/rhea_identifier_updates.json' not in changed
assert c.PRIMARY==set(changed)|{'data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json'}
assert len(c.load(B/'runtime/conf/identifier_sources.json'))==831
assert (T/'conf/rhea_identifier_updates.json').read_bytes()==(B/'rhea-updates.json').read_bytes()
target=P/'payload/data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml'
assert c.pin(target)['sha256']=='a367fac8ac036416baaabc9d64ae1d9927e66e87ad1bb96e2883725fd14ce68b'
assert target.read_bytes()==(B/'corpus/5-prime-deoxyadenosine-degradation-ii.yaml').read_bytes()
sem=c.load(P/'semantic-preservation.json')
for kind in ['sources','ontology']:
    old=c.load(T/f'data/identifier_authorities/{kind}.json');new=c.load(P/f'payload/data/identifier_authorities/{kind}.json')
    assert (P/f'payload/data/identifier_authorities/{kind}.json').read_bytes()==(B/(kind+'.json')).read_bytes()
    assert list(old)==list(new)
    for key,value in old.items():
        if isinstance(value,dict):
            assert [k for k in new[key] if k in value]==list(value)
            for ident,obj in value.items():assert stable(obj)==stable(new[key][ident])
        else:assert stable(value)==stable(new[key])
oldmanifest=c.load(T/'conf/identifier_sources.json');newmanifest=c.load(P/'payload/conf/identifier_sources.json')
assert len(oldmanifest)==855 and len(newmanifest)==869 and stable(newmanifest[:855])==stable(oldmanifest)
graph_changes=[];context_count=0;graph_counts={};changed_nodes=[]
for name in ['nodes.tsv','edges.tsv']:
    before=readrows(T/'output/kgx'/name);after=readrows(B/'actual-kgx'/name);old={r['id']:r for r in before};new={r['id']:r for r in after}
    assert len(old)==len(before) and len(new)==len(after) and set(old)<=set(new)
    graph_counts[name]={'before':len(before),'after':len(after)}
    if name=='edges.tsv':assert [r for r in after if r['id'] in old]==before
    else:
        for ident,row in old.items():
            bc=json.loads(row['source_contexts']);ac=json.loads(new[ident]['source_contexts'])
            assert [v for v in ac if v['record_id']!=RID]==bc;context_count+=len(bc)
            diff={k:{'before':v,'after':new[ident][k]} for k,v in row.items() if k!='source_contexts' and v!=new[ident][k]}
            if diff:graph_changes.append({'id':ident,'fields':diff})
            if row!=new[ident]:changed_nodes.append(ident)
assert context_count==7966 and len(changed_nodes)==15
assert graph_counts=={'nodes.tsv':{'before':4277,'after':4297},'edges.tsv':{'before':11949,'after':11987}}
assert graph_changes==sem['exact_aggregate_changes']==[{'id':'CHEBI:57642','fields':{'name':{'before':'glycerone phosphate(2-)','after':'glycerone phosphate(2−)'}}}]
# Invoke the real native SSSOM row functions only in memory, not its exporter.
sys.path[:0]=[str(T/'src'),str(T)]
from pathwaymech.schema import validate_record
from pathwaymech.sssom import sssom_rows,_cell,SSSOM_HEADER,SSSOM_COLUMNS
record=validate_record(yaml.safe_load(target.read_bytes()))
rows=[{k:_cell(asdict(row)[k]) for k in SSSOM_COLUMNS} for row in sssom_rows([record])]
ss=sem['SSSOM'];assert len(rows)==0 and Counter(stable(row) for row in rows)==Counter(stable(row) for row in ss['expected_added_rows'])
oldtext=(T/'output/sssom/source_mappings.sssom.tsv').read_text();header=[v for v in oldtext.splitlines() if v.startswith('#')]
assert header==list(SSSOM_HEADER)==ss['exact_header_lines']
oldss=list(csv.DictReader(io.StringIO('\n'.join(v for v in oldtext.splitlines() if not v.startswith('#'))),delimiter='\t'))
assert len(oldss)==ss['old_rows']==32 and ss['expected_total_rows']==32
assert not (set(stable(v) for v in rows)&set(stable(v) for v in oldss))
stages=c.load(P/'stages.json');assert stages['cwd']==str(T)
assert c.pin(P/'stages.json')['sha256']=='f259f742fcea751783b4861ad765b5c4c5bfc112d692d73d945523bfcf3f2912'
assert [v['name'] for v in stages['nine_fresh_gates']]==['render','skills','validate','tests','lint','kgx','vendored','diff-check','site-current']
assert len(stages['history_commands'])==2 and all(cmd[cmd.index('--actor-name')+1]=='codex' for cmd in stages['history_commands'])
assert [cmd[cmd.index('--event')+1] for cmd in stages['history_commands']]==['CREATE','EDIT']
assert stages['before_first_render_after_history'][0]['name']=='sssom'
assert plan['history_before_first_render'] is True and stages['native_review_interfaces']['do_not_fabricate_review_content_or_completion_time'] is True
for command in stages['history_commands']+[v['argv'] for v in stages['nine_fresh_gates']+stages['before_first_render_after_history']]:
    if command[0].endswith('/python'):assert command[:2]==['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B']
replacements={'/pathwaymech-next-236-local-20261012':'/pathwaymech-next-237-local-20261012','9bd87745d842b0602d027f3d15d26bbc178474a6':c.BASE,'8f511cd6f99173bc86f5aaa9f349a35af5fddfb3':c.TREE,'feat/pathway-next-236-local-20261012':c.BRANCH,'2026-10-12-next-236':'2026-10-12-next-237','aceto236':'deoxy237','pathwaymech-next-236-local-adoption-':'pathwaymech-next-237-local-adoption-'}
for row in c.load(P/'helper-lineage.json'):
    check(row['original']);check(row['successor']);text=(OLD/row['helper']).read_text()
    for a,b in replacements.items():text=text.replace(a,b)
    a=ast.parse(text);b=ast.parse((P/row['helper']).read_text())
    if row['helper']=='common.py':
        def primary(t):return next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='PRIMARY' for x in n.targets))
        primary(a).value=primary(b).value
    assert ast.dump(a)==ast.dump(b)
replay=portable.verify(T,P/'payload')
assert replay==c.load(P/'receipts/portable-replay.stdout') and replay['unique_bodies']==2380
proof=c.load(P/'preparation-archive-proof.json');check(proof['archive'])
with zipfile.ZipFile(proof['archive']['path']) as z:
    assert set(z.namelist())=={r['archive_member'] for r in proof['members']}
    for row in proof['members']:
        check(row);body=z.read(row['archive_member']);assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
for name in ['common.py','verify_portable.py']:assert gzip.decompress((D/(name+'.gz')).read_bytes())==(P/name).read_bytes()
assert (D/'README.md').read_bytes()==(P/'REPORT.md').read_bytes()
closures=json.loads(gzip.decompress((D/'external-packet-closures.json.gz').read_bytes()))
assert len(closures)==10 and sum(len(v['external_fixture_owners']) for v in closures)==0
for row in closures:check(row['handoff']);check(row['manifest']);assert not row['declared_followed_views_not_traversed']
# Author commands retain actual script versions and streams, including unsuccessful lint attempts.
receipts=[]
for path in sorted((P/'receipts').glob('*.json')):
    r=c.load(path);check(r['stdout']);check(r['stderr'])
    for item in r['helpers']:
        check(item['retained']);assert item['executed']['sha256']==item['retained']['sha256'] and item['executed']['bytes']==item['retained']['bytes']
    receipts.append({'receipt':c.pin(path),'exit_code':r['exit_code'],'argv':r['argv']})
assert c.load(P/'receipts/guard-controls.json')['exit_code']==0
assert c.load(P/'configured-helper-lint-final.receipt.json')['exit_code']==1
final_lint=c.load(P/'configured-helper-lint-successor.receipt.json');assert final_lint['exit_code']==0
check(final_lint['stdout']);check(final_lint['stderr'])
for row in final_lint['helpers']:check(row)
# Inherited fixture bodies and giant SQL databases are intentionally not opened.
c.cache_check();assert c.inventory(T,exclude_git=True)==(baseline_files,baseline_dirs);c.sealed_check()
out={'status':'passed','subject_artifacts':276,'seals':2,'physical_directories':len(m['directories']),'baseline_files':12119,'baseline_directories':1959,
 'baseline_commit_tree_branch':'inherited exact clean capture; no fresh Git command','baseline_counts':counts,'complete_hidden_ignored_baseline_pre_post_exact':True,'cache_entries':800,'cache_pre_post_exact':True,
 'runtime_checked':270,'effective_runtime_differences':1,'primary_owners':4,'dossier_owners':9,'explicit_native_configuration_bridge_checked':True,'retained_runtime_manifest_rows':831,'baseline_manifest_rows':855,'effective_manifest_rows':869,'Rhea_config_unchanged':True,
 'actual_native_outputs_byte_exact':True,'whole_old_objects_and_nested_order_preserved_without_exceptions':True,'old_KGX_contexts':7966,'old_edges_payload_and_order_exact':True,'graph_counts':graph_counts,'changed_old_nodes':changed_nodes,'aggregate_changes':graph_changes,
 'SSSOM_added_rows':rows,'SSSOM_native_row_normalizer_replayed_without_export':True,'history_before_render_and_SSSOM_before_gates':True,'gates_planned':9,'helper_AST_rebase_exact':True,'portable_replay':replay,'preparation_archive_members':len(proof['members']),
 'external_fixture_physical_files':0,'external_fixture_whole_hashes':'inherited; not rehashed','author_receipts':receipts,'SQL_databases_read':False,'adoption_native_gates_history_Git_GitHub_performed':False,'science':'inherited accepted record and actual output review; no new primary-paper review'}
c.write_new(R/'audit-results.json',out);print(json.dumps({'status':'passed','primary':4,'dossier':9,'portable_bodies':2380,'SSSOM_added':0,'baseline_cache_unchanged':True}))
