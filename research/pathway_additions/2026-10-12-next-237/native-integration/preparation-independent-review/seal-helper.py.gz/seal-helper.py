from pathlib import Path
import sys,json,datetime,hashlib,zipfile
P=Path('/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012');R=Path('/private/tmp/pathwaymech-next-237-local-integration-independent-review-20261012')
sys.path.insert(0,str(P));import common as c
assert c.load(R/'audit-successor.json')['exit_code']==0 and c.load(R/'controls.json')['exit_code']==0
res=c.load(R/'audit-results.json');assert res['portable_replay']['unique_bodies']==2380
F=Path('/private/tmp/pathwaymech-next-237-independent-guard-fixtures-20261012');fr,fd=c.inventory(F)
c.write_new(R/'control-fixtures-inventory.json',{'root':str(F),'rows':fr,'directories':fd,'links_and_specials':'inert metadata, not opened or followed'})
with zipfile.ZipFile(R/'control-fixtures.zip','x',zipfile.ZIP_DEFLATED) as z:
 for row in fr:
  if row['type']=='regular':z.writestr(row['path'],c.regular_bytes(F/row['path']))
c.write_new(R/'fresh-git-diagnostic.json',{'tool_chunk':'de6925','exit_code':0,'cwd':str(c.ROOT),'clean':True,'HEAD':c.BASE,'tree':c.TREE,'note':'read-only fresh Git commands; main audit reused exact baseline capture'})
report='''Independent local-integration review accepts the exact 237 preparation for local adoption. The reviewer is Codex /root, independent of its preparation author. This is a preparation review, not maintained QA or a new primary-paper review.

Fresh checks bound all 276 preparation artifacts plus two seals, full directory membership, all 12,119 hidden/ignored baseline files and 1,959 directories, and all 800 cache identities and bodies. The target is clean at 290bd9781e43e473d88b9fd7c17f6f61da45092e, tree ba9aea8a75901f872e86a30505448f1113c4d6da, on its planned branch. No target or cache writes occurred.

All four primary and nine dossier owners match the exact plan. All 270 accepted runtime files were bridged to actual native execution; only the explicit actual manifest changes, from 855 to 869 rows. Existing Rhea configuration and production code remain exact. The complete accepted source/ontology bodies preserve every old owner/term object and nested order. All 237 prior record bodies, 118 saved review pairs and 402 history records remain byte-exact.

All 11,949 old KGX edge rows, multiplicity and relative order are exact. All 7,966 old node contexts and order are retained. After-KGX has 4,297 nodes and 11,987 edges, with 15 shared-node context additions. The sole old aggregate-field change is CHEBI:57642 from ASCII minus to Unicode minus in its label. Every old context label and canonical authority object stays exact. Native in-memory SSSOM row generation produces zero added mappings; all 32 old rows and headers are retained, with byte-identical generation required during actual gates.

The complete portable resolver independently rehashed all 2,380 bodies, totaling 339,540,824 decoded bytes, using the payload and committed repository owners only. The whole new archive, ordered parts, canonical member names, archive membership and original groups passed. Whole preparation archive contents, gzip helpers and all ten external packet closure bindings passed. Giant SQL bodies and earlier explicitly excluded synthetic fixture bodies were not rehashed; their accepted execution provenance is inherited honestly. The independent 42 guard controls passed in 0.23 seconds; complete new synthetic regular bodies are retained in an inert ZIP, with links/specials recorded only as metadata.

Full manual reading covered the report, handoff, plan, stages, guard/adoption code, tests and correction/packaging lineage. AST comparison confirms only the declared baseline/path/status/primary-set changes to accepted guards. Histories precede SSSOM and render; nine real maintained gates and two immutable native reviews remain required. Existing scientific acceptance, provider correction, endpoint/strain/construct/metal qualifications and source-access limits are inherited without promotion.

One independent audit assertion selected the author's preserved failed final-named lint receipt. The actual final-helper-verification correctly identifies a separately named successful successor. The original audit/helper/streams remain intact; the successor explicitly verifies both statuses and all passed-lint helper hashes, and completed in 33.04 seconds. Guessed optional filenames and one Git diagnostic from a non-repository directory were read-only probes, not absence findings. Their corrections are recorded. No product, source, plan, cache or sealed preparation changed to satisfy the audit.

The acceptance authorizes exact local adoption only. It does not claim native maintained gates, native review completion, commit, public publication, licensing clearance or source exhaustion.
'''
(R/'REPORT.md').write_text(report)
(R/'seal-helper.py').write_bytes(Path(__file__).read_bytes())
rows,ds=c.inventory(R);assert all(r['type']=='regular' for r in rows)
c.write_new(R/'artifact-manifest.json',{'artifacts':[{'relative_path':r['path'],**c.pin(R/r['path'])} for r in rows],'directories':ds,'hidden_and_ignored_included':True})
c.write_new(R/'handoff.json',{'status':'accepted_exact_local_preparation','reviewer':'Codex /root','preparation':c.pin(P/'handoff.json'),'manifest':c.pin(R/'artifact-manifest.json'),'report':c.pin(R/'REPORT.md'),'audit':c.pin(R/'audit-results.json'),'artifacts':len(rows),'seals':2,'local_only':True,'publication_authorized':False,'adoption_performed':False,'finished_at':datetime.datetime.now(datetime.UTC).isoformat()})
A=Path('/private/tmp/pathwaymech-next-237-root-local-integration-acceptance-20261012.json')
c.write_new(A,{'status':'accepted_exact_deoxy237_local_integration_for_adoption','reviewer':'Codex /root','local_only':True,'publication_authorized':False,'shared_cache_mutation':False,'history_before_first_render':True,'target':str(c.ROOT),'commit':c.BASE,'tree':c.TREE,'handoff':c.pin(P/'handoff.json'),'independent_review':c.pin(R/'handoff.json'),'review_manifest':c.pin(R/'artifact-manifest.json'),'record_sha256':'a367fac8ac036416baaabc9d64ae1d9927e66e87ad1bb96e2883725fd14ce68b','primary_owners':4,'total_owners':13,'remaining':'Exact adoption, histories before native generation, nine gates, independent actual maintained QA, immutable reviews, local finalization; publication remains separately blocked.','at':datetime.datetime.now(datetime.UTC).isoformat()})
print(json.dumps({'review_handoff':c.pin(R/'handoff.json'),'review_manifest':c.pin(R/'artifact-manifest.json'),'acceptance':c.pin(A),'artifacts':len(rows)},indent=2))
