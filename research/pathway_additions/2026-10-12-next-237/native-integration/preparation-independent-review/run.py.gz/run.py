"""Retain actual independent commands, source pins, complete streams and timing."""
import hashlib,json,os,subprocess,sys,time,datetime
from pathlib import Path
R=Path(__file__).resolve().parent
PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
P=Path('/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012')
name=sys.argv[1];cmd=[PY,'-B',*sys.argv[2:]]
env={'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(P)+os.pathsep+str(R)}
def bind(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
start=time.time();started=datetime.datetime.now(datetime.UTC).isoformat();inputs=[bind(p) for p in R.glob('*.py')]+[bind(P/p) for p in ['common.py','adopt.py','verify_portable.py']]
with (R/(name+'.stdout')).open('xb') as out,(R/(name+'.stderr')).open('xb') as err:
 code=subprocess.run(cmd,cwd=R,env={**os.environ,**env},stdout=out,stderr=err).returncode
receipt={'command':cmd,'cwd':str(R),'environment':env,'started_at':started,'finished_at':datetime.datetime.now(datetime.UTC).isoformat(),'elapsed_seconds':time.time()-start,'exit_code':code,'inputs':inputs,'stdout':bind(R/(name+'.stdout')),'stderr':bind(R/(name+'.stderr'))}
(R/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(code)
