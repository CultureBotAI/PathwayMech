"""Independently appraise exact retained whitespace; never normalize evidence."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/private/tmp/pathwaymech-next-237-local-20261012')
STAGE = Path('/private/tmp/pathwaymech-next-237-staged-precommit-20261012')
OUT = Path('/private/tmp/pathwaymech-next-237-root-whitespace-appraisal-20261012.json')

def pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

scope = json.loads((STAGE / 'staged-whitespace-scope.json').read_bytes())
assert scope['original_full_staged_exit'] == 2
assert len(scope['exclusions']) == 4 and len(scope['diagnostics']) == 14
full = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, capture_output=True)
assert full.returncode == 2
assert full.stdout == (STAGE / 'whitespace-unscoped.stdout').read_bytes()
assert full.stderr == (STAGE / 'whitespace-unscoped.stderr').read_bytes()
appraised = []
for entry in scope['exclusions']:
    p = ROOT / entry['path']
    assert p.is_file() and not p.is_symlink()
    body = p.read_bytes()
    source = Path(entry['source']).read_bytes()
    staged = subprocess.check_output(['git', 'show', ':' + entry['path']], cwd=ROOT)
    assert body == source == staged
    assert pin(body) == entry['body'] == entry['source_body']
    numbers = [d['line'] for d in scope['diagnostics'] if d['path'] == entry['path']]
    is_patch = p.suffix in ('.patch', '.diff')
    expected = b' ' if is_patch else b'  '
    assert all(body.splitlines()[n-1] == expected for n in numbers)
    if not is_patch:
        assert p.name == 'tests.stdout' and numbers == [67]
        assert b'4273 passed, 3 skipped' in body
    else:
        assert body.startswith(b'--- ') and b'\n+++ ' in body and b'\n@@ ' in body
    appraised.append({**entry, 'diagnostic_lines': numbers,
        'accepted_reason': ('The single space is the literal context-line marker of the retained unified diff.'
            if is_patch else 'The two spaces are the exact upstream dependency-warning output in the successful pytest stream.'),
        'root_observation': 'Whole retained source, working file, and staged blob are byte identical; context personally read.'})
argv = ['git', 'diff', '--cached', '--check', '--', '.',
        *[':(exclude,literal)' + e['path'] for e in appraised]]
scoped = subprocess.run(argv, cwd=ROOT, capture_output=True)
assert scoped.returncode == 0 and not scoped.stdout and not scoped.stderr
report = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'root_helper': pin(Path(__file__).read_bytes()),
    'scope_report': pin((STAGE / 'staged-whitespace-scope.json').read_bytes()),
    'full_staged_whitespace': {'exit_code': full.returncode, 'stdout': pin(full.stdout), 'stderr': pin(full.stderr)},
    'individual_exceptions': appraised,
    'authored_scope': {'argv': argv, 'exit_code': scoped.returncode, 'stdout': pin(scoped.stdout), 'stderr': pin(scoped.stderr)},
    'disposition': 'Four exact retained-original exceptions accepted. Full check remains exit 2, scoped authored check is 0. Local commit may proceed after planned preservation checks.',
    'source_bytes_changed': False, 'git_settings_changed': False,
    'publication_authorized': False}
with OUT.open('x') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
print(json.dumps({'path': str(OUT), **pin(OUT.read_bytes()), 'full_exit': full.returncode, 'scoped_exit': scoped.returncode}))
