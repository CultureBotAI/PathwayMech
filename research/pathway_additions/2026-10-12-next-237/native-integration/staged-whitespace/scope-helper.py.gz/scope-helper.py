"""Retain exact original-byte diagnostics; check only explicitly appraised exclusions."""
from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
R=Path('/private/tmp/pathwaymech-next-237-local-20261012');O=Path('/private/tmp/pathwaymech-next-237-staged-precommit-20261012')
def load(p):return json.loads(Path(p).read_bytes())
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
v=load(O/'staged-verification.json');diag=v['whitespace_diagnostics'];paths=sorted({x['path'] for x in diag})
assert v['full_whitespace_exit_code']==2 and len(paths)==4 and len(diag)==14
plan={x['destination']:x for x in load('/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012/plan.json')['changes']}
copy={x['repository_path']:x for x in load('/private/tmp/pathwaymech-next-237-maintained-independent-qa-20261012/copy-plan.json')['files']}
root={x['owner']:x for x in load(R/'research/pathway_additions/2026-10-12-next-237/native-integration/root-storage-map.json')['entries']}
bindings=[]
for p in paths:
 b=(R/p).read_bytes()
 if p in plan:
  x=plan[p]['payload'];assert pin(b)=={'bytes':x['bytes'],'sha256':x['sha256']};src=x['path'];raw=Path(src).read_bytes();assert raw==b;kind='accepted complete upstream XML fixture'
 elif p in copy:
  x=copy[p];assert pin(b)=={'bytes':x['bytes'],'sha256':x['sha256']};src=x['source_path'];raw=Path(src).read_bytes();assert (gzip.decompress(b) if x['gzip_encoded'] else b)==raw;kind='exact retained test stream' if p.endswith('tests.stdout') else 'exact retained unified-diff lineage'
 else:
  x=root[p];assert pin(b)==x['stored'];src=x['source'];raw=Path(src).read_bytes();assert (gzip.decompress(b) if x['encoding']=='gzip' else b)==raw;kind='exact retained unified-diff lineage'
 if p.endswith(('.patch','.diff')):
  assert all(b.splitlines()[d['line']-1]==b' ' for d in diag if d['path']==p)
 staged=subprocess.check_output(['git','show',':'+p],cwd=R);assert staged==b
 bindings.append({'path':p,'body':pin(b),'source':src,'source_body':pin(raw),'classification':kind,'action':'preserve original bytes; exact-path whitespace exclusion only'})
argv=['git','diff','--cached','--check','--','.',*[':(exclude,literal)'+p for p in paths]]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=R,capture_output=True)
(O/'whitespace-authored.stdout').write_bytes(r.stdout);(O/'whitespace-authored.stderr').write_bytes(r.stderr)
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_full_staged_exit':2,'original_stdout':pin((O/'whitespace-unscoped.stdout').read_bytes()),'original_stderr':pin((O/'whitespace-unscoped.stderr').read_bytes()),'diagnostics':diag,'exclusions':bindings,'authored_scope':{'argv':argv,'cwd':str(R),'started_at':start,'exit_code':r.returncode,'stdout':pin(r.stdout),'stderr':pin(r.stderr)},'whitespace_settings_changed':False,'source_bytes_changed':False,'appraisal':'independent root appraisal requested separately'}
(O/'staged-whitespace-scope.json').write_text(json.dumps(report,indent=2)+'\n');assert r.returncode==0
print(json.dumps({'authored_scope_exit':r.returncode,'exact_excluded_paths':len(paths),'original_full_staged_exit':2,'diagnostics':len(diag)}))
