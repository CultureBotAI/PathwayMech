"""Run only after actual gates and root QA. Inspect, then author/validate external content.

No native saves, product edits, broad gates, source builders or SQL hashes.
"""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,shlex,subprocess,stat
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-237-local-20261012')
Q=Path('/private/tmp/pathwaymech-next-237-root-maintained-qa-20261012')
N=Path('/private/tmp/pathwaymech-next-237-local-native-execution-20261012')
S=Path('/private/tmp/pathwaymech-next-237-science-review-20261012')
P=Path('/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012')
DR='research/pathway_additions/2026-10-12-next-237/native-integration/independent-qa'
TARGET='data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml'
PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
class Dumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
def utc():return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def save(n,v):
 with (H/n).open('x') as f:f.write(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def verify(v):
 now=pin(v['path']);assert now['sha256']==v['sha256']
 if 'bytes' in v:assert now['bytes']==v['bytes']
 return now
def run(name,argv):
 start=utc();helper=pin(Path(__file__))
 with (H/(name+'.stdout')).open('xb') as out,(H/(name+'.stderr')).open('xb') as err:
  result=subprocess.run(argv,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',UV_NO_SYNC='1',PYTHONPATH=str(R/'src')+':'+str(R)),stdout=out,stderr=err)
 receipt=dict(command=argv,cwd=str(R),started_at=start,finished_at=utc(),exit_code=result.returncode,helper=helper,stdout=pin(H/(name+'.stdout')),stderr=pin(H/(name+'.stderr')))
 save(name+'.execution.json',receipt);assert result.returncode==0,name
 return load(H/(name+'.stdout')) if name.endswith('inspect') else receipt

# Fail before any native content if a phase or actual QA is incomplete.
native_manifest=load(N/'artifact-manifest.json');native_seen=set()
for row in native_manifest['files']:
 p=N/row['relative_path'];assert stat.S_ISREG(p.lstat().st_mode)
 assert pin(p)['sha256']==row['sha256'] and pin(p)['bytes']==row['bytes'];native_seen.add(row['relative_path'])
native_actual=set()
for dp,dn,fn in os.walk(N,followlinks=False):
 for n in dn:assert not (Path(dp)/n).is_symlink()
 for n in fn:
  p=Path(dp)/n;assert stat.S_ISREG(p.lstat().st_mode);native_actual.add(p.relative_to(N).as_posix())
assert native_actual==native_seen|{'artifact-manifest.json','handoff.json'} and len(native_seen)==65
native_closure=dict(handoff=pin(N/'handoff.json'),manifest=pin(N/'artifact-manifest.json'),files=65,seals=2,hidden_ignored_included=True)
phases=[];commands=[]
stage=load(P/'stages.json')
expected={r['name']:r['argv'] for r in stage['nine_fresh_gates']+stage['before_first_render_after_history']}
expected.update({'history-'+str(i):argv for i,argv in enumerate(stage['history_commands'],1)})
for phase in ['history-and-generation','remaining-offline-gates','vendored-gate','final-gates']:
 path=N/phase/'completion.json';value=load(path);assert value['status']=='phase_passed'
 phases.append(pin(path))
 for row in value['receipts']:
  assert row['argv']==expected[row['name']] and row['exit_code']==0 and row['cwd']==str(R)
  assert row['environment']==stage['environment']
  for k in ['stdout','stderr','runner_at_start','phase_start']:
   if k in row:verify(row[k])
  receipt=N/phase/(row['name']+'.execution.json')
  assert load(receipt)==row
  commands.append(dict(name=row['name'],receipt=pin(receipt),execution=row))
assert set(expected)=={c['name'] for c in commands} and len(commands)==12
for a,b in zip(commands,commands[1:]):assert a['execution']['finished_at']<=b['execution']['started_at']
qa=load(Q/'target-qa.json');tree=load(Q/'checkout-preservation.json')
assert qa['status']=='all_actual_maintained_target_and_preservation_checks_passed'
assert tree['status']=='complete_checkout_preservation_after_native_gates_passed'
for name in ['target','checkout']:
 receipt=load(Q/(name+'.execution.json'));assert receipt['exit_code']==0
 for k in ['helper_at_start','stdout','stderr']:verify(receipt[k])
for p in qa['inputs']:verify(p)
target=yaml.safe_load((R/TARGET).read_bytes());assert pin(R/TARGET)['sha256']=='a367fac8ac036416baaabc9d64ae1d9927e66e87ad1bb96e2883725fd14ce68b'
initial=load(H/'initial-record-check.json');assert initial['target']==pin(R/TARGET)
for p in initial['source_originals_rehashed']:verify(p)
for p in load(H/'rasterize.execution.json')['inputs']:verify(p)
save('actual-input-bindings.json',dict(status='passed',native_packet_closure=native_closure,phase_completions=phases,actual_commands=commands,root_target_QA=pin(Q/'target-qa.json'),root_checkout_QA=pin(Q/'checkout-preservation.json'),fresh_independent_record_check=pin(H/'initial-record-check.json'),old_objects_preservation='Root-executed full tree/graph checkers read independently; actual receipts inherited here, not rerun',native_review_saved=False))

# Copy compact complete reports/receipts. Whole scientific source bodies are already portable.
retained={}
def retain(p,rel):
 p=Path(p);dest=H/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 with dest.open('xb') as f:f.write(p.read_bytes())
 retained[str(p)]=dict(source=pin(p),copy=pin(dest),repository_path=DR+'/'+rel)
for p in [S/'REPORT.md',S/'paragraph-dispositions.json',S/'edge-dispositions.json',S/'identifier-dispositions.json',S/'reference-dispositions.json',S/'findings.json',S/'handoff.json',Path('/private/tmp/pathwaymech-next-237-provider-independent-review-20261012/REPORT.md'),Path('/private/tmp/pathwaymech-next-237-provider-independent-review-20261012/handoff.json'),Path('/private/tmp/pathwaymech-next-237-root-scientific-acceptance-20261012.json'),Path('/private/tmp/pathwaymech-next-237-canonical-output-independent-review-20261012/REPORT.md'),Path('/private/tmp/pathwaymech-next-237-canonical-output-independent-review-20261012/handoff.json'),Path('/private/tmp/pathwaymech-next-237-local-integration-independent-review-20261012/REPORT.md'),Path('/private/tmp/pathwaymech-next-237-local-integration-independent-review-20261012/handoff.json'),Path('/private/tmp/pathwaymech-next-237-local-adoption-20261012/receipt.json'),P/'stages.json',P/'handoff.json']:
 retain(p,'inherited/'+p.parent.name+'/'+p.name)
for p in [Q/'target-qa.json',Q/'checkout-preservation.json',Q/'check_target.py',Q/'check_checkout.py',Q/'run_qa.py']+[Q/(n+s) for n in ['target','checkout'] for s in ['.execution.json','.stdout','.stderr']]:retain(p,'root-qa/'+p.name)
for name in ['REPORT.md','execution-summary.json','actual-tool-provenance.json','handoff.json','artifact-manifest.json']:retain(N/name,'actual-native/'+name)
for row in phases:
 p=Path(row['path']);retain(p,'actual-native/'+str(p.relative_to(N)))
for command in commands:
 for item in [command['receipt'],command['execution']['stdout'],command['execution']['stderr']]:
  p=Path(item['path']);retain(p,'actual-native/'+str(p.relative_to(N)))
save('evidence-copy-bindings.json',dict(files=list(retained.values()),primary_bodies_duplicated=False))
ps=load(S/'paragraph-dispositions.json');es=load(S/'edge-dispositions.json');ids=load(S/'identifier-dispositions.json');refs=load(S/'reference-dispositions.json')
assert target['description'].split('\n\n')==[p['text'] for p in ps] and target['mechanistic_edges']==[e['edge'] for e in es]

# Native inspection precedes the immutable review judgments below.
technical=[p for p in ['conf/identifier_sources.json','data/identifier_authorities/ontology.json','data/identifier_authorities/sources.json']]
inspections={}
for kind in ['scientific','technical']:
 targets=[dict(target_id=target['id'],path=TARGET,label=target['label'],kind='maintained',ownership_note='Maintained scientific owner; generated graph and tables derive from exact accepted science.')] if kind=='scientific' else [dict(target_id='owner-'+str(i),path=p,label=p,kind='maintained',ownership_note='Primary configuration or authority owner; exact accepted native outputs and complete prior object preservation.') for i,p in enumerate(technical,1)]
 save(kind+'-targets.json',{'targets':targets})
 args=[PY,'-B','scripts/record_review.py','inspect','--targets',str(H/(kind+'-targets.json'))]
 for p in ['docs/record-review-profile.md','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','pages/records/MetaCyc_PWY-8131.html']+technical:
  args+=['--input',p]
 inspections[kind]=run(kind+'-inspect',args)
start=utc();evidence=[]
def ev(eid,kind,reference,summary,digest):
 evidence.append(dict(evidence_id=eid,kind=kind,reference=reference,accessed_at=utc(),support='supports',summary=summary,snapshot_sha256=digest))
ev('current-record','record_content',TARGET,'Fresh complete reading of the exact adopted YAML:12 paragraphs,38 edges,15 qualifiers,35 identities and31 references.',pin(R/TARGET)['sha256'])
for eid,name,summary in [('fresh-record','initial-record-check.json','Independent exact current claims, all120 locators, all96 source bodies and35 actual authority identities verified.'),('actual-bindings','actual-input-bindings.json','All12 actual native commands, complete stream descriptors, phase order and original argv/environment verified; no repeated broad gate.'),('visual','visual-assessment.json','Actual maintained SVG statically rasterized and personally inspected with native light CSS; dense layout and label truncation retained as limitations.')]:
 ev(eid,'validation',DR+'/'+name,summary,pin(H/name)['sha256'])
for eid,p in [('full-science',S/'REPORT.md'),('prior-paragraphs',S/'paragraph-dispositions.json'),('prior-edges',S/'edge-dispositions.json'),('prior-identities',S/'identifier-dispositions.json'),('prior-references',S/'reference-dispositions.json'),('provider-successor',Path('/private/tmp/pathwaymech-next-237-provider-independent-review-20261012/REPORT.md')),('native-output',Path('/private/tmp/pathwaymech-next-237-canonical-output-independent-review-20261012/REPORT.md')),('integration-preparation',Path('/private/tmp/pathwaymech-next-237-local-integration-independent-review-20261012/REPORT.md'))]:
  row=retained[str(p)];ev(eid,'prior_review',row['repository_path'],'Complete accepted predecessor read; interpretation inherited and matched against current content. Not a new full source-paper review.',row['source']['sha256'])
for eid,name in [('root-target','target-qa.json'),('root-tree','checkout-preservation.json')]:
 row=retained[str(Q/name)];ev(eid,'validation',row['repository_path'],'Actual root computational QA from independently read checker; complete receipt/streams and current input identity verified. This reviewer did not rerun it.',row['source']['sha256'])
checks=[]
for row in commands:
 eid='actual-'+row['name'];p=Path(row['receipt']['path']);ev(eid,'validation',retained[str(p)]['repository_path'],'Actual root-owned execution performed by sibling executor. Exact command, successful exit and complete stream hashes independently verified.',row['receipt']['sha256'])
 checks.append(dict(check_id=eid,name='Actual native '+row['name'],status='passed',required=row['name'] in {r['name'] for r in stage['nine_fresh_gates']},summary='Original successful execution; no repeat by this reviewer.',target_ids=[],command=shlex.join(row['execution']['argv']),exit_code=0,expected_exit_code=0,evidence_ids=[eid]))
for name,eid,summary in [('current-science','fresh-record','Fresh independent record/source/locator/authority comparison passed.'),('root-target','root-target','Root complete maintained graph/table/evidence and target preservation checks passed; checker and actual receipts independently read.'),('root-tree','root-tree','Root complete hidden/ignored physical-tree preservation and800 cache identity checks passed; actual receipts bound.'),('static-visual','visual','Fresh actual static graph viewed; full qualification remains in checked tables.')]:checks.append(dict(check_id=name,name=name,status='passed',required=True,summary=summary,target_ids=[],evidence_ids=[eid]))
checks.append(dict(check_id='browser-interaction',name='Browser interaction/responsive/dark checks',status='unavailable',required=False,summary='Static light raster and full source-to-DOM correspondence only; interactive behavior not tested.',target_ids=[],evidence_ids=['visual']))
limits=['Full primary scientific interpretation is inherited from the accepted separate review by this same independent scientific reviewer. Current work freshly reads the whole adopted record and all individual dispositions and replays120 locators/96 source hashes; it does not repeat the full-paper review.','The unavailable2020 SI and original main figure bodies, inaccessible exact tag orientation, unrendered2024 EMF and database-attributed older cited papers retain their accepted limits. No fresh figure-pixel or full comparative-genome audit is claimed.','ATCC25922 whole-route physiology remains distinct from MG1655 nucleosidase, Bacillus HD73/HD73-20 three-enzyme module and R.rubrum shared steps. Recombinant/tag/metal conditions and native reversible final reactions remain explicit.','Static actual light graph is tall, with truncated long construct/state labels and crowded shared-junction labels. Complete evidence/qualifications survive in checked tables. No keyboard, JavaScript, responsive or dark-theme result is claimed.','Root-owned actual native gates and target/tree QA are inherited from exact verified executions, not repeated by this reviewer. Whole authority output/first-owner preservation interpretation is inherited from accepted independent output review; no SQL full rehash or full builder was rerun.','The reviewer performed earlier237 independent science/provider/design review and authored its external canonical preparation. The record, local integration preparation, actual native builds/adoption/gates and root checkers were authored or executed by other agents. Current independence applies to adopted scientific content and review judgments; prior self-authored preparation is not independently certified here.','No maintained files, native reviews, cache, Git state or GitHub objects were written by this reviewer. Root owns exact evidence adoption, guarded final inspection/validation and append-only native saves. Resolved local provider attribution does not claim GitHub issue closure.']
summaries={}
for kind in ['scientific','technical']:
 ins=inspections[kind];tids=[t['target_id'] for t in ins['targets']];assessments=[]
 def assess(aid,area,topic,summary,eids,details=None,targets=None):
  a=dict(assessment_id=aid,area=area,topic=topic,outcome='supported',summary=summary,target_ids=tids if targets is None else targets,evidence_ids=eids)
  if details:a['details']=details
  assessments.append(a)
 findings=[]
 if kind=='scientific':
  for p in ps:assess('paragraph-'+str(p['paragraph_1based']),'evidence','Paragraph '+str(p['paragraph_1based']),'Inherited complete scientific assessment, freshly compared to unchanged current text: '+p['independent_assessment'],['current-record','prior-paragraphs','fresh-record'])
  for e in es:assess('edge-'+e['edge']['id'],'graph',e['edge']['id'],'Inherited complete edge/endpoint assessment, freshly matched to current whole object and source locators: '+e['independent_assessment'],['current-record','prior-edges','fresh-record'])
  for e in target['mechanistic_edges']:
   for q in e.get('endpoint_qualifiers',[]):assess('qualifier-'+e['id']+'-'+q['endpoint'],'scope',e['id']+' '+q['kind'],'The complete current qualification remains evidence-backed and rendered separately from reference protein identity: '+q['description'],['current-record','prior-edges','fresh-record','root-target'])
  for i,row in enumerate(ids,1):assess('identity-'+str(i),'identity',row['id'],'Inherited identity interpretation remains valid and the exact selected identity is now present in actual integrated authority: '+row['assessment'],['current-record','prior-identities','fresh-record','native-output'],'The earlier20 missing snapshot identities were integration-stage gaps; actual accepted output and current term comparison now establish their presence.')
  for i,row in enumerate(refs,1):
   changed=row['reference']['id']=='PMID:31950558'
   summary='Current NCBI BioC provider wording exactly implements the independently accepted successor, with unchanged correct paper identity, original hash and locators.' if changed else row['assessment']
   assess('reference-'+str(i),'provenance',row['reference']['id'],'Inherited reference judgment with fresh current original-byte binding: '+summary,['current-record','prior-references','fresh-record']+(['provider-successor'] if changed else []))
  assess('route-and-render','representation','Complete maintained route and graph','All four native events,14 written sides,three transfers,38 arrows,46 visual nodes,15 qualified endpoints,35 named identities and31 references are preserved. Both final native reactions remain reversible; the figure does not replace source scope.',['current-record','root-target','visual'])
  findings=[dict(finding_id='provider-attribution',issue_key='pwy8131-bioc-provider-attribution',category='provenance',severity='minor',status='resolved',certainty='confirmed',title='NCBI BioC provider attribution corrected in maintained record',description='The earlier external review found Europe PMC named for an NCBI BioC acquisition. Exact adopted references[1].source_version now says complete NCBI BioC main text. The paper body and scientific claims are unchanged. GitHub alias deoxy237-ncbi-bioc-provider-attribution maps to the same issue503.',target_ids=tids,field_paths=['references[1].source_version'],evidence_ids=['current-record','fresh-record','provider-successor','prior-references'],native_severity='minor',normalization_reason='Provider metadata correction without paper-identity or scientific-content defect.',disposition_reason='Accepted one-field successor is present in the actual maintained bytes; its real NCBI receipt and unchanged source hash were freshly verified.',previous_occurrences=[],external_issues=['https://github.com/CultureBotAI/PathwayMech/issues/503'])]
  title="5′-deoxyadenosine degradation II: accepted science and maintained QA"
  summary='Exact accepted scientific successor is retained; current complete record, identity, evidence and graph/table QA pass with inherited access and static visual limits. Provider attribution is resolved locally.'
 else:
  for i,t in enumerate(ins['targets'],1):assess('owner-'+str(i),'ownership',t['path'],'Exact current primary owner equals accepted integration payload and actual native source output; no runtime adapter or policy change.',['native-output','integration-preparation','root-target'],targets=[t['target_id']])
  assess('authorities','grounding','Complete actual authorities and effective manifest','Sources2633 terms/692 owners and ontology2011/five match actual native output. All prior whole owner/term objects and nested order remain exact. Actual869-row manifest retains855 old rows; stale831-row frozen-runtime manifest is not adopted. P0AF12 and CPLX0-1541 retain old first owners.',['native-output','integration-preparation','fresh-record','root-target'])
  assess('old-tree','provenance','Old scientific and generated owners','All237 old record/page pairs,118 saved review pairs,402 histories and800 cache identities remain exact. Only13 planned owner changes,10 generated owners andtwo new histories are permitted before evidence adoption.',['root-tree','root-target'])
  assess('graph-and-mappings','representation','Whole graph context preservation','Both actual KGX surfaces match4297 nodes/11987 edges. All11949 old edges and7966 old contexts retain complete payload/order/multiplicity. Fifteen shared-node contexts are added. Only CHEBI57642 aggregate display changes ASCII to Unicode minus; old context/canonical labels remain. No category or direction delta. SSSOM remains byte-identical with32 rows andzero additions.',['native-output','integration-preparation','root-target','actual-bindings'])
  assess('portable-originals','provenance','Complete portable scientific evidence','Accepted integration resolver independently rehashed2380 complete bodies/339540824 decoded bytes, preserving868 manifest originals and96 scientific originals. Current reference hashes and all96 original bytes were freshly checked; no claim to rerun the whole portable resolver or giant SQL hash here.',['integration-preparation','fresh-record','root-tree'])
  assess('gates','consistency','Actual histories and gates','Two native histories precede SSSOM and first render. Allnine required gates passed using exact stage argv/environment; complete actual receipt/stream hashes and chronological phases verified.',['actual-bindings','root-tree'])
  title='PWY-8131 authority integration: independent maintained review'
  summary='Three technical primary owners match accepted unchanged-runtime native outputs. Complete old-owner/context preservation and actual native gates pass; no adapter changes were needed.'
 local_checks=json.loads(json.dumps(checks))
 for c in local_checks:c['target_ids']=tids
 finish=utc();doc=dict(schema_version='1.0.0',review_id=finish.replace('-','').replace(':','')+'-deoxy237-'+kind,kind='record' if kind=='scientific' else 'repository',repository='CultureBotAI/PathwayMech',title=title,started_at=start,finished_at=finish,reviewer=dict(identity='Codex /root/deoxy237_science_review',kind='agent',independence='independent',independence_basis=limits[5]),skill='.claude/skills/review-yaml-record/SKILL.md',completion='completed',verdict='pass_with_limitations',scientific_review=kind=='scientific',summary=summary,source=ins['source'],scope=dict(description=summary,selection='Exact adopted237 integration at baseline290bd9781e43e473d88b9fd7c17f6f61da45092e before independent QA evidence adoption and native review saves.',coverage='full',population_size=len(tids),reviewed_target_ids=tids,exclusions=[dict(target='New full primary-paper review and full source/SQL builders',reason='Earlier full scientific interpretation and actual native output acceptance are inherited and pinned.'),dict(target='Native saves and publication',reason='Separate root-owned actions after guarded exact evidence adoption and final inspection.')]),targets=ins['targets'],checks=local_checks,evidence=evidence,assessments=assessments,findings=findings,actions=[],limitations=limits,notes=['The captured review interval begins after actual native inspection; complete manual reading and the independently timestamped current-record audit preceded it.','External predecessor reports have no native structured review identifiers. Stable issue503 review key and GitHub alias are retained without inventing previous_occurrences.','Historical scientific-review statements that authority integration or sibling adoption was pending describe the earlier frozen stage; current exact outputs/gates are separately assessed.','Draft content is external and schema-validated only. Final native saving remains root owned.'],links=['https://github.com/CultureBotAI/PathwayMech/issues/503'],tags=['deoxyadenosine','local-integration','independent-maintained-qa'])
 with (H/(kind+'-review.yaml')).open('x') as f:f.write(yaml.dump(doc,Dumper=Dumper,sort_keys=False,allow_unicode=True,width=100))
 run(kind+'-validate',[PY,'-B','scripts/record_review.py','validate',str(H/(kind+'-review.yaml'))])
 summaries[kind]=dict(targets=len(tids),assessments=len(assessments),findings=len(findings),draft=pin(H/(kind+'-review.yaml')))
save('draft-summary.json',summaries)
print(json.dumps(dict(status='external_native_content_validated_no_saves',drafts=summaries)))
