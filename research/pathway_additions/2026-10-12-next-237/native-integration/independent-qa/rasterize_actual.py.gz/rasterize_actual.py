"""Static actual maintained graph only; complete body/DOM QA remains separate."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess
from lxml import etree
H=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-237-local-20261012')
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
page=R/'pages/records/MetaCyc_PWY-8131.html';cssfile=R/'pages/assets/pathway-network.css';record=R/'data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml'
before=[pin(p) for p in [page,cssfile,record]]
assert before[0]['sha256']=='04943fb62ac6b0f655ace4935af2be4fb6dcb9a69d775712a3f5ffdda04cb889'
raw=re.search(r'<svg\b[^>]*class="pathway-network-svg"[^>]*>.*?</svg>',page.read_text(),re.S).group(0)
(H/'actual-graph.svg').write_text(raw)
css=cssfile.read_text().split('@media')[0]
for k,v in dict(re.findall(r'(--graph-[a-z]+):\s*([^;]+);',css)).items():css=css.replace('var('+k+')',v)
svg=etree.fromstring(raw.encode());style=etree.Element('{http://www.w3.org/2000/svg}style');style.text=css;svg.insert(0,style)
(H/'light-static-graph.svg').write_bytes(etree.tostring(svg))
cmd=['/usr/local/bin/rsvg-convert','-w','2200','-b','white','-o',str(H/'actual-graph.png'),str(H/'light-static-graph.svg')]
start=datetime.now(timezone.utc).isoformat()
with (H/'rasterize.stdout').open('xb') as out,(H/'rasterize.stderr').open('xb') as err:result=subprocess.run(cmd,stdout=out,stderr=err)
assert before==[pin(p) for p in [page,cssfile,record]]
receipt=dict(command=cmd,started_at=start,finished_at=datetime.now(timezone.utc).isoformat(),exit_code=result.returncode,helper=pin(Path(__file__)),inputs=before,stdout=pin(H/'rasterize.stdout'),stderr=pin(H/'rasterize.stderr'),outputs=[pin(H/n) for n in ['actual-graph.svg','light-static-graph.svg','actual-graph.png']],scope='Static native light-theme graph raster; no browser interaction or human assessment in this execution')
with (H/'rasterize.execution.json').open('x') as f:f.write(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));raise SystemExit(result.returncode)
