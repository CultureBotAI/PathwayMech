"""Capture actual final independent native content preparation (no saves)."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,os,time,sys
H=Path(__file__).resolve().parent;PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
p=H/'complete_native_drafts.py';argv=[PY,'-B',str(p)];bound=pin(p);start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();env=dict(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',UV_NO_SYNC='1')
with (H/'complete.stdout').open('xb') as out,(H/'complete.stderr').open('xb') as err:r=subprocess.run(argv,cwd=H,env=dict(os.environ,**env),stdout=out,stderr=err)
assert pin(p)==bound
v=dict(argv=argv,cwd=str(H),environment=env,started_at=start,finished_at=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-tick,exit_code=r.returncode,child_at_start=bound,wrapper=pin(__file__),stdout=pin(H/'complete.stdout'),stderr=pin(H/'complete.stderr'))
with (H/'complete.execution.json').open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
print(json.dumps(v));sys.exit(r.returncode)
