"""Final compact evidence/readback validation, no native saves or broad gate reruns."""
from pathlib import Path
import json,hashlib,stat,os
import yaml
H=Path(__file__).resolve().parent;Q=Path('/private/tmp/pathwaymech-next-237-root-maintained-qa-20261012');R=Path('/private/tmp/pathwaymech-next-237-local-20261012')
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
m=load(Q/'artifact-manifest.json');rows=m.get('artifacts',m.get('files'));seen=set()
for r in rows:
 p=Q/r['relative_path'];assert stat.S_ISREG(p.lstat().st_mode);v=pin(p);assert v['sha256']==r['sha256'] and v['bytes']==r['bytes'];seen.add(r['relative_path'])
actual=set()
for dp,dn,fn in os.walk(Q,followlinks=False):
 for n in dn:assert not (Path(dp)/n).is_symlink()
 for n in fn:actual.add((Path(dp)/n).relative_to(Q).as_posix())
assert actual==seen|{'artifact-manifest.json','handoff.json'} and len(seen)==16
copies=[]
for n in ['REPORT.md','handoff.json','artifact-manifest.json']:
 p=Q/n;q=H/'root-qa'/n
 with q.open('xb') as f:f.write(p.read_bytes())
 copies.append(dict(source=pin(p),copy=pin(q)))
qa=load(Q/'target-qa.json');assert all(c['passed'] for c in qa['checks'])
result={}
for kind in ['scientific','technical']:
 p=H/(kind+'-review.yaml');d=yaml.safe_load(p.read_bytes());ins=load(H/(kind+'-inspect.stdout'));assert d['source']==ins['source'] and d['targets']==ins['targets']
 assert d['findings']==[] and len(d['assessments'])==(132 if kind=='scientific' else 8)
 for row in d['source']['inputs']:assert pin(R/row['path'])['sha256']==row['sha256']
 assert all(a['outcome']=='supported' for a in d['assessments']);assert len({a['assessment_id'] for a in d['assessments']})==len(d['assessments'])
 result[kind]=dict(draft=pin(p),assessments=len(d['assessments']),evidence=len(d['evidence']),targets=len(d['targets']),inputs=len(d['source']['inputs']),verdict=d['verdict'],findings=0,source_exactly_matches_actual_inspect=True)
 if kind=='scientific':
  provider=[a for a in d['assessments'] if a['topic']=='PMID:31950558'];assert len(provider)==1 and 'pwy8131-bioc-provider-attribution' in provider[0]['summary'] and 'deoxy237-ncbi-bioc-provider-attribution' in provider[0]['summary']
  result[kind]['historical_provider_assessment']=provider[0]
 else:result[kind]['all_assessments']=d['assessments']
v=dict(status='final_current_inputs_and_complete_root_closure_passed',root_qa_closure=dict(handoff=pin(Q/'handoff.json'),manifest=pin(Q/'artifact-manifest.json'),artifacts=16,seals=2,hidden_ignored_included=True,all_target_checks_passed=len(qa['checks'])),copies=copies,drafts=result,native_save_performed=False)
with (H/'final-readback.json').open('x') as f:f.write(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(v,indent=2,ensure_ascii=False))
