"""Fresh adopted-record comparison, explicitly before final page/gate QA."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,xml.etree.ElementTree as ET
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-237-local-20261012')
S=Path('/private/tmp/pathwaymech-next-237-science-review-20261012')
A=Path('/private/tmp/pathwaymech-next-237-author-20261012')
P=R/'data/pathways/5-prime-deoxyadenosine-degradation-ii.yaml'
def read(p):return json.loads(Path(p).read_bytes())
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def sha(v):return hashlib.sha256(json.dumps(v,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
start=datetime.now(timezone.utc).isoformat()
assert pin(P)['sha256']=='a367fac8ac036416baaabc9d64ae1d9927e66e87ad1bb96e2883725fd14ce68b'
d=yaml.safe_load(P.read_bytes());paragraphs=read(S/'paragraph-dispositions.json');edges=read(S/'edge-dispositions.json');ids=read(S/'identifier-dispositions.json');refs=read(S/'reference-dispositions.json')
assert d['description'].split('\n\n')==[p['text'] for p in paragraphs]
assert d['mechanistic_edges']==[e['edge'] for e in edges]
named=[{'id':d['id'],'label':d['label']}]+[n for c in ['taxa','participants','reactions'] for n in d[c]]
assert named==[row['selected'] for row in ids]
reference_comparisons=[]
for actual,prior in zip(d['references'],refs):
 expected=dict(prior['reference'])
 if actual['id']=='PMID:31950558':expected['source_version']='2020 publication; complete NCBI BioC main text'
 assert actual==expected
 body=pin(prior['original']['path']);assert body==prior['original'] and body['sha256']==actual['source_sha256']
 reference_comparisons.append({'id':actual['id'],'original':body,'current_reference_sha256':sha(actual),'only_provider_correction':actual['id']=='PMID:31950558'})
assert (len(paragraphs),len(edges),len(ids),len(refs))==(12,38,35,31)
assert sum(len(e.get('endpoint_qualifiers',[])) for e in d['mechanistic_edges'])==15
sources=read(A/'sources.json');byhash={s['sha256']:Path(s['path']) for s in sources}
source_checks=[]
for s in sources:
 body=pin(s['path']);assert body['sha256']==s['sha256'] and body['bytes']==s['bytes']
 source_checks.append(body)
prior_locations=read(S/'locator-audit.json');locations=[]
byref={ref['id']:ref for ref in d['references']}
for e in d['mechanistic_edges']:
 for context,evs in [('edge',e['evidence'])]+[(f'endpoint_qualifiers[{i}]',q['evidence']) for i,q in enumerate(e.get('endpoint_qualifiers',[]))]:
  for i,ev in enumerate(evs):
   p=byhash[byref[ev['reference_id']]['source_sha256']];root=ET.parse(p).getroot();loc=ev['source_locator'];m=re.fullmatch(r'\(//(body//p|passage)\)\[(\d+)\]',loc)
   if m:hits=root.findall('.//'+m[1])[int(m[2])-1:int(m[2])]
   else:
    assert loc.startswith('/'+root.tag+'/');rel='./'+loc[len(root.tag)+2:]
    if '[dblink-db=' in rel:
     base,value=rel.split('[dblink-db=');hits=[x for x in root.findall(base) if x.findtext('dblink-db')==value.rstrip(']').strip('"')]
    else:hits=root.findall(rel)
   assert hits,(e['id'],loc)
   row={'edge':e['id'],'context':context,'index_0based':i,'reference':ev['reference_id'],'locator':loc,'source_assertion':ev.get('source_assertion',ev.get('quote')),'original':pin(p),'matched_xml':[ET.tostring(x,encoding='unicode') for x in hits]}
   assert row==prior_locations[len(locations)]
   locations.append({'edge':e['id'],'context':context,'reference':ev['reference_id'],'locator':loc,'source':row['original'],'match_count':len(hits),'exact_prior_resolution_sha256':sha(row)})
assert len(locations)==120 and len(source_checks)==96
authority={k:read(R/'data/identifier_authorities'/(k+'.json')) for k in ['sources','ontology']}
actual=Path('/private/tmp/pathwaymech-next-237-canonical-build-20261012')
for k in authority:assert (R/'data/identifier_authorities'/(k+'.json')).read_bytes()==(actual/(k+'.json')).read_bytes()
authority_results=[]
for n in named:
 matches=[(k,a['terms'][n['id']]) for k,a in authority.items() if n['id'] in a['terms']]
 assert len(matches)==1,n['id'];k,t=matches[0]
 authority_results.append({'id':n['id'],'authority':k,'term':t,'owner':authority[k]['sources'][t['source']]})
receipt=Path('/private/tmp/pathwaymech-next-237-preflight-20261012/inherited-packets/discovery/route-sources/requests/PMC7237333-BioC.xml.json')
rr=read(receipt);assert rr['requested_url']==rr['final_url']=='https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_xml/PMC7237333/unicode'
result={'status':'adopted_scientific_content_matches_accepted_successor_final_gates_pending','started_at':start,'finished_at':datetime.now(timezone.utc).isoformat(),'target':pin(P),'paragraphs':12,'edges':38,'qualifiers':15,'selected_identities':35,'references':31,'locators':locations,'source_originals_rehashed':source_checks,'reference_comparisons':reference_comparisons,'all_selected_authority_terms':authority_results,'provider_correction_receipt':pin(receipt),'page_QA_complete':False,'native_gate_acceptance':False,'primary_science':'Inherited complete accepted review; fresh current whole-record reading and exact claim comparisons, no fresh full-paper reading','native_review_saved':False}
with (H/'initial-record-check.json').open('x') as f:f.write(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','started_at','finished_at','target','paragraphs','edges','qualifiers','selected_identities','references','page_QA_complete','native_gate_acceptance']}))
