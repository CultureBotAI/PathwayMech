"""Verify final external native content, package exact durable evidence, then seal."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,os,stat
import yaml
H=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-237-local-20261012')
DR='research/pathway_additions/2026-10-12-next-237/native-integration/independent-qa'
def pin(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(Path(p).read_bytes())
def save(n,v):
 with (H/n).open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
results={}
for kind in ['scientific','technical']:
 d=yaml.safe_load((H/(kind+'-review.yaml')).read_bytes())
 for row in d['source']['inputs']:assert sha((R/row['path']).read_bytes())==row['sha256']
 for e in d['evidence']:
  p=H/e['reference'][len(DR)+1:] if e['reference'].startswith(DR+'/') else R/e['reference']
  assert sha(p.read_bytes())==e['snapshot_sha256'],e['evidence_id']
 assert d['completion']=='completed' and all(c['status']=='passed' for c in d['checks'] if c['required'])
 assert len(d['targets'])==(1 if kind=='scientific' else 3)
 assert len(d['assessments'])==(132 if kind=='scientific' else 8)
 assert not d['findings']
 assert all(f['status']=='resolved' for f in d['findings'])
 rec=load(H/(kind+'-validate.execution.json'));assert rec['exit_code']==0
 for k in ['stdout','stderr']:assert pin(rec[k]['path'])==rec[k]
 results[kind]=dict(draft=pin(H/(kind+'-review.yaml')),targets=len(d['targets']),assessments=len(d['assessments']),resolved_findings=len(d['findings']),evidence_bindings=len(d['evidence']),current_inputs=len(d['source']['inputs']))
save('final-draft-check.json',dict(status='both_native_drafts_and_evidence_bindings_passed',results=results,native_save_performed=False))
durable=[]
for row in load(H/'evidence-copy-bindings.json')['files']:
 p=Path(row['copy']['path']);assert pin(p)==row['copy'];gz=p.suffix=='.py'
 assert row['repository_path']==DR+'/'+p.relative_to(H).as_posix()
 durable.append({**row,'repository_path':row['repository_path']+'.gz' if gz else row['repository_path'],'gzip_encoded':gz,'decoded_sha256':row['copy']['sha256']})
save('durable-evidence-bindings.json',dict(files=durable,scope='Final payload encodes retained Python bodies as deterministic gzip; plain external map remains historical. Reports, actual commands and judgments unchanged.'))
assert (H/'REPORT.md').is_file() and (H/'read-coverage.json').is_file()
save('package-execution.json',dict(started_at=datetime.now(timezone.utc).isoformat(),helper=pin(__file__),status='binding_checks_passed_sealing_next',completion_scope='Final process completion is recorded by actual tool response, not predicted here.'))
files=sorted(p for p in H.rglob('*') if p.is_file() and 'payload' not in p.relative_to(H).parts and p.relative_to(H).as_posix() not in ['copy-plan.json','artifact-manifest.json','handoff.json'])
payload=H/'payload';payload.mkdir();rows=[]
for p in files:
 assert stat.S_ISREG(p.lstat().st_mode)
 rel=p.relative_to(H).as_posix();raw=p.read_bytes();gz=p.suffix=='.py';dest=rel+'.gz' if gz else rel;body=gzip.compress(raw,mtime=0) if gz else raw
 out=payload/dest;out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('xb') as f:f.write(body)
 assert (gzip.decompress(out.read_bytes()) if gz else out.read_bytes())==raw
 rows.append(dict(repository_path=DR+'/'+dest,payload_path=str(out),bytes=len(body),sha256=sha(body),source_path=str(p),decoded_sha256=sha(raw),decoded_bytes=len(raw),gzip_encoded=gz))
index=dict(status='ready_for_exact_root_adoption',durable_root=DR,files=[{k:v for k,v in r.items() if k not in ['payload_path','source_path']} for r in rows])
with (payload/'package-index.json').open('x') as f:f.write(json.dumps(index,indent=2)+'\n')
p=pin(payload/'package-index.json');rows.append(dict(repository_path=DR+'/package-index.json',payload_path=p['path'],bytes=p['bytes'],sha256=p['sha256'],gzip_encoded=False))
save('copy-plan.json',dict(durable_root=DR,files=rows,root_evidence=[],native_save_performed=False,maintained_writes_performed=False,after_adoption='Root runs exact retained finalize_native_inputs.py into a new external output directory, inspects and saves unchanged judgments, then checks append-only preservation.'))
artifacts=[];dirs=[]
for dp,dn,fn in os.walk(H,followlinks=False):
 for name in dn:
  p=Path(dp)/name;assert not p.is_symlink();dirs.append(p.relative_to(H).as_posix())
 for name in fn:
  p=Path(dp)/name;assert stat.S_ISREG(p.lstat().st_mode)
  if p.relative_to(H).as_posix() not in ['artifact-manifest.json','handoff.json']:
   row=pin(p);artifacts.append(dict(relative_path=p.relative_to(H).as_posix(),type='regular',bytes=row['bytes'],sha256=row['sha256']))
save('artifact-manifest.json',dict(artifacts=sorted(artifacts,key=lambda r:r['relative_path']),directories=sorted(dirs),hidden_ignored_included=True,aliases=0))
save('handoff.json',dict(status='actual237_maintained_qa_pass_with_limits_external_native_content_validated',reviewer='Codex /root/deoxy237_science_review',at=datetime.now(timezone.utc).isoformat(),open_findings=[],historical_corrected_external_findings=['pwy8131-bioc-provider-attribution'],artifacts=len(artifacts),seals=2,manifest=pin(H/'artifact-manifest.json'),report=pin(H/'REPORT.md'),copy_plan=pin(H/'copy-plan.json'),native_drafts=[pin(H/(kind+'-review.yaml')) for kind in ['scientific','technical']],actual_input_bindings=pin(H/'actual-input-bindings.json'),limitations='Inherited full primary science/output interpretation; fresh full adopted content and locator/source/authority checks plus actual static graph inspection. Root-owned broad gates/whole-target/tree QA are independently bound, not rerun. No native save or maintained write by reviewer.',next='Separate root acceptance, exact evidence adoption, guarded native input extension, immutable save/check and append-only preservation.'))
print(json.dumps(dict(handoff=pin(H/'handoff.json'),manifest=pin(H/'artifact-manifest.json'),artifacts=len(artifacts),payload_files=len(rows),drafts=results)))
