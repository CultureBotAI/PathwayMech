import ast
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path

P = Path('/private/tmp/pathwaymech-next-237-native-runner-preparation-20261012')
RUNNER = Path('/private/tmp/pathwaymech-next-237-root-run-native-20261012.py')
OLD = Path('/private/tmp/pathwaymech-next-236-root-run-native-20261012.py')
PREP = Path('/private/tmp/pathwaymech-next-237-local-integration-preparation-20261012')

def pin(p):
    assert p.is_file() and not p.is_symlink()
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(p, x):
    with p.open('x') as s:
        json.dump(x, s, indent=2)
        s.write('\n')

body = RUNNER.read_bytes()
syntax = ast.parse(body)
constants = {n.targets[0].id: ast.literal_eval(n.value) for n in syntax.body if isinstance(n, ast.Assign) and isinstance(n.value, (ast.Constant, ast.Tuple))}
for name, relative in [('EXPECTED_STAGE', 'stages.json'), ('EXPECTED_HANDOFF', 'handoff.json'), ('EXPECTED_PLAN', 'plan.json'), ('EXPECTED_SEMANTIC', 'semantic-preservation.json')]:
    assert constants[name] == pin(PREP / relative)['sha256']
stages = json.loads((PREP / 'stages.json').read_bytes())
semantic = json.loads((PREP / 'semantic-preservation.json').read_bytes())['SSSOM']
phases = {
    'history-and-generation': [{'name': f'history-{i+1}', 'argv': a} for i, a in enumerate(stages['history_commands'])] + stages['before_first_render_after_history'] + stages['nine_fresh_gates'][:2],
    'remaining-offline-gates': stages['nine_fresh_gates'][2:6],
    'vendored-gate': stages['nine_fresh_gates'][6:7],
    'final-gates': stages['nine_fresh_gates'][7:],
}
assert tuple(phases) == constants['PHASES']
assert [r['name'] for v in phases.values() for r in v] == ['history-1', 'history-2', 'sssom', 'render', 'skills', 'validate', 'tests', 'lint', 'kgx', 'vendored', 'diff-check', 'site-current']
assert semantic['old_rows'] == semantic['expected_total_rows'] == 32
assert semantic['expected_added_rows'] == []
assert not os.path.lexists('/private/tmp/pathwaymech-next-237-local-native-execution-20261012')
(P / 'runner.py').write_bytes(body)
(P / 'predecessor-runner.py').write_bytes(OLD.read_bytes())
(P / 'runner.diff').write_text(''.join(difflib.unified_diff(OLD.read_text().splitlines(keepends=True), body.decode().splitlines(keepends=True), fromfile=str(OLD), tofile=str(RUNNER))))
(P / 'sealing-helper.py').write_bytes(Path(__file__).read_bytes())
inputs = [PREP / name for name in ['handoff.json', 'artifact-manifest.json', 'stages.json', 'plan.json', 'semantic-preservation.json']]
inputs += [Path('/private/tmp/pathwaymech-next-237-root-local-integration-acceptance-20261012.json'), Path('/private/tmp/pathwaymech-next-237-local-adoption-20261012/receipt.json')]
write(P / 'static-checks.json', {'status': 'passed', 'at': datetime.datetime.now(datetime.UTC).isoformat(), 'runner': pin(RUNNER), 'predecessor': pin(OLD), 'inputs': [pin(p) for p in inputs], 'syntax_parse': True, 'four_pinned_preparation_inputs_exact': True, 'phase_commands': phases, 'history_before_generation': True, 'SSSOM_old_rows': 32, 'SSSOM_added_rows': 0, 'SSSOM_whole_bytes_required': True, 'runner_imported_or_executed': False, 'native_output_directory_absent_at_check': True, 'retained_origin_guards': ['whole runner at phase start', 'phase-start receipt creation pin', 'each command execution receipt creation pin', 'stdout/stderr creation hashes', 'adoption/approval and stage-plan pins through phase completion', 'previous phase streams and receipt origins checked before next phase'], 'limits': ['Static inspection and lint only; no execution of native runner or synthetic phase tests in this preparation.', 'Literal file guards reject symlinks at pinned leaf paths; do not claim protection against all parent-directory replacement races.']})
write(P / 'preparation-command-history.json', {'retrospective_tool_receipts': [
    {'tool_chunk': '66624d', 'action': 'Ruff format initial runner', 'exit_code': 0, 'streams': ['format.stdout', 'format.stderr']},
    {'tool_chunk': 'f2a081', 'action': 'Ruff check initial formatted runner', 'exit_code': 1, 'streams': ['lint.stdout', 'lint.stderr'], 'findings': 'Four UP017 timezone aliases and one B905 strict zip flag; exact pre-fix body retained.'},
    {'tool_chunk': 'f220f1', 'action': 'Ruff check successor runner', 'exit_code': 0, 'streams': ['lint-successor.stdout', 'lint-successor.stderr']},
    {'tool_chunk': '88a9d4', 'action': 'Rebase actual adoption path and exact acceptance contract; Ruff check', 'exit_code': 0, 'streams': ['actual-rebase-lint.stdout', 'actual-rebase-lint.stderr']}], 'history_note': 'Tool IDs and exit codes transcribed from actual tool outputs; this preparation does not invent wall-clock receipts for earlier tool calls. Initial approval fields were placeholders in an unexecuted draft and were replaced with the actual root acceptance digest and target/baseline/handoff bindings. A read-only combined source display was truncated; full stages/acceptance/adoption were visible and semantic data was then consumed whole programmatically; no truncated whole-semantic manual-read claim.'})
(P / 'REPORT.md').write_text('''The exact 237 native runner is prepared and statically checked against the accepted local integration plan. The root has accepted preparation and adopted exactly 13 owners; execution authorization arrived before this final seal. No native phase has run at this seal.\n\nThe four explicit phases contain two history commands, SSSOM, and the nine accepted gates in their existing order. Both histories precede SSSOM and rendering. SSSOM must retain all 32 existing rows and its exact whole bytes. No native review save, Git commit, push, PR, merge, or branch deletion command is present. The vendored gate remains a separate phase because it can require public read-only network access.\n\nThe runner is rebased from the completed 236 helper. It pins the actual 237 acceptance digest, adoption receipt, handoff, plan, semantic expectations and stages, and verifies the expected baseline HEAD. Every phase retains the exact runner body and its creation-time phase receipt; each command records actual start/end times, duration, argv, environment overrides, exit status and both stream hashes. First-created receipt hashes are held through final completion and checked before the next phase. Existing phase folders cannot be overwritten.\n\nThe initial lint failure and five fixes are retained along with the exact pre-fix body and succeeding lint streams. The first unexecuted runner had provisional adoption path/approval fields; its complete body is retained before rebase to the real root contract. Static AST parsing, four input pins, complete phase order and zero-addition SSSOM checks pass. No executed native or synthetic phase-test claim is made here. The stronger origin checks were read as code; actual evidence will be produced only by later authorized runs. Leaf files are checked against literal symlinks, without a claim of adversarial parent-directory race resistance.\n\nThe final executable is the top-level path recorded in static-checks.json. runner.py is an inert exact retained copy. This packet is immutable after the manifest/handoff seal; actual executions belong to the separate local-native-execution directory.\n''')
rows = []
directories = []
for current, dirs, files in os.walk(P, followlinks=False):
    for name in dirs:
        q = Path(current) / name
        assert not q.is_symlink()
        directories.append(str(q.relative_to(P)))
    for name in files:
        q = Path(current) / name
        assert name not in {'artifact-manifest.json', 'handoff.json'}
        row = pin(q); row['relative_path'] = str(q.relative_to(P)); row['kind'] = 'regular_file'
        rows.append(row)
rows.sort(key=lambda r: r['relative_path'])
write(P / 'artifact-manifest.json', {'files': rows, 'directories': sorted(directories), 'walk': 'literal os.walk, includes ignored and hidden entries, rejects symlinks'})
write(P / 'handoff.json', {'status': 'prepared_and_sealed_not_executed', 'runner': pin(RUNNER), 'manifest': pin(P / 'artifact-manifest.json'), 'artifact_count': len(rows), 'directories': len(directories), 'native_execution_performed': False, 'adoption_already_completed_by_root': True})
print(json.dumps({'handoff': pin(P / 'handoff.json'), 'manifest': pin(P / 'artifact-manifest.json'), 'runner': pin(RUNNER), 'artifacts': len(rows)}, indent=2))
