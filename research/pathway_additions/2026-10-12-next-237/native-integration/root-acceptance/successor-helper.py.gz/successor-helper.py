"""Bind root's reviewed native judgments and exact lossless local finalization inputs."""
import datetime,gzip,hashlib,json,os,stat
from pathlib import Path,PurePosixPath
import yaml

P=Path('/private/tmp/pathwaymech-next-237-maintained-independent-qa-20261012')
F=Path('/private/tmp/pathwaymech-next-237-finalization-preparation-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def closure(root,h,m):
 assert pin(root/'handoff.json')['sha256']==h
 assert pin(root/'artifact-manifest.json')['sha256']==m
 doc=json.loads((root/'artifact-manifest.json').read_text());rows=doc.get('artifacts',doc.get('files'));files=set();dirs=set()
 for parent,ds,fs in os.walk(root,followlinks=False):
  for name in ds:
   q=Path(parent)/name;assert stat.S_ISDIR(q.lstat().st_mode) and not q.is_symlink();dirs.add(str(q.relative_to(root)))
  for name in fs:
   q=Path(parent)/name;assert stat.S_ISREG(q.lstat().st_mode) and not q.is_symlink();files.add(str(q.relative_to(root)))
 assert files=={x['relative_path'] for x in rows}|{'handoff.json','artifact-manifest.json'}
 assert dirs==set(doc['directories'])
 for row in rows:
  got=pin(root/row['relative_path']);assert all(got[k]==row[k] for k in ('bytes','sha256'))
 return {'handoff':pin(root/'handoff.json'),'manifest':pin(root/'artifact-manifest.json'),'artifacts':len(rows),'directories':len(dirs),'seals':2,'hidden_ignored_included':True}

peer=closure(P,'f65993decc4347e9dddde87b7817d076f0b63bcf931ccd37f5eb3393fd8b71f5','b2ab96cb9fc9bfa057beed65c72dc1da94883925d9bc324c49d4bff043d8b676')
prep=closure(F,'140a995d5f527cc7a86c7cc3ad3d3e5fc5f934576d862caa7f8eaa4114ce35aa','4b3a4c8c3df2195cb3ea98fdbaf0cab3847f7bd153321c935645a37128187a42')
plan=json.loads((P/'copy-plan.json').read_text());seen=set()
for row in plan['files']:
 rel=PurePosixPath(row['repository_path']);assert not rel.is_absolute() and '..' not in rel.parts
 assert str(rel).startswith(plan['durable_root']+'/') and str(rel) not in seen;seen.add(str(rel))
 b=Path(row['payload_path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
 decoded=gzip.decompress(b) if row['gzip_encoded'] else b
 if 'source_path' in row:
  assert len(decoded)==row['decoded_bytes'] and hashlib.sha256(decoded).hexdigest()==row['decoded_sha256']
  assert decoded==Path(row['source_path']).read_bytes()
 else:
  assert str(rel)==plan['durable_root']+'/package-index.json' and not row['gzip_encoded']
  index=json.loads(b);assert index['durable_root']==plan['durable_root']
  assert index['files']==[{k:v for k,v in r.items() if k not in ('payload_path','source_path')} for r in plan['files'] if 'source_path' in r]
drafts=[]
for kind,expected,n in [('scientific','e4a6f953f1b76f2a99a13f13026fc8ee21b5675af30a0dd538c93a5806a1bfac',132),('technical','f9faaf1dee2ca209338062384db6db982da9291652fab3314db02a55c9fe75c9',8)]:
 path=P/(kind+'-review.yaml');assert pin(path)['sha256']==expected
 d=yaml.safe_load(path.read_bytes());assert len(d['assessments'])==n and not d['findings']
 assert d['source']['git_revision']=='290bd9781e43e473d88b9fd7c17f6f61da45092e'
 assert all(c['status']=='passed' for c in d['checks'] if c['required'])
 assert d['verdict']=='pass_with_limitations'
 drafts.append(dict(pin(path),review_id=d['review_id'],assessments=n))
assert pin(P/'finalize_native_inputs.py')['sha256']=='313422118bfc726ca607ce2fb184bbbf34f998ae63507719967fcd72db2497a4'
out={'at':datetime.datetime.now(datetime.UTC).isoformat(),'status':'maintained_peer_judgments_and_local_finalization_accepted','peer':peer,'finalization_preparation':prep,'native_drafts':drafts,'copy_plan':pin(P/'copy-plan.json'),'verified_payloads':len(seen),'verified_lossless_original_payloads':len(seen)-1,'derived_package_indexes':1,'retained_root_helper_diagnostic':{'helper':pin(Path('/private/tmp/pathwaymech-next-237-accept-maintained-qa-20261012.py')),'tool':'080d22','exit_code':1,'reason':'Initial reader assumed derived package-index has original-only decoded_bytes/source_path fields; successor checks exact derived-index equality. No packet or target changed.'},'finalizer':pin(P/'finalize_native_inputs.py'),'root_QA_handoff':pin(Path('/private/tmp/pathwaymech-next-237-root-maintained-qa-20261012/handoff.json')),'manual_read_scope':'Root read complete peer REPORT/read-coverage, all132 SCI and8 TECH assessment summaries and all SCI notes, reviewer independence, scope and scientific/static limits. Full accepted source interpretation remains inherited. Root read complete finalizer and local finalization plan; 143 original payloads decoded byte-for-byte to their sources and the derived package index compared to exact rows. Native check commands bind actual successful prior executions; no broad rerun.','authorization':'Execute exact local plan: durable evidence adoption, guarded fresh native input extension, same judgments/times, two native saves, append-only check, bounded physical/index staging and local commit/postcommit. Any staged whitespace failure requires separate root appraisal of every exact original-byte exception before proceeding; no inferred broad exclusion.','provider_resolution':'Already-applied source provider correction recorded as evidence-linked reference assessment with stable external key and issue503 alias. No invented native predecessor or GitHub closure.','prohibited':['public push','PR creation','merge','branch deletion','issue closure','source normalization','licensing clearance'],'publication_authorized':False,'helper':pin(Path(__file__))}
path=Path('/private/tmp/pathwaymech-next-237-root-maintained-review-acceptance-20261012.json')
with path.open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps(pin(path)))
