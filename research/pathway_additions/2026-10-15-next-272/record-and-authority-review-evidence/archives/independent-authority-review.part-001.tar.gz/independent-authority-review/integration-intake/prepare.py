"""Prepare the reviewed 97-source delta and preserve every previous owner."""

from __future__ import annotations

import hashlib
import json
import shutil
from datetime import UTC, datetime
from pathlib import Path

import yaml
from pathwaymech.identifiers import _load_authority
from scripts.build_source_identifier_snapshot import build_snapshot

OWN = Path(__file__).resolve().parent
WT = Path("/private/tmp/pathwaymech-next-272-20261015")
GRAPH = Path("/private/tmp/pathwaymech-next-272-graph-design")
ONTOLOGY = Path("/private/tmp/pathwaymech-next-272-ontology-order-successor")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def order(value):
    if isinstance(value, dict):
        return [(k, order(v)) for k, v in value.items()]
    if isinstance(value, list):
        return [order(v) for v in value]
    return value


graph_path = GRAPH / "results/recommended-selected-graph-payload.json"
assert sha(graph_path.read_bytes()) == (
    "3a5438516cb6bd82075e575dbb152eaba84337ac8371a400b8b6ce964506a29e"
)
graph = json.loads(graph_path.read_text())
closure = {
    row["reference_id"]: row
    for row in json.loads((GRAPH / "results/source-closure.json").read_text())
}
refs = {row["id"]: row for row in graph["references"]}
base = {}
for name, relative in {
    "sources": "data/identifier_authorities/sources.json",
    "ontology": "data/identifier_authorities/ontology.json",
    "conf": "conf/identifier_sources.json",
}.items():
    source = WT / relative
    target = OWN / "baseline" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == source.read_bytes()
    else:
        shutil.copyfile(source, target)
    base[name] = json.loads(target.read_text())
all_old = base["sources"]["terms"] | base["ontology"]["terms"]
nodes = [
    {"id": graph["id"], "label": "ethanolamine utilization"},
    *graph["participants"],
    *graph["reactions"],
    *graph["taxa"],
]
assert len(nodes) == len({n["id"] for n in nodes}) == 128
new_ids = {n["id"] for n in nodes if n["id"] not in all_old}
assert len(new_ids) == 101
entries = json.loads((WT / "tests/fixtures/ethanolamine_authority/manifest.json").read_text())
assert len(entries) == 63
entries = [{**e, "path": "ethanolamine272/" + e["path"]} for e in entries]
for node in nodes:
    ident = node["id"]
    if not ident.startswith("UniProtKB:"):
        continue
    row = closure[ident]
    raw = (Path(row["owner"]) / row["path"]).read_bytes()
    data = json.loads(raw)
    assert data["primaryAccession"] == ident.split(":", 1)[1]
    receipt_row = row["acquisition_evidence"]["receipts"][0]
    receipt = json.loads(Path(receipt_row["path"]).read_text())
    assert receipt["sha256"] == row["sha256"] == sha(raw)
    headers = {k.lower(): v for k, v in receipt["headers"].items()}
    release = headers["x-uniprot-release"]
    audit = data["entryAudit"]
    entries.append(
        {
            "key": "ethanolamine272-uniprotkb-" + data["primaryAccession"].lower(),
            "kind": "uniprot",
            "path": "ethanolamine272/" + Path(row["path"]).name,
            "url": receipt["url"],
            "version": f"UniProt {release}; entryVersion {audit['entryVersion']}; "
            f"sequenceVersion {audit['sequenceVersion']}",
            "license": "CC-BY-4.0",
            "sha256": row["sha256"],
        }
    )
assert len(entries) == 97
bindings = []
for entry in entries:
    if entry["kind"] == "uniprot":
        ident = "UniProtKB:" + entry["url"].rsplit("/", 1)[1].removesuffix(".json")
    else:
        ident = (
            entry["url"].split("?", 1)[1].replace("META:", "MetaCyc:").replace("ECOLI:", "EcoCyc:")
        )
    assert ident in new_ids
    row = closure[ident]
    source = Path(row["owner"]) / row["path"]
    raw = source.read_bytes()
    assert sha(raw) == row["sha256"] == entry["sha256"] == refs[ident]["source_sha256"]
    target = OWN / "cache" / entry["path"]
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    evidence = row["acquisition_evidence"]
    if isinstance(evidence, str):
        assert ident == "EcoCyc:ETHAMLY-CPLX"
        p = Path(row["owner"]) / "receipts/ECOLI-ETHAMLY-CPLX.xml.json"
        evidence = {"receipts": [{"path": str(p), "sha256": sha(p.read_bytes())}]}
    retained = []
    for i, receipt in enumerate(evidence.get("receipts", [])):
        p = Path(receipt["path"])
        assert sha(p.read_bytes()) == receipt["sha256"]
        dest = OWN / "acquisition" / (Path(entry["path"]).name + f".receipt-{i}.json")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)
        retained.append({"path": str(dest.relative_to(OWN)), "sha256": receipt["sha256"]})
    if not retained:
        assert ident == "MetaCyc:ACETALD"
        assert evidence["historical_reuse_bindings"]
    bindings.append(
        {
            "id": ident,
            "source": str(source),
            "cache_path": entry["path"],
            "sha256": sha(raw),
            "bytes": len(raw),
            "receipt_copies": retained,
            "acquisition_evidence": evidence,
            "request_scope": "No new acquisition occurred. Source URL validates issuer identity; "
            "a retained receipt, when present, binds actual historical request. "
            "ACETALD is exact historical reuse with no matching receipt.",
        }
    )
dump(OWN / "new-source-manifest.json", entries)
dump(OWN / "source-bindings.json", bindings)
selection = {"id": graph["id"]}
for section in ("participants", "reactions"):
    selection[section] = [
        n
        for n in graph[section]
        if n["id"] in new_ids and n["id"].split(":", 1)[0] in {"MetaCyc", "EcoCyc", "UniProtKB"}
    ]
selected = OWN / "selection"
selected.mkdir(exist_ok=True)
(selected / "authority-routing-only.yaml").write_text(yaml.safe_dump(selection, sort_keys=False))
delta = build_snapshot(OWN / "new-source-manifest.json", selected, OWN / "cache")
assert len(delta["sources"]) == len(delta["terms"]) == 97
assert set(delta["terms"]) == {row["id"] for row in bindings}
dump(OWN / "source-additions.json", delta)
merged = json.loads(json.dumps(base["sources"]))
for section in ("sources", "terms"):
    assert not (merged[section].keys() & delta[section].keys())
    merged[section].update(delta[section])
    assert list(merged[section])[: len(base["sources"][section])] == list(base["sources"][section])
    for key, value in base["sources"][section].items():
        assert order(merged[section][key]) == order(value)
dump(OWN / "sources.json", merged)
_load_authority(OWN / "sources.json")
ontology_raw = (ONTOLOGY / "proposed-ontology.json").read_bytes()
assert sha(ontology_raw) == "8ab396c8de205cbdbb8ade07795536a4b20eec59f5ad4fe5afbc08c1486975c6"
assert (ONTOLOGY / "baseline.json").read_bytes() == (
    WT / "data/identifier_authorities/ontology.json"
).read_bytes()
(OWN / "ontology.json").write_bytes(ontology_raw)
ontology = json.loads(ontology_raw)
_load_authority(OWN / "ontology.json")
assert len(ontology["terms"]) - len(base["ontology"]["terms"]) == 4
for node in nodes:
    term = (merged["terms"] | ontology["terms"])[node["id"]]
    assert node["label"] == term["label"], (node["id"], node["label"], term["label"])
assert not ({e["key"] for e in entries} & {e["key"] for e in base["conf"]})
dump(OWN / "identifier_sources.json", base["conf"] + entries)
receipt = {
    "created_at": datetime.now(UTC).isoformat(),
    "status": "Prepared candidate; independent authority/integration review pending; not adopted",
    "graph_sha256": sha(graph_path.read_bytes()),
    "native_additions": 63,
    "uniprot_additions": 34,
    "ontology_additions": 4,
    "existing_selected_terms_preserved": 27,
    "prior_source_terms": len(base["sources"]["terms"]),
    "result_source_terms": len(merged["terms"]),
    "result_ontology_terms": len(ontology["terms"]),
    "all_128_selected_labels_match": True,
    "prior_source_objects_and_recursive_order_preserved": True,
    "source_snapshot_sha256": sha((OWN / "sources.json").read_bytes()),
    "ontology_snapshot_sha256": sha(ontology_raw),
    "source_manifest_sha256": sha((OWN / "identifier_sources.json").read_bytes()),
    "scope": "Only 97 source additions projected. Existing complete source and ontology "
    "snapshots loaded through actual consumer; old owner bytes/order retained. "
    "Four ontology terms use separately accepted pinned extractor/source review. "
    "No historical full-source rebuild, new download or new whole-database hash.",
}
dump(OWN / "preparation-result.json", receipt)
print(json.dumps(receipt))
