"""Independent finite originals, producer/consumer and adversarial boundary audit."""

import base64
import collections
import copy
import gzip
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET

from pathwaymech.biocyc_ethanolamine import (
    FIELD,
    PROFILES,
    ethanolamine_metadata,
    ethanolamine_term,
    validate_ethanolamine_assertions,
)

from pathwaymech.identifiers import _load_authority
from scripts.build_source_identifier_snapshot import build_snapshot

OWNER = Path("/private/tmp/pathwaymech-next-272-independent-authority-review")
WORK = Path("/private/tmp/pathwaymech-next-272-20261015")
GRAPH = Path("/private/tmp/pathwaymech-next-272-graph-design")
FIXTURES = WORK / "tests/fixtures/ethanolamine_authority"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    checks = []
    mutations = []
    staged = OWNER / "staged-originals"
    staged.mkdir(exist_ok=True)
    entries = json.loads((FIXTURES / "manifest.json").read_text())
    storage = json.loads((FIXTURES / "storage.json").read_text())
    closure = {
        r["reference_id"]: r
        for r in json.loads((GRAPH / "results/source-closure.json").read_text())
    }
    selected = {
        r["id"]: r
        for r in json.loads((GRAPH / "results/node-ledger.json").read_text())
        if r["proposed_declaration"]
    }
    old = json.loads((GRAPH / "baseline/data/identifier_authorities/sources.json").read_text())[
        "terms"
    ]
    expected = {
        key for key in selected if key.startswith(("MetaCyc:", "EcoCyc:")) and key not in old
    }
    by_id = {}
    metadata = {}
    slots = []

    def check(label, actual, wanted=True):
        checks.append(
            {"check": label, "pass": actual == wanted, "actual": actual, "expected": wanted}
        )

    def snapshot(meta, key="exact"):
        ident, term = ethanolamine_term(meta, key)
        return {"version": 1, "sources": {key: meta}, "terms": {ident: term}}

    def consumer(value, path):
        path.write_text(json.dumps(value))
        return _load_authority(path)

    for entry in entries:
        pgdb, frame = entry["url"].split("?", 1)[1].split(":", 1)
        ident = ("MetaCyc" if pgdb == "META" else "EcoCyc") + ":" + frame
        by_id[ident] = entry
        item = storage[entry["path"]]
        packed = (FIXTURES / item["path"]).read_bytes()
        check("compressed hash " + ident, sha(packed), item["compressed_sha256"])
        raw = gzip.decompress(packed)
        check("fixture original hash " + ident, sha(raw), entry["sha256"])
        actual_source = Path(closure[ident]["owner"]) / closure[ident]["path"]
        check(
            "fixture equals accepted biological original " + ident,
            raw == actual_source.read_bytes(),
        )
        (staged / entry["path"]).write_bytes(raw)
        root = ET.fromstring(raw)
        own = next(n for n in root if n.tag != "metadata")
        check("issuing object " + ident, [own.get("orgid"), own.get("frameid")], [pgdb, frame])
        check(
            "own complete slot count " + ident,
            collections.Counter(n.tag for n in own),
            PROFILES[ident]["slots"],
        )
        for i, child in enumerate(own):
            slots.append(
                {
                    "id": ident,
                    "ordinal": i + 1,
                    "tag": child.tag,
                    "sha256": sha(ET.tostring(child)),
                    "text": "".join(child.itertext()),
                }
            )
        meta = ethanolamine_metadata(entry, staged)
        metadata[ident] = meta
        value = snapshot(meta)
        term = value["terms"][ident]
        check("label agrees with accepted graph " + ident, term["label"], selected[ident]["label"])
        check("raw bytes roundtrip " + ident, base64.b64decode(meta[FIELD]["original_base64"]), raw)
        check(
            "consumer terms exact " + ident,
            consumer(value, OWNER / "roundtrip.json"),
            value["terms"],
        )
        check(
            "all raw slots roundtrip " + ident,
            [r["xml"] for r in meta[FIELD]["projection"]["slots"]],
            [ET.tostring(n, encoding="unicode") for n in own],
        )
    check("exact selected missing native identity scope", sorted(by_id), sorted(expected))
    check("adapter exact selected scope", sorted(PROFILES), sorted(expected))
    check("selected source count", len(by_id), 63)
    check("independent full own-slot inventory", len(slots), 1468)
    (OWNER / "independent-own-slot-inventory.json").write_text(json.dumps(slots, indent=2) + "\n")

    def rejects(label, boundary, thunk):
        try:
            thunk()
        except (ValueError, ET.ParseError) as error:
            mutations.append(
                {
                    "mutation": label,
                    "boundary": boundary,
                    "rejected": True,
                    "error_type": type(error).__name__,
                    "message": str(error),
                }
            )
        else:
            mutations.append({"mutation": label, "boundary": boundary, "rejected": False})

    # All63 profiles: re-pinned originals with preserved top slot counts still
    # cannot adopt a second identity or an incompatible embedded source database.
    for ident, entry in by_id.items():
        raw = (staged / entry["path"]).read_bytes()
        for mutation in [
            "top_dual_identity",
            "embedded_consistent_foreign_pgdb",
            "nonblank_own_tail",
        ]:
            root = ET.fromstring(raw)
            own = next(n for n in root if n.tag != "metadata")
            if mutation == "top_dual_identity":
                own.set("resource", "getxml?" + own.get("orgid") + ":" + own.get("frameid"))
            elif mutation == "embedded_consistent_foreign_pgdb":
                node = next(n for n in own.iter() if n is not own and n.get("frameid"))
                pgdb = "ECOLI" if node.get("orgid") == "META" else "META"
                node.set("orgid", pgdb)
                field = "ID" if "ID" in node.attrib else "resource"
                node.set(
                    field, ("" if field == "ID" else "getxml?") + pgdb + ":" + node.get("frameid")
                )
            else:
                own[0].tail = "misleading unstructured container text"
            mutated = ET.tostring(root, encoding="utf-8", xml_declaration=True)
            case = OWNER / "mutations" / (ident.replace(":", "_") + "-" + mutation)
            case.mkdir(parents=True, exist_ok=True)
            (case / entry["path"]).write_bytes(mutated)
            modified = {**entry, "sha256": sha(mutated)}
            rejects(
                ident + "/" + mutation,
                "producer",
                lambda e=modified, c=case: ethanolamine_metadata(e, c),
            )
            meta = copy.deepcopy(metadata[ident])
            meta["sha256"] = sha(mutated)
            meta[FIELD]["original_base64"] = base64.b64encode(mutated).decode()
            meta[FIELD]["root_attributes"] = dict(root.attrib)
            meta[FIELD]["metadata_xml"] = ET.tostring(root.find("metadata"), encoding="unicode")
            meta[FIELD]["projection"]["slots"] = [
                {"ordinal": i + 1, "name": n.tag, "xml": ET.tostring(n, encoding="unicode")}
                for i, n in enumerate(own)
            ]
            valid = snapshot(metadata[ident])
            valid["sources"]["exact"] = meta
            rejects(
                ident + "/" + mutation,
                "consumer",
                lambda v=valid, c=case: consumer(v, c / "snapshot.json"),
            )

    # Snapshot-level falsification of every profile, without relying on scalar
    # term-label tampering already covered by the author's focused tests.
    for ident, meta in metadata.items():
        for mutation in ["slot_xml", "root_attributes", "native_id", "synonym_injection"]:
            bad = copy.deepcopy(snapshot(meta))
            native = bad["sources"]["exact"][FIELD]
            if mutation == "slot_xml":
                native["projection"]["slots"][0]["xml"] += "<invented/>"
            elif mutation == "root_attributes":
                native["root_attributes"]["ptools-version"] = "27.0-trusted"
            elif mutation == "native_id":
                native["id"] = (
                    "MetaCyc:PWY0-1477" if ident != "MetaCyc:PWY0-1477" else "MetaCyc:GDP"
                )
            else:
                native["projection"]["synonyms"].append("invented trusted alias")
                bad["terms"][ident]["synonyms"].append("invented trusted alias")
            rejects(
                ident + "/" + mutation,
                "consumer",
                lambda v=bad: consumer(v, OWNER / "forged-snapshot.json"),
            )

    # Positive adversarial nested-name changes on unnamed source entities:
    # nested gene or annotation names must never be promoted to identity labels.
    for ident in ["MetaCyc:STM2468-MONOMER", "MetaCyc:ETHAMLY-CPLX", "EcoCyc:ETHAMLY-CPLX"]:
        entry = by_id[ident]
        root = ET.fromstring((staged / entry["path"]).read_bytes())
        own = root[1]
        existing = own.find(".//common-name")
        if existing is None:
            wrapper = own.find("comment")
            ET.SubElement(
                wrapper, "common-name", {"datatype": "string"}
            ).text = "misleading nested title"
        else:
            existing.text = "misleading nested title"
        raw = ET.tostring(root, encoding="utf-8", xml_declaration=True)
        case = OWNER / "nested-name" / ident.replace(":", "_")
        case.mkdir(parents=True, exist_ok=True)
        (case / entry["path"]).write_bytes(raw)
        changed = ethanolamine_metadata({**entry, "sha256": sha(raw)}, case)
        value = snapshot(changed)
        check(
            "nested title not promoted " + ident,
            value["terms"][ident]["label"],
            ident.split(":", 1)[1],
        )
        check(
            "nested title not alias " + ident,
            "misleading nested title" not in value["terms"][ident]["synonyms"],
        )
        check(
            "nested-name context remains roundtrippable " + ident,
            consumer(value, case / "snapshot.json"),
            value["terms"],
        )

    # Strong rejection-only recognition: encoded or differently presented URLs
    # cannot launder the63 sources into legacy untyped ownership, even unselected.
    hostile_urls = [
        "https://biocyc.org/META/NEW-IMAGE?type=PATHWAY&object=PWY0-1477",
        "http://www.ecocyc.org/ECOLI/NEW-IMAGE?object=ETHAMLY-CPLX",
        "https://www.biocyc.org/ECOLI/NEW-IMAGE?id=ETHAMLY-CPLX",
        "https://metacyc.org/getxml?%4dETA%3AGDP",
        "https://www.metacyc.org/getxml?%45COLI%3AETHAMLY-CPLX",
        "https://biocyc.org/getxml?%69%64=META%3AFE%2B2",
        "https://biocyc.org/getxml?object=META%3AGDP&id=unrelated",
    ]
    for url in hostile_urls:
        rejects(
            url,
            "global_source_assertion",
            lambda u=url: validate_ethanolamine_assertions({"legacy": {"url": u}}, []),
        )

    # Consumer rejects a reattached term under another valid complete owner.
    mixed = {"version": 1, "sources": {}, "terms": {}}
    for index, (ident, meta) in enumerate(metadata.items()):
        key = "source-" + str(index)
        mixed["sources"][key] = meta
        mixed["terms"][ident] = ethanolamine_term(meta, key)[1]
    check(
        "all63 simultaneous consumer roundtrip",
        consumer(mixed, OWNER / "complete-snapshot.json"),
        mixed["terms"],
    )
    bad = copy.deepcopy(mixed)
    keys = list(bad["terms"])
    bad["terms"][keys[0]]["source"] = bad["terms"][keys[1]]["source"]
    rejects(
        "cross-bound-source-owner", "consumer", lambda: consumer(bad, OWNER / "cross-bound.json")
    )

    # Producer source inventory preflight runs even when no selected node needs
    # an original, so an invalid unused typed original cannot hide behind scope.
    source_manifest = OWNER / "all-source-manifest.json"
    source_manifest.write_text(json.dumps(entries))
    record_dir = OWNER / "minimal-records"
    record_dir.mkdir(exist_ok=True)
    (record_dir / "one.yaml").write_text("id: MetaCyc:PWY0-1477\n")
    built = build_snapshot(source_manifest, record_dir, staged)
    check("producer selects only requested root", sorted(built["terms"]), ["MetaCyc:PWY0-1477"])
    broken = copy.deepcopy(entries)
    next(e for e in broken if e["url"].endswith("META:GDP"))["sha256"] = "0" * 64
    source_manifest.write_text(json.dumps(broken))
    rejects(
        "unselected-GDP-invalid-hash",
        "producer-preflight",
        lambda: build_snapshot(source_manifest, record_dir, staged),
    )
    source_manifest.write_text(json.dumps(entries))
    check(
        "original source fixtures restored",
        all(sha((staged / e["path"]).read_bytes()) == e["sha256"] for e in entries),
    )
    failed = [m for m in mutations if not m["rejected"]]
    result = {
        "scope": "Independent source/boundary checks; pass count is not scientific acceptance.",
        "checks": checks,
        "mutations": mutations,
        "check_count": len(checks),
        "mutation_count": len(mutations),
        "all_checks_passed": all(c["pass"] for c in checks),
        "unrejected_mutations": failed,
    }
    # Bytes used by comparisons are summarized by equality checks, not serialized.
    for item in checks:
        if isinstance(item["actual"], bytes):
            item["actual"] = sha(item["actual"])
            item["expected"] = sha(item["expected"])
    (OWNER / "independent-audit-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "checks": len(checks),
                "mutations": len(mutations),
                "all_checks_passed": result["all_checks_passed"],
                "unrejected": failed,
            }
        )
    )


if __name__ == "__main__":
    main()
