"""Independent additive snapshot, provenance, source rebuild and role review."""

import hashlib
import json
import shutil
from pathlib import Path

import yaml

from pathwaymech.identifiers import _load_authority, identifier_errors
from scripts.build_source_identifier_snapshot import build_snapshot

OWNER = Path("/private/tmp/pathwaymech-next-272-independent-authority-review")
CANDIDATE = Path("/private/tmp/pathwaymech-next-272-authority-integration")
GRAPH = Path("/private/tmp/pathwaymech-next-272-graph-design")
WORK = Path("/private/tmp/pathwaymech-next-272-20261015")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ordered(value):
    if isinstance(value, dict):
        return [(key, ordered(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [ordered(item) for item in value]
    return value


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def main():
    checks = []
    evidence = []
    target = OWNER / "integration-replay"
    target.mkdir(exist_ok=True)

    def check(label, actual, expected=True):
        checks.append({"check": label, "pass": actual == expected})
        if actual != expected:
            checks[-1].update(actual=actual, expected=expected)

    def read(path):
        return json.loads(path.read_text())

    expected_hashes = {
        "sources.json": "e9f77bb01f30806cc76dc6ac7a952fb5ed9f03a9a7962a64f7ecb4e0f0c86ede",
        "ontology.json": "8ab396c8de205cbdbb8ade07795536a4b20eec59f5ad4fe5afbc08c1486975c6",
        "identifier_sources.json": (
            "0ff47a8894f3fd9d28cd9ee96afd1c64ade828980371a920a6a1d921e2fddf7b"
        ),
    }
    for name, digest in expected_hashes.items():
        check("announced candidate hash " + name, sha(CANDIDATE / name), digest)
    graph = read(GRAPH / "results/recommended-selected-graph-payload.json")
    nodes = [
        *graph["participants"],
        *graph["reactions"],
        *graph["taxa"],
        {"id": graph["id"], "label": "ethanolamine utilization"},
    ]
    selected = {n["id"]: n for n in nodes}
    closure = {r["reference_id"]: r for r in read(GRAPH / "results/source-closure.json")}
    entries = read(CANDIDATE / "new-source-manifest.json")
    bindings = {r["id"]: r for r in read(CANDIDATE / "source-bindings.json")}
    check("97 manifest entries and exact source bindings", len(entries), 97)
    check("97 unique source keys", len({r["key"] for r in entries}), 97)
    check("97 unique source paths", len({r["path"] for r in entries}), 97)
    by_id = {}
    for entry in entries:
        if entry["kind"] == "uniprot":
            ident = "UniProtKB:" + entry["url"].rsplit("/", 1)[1].removesuffix(".json")
        else:
            ident = (
                entry["url"].split("?")[1].replace("META:", "MetaCyc:").replace("ECOLI:", "EcoCyc:")
            )
        by_id[ident] = entry
        row = closure[ident]
        raw = Path(row["owner"]) / row["path"]
        staged = CANDIDATE / "cache" / entry["path"]
        check("manifest exact accepted original digest " + ident, entry["sha256"], row["sha256"])
        check("staged source bytes " + ident, staged.read_bytes() == raw.read_bytes())
        check("staged digest " + ident, sha(staged), entry["sha256"])
        for receipt in bindings[ident]["receipt_copies"]:
            path = CANDIDATE / receipt["path"]
            check("retained receipt hash " + ident, sha(path), receipt["sha256"])
            data = read(path)
            if entry["kind"] == "uniprot":
                obj = read(raw)
                headers = {k.lower(): v for k, v in data["headers"].items()}
                version = (
                    f"UniProt {headers['x-uniprot-release']}; "
                    f"entryVersion {obj['entryAudit']['entryVersion']}; "
                    f"sequenceVersion {obj['entryAudit']['sequenceVersion']}"
                )
                check(
                    "exact UniProt issuing accession " + ident,
                    obj["primaryAccession"],
                    ident.split(":")[1],
                )
                check("actual receipt source version " + ident, entry["version"], version)
                check("receipt original hash " + ident, data["sha256"], entry["sha256"])
                check("receipt actual URL " + ident, data["url"], entry["url"])
        if not bindings[ident]["receipt_copies"]:
            check("only exact historical ACETALD lacks receipt", ident, "MetaCyc:ACETALD")
            check(
                "ACETALD reuse bindings preserved",
                bool(bindings[ident]["acquisition_evidence"]["historical_reuse_bindings"]),
            )
        evidence.append(
            {
                "id": ident,
                "source_sha256": sha(raw),
                "receipt_count": len(bindings[ident]["receipt_copies"]),
            }
        )
    base_source = read(CANDIDATE / "baseline/data/identifier_authorities/sources.json")
    base_ontology = read(CANDIDATE / "baseline/data/identifier_authorities/ontology.json")
    base_conf = read(CANDIDATE / "baseline/conf/identifier_sources.json")
    for name in ["sources", "ontology"]:
        p = CANDIDATE / "baseline/data/identifier_authorities" / (name + ".json")
        frozen = GRAPH / "baseline/data/identifier_authorities" / (name + ".json")
        check("immutable baseline bytes " + name, p.read_bytes() == frozen.read_bytes())
    merged = read(CANDIDATE / "sources.json")
    ontology = read(CANDIDATE / "ontology.json")
    all_old = base_source["terms"] | base_ontology["terms"]
    check(
        "exact 97 new source identities",
        set(merged["terms"]) - set(base_source["terms"]) == set(by_id),
    )
    check(
        "new source owners exact keys",
        set(merged["sources"]) - set(base_source["sources"]) == {e["key"] for e in entries},
    )
    ontology_add = set(ontology["terms"]) - set(base_ontology["terms"])
    check(
        "exact four ontology identities",
        ontology_add == {"CHEBI:16000", "GO:0031469", "GO:0031471", "NCBITaxon:99287"},
    )
    for label, before, after in [
        ("source", base_source, merged),
        ("ontology", base_ontology, ontology),
    ]:
        check(label + " top key order preserved", list(after), list(before))
        for section in ["sources", "terms"]:
            check(
                label + "/" + section + " original key prefix",
                list(after[section])[: len(before[section])],
                list(before[section]),
            )
            for key, value in before[section].items():
                check(
                    label + "/" + section + "/" + key + " recursively identical",
                    ordered(after[section][key]),
                    ordered(value),
                )
        path = CANDIDATE / (label.replace("source", "sources") + ".json")
        check(label + " complete consumer loads exact terms", _load_authority(path), after["terms"])
    complete_terms = merged["terms"] | ontology["terms"]
    check(
        "exact all101 selected additions", set(selected) - set(all_old), set(by_id) | ontology_add
    )
    check("27 existing selected owners", len(set(selected) & set(all_old)), 27)
    for ident, node in selected.items():
        check("selected exact label " + ident, complete_terms[ident]["label"], node["label"])
        if ident in all_old:
            check(
                "selected existing owner unchanged " + ident,
                ordered(complete_terms[ident]),
                ordered(all_old[ident]),
            )
    combined_conf = read(CANDIDATE / "identifier_sources.json")
    check(
        "full old manifest recursively preserved",
        ordered(combined_conf[: len(base_conf)]),
        ordered(base_conf),
    )
    check(
        "exact97 appended manifest entries",
        ordered(combined_conf[len(base_conf) :]),
        ordered(entries),
    )

    # Independent selection from the complete accepted graph, not the root's
    # routing YAML, and a new build output location. Inputs are read-only.
    selection_dir = target / "selection"
    selection_dir.mkdir(exist_ok=True)
    selection = {"id": graph["id"]}
    for section in ["participants", "reactions"]:
        selection[section] = [{"id": n["id"]} for n in graph[section] if n["id"] in by_id]
    (selection_dir / "minimal.yaml").write_text(yaml.safe_dump(selection, sort_keys=False))
    delta = build_snapshot(
        CANDIDATE / "new-source-manifest.json", selection_dir, CANDIDATE / "cache"
    )
    dump(target / "source-additions.json", delta)
    check(
        "independent builder delta equals candidate bytes",
        (target / "source-additions.json").read_bytes(),
        (CANDIDATE / "source-additions.json").read_bytes(),
    )
    rebuilt = read(CANDIDATE / "baseline/data/identifier_authorities/sources.json")
    for section in ["sources", "terms"]:
        rebuilt[section].update(delta[section])
    dump(target / "sources.json", rebuilt)
    check(
        "independent full source snapshot byte reproduction",
        sha(target / "sources.json"),
        expected_hashes["sources.json"],
    )
    # Actual role gates with all128 selected nodes and unchanged identifier policy.
    sandbox = target / "role-gate"
    (sandbox / "conf").mkdir(parents=True, exist_ok=True)
    (sandbox / "data/identifier_authorities").mkdir(parents=True, exist_ok=True)
    (sandbox / "data/pathways").mkdir(parents=True, exist_ok=True)
    shutil.copyfile(WORK / "conf/identifier_policy.yaml", sandbox / "conf/identifier_policy.yaml")
    shutil.copyfile(
        CANDIDATE / "sources.json", sandbox / "data/identifier_authorities/sources.json"
    )
    shutil.copyfile(
        CANDIDATE / "ontology.json", sandbox / "data/identifier_authorities/ontology.json"
    )
    record = {k: graph[k] for k in ["id", "participants", "reactions", "taxa"]}
    record["label"] = "ethanolamine utilization"
    (sandbox / "data/pathways/record.yaml").write_text(yaml.safe_dump(record, sort_keys=False))
    errors = identifier_errors(sandbox)
    check("all128 selected node label/type gates", errors, [])
    result = {
        "candidate_bindings": expected_hashes,
        "checks": checks,
        "source_evidence": evidence,
        "all_passed": all(c["pass"] for c in checks),
        "checks_count": len(checks),
        "scope": (
            "Additive preservation and97-source delta replay; "
            "not a historical full-source rebuild or ontology database rehash."
        ),
    }
    for item in checks:
        for key in ["actual", "expected"]:
            if isinstance(item.get(key), bytes):
                item[key] = hashlib.sha256(item[key]).hexdigest()
    dump(OWNER / "integration-review-result.json", result)
    print(
        json.dumps(
            {
                "checks": len(checks),
                "all_passed": result["all_passed"],
                "failed": [c for c in checks if not c["pass"]],
            }
        )
    )


if __name__ == "__main__":
    main()
