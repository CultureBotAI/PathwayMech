import hashlib
import json
import shutil
import subprocess
from pathlib import Path

OWNER = Path("/private/tmp/pathwaymech-next-272-complete-record-preparation")
WORKTREE = Path("/private/tmp/pathwaymech-next-272-20261015")
GRAPH = Path("/private/tmp/pathwaymech-next-272-graph-design")
BASELINE = "54e768a985d07705ea25445804c83b4758646e37"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


bindings = []
files = list((GRAPH / "results").glob("*.json")) + list((GRAPH / "biology-audit").glob("*.json"))
files += [
    GRAPH / name
    for name in ["DESIGN.md", "HANDOFF.md", "artifact-manifest.json", "freeze-proof.json"]
]
parents = {
    "graph_review": Path("/private/tmp/pathwaymech-next-272-independent-graph-design-review"),
    "native": Path("/private/tmp/pathwaymech-next-272-native-source-preparation"),
    "primary": Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation"),
    "scientific_review": Path(
        "/private/tmp/pathwaymech-next-272-independent-scientific-source-review"
    ),
    "magnesium_successor": Path("/private/tmp/pathwaymech-next-272-native-magnesium-successor"),
    "eutt": Path("/private/tmp/pathwaymech-next-272-eutt-specificity-followup"),
}
for source in files:
    if not source.exists():
        continue
    dest = OWNER / "inputs/graph" / source.relative_to(GRAPH)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, dest)
    bindings.append(
        {"source": str(source), "copy": str(dest.relative_to(OWNER)), "sha256": digest(source)}
    )
for name, parent in parents.items():
    chosen = ["HANDOFF.md", "artifact-manifest.json", "freeze-proof.json"]
    if name == "native":
        chosen += ["results/source-conflicts.json"]
    if name == "primary":
        chosen += ["results/source-reading-ledger.json", "results/claim-ledger.json"]
    for relative in chosen:
        source = parent / relative
        if not source.exists():
            continue
        dest = OWNER / "inputs" / name / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        bindings.append(
            {"source": str(source), "copy": str(dest.relative_to(OWNER)), "sha256": digest(source)}
        )
paths = [
    "CLAUDE.md",
    ".claude/skills/add-pathway/SKILL.md",
    "docs/CURATION.md",
    "docs/HARMONIZATION.md",
    "docs/CAUSAL_GRAPHS.md",
    "docs/IDENTIFIERS.md",
    "src/pathwaymech/schema.py",
    "src/pathwaymech/schema/pathwaymech.yaml",
    "src/pathwaymech/strict.py",
    "src/pathwaymech/reaction_mechanisms.py",
    "data/pathways/methanogenesis-from-acetate.yaml",
    "data/pathways/acetate-and-atp-formation-from-acetyl-coa-i.yaml",
    "pyproject.toml",
]
for relative in paths:
    source = WORKTREE / relative
    original = subprocess.run(
        ["git", "-C", str(WORKTREE), "show", f"{BASELINE}:{relative}"],
        check=True,
        capture_output=True,
    ).stdout
    equal = source.read_bytes() == original
    if relative.startswith("src/pathwaymech/"):
        assert equal, relative
    if not equal:
        current = OWNER / "inputs/current-guidance" / relative
        current.parent.mkdir(parents=True, exist_ok=True)
        current.write_bytes(source.read_bytes())
        bindings.append(
            {
                "source": str(source),
                "copy": str(current.relative_to(OWNER)),
                "sha256": digest(source),
                "scope": "concurrently revised guidance; not a baseline-byte assertion",
            }
        )
    dest = OWNER / "baseline" / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(original)
    bindings.append(
        {
            "source": str(source),
            "copy": str(dest.relative_to(OWNER)),
            "sha256": digest(dest),
            "baseline_commit": BASELINE,
            "live_bytes_equal_baseline": equal,
        }
    )
(OWNER / "results/intake-bindings.json").write_text(json.dumps(bindings, indent=2) + "\n")
print(
    f"{len(bindings)} exact input bindings; unchanged structural schema verified; "
    "guidance changes explicitly recorded"
)
