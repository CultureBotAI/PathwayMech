"""Build a complete scratch record while preserving the exact accepted graph."""

from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path

import yaml

OWNER = Path(__file__).resolve().parents[1]
GRAPH = OWNER / "inputs/graph"
PRIMARY = OWNER / "inputs/primary/results/source-reading-ledger.json"


def read(path: Path):
    return json.loads(path.read_text())


def write(name: str, value):
    (OWNER / "results" / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def sha(text: str):
    return hashlib.sha256(text.encode()).hexdigest()


class RecordDumper(yaml.SafeDumper):
    pass


def string(dumper, value):
    style = "|" if "\n" in value else None
    return dumper.represent_scalar("tag:yaml.org,2002:str", value, style=style)


RecordDumper.add_representer(str, string)

payload = read(GRAPH / "results/recommended-selected-graph-payload.json")
paragraphs = yaml.safe_load((OWNER / "narrative.yaml").read_text())
for index, paragraph in enumerate(paragraphs):
    paragraph["index"] = index
    paragraph["record_pointer"] = "/description"
    paragraph["text_sha256"] = sha(paragraph["text"])
    paragraph["locator"] = f"description paragraph {index + 1}, starts: {paragraph['text'][:90]}"
by_key = {p["key"]: p for p in paragraphs}
record = {
    "id": payload["id"],
    "label": "ethanolamine utilization",
    "description": "\n\n".join(p["text"] for p in paragraphs),
    "pathway_type": "ethanolamine-utilization",
    "taxa": copy.deepcopy(payload["taxa"]),
    "participants": copy.deepcopy(payload["participants"]),
    "reactions": copy.deepcopy(payload["reactions"]),
    "mechanistic_edges": copy.deepcopy(payload["mechanistic_edges"]),
    "references": copy.deepcopy(payload["references"]),
}
refs = {r["id"]: r for r in record["references"]}
sources = read(PRIMARY)["sources"]
source_ref = {}
source_mappings = []
for source in sources:
    citation = source["citation"]
    if source["key"] == "S24":
        citation = "Held, Kolb, Perdue et al. 2016; PMID27063436; PMC4827028; DOI10.1038/srep24359"
    pmid = re.search(r"PMID(\d+)", citation)
    doi = re.search(r"DOI(\S+)", citation)
    identifier = f"PMID:{pmid[1]}" if pmid else f"DOI:{doi[1]}"
    source_ref[source["key"]] = identifier
    if identifier in refs:
        refs[identifier]["citation"] = citation
        if refs[identifier].get("title", "").startswith(source["key"] + " primary evidence"):
            del refs[identifier]["title"]
    else:
        refs[identifier] = {
            "id": identifier,
            "citation": citation,
            "url": source["primary_url"],
            "source_version": source["access"],
        }
        # No single hash is invented for a multi-artifact reading scope.
        original = [a for a in source["artifacts"] if a["path"].startswith("originals/")]
        if len(original) == 1:
            refs[identifier]["source_sha256"] = original[0]["sha256"]
        record["references"].append(refs[identifier])
    source_mappings.append(
        {
            "source_key": source["key"],
            "reference_id": identifier,
            "accepted_citation": citation,
            "access": source["access"],
            "actual_read_scope": source["actual_read_scope"],
            "limits": source["limits"],
            "artifacts": source["artifacts"],
            "artifact_owner": "/private/tmp/pathwaymech-next-272-primary-evidence-preparation",
            "citation_successor_applied": source["key"] == "S24",
        }
    )
record["references"].append(
    {
        "id": "PMID:25914129",
        "citation": (
            "EutT oxidation-state specificity study; PMID25914129; DOI10.1002/anie.201501930"
        ),
        "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC4504680/",
        "source_version": (
            "Official NCBI XML main; accepted main/caption/Table 1 reading; "
            "supporting information unavailable"
        ),
        "source_sha256": "eb04059b7233d069d2c243bccb2b08352399ba9657b8731d09f4225b213ea2b5",
    }
)
source_ref["S25"] = "PMID:25914129"
reference_lookup = {r["id"]: r for r in record["references"]}
bibliographic = []
for metadata in read(OWNER / "inputs/bibliography/exact-bibliographic-projections.json"):
    if metadata["reference_id"] not in reference_lookup:
        continue
    reference = reference_lookup[metadata["reference_id"]]
    reference["title"] = metadata["title"]
    if (
        reference.get("citation", "").startswith("PMID")
        or metadata["reference_id"] == "PMID:25914129"
    ):
        reference["citation"] = metadata["citation"]
    bibliographic.append(metadata)
write("bibliographic-record-mapping.json", bibliographic)

ref_index = {r["id"]: i for i, r in enumerate(record["references"])}
node_index = {record["id"]: "/id"}
for section in ["participants", "reactions", "taxa"]:
    for index, node in enumerate(record[section]):
        node_index[node["id"]] = f"/{section}/{index}"
edge_index = {e["id"]: i for i, e in enumerate(record["mechanistic_edges"])}


def edge_pointers(ids):
    return [f"/mechanistic_edges/{edge_index[i]}" for i in ids if i in edge_index]


def incident(identifier):
    return [
        f"/mechanistic_edges/{i}"
        for i, e in enumerate(record["mechanistic_edges"])
        if identifier in [e["subject"], e["object"]]
    ]


def paragraph_bindings(keys):
    return [
        {k: by_key[key][k] for k in ["key", "index", "record_pointer", "text_sha256", "locator"]}
        for key in keys
    ]


primary = []
for claim in read(GRAPH / "biology-audit/primary-claim-design-ledger.json"):
    keys = [p["key"] for p in paragraphs if claim["id"] in p["primary_claims"]]
    assert keys, claim["id"]
    reference = source_ref[claim["source_key"]]
    edges = [
        f"/mechanistic_edges/{i}"
        for i, e in enumerate(record["mechanistic_edges"])
        if any(v.get("reference_id") == reference for v in e["evidence"])
    ]
    primary.append(
        {
            **claim,
            "record_narrative": paragraph_bindings(keys),
            "reference_pointer": f"/references/{ref_index[reference]}",
            "same_source_edge_pointers": edges,
            "disposition": (
                "Supported claim and qualification retained in narrative; only "
                "exact accepted graph assertions receive typed edges."
            ),
        }
    )
conflicts = []
for conflict in read(OWNER / "inputs/native/results/source-conflicts.json"):
    keys = [p["key"] for p in paragraphs if conflict["id"] in p["conflicts"]]
    assert keys, conflict["id"]
    conflicts.append(
        {
            **conflict,
            "record_narrative": paragraph_bindings(keys),
            "successor_precedence": "inputs/graph/results/scientific-successor-precedence.json",
            "disposition": (
                "Raw source statements remain unchanged; current qualified record"
                " wording applies accepted successors."
            ),
        }
    )
proteins = []
for protein in read(GRAPH / "biology-audit/protein-design-ledger.json"):
    keys = [p["key"] for p in paragraphs if protein["gene"] in p["genes"]]
    assert keys, protein["id"]
    proteins.append(
        {
            **protein,
            "record_node": node_index[protein["id"]],
            "record_edges": incident(protein["id"]),
            "record_narrative": paragraph_bindings(keys),
            "current_selection_precedence": (
                "All scoped selected edges supersede earlier conditional/future "
                "wording only at their exact accepted scope."
            ),
        }
    )
activities = []
for activity in read(GRAPH / "results/all71-activity-design-dispositions.json"):
    identifier = f"MetaCyc:{activity['activity']}"
    pointers = incident(identifier)
    activities.append(
        {
            **activity,
            "record_node": node_index.get(identifier),
            "record_edges": pointers,
            "record_narrative": paragraph_bindings(["eutbc_regulation"]),
            "record_disposition": "Selected exact native activity preserved."
            if pointers
            else (
                "Adjacent or unrelated backlink explicitly excluded from selected"
                " catalyst set; retained source-specific rationale is not a "
                "missing enzyme assignment."
            ),
        }
    )
slots = []
slot_inputs = [
    "all3689-native-slot-design-dispositions.json",
    "supplemental16-native-slot-design-dispositions.json",
]
for filename in slot_inputs:
    for slot in read(GRAPH / "results" / filename):
        identifier = slot["source_id"]
        pointers = edge_pointers(slot.get("edge_keys", []))
        for i, edge in enumerate(record["mechanistic_edges"]):
            for ev in edge["evidence"]:
                if ev["reference_id"] == identifier and slot["locator"] in ev.get(
                    "source_locator", ""
                ):
                    pointer = f"/mechanistic_edges/{i}"
                    if pointer not in pointers:
                        pointers.append(pointer)
        applicable_conflicts = [
            c["id"]
            for c in conflicts
            if any(
                sc.get("sha256") == slot["source_sha256"] and sc.get("locator") == slot["locator"]
                for sc in c["source_claims"]
            )
        ]
        keys = sorted(
            {p["key"] for p in paragraphs if set(p["conflicts"]) & set(applicable_conflicts)}
        )
        slots.append(
            {
                **slot,
                "record_node": node_index.get(identifier),
                "record_reference": f"/references/{ref_index[identifier]}"
                if identifier in ref_index
                else None,
                "record_edges": pointers,
                "record_narrative": paragraph_bindings(keys),
                "field_disposition": "Exact accepted assertion represented by edge evidence."
                if pointers
                else (
                    "Identity, evidence or contextual own slot remains bound through "
                    "its issuing reference and accepted semantic ledger; no extra "
                    "mechanistic claim is inferred."
                ),
                "successor_precedence": "results/successor-record-mapping.json",
            }
        )
edges = []
for edge in record["mechanistic_edges"]:
    source_ledger = (
        "results/edge-ledger.json"
        if edge["id"] in {x["graph_edge"]["id"] for x in read(GRAPH / "results/edge-ledger.json")}
        else "results/recommended-option-selection.json"
    )
    edges.append(
        {
            "edge_id": edge["id"],
            "record_pointer": f"/mechanistic_edges/{edge_index[edge['id']]}",
            "exact_payload_sha256": sha(
                json.dumps(edge, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            ),
            "accepted_design_ledger": source_ledger,
            "unchanged": True,
        }
    )
successors = read(GRAPH / "results/scientific-successor-precedence.json")
successor_mapping = {
    "magnesium": {
        "derived_dispositions": successors["magnesium_dispositions"],
        "record_narrative": paragraph_bindings(["eutpq_magnesium"]),
        "finding": 634,
        "resolution_scope": (
            "Correction carried in scratch narrative and unchanged qualified "
            "graph; issue closure requires root maintained/merged "
            "verification."
        ),
    },
    "citation": {
        "accepted_successor": successors["citation_correction"],
        "record_reference": f"/references/{ref_index['PMID:27063436']}",
        "record_narrative": paragraph_bindings(["eutpq_physiology"]),
    },
    "euth": {
        "accepted_successor": successors["historical_euth_context_correction"],
        "record_narrative": paragraph_bindings(["euth"]),
    },
    "eutt": [
        {
            **x,
            "record_narrative": paragraph_bindings(
                ["eutt_cobinamide", "eutt_chemistry", "eutt_metals"]
            ),
        }
        for x in read(GRAPH / "results/accepted-eutt-followup-design.json")
    ],
    "euta": {
        "accepted_design": read(GRAPH / "results/euta-target-claim-design.json"),
        "record_narrative": paragraph_bindings(["euta", "eutbc"]),
        "record_edges": [
            f"/mechanistic_edges/{i}"
            for i, e in enumerate(record["mechanistic_edges"])
            if "EcoCyc:ETHAMLY-CPLX" in [e["subject"], e["object"]]
        ],
    },
    "cargo": {
        "accepted_design": read(GRAPH / "results/cargo-construct-claim-design.json"),
        "record_narrative": paragraph_bindings(["cargo_reporters"]),
        "record_edges": edge_pointers(["option-eutc19-egfp-native-host-location"]),
    },
}
for name, values in [
    ("narrative-map.json", paragraphs),
    ("primary-claim-record-mapping.json", primary),
    ("conflict-record-mapping.json", conflicts),
    ("protein-record-mapping.json", proteins),
    ("activity-record-mapping.json", activities),
    ("native-slot-record-mapping.json", slots),
    ("edge-record-mapping.json", edges),
    ("successor-record-mapping.json", successor_mapping),
    ("primary-reference-closure.json", source_mappings),
]:
    write(name, values)
write(
    "declaration-record-mapping.json",
    [{"id": identifier, "record_pointer": pointer} for identifier, pointer in node_index.items()],
)
for filename in [
    "core-occurrences.json",
    "ancillary-eutt-occurrences.json",
    "composition-ledger.json",
]:
    write(
        filename.replace(".json", "-record-mapping.json"),
        [
            {**x, "record_edges": edge_pointers([x["edge"]])}
            for x in read(GRAPH / "results" / filename)
        ],
    )
write(
    "regulation-record-mapping.json",
    [
        {
            **x,
            "record_edges": [
                f"/mechanistic_edges/{i}"
                for i, e in enumerate(record["mechanistic_edges"])
                if e["subject"] == x["regulator"] and e["object"] == x["target"]
            ],
            "record_narrative": paragraph_bindings(["eutbc_regulation"]),
        }
        for x in read(GRAPH / "results/regulation-ledger.json")
    ],
)
write("complete-record.json", record)
(OWNER / "ethanolamine-utilization.yaml").write_text(
    yaml.dump(record, Dumper=RecordDumper, sort_keys=False, allow_unicode=True, width=100)
)
print(
    f"Complete candidate: {len(record['mechanistic_edges'])} edges, "
    f"{len(node_index)} declarations, {len(record['references'])} references, "
    f"{len(paragraphs)} narrative paragraphs"
)

write(
    "protein-comment-record-mapping.json",
    [
        {
            "protein_id": protein["id"],
            "source_comment": comment,
            "record_node": protein["record_node"],
            "record_narrative": protein["record_narrative"],
            "record_edges": protein["record_edges"],
            "scope": (
                "Exact comment source retained; only accepted scoped assertions "
                "are typed edges. No fresh complete primary reading inferred from"
                " a database citation."
            ),
        }
        for protein in proteins
        for comment in protein["comment_evidence_bindings"]
    ],
)
