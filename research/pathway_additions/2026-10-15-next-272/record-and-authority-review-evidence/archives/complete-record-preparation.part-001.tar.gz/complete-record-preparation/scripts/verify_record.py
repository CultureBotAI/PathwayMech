"""Offline structural and preservation checks; no identifier adoption."""

from __future__ import annotations

import hashlib
import json
import sys
import types
from pathlib import Path

import yaml
from jsonschema import FormatChecker
from jsonschema.validators import validator_for

OWNER = Path(__file__).resolve().parents[1]
package = types.ModuleType("pathwaymech")
package.__path__ = [str(OWNER / "baseline/src/pathwaymech")]
sys.modules["pathwaymech"] = package
from pathwaymech.schema import validate_record  # noqa: E402
from pathwaymech.strict import json_schema  # noqa: E402


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


checks = []


def check(label, condition):
    checks.append({"check": label, "passed": bool(condition)})


record = yaml.safe_load((OWNER / "ethanolamine-utilization.yaml").read_text())
payload = read(OWNER / "inputs/graph/results/recommended-selected-graph-payload.json")
check("YAML equals generated JSON", record == read(OWNER / "results/complete-record.json"))
for section in ["id", "taxa", "participants", "reactions", "mechanistic_edges"]:
    check(f"exact accepted graph preservation: {section}", record[section] == payload[section])
check("97 edges", len(record["mechanistic_edges"]) == 97)
check(
    "128 declarations",
    1 + sum(len(record[s]) for s in ["taxa", "participants", "reactions"]) == 128,
)
check(
    "19 accepted options",
    len(read(OWNER / "inputs/graph/results/recommended-option-selection.json")) == 19,
)
try:
    validate_record(record)
except ValueError as error:
    check(f"handwritten structural contract: {error}", False)
else:
    check("handwritten structural contract", True)
generated = json.loads(json_schema())
(OWNER / "results/closed-record-schema.json").write_text(json.dumps(generated, indent=2) + "\n")
cls = validator_for(generated)
cls.check_schema(generated)
errors = [str(e) for e in cls(generated, format_checker=FormatChecker()).iter_errors(record)]
check("unchanged closed LinkML schema contract", not errors)
(OWNER / "results/closed-schema-errors.json").write_text(json.dumps(errors, indent=2) + "\n")
evidence = []


def walk(value, path=""):
    if isinstance(value, dict):
        if "reference_id" in value and ("source_assertion" in value or "quote" in value):
            evidence.append(
                {
                    "pointer": path,
                    "length": len(value.get("source_assertion", value.get("quote", ""))),
                    "reference_id": value["reference_id"],
                }
            )
            check(f"evidence limit {path}", evidence[-1]["length"] <= 400)
        for key, child in value.items():
            walk(child, f"{path}/{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            walk(child, f"{path}/{index}")


walk(record)
for binding in read(OWNER / "results/intake-bindings.json") + read(
    OWNER / "results/bibliographic-input-bindings.json"
):
    copied = OWNER / binding["copy"]
    check(f"copied input hash {binding['copy']}", sha(copied) == binding["sha256"])
    if "baseline_commit" not in binding and "concurrently revised" not in binding.get("scope", ""):
        check(
            f"frozen parent input hash {binding['copy']}",
            sha(Path(binding["source"])) == binding["sha256"],
        )
for filename, count in [
    ("edge-record-mapping.json", 97),
    ("declaration-record-mapping.json", 128),
    ("primary-claim-record-mapping.json", 32),
    ("conflict-record-mapping.json", 19),
    ("protein-record-mapping.json", 34),
    ("protein-comment-record-mapping.json", 298),
    ("activity-record-mapping.json", 71),
    ("native-slot-record-mapping.json", 3705),
    ("core-occurrences-record-mapping.json", 22),
    ("ancillary-eutt-occurrences-record-mapping.json", 9),
    ("composition-ledger-record-mapping.json", 11),
    ("regulation-record-mapping.json", 12),
]:
    data = read(OWNER / "results" / filename)
    check(f"complete mapping {filename}", len(data) == count)
    if filename in [
        "primary-claim-record-mapping.json",
        "conflict-record-mapping.json",
        "protein-record-mapping.json",
    ]:
        for row in data:
            check(f"narrative mapping {filename} {row['id']}", bool(row["record_narrative"]))
refs = {r["id"]: r for r in record["references"]}
check(
    "all accepted reference identities retained",
    all(r["id"] in refs for r in payload["references"]),
)
for reference in payload["references"]:
    for key in ["url", "source_sha256", "source_version"]:
        if key in reference:
            check(
                f"accepted reference {key} retained {reference['id']}",
                refs[reference["id"]][key] == reference[key],
            )
for source in read(OWNER / "results/primary-reference-closure.json"):
    for artifact in source["artifacts"]:
        path = Path(source["artifact_owner"]) / artifact["path"]
        check(f"primary artifact {artifact['path']}", sha(path) == artifact["sha256"])
check("citation successor", refs["PMID:27063436"]["citation"].startswith("Held, Kolb, Perdue"))
check(
    "magnesium qualification present",
    "magnesium-independent catalysis is not established" in record["description"],
)
check("no authority/history extension", not set(record) & {"curation_history", "source_mappings"})
check(
    "all issue634 derived dispositions mapped",
    len(read(OWNER / "results/successor-record-mapping.json")["magnesium"]["derived_dispositions"])
    == 25,
)
check(
    "all six EutT followup dispositions mapped",
    len(read(OWNER / "results/successor-record-mapping.json")["eutt"]) == 6,
)


def resolve(pointer):
    value = record
    for token in pointer.lstrip("/").split("/"):
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


for path in sorted((OWNER / "results").glob("*-record-mapping.json")):

    def pointers(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key in {
                    "record_pointer",
                    "record_node",
                    "record_reference",
                    "reference_pointer",
                } and isinstance(child, str):
                    yield child
                elif key in {"record_edges", "same_source_edge_pointers"}:
                    yield from child
                else:
                    yield from pointers(child)
        elif isinstance(value, list):
            for child in value:
                yield from pointers(child)

    for pointer in sorted(set(pointers(read(path)))):
        check(f"mapping pointer {path.name}:{pointer}", resolve(pointer) is not None)
for p in read(OWNER / "results/narrative-map.json"):
    actual = record["description"].split("\n\n")[p["index"]]
    check(
        f"narrative paragraph {p['key']}",
        hashlib.sha256(actual.encode()).hexdigest() == p["text_sha256"],
    )
for row in read(OWNER / "results/regulation-record-mapping.json"):
    for pointer in row["record_edges"]:
        edge = resolve(pointer)
        check(
            f"exact regulation {row['source_id']}",
            edge["subject"] == row["regulator"] and edge["object"] == row["target"],
        )


report = {
    "scope": (
        "Complete scratch PathwayRecord structural contract and exact "
        "graph/input preservation; no authority, corpus, rendering, KGX, "
        "scientific-acceptance or publication claim."
    ),
    "candidate_sha256": sha(OWNER / "ethanolamine-utilization.yaml"),
    "graph_payload_sha256": sha(
        OWNER / "inputs/graph/results/recommended-selected-graph-payload.json"
    ),
    "checks": len(checks),
    "passed": sum(x["passed"] for x in checks),
    "failed": [x for x in checks if not x["passed"]],
    "evidence_items": len(evidence),
    "max_evidence_length": max(e["length"] for e in evidence),
    "counts": {
        s: len(record[s])
        for s in ["participants", "reactions", "taxa", "mechanistic_edges", "references"]
    },
    "details": checks,
}
(OWNER / "results/verification.json").write_text(json.dumps(report, indent=2) + "\n")
(OWNER / "results/evidence-limits.json").write_text(json.dumps(evidence, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "details"}, indent=2))
assert not report["failed"], "verification failed"
