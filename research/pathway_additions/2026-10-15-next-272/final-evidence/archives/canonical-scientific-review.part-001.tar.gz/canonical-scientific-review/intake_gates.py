"""Read terminal root gate receipts without executing or modifying root checks."""

import hashlib
import json
import shlex
from datetime import UTC, datetime
from pathlib import Path

OWNER = Path(__file__).resolve().parent
ROOT_CI = Path("/private/tmp/pathwaymech-next-272-ci")
REPO = Path("/private/tmp/pathwaymech-next-272-20261015")
state_path = ROOT_CI / "full-gates-live.json"
state_bytes = state_path.read_bytes()
state = json.loads(state_bytes)
logs = OWNER / "root-gates"
logs.mkdir(exist_ok=True)
summaries = {
    "full-validate": (
        "Full corpus QC passed: closed schema, identifiers, evidence and "
        "current generated pages for269 pathway records."
    ),
    "full-test": (
        "Entire documented pytest suite: 8,014 passed, 3 skipped, 7 warnings "
        "in1,014.26s. Exact output is retained."
    ),
    "full-lint": "Documented repository lint command passed.",
    "full-diff-check": "Actual worktree git diff --check passed.",
    "full-review-check": "All196 existing review bundles passed before the new canonical save.",
}
checks = []
for key, check in sorted(state["checks"].items()):
    if check["status"] != "terminal":
        continue
    copied = {}
    for label, row in check["logs"].items():
        source = Path(row["path"])
        data = source.read_bytes()
        assert len(data) == row["bytes"]
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        dest = logs / source.name
        if dest.exists():
            assert dest.read_bytes() == data
        else:
            dest.write_bytes(data)
        copied[label] = {**row, "retained_copy": str(dest)}
    checks.append(
        {
            "key": key,
            "name": shlex.join(check["command"]),
            "command": shlex.join(check["command"]),
            "exit_code": check["exit_code"],
            "required": key != "full-review-check",
            "summary": summaries[key],
            "started_utc": check["started_utc"],
            "finished_utc": check["finished_utc"],
            "logs": copied,
        }
    )
inspected = json.loads((OWNER / "inspect-expanded.json").read_text())
current_inputs = []
for row in inspected["source"]["inputs"]:
    actual = hashlib.sha256((REPO / row["path"]).read_bytes()).hexdigest()
    assert actual == row["sha256"], row["path"]
    current_inputs.append({"path": row["path"], "sha256": actual})
complete = len(checks) == 5 and state.get("all_checks_passed") is True
result = {
    "accessed_at": datetime.now(UTC).isoformat(),
    "executor": "root agent",
    "worktree": str(REPO),
    "root_receipt": str(state_path),
    "root_receipt_sha256": hashlib.sha256(state_bytes).hexdigest(),
    "checks": checks,
    "complete": complete,
    "current_inspected_inputs_unchanged": current_inputs,
    "scope": "Read and verified root command receipts/logs; no invented one-record validator.",
}
name = "gate-intake.json" if complete else "gate-intake-in-progress.json"
(OWNER / name).write_text(json.dumps(result, indent=2) + "\n")
(logs / ("terminal-state.json" if complete else "initial-terminal-state.json")).write_bytes(
    state_bytes
)
print(json.dumps({"complete": complete, "checks": [(c["key"], c["exit_code"]) for c in checks]}))
