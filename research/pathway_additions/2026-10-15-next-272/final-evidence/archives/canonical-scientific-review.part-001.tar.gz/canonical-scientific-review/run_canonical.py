"""Execute only the authorized governed review validate/save/check workflow."""

import hashlib
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

OWNER = Path(__file__).resolve().parent
REPO = Path("/private/tmp/pathwaymech-next-272-20261015")
PYTHON = "/private/tmp/pathwaymech-next-263-verified-venv/bin/python"
BASE = "54e768a985d07705ea25445804c83b4758646e37"
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1")
prefix = [
    PYTHON,
    "-B",
    "scripts/record_review.py",
    "--repo-root",
    str(REPO),
    "--schema",
    "schema/record_review.yaml",
]
receipts = []
for name, args in [
    ("canonical-validate", ["validate", str(OWNER / "completed-review.yaml")]),
    ("canonical-save", ["save", "--content", str(OWNER / "completed-review.yaml")]),
    ("canonical-check", ["check", "--base", BASE, "--require-reviews"]),
]:
    start = datetime.now(UTC).isoformat()
    run = subprocess.run(
        prefix + args, cwd=REPO, env=env, capture_output=True, text=True, check=False
    )
    logs = {}
    for label, data in [("stdout", run.stdout), ("stderr", run.stderr)]:
        p = OWNER / f"{name}.{label}"
        p.write_text(data)
        logs[label] = {
            "path": str(p),
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            "bytes": p.stat().st_size,
        }
    receipts.append(
        {
            "name": name,
            "command": prefix + args,
            "started_at": start,
            "finished_at": datetime.now(UTC).isoformat(),
            "exit_code": run.returncode,
            "logs": logs,
        }
    )
    (OWNER / "canonical-command-receipts.json").write_text(json.dumps(receipts, indent=2) + "\n")
    print(
        json.dumps(
            {"name": name, "exit_code": run.returncode, "stdout": run.stdout, "stderr": run.stderr}
        ),
        flush=True,
    )
    if run.returncode:
        raise SystemExit(run.returncode)
saved = json.loads((OWNER / "canonical-save.stdout").read_text())
copies = OWNER / "canonical-bundle"
copies.mkdir()
pair = {}
for kind, source in saved.items():
    p = Path(source)
    data = p.read_bytes()
    (copies / p.name).write_bytes(data)
    pair[kind] = {
        "maintained_path": str(p.relative_to(REPO)),
        "scratch_copy": str((copies / p.name).relative_to(OWNER)),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }
(OWNER / "canonical-saved-pair.json").write_text(json.dumps(pair, indent=2) + "\n")
print(json.dumps(pair, indent=2))
