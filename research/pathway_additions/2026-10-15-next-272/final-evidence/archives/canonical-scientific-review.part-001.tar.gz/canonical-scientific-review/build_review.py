"""Assemble the canonical observation after terminal full-corpus gate intake."""

import hashlib
import json
import shlex
from datetime import UTC, datetime
from pathlib import Path

import yaml

OWNER = Path(__file__).resolve().parent
REPO = Path("/private/tmp/pathwaymech-next-272-20261015")
PREFIX = "research/pathway_additions/2026-10-15-next-272/"
AP = PREFIX + "accepted-preparation/"
RP = PREFIX + "record-and-authority-review-evidence/"
TARGET = "MetaCyc:PWY0-1477"
TARGETS = [TARGET]
NOW = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
START = json.loads((OWNER / "started-at.json").read_text())["started_at"]
INSPECT = json.loads((OWNER / "inspect-final.json").read_text())
INSPECT_RECEIPT = json.loads((OWNER / "final-inspection-receipt.json").read_text())
GATES = json.loads((OWNER / "gate-intake.json").read_text())
BINDING = json.loads((OWNER / "canonical-binding-results.json").read_text())
assert not BINDING["failed"]
assert all(g["exit_code"] == 0 for g in GATES["checks"])


class ReviewDumper(yaml.SafeDumper):
    """Emit the governed contract without aliases for reused target lists."""

    def ignore_aliases(self, _data):
        return True


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def local_evidence(key, kind, reference, locator, summary, support="supports"):
    return {
        "evidence_id": key,
        "kind": kind,
        "reference": reference,
        "locator": locator,
        "accessed_at": NOW,
        "support": support,
        "summary": summary,
        "snapshot_sha256": sha(REPO / reference),
    }


evidence = [
    local_evidence(
        "maintained",
        "record_content",
        "data/pathways/ethanolamine-utilization.yaml",
        (
            "Entire 3,805-line record; /description; /taxa; /participants; /reactions; "
            "/mechanistic_edges; /references"
        ),
        (
            "Read the complete actual maintained target after fresh canonical inspect. "
            "It has 23 narrative paragraphs, 128 declarations including the root, 97 "
            "edges, and 291 references. Exact adopted candidate SHA "
            "f1fd9402cab31bf3c62d53ef630abc52308c2c0e2d7b61d7ad6b9c0aaba8fb1e."
        ),
    ),
    local_evidence(
        "core",
        "prior_review",
        AP + "reports/independent-core-context-review/REVIEW.md",
        (
            "Native pathway identity and chemical boundary; concrete species/source "
            "conflicts; taxon/provenance limits; iModulonDB context"
        ),
        (
            "Earlier independent source reading by this reviewer verified exact native "
            "root, five reactions, 22 occurrences, 14 concrete species, two direct taxa "
            "and independently balanced equations. Native CML conflicts, EC2.7.2.15 "
            "specificity and charged/neutral identities remain qualified in the actual "
            "record."
        ),
    ),
    local_evidence(
        "biology",
        "prior_review",
        AP + "reports/independent-scientific-source-review/REVIEW.md",
        (
            "All supported primary/native dispositions; magnesium/citation successor; "
            "explicit primary reading limits"
        ),
        (
            "Separate independent scientific source review assessed all 32 primary "
            "claims, 19 source-conflict groups and 71 activity leads, and accepted the "
            "magnesium/citation successor. This canonical assessment checks their "
            "treatment in the actual record; it does not claim to have independently "
            "reread every paper in full."
        ),
    ),
    local_evidence(
        "graph",
        "prior_review",
        AP + "reports/independent-graph-design-review/REVIEW.md",
        "Exact 97-edge/128-declaration selection and all 19 scoped option dispositions",
        (
            "This reviewer previously assessed the complete design against retained "
            "original sources. Canonical equality checks establish that every selected "
            "graph field, evidence payload and endpoint qualifier is unchanged in the "
            "actual record. Source-supported optional context survives alongside the "
            "five-member core."
        ),
    ),
    local_evidence(
        "eutt",
        "prior_review",
        AP + "reports/independent-eutt-followup-review/REVIEW.md",
        "Six accepted bounded 2015 source dispositions and operational correction",
        (
            "Separate independent followup review accepts the main-text report of "
            "pre-reduced Co(I) cobinamide activity while distinguishing Co(II) "
            "coordination, competitive inhibition, unavailable SI, the unread 2006 main "
            "and the native inactivity annotation. Canonical targeted rereading of main "
            "paragraph P9 confirms this scope."
        ),
    ),
    local_evidence(
        "record-preparation",
        "record_content",
        RP + "archives/complete-record-preparation.part-001.tar.gz",
        (
            "complete-record-preparation/results/{primary-claim,conflict,protein,activit"
            "y,native-slot,successor}-record-mapping.json; narrative-map.json; "
            "primary-reference-closure.json"
        ),
        (
            "Independently decoded all 127 outer file payloads of this retained "
            "archive, matched sizes/hashes, and bound the actual record to the frozen "
            "candidate. Checked 32 claim, 19 conflict, 34 protein, 71 activity and "
            "3,705 native-slot mappings. Mapping counts are coverage accounting, not "
            "scientific truth by themselves."
        ),
    ),
    local_evidence(
        "imodulon",
        "database",
        AP + "reports/imodulondb-preparation/ASSESSMENT.md",
        (
            "Finite installed datasets/search/summarize receipts and raw fallback; "
            "e_coli/modulome/76"
        ),
        (
            "Reused this task session’s actual installed-runner crosscheck: 28 dataset "
            "keys/20 organisms, 12 searches across six matching keys, 11 successes and "
            "one real regulator:null failure with retained raw fallback; successful "
            "component 76 summary. All 13 returned signed weights were independently "
            "checked earlier. This is expression context only."
        ),
        "context_only",
    ),
    local_evidence(
        "authority",
        "authority",
        PREFIX + "authority-source-originals/new-source-manifest.json",
        "97 retained native/UniProt source originals; finite selected identity set",
        (
            "Separate completed independent authority/code review accepted the exact "
            "63-native-original producer/consumer profile and additive snapshots. All "
            "128 selected labels and roles were bound; existing owners remain "
            "unchanged. This is identity/provenance support, not independent proof of "
            "biological mechanism."
        ),
    ),
]

for key, ref, locator, digest, summary in [
    (
        "magnesium-primary",
        "PMID:26448059; https://pmc.ncbi.nlm.nih.gov/articles/PMC4857615/",
        AP
        + (
            "archives/native-magnesium-successor.part-001.tar.gz :: "
            "native-magnesium-successor/originals/PMC4857615-efetch.xml; "
            './/p[@id="P13"], P14, P37, P39, P40'
        ),
        "44360d646bf5b6b3f123b0655788eb27a8a9ce470ba493ba4e6fc4c4ab725d26",
        (
            "Directly reread exact primary paragraphs: EDTA-treatment resistance is "
            "reported, while kinetic and HPLC assays add 6.6 and 1 mM MgCl2. GTP "
            "acceptance and tag cleavage remain recombinant-assay facts. The record "
            "neither asserts magnesium-independent activity nor a demonstrated bound-Mg "
            "requirement."
        ),
    ),
    (
        "cargo-primary",
        "PMID:22428024; https://pubmed.ncbi.nlm.nih.gov/22428024/",
        AP
        + (
            "archives/primary-evidence-preparation.part-001.tar.gz :: "
            "primary-evidence-preparation/originals/cargo-2012-primary.xml; "
            "/article/body/sec[4]/sec[2]/p[1], /body/sec[2]/sec[4]/p[1], "
            "/body/sec[2]/sec[8]/p[2]"
        ),
        "b31a9952234134bbcdad7022160ba80498eb19c9402d409dd01b53aceb5657e3",
        (
            "Directly reread LT2 19-residue EGFP motif construction, native Salmonella "
            "ethanolamine-host fluorescence and intact/broken-shell anti-GFP "
            "accessibility. The exact P19265 first 19 prefix/taxon binding was "
            "independently checked in design. Canonical edge 96 retains "
            "experimental_construct scope, not full-length EutC localization."
        ),
    ),
    (
        "euta-primary",
        "EcoCyc:ETHAMLY-CPLX",
        AP
        + (
            "archives/euta-target-followup.part-001.tar.gz :: "
            "euta-target-followup/originals/ECOLI-ETHAMLY-CPLX.xml; "
            "own component[1], component[2] and comment[1]"
        ),
        "796c3185af98fa998262835441853476388ed0ca2ba6ac28484e87bb5eedd55c",
        (
            "Prior independent direct intake accepted the newly acquired exact EcoCyc "
            "target, reciprocal EutA comment and six-plus-six components. It is not "
            "silently equated to the separately issued META complex."
        ),
    ),
    (
        "euta-assay",
        "PMID:15466038; https://journals.asm.org/doi/10.1128/jb.186.20.6845-6854.2004",
        AP
        + (
            "archives/euta-target-followup.part-001.tar.gz :: "
            "euta-target-followup/inputs/EutA-2004-publisher-web-reading.json; "
            "publisher L112–115, L123–128, L189–200"
        ),
        "47c0d8f4c042f2d9319485c297be0b4db4ed2a650e72155c347ef9645b5461f5",
        (
            "Prior independent publisher-text reading supports the qualified "
            "JM109/recombinant EutA and substrate-inactivated holoEAL assay. Actual "
            "edge 93 retains free AdoCbl/ATP/Mg conditions and distinguishes the "
            "CN-Cbl model. Exact assay/native sequence identity is not established."
        ),
    ),
]:
    evidence.append(
        {
            "evidence_id": key,
            "kind": "primary_source" if key != "euta-primary" else "database",
            "reference": ref,
            "locator": locator,
            "accessed_at": NOW,
            "support": "supports",
            "summary": summary,
            "snapshot_sha256": digest,
        }
    )

evidence.append(
    {
        "evidence_id": "independent-binding",
        "kind": "validation",
        "reference": str(OWNER / "canonical-binding-results.json"),
        "locator": "/checks; /reference_bindings; /mapping_counts",
        "accessed_at": NOW,
        "support": "supports",
        "snapshot_sha256": sha(OWNER / "canonical-binding-results.json"),
        "summary": (
            "5,513 finite independent canonical binding checks passed: actual/frozen "
            "equality, full preparation physical inventory, all reference original "
            "hashes, native issuing-object identities, UniProt accessions/taxa, mapping "
            "pointers and bibliographic metadata. The initial checker used the wrong "
            "activity-disposition token; corrected local checker/result and initial "
            "failure are both retained."
        ),
    }
)
evidence.append(
    {
        "evidence_id": "prior-search",
        "kind": "search",
        "reference": str(OWNER / "prior-review-search.stdout"),
        "locator": "Complete stdout; command/result in canonical-binding-results.json",
        "accessed_at": NOW,
        "support": "context_only",
        "snapshot_sha256": sha(OWNER / "prior-review-search.stdout"),
        "summary": (
            "No earlier canonical or historical review target match was found in the "
            "explicitly searched review directories."
        ),
        "search_scope": (
            "rg --no-ignore --hidden -n PWY0-1477|ethanolamine-utilization reviews "
            "reports/yaml_record_review reports/yaml_category_review; exit1; stderr "
            "empty. Hidden and ignored files included. Archive contents not decoded; "
            "this is not a global issue or literature search."
        ),
    }
)
evidence.append(
    {
        "evidence_id": "corpus-gates",
        "kind": "validation",
        "reference": PREFIX + "integration-gates/gate-results.json",
        "locator": "Terminal gate state, retained receipt bindings and exact log hashes",
        "accessed_at": NOW,
        "support": "supports",
        "snapshot_sha256": sha(REPO / (PREFIX + "integration-gates/gate-results.json")),
        "summary": (
            "Independently read and hash-verified root-executed final full-corpus gate "
            "receipts. Root ran these commands on the adopted working tree; this "
            "reviewer did not relabel them as personally rerun one-record checks. "
            "Independent intake passed 128 checks across all 62 retained original "
            "payloads. The 1,747-input inventory was observed after gates and is not "
            "a retroactive start-state attestation."
        ),
    }
)


def assessment(key, area, topic, text, ids, dimensions=None):
    row = {
        "assessment_id": key,
        "area": area,
        "topic": topic,
        "outcome": "supported",
        "summary": text,
        "target_ids": TARGETS,
        "evidence_ids": ids,
    }
    if dimensions:
        row["dimensions"] = [
            {"name": k, "value": v, "definition": d, "evidence_ids": ids} for k, v, d in dimensions
        ]
    return row


assessments = [
    assessment(
        "identity",
        "identity",
        "Exact pathway boundary and chemical identities",
        (
            "The record denotes the issued five-reaction ethanolamine-utilization "
            "pathway with both acetaldehyde branches. All 22 core material occurrences "
            "and four ordering edges survive. Charged native ethanolaminium is distinct "
            "from neutral EutH substrate; no broader GO process, KEGG biosynthetic "
            "module, normalized MetaNetX species or similarly named source object is "
            "asserted as an exact alias. EutT is ancillary rather than a sixth core "
            "member."
        ),
        ["maintained", "core", "graph"],
        [
            ("source-object", "META:PWY0-1477, release 27.0", "Exact issuing object and boundary"),
            (
                "reaction-direction",
                "One own L2R and four own reversible; selected traversal has two R2L reactions",
                "Own direction, pathway traversal and assay direction remain separate",
            ),
        ],
    ),
    assessment(
        "taxa",
        "scope",
        "Taxa, proteins and experimental preparations",
        (
            "Direct MG1655/LT2 pathway associations are retained without upgrading all "
            "experiments to those strains. K12 UniProt taxon 83333, LT2 proteins, "
            "NCIB8114 purification, JM109/BL21 recombinant hosts and engineered "
            "yeast/crude extracts remain distinct. The CPZ-55 caution is curator "
            "inference, not proof of route absence or intact native flux."
        ),
        ["maintained", "core", "biology", "graph"],
        [
            (
                "taxon-condition",
                (
                    "NCBITaxon:511145 and 99287 direct associations; K12 protein 83333; exact "
                    "experimental host in narrative/qualifiers"
                ),
                "Source taxon does not define every assay material",
            ),
            (
                "evidence-tier",
                (
                    "Direct assays, unpurified extracts, mutant phenotypes, similarity and "
                    "curator inference are distinguished"
                ),
                "No evidence-tier promotion across issued proteins",
            ),
        ],
    ),
    assessment(
        "core-graph",
        "graph",
        "Reactions, catalysts, composition and regulation",
        (
            "All 97 accepted edges and all endpoint qualifiers/evidence equal the "
            "reviewed complete selected graph. Seven selected native activities are "
            "represented; eight adjacent and 56 unrelated leads remain accounted context "
            "without unrelated catalysts. EutBC six-plus-six component slots and "
            "conflicting prose are explicit; subunits contribute through enables and "
            "qualified heteromer state. Nine in-scope regulation assertions retain "
            "exact activities and assay scope; three off-route backlinks do not become "
            "pathway members."
        ),
        ["maintained", "graph", "biology", "independent-binding"],
        [
            (
                "component-role",
                (
                    "EutBC complete catalysis versus subunit contribution; EutL three-chain "
                    "pseudohexamer; EutN preparation-dependent assembly"
                ),
                "Chain count, geometric shape and activity role are not conflated",
            ),
            (
                "branch-quantity",
                "No physiological branch ratio or single whole-route net asserted",
                "Balanced individual equations do not establish route flux",
            ),
        ],
    ),
    assessment(
        "conditional-context",
        "evidence",
        "Conditional activity, metal and localization evidence",
        (
            "All 19 scoped options are included with their accepted qualifications. "
            "EutP/Q GTP is an assay input without invented GDP output; EDTA resistance "
            "occurs under documented added-Mg conditions. EutT FeII refers to a "
            "reconstituted preparation. EutA reactivates the exact source-associated "
            "inactive recombinant EAL material under specified ATP/Mg/free-AdoCbl "
            "conditions. The EutC19-EGFP location edge denotes the tested short "
            "reporter, not full-length EutC. EutH membrane location does not assert "
            "charged-substrate transport or BMC delivery."
        ),
        ["maintained", "graph", "magnesium-primary", "cargo-primary", "euta-primary", "euta-assay"],
        [
            (
                "experimental-construct",
                "P/Q cleaved tags; Q GT remnant; A JM109/EAL state; EutC1–19-EGFP motif",
                "Assay materials travel in edge descriptions and endpoint qualifiers",
            ),
            (
                "compartment",
                (
                    "Native association, inferred lumen/side, engineered shells and reporter "
                    "encapsulation retain distinct scopes"
                ),
                "GO identity alone is not enzyme-localization evidence",
            ),
        ],
    ),
    assessment(
        "narrative",
        "completeness",
        "Biological context and unresolved source disagreements",
        (
            "All 23 actual narrative paragraphs were read and compared with 32 accepted "
            "primary claims, 19 conflict groups, 34 proteins, 71 activities and 3,705 "
            "native slots. Supported EutR regulation, conditional growth/washing/GSSG "
            "effects, shell architecture, EutG alternative substrates, EutE biochemical "
            "updates and ancillary EutT chemistry survive even where no exact typed "
            "relation is justified. Corrected wording distinguishes nine EutT material "
            "slots from coefficient-two amounts. Source-native EC, CML, oligomer, "
            "location and proton-count disagreements remain explicit."
        ),
        ["maintained", "record-preparation", "biology", "graph", "independent-binding"],
    ),
    assessment(
        "eutt-specificity",
        "evidence",
        "Oxidation-state specificity and limits of followup evidence",
        (
            "The actual record accurately attributes positive pre-reduced Co(I) "
            "cobinamide activity to the 2015 main report while retaining unavailable "
            "supporting assays and the native inactivity conflict. It does not mistake "
            "competitive inhibition for product detection, extend Co(II) coordination "
            "evidence to Co(I), invent physiological reductant identity or assert "
            "direct EutT-to-EAL delivery."
        ),
        ["maintained", "eutt", "biology"],
        [
            (
                "source-access",
                "2015 main/captions/Table 1 accepted; SI unavailable; 2006 main unread",
                "Availability and scientific reading scope remain distinct",
            )
        ],
    ),
    assessment(
        "references",
        "provenance",
        "Issuing references, labels and reproducible evidence placement",
        (
            "All 291 reference IDs are unique and internal evidence links resolve. All "
            "present source_sha256 values matched actual retained original bytes; "
            "native references identify exact issuing own objects and 34 UniProt "
            "references identify the actual accessions/taxa. Sixteen narrative "
            "references extend the prior 275; nine prior rows change only title/citation "
            "metadata. Multi-artifact readings avoid invented aggregate-original "
            "hashes. Native structured source assertions stay attributed to the "
            "database, not misrepresented as quotations from cited papers."
        ),
        ["maintained", "authority", "record-preparation", "independent-binding"],
    ),
    assessment(
        "expression-context",
        "scope",
        "iModulonDB crosscheck",
        (
            "The reused finite installed-adapter crosscheck supplies expression context "
            "only. Component 76 returns eutJ/G/H/A and negatively weighted ackA among 13 "
            "rows. Signed module weights do not define reaction direction, activation, "
            "catalyst identity, exact pathway membership or native-strain flux. The "
            "actual regulator:null failure and bounded raw fallback are retained; no "
            "dataset-exhaustion conclusion is made."
        ),
        ["maintained", "imodulon", "core"],
        [
            (
                "dataset-scope",
                (
                    "28 dataset keys/20 organisms; 12 actual searches in six matching keys; one "
                    "component 76 summary"
                ),
                "Finite returned results, not all transcriptomic genes or all experiments",
            )
        ],
    ),
    assessment(
        "gates",
        "schema",
        "Required corpus gates and ownership",
        (
            "Required full-corpus validation, tests, lint and diff checks have terminal "
            "successful root receipts for the actual adopted working tree. The "
            "scientific conclusion follows source interpretation and full-record "
            "review, with deterministic checks supporting schema/identifier/provenance "
            "integrity. This review changes neither the pathway, native status nor "
            "history and does not close GitHub issues."
        ),
        ["maintained", "corpus-gates"],
    ),
]

checks = [
    {
        "check_id": "canonical-inspect",
        "name": "Governed actual maintained-target inspect",
        "status": "passed",
        "required": True,
        "summary": (
            "Fresh inspect preceded formal assessment; expanded inspection added "
            "reviewed retained context and current justfile. All 12 originally inspected "
            "inputs remain byte-identical. Final inspection explicitly added the "
            "terminal gate package, binds 26 inputs and preserves all prior 24 hashes."
        ),
        "target_ids": TARGETS,
        "exit_code": 0,
        "command": shlex.join(INSPECT_RECEIPT["command"]),
        "evidence_ids": ["maintained"],
    },
    {
        "check_id": "canonical-binding",
        "name": "Independent finite canonical binding",
        "status": "passed",
        "required": True,
        "summary": (
            "5,513 checks passed; all 97 graph edges and 128 declarations unchanged; all "
            "original-hash references bound; final preparation physical inventory and "
            "coverage mappings verified."
        ),
        "target_ids": TARGETS,
        "command": (
            "PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 "
            "/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B "
            "check_canonical_binding.py"
        ),
        "exit_code": 0,
        "evidence_ids": ["independent-binding"],
        "scope_note": (
            "Owned scratch checker, not a new substitute corpus validator or proof that "
            "counts establish science."
        ),
    },
]
for gate in GATES["checks"]:
    checks.append(
        {
            "check_id": gate["key"],
            "name": gate["name"],
            "status": "passed",
            "required": gate["required"],
            "summary": gate["summary"],
            "target_ids": TARGETS,
            "command": gate["command"],
            "exit_code": gate["exit_code"],
            "evidence_ids": ["corpus-gates"],
            "scope_note": (
                "Root executed the exact documented command on the actual worktree; "
                "reviewer read terminal receipts/logs and verified their hashes."
            ),
        }
    )

review = {
    "schema_version": "1.0.0",
    "review_id": NOW.replace("-", "").replace(":", "") + "-ethanolamine-utilization-scientific",
    "kind": "record",
    "repository": "CultureBotAI/PathwayMech",
    "title": "Independent scientific review of ethanolamine utilization",
    "started_at": START,
    "finished_at": NOW,
    "reviewer": {
        "identity": "Codex agent /root/next272_core_and_context_review",
        "kind": "agent",
        "independence": "independent",
        "independence_basis": (
            "Independent of the record, native-source, primary-source and adapter "
            "authors. Previously reviewed finite core/context, graph design and "
            "authority integration; gave review findings but authored no maintained "
            "record or source packet. Current writes are scratch and this governed "
            "review bundle only."
        ),
    },
    "skill": ".claude/skills/review-yaml-record/SKILL.md",
    "completion": "completed",
    "verdict": "pass_with_limitations",
    "scientific_review": True,
    "summary": (
        "The actual adopted ethanolamine-utilization record is supported at its "
        "stated source and experimental scope. Full maintained-record reading and "
        "independent canonical binding preserve all five core reactions, both "
        "branches, 97 scoped edges, 128 declarations and the accepted source "
        "conflicts/limitations. No new actionable scientific finding was "
        "identified. Required full-corpus gates passed; this observation does not "
        "close existing GitHub issues or claim literature exhaustion."
    ),
    "source": INSPECT["source"],
    "scope": {
        "description": (
            "Scientific review of exactly one actual maintained PathwayRecord, "
            "including entire narrative, local graph, references and explicit "
            "source/assay limits."
        ),
        "selection": (
            "Exact root-authorized data/pathways/ethanolamine-utilization.yaml after "
            "adoption at SHA f1fd9402cab31bf3c62d53ef630abc52308c2c0e2d7b61d7ad6b9c0aaba"
            "8fb1e."
        ),
        "coverage": "full",
        "population_size": 1,
        "reviewed_target_ids": TARGETS,
        "exclusions": [
            {
                "target": "All other maintained pathway records",
                "reason": "Only corpus gates cover them; no new scientific assessment.",
            },
            {
                "target": "Adapter code, browser pixels and publication/merge state",
                "reason": "Separate code/integration work; this review concerns pathway science.",
            },
        ],
    },
    "targets": INSPECT["targets"],
    "checks": checks,
    "evidence": evidence,
    "assessments": assessments,
    "findings": [],
    "actions": [],
    "limitations": [
        (
            "Full target coverage means the entire one-record surface was assessed, not "
            "that every cited article or atomic database field was independently reread "
            "in full during this canonical step. Prior independent exact-source "
            "readings and their limits are retained; direct canonical rereading "
            "targeted the Mg/GTP methods, cargo reporter paragraphs and EutT "
            "specificity main text."
        ),
        (
            "Several primary sources have abstract-only or retained publisher-tool-text "
            "scope; one acquired historical PDF was not semantically read in the source "
            "review. EutT 2015 supporting assays, the 2006 EutT main, Starai 2005 main and "
            "many figure pixels/supplements remain unavailable or uninspected. No new "
            "web search or global evidence-exhaustion claim is made."
        ),
        (
            "The native acetate-kinase EC annotation, five CML placeholder "
            "representations, EutBC prose/component wording, EutN assembly forms, "
            "several compartment annotations, EutT proton count and cobinamide "
            "specificity retain source disagreements. The record reports their scope "
            "and does not resolve them by a convenient alias or unsupported mechanistic "
            "edge."
        ),
        (
            "No physiological branch ratio, whole-route net flux, exact in-vivo EutT "
            "reductant, direct EutT-to-EAL delivery, universal enzyme essentiality or "
            "universal full-length cargo topology is established."
        ),
        (
            "iModulonDB results are finite computational expression context. One "
            "unchanged adapter search failed on regulator:null; exact raw fallback and "
            "successful component summary do not establish dataset exhaustion, complete "
            "sampled population or native-strain activity."
        ),
        (
            "Historical reuse of ACETALD and Pi original bytes in the core preparation "
            "does not invent missing historical HTTP receipts. Multi-artifact primary "
            "references intentionally have no fabricated aggregate-original hash."
        ),
        (
            "No browser pixel review is claimed. Root owns rendering/KGX integration "
            "and publication; passing science and corpus gates do not prove deployment "
            "or merged-state issue closure."
        ),
        (
            "The full suite completed with 8,014 passed, 3 skipped and 7 warnings. "
            "The skips and deprecation warnings are retained in the exact root log; "
            "they are not reported as successful executed tests."
        ),
    ],
    "notes": [
        (
            "Findings: zero in this declared canonical scientific scope. The "
            "hidden/ignored-inclusive review-directory search found no predecessor "
            "record review for this target; it was not a global GitHub backlog search."
        ),
        (
            "Existing issues 634 (Mg interpretation), 635 (authority rejection hosts) "
            "and 636 (history argument forwarding) remain governed by their separately "
            "tracked merged-state acceptance. This clean review neither silently "
            "retires nor closes them."
        ),
        (
            "The root-authorized justfile new-history positional-argument fix was "
            "explicitly read before expanded inspect. Required validation/test/lint "
            "recipes are unchanged; its substantive command-injection review is "
            "separate."
        ),
        (
            "After the retained full gates, staging exposed upstream XML trailing "
            "spaces. Root tracked issue 637 and added a narrowly scoped source-file "
            "attribute exception; the staged successor receipt reports exit 0. "
            "That packaging change and its independent acceptance are operational "
            "work outside this scientific review. No prior inspected input changed, "
            "and the earlier unstaged diff check is not relabelled as a staged check."
        ),
    ],
    "tags": ["ethanolamine", "scientific-review", "source-scoped", "next272"],
}
(OWNER / "completed-review.yaml").write_text(
    yaml.dump(review, Dumper=ReviewDumper, sort_keys=False, allow_unicode=True, width=100)
)
print(
    json.dumps(
        {
            "review_id": review["review_id"],
            "finished_at": NOW,
            "checks": len(checks),
            "assessments": len(assessments),
            "evidence": len(evidence),
            "verdict": review["verdict"],
        },
        indent=2,
    )
)
