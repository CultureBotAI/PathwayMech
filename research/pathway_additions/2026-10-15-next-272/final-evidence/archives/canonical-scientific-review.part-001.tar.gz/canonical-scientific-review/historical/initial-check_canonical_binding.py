"""Read-only finite canonical-record binding checks; writes only this owner."""

import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

OWNER = Path(__file__).resolve().parent
REPO = Path('/private/tmp/pathwaymech-next-272-20261015')
PREP = Path('/private/tmp/pathwaymech-next-272-complete-record-preparation')
GRAPH = Path('/private/tmp/pathwaymech-next-272-graph-design')
checks = []


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def require(key, result, detail=''):
    checks.append({'key': key, 'passed': bool(result), 'detail': detail})


def read(p):
    return json.loads(p.read_text())


def pointer(obj, path):
    for key in path.strip('/').split('/'):
        obj = obj[int(key)] if isinstance(obj, list) else obj[key]
    return obj


record_path = REPO / 'data/pathways/ethanolamine-utilization.yaml'
record = yaml.safe_load(record_path.read_text())
graph = read(GRAPH / 'results/recommended-selected-graph-payload.json')
require('maintained exact candidate', digest(record_path) == 'f1fd9402cab31bf3c62d53ef630abc52308c2c0e2d7b61d7ad6b9c0aaba8fb1e')
require('full read snapshot unchanged', record_path.read_bytes() == (OWNER / 'maintained-input.yaml').read_bytes())
require('preparation manifest binding', digest(PREP / 'artifact-manifest.json') == 'fa1fca048f61b47ab3f626f888006962d19b7b730cd412c6678f4984c3879758')
require('preparation freeze binding', digest(PREP / 'freeze-proof.json') == '9ac5a1314b046b0824c46990e195271077c898eac5f88edd9ebbdcca1a76d48a')
manifest = read(PREP / 'artifact-manifest.json')
physical = {str(p.relative_to(PREP)) for p in PREP.rglob('*') if p.is_file()}
require('preparation physical inventory', physical == {r['path'] for r in manifest['files']} | {'artifact-manifest.json', 'freeze-proof.json'})
for row in manifest['files']:
    p = PREP / row['path']
    require('preparation ' + row['path'], p.stat().st_size == row['bytes'] and digest(p) == row['sha256'])

for key in ['id', 'participants', 'reactions', 'taxa', 'mechanistic_edges']:
    require('accepted complete selected graph exact ' + key, record[key] == graph[key])
refs = {r['id']: r for r in record['references']}
require('291 unique references', len(refs) == len(record['references']) == 291)
oldrefs = {r['id']: r for r in graph['references']}
reference_changes = {}
for identifier, prior in oldrefs.items():
    after = refs[identifier]
    changed = [k for k in set(prior) | set(after) if prior.get(k) != after.get(k)]
    if changed:
        reference_changes[identifier] = changed
    require('prior reference provenance ' + identifier, set(changed) <= {'title', 'citation'})

paragraphs = record['description'].split('\n\n')
narrative = read(PREP / 'results/narrative-map.json')
require('23 complete narrative paragraphs', len(paragraphs) == len(narrative) == 23)
for row in narrative:
    require('paragraph ' + row['key'], paragraphs[row['index']] == row['text'] and hashlib.sha256(row['text'].encode()).hexdigest() == row['text_sha256'])

mapping_counts = {}
for name, expected in [('primary-claim',32), ('conflict',19), ('protein',34), ('activity',71), ('native-slot',3705)]:
    rows = read(PREP / f'results/{name}-record-mapping.json')
    mapping_counts[name] = len(rows)
    require(name + ' finite population', len(rows) == expected)
    for i, row in enumerate(rows):
        for binding in row.get('record_narrative', []):
            text = paragraphs[binding['index']]
            require(f'{name} {i} paragraph', hashlib.sha256(text.encode()).hexdigest() == binding['text_sha256'])
        for key in ['record_node', 'record_reference', 'reference_pointer']:
            if row.get(key):
                value = pointer(record, row[key])
                identifier = row.get('source_id', row.get('id'))
                if key == 'record_node' and name == 'protein':
                    require(f'{name} {i} declared identity', value['id'] == identifier)
                if key == 'record_reference':
                    require(f'{name} {i} source identity/hash', value['id'] == row['source_id'] and value['source_sha256'] == row['source_sha256'])
        for edgepath in row.get('record_edges', []):
            require(f'{name} {i} edge resolves', bool(pointer(record, edgepath)['evidence']))

activities = read(PREP / 'results/activity-record-mapping.json')
activity_distribution = {}
for row in activities:
    activity_distribution[row['disposition']] = activity_distribution.get(row['disposition'], 0) + 1
    require('selected activity membership ' + row['activity'], bool(row['record_edges']) == (row['disposition'] == 'selected_direct_pathway_enzyme'))

# Hash candidates are drawn from explicit retained preparation inventories. Each
# matching original is reread; an inventory hash alone does not verify content.
packets = ['native-source-preparation', 'core-identity-preparation', 'primary-evidence-preparation', 'euta-target-followup', 'eutt-specificity-followup', 'imodulondb-preparation']
hash_paths = {}
for packet in packets:
    base = Path('/private/tmp/pathwaymech-next-272-' + packet)
    for row in read(base / 'artifact-manifest.json')['files']:
        hash_paths.setdefault(row['sha256'], []).append(base / row['path'])
bindings = []
for identifier, ref in refs.items():
    sha = ref.get('source_sha256')
    if not sha:
        bindings.append({'id': identifier, 'status': 'multi-artifact reference; no invented aggregate original hash', 'source_version': ref['source_version']})
        continue
    candidates = hash_paths.get(sha, [])
    p = next((p for p in candidates if p.is_file() and digest(p) == sha), None)
    require('retained exact reference original ' + identifier, p is not None)
    if p is None:
        bindings.append({'id': identifier, 'sha256': sha, 'status': 'no match in finite packet inventories'})
        continue
    bindings.append({'id': identifier, 'sha256': sha, 'path': str(p), 'bytes': p.stat().st_size})
    if identifier.startswith(('MetaCyc:', 'EcoCyc:')):
        prefix, local = identifier.split(':', 1)
        expected_org = 'META' if prefix == 'MetaCyc' else 'ECOLI'
        root = ET.fromstring(p.read_bytes())
        own = [e for e in root if e.get('frameid') == local and e.get('orgid') == expected_org and e.get('ID') == expected_org + ':' + local]
        require('native issuing own object ' + identifier, len(own) == 1)
    elif identifier.startswith('UniProtKB:'):
        source = read(p)
        require('UniProt exact accession ' + identifier, source['primaryAccession'] == identifier.split(':')[1])
        require('UniProt allowed source taxa ' + identifier, source['organism']['taxonId'] in (83333, 99287))

for row in read(PREP / 'results/bibliographic-record-mapping.json'):
    p = Path(row['source'])
    require('bibliographic original ' + row['reference_id'], digest(p) == row['sha256'])
    require('bibliographic exact title ' + row['reference_id'], refs[row['reference_id']]['title'] == row['title'])
    if p.suffix == '.json':
        native = pointer(read(p), row['locator'])
        require('bibliographic exact PMID ' + row['reference_id'], str(native['id']) == row['reference_id'].split(':')[1])
        require('bibliographic exact source title ' + row['reference_id'], native['title'] == row['title'])
        require('bibliographic DOI ' + row['reference_id'], native['doi'].lower() in refs[row['reference_id']]['citation'].lower())

search_cmd = ['rg', '--no-ignore', '--hidden', '-n', 'PWY0-1477|ethanolamine-utilization', 'reviews', 'reports/yaml_record_review', 'reports/yaml_category_review']
search = subprocess.run(search_cmd, cwd=REPO, capture_output=True, text=True, check=False)
(OWNER / 'prior-review-search.stdout').write_text(search.stdout)
(OWNER / 'prior-review-search.stderr').write_text(search.stderr)
require('prior review search completed', search.returncode in (0,1), search.stderr)
result = {
    'scope': 'Canonical binding and finite source-integrity checks; scientific interpretation is separate and uses full maintained record reading plus retained independent source review.',
    'maintained_sha256': digest(record_path), 'checks': checks,
    'passed': sum(c['passed'] for c in checks), 'failed': [c for c in checks if not c['passed']],
    'mapping_counts': mapping_counts, 'activity_distribution': activity_distribution,
    'reference_changes': reference_changes, 'added_references': sorted(set(refs)-set(oldrefs)),
    'reference_bindings': bindings,
    'prior_review_search': {'command': search_cmd, 'exit_code': search.returncode, 'ignored_and_hidden_included': True, 'archive_contents_decoded': False},
    'frozen_packets_written': False, 'maintained_record_written': False,
}
(OWNER / 'canonical-binding-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['passed', 'failed', 'mapping_counts', 'activity_distribution', 'added_references']}, indent=2))
raise SystemExit(bool(result['failed']))
