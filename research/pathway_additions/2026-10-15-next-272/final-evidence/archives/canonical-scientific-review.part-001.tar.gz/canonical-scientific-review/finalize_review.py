"""Freeze the completed independent canonical review after terminal governed checks."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import yaml

OWNER = Path(__file__).resolve().parent
REPO = Path("/private/tmp/pathwaymech-next-272-20261015")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


assert not (OWNER / "freeze-proof.json").exists()
receipts = json.loads((OWNER / "canonical-command-receipts.json").read_text())
assert [r["name"] for r in receipts] == [
    "canonical-validate",
    "canonical-save",
    "canonical-check",
]
assert all(r["exit_code"] == 0 for r in receipts)
for receipt in receipts:
    for log in receipt["logs"].values():
        p = Path(log["path"])
        assert sha(p) == log["sha256"] and p.stat().st_size == log["bytes"]
review = yaml.safe_load((OWNER / "completed-review.yaml").read_text())
pair = json.loads((OWNER / "canonical-saved-pair.json").read_text())
for item in pair.values():
    maintained, copied = REPO / item["maintained_path"], OWNER / item["scratch_copy"]
    assert maintained.read_bytes() == copied.read_bytes()
    assert sha(copied) == item["sha256"] and copied.stat().st_size == item["bytes"]
saved = yaml.safe_load((OWNER / "canonical-bundle/review.yaml").read_text())
assert saved == review
markdown = (OWNER / "canonical-bundle/review.md").read_text()
embedded = markdown.split("```yaml\n", 1)[1].rsplit("```", 1)[0]
assert yaml.safe_load(embedded) == saved
inputs = []
for item in saved["source"]["inputs"]:
    actual = sha(REPO / item["path"])
    assert actual == item["sha256"], item["path"]
    inputs.append({"path": item["path"], "sha256": actual})
assert len(inputs) == 26
write_json(
    OWNER / "post-save-integrity.json",
    {
        "utc": datetime.now(UTC).isoformat(),
        "input_count": len(inputs),
        "all_inspected_inputs_unchanged": True,
        "saved_yaml_semantically_equals_authorized_content": True,
        "rendered_embedded_yaml_equals_saved_yaml": True,
        "saved_copies_exact": True,
        "inputs": inputs,
        "canonical_pair": pair,
    },
)
post = json.loads((OWNER / "canonical-check.stdout").read_text())
result = {
    "status": "completed_canonical_scientific_review",
    "review_id": saved["review_id"],
    "verdict": saved["verdict"],
    "scientific_review": True,
    "findings_by_severity": {"blocker": 0, "major": 0, "minor": 0},
    "target": saved["targets"][0],
    "target_sha256": sha(REPO / saved["targets"][0]["path"]),
    "baseline": saved["source"]["git_revision"],
    "inspected_inputs": 26,
    "assessments": len(saved["assessments"]),
    "evidence_items": len(saved["evidence"]),
    "canonical_binding_checks": 5513,
    "record_archive_intake_checks": 129,
    "gate_package_intake_checks": 128,
    "full_suite": {"passed": 8014, "skipped": 3, "warnings": 7, "seconds": 1014.26},
    "root_full_gates_all_exit_zero": True,
    "governed_validate_save_check_all_exit_zero": True,
    "post_save_check": post,
    "canonical_pair": pair,
    "readable_receipts": [
        "canonical-command-receipts.json",
        "canonical-check.stdout",
        "canonical-check.stderr",
        "post-save-integrity.json",
    ],
    "limitations": saved["limitations"],
    "ownership": (
        "Reviewer maintained writes are only the saver-generated canonical pair. "
        "No record, code, history, source-owner or runtime modification; no network, "
        "Git/GitHub mutation or install. Parent owns staged packaging and issue closure."
    ),
    "future_retention": (
        "The not-yet-created final-evidence package is not an inspected source input. "
        "Parent may retain this completed immutable owner and exact saved pair later."
    ),
    "all_started_jobs_terminal": True,
}
write_json(OWNER / "RESULT.json", result)
with (OWNER / "OPERATIONS.md").open("a") as out:
    out.write(
        "\nGoverned validate, save and full post-save check completed with exit 0. "
        f"The final review ID is `{saved['review_id']}`. Exact saved copies and hashes "
        "are in canonical-bundle/ and canonical-saved-pair.json. The generated Markdown "
        "prose was reviewed; an initially oversized full print was truncated because "
        "it also embeds the YAML, so the final limitations were read separately. The "
        "entire embedded YAML was parsed and compared semantically with the saved "
        "authoritative YAML. Post-save integrity rechecks all 26 input hashes unchanged. "
        "No follow-on reviewer command mutates the maintained pair. All subprocesses "
        "are terminal at freeze. Full physical inventory includes hidden and ignored "
        "files; no source or reviewer evidence was deleted.\n"
    )
(OWNER / "HANDOFF.md").write_text(
    "# Canonical scientific review handoff\n\n"
    "Completed the independent scientific review of the actual maintained "
    "`data/pathways/ethanolamine-utilization.yaml` (MetaCyc:PWY0-1477), SHA256 "
    f"`{result['target_sha256']}`. Verdict: **pass with limitations**. "
    "There are zero blocker, major or minor findings in the declared one-record "
    "scientific scope. This does not close existing issues or establish merge state.\n\n"
    "The entire 3,805-line maintained record was read after fresh governed inspect. "
    "Its 23 narrative paragraphs, 97 scoped edges, 128 declarations and 291 references "
    "retain the accepted source conflicts and experimental qualifications. The "
    "finite canonical binding passed 5,513 checks; record-retention intake passed "
    "129 checks; terminal gate-package intake passed 128 checks. These support "
    "integrity and coverage and do not substitute for scientific interpretation.\n\n"
    "All required root-executed corpus gates passed. The full suite reports 8,014 "
    "passed, 3 skipped and 7 warnings. The reviewer verified exact terminal receipts "
    "rather than claiming to rerun root commands. Governed review validate, save and "
    "post-save check all passed. Full check output is `canonical-check.stdout`; "
    "commands, timestamps and exact log hashes are in `canonical-command-receipts.json`. "
    "All 26 inspected input hashes remain unchanged after save.\n\n"
    "The canonical maintained pair is:\n\n"
    f"- `{pair['review']['maintained_path']}`; SHA256 `{pair['review']['sha256']}`.\n"
    f"- `{pair['markdown']['maintained_path']}`; SHA256 `{pair['markdown']['sha256']}`.\n\n"
    "Readable exact copies for retention are **`canonical-bundle/review.yaml`** and "
    "**`canonical-bundle/review.md`**. Also expose `RESULT.json`, "
    "`canonical-command-receipts.json`, `canonical-check.stdout`, "
    "`canonical-check.stderr`, `post-save-integrity.json`, and top-level Markdown. "
    "Retain the complete physical owner, including historical validation failures "
    "and scratch checker corrections. The two rejected review assembly attempts "
    "saved no maintained bundle; the successful immutable pair is unambiguous.\n\n"
    "The scientific limits remain explicit: retained source reading is finite; not "
    "every cited paper, supplement or figure was reread; EutT SI and selected primary "
    "mains remain unavailable/unread. Native chemistry, assembly, compartment and "
    "specificity conflicts remain attributed. There is no asserted physiological "
    "branch ratio, whole-route net flux, exact EutT reductant or direct delivery. "
    "iModulonDB is bounded expression context. Historical reused original bytes "
    "do not acquire fabricated HTTP receipts. Browser pixels, adapter acceptance, "
    "staged XML packaging and publication are separate work. See the canonical "
    "pair and OPERATIONS.md for complete limits and chronology.\n\n"
    "Only the canonical pair was written to maintained content by this reviewer. "
    "There were no record/code/history edits, Git/GitHub mutations, network calls, "
    "installs, shared runtime changes or known incidental original-checkout writes. "
    "Python bytecode was disabled; Ruff used explicit --no-cache. All jobs are "
    "terminal. This full physical inventory includes hidden/ignored files. The "
    "future final-evidence retention package is not one of the canonical inspected "
    "inputs, avoiding a provenance cycle. This owner is immutable after freeze; "
    "any correction requires a successor.\n"
)
files = []
for p in sorted(OWNER.rglob("*")):
    assert not p.is_symlink(), p
    if p.is_file() and str(p.relative_to(OWNER)) not in {
        "artifact-manifest.json",
        "freeze-proof.json",
    }:
        files.append(
            {"path": str(p.relative_to(OWNER)), "bytes": p.stat().st_size, "sha256": sha(p)}
        )
manifest = {
    "schema": "physical-file-manifest/v1",
    "owner": str(OWNER),
    "scope": "All physical files recursively, including hidden/ignored content.",
    "excluded_files": ["artifact-manifest.json", "freeze-proof.json"],
    "files": files,
}
write_json(OWNER / "artifact-manifest.json", manifest)
freeze = {
    "frozen_utc": datetime.now(UTC).isoformat(),
    "manifest_sha256": sha(OWNER / "artifact-manifest.json"),
    "handoff_sha256": sha(OWNER / "HANDOFF.md"),
    "result_sha256": sha(OWNER / "RESULT.json"),
    "listed_file_count": len(files),
    "physical_file_count": len(files) + 2,
    "listed_bytes": sum(f["bytes"] for f in files),
    "all_started_jobs_terminal": True,
    "freeze_scope": "Immutable; any correction requires a successor.",
}
write_json(OWNER / "freeze-proof.json", freeze)
for item in files:
    p = OWNER / item["path"]
    assert p.stat().st_size == item["bytes"] and sha(p) == item["sha256"]
physical = {str(p.relative_to(OWNER)) for p in OWNER.rglob("*") if p.is_file()}
assert physical == {f["path"] for f in files} | {"artifact-manifest.json", "freeze-proof.json"}
print(json.dumps({**freeze, "freeze_sha256": sha(OWNER / "freeze-proof.json")}, indent=2))
