"""Read immutable Git objects into a portable review-only baseline archive."""

import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

WORKTREE = Path("/private/tmp/pathwaymech-next-272-20261015")
OWNER = Path(__file__).resolve().parent
BASELINE = "54e768a985d07705ea25445804c83b4758646e37"
SOURCES = [
    "src/pathwaymech/cli.py",
    "src/pathwaymech/graph_view.py",
    "src/pathwaymech/kgx.py",
    "src/pathwaymech/site_display.py",
    "src/pathwaymech/cross_mech.py",
    "docs/CAUSAL_GRAPHS.md",
]


def git(*args):
    return subprocess.run(
        ["git", *args],
        cwd=WORKTREE,
        check=True,
        capture_output=True,
    ).stdout


def main():
    tree = git("ls-tree", "-rz", BASELINE, "--", "data/pathways", "pages", *SOURCES)
    entries = []
    contents = []
    tree_items = [item for item in tree.split(b"\0") if item]
    object_ids = [item.split(b"\t", 1)[0].split()[2] for item in tree_items]
    batch = subprocess.run(
        ["git", "cat-file", "--batch"],
        cwd=WORKTREE,
        input=b"\n".join(object_ids) + b"\n",
        check=True,
        capture_output=True,
    ).stdout
    offset = 0
    for item in tree_items:
        if not item:
            continue
        metadata, path = item.split(b"\t", 1)
        mode, kind, object_id = metadata.decode().split()
        path = path.decode()
        assert kind == "blob" and mode == "100644", (path, mode, kind)
        end = batch.index(b"\n", offset)
        object_header = batch[offset:end].split()
        assert object_header[0].decode() == object_id
        size = int(object_header[2])
        raw = batch[end + 1 : end + 1 + size]
        offset = end + size + 2
        entries.append(
            {
                "path": path,
                "git_object_id": object_id,
                "mode": mode,
                "size": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        )
        contents.append((path, raw))
    archive = OWNER / "baseline.tar.gz"
    with archive.open("wb") as handle:
        with gzip.GzipFile(filename="", fileobj=handle, mode="wb", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w|", format=tarfile.PAX_FORMAT) as tar:
                for path, raw in contents:
                    info = tarfile.TarInfo(path)
                    info.size = len(raw)
                    info.mode = 0o644
                    tar.addfile(info, io.BytesIO(raw))
    record_paths = [
        e["path"]
        for e in entries
        if e["path"].startswith("data/pathways/") and e["path"].endswith(".yaml")
    ]
    page_paths = [e["path"] for e in entries if e["path"].startswith("pages/records/")]
    assert len(record_paths) == 268 and len(page_paths) == 268
    manifest = {
        "baseline_commit": BASELINE,
        "baseline_tree": git("rev-parse", BASELINE + "^{tree}").decode().strip(),
        "method": (
            "Git recursive tree includes every tracked path irrespective of ignore rules; "
            "current physical paths are inventoried separately after integration readiness."
        ),
        "old_records": len(record_paths),
        "old_record_pages": len(page_paths),
        "archive": {
            "path": archive.name,
            "size": archive.stat().st_size,
            "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        },
        "files": entries,
    }
    (OWNER / "baseline-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({k: v for k, v in manifest.items() if k != "files"}, indent=2))


if __name__ == "__main__":
    main()
