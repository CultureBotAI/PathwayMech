"""Derive collection counts and new index/history expectations from actual YAML."""

import hashlib
import json
from pathlib import Path

import yaml

from audit_integration import DOM, norm, plain

OWNER = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/pathwaymech-next-272-20261015")
RECORD_ID = "MetaCyc:PWY0-1477"
HISTORY = "history/records/ethanolamine-utilization/2026-10-16T062849Z-codex-fe5e5e.yaml"


def main():
    records = [
        yaml.safe_load(p.read_bytes()) for p in sorted((ROOT / "data/pathways").rglob("*.yaml"))
    ]
    record = next(r for r in records if r["id"] == RECORD_ID)
    checks = {}
    expected_stats = {
        "Pathway records": len(records),
        "Taxa represented": len({t["id"] for r in records for t in r.get("taxa", [])}),
        "Mechanistic edges": sum(len(r.get("mechanistic_edges", [])) for r in records),
        "Distinct references": len({ref["id"] for r in records for ref in r.get("references", [])}),
    }
    home = DOM((ROOT / "pages/index.html").read_text()).root
    observed_stats = {
        n.tagged("dt")[0].text: int(n.tagged("dd")[0].text.replace(",", ""))
        for n in home.tagged("div")
        if n.attrs.get("class") == "home-stat"
    }
    checks["home-all-collection-metrics"] = observed_stats == expected_stats
    index = json.loads((ROOT / "pages/pathway_index.json").read_bytes())
    new = [row for row in index["records"] if row["id"] == RECORD_ID]
    prefixes = {"UniProtKB", "SGD", "EC", "Ensembl", "Entrez", "NCBIProtein", "TubercuList"}
    expected_index = {
        "id": RECORD_ID,
        "label": record["label"],
        "pathway_type": record["pathway_type"],
        "page": "records/MetaCyc_PWY0-1477.html",
        "url": "https://culturebotai.github.io/PathwayMech/pages/records/MetaCyc_PWY0-1477.html",
        "taxa": record["taxa"],
        "proteins": [
            {"id": p["id"], "label": p["label"]}
            for p in record["participants"]
            if p["id"].split(":")[0] in prefixes
        ],
        "reactions": [r["id"] for r in record["reactions"]],
    }
    checks["index-complete-new-entry"] = new == [expected_index]
    browse = DOM((ROOT / "pages/browse.html").read_text()).root
    new_links = [a for a in browse.tagged("a") if a.attrs.get("href") == expected_index["page"]]
    checks["browse-exact-new-entry"] = len(new_links) == 1 and (
        plain(record["label"]) in new_links[0].text
        and RECORD_ID in new_links[0].text
        and "97 mechanistic edges" in new_links[0].text
    )
    manifest = json.loads((ROOT / "pages/downloads/manifest.json").read_bytes())
    combined = (ROOT / "pages/downloads/nodes.tsv").read_bytes() + (
        ROOT / "pages/downloads/edges.tsv"
    ).read_bytes()
    fingerprint = hashlib.sha256(combined).hexdigest()
    checks["manifest-combined-export-fingerprint"] = manifest["version"] == "sha256:" + fingerprint
    checks["home-current-export-fingerprint"] = fingerprint in home.text
    page = DOM((ROOT / "pages/records/MetaCyc_PWY0-1477.html").read_text()).root
    history_raw = (ROOT / HISTORY).read_bytes()
    history = yaml.safe_load(history_raw)
    checks["history-exact-target"] = (
        history["target"]["path"] == "data/pathways/ethanolamine-utilization.yaml"
    )
    checks["history-codex-attribution"] = history["session"]["actors"][0]["name"] == "codex"
    checks["page-session-source-identity"] = any(
        a.attrs.get("href") == "https://github.com/CultureBotAI/PathwayMech/blob/main/" + HISTORY
        for a in page.tagged("a")
    )
    checks["page-session-time"] = history["session"]["timestamp"] in page.text
    for number, event in enumerate(history["events"]):
        checks[f"page-history-summary-{number}"] = norm(plain(event["summary"])) in norm(page.text)
        checks[f"page-history-details-{number}"] = norm(plain(event["details"])) in norm(page.text)
    checks["source-yaml-link"] = any(
        a.attrs.get("href")
        == "https://github.com/CultureBotAI/PathwayMech/blob/main/data/pathways/ethanolamine-utilization.yaml"
        for a in page.tagged("a")
    )
    result = {
        "passed": all(checks.values()),
        "checks": checks,
        "collection_metrics": expected_stats,
        "new_index_entry": new,
        "history_path": HISTORY,
        "history_sha256": hashlib.sha256(history_raw).hexdigest(),
    }
    (OWNER / "global-output-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
