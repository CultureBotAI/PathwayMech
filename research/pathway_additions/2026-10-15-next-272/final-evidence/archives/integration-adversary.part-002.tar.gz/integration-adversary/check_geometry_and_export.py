"""Inspect actual SVG geometry and independently exported KGX byte parity."""

import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

OWNER = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/pathwaymech-next-272-20261015")
EXPORT = Path("/private/tmp/pathwaymech-next-272-ci/kgx")
checks = []


def check(name, passed, detail=None):
    checks.append({"key": name, "passed": bool(passed), "detail": detail})


def endpoints(path):
    parts = re.findall(r"([MCHVL])\s*([^MCHVL]+)", path)
    start = None
    x = y = 0.0
    for command, args in parts:
        values = [float(v) for v in re.findall(r"-?\d+(?:\.\d+)?", args)]
        if command in {"M", "L"}:
            assert len(values) == 2
            x, y = values
        elif command == "C":
            assert len(values) == 6
            x, y = values[-2:]
        elif command == "H":
            assert len(values) == 1
            x = values[0]
        elif command == "V":
            assert len(values) == 1
            y = values[0]
        if start is None:
            assert command == "M"
            start = (x, y)
    return start, (x, y)


def on_box(point, box):
    x, y = point
    left, top, right, bottom = box
    return left <= x <= right and top <= y <= bottom and (x in {left, right} or y in {top, bottom})


def main():
    svg_raw = (OWNER / "actual-network.svg").read_bytes()
    svg = ET.fromstring(svg_raw)
    ns = {"s": "http://www.w3.org/2000/svg"}
    left, top, width, height = [float(v) for v in svg.attrib["viewBox"].split()]
    check("zero-viewbox-origin", left == top == 0)
    markers = {n.attrib["id"] for n in svg.findall(".//s:marker", ns)}
    nodes = {}
    for link in svg.findall("s:a", ns):
        if link.attrib.get("class") != "graph-node":
            continue
        shape = next(n for n in link if n.attrib.get("class") == "graph-node-shape")
        if shape.tag.endswith("rect"):
            x, y, w, h = [float(shape.attrib[k]) for k in ("x", "y", "width", "height")]
            box = x, y, x + w, y + h
        else:
            points = [
                [float(v) for v in pair.split(",")] for pair in shape.attrib["points"].split()
            ]
            box = (
                min(p[0] for p in points),
                min(p[1] for p in points),
                max(p[0] for p in points),
                max(p[1] for p in points),
            )
        identifier = link.attrib["data-node-id"]
        nodes[identifier] = box
        check(
            "node-inside-viewbox/" + identifier,
            0 <= box[0] < box[2] <= width and 0 <= box[1] < box[3] <= height,
        )
    for link in svg.findall("s:a", ns):
        if "graph-edge" not in link.attrib.get("class", "").split():
            continue
        line = next(n for n in link if n.attrib.get("class") == "graph-edge-line")
        start, end = endpoints(line.attrib["d"])
        anchor = link.attrib["href"]
        check(
            "arrow-starts-at-subject/" + anchor, on_box(start, nodes[link.attrib["data-subject"]])
        )
        check("arrow-ends-at-object/" + anchor, on_box(end, nodes[link.attrib["data-object"]]))
        check("arrow-marker-resolves/" + anchor, line.attrib["marker-end"][5:-1] in markers)
    for index, text in enumerate(svg.findall(".//s:text", ns)):
        x, y = float(text.attrib["x"]), float(text.attrib["y"])
        check("text-anchor-inside-viewbox/" + str(index), 0 <= x <= width and 0 <= y <= height)
    boxes = list(nodes.items())
    for index, (identifier, box) in enumerate(boxes):
        overlaps = []
        for other, b in boxes[index + 1 :]:
            if max(box[0], b[0]) < min(box[2], b[2]) and max(box[1], b[1]) < min(box[3], b[3]):
                overlaps.append(other)
        check("nonoverlapping-node-box/" + identifier, not overlaps, overlaps)
    exports = {}
    for name in ("nodes.tsv", "edges.tsv"):
        published = (ROOT / "pages/downloads" / name).read_bytes()
        separate = (EXPORT / name).read_bytes()
        check("independent-cli-export-parity/" + name, published == separate)
        exports[name] = {"sha256": hashlib.sha256(published).hexdigest(), "size": len(published)}
    result = {
        "scope": "Structural SVG geometry and standalone CLI KGX parity; no pixel/browser test.",
        "svg_sha256": hashlib.sha256(svg_raw).hexdigest(),
        "viewbox": [left, top, width, height],
        "exports": exports,
        "checks": checks,
        "passed": all(c["passed"] for c in checks),
    }
    (OWNER / "geometry-and-export-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}, indent=2))
    print(json.dumps([c for c in checks if not c["passed"]], indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
