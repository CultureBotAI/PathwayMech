"""Challenge the independent audit with in-memory corruptions of actual artifacts.

OverlayPath changes only reads. Maintained and frozen files are never written.
Each case keeps its bounded mutation and full checker receipt in scratch.
"""

import argparse
import contextlib
import csv
import io
import json
import re
from pathlib import Path, PosixPath

import yaml

import audit_integration as audit

ROOT = Path("/private/tmp/pathwaymech-next-272-20261015")
OWNER = Path(__file__).resolve().parent
PAGE = "pages/records/MetaCyc_PWY0-1477.html"
RECORD = "data/pathways/ethanolamine-utilization.yaml"
overrides = {}


class OverlayPath(PosixPath):
    def read_bytes(self):
        if str(self) in overrides:
            return overrides[str(self)]
        return super().read_bytes()

    def read_text(self, encoding=None, errors=None, newline=None):
        if str(self) in overrides:
            return self.read_bytes().decode(encoding or "utf-8", errors or "strict")
        return super().read_text(encoding=encoding, errors=errors, newline=newline)


def rewrite_tsv(raw, change):
    reader = csv.DictReader(io.StringIO(raw.decode()), delimiter="\t")
    rows = list(reader)
    change(rows)
    output = io.StringIO(newline="")
    writer = csv.DictWriter(
        output, fieldnames=reader.fieldnames, delimiter="\t", lineterminator="\n"
    )
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().encode()


def main(output_name, only):
    cases_root = OWNER / output_name
    cases_root.mkdir(exist_ok=False)
    record = yaml.safe_load((ROOT / RECORD).read_bytes())
    page = (ROOT / PAGE).read_text()
    dom = audit.DOM(page).root
    svg_edges = [n for n in dom.tagged("a") if "graph-edge" in n.attrs.get("class", "").split()]
    endpoints = {e[k] for e in record["mechanistic_edges"] for k in ("subject", "object")}
    isolated = sorted({n["id"] for n in record["participants"]} - endpoints)[0]
    node_pattern = r'<a class="graph-node" data-node-id="' + re.escape(isolated) + r'".*?</a>'
    without_node, removed = re.subn(node_pattern, "", page, count=1, flags=re.S)
    assert removed == 1
    qnumber, qedge = next(
        (i, e) for i, e in enumerate(record["mechanistic_edges"], 1) if e.get("endpoint_qualifiers")
    )
    qkey = svg_edges[qnumber - 1].attrs["data-subject"]
    collapsed = page.replace(f'data-subject="{qkey}"', f'data-subject="{qedge["subject"]}"', 1)
    assert collapsed != page
    reporter = record["mechanistic_edges"][-1]["endpoint_qualifiers"][0]["description"]
    reporter_lost = page.replace(reporter, "Full-length native EutC has unqualified location.")
    assert reporter_lost != page
    first = svg_edges[0]
    before = (
        f'data-subject="{first.attrs["data-subject"]}" data-object="{first.attrs["data-object"]}"'
    )
    after = (
        f'data-subject="{first.attrs["data-object"]}" data-object="{first.attrs["data-subject"]}"'
    )
    reversed_edge = page.replace(before, after, 1)
    assert reversed_edge != page
    edges_raw = (ROOT / "pages/downloads/edges.tsv").read_bytes()

    def strip_qualifier(rows):
        row = next(
            r
            for r in rows
            if r["subject"] == qedge["subject"]
            and r["object"] == qedge["object"]
            and json.loads(r["evidence"]) == qedge["evidence"]
        )
        assert json.loads(row["endpoint_qualifiers"]) == qedge["endpoint_qualifiers"]
        row["endpoint_qualifiers"] = ""

    def strip_reference_metadata(rows):
        row = next(
            r
            for r in rows
            if r["subject"] == qedge["subject"]
            and r["object"] == qedge["object"]
            and json.loads(r["evidence"]) == qedge["evidence"]
        )
        metadata = json.loads(row["reference_metadata"])
        metadata[0]["url"] = "https://example.invalid/lost-source-identity"
        row["reference_metadata"] = json.dumps(metadata)

    old = json.loads((OWNER / "baseline-manifest.json").read_bytes())
    old_page = next(e["path"] for e in old["files"] if e["path"].startswith("pages/records/"))
    cases = [
        ("drop-disconnected-component", PAGE, without_node.encode(), "svg/all-declared-bases"),
        ("collapse-qualified-endpoint-to-native", PAGE, collapsed.encode(), "/separate-instance"),
        ("generalize-short-reporter-state", PAGE, reporter_lost.encode(), "/full-svg-qualifier"),
        ("reverse-svg-arrow", PAGE, reversed_edge.encode(), "/unqualified-native"),
        (
            "strip-kgx-endpoint-qualification",
            "pages/downloads/edges.tsv",
            rewrite_tsv(edges_raw, strip_qualifier),
            "kgx/qualifiers/",
        ),
        (
            "replace-kgx-reference-source",
            "pages/downloads/edges.tsv",
            rewrite_tsv(edges_raw, strip_reference_metadata),
            "kgx/reference-metadata/",
        ),
        (
            "change-old-page-one-byte",
            old_page,
            (ROOT / old_page).read_bytes() + b" ",
            "old-byte-preservation/" + old_page,
        ),
    ]
    results = []
    for name, path, changed, expected_key in cases:
        if only and name not in only:
            continue
        case = cases_root / name
        case.mkdir()
        overrides.clear()
        overrides[str(ROOT / path)] = changed
        audit.checks.clear()
        with (case / "audit.log").open("w") as output, contextlib.redirect_stdout(output):
            code = audit.run(OverlayPath(ROOT), RECORD, OWNER / "accepted-selection.json", case)
        observed = json.loads((case / "artifact-audit-result.json").read_bytes())
        failures = [c["key"] for c in observed["checks"] if not c["passed"]]
        result = {
            "case": name,
            "mutated_path": path,
            "original_sha256": audit.digest((ROOT / path).read_bytes()),
            "mutated_sha256": audit.digest(changed),
            "mutated_size": len(changed),
            "expected_failure_key": expected_key,
            "failed_checks": failures,
            "rejected": code == 1 and any(expected_key in k for k in failures),
        }
        (case / "mutation.json").write_text(json.dumps(result, indent=2) + "\n")
        results.append(result)
        print(json.dumps(result), flush=True)
    overrides.clear()
    summary = {
        "method": "In-memory read overlays; actual maintained bytes never written.",
        "cases": results,
        "passed": all(r["rejected"] for r in results),
    }
    (cases_root / "RESULT.json").write_text(json.dumps(summary, indent=2) + "\n")
    return 0 if summary["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-name", default="artifact-corruption-probes")
    parser.add_argument("--only", nargs="*", default=[])
    args = parser.parse_args()
    raise SystemExit(main(args.output_name, args.only))
