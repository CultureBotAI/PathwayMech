"""Exercise the actual just recipe using literal argv and scratch history output."""

import hashlib
import json
import os
import subprocess
from pathlib import Path

import yaml

OWNER = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/pathwaymech-next-272-20261015")
RESULTS = OWNER / "history-wrapper-review"


def main():
    RESULTS.mkdir(exist_ok=False)
    history_root = RESULTS / "generated history with spaces"
    sentinels = [
        RESULTS / name
        for name in ("semicolon-side-effect", "dollar-side-effect", "backtick-side-effect")
    ]
    summary = f"Multiword review; touch {sentinels[0]}"
    details = (
        'Preserve exact "double quotes", single\'quotes, colon: value, & ampersand, '
        f"and literal $HOME $(touch {sentinels[1]}) `touch {sentinels[2]}`.\n"
        "Second line retains spaces, Unicode Δ, tabs\tand backslash \\ exactly."
    )
    command = [
        "/usr/local/bin/just",
        "new-history",
        "--kind",
        "record",
        "--slug",
        "ethanolamine-utilization",
        "--target-root",
        "data/pathways",
        "--event",
        "REVIEW",
        "--outcome",
        "no_change",
        "--summary",
        summary,
        "--details",
        details,
        "--actor-name",
        "codex",
        "--agent-tool",
        "codex",
        "--issue",
        "636",
        "--history-root",
        str(history_root),
    ]
    environment = dict(os.environ)
    environment.update(
        {
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONNOUSERSITE": "1",
            "PYTHONPATH": "src:.",
            "UV_NO_SYNC": "1",
            "UV_PROJECT_ENVIRONMENT": "/private/tmp/pathwaymech-next-263-verified-venv",
            "UV_CACHE_DIR": "/private/tmp/pathwaymech-next-267-uv-cache",
        }
    )
    assert (ROOT / "data/pathways/ethanolamine-utilization.yaml").is_file()
    before = {str(p.relative_to(RESULTS)) for p in RESULTS.rglob("*") if p.is_file()}
    run = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, text=True)
    files = [p for p in history_root.rglob("*") if p.is_file()] if history_root.exists() else []
    observed = yaml.safe_load(files[0].read_text()) if len(files) == 1 else None
    checks = {
        "process_success": run.returncode == 0,
        "single_new_yaml": len(files) == 1 and files[0].suffix == ".yaml",
        "stdout_identifies_exact_file": bool(files)
        and run.stdout.splitlines()[-1] == str(files[0]),
        "exact_summary": bool(observed) and observed["events"][0]["summary"] == summary,
        "exact_multiline_details": bool(observed) and observed["events"][0]["details"] == details,
        "exact_actor": bool(observed)
        and observed["session"]["actors"]
        == [{"type": "ai_agent", "name": "codex", "agent_tool": "codex"}],
        "exact_target": bool(observed)
        and observed["target"]
        == {
            "kind": "record",
            "path": "data/pathways/ethanolamine-utilization.yaml",
            "slug": "ethanolamine-utilization",
        },
        "issue_uri": bool(observed)
        and observed["links"]["issues"]
        == ["https://github.com/CultureBotAI/PathwayMech/issues/636"],
        "no_shell_side_effect": all(not p.exists() for p in sentinels),
        "all_new_files_under_requested_history_root": (
            {str(p.relative_to(RESULTS)) for p in RESULTS.rglob("*") if p.is_file()} - before
            == {str(p.relative_to(RESULTS)) for p in files}
        ),
    }
    receipt = {
        "scope": (
            "Independent actual just new-history recipe regression, issue636; no maintained writes."
        ),
        "argv": command,
        "shell": False,
        "returncode": run.returncode,
        "stdout": run.stdout,
        "stderr": run.stderr,
        "checks": checks,
        "justfile_sha256": hashlib.sha256((ROOT / "justfile").read_bytes()).hexdigest(),
        "observed_record": observed,
        "passed": all(checks.values()),
        "inventory_method": "Path.rglob includes hidden and ignored physical paths.",
    }
    (RESULTS / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
