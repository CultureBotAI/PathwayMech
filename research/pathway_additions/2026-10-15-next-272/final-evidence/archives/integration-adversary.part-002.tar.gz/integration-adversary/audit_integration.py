"""Independent checks of maintained YAML, HTML/SVG and TSV artifact contracts.

Does not import renderer, exporter, adapter, or retention implementation code.
Run only after root announces record adoption and rendering are ready.
"""

import argparse
import csv
import hashlib
import io
import json
import re
import tarfile
import xml.etree.ElementTree as ET
from html import unescape
from html.parser import HTMLParser
from pathlib import Path

import yaml

OWNER = Path(__file__).resolve().parent
EXPECTED_SELECTION = "3a5438516cb6bd82075e575dbb152eaba84337ac8371a400b8b6ce964506a29e"
checks = []


def check(key, condition, detail=None):
    checks.append({"key": key, "passed": bool(condition), "detail": detail})


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def norm(text):
    return " ".join(text.split())


def plain(text):
    return re.sub(r"</?(?:sup|sub|i|em)>", "", unescape(text), flags=re.I)


class Node:
    def __init__(self, tag, attrs=None):
        self.tag = tag
        self.attrs = dict(attrs or [])
        self.children = []

    @property
    def text(self):
        return "".join(c if isinstance(c, str) else c.text for c in self.children)

    def walk(self):
        yield self
        for child in self.children:
            if isinstance(child, Node):
                yield from child.walk()

    def tagged(self, tag):
        return [n for n in self.walk() if n.tag == tag]


class DOM(HTMLParser):
    VOID = {
        "area",
        "base",
        "br",
        "col",
        "embed",
        "hr",
        "img",
        "input",
        "link",
        "meta",
        "param",
        "source",
        "track",
        "wbr",
    }

    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.root = Node("document")
        self.stack = [self.root]
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        node = Node(tag, attrs)
        self.stack[-1].children.append(node)
        if tag not in self.VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in self.VOID:
            self.stack.pop()

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == tag:
                del self.stack[index:]
                break

    def handle_data(self, text):
        self.stack[-1].children.append(text)


def tsv(raw):
    rows = list(csv.DictReader(io.StringIO(raw.decode()), delimiter="\t"))
    assert len({r["id"] for r in rows}) == len(rows), "duplicate TSV IDs"
    return {r["id"]: r for r in rows}


def evidence_checks(prefix, container, evidence, references):
    text = container.text
    links = [n.attrs.get("href") for n in container.tagged("a")]
    for i, item in enumerate(evidence):
        check(f"{prefix}/evidence-{i}/reference", item["reference_id"] in text)
        check(f"{prefix}/evidence-{i}/reference-link", references[item["reference_id"]] in links)
        for field in ("quote", "source_assertion", "source_locator"):
            if field in item:
                check(f"{prefix}/evidence-{i}/{field}", norm(item[field]) in norm(text))


def physical_inventory(root, relative):
    result = []
    for path in sorted((root / relative).rglob("*")):
        if path.is_symlink():
            result.append({"path": path.relative_to(root).as_posix(), "symlink": True})
        elif path.is_file():
            raw = path.read_bytes()
            result.append(
                {"path": path.relative_to(root).as_posix(), "size": len(raw), "sha256": digest(raw)}
            )
    return result


def run(root, record_path, selection_path, output_owner=None):
    output_owner = output_owner or OWNER
    baseline = json.loads((OWNER / "baseline-manifest.json").read_bytes())
    archive_raw = (OWNER / baseline["archive"]["path"]).read_bytes()
    check("baseline/archive-hash", digest(archive_raw) == baseline["archive"]["sha256"])
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode="r:gz") as tar:
        old = {m.name: tar.extractfile(m).read() for m in tar.getmembers()}
    for entry in baseline["files"]:
        check("baseline/blob/" + entry["path"], digest(old[entry["path"]]) == entry["sha256"])
    selected_raw = selection_path.read_bytes()
    check("selection/hash", digest(selected_raw) == EXPECTED_SELECTION)
    selected = json.loads(selected_raw)
    raw_record = (root / record_path).read_bytes()
    record = yaml.safe_load(raw_record)
    check("record/id", record["id"] == selected["id"])
    for field in ("participants", "reactions", "taxa", "mechanistic_edges"):
        check("record/accepted-selection/" + field, record.get(field) == selected[field])
    record_refs = {r["id"]: r for r in record["references"]}
    reference_metadata_changes = []
    for ref in selected["references"]:
        adopted = record_refs.get(ref["id"], {})
        check(
            "record/accepted-reference-provenance/" + ref["id"],
            {k: v for k, v in adopted.items() if k not in {"title", "citation"}}
            == {k: v for k, v in ref.items() if k not in {"title", "citation"}},
        )
        if adopted != ref:
            reference_metadata_changes.append({"id": ref["id"], "before": ref, "after": adopted})
    check(
        "record/no-unaccepted-graph-override",
        not record.get("reaction_mechanisms") and not record.get("detail_only_participant_ids"),
    )
    current = physical_inventory(root, "data/pathways") + physical_inventory(root, "pages")
    current_by_path = {entry["path"]: entry for entry in current}
    check("inventory/no-symlinks", all(not e.get("symlink") for e in current))
    for entry in baseline["files"]:
        path = entry["path"]
        if path.startswith(("data/pathways/", "pages/records/")) or not path.startswith("pages/"):
            check(
                "old-byte-preservation/" + path,
                (root / path).is_file() and digest((root / path).read_bytes()) == entry["sha256"],
            )
    old_record_paths = {p for p in old if p.startswith("data/pathways/")}
    old_page_paths = {p for p in old if p.startswith("pages/records/")}
    new_record_paths = {
        p for p in current_by_path if p.startswith("data/pathways/")
    } - old_record_paths
    new_page_paths = {p for p in current_by_path if p.startswith("pages/records/")} - old_page_paths
    page_path = "pages/records/MetaCyc_PWY0-1477.html"
    check(
        "inventory/exact-record-addition",
        new_record_paths == {record_path},
        sorted(new_record_paths),
    )
    check("inventory/exact-page-addition", new_page_paths == {page_path}, sorted(new_page_paths))
    check(
        "inventory/no-other-page-additions",
        {p for p in current_by_path if p.startswith("pages/")} - set(old) == {page_path},
    )
    for path in (
        "pages/style.css",
        "pages/.nojekyll",
        "pages/assets/pathway-network.css",
        "pages/assets/pathway-network.js",
    ):
        check("global/unchanged-asset/" + path, (root / path).read_bytes() == old[path])

    page = (root / page_path).read_text()
    dom = DOM(page).root
    all_ids = [n.attrs["id"] for n in dom.walk() if "id" in n.attrs]
    check("html/unique-ids", len(all_ids) == len(set(all_ids)))
    by_id = {n.attrs["id"]: n for n in dom.walk() if "id" in n.attrs}
    dangling = [
        n.attrs["href"]
        for n in dom.tagged("a")
        if n.attrs.get("href", "").startswith("#") and n.attrs["href"][1:] not in by_id
    ]
    check("html/all-local-fragments-resolve", not dangling, dangling)
    components = [n for n in dom.tagged("tr") if n.attrs.get("id", "").startswith("component-")]
    declarations = [n for field in ("taxa", "participants", "reactions") for n in record[field]]
    check("html/all-component-rows", len(components) == len(declarations))
    component_ids = [n.tagged("code")[0].text for n in components]
    check("html/complete-component-identities", component_ids == [n["id"] for n in declarations])
    for declaration, row in zip(declarations, components, strict=True):
        check("html/component-label/" + declaration["id"], plain(declaration["label"]) in row.text)
        if declaration.get("direction"):
            check(
                "html/reaction-direction/" + declaration["id"],
                declaration["direction"].replace("_", " ") in row.text,
            )
    for paragraph in re.split(r"\n\s*\n", record["description"]):
        check(
            "html/narrative/" + digest(paragraph.encode())[:12],
            norm(plain(paragraph)) in norm(dom.text),
        )
    reference_anchors = {}
    for ref in record["references"]:
        found = [
            n
            for n in dom.tagged("li")
            if n.attrs.get("id", "").startswith("reference-")
            and n.tagged("code")
            and n.tagged("code")[0].text == ref["id"]
        ]
        check("html/reference/" + ref["id"], len(found) == 1)
        if found:
            reference_anchors[ref["id"]] = "#" + found[0].attrs["id"]
            if ref.get("url"):
                check(
                    "html/reference/" + ref["id"] + "/source-url",
                    ref["url"] in [a.attrs.get("href") for a in found[0].tagged("a")],
                )
            for field in ("title", "citation", "source_version"):
                if ref.get(field):
                    check(
                        "html/reference/" + ref["id"] + "/" + field,
                        norm(plain(ref[field])) in norm(found[0].text),
                    )
    graph_edges = [n for n in dom.tagged("a") if "graph-edge" in n.attrs.get("class", "").split()]
    graph_nodes = [n for n in dom.tagged("a") if "graph-node" in n.attrs.get("class", "").split()]
    by_node = {n.attrs["data-node-id"]: n for n in graph_nodes}
    check("svg/edge-count", len(graph_edges) == 97)
    check("svg/node-identities-unique", len(by_node) == len(graph_nodes))
    expected_bases = {n["id"] for field in ("participants", "reactions") for n in record[field]}
    endpoints = {e[k] for e in record["mechanistic_edges"] for k in ("subject", "object")}
    expected_bases |= {n["id"] for n in record["taxa"] if n["id"] in endpoints}
    if record["id"] in endpoints:
        expected_bases.add(record["id"])
    actual_bases = {
        n.attrs["data-node-id"] for n in graph_nodes if n.attrs.get("data-qualified") != "true"
    }
    check("svg/all-declared-bases", actual_bases == expected_bases)
    isolated = expected_bases - endpoints
    check("svg/disconnected-context-present", isolated <= actual_bases, sorted(isolated))
    qualified = [n for n in graph_nodes if n.attrs.get("data-qualified") == "true"]
    check(
        "svg/qualified-count",
        len(qualified)
        == sum(len(e.get("endpoint_qualifiers", [])) for e in record["mechanistic_edges"]),
    )
    for number, (edge, svg_edge) in enumerate(
        zip(record["mechanistic_edges"], graph_edges, strict=True), 1
    ):
        prefix = "edge/" + edge["id"]
        row = by_id.get(f"mechanism-edge-{number}")
        check(prefix + "/table-row", row is not None)
        cells = [n for n in row.children if isinstance(n, Node) and n.tag == "td"]
        check(prefix + "/four-cells", len(cells) == 4)
        check(prefix + "/subject", cells[0].tagged("code")[0].text == edge["subject"])
        check(prefix + "/object", cells[2].tagged("code")[0].text == edge["object"])
        check(prefix + "/predicate", cells[1].text.startswith(edge["predicate"]))
        check(prefix + "/description", norm(edge.get("description", "")) in norm(cells[1].text))
        evidence_checks(prefix, cells[3], edge["evidence"], reference_anchors)
        check(prefix + "/svg-predicate", svg_edge.attrs["data-predicate"] == edge["predicate"])
        check(prefix + "/svg-evidence-link", svg_edge.attrs["href"] == "#" + row.attrs["id"])
        title = svg_edge.tagged("title")[0].text
        check(prefix + "/svg-title-aria", title == svg_edge.attrs["aria-label"])
        check(prefix + "/svg-description", norm(plain(edge.get("description", ""))) in norm(title))
        line = [n for n in svg_edge.tagged("path") if n.attrs.get("class") == "graph-edge-line"][0]
        check(prefix + "/arrow-directed", line.attrs.get("marker-end", "").startswith("url(#"))
        check(
            prefix + "/context-style",
            bool(line.attrs.get("stroke-dasharray"))
            == (
                edge["predicate"]
                in {"part_of", "has_part", "occurs_in", "located_in", "has_cofactor"}
            ),
        )
        qualifiers = {q["endpoint"]: q for q in edge.get("endpoint_qualifiers", [])}
        for role, cell_index in (("subject", 0), ("object", 2)):
            display_id = svg_edge.attrs["data-" + role]
            node = by_node[display_id]
            if role in qualifiers:
                qualifier = qualifiers[role]
                check(
                    prefix + "/" + role + "/native-id",
                    svg_edge.attrs["data-" + role + "-id"] == edge[role],
                )
                check(
                    prefix + "/" + role + "/separate-instance",
                    display_id != edge[role] and node.attrs.get("data-base-node-id") == edge[role],
                )
                check(
                    prefix + "/" + role + "/visible-qualified-label",
                    qualifier["kind"].replace("_", " ") in node.attrs["data-node-label"],
                )
                check(
                    prefix + "/" + role + "/full-svg-qualifier",
                    qualifier["description"] in title
                    and qualifier["description"] in node.attrs["aria-label"],
                )
                qid = f"mechanism-edge-{number}-qualifier-{role}"
                qnodes = [n for n in cells[cell_index].walk() if n.attrs.get("id") == qid]
                check(prefix + "/" + role + "/adjacent-qualifier", len(qnodes) == 1)
                check(
                    prefix + "/" + role + "/qualifier-description",
                    qualifier["description"] in qnodes[0].text,
                )
                check(prefix + "/" + role + "/qualifier-node-link", node.attrs["href"] == "#" + qid)
                evidence_checks(
                    prefix + "/" + role, qnodes[0], qualifier["evidence"], reference_anchors
                )
                for evidence in qualifier["evidence"]:
                    for field in ("reference_id", "quote", "source_assertion", "source_locator"):
                        if field in evidence:
                            check(
                                prefix
                                + "/"
                                + role
                                + "/svg-"
                                + field
                                + "/"
                                + digest(evidence[field].encode())[:10],
                                evidence[field] in title
                                and evidence[field] in node.attrs["aria-label"],
                            )
            else:
                check(prefix + "/" + role + "/unqualified-native", display_id == edge[role])
    svg_markup = re.search(
        r'<svg xmlns="http://www.w3.org/2000/svg" class="pathway-network-svg".*?</svg>', page, re.S
    ).group()
    svg = ET.fromstring(svg_markup)
    check("svg/standalone-well-formed", svg.tag == "{http://www.w3.org/2000/svg}svg")
    (output_owner / "actual-network.svg").write_text(svg_markup + "\n")

    old_edges = tsv(old["pages/downloads/edges.tsv"])
    new_edges = tsv((root / "pages/downloads/edges.tsv").read_bytes())
    for identifier, edge in old_edges.items():
        check("kgx/old-edge/" + identifier, new_edges.get(identifier) == edge)
    added_edges = {k: v for k, v in new_edges.items() if k not in old_edges}
    check("kgx/exact-97-edge-additions", len(added_edges) == 97)
    check(
        "kgx/new-edges-knowledge-source",
        all(e["primary_knowledge_source"] == "infores:pathwaymech" for e in added_edges.values()),
    )
    # Join independently on complete native endpoints and payload, not exporter-specific hashed IDs.
    for edge in record["mechanistic_edges"]:
        found = [
            r
            for r in added_edges.values()
            if r["subject"] == edge["subject"]
            and r["object"] == edge["object"]
            and json.loads(r["evidence"]) == edge["evidence"]
            and r["description"] == norm(edge.get("description", ""))
        ]
        check("kgx/new-edge-payload/" + edge["id"], len(found) == 1)
        if not found:
            continue
        row = found[0]
        predicate = {
            "has_input": "RO:0002233",
            "has_output": "RO:0002234",
            "part_of": "BFO:0000050",
            "has_part": "BFO:0000051",
            "located_in": "RO:0001025",
            "occurs_in": "BFO:0000066",
            "causally_upstream_of": "RO:0002411",
            "provides_input_for": "RO:0002413",
        }.get(edge["predicate"], "pathwaymech:" + edge["predicate"])
        check("kgx/predicate/" + edge["id"], row["predicate"] == predicate)
        check(
            "kgx/qualifiers/" + edge["id"],
            json.loads(row["endpoint_qualifiers"] or "[]") == edge.get("endpoint_qualifiers", []),
        )
        refs = {e["reference_id"] for e in edge["evidence"]}
        refs |= {
            e["reference_id"] for q in edge.get("endpoint_qualifiers", []) for e in q["evidence"]
        }
        check("kgx/citation-set/" + edge["id"], set(row["source_records"].split("|")) == refs)
        check(
            "kgx/reference-metadata/" + edge["id"],
            {r["id"]: r for r in json.loads(row["reference_metadata"])}
            == {r: record_refs[r] for r in refs},
        )
    old_nodes = tsv(old["pages/downloads/nodes.tsv"])
    new_nodes = tsv((root / "pages/downloads/nodes.tsv").read_bytes())
    expected_node_ids = {record["id"]} | {n["id"] for n in declarations}
    check("kgx/exact-node-union", set(new_nodes) == set(old_nodes) | expected_node_ids)
    for identifier, old_node in old_nodes.items():
        row = new_nodes.get(identifier)
        check("kgx/old-node-exists/" + identifier, row is not None)
        if row is None:
            continue
        if identifier not in expected_node_ids:
            check("kgx/untouched-node/" + identifier, row == old_node)
        else:
            current_contexts = json.loads(row["source_contexts"])
            original_contexts = json.loads(old_node["source_contexts"])
            check(
                "kgx/old-node-contexts/" + identifier,
                [c for c in current_contexts if c["record_id"] != record["id"]]
                == original_contexts,
            )
    for identifier in expected_node_ids:
        contexts = [
            c
            for c in json.loads(new_nodes[identifier]["source_contexts"])
            if c["record_id"] == record["id"]
        ]
        expected = (
            [{"record_id": record["id"], "collection": "pathway", "label": record["label"]}]
            if identifier == record["id"]
            else []
        )
        expected += [
            {"record_id": record["id"], "collection": field, **n}
            for field in ("taxa", "participants", "reactions")
            for n in record[field]
            if n["id"] == identifier
        ]
        check("kgx/new-record-context/" + identifier, contexts == expected)
        all_contexts = json.loads(new_nodes[identifier]["source_contexts"])
        directions = {c["direction"] for c in all_contexts if c.get("direction")}
        check(
            "kgx/direction-consistency/" + identifier,
            new_nodes[identifier]["direction"]
            == (next(iter(directions)) if len(directions) == 1 else ""),
        )
        categories = {c["category"] for c in all_contexts if c.get("category")}
        check(
            "kgx/source-category-completeness/" + identifier,
            set(filter(None, new_nodes[identifier]["source_category"].split("|"))) == categories,
        )
    old_index = json.loads(old["pages/pathway_index.json"])
    new_index = json.loads((root / "pages/pathway_index.json").read_bytes())
    check(
        "global/index-old-entries",
        [r for r in new_index["records"] if r["id"] != record["id"]] == old_index["records"],
    )
    check("global/index-new-count", len(new_index["records"]) == 269)
    browse = DOM((root / "pages/browse.html").read_text()).root
    old_browse = DOM(old["pages/browse.html"].decode()).root
    browsed = {
        n.attrs["href"]: n.text
        for n in browse.tagged("a")
        if n.attrs.get("href", "").startswith("records/")
    }
    previously_browsed = {
        n.attrs["href"]: n.text
        for n in old_browse.tagged("a")
        if n.attrs.get("href", "").startswith("records/")
    }
    check(
        "global/browse-old-entries", all(browsed.get(k) == v for k, v in previously_browsed.items())
    )
    check("global/browse-count", len(browsed) == 269)
    manifest = json.loads((root / "pages/downloads/manifest.json").read_bytes())
    check("global/download-record-count", manifest["pathway_records"] == 269)
    for filename in ("nodes.tsv", "edges.tsv"):
        raw = (root / "pages/downloads" / filename).read_bytes()
        check(
            "global/download-hash/" + filename, digest(raw) == manifest["files"][filename]["sha256"]
        )
        check(
            "global/download-rows/" + filename,
            len(raw.splitlines()) - 1 == manifest["files"][filename]["rows"],
        )
    result = {
        "scope": (
            "Independent maintained record and generated artifact integration; excludes "
            "self-authored adapter and retention acceptance and separate scientific "
            "source approval."
        ),
        "baseline_commit": baseline["baseline_commit"],
        "record_path": record_path,
        "record_sha256": digest(raw_record),
        "page_path": page_path,
        "page_sha256": digest(page.encode()),
        "selection_sha256": digest(selected_raw),
        "reference_metadata_changes": reference_metadata_changes,
        "additional_narrative_reference_ids": sorted(
            record_refs.keys() - {r["id"] for r in selected["references"]}
        ),
        "counts": {
            "old_records": 268,
            "old_record_pages": 268,
            "edges": len(graph_edges),
            "graph_nodes": len(graph_nodes),
            "qualified_nodes": len(qualified),
            "disconnected_graph_nodes": len(isolated),
            "kgx_added_edges": len(added_edges),
            "kgx_added_nodes": len(set(new_nodes) - set(old_nodes)),
        },
        "physical_inventory_method": (
            "Path.rglob, includes hidden and ignored paths; symlinks independently flagged."
        ),
        "physical_inventory": current,
        "checks": checks,
        "passed": all(c["passed"] for c in checks),
    }
    (output_owner / "artifact-audit-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "passed": result["passed"],
                "checks": len(checks),
                "counts": result["counts"],
                "failed_checks": [c for c in checks if not c["passed"]],
            },
            indent=2,
        )
    )
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--record", required=True)
    parser.add_argument("--selection", type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(run(args.root, args.record, args.selection))
