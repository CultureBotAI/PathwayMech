import collections
import hashlib
import json
import subprocess
from pathlib import Path

OWNER = Path(__file__).resolve().parent
WORK = Path('/private/tmp/pathwaymech-next-272-20261015')
REL = Path('research/pathway_additions/2026-10-15-next-272/authority-source-originals')
SOURCE = WORK / REL
ACCEPTED = Path('/private/tmp/pathwaymech-next-272-independent-authority-review')
CI = Path('/private/tmp/pathwaymech-next-272-ci')
CHECKS = []
COMMANDS = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def check(condition, name):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)


def run(args, cwd=WORK, input_data=None):
    process = subprocess.run(args, cwd=cwd, input=input_data, capture_output=True, check=False)
    receipt = {'argv': list(map(str, args)), 'cwd': str(cwd), 'exit_code': process.returncode, 'stdout_bytes': len(process.stdout), 'stdout_sha256': sha(process.stdout), 'stderr': process.stderr.decode(errors='replace')}
    if args[:2] != ['git', 'show']:
        receipt['stdout'] = process.stdout.decode(errors='replace')
    COMMANDS.append(receipt)
    return process


def save(name, data):
    (OWNER / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


accepted_manifest_raw = (ACCEPTED / 'artifact-manifest.json').read_bytes()
check(sha(accepted_manifest_raw) == '2be3465bf19b4e3b428ba224a4fee0d85c2ed2efdd59b66818f1b22b161b5cef', 'accepted authority review exact manifest')
accepted_manifest = {r['path']: r for r in json.loads(accepted_manifest_raw)['files']}
inventory_raw = (ACCEPTED / 'portable-retained-source-inventory.json').read_bytes()
check(sha(inventory_raw) == accepted_manifest['portable-retained-source-inventory.json']['sha256'], 'accepted inventory bound to frozen authority review')
inventory = json.loads(inventory_raw)['files']
physical = {p.relative_to(SOURCE).as_posix(): p for p in SOURCE.rglob('*') if p.is_file()}
check(not any(p.is_symlink() for p in SOURCE.rglob('*')), 'no evidence-owner symlinks')
check(len(inventory) == len(physical) == 207 and set(physical) == {r['path'] for r in inventory}, 'complete207 hidden ignored evidence-owner inventory unchanged')
for row in inventory:
    raw = physical[row['path']].read_bytes()
    if row['path'] != '.gitattributes':
        check(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'unchanged accepted owner:' + row['path'])
    staged = run(['git', 'show', ':' + (REL / row['path']).as_posix()])
    check(staged.returncode == 0 and staged.stdout == raw, 'staged exact evidence bytes:' + row['path'])

old_attributes = b'cache/**/* -text\nacquisition/*.json -text\n'
check(sha(old_attributes) == next(r for r in inventory if r['path'] == '.gitattributes')['sha256'], 'accepted previous attributes exactly reconstructed')
attributes = (SOURCE / '.gitattributes').read_bytes()
expected_attributes = b'cache/**/* -text\n# Preserve original issuer XML end-of-line spaces without normalizing evidence.\n/cache/ethanolamine272/*.xml whitespace=-blank-at-eol\nacquisition/*.json -text\n'
check(attributes == expected_attributes, 'only narrow source XML whitespace rule and explanatory comment added')
bindings = json.loads((SOURCE / 'source-bindings.json').read_bytes())
manifest = json.loads((SOURCE / 'new-source-manifest.json').read_bytes())
manifest_by_path = {r['path']: r for r in manifest}
check(len(bindings) == len(manifest_by_path) == 97, '97 unique retained source originals')
counts = collections.Counter()
source_rows = []
for row in bindings:
    relative = 'cache/' + row['cache_path']
    raw = (SOURCE / relative).read_bytes()
    entry = manifest_by_path[row['cache_path']]
    check(len(raw) == row['bytes'] and sha(raw) == row['sha256'] == entry['sha256'], 'original binding manifest exact:' + row['id'])
    kind = 'native_xml' if row['id'].startswith(('MetaCyc:', 'EcoCyc:')) else 'uniprot_json'
    counts[kind] += 1
    check((kind == 'native_xml') == relative.endswith('.xml'), 'native/UniProt file type:' + row['id'])
    source_rows.append({'id': row['id'], 'path': relative, 'bytes': len(raw), 'sha256': sha(raw), 'kind': kind, 'staged_exact': True})
check(counts == {'native_xml': 63, 'uniprot_json': 34}, '63 native plus34 UniProt originals preserved')

queries = [(REL / row['path']).as_posix() for row in source_rows]
controls = [
    (REL / 'cache/ethanolamine272/nested/control.xml').as_posix(),
    (REL / 'cache/other/control.xml').as_posix(),
    (REL / 'acquisition/control.xml').as_posix(),
    (REL / 'reproduce.py').as_posix(),
    (REL / 'README.md').as_posix(),
    (REL / 'control.xml').as_posix(),
    'research/pathway_additions/2026-10-15-next-272/control.xml',
    'src/pathwaymech/identifiers.py',
    'data/pathways/ethanolamine-utilization.yaml',
]
queries += controls
effective = {}
for cached in (False, True):
    args = ['git', 'check-attr'] + (['--cached'] if cached else []) + ['-z', '--stdin', 'text', 'whitespace']
    response = run(args, input_data=('\0'.join(queries) + '\0').encode())
    check(response.returncode == 0, 'effective attribute query succeeds:' + str(cached))
    values = response.stdout.decode().split('\0')[:-1]
    rows = {(values[i], values[i + 1]): values[i + 2] for i in range(0, len(values), 3)}
    for source in source_rows:
        path = (REL / source['path']).as_posix()
        check(rows[(path, 'text')] == 'unset', 'original retains text-unset:' + path + ':' + str(cached))
        expected = '-blank-at-eol' if source['kind'] == 'native_xml' else 'unspecified'
        check(rows[(path, 'whitespace')] == expected, 'narrow original whitespace attribute:' + path + ':' + str(cached))
    for path in controls:
        check(rows[(path, 'whitespace')] == 'unspecified', 'outside/deeper control unaffected:' + path + ':' + str(cached))
    effective['cached' if cached else 'working_tree'] = [{'path': path, 'text': rows[(path, 'text')], 'whitespace': rows[(path, 'whitespace')]} for path in queries]

initial_raw = (CI / 'initial-stage-check.json').read_bytes()
initial = json.loads(initial_raw)
failure = next(row for row in initial if row['args'] == ['git', 'diff', '--cached', '--check'])
lines = [line for line in failure['stdout'].splitlines() if line.endswith(': trailing whitespace.')]
file_paths = {line.rsplit(':', 2)[0] for line in lines}
check(failure['exit_code'] == 2 and len(lines) == 116 and len(file_paths) == 39, 'initial exact116 diagnostics39 files')
check(file_paths <= {(REL / r['path']).as_posix() for r in source_rows if r['kind'] == 'native_xml'}, 'initial diagnostics confined to original XML')
successor_raw = (CI / 'source-xml-whitespace-successor.json').read_bytes()
successor = json.loads(successor_raw)
check(successor[-1]['args'] == ['git', 'diff', '--cached', '--check'] and successor[-1]['exit_code'] == 0 and not successor[-1]['stdout'] and not successor[-1]['stderr'], 'retained actual successor terminal0')
current_check = run(['git', 'diff', '--cached', '--check'])
check(current_check.returncode == 0 and not current_check.stdout and not current_check.stderr, 'independent full cached check passes')

# Exercise Git's whitespace engine with the actual queried rule. This uses only
# command-line config and scratch files, never index/worktree mutations.
probe_attr = OWNER / 'effective-rule-probe.attributes'
probe_attr.write_text('*.xml whitespace=-blank-at-eol\n')
cases = {
    'issuer_trailing_spaces_allowed.xml': (b'<x>original</x>\n', b'<x>original</x>  \n', False, None),
    'space_before_tab_rejected.xml': (b'<x>original</x>\n', b' \t<x>original</x>\n', True, 'space before tab'),
    'new_blank_eof_rejected.xml': (b'<x>original</x>\n', b'<x>original</x>\n\n', True, 'new blank line at EOF'),
    'conflict_marker_rejected.xml': (b'<x>original</x>\n', b'<<<<<<< HEAD\n<x>original</x>\n=======\n<x>other</x>\n>>>>>>> branch\n', True, 'leftover conflict marker'),
    'ordinary_product_trailing_rejected.py': (b'clean\n', b'trailing \n', True, 'trailing whitespace'),
}
probe_results = []
for filename, (before, after, expect_error, expected_text) in cases.items():
    a, b = OWNER / 'engine-controls/before' / filename, OWNER / 'engine-controls/after' / filename
    a.parent.mkdir(parents=True, exist_ok=True)
    b.parent.mkdir(parents=True, exist_ok=True)
    a.write_bytes(before)
    b.write_bytes(after)
    args = ['git', '-c', 'core.attributesFile=' + str(probe_attr), 'diff', '--no-index', '--check', '--', str(a), str(b)]
    response = run(args, cwd=OWNER)
    check(response.returncode == (3 if expect_error else 1), 'Git engine expected result:' + filename)
    if expected_text:
        check(expected_text in response.stdout.decode(), 'Git engine diagnostic retained:' + filename)
    else:
        check(not response.stdout and not response.stderr, 'only permitted EOL whitespace ignored')
    probe_results.append({'case': filename, 'exit_code': response.returncode, 'stdout': response.stdout.decode(), 'stderr': response.stderr.decode(), 'meaning': 'no-index1 means differences without check error;3 means differences plus check error'})

reproduction = []
for name, target in [('sources.json', 'data/identifier_authorities/sources.json'), ('ontology.json', 'data/identifier_authorities/ontology.json'), ('identifier_sources.json', 'conf/identifier_sources.json')]:
    generated = (OWNER / 'reproduction' / name).read_bytes()
    maintained = (WORK / target).read_bytes()
    staged = run(['git', 'show', ':' + target])
    check(generated == maintained == staged.stdout and staged.returncode == 0, 'reproduced maintained staged snapshots exact:' + target)
    reproduction.append({'name': name, 'target': target, 'bytes': len(generated), 'sha256': sha(generated), 'staged_and_worktree_exact': True})

(OWNER / 'reviewed-current.gitattributes').write_bytes(attributes)
(OWNER / 'reviewed-previous.gitattributes').write_bytes(old_attributes)
(OWNER / 'accepted-inventory.json').write_bytes(inventory_raw)
(OWNER / 'initial-stage-check.json').write_bytes(initial_raw)
(OWNER / 'source-xml-whitespace-successor.json').write_bytes(successor_raw)
(OWNER / 'source-xml-whitespace-issue.md').write_bytes((CI / 'source-xml-whitespace-issue.md').read_bytes())
save('source-originals-verification.json', source_rows)
save('effective-attributes.json', effective)
save('whitespace-engine-controls.json', probe_results)
save('snapshot-reproduction.json', reproduction)
save('command-receipts.json', COMMANDS)
save('verification-result.json', {'checks_passed': len(CHECKS), 'checks': CHECKS, 'decision': 'accept narrow source XML packaging successor only', 'issue': 637, 'originals': dict(counts), 'source_owner_physical_files': len(physical), 'prior_owner_only_changed_file': '.gitattributes', 'attributes_sha256': sha(attributes), 'reproduction': reproduction, 'scope_limits': 'No independent full scientific or authority acceptance; core.whitespace controls were not globally disabled; command-line scratch probe uses observed per-path setting.'})
print(json.dumps({'checks_passed': len(CHECKS), 'originals': dict(counts), 'source_owner_physical_files': len(physical), 'reproduction_exact': 3, 'decision': 'accept packaging successor only'}))
