"""Retain exact public API response bodies without modifying the adapter."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys
import urllib.error
import urllib.request

root = Path(__file__).resolve().parent
items = json.loads(Path(sys.argv[1]).read_text())
failed = False
for name, url in items:
    receipt_path = root / (name + '.receipt.json')
    assert not receipt_path.exists(), name
    started = datetime.now(timezone.utc).isoformat()
    request = urllib.request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'kg-microbe-sources/1'})
    error = None
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = response.read()
            status = response.status
            headers = dict(response.headers)
            final_url = response.url
    except urllib.error.HTTPError as exc:
        body = exc.read()
        status = exc.code
        headers = dict(exc.headers)
        final_url = exc.url
        error = str(exc)
    except urllib.error.URLError as exc:
        body = b''
        status = None
        headers = {}
        final_url = url
        error = str(exc)
    parsed = None
    try:
        parsed = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        pass
    (root / (name + '.body.json')).write_bytes(body)
    result = {'url': url, 'final_url': final_url, 'started_utc': started,
              'finished_utc': datetime.now(timezone.utc).isoformat(),
              'http_status': status, 'headers': headers, 'error': error,
              'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(),
              'parsed_json': parsed is not None, 'scope': 'Exact HTTP response body, kept without repair or normalization.'}
    receipt_path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'name': name, 'status': status, 'bytes': len(body), 'parsed_json': parsed is not None}), flush=True)
    failed = failed or status != 200 or parsed is None
raise SystemExit(1 if failed else 0)
