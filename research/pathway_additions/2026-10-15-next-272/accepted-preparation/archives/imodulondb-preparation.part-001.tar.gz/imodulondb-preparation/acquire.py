"""Bounded public iModulonDB cross-check with the existing installed runner."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

OWNER = Path(__file__).resolve().parent
CLAW = Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/culturebotai-claw')
RUNNER = CLAW / '.venv/bin/kg-microbe-sources'
ENV = os.environ.copy()
ENV.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')

def run(item):
    name, args = item
    receipt_path = OWNER / (name + '.receipt.json')
    assert not receipt_path.exists(), name
    command = [str(RUNNER), 'imodulondb', '--timeout', '30', *args]
    started = datetime.now(timezone.utc).isoformat()
    p = subprocess.run(command, cwd=OWNER, env=ENV, capture_output=True, timeout=120)
    (OWNER / (name + '.stdout')).write_bytes(p.stdout)
    (OWNER / (name + '.stderr')).write_bytes(p.stderr)
    receipt = {'command': command, 'cwd': str(OWNER), 'started_utc': started,
               'finished_utc': datetime.now(timezone.utc).isoformat(),
               'exit_code': p.returncode,
               'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
               'stderr_sha256': hashlib.sha256(p.stderr).hexdigest(),
               'representation': 'Exact installed-adapter stdout/stderr; rendered projection, not raw HTTP body.',
               'scope': 'Computational expression-module context only, not direct mechanism or taxon evidence.'}
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'name': name, 'exit_code': p.returncode, 'stdout_bytes': len(p.stdout)}), flush=True)
    return p.returncode

if __name__ == '__main__':
    items = json.loads(Path(sys.argv[1]).read_text())
    with ThreadPoolExecutor(max_workers=3) as pool:
        codes = list(pool.map(run, items))
    raise SystemExit(0 if all(code == 0 for code in codes) else 1)
