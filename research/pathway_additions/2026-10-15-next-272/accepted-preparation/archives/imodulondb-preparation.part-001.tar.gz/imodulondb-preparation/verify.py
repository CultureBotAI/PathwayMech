"""Verify the finite acquired source packet and write its derived assessment."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
command_items = []
for name in ['initial-commands.json', 'search-commands.json', 'summary-commands.json']:
    command_items.extend(json.loads((root / name).read_text()))
assert len(command_items) == 15
command_results = []
for name, args in command_items:
    receipt = json.loads((root / (name + '.receipt.json')).read_text())
    assert receipt['command'][4:] == args
    assert digest(root / (name + '.stdout')) == receipt['stdout_sha256']
    assert digest(root / (name + '.stderr')) == receipt['stderr_sha256']
    expected = 2 if name == 'e_coli-modulome-ethanolamine' else 0
    assert receipt['exit_code'] == expected
    if expected:
        assert (root / (name + '.stderr')).read_text().strip() == 'imodulons[0].regulator must be a JSON list, got NoneType'
    command_results.append({'name': name, 'exit_code': receipt['exit_code']})
raw_items = []
for name in ['raw-fallback-commands.json', 'raw-context-commands.json']:
    raw_items.extend(json.loads((root / name).read_text()))
assert len(raw_items) == 3
for name, url in raw_items:
    receipt = json.loads((root / (name + '.receipt.json')).read_text())
    body = root / (name + '.body.json')
    assert receipt['url'] == url and receipt['http_status'] == 200 and receipt['parsed_json']
    assert digest(body) == receipt['sha256'] and body.stat().st_size == receipt['bytes']
    json.loads(body.read_text())
for row in json.loads((root / 'runner-source-binding.json').read_text())['files']:
    assert digest(root / row['copied_path']) == row['sha256']
    assert digest(Path(row['source_path'])) == row['sha256']

datasets = json.loads((root / 'raw-datasets.body.json').read_text())
keys = [row['id'] + '/' + dataset for row in datasets for dataset in row['datasets']]
assert len(datasets) == 20 and len(keys) == len(set(keys)) == 28
matched = [key for key in keys if key.startswith(('e_coli/', 's_enterica/'))]
assert len(matched) == 6
for key in keys:
    assert '`' + key + '`' in (root / 'live-datasets.stdout').read_text()
search_results = []
for name, args in json.loads((root / 'search-commands.json').read_text()):
    organism = args[args.index('--organism') + 1]
    dataset = args[args.index('--dataset') + 1]
    query = args[args.index('--query') + 1]
    assert organism + '/' + dataset in matched
    if name == 'e_coli-modulome-ethanolamine':
        source = json.loads((root / 'raw-e_coli-modulome-ethanolamine.body.json').read_text())
        assert len(source['genes']) == 10 and len(source['imodulons']) == 1
        assert source['imodulons'][0]['k'] == 76
        assert source['imodulons'][0]['name'] == 'Fermentation'
        assert source['imodulons'][0]['regulator'] is None
        genes, modules = 10, 1
        representation = 'raw HTTP JSON after retained adapter parser failure'
    else:
        text = (root / (name + '.stdout')).read_text()
        genes = int(re.search(r'^- genes: (\d+)$', text, re.M).group(1))
        modules = int(re.search(r'^- iModulons: (\d+)$', text, re.M).group(1))
        assert genes == 10 and modules == 0
        representation = 'adapter-rendered stdout'
    search_results.append({'dataset': organism + '/' + dataset, 'query': query,
                           'returned_genes': genes, 'returned_components': modules,
                           'representation': representation})

component = json.loads((root / 'raw-e_coli-modulome-76-genes.body.json').read_text())
genes = component['genes']
assert len(genes) == len({row['gene_id'] for row in genes}) == 13
assert float(component['threshold']) == 0.105120952
summary = (root / 'e_coli-modulome-summary-76.stdout').read_text()
for row in genes:
    assert row['organism'] == 'e_coli' and row['dataset'] == 'modulome'
    assert row['in_imodulon'] is True and abs(row['weight']) >= float(component['threshold'])
    assert '`e_coli/modulome/' + row['gene_id'] + '`' in summary
    assert row['uniprot_id'] in summary and row['string_id'] in summary
assert {row['gene_name'] for row in genes if row['gene_name'].startswith('eut')} == {'eutJ', 'eutG', 'eutH', 'eutA'}
selected = [row for row in genes if row['gene_name'].startswith('eut') or row['gene_name'] == 'ackA']
assert len(selected) == 5
assessment = {
    'utc': datetime.now(timezone.utc).isoformat(), 'candidate': 'MetaCyc:PWY0-1477',
    'kind': 'bounded computational expression-module source preparation',
    'organism_entries': 20, 'dataset_keys': 28, 'matched_dataset_keys': matched,
    'command_results': command_results, 'search_results': search_results,
    'component_key': 'e_coli/modulome/76', 'threshold': component['threshold'],
    'returned_component_rows': 13, 'selected_context_rows': selected,
    'direct_mechanistic_edges_supported_by_this_packet': 0,
    'strain_experiment_scope_verified': False, 'global_or_dataset_exhaustion_proved': False,
    'source_annotations_are_not_primary_experimental_reading': True,
    'shared_adapter_repaired_or_modified': False,
    'mechanical_verification': 'All 18 acquisition receipts, exact source hashes, finite search counts and all 13 component rows verified.'}
(root / 'assessment.json').write_text(json.dumps(assessment, indent=2) + '\n')
print(json.dumps({'verified': True, 'cli_commands': 15, 'cli_successes': 14,
                  'retained_parser_failures': 1, 'raw_http_successes': 3,
                  'search_queries': 12, 'component_rows': 13}), flush=True)
