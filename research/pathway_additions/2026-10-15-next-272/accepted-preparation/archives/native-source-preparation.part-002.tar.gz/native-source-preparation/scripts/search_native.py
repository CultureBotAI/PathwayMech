from pathlib import Path
import urllib.request, json, hashlib, datetime

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
for term in ["eut", "ethanolamine"]:
    url = "https://bf2i-artsymbiocyc.insa-lyon.fr/META/keywordsearch?keyword=" + term
    row = {
        "url": url,
        "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    try:
        with urllib.request.urlopen(url, timeout=45) as h:
            raw = h.read()
            row.update(
                status=h.status,
                final_url=h.url,
                headers={
                    k: v for k, v in h.headers.items() if k.lower() != "set-cookie"
                },
            )
        p = R / "originals" / ("search-" + term + ".xml")
        p.write_bytes(raw)
        row.update(
            path=str(p.relative_to(R)),
            sha256=hashlib.sha256(raw).hexdigest(),
            bytes=len(raw),
        )
    except Exception as e:
        row["error"] = repr(e)
    row["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (R / "receipts" / ("search-" + term + ".json")).write_text(
        json.dumps(row, indent=2) + "\n"
    )
    print(term, row.get("status"), row.get("error"))
