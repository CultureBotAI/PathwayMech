"""Offline raw/source/semantic coverage verification; no acquisition or mutation."""

from pathlib import Path
import collections
import hashlib
import json
import xml.etree.ElementTree as ET

R = Path(__file__).resolve().parents[1]


def read(p):
    return json.loads((R / p).read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


n = read("results/all-native-projections.json") + read(
    "results/ecoli-native-projections.json"
)
nb = {x["attributes"]["orgid"] + ":" + x["id"]: x for x in n}
assert len(n) == len(nb) == 228
slots = []
for x in n:
    p = R / x["source_path"]
    assert sha(p) == x["sha256"] and p.stat().st_size == x["bytes"]
    root = ET.parse(p).getroot()
    ob = [c for c in root if c.tag != "metadata"]
    assert len(ob) == 1
    ob = ob[0]
    assert (
        ob.attrib == x["attributes"]
        and ob.tag == x["type"]
        and ob.get("detail") == "full"
    )
    assert root.findtext("metadata/query") == ob.get("orgid") + ":" + ob.get("frameid")
    assert (
        root.findtext("metadata/num_results") == "1"
        and root.find("metadata/PGDB").attrib == x["version"]
    )
    assert len(ob) == x["own_slot_count"] == len(x["slots"])
    for el, s in zip(ob, x["slots"]):
        assert ET.tostring(el, encoding="unicode") == s["xml"] and el.tag == s["slot"]
        slots.append(
            (
                ob.get("orgid") + ":" + x["id"],
                s["locator"],
                hashlib.sha256(s["xml"].encode()).hexdigest(),
            )
        )
assert len(slots) == 3689
sl = read("results/complete-native-slot-interpretations.json")
assert slots == [(x["id"], x["locator"], x["xml_sha256"]) for x in sl]
assert len(read("results/all-native-object-dispositions.json")) == 228
b = read("inputs/discovery/results/ethanolamine-boundary.json")
assert (
    b["root"]["own_slot_count"] == 21
    and len(b["root"]["members"]) == 5
    and len(b["root"]["ordering"]) == 4
)
assert b["root"]["sha256"] == nb["META:PWY0-1477"]["sha256"]
assert len(b["materials"]) == 14 and b["material_occurrences"] == 22
lead = {(z["frameid"], x["frameid"]) for x in b["reactions"] for z in x["activities"]}
a = read("results/all71-activity-dispositions.json")
assert len(a) == 71
assert {(x["activity"], x["reaction"]) for x in a} == lead
for x in a:
    act = nb["META:" + x["activity"]]
    enz = nb["META:" + x["enzyme"]]
    assert act["sha256"] == x["activity_sha256"] and enz["sha256"] == x["enzyme_sha256"]
    assert act["links"]["enzyme"][0]["frameid"] == enz["id"]
    assert act["links"]["reaction"][0]["frameid"] == x["reaction"]
assert len({x["enzyme"] for x in a}) == 68
u = read("results/uniprot-complete-projections.json")
assert len(u) == 34
comments = []
for x in u:
    p = R / x["source_path"]
    raw = json.loads(p.read_text())
    assert sha(p) == x["source_sha256"]
    assert (
        raw["primaryAccession"] == x["id"]
        and raw["entryAudit"] == x["audit"]
        and raw["organism"] == x["organism"]
    )
    assert raw["comments"] == x["comments"] and raw["sequence"] == x["sequence"]
    receipt = read("receipts/UniProt-" + x["id"] + ".json.json")
    assert receipt["status"] == 200 and receipt["validated"]
    assert (
        receipt["url"] == "https://rest.uniprot.org/uniprotkb/" + x["id"] + ".json"
        and receipt["sha256"] == x["source_sha256"]
    )
    comments.extend((x["id"], i, c) for i, c in enumerate(x["comments"]))
assert collections.Counter(x["organism"]["taxonId"] for x in u) == {
    83333: 17,
    99287: 17,
}
assert (
    len(comments) == 298
    and len(read("results/all34-protein-semantic-dispositions.json")) == 34
)
cl = read("results/all-uniprot-comment-dispositions.json")
assert {(x["id"][10:], x["locator"]): x["source_statement"] for x in cl} == {
    (a, "/comments/" + str(i)): c for a, i, c in comments
}
for fn in [
    "results/reused-input-bindings.json",
    "results/core-original-copy-bindings.json",
    "results/additional-input-bindings.json",
]:
    for x in read(fn):
        assert sha(R / x["copy"]) == x["sha256"]
covered = set()
receipts = []
for p in (R / "receipts").glob("*.json"):
    x = json.loads(p.read_text())
    assert x["status"] == 200
    q = R / x.get("path", "")
    if q.is_file() and x.get("sha256"):
        assert sha(q) == x["sha256"]
        covered.add(str(q.relative_to(R)))
    receipts.append(p.name)
for x in read("results/core-original-copy-bindings.json"):
    covered.add(x["copy"])
for x in read("results/reused-input-bindings.json"):
    if x["copy"].startswith("originals/"):
        covered.add(x["copy"])
originals = {str(p.relative_to(R)) for p in (R / "originals").iterdir() if p.is_file()}
assert originals <= covered, sorted(originals - covered)
assert len(read("results/source-conflicts.json")) == 19
go = read("originals/GO-microcompartment.json")
assert {x["id"] for x in go["results"]} == {"GO:0031471", "GO:0031469"}
assert all(x["isObsolete"] is False for x in go["results"])
for f, taxon in [
    ("uniprot-ecoli-eut.response", 83333),
    ("uniprot-lt2-eut.response", 99287),
]:
    search = read("originals/" + f)
    assert {x["primaryAccession"] for x in search["results"]} == {
        x["id"] for x in u if x["organism"]["taxonId"] == taxon
    }
recon = read("results/enzyme-count-reconciliation.json")
assert (
    recon["distinct_activity_linked_enzyme_count"] == 68
    and recon["original_acquisition_plan_count"] == 69
)
assert recon["extra_selected_component_objects"] == ["G7288-MONOMER"]
summary = {
    "status": "pass",
    "native_objects": len(n),
    "native_own_slots": len(slots),
    "complete_root_activities": len(a),
    "distinct_root_activity_enzymes": 68,
    "individual_uniprot": len(u),
    "uniprot_comment_statements": len(comments),
    "original_files_with_hash_bound_receipt_or_explicit_reuse": len(originals),
    "http_receipts": len(receipts),
    "conflict_groups": 19,
    "reused_core_http_gap": "ACETALD and Pi original HTTP receipts were not supplied; exact raw source envelope and older owner provenance retained. No fresh timestamp claimed.",
    "scope": "Raw/projection/coverage consistency; no independent scientific approval or exhaustive literature review.",
}
print(json.dumps(summary, indent=2))
