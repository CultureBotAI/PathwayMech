from pathlib import Path
import json, sys

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
rows = json.loads((R / "results/uniprot-complete-projections.json").read_text())
for x in sorted(rows, key=lambda x: (x["organism"]["taxonId"], x["gene"])):
    if (
        str(x["organism"]["taxonId"]) != sys.argv[1]
        or not sys.argv[2] <= x["gene"] <= sys.argv[3]
    ):
        continue
    print("\n" + x["id"] + " " + x["gene"] + " " + x["organism"]["scientificName"])
    for i, c in enumerate(x["comments"]):
        print(i, c["commentType"])

        def walk(v, k=""):
            if isinstance(v, dict):
                if "evidenceCode" in v:
                    return
                for a, b in v.items():
                    if a != "commentType":
                        walk(b, a)
            elif isinstance(v, list):
                for a in v:
                    walk(a, k)
            elif v is not None:
                print(" ", k, ":", v)

        walk(c)

        def ev(v):
            if isinstance(v, dict):
                if "evidenceCode" in v:
                    yield tuple(v.get(a) for a in ["evidenceCode", "source", "id"])
                for q in v.values():
                    yield from ev(q)
            elif isinstance(v, list):
                for q in v:
                    yield from ev(q)

        print(" EVIDENCE", sorted(set(ev(c)), key=str))
