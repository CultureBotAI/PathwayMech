from pathlib import Path
import urllib.request, json, hashlib, datetime

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
url = "https://www.ebi.ac.uk/QuickGO/services/ontology/go/terms/GO%3A0031469%2CGO%3A0031471"
row = {
    "url": url,
    "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
try:
    with urllib.request.urlopen(
        urllib.request.Request(url, headers={"Accept": "application/json"}), timeout=60
    ) as h:
        raw = h.read()
        row.update(
            status=h.status,
            final_url=h.url,
            headers={k: v for k, v in h.headers.items() if k.lower() != "set-cookie"},
        )
    p = R / "originals/GO-microcompartment.json"
    p.write_bytes(raw)
    row.update(
        path=str(p.relative_to(R)),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
    )
except Exception as e:
    row["error"] = repr(e)
row["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(R / "receipts/GO-microcompartment.json").write_text(json.dumps(row, indent=2) + "\n")
print(row.get("status"), row.get("error"))
