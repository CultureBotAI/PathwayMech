from pathlib import Path
import urllib.request, urllib.error, urllib.parse, json, hashlib, datetime, concurrent.futures, xml.etree.ElementTree as E

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")


def get(item):
    name, url, kind, identity = item
    row = {
        "name": name,
        "url": url,
        "identity": identity,
        "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    p = R / "originals" / name
    try:
        assert not p.exists()
        with urllib.request.urlopen(url, timeout=60) as h:
            raw = h.read()
            row.update(
                status=h.status,
                final_url=h.url,
                headers={
                    k: v for k, v in h.headers.items() if k.lower() != "set-cookie"
                },
            )
        p.write_bytes(raw)
        row.update(
            path=str(p.relative_to(R)),
            bytes=len(raw),
            sha256=hashlib.sha256(raw).hexdigest(),
        )
        if kind == "uniprot":
            obj = json.loads(raw)
            assert obj["primaryAccession"] == identity
            row.update(
                validated=True,
                entry_version=obj["entryAudit"]["entryVersion"],
                taxon=obj["organism"]["taxonId"],
            )
        else:
            root = E.fromstring(raw)
            obj = [x for x in root if x.tag != "metadata"]
            assert len(obj) == 1
            obj = obj[0]
            assert (
                obj.get("orgid") == "ECOLI"
                and obj.get("frameid") == identity
                and obj.get("detail") == "full"
            )
            row.update(
                validated=True,
                type=obj.tag,
                own_slots=len(obj),
                pgdb=root.find("./metadata/PGDB").attrib,
            )
    except Exception as e:
        row["error"] = repr(e)
        if isinstance(e, urllib.error.HTTPError):
            raw = e.read()
            p = R / "originals" / (name + ".failure")
            p.write_bytes(raw)
            row.update(
                failure_path=str(p.relative_to(R)),
                failure_sha256=hashlib.sha256(raw).hexdigest(),
                status=e.code,
            )
    row["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (R / "receipts" / (name + ".json")).write_text(json.dumps(row, indent=2) + "\n")
    return {k: row.get(k) for k in ["name", "status", "validated", "error"]}


if __name__ == "__main__":
    ids = set()
    u = []
    for file in ["uniprot-ecoli-eut", "uniprot-lt2-eut"]:
        for x in json.loads((R / "originals" / (file + ".response")).read_text())[
            "results"
        ]:
            a = x["primaryAccession"]
            u.append(
                (
                    "UniProt-" + a + ".json",
                    "https://rest.uniprot.org/uniprotkb/" + a + ".json",
                    "uniprot",
                    a,
                )
            )
            if file == "uniprot-ecoli-eut":
                ids.update(
                    y["id"].split(":")[1]
                    for y in x.get("uniProtKBCrossReferences", [])
                    if y["database"] == "BioCyc" and y["id"].startswith("EcoCyc:")
                )
    for c in (
        E.parse(R / "originals/ecoli-eut-search.response")
        .getroot()
        .findall("./body/protein")
    ):
        if "eut" in (c.findtext("context") or "").lower():
            ids.add(urllib.parse.parse_qs(c.findtext("namespace_id"))["object"][0])
    u.extend(
        (
            "ECOLI-" + a + ".xml",
            "https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?ECOLI:" + a,
            "ecoli",
            a,
        )
        for a in sorted(ids)
    )
    (R / "results/ecoli-uniprot-acquisition-plan.json").write_text(
        json.dumps(u, indent=2) + "\n"
    )
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for row in pool.map(get, u):
            print(json.dumps(row), flush=True)
