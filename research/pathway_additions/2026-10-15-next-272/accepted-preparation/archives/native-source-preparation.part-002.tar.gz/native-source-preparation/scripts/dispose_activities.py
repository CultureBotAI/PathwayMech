from pathlib import Path
import json, xml.etree.ElementTree as E, collections

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
rows = json.loads((R / "results/all-native-projections.json").read_text())
by = {x["id"]: x for x in rows}
plan = json.loads((R / "results/initial-acquisition-plan.json").read_text())
boundary = json.loads(
    (R / "inputs/discovery/results/ethanolamine-boundary.json").read_text()
)
reaction_for = {
    a["frameid"]: x["frameid"] for x in boundary["reactions"] for a in x["activities"]
}
selected = {
    "ETHAMLY-ENZRXN": "Select the E. coli EutBC activity as native ethanolamine cleavage. Full source mixes NCIB 8114 non-K12 purification, mutant assays and recombinant/N-terminal-truncated constructs. Preserve each evidence tier, AdoCbl requirement, inhibitors and alpha6/beta6 composition; do not assign independent whole catalysis to EutB or EutC.",
    "ENZRXN0-7425": "Select E. coli dimeric EutD activity. The source records reversible catalysis, slower acetyl-phosphate formation but similar efficiencies, and pyruvate activation. Distinguish this 2010 E. coli assay from the 2004 LT2 reverse-direction EutD assay and conditional genetic phenotypes.",
    "ENZRXN0-8531": "Select E. coli EutE as an authoritative activity assertion with unpurified heterologous yeast evidence (PMID24269999/26384570), not purified native-cell catalysis or proof of an E. coli lumen location.",
    "ENZRXN-26158": "Select LT2 EutG as a native activity assertion supported by mutant phenotype (EV-EXP-IMP-REACTION-BLOCKED), not a purified biochemical assay. Preserve conditional pH/carbon-source aldehyde-release effects and the proposed NAD recycling explanation.",
    "ENZRXN-26159": "Select LT2 EutE as a native activity assertion with mutant phenotype and sequence-similarity support. Carbon-source failure with nitrogen-source utilization is not proof of purified enzyme kinetics. Do not transfer E. coli heterologous assays to this protein.",
    "ENZRXN-26156": "Select LT2 EutQ acetate kinase. Preserve heterologous poly-His recombinant preparation and direction-specific assays, coupled EutD result, and anaerobic ethanolamine+tetrathionate conditional growth defect. Its native location is explicitly unknown, with metabolosome placement suggested only.",
    "ENZRXN-26157": "Select LT2 EutP acetate kinase. Preserve heterologous poly-His recombinant preparation and direction-specific assays. EutP shares biochemical activity with EutQ but has no observed phenotype under the cited anaerobic ethanolamine+tetrathionate conditions; location is explicitly unknown.",
}
context = {
    "ACETATEKINA-MONOMER": "General E. coli AckA acetate/propionate kinase; source physiology concerns acetate/ATP, threonine, xylose and global acetyl-phosphate signalling. No inspected direct ethanolamine assignment. Keep as possible shared-system context, not a replacement for EutP/Q.",
    "PHOSACETYLTRANS-CPLX": "General E. coli Pta complex, distinct from EutD. Characterized Pta kinetics/activation do not make it the metabolosome enzyme. Genetic bypass or compensation must remain conditional and protein-specific.",
    "ADHE-CPLX": "General E. coli bifunctional AdhE complex with acetaldehyde/alcohol activities; activity comments explicitly mix E. coli B preparations. Do not replace EutE/G or move this protein into the metabolosome.",
    "CPLX0-8015": "E. coli AdhP ethanol/acetaldehyde enzyme, ethanol-induced and studied in engineered alcohol production; no direct ethanolamine route assignment in the inspected source.",
    "MHPF-MONOMER": "E. coli MhpF aromatic-degradation acetaldehyde dehydrogenase and engineered yeast/butanol context; shared chemistry and rescue constructs do not establish native EutE identity.",
    "GARTRANSFORMYL2-MONOMER": "E. coli PurT GAR transformylase has an ATP-consuming acetate-kinase side activity. Purine-synthesis mechanism and incidental side reaction do not establish ethanolamine ATP production.",
    "STM2047-MONOMER": "LT2 PduL is the distinct propanediol microcompartment phosphotransacylase. Its side Pta activity/rescue does not identify it as EutD or add the propanediol pathway to the five-member ethanolamine route.",
}
other = {
    "AADCLOS-MONOMER": "C. acetobutylicum solventogenic AdhE/Aad; primary physiological assignment is butanol synthesis, with shared ethanol/aldehyde reactions.",
    "ACEKINPROP-MONOMER": "A. propionicum propionate-fermentation oxidative branch; genetics and subunit structure unknown.",
    "ACKCLTH-MONOMER": "M. thermoacetica CO2-to-acetate synthesis, not ethanolamine-specific evidence.",
    "CPLX-101": "C. acetobutylicum acidogenic acetate/ATP production; strain-specific purified enzyme and divalent-ion behavior.",
    "CPLX-1303": "M. thermoacetica CO2-to-acetate synthesis Pta.",
    "CPLX-1869": "Thermotoga glucose fermentation Pta; a shared acetate/ATP module is not this pathway.",
    "CPLX-1870": "Thermotoga glucose fermentation acetate kinase.",
    "CPLX-441": "Methanosarcina acetate activation during methanogenesis, with opposite selected physiological direction.",
    "CPLX-5381": "Soybean embryo alcohol dehydrogenase with multiple isoelectric isoforms and broad aliphatic-alcohol substrates; plant context.",
    "CPLX-8344": "Zymomonas fermentative alcohol dehydrogenase II; iron/cobalt and oxygen effects belong to that enzyme.",
    "CPLX-8687": "Yeast ADH1 principal fermentative alcohol dehydrogenase; no ethanolamine-catabolic assignment.",
    "CPLX-8688": "Yeast ADH2 ethanol oxidation, glucose repression and efficient ethanol utilization; not this route.",
    "CPLX-8689": "Yeast mitochondrial ADH3, proposed NADH shuttling; not an Eut microcompartment protein.",
    "CPLX-8690": "Yeast mitochondrial ADH4 alcohol activity; physiology and chain specificity remain yeast-specific.",
    "CPLX-8693": "Yeast ADH5 function remains incompletely resolved; broad alcohol reaction backlink does not define ethanolamine utilization.",
    "CPLX-8956": "Corynebacterium mycothiol/formaldehyde detoxification protein has a mycothiol-independent alcohol side activity; not EutG.",
    "CPLX66-101": "Human hepatic/tissue alcohol dehydrogenases; nonmicrobial and unrelated pathway context.",
    "GIO2-1257-MONOMER": "Chlamydomonas putative chloroplast ACK1. Source explicitly does not link the protein sequence to observed acetate-kinase activity.",
    "GIO2-535-MONOMER": "Chlamydomonas bifunctional Adh1 in anaerobic ethanol production; not EutE/G.",
    "GIO2-991-MONOMER": "Chlamydomonas putative chloroplast PAT2; native source explicitly lacks direct activity for the sequence.",
    "MONOMER-11088": "Tobacco UDP-glucose/alcohol dehydrogenase dual activity from xylogenic cultures; not a microbial Eut enzyme.",
    "MONOMER-11388": "Pseudomonas TodI toluene-degradation component; predicted homology/expression evidence, unknown subunit composition.",
    "MONOMER-12291": "Fusobacterium Pta activity in cell extracts with sequence assignment predicted from genome; genus-level root narrative does not prove this full route.",
    "MONOMER-12780": "Pseudomonas DmpF aromatic meta-cleavage aldolase/dehydrogenase partner with proposed channeling; not EutE.",
    "MONOMER-13062": "Fructilactobacillus heterolactic fermentation Pta; electron-acceptor-dependent acetate versus ethanol routing.",
    "MONOMER-13097": "Streptococcus sorbitol/mannitol-induced, unpurified NAD-dependent alcohol activity.",
    "MONOMER-13133": "Gottschalkia purine-fermentation acetate kinase, partially purified; not Eut-associated.",
    "MONOMER-13134": "Gottschalkia Pta measured in cell extracts; not Eut-associated.",
    "MONOMER-13296": "Syntrophotalea crude-extract Pta measured after acetylene/acetoin growth.",
    "MONOMER-13297": "Syntrophotalea crude-extract acetate kinase measured after acetylene/acetoin growth.",
    "MONOMER-13298": "Syntrophotalea crude-extract alcohol dehydrogenase measured after acetylene/acetoin growth.",
    "MONOMER-13299": "Syntrophotalea crude-extract aldehyde dehydrogenase measured after acetylene/acetoin growth.",
    "MONOMER-13304": "Dasytricha whole-cell/hydrogenosome-fraction acetate kinase; does not establish bacterial compartment localization.",
    "MONOMER-13305": "Dasytricha soluble/insoluble-fraction Pta; not ethanolamine-specific.",
    "MONOMER-13471": "Clostridium kluyveri Pta; no inspected Eut-specific assignment.",
    "MONOMER-13473": "Clostridium kluyveri AckA; no inspected Eut-specific assignment.",
    "MONOMER-15098": "Maize ADH1 from anaerobically treated roots; plant stress response.",
    "MONOMER-15099": "Potato ADH1 induced by stress/anaerobiosis and heterologously characterized; plant context.",
    "MONOMER-15105": "Pea alcohol dehydrogenase, anaerobic promoter/reporter response; plant context.",
    "MONOMER-15908": "Roseovarius Pta induced during sulfolactate/sulfoacetaldehyde degradation.",
    "MONOMER-17184": "Cupriavidus FurX furfural reduction coupled to ethanol-dependent NADH supply.",
    "MONOMER-17646": "Leuconostoc partially purified aldehyde activity copurifies with alcohol activity; NAD-dependent with aldehyde alternatives.",
    "MONOMER-20612": "Acetoanaerobium acetate kinase during Stickland amino-acid fermentation; unpurified activity.",
    "MONOMER-20853": "Bilophila isethionate/taurine-associated acetaldehyde dehydrogenase with pH-dependent His-tagged assay.",
    "MONOMER-21789": "Desulfovibrio reductive glycine/lactate metabolism acetate kinase; not Eut-associated.",
    "MONOMER-354": "Pseudomonas CmtH final p-cymene degradation reaction, not ethanolamine.",
    "MONOMER-3661": "Paracoccus Pta in a partially purified fraction; protein-size agreement does not establish Eut context.",
    "MONOMER-602": "Mycoplasmoides Pta in pyruvate metabolism.",
    "MONOMER-603": "Mycoplasmoides acetate kinase in pyruvate metabolism and proposed ATP supplementation.",
    "MONOMER-8": "Eubacterium gallate-degradation acetyl-CoA branch Pta.",
    "MONOMER-9": "Eubacterium gallate-degradation acetyl-CoA branch acetate kinase.",
    "PTACLOS-MONOMER": "Clostridium acidogenic Pta/Ack operon and solvent-stage activity decline; not EutD.",
    "PTAMSARC-MONOMER": "Methanosarcina Pta in acetate activation for methanogenesis; separate shared chemistry.",
    "PTAPROP-MONOMER": "Anaerotignum propionate-fermentation oxidative branch Pta.",
}
out = []
for fid in plan["activities"]:
    x = by[fid]
    assert x["type"] == "Enzymatic-Reaction"
    enz = x["links"]["enzyme"]
    assert len(enz) == 1
    p = by[enz[0]["frameid"]]
    assert p["type"] == "Protein"
    if fid in selected:
        status = "selected_native_eut_activity"
        reason = selected[fid]
    elif p["id"] in context:
        status = "shared_same_taxon_or_adjacent_context"
        reason = context[p["id"]]
    else:
        status = "not_selected_unrelated_biological_context"
        reason = other[p["id"]]
    ev = [
        {"locator": s["locator"], "xml": s["xml"]}
        for s in x["slots"]
        if s["slot"] == "evidence"
    ]
    out.append(
        {
            "activity": fid,
            "reaction": reaction_for[fid],
            "enzyme": p["id"],
            "disposition": status,
            "rationale": reason,
            "source_taxa": p["links"].get("species", []),
            "source_activity_direction": x["reaction-direction"],
            "activity_evidence": ev,
            "activity_pmids": x["pmids"],
            "activity_sha256": x["sha256"],
            "enzyme_sha256": p["sha256"],
            "all_activity_slots_retained": x["own_slot_count"],
            "all_enzyme_slots_retained": p["own_slot_count"],
            "cofactor_slots": [
                s
                for s in x["slots"]
                if s["slot"]
                in [
                    "cofactor",
                    "alternative-cofactor",
                    "cofactor-binding-comment",
                    "prosthetic-group",
                ]
            ],
            "alternative_or_kinetic_slots": [
                s
                for s in x["slots"]
                if s["slot"]
                in [
                    "alternative-substrate",
                    "km",
                    "kcat",
                    "vmax",
                    "specific-activity",
                    "ph-opt",
                    "temperature-opt",
                ]
            ],
            "regulation_links": x["links"].get("regulated-by", []),
            "enzyme_component_slots": [
                s for s in p["slots"] if s["slot"] == "component"
            ],
            "enzyme_location_slots": [s for s in p["slots"] if s["slot"] == "location"],
            "caveat": "Disposition is source-preparation advice, not maintained graph approval or independent review. Structured database evidence is not a quotation from the listed papers.",
        }
    )
assert len(out) == len({x["activity"] for x in out}) == 71
(R / "results/all71-activity-dispositions.json").write_text(
    json.dumps(out, indent=2, ensure_ascii=False) + "\n"
)
print(
    json.dumps(
        {
            "activities": len(out),
            "enzymes": len({x["enzyme"] for x in out}),
            "dispositions": dict(collections.Counter(x["disposition"] for x in out)),
        }
    )
)
