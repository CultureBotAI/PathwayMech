from pathlib import Path
import urllib.request, urllib.error, urllib.parse, json, hashlib, datetime, sys

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
queries = {
    "ecoli-eut-search": "https://bf2i-artsymbiocyc.insa-lyon.fr/ECOLI/keywordsearch?keyword=eut",
    "uniprot-ecoli-eut": "https://rest.uniprot.org/uniprotkb/search?"
    + urllib.parse.urlencode(
        {
            "query": "(organism_id:83333) AND (gene:eut*)",
            "format": "json",
            "size": "100",
        }
    ),
    "uniprot-lt2-eut": "https://rest.uniprot.org/uniprotkb/search?"
    + urllib.parse.urlencode(
        {
            "query": "(organism_id:99287) AND (gene:eut*)",
            "format": "json",
            "size": "100",
        }
    ),
}
for name in sys.argv[1:]:
    url = queries[name]
    row = {
        "name": name,
        "url": url,
        "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    try:
        with urllib.request.urlopen(url, timeout=60) as h:
            raw = h.read()
            row.update(
                status=h.status,
                final_url=h.url,
                headers={
                    k: v for k, v in h.headers.items() if k.lower() != "set-cookie"
                },
            )
        p = R / "originals" / (name + ".response")
        assert not p.exists()
        p.write_bytes(raw)
        row.update(
            path=str(p.relative_to(R)),
            sha256=hashlib.sha256(raw).hexdigest(),
            bytes=len(raw),
        )
    except Exception as e:
        row["error"] = repr(e)
        if isinstance(e, urllib.error.HTTPError):
            raw = e.read()
            p = R / "originals" / (name + ".failure")
            p.write_bytes(raw)
            row.update(
                failure_path=str(p.relative_to(R)),
                sha256=hashlib.sha256(raw).hexdigest(),
                bytes=len(raw),
                status=e.code,
            )
    row["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (R / "receipts" / (name + ".json")).write_text(json.dumps(row, indent=2) + "\n")
    print(name, row.get("status"), row.get("error"))
