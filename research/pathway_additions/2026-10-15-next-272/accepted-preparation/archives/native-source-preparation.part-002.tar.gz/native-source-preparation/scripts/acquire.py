from pathlib import Path
import urllib.request, urllib.error, json, hashlib, datetime, sys, concurrent.futures, xml.etree.ElementTree as E

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")


def acquire(fid):
    url = "https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:" + fid
    path = R / "originals" / ("META-" + fid + ".xml")
    if path.exists():
        return {"id": fid, "state": "already retained"}
    receipt = {
        "id": fid,
        "url": url,
        "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }
    try:
        with urllib.request.urlopen(url, timeout=55) as h:
            raw = h.read()
            receipt.update(
                status=h.status,
                final_url=h.url,
                headers={
                    k: v
                    for k, v in h.headers.items()
                    if k.lower() not in ["set-cookie", "cookie"]
                },
            )
        path.write_bytes(raw)
        receipt.update(
            path=str(path.relative_to(R)),
            bytes=len(raw),
            sha256=hashlib.sha256(raw).hexdigest(),
        )
        root = E.fromstring(raw)
        objs = [c for c in root if c.tag != "metadata"]
        assert len(objs) == 1
        o = objs[0]
        assert (
            o.get("frameid") == fid
            and o.get("orgid") == "META"
            and o.get("detail") == "full"
        )
        assert (
            root.findtext("./metadata/query") == "META:" + fid
            and root.findtext("./metadata/num_results") == "1"
        )
        receipt.update(
            validated=True,
            type=o.tag,
            own_slots=len(o),
            pgdb=root.find("./metadata/PGDB").attrib,
        )
    except Exception as e:
        receipt["error"] = repr(e)
        if isinstance(e, urllib.error.HTTPError):
            raw = e.read()
            failed = R / "originals" / ("META-" + fid + ".http-failure")
            failed.write_bytes(raw)
            receipt.update(
                failure_path=str(failed.relative_to(R)),
                failure_sha256=hashlib.sha256(raw).hexdigest(),
                status=e.code,
            )
    receipt["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = (
        R
        / "receipts"
        / ("native-" + fid + "-" + receipt["started_at"].replace(":", "") + ".json")
    )
    p.write_text(json.dumps(receipt, indent=2) + "\n")
    return {
        k: receipt.get(k)
        for k in ["id", "status", "validated", "type", "own_slots", "error"]
    }


if __name__ == "__main__":
    if sys.argv[1] == "initial":
        p = json.loads((R / "results/initial-acquisition-plan.json").read_text())
        ids = p["activities"] + p["root_narrative_leads"]
    else:
        ids = sys.argv[1:]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(acquire, dict.fromkeys(ids)):
            print(json.dumps(result), flush=True)
