import json, sys, concurrent.futures
from acquire import acquire, R

ids = json.loads((R / "results" / sys.argv[1]).read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(acquire, dict.fromkeys(ids)):
        print(json.dumps(result), flush=True)
