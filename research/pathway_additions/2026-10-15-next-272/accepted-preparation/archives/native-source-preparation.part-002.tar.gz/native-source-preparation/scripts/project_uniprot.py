from pathlib import Path
import json, hashlib

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
rows = []
for p in sorted((R / "originals").glob("UniProt-*.json")):
    x = json.loads(p.read_text())
    a = x["primaryAccession"]
    rows.append(
        {
            "id": a,
            "gene": x["genes"][0]["geneName"]["value"],
            "organism": x["organism"],
            "audit": x["entryAudit"],
            "name": x["proteinDescription"],
            "comments": x.get("comments", []),
            "references": x.get("references", []),
            "crossrefs": x.get("uniProtKBCrossReferences", []),
            "sequence": x["sequence"],
            "source_path": str(p.relative_to(R)),
            "source_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            "entry_type": x.get("entryType"),
        }
    )
(R / "results/uniprot-complete-projections.json").write_text(
    json.dumps(rows, indent=2) + "\n"
)
print("Projected", len(rows), "individual UniProt originals")
