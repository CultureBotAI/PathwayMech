from pathlib import Path
import xml.etree.ElementTree as E, json, hashlib, collections, html, re
from html.parser import HTMLParser

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")


class TextOnly(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []

    def handle_data(self, data):
        self.parts.append(data)


def plain(t):
    p = TextOnly()
    p.feed(t)
    p.close()
    return re.sub(r"\s+", " ", " ".join(p.parts)).strip()


rows = []
for p in sorted((R / "originals").glob("ECOLI-*.xml")):
    root = E.parse(p).getroot()
    obs = [c for c in root if c.tag != "metadata"]
    assert len(obs) == 1
    o = obs[0]
    fid = o.get("frameid")
    assert fid == p.stem[6:] and o.get("detail") == "full"
    counts = collections.Counter()
    slots = []
    for c in o:
        counts[c.tag] += 1
        slots.append(
            {
                "slot": c.tag,
                "ordinal": counts[c.tag],
                "locator": f"/{root.tag}/{o.tag}[@frameid='{fid}']/{c.tag}[{counts[c.tag]}]",
                "xml": E.tostring(c, encoding="unicode"),
                "plain_text": plain(" ".join(c.itertext())),
                "direct_objects": [
                    {"type": e.tag, **e.attrib} for e in c if "frameid" in e.attrib
                ],
            }
        )
    row = {
        "id": fid,
        "type": o.tag,
        "attributes": o.attrib,
        "source_path": str(p.relative_to(R)),
        "bytes": len(p.read_bytes()),
        "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        "version": root.find("./metadata/PGDB").attrib,
        "own_slot_count": len(o),
        "slots": slots,
    }
    for name in [
        "common-name",
        "synonym",
        "comment",
        "reaction-direction",
        "physiologically-relevant?",
    ]:
        row[name] = [plain(" ".join(c.itertext())) for c in o.findall(name)]
    row["links"] = {
        s: [
            {
                "type": c.tag,
                **c.attrib,
                "name": c.findtext("common-name"),
                "species": [
                    {
                        "id": z.get("frameid"),
                        "name": z.findtext("common-name"),
                        "strain": z.findtext("strain-name"),
                    }
                    for z in c.findall("./species/Organism")
                ],
            }
            for x in o.findall(s)
            for c in x
            if "frameid" in c.attrib
        ]
        for s in counts
        if any("frameid" in c.attrib for x in o.findall(s) for c in x)
    }
    row["pmids"] = sorted(
        {c.text for c in o.findall(".//pubmed-id") if c.text}
        | set(re.findall(r"pubmed/(\d+)", E.tostring(o, encoding="unicode")))
    )
    rows.append(row)
(R / "results/ecoli-native-projections.json").write_text(
    json.dumps(rows, indent=2, ensure_ascii=False) + "\n"
)
summary = []
for r in rows:
    summary.append(
        {
            "id": r["id"],
            "type": r["type"],
            "names": r["common-name"] + r["synonym"],
            "comments": r["comment"],
            "links": r["links"],
            "pmids": r["pmids"],
            "own_slots": r["own_slot_count"],
        }
    )
(R / "results/ecoli-semantic-reading.json").write_text(
    json.dumps(summary, indent=2, ensure_ascii=False) + "\n"
)
print(
    json.dumps(
        {
            "objects": len(rows),
            "types": dict(collections.Counter(x["type"] for x in rows)),
            "own_slots": sum(x["own_slot_count"] for x in rows),
        }
    )
)
