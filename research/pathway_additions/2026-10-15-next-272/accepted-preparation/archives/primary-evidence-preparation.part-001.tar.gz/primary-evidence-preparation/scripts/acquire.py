from pathlib import Path
import urllib.request,urllib.error,json,hashlib,datetime,concurrent.futures,sys
owner=Path('/private/tmp/pathwaymech-next-272-primary-evidence-preparation')
tasks=json.loads(Path(sys.argv[1]).read_text())
def one(t):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); p=owner/'originals'/t['name']; result={'url':t['url'],'start_utc':start,'path':str(p.relative_to(owner)),'method':'GET','headers_requested':{'User-Agent':'PathwayMech scientific source preparation (public read-only)'}}
 try:
  with urllib.request.urlopen(urllib.request.Request(t['url'],headers=result['headers_requested']),timeout=45) as r:
   b=r.read();result.update(status=r.status,final_url=r.url,headers=dict(r.headers))
 except urllib.error.HTTPError as e:
  b=e.read();result.update(status=e.code,final_url=e.url,headers=dict(e.headers),error=str(e))
 except Exception as e:
  b=b'';result.update(error_type=type(e).__name__,error=str(e))
 p.write_bytes(b);result.update(bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),finish_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (owner/'receipts'/(t['name']+'.json')).write_text(json.dumps(result,indent=2)+'\n');return {k:result.get(k) for k in ['path','status','bytes','error']}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for r in ex.map(one,tasks):print(json.dumps(r),flush=True)
