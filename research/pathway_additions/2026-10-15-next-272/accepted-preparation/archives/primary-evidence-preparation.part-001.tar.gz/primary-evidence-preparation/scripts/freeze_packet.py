from pathlib import Path
import hashlib,json,datetime
p=Path(__file__).resolve().parents[1]
def sha(x):return hashlib.sha256(x.read_bytes()).hexdigest()
def files():
 fs=[]
 for q in p.rglob('*'):
  assert not q.is_symlink(),q
  if q.is_file():fs.append(q)
 return sorted(fs,key=lambda q:str(q.relative_to(p)))
assert not (p/'artifact-manifest.json').exists() and not (p/'freeze-proof.json').exists()
rows=[{'path':str(q.relative_to(p)),'bytes':q.stat().st_size,'sha256':sha(q)} for q in files()]
manifest={'format':'bounded-primary-preparation-manifest/1','owner':str(p),'files':rows,'file_count':len(rows),'listed_bytes':sum(x['bytes'] for x in rows),'inventory_scope':'Complete physical regular-file traversal, hidden/ignored included; no symlinks; nested containers opaque except declared targeted decoding','excluded_envelope_files':['artifact-manifest.json','freeze-proof.json']}
(p/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof={'format':'bounded-primary-preparation-freeze/1','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':str(p),'manifest_sha256':sha(p/'artifact-manifest.json'),'handoff_sha256':sha(p/'HANDOFF.md'),'result_sha256':sha(p/'RESULT.json'),'listed_files':len(rows),'listed_bytes':sum(x['bytes'] for x in rows),'physical_files_including_envelope':len(rows)+2,'physical_paths_including_envelope':sorted([x['path'] for x in rows]+['artifact-manifest.json','freeze-proof.json']),'all_jobs_terminal':True,'verification':'receipts/verify-attempt2.stdout.json','note':'No post-freeze writes. Scientific scope and inaccessible material remain limited by HANDOFF and source-reading-ledger.'}
(p/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert sorted(str(q.relative_to(p)) for q in files())==proof['physical_paths_including_envelope']
for r in rows:
 q=p/r['path'];assert q.stat().st_size==r['bytes'] and sha(q)==r['sha256']
assert sha(p/'artifact-manifest.json')==proof['manifest_sha256']
print(json.dumps({'owner':str(p),'manifest_sha256':sha(p/'artifact-manifest.json'),'HANDOFF_sha256':sha(p/'HANDOFF.md'),'freeze_sha256':sha(p/'freeze-proof.json'),'RESULT_sha256':sha(p/'RESULT.json'),'listed_files':len(rows),'physical_files':len(rows)+2,'listed_bytes':sum(x['bytes'] for x in rows),'all_fresh_rechecks_pass':True},indent=2))
