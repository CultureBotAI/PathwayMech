from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,re,sys
P=Path(__file__).resolve().parents[1]; checks=[]
def check(name,ok,detail=None):
 checks.append({'name':name,'pass':bool(ok),'detail':detail})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((P/'results/source-reading-ledger.json').read_text())['sources'];c=json.loads((P/'results/claim-ledger.json').read_text())['claims']
check('24 unique source entries',len(s)==24==len({x['key'] for x in s}))
check('32 unique claim dispositions',len(c)==32==len({x['id'] for x in c}))
for x in s:
 for f in x['artifacts']:
  p=P/f['path'];check('source binding '+x['key']+' '+f['path'],p.is_file() and p.stat().st_size==f['bytes'] and sha(p)==f['sha256'])
for x in c:check('claim source and scope '+x['id'],x['source'] in {z['key'] for z in s} and bool(x['locator']) and bool(x['qualification']) and x['verbatim_quote'] is False)
a=json.loads((P/'results/acquisition-audit.json').read_text())
for x in a['responses']:
 p=P/x['path']; r=json.loads((P/x['receipt']).read_text());check('HTTP exact bytes '+x['path'],sha(p)==x['sha256']==r['sha256'] and p.stat().st_size==x['bytes']==r['bytes'])
check('47 distinct direct acquisitions',len(a['responses'])==47==len({x['path'] for x in a['responses']}))
for n,b in [('PMC355984',False),('PMC3697265',False),('PMC3187147',False),('PMC3911174',False),('PMC9481676',True),('PMC4857615',True),('PMC4827028',True),('PMC3439341',True)]:
 r=E.fromstring((P/'originals'/(n+'-efetch.xml')).read_bytes());check('XML body classification '+n,(r.find('.//body') is not None)==b)
for n in ['2022-supplement-EuropePMC.zip','EutPQ-supplement-EuropePMC.zip']:
 b=(P/'originals'/n).read_bytes();check('HTTP200 SI is an error '+n,not b.startswith(b'PK') and b'not open access' in b.lower())
for n,source in [('2022','PMC9481676-efetch.xml'),('EutPQ','PMC4857615-efetch.xml'),('cargo2012','cargo-2012-primary.xml'),('EutE2011','PMC3187147-efetch.xml'),('EutT2014','PMC3911174-efetch.xml'),('EutQ2016','PMC4827028-efetch.xml'),('EutG2012','PMC3439341-efetch.xml')]:
 old=json.loads((P/'results'/(n+'-elements.json')).read_text());r=E.fromstring((P/'originals'/source).read_bytes()); tags={x['tag'] for x in old};key='element_ordinal' if 'element_ordinal' in old[0] else 'ordinal'
 now=[{key:i,'tag':e.tag,'id':e.get('id'),'text':' '.join(''.join(e.itertext()).split())} for i,e in enumerate(r.iter()) if e.tag in tags]
 check('exact XML text projection '+n,old==now,{'recorded_elements':len(old),'replayed_elements':len(now)})
coverage=json.loads((P/'results/2013-web-main-coverage-final.json').read_text());allns=set()
for f,expected in coverage['captured_line_sets'].items():
 ss=json.loads((P/f).read_text());got=set()
 for chunk in ss.split('--------------------------------------------------------------------------------'):
  if 'doi/full/10.1128/jb.02179-12' in chunk.lower() and 'Evidence that a Metabolic' in chunk:got|=set(map(int,re.findall(r'\bL(\d+):',chunk)))
 check('2013 retained line coverage '+f,got==set(expected));allns|=got
check('2013 complete main text line span82–571',set(range(82,572))<=allns)
for f in P.rglob('*'):
 check('physical nonsymlink '+str(f.relative_to(P)),not f.is_symlink())
result={'format':'bounded-primary-evidence-verification/1','checks':len(checks),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'details':checks,'limitations':'Mechanical binding/projection checks are not independent scientific review or literature completeness.'}
print(json.dumps(result,indent=2));sys.exit(bool(result['failed']))
