from pathlib import Path
import urllib.request,urllib.error,json,hashlib,datetime
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
for pmc in ['PMC3697265','PMC355984','PMC1447003','PMC1291257']:
 url=f'https://pmc.ncbi.nlm.nih.gov/articles/{pmc}/?report=xml'
 out=R/'originals'/(pmc+'.html');receipt={'url':url,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=45) as h:raw=h.read();receipt.update(status=h.status,final_url=h.url,headers=dict(h.headers))
  assert not out.exists();out.write_bytes(raw);receipt.update(path=str(out.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except urllib.error.HTTPError as e:
  raw=e.read();out=out.with_suffix('.failed.html');out.write_bytes(raw);receipt.update(error=repr(e),status=e.code,path=str(out.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except Exception as e:receipt['error']=repr(e)
 (R/'receipts'/(pmc+'.html.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(pmc,receipt.get('status'),receipt.get('bytes'),receipt.get('error'),flush=True)
