from pathlib import Path
import subprocess, json, hashlib, datetime, shutil
import yaml

R = Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
W = Path('/private/tmp/pathwaymech-next-271-20261015')
BASE = '63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'
def sha(b): return hashlib.sha256(b).hexdigest()
def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
def git(*args): return subprocess.check_output(['git', '-C', str(W), *args])
files = git('ls-tree','-r','--name-only', BASE,'data/pathways').decode().splitlines()
rows=[]
for p in files:
    if not p.endswith('.yaml'): continue
    b=git('show', BASE+':'+p)
    dest=R/'inputs/baseline'/p; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
    d=yaml.safe_load(b)
    rows.append({'path':p,'sha256':sha(b),'bytes':len(b),'id':d['id'],'label':d['label'],
                 'taxa':d.get('taxa',[]),'reactions':d.get('reactions',[]),'source_mappings':d.get('source_mappings',[])})
assert len(rows)==267
paths=['CLAUDE.md','.claude/skills/add-pathway/SKILL.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','conf/sources.yaml','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','templates/pathway_mechanism_research.md','research/cross_mech/2026-10-05-uniprot-protein-links.md']
bindings=[]
for p in paths:
    b=git('show',BASE+':'+p); dest=R/'inputs/baseline'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
    bindings.append({'path':p,'sha256':sha(b),'bytes':len(b),'matches_worktree':b==(W/p).read_bytes()})
pending='data/pathways/methanogenesis-from-acetate.yaml'
b=(W/pending).read_bytes(); dest=R/'inputs/pending271'/pending;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
save(R/'results/baseline.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':BASE,'tree':git('rev-parse',BASE+'^{tree}').decode().strip(),'count':len(rows),'records':rows,'governance_bindings':bindings,'pending271':{'path':pending,'sha256':sha(b),'bytes':len(b)},'warning':'Pending271 is not landed; rebind actual merge before any maintained curation.'})
for number in (270,271):
    owner=Path(f'/private/tmp/pathwaymech-next-{number}-discovery')
    for p in [owner/'HANDOFF.md',owner/'ASSESSMENT.md',owner/'results/candidate-comparison.json',owner/'artifact-manifest.json',owner/'freeze-proof.json']:
        if p.is_file():
            target=R/f'inputs/prior-next{number}'/p.relative_to(owner);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
patterns=['DISSULFRED-PWY','dissimilatory sulfate reduction','dissimilatory sulphate reduction','sulfate respiration','sulfate reduction IV','N2FIX-PWY','AMMOXID-PWY','PWY0-1477']
(R/'results/initial-search-patterns.txt').write_text('\n'.join(patterns)+'\n')
args=['rg','--no-ignore','--hidden','-l','-F','-i','-f',str(R/'results/initial-search-patterns.txt'),'-g','!.git','-g','!.venv','.']
run=subprocess.run(args,cwd=W,capture_output=True)
(R/'results/initial-rg.stdout').write_bytes(run.stdout);(R/'results/initial-rg.stderr').write_bytes(run.stderr)
matches=[]
for path in run.stdout.decode().splitlines():
    p=W/path;raw=p.read_bytes()
    text=raw.decode('utf-8',errors='replace')
    hits=[]
    for num,line in enumerate(text.splitlines(),1):
        pats=[pat for pat in patterns if pat.lower() in line.lower()]
        if pats: hits.append({'line':num,'patterns':pats,'text':line})
    matches.append({'path':path,'bytes':len(raw),'sha256':sha(raw),'hits':hits})
save(R/'results/initial-ordinary-text-search.json',{'argv':args,'cwd':str(W),'returncode':run.returncode,'scope':'Hidden and ignored ordinary text included. Root Git administration/runtime excluded. Binary/compressed payload interiors not searched by rg.','matches':matches})
print(json.dumps({'records':len(rows),'matched_files':len(matches),'returncode':run.returncode}))
