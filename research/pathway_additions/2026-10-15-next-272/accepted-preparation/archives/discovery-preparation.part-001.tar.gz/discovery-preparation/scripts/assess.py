from pathlib import Path
import json,subprocess,hashlib,collections,gzip,shutil,re
import yaml
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation');W=Path('/private/tmp/pathwaymech-next-271-20261015')
BASE='63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,d): (R/'results'/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def git(path):return subprocess.check_output(['git','-C',str(W),'show',BASE+':'+path])
root=next(x for x in json.loads((R/'results/native-complete-own-slot-projections.json').read_text()) if x['frameid']=='PWY0-1477')
dispositions={
 'parent':'Amine-degradation classification; not a member pathway or causal edge.',
 'credits':'Curatorial provenance, 2010 creation/2017 revision. Not experimental mechanism evidence.',
 'comment':'All five paragraphs read. Preserve chemical route, both branches, microcompartment/cofactor/regulation context and explicit uncertainty. The blanket lumen wording conflicts with the 2013 cited model predicting external EutBC; do not flatten either into universal measured localization. Narrative full-operon range is not direct strain proof. EutE is explicitly assumed; genetic phenotypes are not purified assays. EutT/cofactor synthesis, phospholipid supply and adjacent PWY-7013 remain separately scoped context, not silently added native members.',
 'pathway-link':'Acetate excretion is a textual boundary link, not an issued transporter reaction. Preserve as context; do not invent a transport accession.',
 'evidence':'Preserve exact evidence code and citation. EV-EXP with PMID784902 and EV-EXP-IDA with PMID14996820 are source evidence assertions, not proof of all five members in both strains. First abstract unavailable; EutD abstract tests acetyl-CoA synthesis and acetate-growth rescue, not directly the whole catabolic route.',
 'taxonomic-range':'Bacteria is broad source range only; no universal occurrence or all-five-reaction experimental assertion.',
 'reaction-ordering':'Preserve this exact directed native predecessor relation. Four relations total, branching at ETHAMLY-RXN; not a measured universal temporal order or compartment transport.',
 'species':'Retain exact native strain association and source NCBI xref as a lead. Two strains: E. coli MG1655/511145 and Salmonella LT2/99287; current issuer and primary strain validation remain required. Do not transfer Salmonella mutant outcomes to E. coli.',
 'reaction-layout':'Native pathway-selected direction is distinct from Reaction-own reversibility. Primaries are diagram layout, not complete equations or explicit compartments.',
 'dblink':'EcoCyc PWY0-1477 is native unification lead. Exact counterpart graph has not been independently acquired; no accepted exact mapping yet.',
 'common-name':'Exact native label ethanolamine utilization; do not replace with the broader GO process as if exact pathway equivalence were proved.',
 'reaction-list':'All five members retained in candidate scope, including ethanol branch and acetate/ATP branch. No truncation to EutBC/EutE; no adjacent TCA/acetate-recapture/cofactor pathway expansion.'}
put('complete-root-slot-dispositions.json',[{**s,'disposition':dispositions[s['slot']]} for s in root['slots']])
# Corpus preservation, formal Rhea-family overlap, and source-owner status.
corpus=[]
for p in sorted((R/'inputs/baseline/data/pathways').glob('*.yaml')):
 raw=p.read_bytes();assert raw==git('data/pathways/'+p.name);corpus.append((p,yaml.safe_load(raw)))
pending=R/'inputs/pending271/data/pathways/methanogenesis-from-acetate.yaml'
assert pending.read_bytes()==(W/'data/pathways'/pending.name).read_bytes()
direction_raw=git('conf/rhea_directions.json');(R/'inputs/baseline/conf/rhea_directions.json').write_bytes(direction_raw)
directions=json.loads(direction_raw)['directions'];aliases=['15314','25293','23291','11355','19524']
families={a:directions.get(a) for a in aliases};overlaps=[]
for p,d in corpus+[(pending,yaml.safe_load(pending.read_bytes()))]:
 hits=[]
 for rxn in d.get('reactions',[]):
  rid=rxn['id'];number=rid.removeprefix('RHEA:')
  if rid.startswith('RHEA:'):
   for a,fam in families.items():
    if fam is not None and directions.get(number)==fam:hits.append({'native_xref_lead':'RHEA:'+a,'record_reaction':rid,'master':fam,'reaction':rxn})
 if hits:overlaps.append({'record':d['id'],'path':p.name,'hits':hits})
put('pinned-rhea-family-overlaps.json',{'direction_source_sha256':sha(direction_raw),'scope':'Pinned selected Rhea direction families normalize native xref leads for duplicate discovery; no chemical equivalence or current issuing validation accepted.','families':families,'overlaps':overlaps})
native=json.loads((R/'results/ethanolamine-boundary.json').read_text());core=['PWY0-1477']+native['root']['members']+native['materials']
authorities=[]
for label,raw in [('landed267',git('data/identifier_authorities/sources.json')),('pending271',(W/'data/identifier_authorities/sources.json').read_bytes())]:
 data=json.loads(raw);rows=[]
 for frame in core:
  term='MetaCyc:'+frame
  rows.append({'id':term,'present':term in data['terms'],'term':data['terms'].get(term)})
 authorities.append({'scope':label,'snapshot_sha256':sha(raw),'source_count':len(data['sources']),'term_count':len(data['terms']),'core':rows})
put('core-authority-coverage.json',authorities)
sources=yaml.safe_load((R/'inputs/baseline/conf/sources.yaml').read_text())['sources']
put('source-and-corpus-overview.json',{'record_count':len(corpus),'pending_count':1,'pathway_prefixes':dict(collections.Counter(d['id'].split(':')[0] for p,d in corpus)),'sources':sources,'source_status_counts':dict(collections.Counter(x['ingest_status'] for x in sources)),'candidate_comparison':[{'id':'MetaCyc:DISSULFRED-PWY','disposition':'Unresolved, not rejected or exhausted. Current issue410 open with no comments; donor-resolved complete DsrC-step evidence is a prerequisite. Fresh full root/five reactions are retained but do not close that gap.'},{'id':'MetaCyc:PWY0-1477','disposition':'Recommend bounded full source preparation. Distinct five-member branched utilization route and microcompartment context; existing EutE/Ack/Pta shared components do not establish a pathway duplicate.'},{'id':'MetaCyc:N2FIX-PWY','disposition':'Cross-Mech lead retained unassessed in this task; no source original read and no rejection or exhaustion claim.'},{'id':'MetaCyc:AMMOXID-PWY','disposition':'Cross-Mech lead retained unassessed in this task; no source original read and no rejection or exhaustion claim.'}]})
# Preserve key prior-context sources in full; the broad search receipts bind other matches.
prior=['research/pathway_additions/2026-10-10/README.md','research/pathway_additions/2026-10-10/candidate-inventory.json','research/pathway_additions/2026-10-10-salvage/imodulondb-context.json','research/pathway_additions/2026-10-14-next-261/source-evidence/native/curated-catalyst-scope-decisions.json','research/pathway_additions/2026-10-14-next-262/source-evidence/native/curated-catalyst-scope-decisions.json','research/pathway_additions/2026-10-14-next-261/source-evidence/native/prose-claim-context-ledger.json','research/pathway_additions/2026-10-14-next-261/authoring/native/native-source-context.md','research/cross_mech/2026-10-05/inputs/uniprot_annotations.json']
bindings=[]
for path in prior:
 raw=(W/path).read_bytes();dst=R/'inputs/prior-reading'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(raw);bindings.append({'path':path,'sha256':sha(raw),'bytes':len(raw)})
put('prior-reading-bindings.json',bindings)
put('input-preservation-check.json',{'all267_landed_records_match_git':True,'pending271_record_matches_initial_copy':True,'landed_commit':BASE,'rebind_required_after_271_merge':True})
print(json.dumps({'root_dispositions':len(root['slots']),'rhea_overlap_records':len(overlaps),'core_coverage':[(x['scope'],sum(r['present'] for r in x['core']),len(x['core'])) for x in authorities]}))
