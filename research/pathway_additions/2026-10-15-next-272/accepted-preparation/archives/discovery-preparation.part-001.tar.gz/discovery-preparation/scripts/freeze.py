from pathlib import Path
import json,hashlib,datetime,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation');W=Path('/private/tmp/pathwaymech-next-271-20261015')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
assert not (R/'artifact-manifest.json').exists() and not (R/'freeze-proof.json').exists()
baseline=json.loads((R/'results/baseline.json').read_text());checks=[]
for row in baseline['records']:
 p=R/'inputs/baseline'/row['path']; b=p.read_bytes()
 assert sha(b)==row['sha256'] and b==(W/row['path']).read_bytes()
 checks.append({'kind':'landed-record','path':str(p.relative_to(R)),'sha256':sha(b),'bytes':len(b),'matches_current_worktree':True})
pending=baseline['pending271'];p=R/'inputs/pending271'/pending['path'];b=p.read_bytes()
assert sha(b)==pending['sha256'] and b==(W/pending['path']).read_bytes()
checks.append({'kind':'pending271-record','path':str(p.relative_to(R)),'sha256':sha(b),'bytes':len(b),'matches_current_worktree':True})
acquisitions=[]
for p in sorted((R/'receipts').glob('*.json')):
 d=json.loads(p.read_text())
 if d.get('path'):
  b=(R/d['path']).read_bytes();assert len(b)==d['bytes'] and sha(b)==d['sha256']
  acquisitions.append({'receipt':str(p.relative_to(R)),'body':d['path'],'status':d.get('status'),'sha256':sha(b),'bytes':len(b)})
 d['receipt_path']=str(p.relative_to(R))
native=[]
for p in sorted((R/'originals').glob('META-*.xml')):
 r=E.parse(p).getroot();metadata=r.find('metadata');objects=[x for x in r if x.tag!='metadata'];assert len(objects)==1
 x=objects[0];fid=p.stem[5:]
 assert x.attrib['frameid']==fid and x.attrib['orgid']=='META' and x.attrib['detail']=='full'
 assert metadata.findtext('query')=='META:'+fid and metadata.findtext('num_results')=='1'
 native.append({'path':str(p.relative_to(R)),'type':x.tag,'frameid':fid,'own_slots':len(list(x)),'version':metadata.find('PGDB').attrib['version'],'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
assert len(native)==12
boundary=json.loads((R/'results/ethanolamine-boundary.json').read_text())
assert len(boundary['root']['members'])==5 and len(boundary['root']['ordering'])==4 and boundary['material_occurrences']==22 and len(boundary['materials'])==14
dispositions=json.loads((R/'results/complete-root-slot-dispositions.json').read_text());assert len(dispositions)==21 and all(x['disposition'] for x in dispositions)
corpus=json.loads((R/'results/all268-corpus-comparison-successor.json').read_text())['records'];assert len(corpus)==268 and not any(x['root_exact_match'] or x['root_label_match'] for x in corpus)
issue=json.loads((R/'originals/issue410-current-gh.json').read_text());assert issue['number']==410 and issue['state']=='OPEN' and issue['comments']==[]
put(R/'results/final-checks.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'record_checks':checks,'acquisitions':acquisitions,'native_envelopes':native,'root_own_slot_dispositions':21,'prospective_corpus_checked':268,'issue410_current_state':issue['state'],'issue410_comment_count':len(issue['comments']),'scope':'Mechanical consistency only, not independent science or authority acceptance. Actual271-merge rebind remains mandatory.','owned_sessions_terminal':[26842,98864,30648,25965,81544,26286,13462,15156,60883,7652]})
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink()
 b=p.read_bytes();files.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)})
put(R/'artifact-manifest.json',{'format':'pathwaymech-discovery-preparation/1','owner':str(R),'files':files,'file_count':len(files),'total_bytes':sum(x['bytes'] for x in files),'exclusions':['artifact-manifest.json','freeze-proof.json'],'scope':'Full physical packet inventory, including inputs, raw originals, failures and corrected exploratory receipts. No maintained curation or independent acceptance.'})
manifest=R/'artifact-manifest.json'
put(R/'freeze-proof.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(manifest.read_bytes()),'handoff_sha256':sha((R/'HANDOFF.md').read_bytes()),'assessment_sha256':sha((R/'ASSESSMENT.md').read_bytes()),'listed_files':len(files),'listed_bytes':sum(x['bytes'] for x in files),'physical_files':len(files)+2,'all_owned_jobs_terminal':True})
physical={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
assert physical=={x['path'] for x in files}|{'artifact-manifest.json','freeze-proof.json'}
for row in files:
 b=(R/row['path']).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
print(json.dumps({'manifest_sha256':sha(manifest.read_bytes()),'freeze_sha256':sha((R/'freeze-proof.json').read_bytes()),'handoff_sha256':sha((R/'HANDOFF.md').read_bytes()),'listed_files':len(files),'physical_files':len(physical),'listed_bytes':sum(x['bytes'] for x in files)},indent=2))
