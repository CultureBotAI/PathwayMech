from pathlib import Path
import xml.etree.ElementTree as E,json,hashlib,collections
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
def put(name,d): (R/'results'/name).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
projections=[]
for p in sorted((R/'originals').glob('META-*.xml')):
 root=E.parse(p).getroot();objects=[c for c in root if c.tag!='metadata'];assert len(objects)==1
 obj=objects[0];fid=p.stem[5:];assert obj.attrib['frameid']==fid and obj.attrib['orgid']=='META' and obj.attrib['detail']=='full'
 assert root.findtext('./metadata/query')=='META:'+fid and root.findtext('./metadata/num_results')=='1'
 counts=collections.Counter();slots=[]
 for c in obj:
  counts[c.tag]+=1
  slots.append({'locator':f"/{root.tag}/{obj.tag}[@frameid='{fid}']/{c.tag}[{counts[c.tag]}]",'slot':c.tag,'index':counts[c.tag],'xml':E.tostring(c,encoding='unicode'),'text':' '.join(c.itertext()).strip()})
 row={'frameid':fid,'type':obj.tag,'attrs':obj.attrib,'version':root.find('./metadata/PGDB').attrib,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'own_slot_count':len(slots),'slots':slots}
 if obj.tag=='Pathway':
  row['members']=[x.attrib['frameid'] for x in obj.findall('./reaction-list/Reaction')]
  row['ordering']=[{'reaction':x.find('Reaction').attrib['frameid'],'predecessors':[p.attrib['frameid'] for p in x.findall('./predecessor-reactions/Reaction')]} for x in obj.findall('reaction-ordering')]
  row['layout']=[{'reaction':x.find('Reaction').attrib['frameid'],'direction':x.findtext('direction')} for x in obj.findall('reaction-layout')]
  row['species']=[{'frameid':x.attrib['frameid'],'rank':x.findtext('rank'),'label':x.findtext('common-name'),'strain':x.findtext('strain-name'),'ncbi':[y.findtext('dblink-oid') for y in x.findall('dblink') if y.findtext('dblink-db')=='NCBI-TAXONOMY-DB']} for x in obj.findall('./species/Organism')]
 if obj.tag=='Reaction':
  row['direction']=obj.findtext('reaction-direction');row['sides']={}
  for side in ['left','right']:
   row['sides'][side]=[]
   for c in obj.findall(side):
    terms=[n for n in c if 'frameid' in n.attrib]
    assert len(terms)==1
    n=terms[0];row['sides'][side].append({'id':n.attrib['frameid'],'type':n.tag,'coefficient':c.findtext('coefficient') or '1','raw_xml':E.tostring(c,encoding='unicode')})
  row['activities']=[x.attrib for x in obj.findall('./enzymatic-reaction/Enzymatic-Reaction')]
  row['xrefs']=[{x.tag:x.text for x in c} for c in obj.findall('dblink')]
 projections.append(row)
put('native-complete-own-slot-projections.json',projections)
eth=next(x for x in projections if x['frameid']=='PWY0-1477')
rxns=[next(x for x in projections if x['frameid']==id) for id in eth['members']]
materials=sorted({t['id'] for r in rxns for terms in r['sides'].values() for t in terms})
put('ethanolamine-boundary.json',{'root':{k:v for k,v in eth.items() if k!='slots'},'reactions':[{k:v for k,v in r.items() if k!='slots'} for r in rxns],'materials':materials,'material_occurrences':sum(len(s) for r in rxns for s in r['sides'].values()),'activity_occurrences':sum(len(r['activities']) for r in rxns)})
print(json.dumps({'root_own_slots':eth['own_slot_count'],'members':len(rxns),'materials':materials,'activity_occurrences':sum(len(r['activities']) for r in rxns)}))
