from pathlib import Path
import subprocess,json,hashlib,gzip,collections,shutil,xml.etree.ElementTree as E
import yaml
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
W=Path('/private/tmp/pathwaymech-next-271-20261015')
O=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(name,d): (R/'results'/name).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def match(raw,patterns,limit=12):
 text=raw.decode('utf-8',errors='replace').lower(); out=[]
 for p in patterns:
  v=p.lower();count=text.count(v)
  if not count:continue
  offsets=[];start=0
  for i in range(min(count,limit)):
   pos=text.index(v,start);offsets.append({'character_offset':pos,'context':text[max(0,pos-180):pos+len(v)+220]});start=pos+len(v)
  out.append({'pattern':p,'count':count,'contexts':offsets,'contexts_limited_to':limit})
 return out
pats=['PWY0-1477','ethanolamine utilization','ethanolamine catabolic process','ethanolamine degradation','ethanolamine catabolism','ethanolamine breakdown','GO:0046336','ETHAMLY-RXN','ALCOHOL-DEHYDROG-RXN','ACETALD-DEHYDROG-RXN','ACETATEKIN-RXN','PHOSACETYLTRANS-RXN','15314','25293','23291','11355','19524','R00749','R00754','R00228','R00315','R00230','23585538','14996820','16585748','16291677','23920494','784902','6374020','7868611','10464203','1090845','15516577','10.1128/jb.02179-12','10.1128/jb.186.6.1890-1892.2004','10.1128/jb.188.8.2865-2874.2006','10.1128/jb.187.23.8039-8046.2005']
(R/'results/candidate-search-patterns.txt').write_text('\n'.join(pats)+'\n')
for label,root in [('pending271-worktree',W),('original-checkout',O)]:
 args=['rg','--no-ignore','--hidden','-l','-i','-F','-f',str(R/'results/candidate-search-patterns.txt'),'-g','!.git','-g','!.venv','.']
 p=subprocess.run(args,cwd=root,capture_output=True)
 (R/f'results/candidate-rg-{label}.stdout').write_bytes(p.stdout);(R/f'results/candidate-rg-{label}.stderr').write_bytes(p.stderr)
 rows=[]
 for path in p.stdout.decode().splitlines():
  raw=(root/path).read_bytes(); rows.append({'path':path,'bytes':len(raw),'sha256':sha(raw),'hits':match(raw,pats)})
 save(f'candidate-ordinary-search-{label}.json',{'root':str(root),'argv':args,'returncode':p.returncode,'scope':'All hidden and ignored ordinary text; .git and .venv excluded; binary and compressed interiors not searched. Numeric substring matches are leads, not identity matches.','matches':rows})
 print(label,'matched',len(rows),flush=True)
# A declared bounded compressed-history scope reused from previous discovery.
old=Path('/private/tmp/pathwaymech-next-270-discovery/results/compressed-history-content-scan.json')
shutil.copyfile(old,R/'inputs/prior-next270/compressed-history-content-scan.json')
archive_rows=[]
for item in json.loads(old.read_text())['files']:
 p=W/item['path']; raw=p.read_bytes();assert sha(raw)==item['compressed_sha256']
 decoded=gzip.decompress(raw);assert sha(decoded)==item['decoded_sha256']
 hits=match(decoded,pats)
 row={'path':item['path'],'bytes':len(raw),'sha256':sha(raw),'decoded_bytes':len(decoded),'decoded_sha256':sha(decoded),'hits':hits}
 archive_rows.append(row)
 if hits:
  dest=R/'inputs/selected-archive-hits'/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
save('selected-compressed-search.json',{'scope':'Exactly the prior next270 116 selected gzip payloads, hashes rechecked before full decode and new ethanolamine-term search. All other archive interiors, including nested containers, remain unsearched.','files':archive_rows})
inventory=[]
for p in W.rglob('*'):
 if not p.is_file() or any(x in p.relative_to(W).parts for x in ['.git','.venv']):continue
 if p.suffix.lower() in ['.gz','.zip','.xz','.bz2','.zst','.tar']:
  b=p.read_bytes();inventory.append({'path':str(p.relative_to(W)),'bytes':len(b),'sha256':sha(b)})
save('archive-physical-inventory.json',{'scope':'Physical container bytes only. This is not an interior content search.','files':inventory})
rows=[]
native=json.loads((R/'results/ethanolamine-boundary.json').read_text())
member_ids={'MetaCyc:'+x for x in native['root']['members']}
for group in ['baseline','pending271']:
 for p in sorted((R/'inputs'/group/'data/pathways').glob('*.yaml')):
  raw=p.read_bytes();d=yaml.safe_load(raw)
  ids=set()
  def visit(v):
   if isinstance(v,dict):
    for k,x in v.items():
     if k=='id' and isinstance(x,str):ids.add(x)
     visit(x)
   elif isinstance(v,list):
    for x in v:visit(x)
  visit(d)
  rows.append({'scope':group,'path':p.name,'id':d['id'],'label':d['label'],'sha256':sha(raw),'declared_member_overlap':sorted(member_ids&ids),'hits':match(raw,pats,4)})
save('all268-corpus-comparison.json',rows)
print('archives',len(inventory),'selected',len(archive_rows),'corpus',len(rows),flush=True)
