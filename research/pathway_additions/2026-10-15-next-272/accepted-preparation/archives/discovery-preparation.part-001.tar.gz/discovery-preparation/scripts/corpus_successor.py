from pathlib import Path
import json,gzip,hashlib,collections
import yaml
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
def put(n,d):(R/'results'/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
old=json.loads((R/'results/all268-corpus-comparison.json').read_text())
root=json.loads((R/'results/ethanolamine-boundary.json').read_text())
memberids={'MetaCyc:'+x for x in root['root']['members']}
p=next((R/'inputs/selected-archive-hits').rglob('rhea-directions.tsv.gz'));raw=gzip.decompress(p.read_bytes())
families={v:line.split('\t')[0] for line in raw.decode().splitlines()[1:] for v in line.split('\t')}
aliases=['15314','25293','23291','11355','19524'];family={a:families[a] for a in aliases}
rows=[];overlaps=[]
for group in ['baseline','pending271']:
 for p in sorted((R/'inputs'/group/'data/pathways').glob('*.yaml')):
  b=p.read_bytes();d=yaml.safe_load(b)
  ids={x['id'] for field in ['participants','reactions','taxa'] for x in d.get(field,[])}|{d['id']}
  refs={x['id'] for x in d.get('references',[])}
  rows.append({'scope':group,'path':p.name,'sha256':sha(b),'id':d['id'],'label':d['label'],'root_exact_match':d['id']=='MetaCyc:PWY0-1477','root_label_match':d['label'].lower()=='ethanolamine utilization','declared_member_overlap':sorted(ids&memberids),'reference_only_member_mentions':sorted((refs-ids)&memberids)})
  found=[]
  for reaction in d.get('reactions',[]):
   rid=reaction['id'];num=rid.removeprefix('RHEA:')
   if rid.startswith('RHEA:'):
    for alias,fam in family.items():
     if families.get(num)==fam:found.append({'native_xref_lead':'RHEA:'+alias,'record_reaction':rid,'master':fam})
  if found:overlaps.append({'record':d['id'],'path':p.name,'hits':found})
put('all268-corpus-comparison-successor.json',{'supersedes':'all268-corpus-comparison.json declared_member_overlap only; initial recursive id collection also included references. Original retained unchanged.','records':rows})
put('complete-table-rhea-family-overlaps.json',{'source_compressed_path':str(next((R/'inputs/selected-archive-hits').rglob('rhea-directions.tsv.gz')).relative_to(R)),'decoded_sha256':sha(raw),'scope':'Complete retained TSV from prior264 discovery; current issuing chemistry and mappings not revalidated. This supplements the older selected-quartet conf table, which omitted 15314 and23291.','families':family,'overlaps':overlaps})
put('corpus-comparison-correction.json',{'problem':'Exploratory traversal counted reference IDs as local node declarations. Three landed records cite native ACETALD-DEHYDROG-RXN without declaring it as a biological node. Corrected read-only successor uses only root/taxa/participants/reactions.','old_sha256':sha((R/'results/all268-corpus-comparison.json').read_bytes()),'successor_sha256':sha((R/'results/all268-corpus-comparison-successor.json').read_bytes()),'complete_record_count':len(rows),'exact_root_or_label_hits':[x for x in rows if x['root_exact_match'] or x['root_label_match']],'biological_member_overlaps':[x for x in rows if x['declared_member_overlap']]})
print(json.dumps({'records':len(rows),'native_declarations':[(x['id'],x['declared_member_overlap']) for x in rows if x['declared_member_overlap']],'formal_family_overlaps':overlaps}))
