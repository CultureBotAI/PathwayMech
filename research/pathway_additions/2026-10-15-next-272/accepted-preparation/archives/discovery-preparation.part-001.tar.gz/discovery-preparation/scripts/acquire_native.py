from pathlib import Path
import urllib.request,json,hashlib,datetime,sys
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
attempt=sys.argv[1]
for fid in sys.argv[2:]:
    url='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+fid
    receipt={'id':fid,'url':url,'attempt':attempt,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(url,timeout=40) as h:
            raw=h.read(); receipt.update(status=h.status,final_url=h.url,headers=dict(h.headers))
        dst=R/'originals'/('META-'+fid+'.xml'); assert not dst.exists();dst.write_bytes(raw)
        receipt.update(path=str(dst.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
    except Exception as e: receipt['error']=repr(e)
    dest=R/'receipts'/('native-'+fid+'-'+attempt+'.json');assert not dest.exists();dest.write_text(json.dumps(receipt,indent=2)+'\n')
    print(fid,receipt.get('status'),receipt.get('error'),flush=True)
