from pathlib import Path
import urllib.request,urllib.error,json,hashlib,datetime,sys
R=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
items={
 'issue410.json':'https://api.github.com/repos/CultureBotAI/PathwayMech/issues/410',
 'issue410-comments.json':'https://api.github.com/repos/CultureBotAI/PathwayMech/issues/410/comments?per_page=100',
 'PMC3697265.xml':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC3697265/fullTextXML',
 'PMC355984.xml':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC355984/fullTextXML',
 'GO0046336.json':'https://www.ebi.ac.uk/QuickGO/services/ontology/go/terms/GO%3A0046336',
 'primary-metadata.json':'https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID%3A23585538%20OR%20EXT_ID%3A14996820%20OR%20EXT_ID%3A16585748%20OR%20EXT_ID%3A16291677%20OR%20EXT_ID%3A23920494%20OR%20EXT_ID%3A784902%20OR%20EXT_ID%3A6374020%20OR%20EXT_ID%3A7868611%20OR%20EXT_ID%3A10464203%20OR%20EXT_ID%3A1090845%20OR%20EXT_ID%3A15516577&format=json&resultType=core&pageSize=100',
 'kegg-module-ethanolamine.txt':'https://rest.kegg.jp/find/module/ethanolamine',
}
for name in sys.argv[2:]:
 url=items[name]; receipt={'url':url,'attempt':sys.argv[1],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'PathwayMech-candidate-research','Accept':'application/json' if name.endswith('.json') else '*/*'})
  with urllib.request.urlopen(req,timeout=45) as h: raw=h.read();receipt.update(status=h.status,final_url=h.url,headers=dict(h.headers))
  dst=R/'originals'/name; assert not dst.exists(); dst.write_bytes(raw)
  receipt.update(path=str(dst.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except urllib.error.HTTPError as e:
  raw=e.read();dst=R/'originals'/(name+'.'+sys.argv[1]+'.failed');dst.write_bytes(raw)
  receipt.update(status=e.code,error=repr(e),path=str(dst.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except Exception as e: receipt['error']=repr(e)
 dst=R/'receipts'/(name+'.'+sys.argv[1]+'.json'); assert not dst.exists();dst.write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,receipt.get('status'),receipt.get('error'),flush=True)
