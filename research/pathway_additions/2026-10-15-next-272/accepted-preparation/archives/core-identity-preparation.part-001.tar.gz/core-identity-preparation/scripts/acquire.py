from pathlib import Path
import json,hashlib,datetime,urllib.request,urllib.error,concurrent.futures,sys
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation')
def one(j):
 receipt={'url':j['url'],'name':j['name'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':sys.argv[2]}
 out=R/'originals'/j['name']; rec=R/'receipts'/(j['name']+'.'+sys.argv[2]+'.json'); assert not out.exists() and not rec.exists()
 try:
  req=urllib.request.Request(j['url'],headers={'User-Agent':'PathwayMech source identity preparation; evidence preservation','Accept':j.get('accept','*/*')})
  with urllib.request.urlopen(req,timeout=50) as h:
   b=h.read();receipt.update(status=h.status,final_url=h.url,headers={k:v for k,v in h.headers.items() if k.lower() not in ['set-cookie']})
 except urllib.error.HTTPError as e:
  b=e.read();receipt.update(status=e.code,error=str(e),headers=dict(e.headers));out=out.with_name(out.name+'.failed')
 except Exception as e:
  b=None;receipt['error']=repr(e)
 if b is not None:out.write_bytes(b);receipt.update(path=str(out.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 receipt['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec.write_text(json.dumps(receipt,indent=2)+'\n')
 return {'name':j['name'],'status':receipt.get('status'),'bytes':receipt.get('bytes'),'error':receipt.get('error')}
if __name__=='__main__':
 jobs=json.loads((R/'inputs'/sys.argv[1]).read_text())
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  for result in ex.map(one,jobs):print(json.dumps(result),flush=True)
