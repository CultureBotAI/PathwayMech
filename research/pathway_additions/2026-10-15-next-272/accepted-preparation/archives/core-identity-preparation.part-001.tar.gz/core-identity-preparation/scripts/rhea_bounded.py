from pathlib import Path
import gzip,re,json,hashlib,xml.etree.ElementTree as E,shutil
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation');P=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');(R/'inputs/rhea').mkdir(exist_ok=True)
H=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((P/'artifact-manifest.json').read_text());rows={x['path']:x for x in m['files']}
for name in ['originals/rhea.rdf.gz','originals/rhea-directions.tsv','originals/rhea-release.properties']:
 b=(P/name).read_bytes();assert H(b)==rows[name]['sha256']
for name in ['artifact-manifest.json','freeze-proof.json','inputs/reused-originals.json','inputs/rhea-ancestry/packet268/source-copy-bindings.json']:
 shutil.copyfile(P/name,R/'inputs/rhea'/name.replace('/','__'))
seeds={'15314','23291','19524','11355','25293'}; families=[]
lines=(P/'originals/rhea-directions.tsv').read_bytes().splitlines(keepends=True); selected=[lines[0]]
for line in lines[1:]:
 vals=line.decode().strip().split('\t')
 if seeds & set(vals):families.append(dict(zip(['master','left_to_right','right_to_left','bidirectional'],vals)));selected.append(line)
assert len(families)==5
(R/'originals/rhea-directions-selected.tsv').write_bytes(b''.join(selected));shutil.copyfile(P/'originals/rhea-release.properties',R/'originals/rhea-release.properties')
NS='http://rdf.rhea-db.org/';rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#';wanted={NS+x for f in families for x in f.values()};nodes={};fragments={};scans=[]
while True:
 with gzip.open(P/'originals/rhea.rdf.gz','rb') as h:
  header=b''
  while True:
   ln=h.readline();header+=ln
   if ln.strip()==b'':break
  count=0;offset=len(header);start=0;part=[]
  for ln in h:
   if ln.startswith(b'<rdf:Description '):part=[];start=offset
   if part or ln.startswith(b'<rdf:Description '):part.append(ln)
   offset+=len(ln)
   if ln.startswith(b'</rdf:Description>'):
    raw=b''.join(part);uri=re.search(rb'rdf:about="([^"]+)"',raw).group(1).decode();count+=1
    if uri in wanted and uri not in nodes:
     e=list(E.fromstring(header+raw+b'</rdf:RDF>'))[0]
     nodes[uri]=[{'predicate':x.tag[1:].replace('}',''),'resource':x.get('{'+rdf+'}resource'),'literal':x.text,'attributes':x.attrib} for x in e]
     fragments[uri]={'raw':raw,'start':start,'end':offset};part=[]
 scans.append({'description_count':count,'decoded_bytes':offset})
 added={x['resource'] for u in wanted for x in nodes.get(u,[]) if x['resource'] and (x['predicate'] in {NS+k for k in ['side','substrates','products','contains','compound','reactivePart','underlyingChebi','chebi','location','replacedBy','replaces']} or x['predicate'].startswith(NS+'contains')) and x['resource'].startswith(NS)}-wanted
 if not added:break
 wanted|=added
assert wanted<=nodes.keys(),wanted-nodes.keys()
result={'source_file':str(P/'originals/rhea.rdf.gz'),'source_sha256':rows['originals/rhea.rdf.gz']['sha256'],'source_frozen_manifest':H((P/'artifact-manifest.json').read_bytes()),'description_scans':scans,'seeds':sorted(seeds),'families':families,'complete_selected_statements':nodes,'fragment_bindings':[]}
(R/'originals/rhea-selected').mkdir(exist_ok=True)
for u,f in sorted(fragments.items()):
 name=u.removeprefix(NS)+'.rdf.fragment';(R/'originals/rhea-selected'/name).write_bytes(f['raw']);result['fragment_bindings'].append({'uri':u,'path':'originals/rhea-selected/'+name,'decoded_source_start':f['start'],'decoded_source_end':f['end'],'sha256':H(f['raw']),'bytes':len(f['raw'])})
(R/'originals/rhea-selected-envelope-header.txt').write_bytes(header)
(R/'results/rhea-issuer-bounded.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'families':families,'descriptions':len(nodes),'scans':len(scans),'fragment_bytes':sum(len(f['raw']) for f in fragments.values())},indent=2))
