from pathlib import Path
import json,re,html,xml.etree.ElementTree as E,collections,hashlib
from html.parser import HTMLParser
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
  if t in ['br','p','tr','h1','h2','h3']:self.parts.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.parts.append(d)
def plain(s):
 p=Text();p.feed(s);return html.unescape(' '.join(p.parts))
def fields(p):
 out={};key=None
 for l in p.read_text().splitlines():
  if l[:12].strip():key=l[:12].strip();out.setdefault(key,[])
  if key:out[key].append(l[12:].strip())
 return {k:' '.join(v) for k,v in out.items()}
for p in (R/'originals').glob('*.html'):
 (R/'results'/(p.name+'.text')).write_text(plain(p.read_text())+'\n')
mnx={}
for p in (R/'originals').glob('MNX-*.html'):
 rows=re.findall(r'<tr><td>(.*?)</td><td[^>]*>(.*?)</td></tr>',p.read_text(),re.S)
 props={plain(k).strip():plain(v).strip() for k,v in rows if '<' not in k}
 mnx[p.stem.removeprefix('MNX-')]={'props':props,'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(R/'results/metanetx-properties.json').write_text(json.dumps(mnx,indent=2)+'\n')
(R/'results/kegg-fields.json').write_text(json.dumps({p.stem:fields(p) for p in (R/'originals').glob('KEGG-*.txt')},indent=2)+'\n')
for i,d in mnx.items():
 if i.startswith('MNXM'):print(i,{k:v for k,v in d['props'].items() if k in ['MNX_ID','name','formula','charge','InChI','InChIKey']})
for p in (R/'originals').glob('IUBMB*.html'): print(p.name,plain(p.read_text())[:2400])
