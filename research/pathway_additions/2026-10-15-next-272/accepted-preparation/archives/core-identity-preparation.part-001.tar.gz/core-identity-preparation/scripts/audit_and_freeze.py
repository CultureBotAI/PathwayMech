from pathlib import Path
import json,hashlib,datetime,shutil,collections,os
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation');H=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(n,v):checks.append({'check':n,'pass':bool(v)});assert v,n
for e in json.loads((R/'results/reuse-bindings.json').read_text())['entries']:
 if e.get('retained_in_packet',True):ck('reused:'+e['path'],(R/e['path']).stat().st_size==e['bytes'] and H((R/e['path']).read_bytes())==e['sha256'])
for e in json.loads((R/'results/additional-reuse-bindings.json').read_text()):ck('additional-reuse:'+e['path'],H((R/e['path']).read_bytes())==e['sha256'])
counts=collections.Counter()
for p in (R/'receipts').glob('*.json'):
 if p.name.startswith('reused'):continue
 d=json.loads(p.read_text());counts[str(d.get('status','network_error'))]+=1
 if 'path' in d:
  raw=(R/d['path']).read_bytes();ck('acquisition:'+p.name,len(raw)==d['bytes'] and H(raw)==d['sha256'])
for n in ['structural-checks.json','alias-crosschecks.json']:
 d=json.loads((R/'results'/n).read_text());ck(n+':all-reported-checks-pass',all(x['pass'] for x in d['checks']))
# Bound source-agent acquisition receipt and original for exact caution reuse.
src=Path('/private/tmp/pathwaymech-next-272-native-source-preparation/receipts/UniProt-P0AEJ6.json.json');dst=R/'receipts/reused-native-agent-UniProt-P0AEJ6.json.json';shutil.copyfile(src,dst)
d=json.loads((R/'results/k12-scope-context.json').read_text());ck('uniprot-scope-exact-copy',H((R/d['path']).read_bytes())==d['sha256'])
(R/'results/native-agent-receipt-binding.json').write_text(json.dumps({'source':str(src),'path':str(dst.relative_to(R)),'sha256':H(dst.read_bytes()),'bytes':dst.stat().st_size},indent=2)+'\n')
for p in R.rglob('*'):ck('no-symlink:'+str(p.relative_to(R)),not p.is_symlink())
result={'scope':'root20 core identities plus2 direct taxa and EcoCyc counterpart; selected issuer comparisons only','check_count':len(checks),'all_passed':all(x['pass'] for x in checks),'network_status_counts':dict(counts),'process_state':'All acquisition/helper calls terminal at freeze; no owned background jobs','checks':checks}
(R/'results/final-integrity-audit.json').write_text(json.dumps(result,indent=2)+'\n')
# Manifest and freeze proof exclude only their own integrity envelopes.
files=[]
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.name in ['artifact-manifest.json','freeze-proof.json'] and p.parent==R:continue
 b=p.read_bytes();files.append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':H(b)})
m={'schema_version':1,'scope':'finite next272 core identity source preparation; no maintained curation','inventory_includes_hidden_and_ignored':True,'file_count':len(files),'listed_bytes':sum(x['bytes'] for x in files),'exclusions':['artifact-manifest.json','freeze-proof.json'],'files':files}
(R/'artifact-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
p={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':H((R/'artifact-manifest.json').read_bytes()),'handoff_sha256':H((R/'HANDOFF.md').read_bytes()),'listed_file_count':len(files),'physical_file_count':len(files)+2,'all_jobs_terminal':True,'files_verified':all((R/x['path']).stat().st_size==x['bytes'] and H((R/x['path']).read_bytes())==x['sha256'] for x in files),'author_agent':'/root/next272_core_identity_preparation'}
(R/'freeze-proof.json').write_text(json.dumps(p,indent=2)+'\n');print(json.dumps({**p,'freeze_sha256':H((R/'freeze-proof.json').read_bytes()),'listed_bytes':m['listed_bytes'],'integrity_checks':len(checks),'network_status_counts':dict(counts)},indent=2))
