from pathlib import Path
import json,re,collections,csv,io,hashlib,gzip,xml.etree.ElementTree as E,shutil
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation');M=json.loads((R/'results/material-identity-assessment.json').read_text());A=json.loads((R/'results/reaction-identity-assessment.json').read_text());K=json.loads((R/'results/kegg-fields.json').read_text());N=json.loads((R/'results/metanetx-properties.json').read_text());checks=[]
def ck(n,v,d=None):checks.append({'check':n,'pass':bool(v),'detail':d});assert v,(n,d)
lookup={x['selected_mnx']:i for i,x in M.items()};report=[]
for i,a in A.items():
 mnx=a['native_xrefs']['METANETX-RXN'];equation=N[mnx]['props']['equation'].split('\n')[-1].strip();l,r=equation.split(' = ');sides=[]
 for s in [l,r]:
  terms=re.findall(r'(\d+) (MNXM\d+)@(MNXD\d+)',s);ck(mnx+':entire-parsed-side',' + '.join(' '.join([c,m+'@'+d]) for c,m,d in terms)==s)
  ck(mnx+':generic-compartment',all(t[2]=='MNXD1' for t in terms));sides.append(collections.Counter({lookup[m]:int(c) for c,m,d in terms}))
 native=[collections.Counter(x['native'] for x in a['native_sides'][z]) for z in ['left','right']];eq=sides==native;rev=sides==native[::-1];ck(mnx+':native-equation',eq or rev)
 report.append({'native':i,'mnx':mnx,'mnx_equation':equation,'orientation_against_native':('same' if eq else 'reversed'),'disposition':'same finite charged species and coefficients; generic MNXD1 does not assert biological compartment; MNX equation alone does not establish native pathway direction'})
kmap={'C00189':'ETHANOL-AMINE','C00014':'AMMONIUM','C00084':'ACETALD','C00010':'CO-A','C00003':'NAD','C00024':'ACETYL-COA','C00004':'NADH','C00080':'PROTON','C00009':'Pi','C00227':'ACETYL-P','C00008':'ADP','C00002':'ATP','C00033':'ACET','C00469':'ETOH'}
kr=[]
for i,a in A.items():
 kid=a['native_xrefs']['LIGAND-RXN'];record=K['KEGG-'+kid];ks=[]
 for s in record['EQUATION'].split(' <=> '):
  ids=s.split(' + ');ck(kid+':implicit-unit',all(x in kmap for x in ids));ks.append(collections.Counter('META:'+kmap[x] for x in ids))
 ns=[collections.Counter(x['native'] for x in a['native_sides'][z]) for z in ['left','right']];ck(kid+':named-transformation',ks==ns or ks==ns[::-1])
 kr.append({'native':i,'kegg':kid,'equation':record['EQUATION'],'definition':record['DEFINITION'],'orientation_against_native':'same' if ks==ns else 'reversed','accepted_exact_charged_equation_alias':False,'reason':'One or more KEGG source formulas differ in hydrogen count/protonation from the native concrete species; molecular stereochemical equivalence is not established from the flat-file names/formulas alone.'})
chem=[]
for k,n in kmap.items():
 m=M['META:'+n];kf=K['KEGG-'+k]['FORMULA'];nf=m['chebi_formula'];chem.append({'kegg':k,'native':'META:'+n,'kegg_names':K['KEGG-'+k]['NAME'],'kegg_formula':kf,'native_charged_formula':nf,'formula_same': sorted(re.findall(r'([A-Z][a-z]?)(\d*)',kf))==sorted(re.findall(r'([A-Z][a-z]?)(\d*)',nf)),'exact_alias_accepted':False})
# All current Rhea TSV exact master rows are explicit projections, not authority for directional quartet IDs.
current=[]
for family in json.loads((R/'results/rhea-issuer-bounded-complete.json').read_text())['families']:
 master=family['master'];p=R/'originals'/f'RHEA-{master}-master.tsv';rows=list(csv.DictReader(io.StringIO(p.read_text()),delimiter='\t'));hit=[r for r in rows if r.get('Reaction identifier')=='RHEA:'+master];ck(master+':exact-current-master-row',len(hit)==1)
 current.append({'master':master,'raw_returned_rows':len(rows),'exact_row':hit[0]})
# Verify each complete RDF fragment against actual exact decoded source slice, then reconstruct with original header.
r=json.loads((R/'results/rhea-issuer-bounded-complete.json').read_text());b=gzip.open(r['source_file'],'rb').read();header=(R/'originals/rhea-selected-envelope-header.txt').read_bytes();allfrags=[]
for f in r['fragment_bindings']:
 raw=(R/f['path']).read_bytes();ck(f['path']+':exact-source-slice',b[f['decoded_source_start']:f['decoded_source_end']]==raw);allfrags.append(raw)
sel=E.fromstring(header+b''.join(allfrags)+b'</rdf:RDF>');ck('selected-rdf-all-fragments',len(sel)==len(r['fragment_bindings']))
# Check all descriptions for a selected URI were retained, including repeated descriptions.
expected=collections.Counter()
for m in re.finditer(rb'<rdf:Description rdf:about="([^"]+)"',b):
 u=m.group(1).decode()
 if u in r['complete_selected_statements']:expected[u]+=1
actual=collections.Counter(f['uri'] for f in r['fragment_bindings']);ck('selected-rdf-all-repeated-descriptions',expected==actual,dict(expected))
D=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
for name in ['GO0046336.json','kegg-module-ethanolamine.txt']:
 dst=R/'originals'/name
 if not dst.exists():shutil.copyfile(D/'originals'/name,dst)
(R/'results/alias-crosschecks.json').write_text(json.dumps({'metanetx':report,'kegg_reactions':kr,'kegg_chemicals':chem,'current_rhea_master_rows':current,'rdf_scope':{'complete_selected_subjects':len(r['complete_selected_statements']),'exact_fragments':len(r['fragment_bindings']),'source_decoded_bytes':len(b)},'checks':checks,'pass_count':len(checks)},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'mnx_reactions':len(report),'kegg_reactions':len(kr),'current_rhea_rows':len(current),'exact_rdf_fragments':len(r['fragment_bindings'])},indent=2))
