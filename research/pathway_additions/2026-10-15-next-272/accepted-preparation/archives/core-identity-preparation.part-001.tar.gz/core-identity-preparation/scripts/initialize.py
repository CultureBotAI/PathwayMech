from pathlib import Path
import json, shutil, hashlib, gzip, datetime
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation'); D=Path('/private/tmp/pathwaymech-next-272-discovery-preparation'); W=Path('/private/tmp/pathwaymech-next-271-20261015')
for d in ['originals','receipts','inputs/discovery','inputs/preflight','inputs/context','results']: (R/d).mkdir(parents=True,exist_ok=True)
entries=[]
def cp(src,dst,kind):
 dst=R/dst; assert not dst.exists(),dst; dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 entries.append({'source':str(src),'path':str(dst.relative_to(R)),'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'mode':'exact-byte-reuse','kind':kind})
for f in ['HANDOFF.md','ASSESSMENT.md','artifact-manifest.json','freeze-proof.json','results/ethanolamine-boundary.json','results/core-authority-coverage.json','results/complete-root-slot-dispositions.json','results/native-complete-own-slot-projections.json']:
 cp(D/f,'inputs/discovery/'+f,'discovery-context')
P=Path('/private/tmp/pathwaymech-next-272-independent-preflight-review')
for f in ['REVIEW.md','artifact-manifest.json','freeze-proof.json']:cp(P/f,'inputs/preflight/'+f,'independent-preflight')
for f in ['CLAUDE.md','.claude/skills/add-pathway/SKILL.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','src/pathwaymech/biocyc_acetate_methanogenesis.py']:
 cp(W/f,'inputs/context/'+f,'read-only-pending271-context')
for fid in ['PWY0-1477','ETHAMLY-RXN','ACETALD-DEHYDROG-RXN','PHOSACETYLTRANS-RXN','ACETATEKIN-RXN','ALCOHOL-DEHYDROG-RXN']:
 cp(D/'originals'/f'META-{fid}.xml',f'originals/META-{fid}.xml','native-original')
 for p in (D/'receipts').glob(f'native-{fid}-*.json'):cp(p,'receipts/reused-discovery-'+p.name,'original-acquisition-receipt')
materials=['ACET','ACETYL-P','ADP','AMMONIUM']
for fid in materials:
 src=W/'research/pathway_additions/2026-10-15-next-271/authority-source-originals/originals'/f'META-{fid}.xml'
 cp(src,f'originals/META-{fid}.xml','native-original')
 receipt=src.parent.parent/'acquisition'/f'META-{fid}.json'
 if receipt.exists():cp(receipt,'receipts/reused271-'+receipt.name,'original-acquisition-receipt')
for fid in ['ACETYL-COA','CO-A','NADH','ATP']:
 src=W/'research/pathway_additions/2026-10-15-next-268/authority-source-originals'/f'META-{fid}.xml'
 cp(src,f'originals/META-{fid}.xml','native-original')
 cp(src.with_suffix('.xml.receipt.json'),'receipts/reused268-'+src.name+'.receipt.json','original-acquisition-receipt')
for fid in ['ACETALD','Pi']:
 src=W/'research/pathway_additions/2026-10-12-next-238/native-integration/independent-qa/reading'/f'META-{fid}.xml'
 cp(src,f'originals/META-{fid}.xml','native-original-with-repository-owner-provenance')
cp(W/'data/identifier_authorities/sources.json','inputs/context/pending271-sources.json','inventory-not-approval')
cp(W/'conf/identifier_sources.json','inputs/context/pending271-identifier-sources.json','inventory-not-approval')
(R/'results/reuse-bindings.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'entries':entries},indent=2)+'\n')
print('Copied',len(entries),'files;',len(list((R/'originals').glob('*.xml'))),'native originals')
