from pathlib import Path
import json,re,xml.etree.ElementTree as E,collections,hashlib,html,shutil
R=Path('/private/tmp/pathwaymech-next-272-core-identity-preparation'); NS='http://rdf.rhea-db.org/'
H=lambda b:hashlib.sha256(b).hexdigest()
def save(n,v):(R/'results'/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
checks=[]
def ck(name,ok,detail=None):
 checks.append({'check':name,'pass':bool(ok),'detail':detail});assert ok,(name,detail)
def formula(s):return {a:int(n) if n else 1 for a,n in re.findall(r'([A-Z][a-z]?)(\d*)',s.replace(' ',''))}
raw={};proj={}
for p in sorted((R/'originals').glob('*.xml')):
 if p.name.startswith('NCBI'):continue
 r=E.parse(p).getroot(); objs=[x for x in r if x.tag!='metadata'];ck(p.name+':single-full-native',len(objs)==1 and objs[0].get('detail')=='full')
 a=objs[0];i=a.get('orgid')+':'+a.get('frameid'); ck(i+':envelope',r.findtext('metadata/query')==i and r.findtext('metadata/num_results')=='1' and r.find('metadata/PGDB').get('version')=='27.0' and a.get('ID')==i)
 raw[i]=a
 slots=[]
 for n,x in enumerate(a,1):
  disp=('inspected-identity-structure-or-equation' if x.tag in ['parent','common-name','synonym','cml','inchi','inchi-key','molecular-weight','monoisotopic-mw','left','right','reaction-direction','ec-number','rank','strain-name','subspecies-name','reaction-list','reaction-ordering','reaction-layout','species','taxonomic-range','dblink'] else 'complete-source-preserved; biological-or-thermodynamic-context-not-accepted-by-this-identity-review')
  slots.append({'ordinal':n,'tag':x.tag,'locator':f'/ptools-xml/{a.tag}[@frameid="{a.get("frameid")}"]/{x.tag}[{1+sum(y.tag==x.tag for y in list(a)[:n-1])}]','disposition':disp,'xml':E.tostring(x,encoding='unicode')})
 proj[i]={'path':str(p.relative_to(R)),'sha256':H(p.read_bytes()),'native_type':a.tag,'attributes':a.attrib,'own_slot_count':len(a),'slots':slots}
save('native-own-slot-projections.json',proj)
materials={};mnx=json.loads((R/'results/metanetx-properties.json').read_text())
for i,a in raw.items():
 if a.tag!='Compound':continue
 xs=[{x.tag:x.text for x in d} for d in a.findall('dblink')];chebi=next(x['dblink-oid'] for x in xs if x['dblink-db']=='CHEBI'); d=json.loads((R/'originals'/f'CHEBI-{chebi}.json').read_text());s=d['default_structure']; c=a.find('cml/molecule'); f=c.find('formula').get('concise');charge=int(c.get('formalCharge'));key=a.findtext('inchi-key').removeprefix('InChIKey=')
 for kind,ok in [('id',d['chebi_accession']=='CHEBI:'+chebi),('inchi',a.findtext('inchi')==s['standard_inchi']),('key',key==s['standard_inchi_key']),('charge',charge==d['chemical_data']['charge']),('formula',formula(f)==formula(d['chemical_data']['formula'])),('concrete',not a.get('class') and not s['is_r_group'])]:ck(i+':chebi:'+kind,ok)
 native_smiles=[x.text for x in c.findall('string') if x.get('title')=='smiles']; placeholder=any('[R]' in x or '[a ' in x for x in native_smiles)
 matches=[(j,q) for j,q in mnx.items() if j.startswith('MNXM') and q['props'].get('InChIKey')==key];ck(i+':single-selected-mnx',len(matches)==1)
 mid,md=matches[0];mp=md['props']
 for kind,ok in [('inchi',mp['InChI']==a.findtext('inchi')),('charge',int(mp['global charge'])==charge),('formula',formula(mp['formula'])==formula(f))]:ck(i+':mnx:'+kind,ok)
 materials[i]={'native_label':a.findtext('common-name'),'native_class':False,'native_formula':f,'native_charge':charge,'native_inchi':a.findtext('inchi'),'native_inchi_key':key,'native_cml_smiles':native_smiles,'native_cml_smiles_placeholder_conflict':placeholder,'chebi':d['chebi_accession'],'chebi_name':d['name'],'chebi_formula':d['chemical_data']['formula'],'chebi_charge':d['chemical_data']['charge'],'chebi_definition':d['definition'],'selected_mnx':mid,'selected_mnx_smiles':mp.get('SMILES'),'selected_mnx_standardized_smiles':mp.get('SMILES (mnx)'),'accepted_chemical_identity':'same concrete molecular species on exact InChI, InChIKey, formula and charge; native SMILES is not an equivalence premise','native_xref_dispositions':[{'database':x['dblink-db'],'accession':x['dblink-oid'],'relationship':x.get('dblink-relationship'),'disposition':'accepted from independent issuer structure' if x['dblink-db']=='CHEBI' else 'source link preserved; no blanket exact alias acceptance'} for x in xs]}
ck('14-core-materials',len(materials)==14)
save('material-identity-assessment.json',materials)
rhea=json.loads((R/'results/rhea-issuer-bounded-complete.json').read_text());g=rhea['complete_selected_statements']
def vals(u,p):return [x['resource'] if x['resource'] is not None else x['literal'] for x in g[u] if x['predicate']==NS+p]
def one(u,p):
 v=set(vals(u,p));assert len(v)==1,(u,p,v);return next(iter(v))
def rside(u,role):
 side=one(u,role);out=[]
 for t in g[side]:
  pre=t['predicate'];coef=pre.removeprefix(NS+'contains')
  if not pre.startswith(NS+'contains') or not coef:continue
  compound=one(t['resource'],'compound');out.append({'coefficient':int(coef),'chebi':one(compound,'accession'),'formula':one(compound,'formula'),'charge':int(one(compound,'charge')),'location':vals(t['resource'],'location'),'rhea_compound':compound})
 return out
reactions={};layouts={x.find('Reaction').get('frameid'):x.findtext('direction') for x in raw['META:PWY0-1477'].findall('reaction-layout')}
for i,a in raw.items():
 if a.tag!='Reaction':continue
 frame=a.get('frameid');xs={d.findtext('dblink-db'):d.findtext('dblink-oid') for d in a.findall('dblink') if d.findtext('dblink-db') in ['RHEA','LIGAND-RXN','METANETX-RXN']};family=next(f for f in rhea['families'] if xs['RHEA'] in f.values());selected=family['right_to_left'] if layouts[frame]=='R2L' else family['left_to_right'];sides={}
 for side in ['left','right']:
  sides[side]=[]
  for x in a.findall(side):
   m=x.find('Compound');ck(i+':unit-unlocated:'+m.get('frameid'),x.find('coefficient') is None and x.find('compartment') is None)
   sides[side].append({'native':'META:'+m.get('frameid'),'chebi':materials['META:'+m.get('frameid')]['chebi'],'coefficient':1})
 selected_sides={'inputs':sides['right'] if layouts[frame]=='R2L' else sides['left'],'outputs':sides['left'] if layouts[frame]=='R2L' else sides['right']}
 actual={'inputs':rside(NS+selected,'substrates'),'outputs':rside(NS+selected,'products')}
 for side in ['inputs','outputs']:
  ck(i+':exact-rhea-'+side,collections.Counter((x['chebi'],x['coefficient']) for x in selected_sides[side])==collections.Counter((x['chebi'],x['coefficient']) for x in actual[side]))
  for x in actual[side]:ck(i+':rhea-unlocated:'+x['chebi'],x['location']==[])
 atom={};charge=0
 for side,sgn in [('inputs',-1),('outputs',1)]:
  for x in selected_sides[side]:
   m=materials[x['native']];charge+=sgn*m['native_charge']
   for atomkey,cnt in formula(m['native_formula']).items():atom[atomkey]=atom.get(atomkey,0)+sgn*cnt
 ck(i+':balanced',charge==0 and all(v==0 for v in atom.values()),{'charge_delta':charge,'element_delta':atom})
 ck(i+':native-id-fallback',len(a.findall('common-name'))==0)
 reactions[i]={'native_direction':a.findtext('reaction-direction'),'native_common_name_count':0,'recommended_label':frame,'label_origin':'native_frame_id','pathway_traversal':layouts[frame],'native_sides':sides,'selected_sides':selected_sides,'native_ec_number':a.findtext('ec-number'),'native_xrefs':xs,'rhea_family':family,'rhea_selected_direction':selected,'rhea_selected_equation':one(NS+selected,'equation'),'rhea_status':one(NS+selected,'status'),'rhea_inputs_outputs':actual,'rhea_disposition':'exact chemical species and unit stoichiometry; directional quartet selected separately from native own reversible statement','mnx_properties':mnx[xs['METANETX-RXN']]['props'],'mnx_disposition':'same concrete chemical equation after independent 14-compound structural resolution; MNXD1 is a generic model compartment, not localization; equal-direction rendering does not replace native direction','kegg_disposition':'same named transformation at KEGG representation; exact charged reaction alias withheld because chemical protonation and/or hydrogen coefficients differ or are not independently stereochemically certified'}
ck('five-source-reactions',len(reactions)==5);ck('22-material-occurrences',sum(len(v) for d in reactions.values() for v in d['native_sides'].values())==22)
save('reaction-identity-assessment.json',reactions)
# Native root versus independently acquired EcoCyc counterpart.
root={}
for i in ['META:PWY0-1477','ECOLI:PWY0-1477']:
 a=raw[i];root[i]={'label':a.findtext('common-name'),'members':[x.get('frameid') for x in a.findall('reaction-list/Reaction')],'layouts':[{'reaction':x.find('Reaction').get('frameid'),'direction':x.findtext('direction')} for x in a.findall('reaction-layout')],'ordering':[[x.get('frameid') for x in z.findall('.//Reaction')] for z in a.findall('reaction-ordering')],'species':[x.get('frameid') for x in a.findall('species/Organism')],'source_pgdb':E.tostring(E.parse(R/proj[i]['path']).getroot().find('metadata/PGDB'),encoding='unicode')}
ck('EcoCyc-five-equivalent-members',root['META:PWY0-1477']['members']==root['ECOLI:PWY0-1477']['members']);ck('EcoCyc-equivalent-layout',root['META:PWY0-1477']['layouts']==root['ECOLI:PWY0-1477']['layouts']);ck('EcoCyc-equivalent-order',root['META:PWY0-1477']['ordering']==root['ECOLI:PWY0-1477']['ordering'])
root['disposition']='Same five-member route and selected topology, independently verified counterpart. EcoCyc PGDB is MG1655-specific; MetaCyc direct species include MG1655 and LT2. Retain native MetaCyc root; no unconditional exact cross-species pathway mapping is proposed.'
save('root-counterpart-assessment.json',root)
taxa=[]
for i in ['511145','99287']:
 a=raw['META:TAX-'+i];b=E.parse(R/'originals'/f'NCBI-TAX-{i}.xml').getroot().find('Taxon'); ck('taxon:'+i+':issuer-id',b.findtext('TaxId')==i);ck('taxon:'+i+':native-link',any(x.findtext('dblink-db')=='NCBI-TAXONOMY-DB' and x.findtext('dblink-oid')==i for x in a.findall('dblink')))
 taxa.append({'ncbi_id':i,'native_common_name':a.findtext('common-name'),'native_strain_name':a.findtext('strain-name'),'native_rank':a.findtext('rank'),'native_parent':a.find('parent/Organism').get('frameid'),'ncbi_scientific_name':b.findtext('ScientificName'),'ncbi_rank':b.findtext('Rank'),'ncbi_parent':b.findtext('ParentTaxId'),'ncbi_other_names':E.tostring(b.find('OtherNames'),encoding='unicode'),'disposition':'Exact issuer strain identity; native strain rank and NCBI no-rank distinction retained' if i=='511145' else 'Exact issuer strain identity; native species label alone is insufficient without strain/subspecies context'})
save('direct-taxon-assessment.json',taxa)
save('structural-checks.json',{'checks':checks,'count':len(checks),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)})
print(json.dumps({'checks':len(checks),'materials':len(materials),'source_reactions':len(reactions),'taxa':len(taxa),'native_smiles_conflicts':[i for i,x in materials.items() if x['native_cml_smiles_placeholder_conflict']]},indent=2))
