"""Independent finite source checks; never imports author helpers or writes inputs."""

import collections
import datetime
import html.parser
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PACKET = Path("/private/tmp/pathwaymech-next-272-core-identity-preparation")
ORIG = PACKET / "originals"
checks = []


def check(name, condition, observed=None):
    checks.append({"check": name, "pass": bool(condition), "observed": observed})


def formula(s):
    tokens = re.findall(r"([A-Z][a-z]?)(\d*)", s.replace(" ", ""))
    return {k: int(v or 1) for k, v in tokens}


class Tables(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self.row = None
        self.cell = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.row = []
        if tag in ("th", "td"):
            self.cell = []

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)

    def handle_endtag(self, tag):
        if tag in ("th", "td") and self.cell is not None:
            if self.row is not None:
                self.row.append(" ".join(" ".join(self.cell).split()))
            self.cell = None
        if tag == "tr" and self.row is not None:
            self.rows.append(self.row)
            self.row = None


def table(path):
    t = Tables()
    t.feed(path.read_text())
    return {r[0]: r[1] for r in t.rows if len(r) == 2}


def native(name, kind):
    path = ORIG / name
    tree = ET.parse(path).getroot()
    entries = tree.findall(kind)
    check(name + " one direct issued object", len(entries) == 1)
    e = entries[0]
    check(name + " issuing envelope", tree.findtext("metadata/query") == e.get("ID"))
    check(name + " full object", e.get("detail") == "full")
    check(
        name + " native org/frame identity", e.get("ID") == e.get("orgid") + ":" + e.get("frameid")
    )
    return e


materials = {}
native_own = {}
projections = json.loads((PACKET / "results/native-own-slot-projections.json").read_text())
for key, projection in projections.items():
    path = PACKET / projection["path"]
    e = native(path.name, projection["native_type"])
    native_own[key] = e
    check(key + " own slot count", len(e) == projection["own_slot_count"])
    check(
        key + " all own slots exact",
        [ET.tostring(c, encoding="unicode") for c in e] == [s["xml"] for s in projection["slots"]],
    )
check(
    "23 native objects and 583 direct own slots",
    len(native_own) == 23 and sum(map(len, native_own.values())) == 583,
)

for e in native_own.values():
    if e.tag != "Compound":
        continue
    frame = e.get("frameid")
    xrefs = {x.findtext("dblink-db"): x.findtext("dblink-oid") for x in e.findall("dblink")}
    chebi = json.loads((ORIG / ("CHEBI-" + xrefs["CHEBI"] + ".json")).read_text())
    mol = e.find("cml/molecule")
    f = formula(mol.find("formula").get("concise"))
    charge = int(mol.get("formalCharge", "0"))
    check(frame + " ChEBI issuer identity", chebi["chebi_accession"] == "CHEBI:" + xrefs["CHEBI"])
    check(
        frame + " concrete molecule",
        e.get("class") != "true" and chebi["default_structure"]["is_r_group"] is False,
    )
    check(
        frame + " exact InChI", e.findtext("inchi") == chebi["default_structure"]["standard_inchi"]
    )
    check(
        frame + " exact InChIKey",
        e.findtext("inchi-key").removeprefix("InChIKey=")
        == chebi["default_structure"]["standard_inchi_key"],
    )
    check(
        frame + " formula and charge",
        f == formula(chebi["chemical_data"]["formula"])
        and charge == chebi["chemical_data"]["charge"],
    )
    # Select independently by the issuer molecular structure, not by the author row.
    candidates = []
    for p in ORIG.glob("MNX-MNXM*.html"):
        props = table(p)
        if props.get("InChI") == e.findtext("inchi"):
            candidates.append((p, props))
    check(frame + " one selected MNX concrete structure", len(candidates) == 1)
    p, props = candidates[0]
    check(
        frame + " MNX formula/charge/key",
        formula(props["formula"]) == f
        and int(props["global charge"]) == charge
        and props["InChIKey"] == e.findtext("inchi-key").removeprefix("InChIKey="),
    )
    materials[frame] = {
        "chebi": chebi["chebi_accession"],
        "formula": f,
        "charge": charge,
        "mnx": p.stem.removeprefix("MNX-"),
        "native_smiles": [s.text for s in mol.findall("string[@title='smiles']")],
        "native_inchi": e.findtext("inchi"),
        "mnx_standardized_SMILES": props.get("SMILES (mnx)"),
    }
check("14 concrete materials", len(materials) == 14)
placeholder = {
    k
    for k, v in materials.items()
    if any("[R]" in s or "*" in s or "[a purine base]" in s for s in v["native_smiles"])
}
check(
    "five generic native SMILES conflicts",
    placeholder == {"ACETALD", "ATP", "ETHANOL-AMINE", "NAD", "NADH"},
    sorted(placeholder),
)

root = native_own["META:PWY0-1477"]
eco = native_own["ECOLI:PWY0-1477"]
members = [x.get("frameid") for x in root.findall("reaction-list/Reaction")]
directions = {
    x.find("Reaction").get("frameid"): x.findtext("direction")
    for x in root.findall("reaction-layout")
}
orders = [
    (x.find("predecessor-reactions/Reaction").get("frameid"), x.find("Reaction").get("frameid"))
    for x in root.findall("reaction-ordering")
]
check(
    "native five-member exact route",
    set(members)
    == {
        "ETHAMLY-RXN",
        "ACETALD-DEHYDROG-RXN",
        "PHOSACETYLTRANS-RXN",
        "ACETATEKIN-RXN",
        "ALCOHOL-DEHYDROG-RXN",
    },
)
check(
    "both branches and all four orders",
    set(orders)
    == {
        ("ETHAMLY-RXN", "ALCOHOL-DEHYDROG-RXN"),
        ("ETHAMLY-RXN", "ACETALD-DEHYDROG-RXN"),
        ("ACETALD-DEHYDROG-RXN", "PHOSACETYLTRANS-RXN"),
        ("PHOSACETYLTRANS-RXN", "ACETATEKIN-RXN"),
    },
)
check(
    "ECOLI same member order",
    members == [x.get("frameid") for x in eco.findall("reaction-list/Reaction")],
)
check(
    "ECOLI same layout directions",
    directions
    == {
        x.find("Reaction").get("frameid"): x.findtext("direction")
        for x in eco.findall("reaction-layout")
    },
)
check(
    "ECOLI same topology",
    orders
    == [
        (x.find("predecessor-reactions/Reaction").get("frameid"), x.find("Reaction").get("frameid"))
        for x in eco.findall("reaction-ordering")
    ],
)
check(
    "direct strain associations distinct from bacteria range",
    {x.get("frameid") for x in root.findall("species/Organism")} == {"TAX-511145", "TAX-99287"}
    and [x.get("frameid") for x in root.findall("taxonomic-range/Organism")] == ["TAX-2"],
)
reactions = {}
for frame in members:
    e = native_own["META:" + frame]
    check(frame + " own names absent", len(e.findall("common-name")) == 0)
    check(
        frame + " source direction retained",
        e.findtext("reaction-direction")
        == ("LEFT-TO-RIGHT" if frame == "ETHAMLY-RXN" else "REVERSIBLE"),
    )
    sides = {}
    for side in ("left", "right"):
        items = e.findall(side)
        for i, x in enumerate(items):
            check(
                frame + f" {side}[{i + 1}] exactly one material and no coefficient/location",
                len(x) == 1
                and x[0].tag == "Compound"
                and not x.attrib
                and not x[0].attrib.keys() - {"resource", "orgid", "frameid"},
            )
        sides[side] = [x[0].get("frameid") for x in items]
    atom_balance = collections.Counter()
    charge_balance = 0
    for side, sign in [("left", -1), ("right", 1)]:
        for material in sides[side]:
            for atom, count in materials[material]["formula"].items():
                atom_balance[atom] += count * sign
            charge_balance += materials[material]["charge"] * sign
    check(
        frame + " independently balanced atoms",
        all(v == 0 for v in atom_balance.values()),
        dict(atom_balance),
    )
    check(frame + " independently balanced charge", charge_balance == 0, charge_balance)
    selected = (
        sides if directions[frame] == "L2R" else {"left": sides["right"], "right": sides["left"]}
    )
    reactions[frame] = {
        "source_direction": e.findtext("reaction-direction"),
        "traversal": directions[frame],
        "native_sides": sides,
        "selected_sides": selected,
        "ec": e.findtext("ec-number").strip(),
        "xrefs": {x.findtext("dblink-db"): x.findtext("dblink-oid") for x in e.findall("dblink")},
    }
check(
    "22 material occurrences",
    sum(len(v["native_sides"][side]) for v in reactions.values() for side in ("left", "right"))
    == 22,
)
check("kinase source annotation retained", reactions["ACETATEKIN-RXN"]["ec"] == "EC-2.7.2.15")

# Exact taxon issuer object, no descendant match or name-based taxon broadening.
taxa = {}
for accession, parent, rank in [("511145", "83333", "no rank"), ("99287", "90371", "strain")]:
    taxon = ET.parse(ORIG / ("NCBI-TAX-" + accession + ".xml")).getroot().find("Taxon")
    native_taxon = native_own["META:TAX-" + accession]
    check(accession + " exact NCBI taxon", taxon.findtext("TaxId") == accession)
    check(
        accession + " parent and rank",
        taxon.findtext("ParentTaxId") == parent and taxon.findtext("Rank") == rank,
    )
    check(accession + " native strain rank retained", native_taxon.findtext("rank") == "strain")
    check(
        accession + " native own parent",
        native_taxon.find("parent/Organism").get("frameid") == "TAX-" + parent,
    )
    taxa[accession] = {"name": taxon.findtext("ScientificName"), "rank": rank, "parent": parent}
uniprot = json.loads((ORIG / "UniProt-P0AEJ6-scope-context.json").read_text())
check(
    "P0AEJ6 K12 scope",
    uniprot["primaryAccession"] == "P0AEJ6" and uniprot["organism"]["taxonId"] == 83333,
)
caution = uniprot["comments"][10]
check(
    "CPZ-55 caution qualified may",
    caution["commentType"] == "CAUTION"
    and "may" in caution["texts"][0]["value"]
    and "CPZ-55" in caution["texts"][0]["value"],
)
check(
    "CPZ-55 curator inference attribution",
    caution["texts"][0]["evidences"]
    == [{"evidenceCode": "ECO:0000305", "source": "PubMed", "id": "9278503"}],
)
neutral = json.loads((ORIG / "CHEBI-16000.json").read_text())
check(
    "neutral ethanolamine is distinct conjugate base",
    neutral["chemical_data"]["charge"] == 0
    and formula(neutral["chemical_data"]["formula"]) == {"C": 2, "H": 7, "N": 1, "O": 1}
    and any(
        x["relation_type"] == "is conjugate base of" and x["final_id"] == 57603
        for x in neutral["ontology_relations"]["outgoing_relations"]
    ),
)

result = {
    "utc": datetime.datetime.now(datetime.UTC).isoformat(),
    "checks": checks,
    "all_passed": all(c["pass"] for c in checks),
    "materials": materials,
    "reactions": reactions,
    "taxa": taxa,
    "caution": caution,
}
(ROOT / "core-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            "checks": len(checks),
            "all_passed": result["all_passed"],
            "failed": [c for c in checks if not c["pass"]],
        },
        indent=2,
    )
)
