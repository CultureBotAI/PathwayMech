"""Independent Rhea source replay and equation comparison, bounded to five families."""

import collections
import csv
import gzip
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent
P = Path("/private/tmp/pathwaymech-next-272-core-identity-preparation")
core = json.loads((ROOT / "core-results.json").read_text())
binding = json.loads((P / "results/rhea-issuer-bounded-complete.json").read_text())
checks = []


def check(name, condition, value=None):
    checks.append({"check": name, "pass": bool(condition), "observed": value})


compressed = Path(binding["source_file"]).read_bytes()
check(
    "original Rhea compressed source digest",
    hashlib.sha256(compressed).hexdigest() == binding["source_sha256"],
)
raw = gzip.decompress(compressed)
fragments = collections.defaultdict(list)
header = (P / "originals/rhea-selected-envelope-header.txt").read_bytes()
graph = collections.defaultdict(list)
RDF = "{http://www.w3.org/1999/02/22-rdf-syntax-ns#}"
RH = "{http://rdf.rhea-db.org/}"
subjects = set(binding["complete_selected_statements"])
scan_count = 0
for m in re.finditer(
    rb'<rdf:Description\b[^>]*rdf:about="([^"]+)"[^>]*>.*?</rdf:Description>\n?', raw, re.S
):
    scan_count += 1
    uri = m[1].decode()
    if uri in subjects:
        fragments[uri].append(m[0])
check("complete source description and byte count", scan_count == 326097 and len(raw) == 206616941)
check(
    "66 selected subjects and 88 descriptions",
    len(fragments) == 66 and sum(map(len, fragments.values())) == 88,
)
for row in binding["fragment_bindings"]:
    path = P / row["path"]
    data = path.read_bytes()
    check(
        "fragment exact original bytes " + row["path"],
        data == raw[row["decoded_source_start"] : row["decoded_source_end"]]
        and data in fragments[row["uri"]],
    )
    e = ET.fromstring(header + data + b"</rdf:RDF>")[0]
    check("fragment subject " + row["path"], e.get(RDF + "about") == row["uri"])
    graph[row["uri"]].extend(list(e))
for uri in subjects:
    check(
        "all repeated descriptions retained " + uri,
        len(fragments[uri]) == sum(x["uri"] == uri for x in binding["fragment_bindings"]),
    )


def values(uri, predicate):
    return [x.get(RDF + "resource") or x.text for x in graph[uri] if x.tag == RH + predicate]


equations = {}
for frame, r in core["reactions"].items():
    native_rhea = r["xrefs"]["RHEA"]
    rows = list(
        csv.DictReader(
            (P / "originals/rhea-directions-selected.tsv").read_text().splitlines(), delimiter="\t"
        )
    )
    family = [row for row in rows if native_rhea in row.values()][0]
    selected_key = "RHEA_ID_LR" if r["traversal"] == "L2R" else "RHEA_ID_RL"
    uri = "http://rdf.rhea-db.org/" + family[selected_key]
    equation = {}
    for pred, side in [("substrates", "left"), ("products", "right")]:
        sides = values(uri, pred)
        check(frame + " one Rhea " + pred, len(sides) == 1)
        side_uri = sides[0]
        participants = values(side_uri, "contains")
        count_predicates = [
            x
            for x in graph[side_uri]
            if x.tag.startswith(RH + "contains") and x.tag != RH + "contains"
        ]
        coefficients = {
            x.get(RDF + "resource"): int(x.tag.removeprefix(RH + "contains"))
            for x in count_predicates
        }
        check(frame + " complete coefficients " + side, set(coefficients) == set(participants))
        terms = []
        for participant in participants:
            compounds = values(participant, "compound")
            check(participant + " one compound", len(compounds) == 1)
            c = compounds[0]
            chebi = values(c, "accession")[0]
            check(participant + " no explicit compartment", not values(participant, "location"))
            check(participant + " integer unit coefficient", coefficients[participant] == 1)
            material = [v for v in core["materials"].values() if v["chebi"] == chebi][0]
            check(participant + " same charge", int(values(c, "charge")[0]) == material["charge"])
            terms.append((chebi, coefficients[participant]))
        expected = [(core["materials"][m]["chebi"], 1) for m in r["selected_sides"][side]]
        check(
            frame + " exact Rhea species/coefficient " + side,
            collections.Counter(terms) == collections.Counter(expected),
            terms,
        )
        equation[side] = terms
    check(
        frame + " approved selected reaction",
        values(uri, "status") == ["http://rdf.rhea-db.org/Approved"],
    )
    equations[frame] = {"selected_rhea": uri, "equation": equation}

result = {
    "checks": checks,
    "all_passed": all(x["pass"] for x in checks),
    "equations": equations,
    "source_scan": {
        "bytes": len(raw),
        "descriptions": scan_count,
        "selection_subjects": len(subjects),
    },
}
(ROOT / "alias-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            "checks": len(checks),
            "all_passed": result["all_passed"],
            "failed": [c for c in checks if not c["pass"]],
        },
        indent=2,
    )
)
