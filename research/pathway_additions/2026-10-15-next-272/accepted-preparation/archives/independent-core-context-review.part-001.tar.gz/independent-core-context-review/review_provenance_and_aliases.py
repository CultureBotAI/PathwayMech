"""Read-only packet provenance and secondary equation comparisons."""

import collections
import hashlib
import html
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
P = Path("/private/tmp/pathwaymech-next-272-core-identity-preparation")
checks = []


def check(name, condition, observed=None):
    checks.append({"check": name, "pass": bool(condition), "observed": observed})


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fields(path):
    result = {}
    current = None
    for line in path.read_text().splitlines():
        key = line[:12].strip()
        if key:
            current = key
            result.setdefault(current, [])
        if current:
            result[current].append(line[12:].strip())
    return {key: " ".join(value) for key, value in result.items()}


def formula(s):
    return {k: int(n or 1) for k, n in re.findall(r"([A-Z][a-z]?)(\d*)", s)}


def table(path):
    text = path.read_text()
    rows = re.findall(r"<tr\b[^>]*>(.*?)</tr>", text, re.S)
    result = {}
    for row in rows:
        cells = re.findall(r"<t[dh]\b[^>]*>(.*?)</t[dh]>", row, re.S)
        if len(cells) == 2:
            value = re.sub(r"<br\s*/?>", "\n", cells[1])
            result[html.unescape(re.sub(r"<[^>]+>", "", cells[0])).strip()] = html.unescape(
                re.sub(r"<[^>]+>", "", value)
            ).strip()
    return result


core = json.loads((ROOT / "core-results.json").read_text())
mnx_lookup = {v["mnx"]: k for k, v in core["materials"].items()}
mnx_results = []
kegg_results = []
for frame, reaction in core["reactions"].items():
    accession = reaction["xrefs"]["METANETX-RXN"]
    props = table(P / "originals" / ("MNX-" + accession + ".html"))
    eq = props["equation"].splitlines()[-1].strip()
    sides = eq.split("=")
    check(frame + " MNX one equality", len(sides) == 2)
    terms = []
    for side in sides:
        values = re.findall(r"(\d+) (MNXM\d+)@(MNXD\d+)", side)
        check(
            frame + " MNX unit generic compartment",
            all(int(n) == 1 and compartment == "MNXD1" for n, mid, compartment in values),
        )
        terms.append(collections.Counter(mnx_lookup[mid] for n, mid, compartment in values))
    expected = [collections.Counter(reaction["native_sides"][s]) for s in ("left", "right")]
    orientation = (
        "same" if terms == expected else "reversed" if terms[::-1] == expected else "different"
    )
    check(
        frame + " MNX equation matches source species and coefficients", orientation != "different"
    )
    # Deprecated endpoint resolution is recorded, not converted into a new exact native CURIE.
    mnx_results.append(
        {
            "native": frame,
            "requested": accession,
            "served_MNX_ID": props["MNX_ID"],
            "native_side_orientation": orientation,
            "equation": eq,
            "deprecation_rows": {
                k: v for k, v in props.items() if k.startswith("MNXR") and "deprecated" in v
            },
        }
    )
    kegg_id = reaction["xrefs"]["LIGAND-RXN"]
    kegg = fields(P / "originals" / ("KEGG-" + kegg_id + ".txt"))
    check(frame + " KEGG issued identity", kegg["ENTRY"].split()[0] == kegg_id)
    parts = kegg["EQUATION"].split("<=>")
    check(frame + " KEGG explicitly reversible", len(parts) == 2)
    chemical_rows = []
    for side in parts:
        ids = re.findall(r"C\d{5}", side)
        for cid in ids:
            compound = fields(P / "originals" / ("KEGG-" + cid + ".txt"))
            check(frame + " KEGG compound identity " + cid, compound["ENTRY"].split()[0] == cid)
            chemical_rows.append(
                {"id": cid, "name": compound["NAME"], "formula": compound["FORMULA"]}
            )
    kegg_results.append(
        {"native": frame, "id": kegg_id, "equation": kegg["EQUATION"], "compounds": chemical_rows}
    )

neutral = fields(P / "originals/KEGG-C00189.txt")
ammonia = fields(P / "originals/KEGG-C00014.txt")
check(
    "KEGG ethanolamine/ammonia microstates differ",
    formula(neutral["FORMULA"]) == {"C": 2, "H": 7, "N": 1, "O": 1}
    and formula(ammonia["FORMULA"]) == {"N": 1, "H": 3},
)
check(
    "KEGG phosphate differs",
    formula(fields(P / "originals/KEGG-C00009.txt")["FORMULA"]) == {"H": 3, "P": 1, "O": 4},
)
for accession, name, equation, comment in [
    ("2.7.2.1", "acetate kinase", "ATP + acetate = ADP + acetyl phosphate", "Requires Mg"),
    (
        "2.7.2.15",
        "propionate kinase",
        "ATP + propanoate = ADP + propanoyl phosphate",
        "Acetate can also act as a substrate.",
    ),
]:
    raw = (P / "originals" / ("IUBMB-EC-" + accession + ".html")).read_text()
    text = html.unescape(re.sub("<[^>]+>", "", raw))
    check(
        "IUBMB " + accession + " exact designation/equation/specificity",
        "EC " + accession in text
        and "Accepted name: " + name in text
        and equation in text
        and comment in text,
    )

all_files = [p for p in P.rglob("*") if p.is_file()]
by_hash = collections.defaultdict(list)
for path in all_files:
    by_hash[digest(path)].append(str(path.relative_to(P)))
receipts = []
for path in sorted((P / "receipts").glob("*.json")):
    receipt = json.loads(path.read_text())
    if "sha256" in receipt:
        matches = by_hash.get(receipt["sha256"], [])
        check("receipt has exact retained body " + path.name, bool(matches), matches)
        check(
            "receipt byte count " + path.name,
            all((P / match).stat().st_size == receipt["bytes"] for match in matches),
        )
    receipts.append(
        {
            "receipt": str(path.relative_to(P)),
            "status": receipt.get("status"),
            "has_body_digest": "sha256" in receipt,
            "error": receipt.get("error"),
        }
    )
reuse = json.loads((P / "results/reuse-bindings.json").read_text())["entries"]
two_reused = []
for row in reuse:
    if row["path"] in ("originals/META-ACETALD.xml", "originals/META-Pi.xml"):
        source = Path(row["source"])
        check("reused retained original " + row["path"], digest(P / row["path"]) == row["sha256"])
        check(
            "reused physical repository owner " + row["path"],
            source.is_file() and digest(source) == row["sha256"],
        )
        supporting = []
        for receipt_path in (P / "receipts").glob("*.json"):
            receipt = json.loads(receipt_path.read_text())
            if receipt.get("sha256") == row["sha256"]:
                supporting.append(str(receipt_path.relative_to(P)))
        check("no invented acquisition receipt in finite packet " + row["path"], not supporting)
        two_reused.append(
            {
                "path": row["path"],
                "source": row["source"],
                "source_exists_now": source.is_file(),
                "sha256": row["sha256"],
                "matching_receipts_in_entire_packet": supporting,
            }
        )

result = {
    "checks": checks,
    "all_passed": all(c["pass"] for c in checks),
    "mnx_equations": mnx_results,
    "kegg_equations": kegg_results,
    "receipts": receipts,
    "two_reused_without_http_receipts": two_reused,
    "scope": (
        "All physical files including ignored/hidden hashed; only packet receipts searched "
        "for missing historical body receipts; no global absence claim."
    ),
}
(ROOT / "provenance-and-alias-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            "checks": len(checks),
            "all_passed": result["all_passed"],
            "failed": [c for c in checks if not c["pass"]],
        },
        indent=2,
    )
)
