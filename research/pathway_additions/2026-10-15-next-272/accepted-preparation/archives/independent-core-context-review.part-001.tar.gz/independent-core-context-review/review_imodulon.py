"""Independent response/receipt checks and unchanged parser fixture replay."""

import hashlib
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
P = Path("/private/tmp/pathwaymech-next-272-imodulondb-preparation")
checks = []


def check(name, condition, observed=None):
    checks.append({"check": name, "pass": bool(condition), "observed": observed})


def load(name):
    return json.loads((P / name).read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


datasets = load("raw-datasets.body.json")
keys = [entry["id"] + "/" + d for entry in datasets for d in entry["datasets"]]
check(
    "20 returned organisms and 28 dataset keys",
    len(datasets) == 20 and len(keys) == 28 and len(set(keys)) == 28,
)
selected_keys = [k for k in keys if k.startswith(("e_coli/", "s_enterica/"))]
check(
    "six matching keys",
    set(selected_keys)
    == {
        "e_coli/modulome",
        "e_coli/precise1k",
        "e_coli/precise278",
        "e_coli/precise815",
        "e_coli/precise_mg1655",
        "s_enterica/core",
    },
)
rendered_datasets = (P / "live-datasets.stdout").read_text()
for key in keys:
    check("rendered dataset " + key, "`" + key + "`" in rendered_datasets)
receipts = []
rendered_tables = {}
for key in selected_keys:
    for query in ("eut", "ethanolamine"):
        stem = key.replace("/", "-") + "-" + query
        receipt = load(stem + ".receipt.json")
        command = receipt["command"]
        check(
            stem + " actual command",
            command[1:5] == ["imodulondb", "--timeout", "30", "search"]
            and command[command.index("--organism") + 1] == key.split("/")[0]
            and command[command.index("--dataset") + 1] == key.split("/")[1]
            and command[command.index("--query") + 1] == query,
        )
        check(
            stem + " terminal receipt",
            bool(receipt["finished_utc"]) and receipt["finished_utc"] >= receipt["started_utc"],
        )
        for stream in ("stdout", "stderr"):
            check(
                stem + " " + stream + " digest",
                digest(P / (stem + "." + stream)) == receipt[stream + "_sha256"],
            )
        text = (P / (stem + ".stdout")).read_text()
        if receipt["exit_code"] == 0:
            rows = [x for x in text.splitlines() if x.startswith("| `")]
            check(stem + " ten returned gene rows", len(rows) == 10)
            check(
                stem + " bounded no component matches",
                "- iModulons: 0" in text
                and not any(
                    x.startswith("| `")
                    for x in text.split("## iModulons")[1].split("## Genes")[0].splitlines()
                ),
            )
            rendered_tables[stem] = rows
        receipts.append({"key": key, "query": query, "exit_code": receipt["exit_code"]})
check(
    "eleven success one real failure",
    sum(r["exit_code"] == 0 for r in receipts) == 11
    and [(r["key"], r["query"], r["exit_code"]) for r in receipts if r["exit_code"] != 0]
    == [("e_coli/modulome", "ethanolamine", 2)],
)
for stem in ["raw-datasets", "raw-e_coli-modulome-76-genes", "raw-e_coli-modulome-ethanolamine"]:
    receipt = load(stem + ".receipt.json")
    path = P / (stem + ".body.json")
    check(
        stem + " exact successful API body",
        receipt["http_status"] == 200
        and receipt["sha256"] == digest(path)
        and receipt["bytes"] == path.stat().st_size,
    )

search = load("raw-e_coli-modulome-ethanolamine.body.json")
check(
    "raw failed search has finite rows",
    len(search["genes"]) == 10 and len(search["imodulons"]) == 1,
)
component = search["imodulons"][0]
check(
    "component 76 context",
    component["k"] == 76
    and component["name"] == "Fermentation"
    and component["regulator"] is None
    and component["function"] == "Fermentation-related hydrogenase/ethanolamine/lactate catabolism",
)

# Use copied installed source as a read-only pure parser. No network and no repair.
spec = importlib.util.spec_from_file_location(
    "review_imodulondb", P / "runner-source/imodulondb.py"
)
adapter = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = adapter
spec.loader.exec_module(adapter)
try:
    adapter.load_search_results(search)
    observed_error = None
except adapter.ImodulonDBError as exc:
    observed_error = str(exc)
check(
    "unchanged parser reproduces exact real failure",
    observed_error == (P / "e_coli-modulome-ethanolamine.stderr").read_text().strip(),
    observed_error,
)
table = load("raw-e_coli-modulome-76-genes.body.json")
parsed = adapter.load_imodulon_gene_table(table)
check(
    "summary parser accepts thirteen raw rows",
    len(parsed.genes) == 13 and len(parsed.in_imodulon) == 13 and parsed.threshold == 0.105120952,
)
check(
    "all rows retain dataset scope",
    all(g["organism"] == "e_coli" and g["dataset"] == "modulome" for g in table["genes"]),
)
check("all rows marked members", all(g["in_imodulon"] is True for g in table["genes"]))
check(
    "both signs present",
    any(g["weight"] < 0 for g in table["genes"]) and any(g["weight"] > 0 for g in table["genes"]),
)
names = {g["gene_name"]: g for g in table["genes"]}
expected = {
    "eutJ": ("b2454", 0.205927273, "P77277"),
    "eutG": ("b2453", 0.20032519, "P76553"),
    "eutH": ("b2452", 0.156945327, "P76552"),
    "eutA": ("b2451", 0.155496541, "P76551"),
    "ackA": ("b2296", -0.171109794, "P0A6A3"),
}
summary = (P / "e_coli-modulome-summary-76.stdout").read_text()
for name, (locus, weight, accession) in expected.items():
    row = names[name]
    check(
        name + " exact identifier and signed weight",
        row["gene_id"] == locus
        and row["weight"] == weight
        and row["uniprot_id"] == accession
        and row["string_id"] == "511145." + locus,
        row["weight"],
    )
for row in table["genes"]:
    check(
        row["gene_id"] + " summary rounded signed value",
        f"| `e_coli/modulome/{row['gene_id']}` | {row['gene_name']} | "
        f"{row['weight']:.6g} | {row['uniprot_id']} |"
        in summary,
    )
check(
    "summary successful terminal receipt",
    load("e_coli-modulome-summary-76.receipt.json")["exit_code"] == 0,
)
check(
    "historical Salmonella annotation preserved",
    "putative transport protein" in (P / "s_enterica-core-eut.stdout").read_text(),
)
for binding in load("runner-source-binding.json")["files"]:
    check(
        "copied runner original " + binding["copied_path"],
        digest(P / binding["copied_path"])
        == binding["sha256"]
        == digest(Path(binding["source_path"])),
    )
result = {
    "all_passed": all(c["pass"] for c in checks),
    "checks": checks,
    "datasets": keys,
    "searches": receipts,
    "returned_gene_rows": table["genes"],
    "component": component,
    "parsed_error": observed_error,
    "finite_rendered_search_rows": rendered_tables,
}
(ROOT / "imodulon-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            "checks": len(checks),
            "all_passed": result["all_passed"],
            "failed": [x for x in checks if not x["pass"]],
        },
        indent=2,
    )
)
