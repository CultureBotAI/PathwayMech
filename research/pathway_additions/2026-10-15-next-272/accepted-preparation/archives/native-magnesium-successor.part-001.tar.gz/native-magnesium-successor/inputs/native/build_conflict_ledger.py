from pathlib import Path
import json

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
n = json.loads((R / "results/all-native-projections.json").read_text()) + json.loads(
    (R / "results/ecoli-native-projections.json").read_text()
)
u = json.loads((R / "results/uniprot-complete-projections.json").read_text())
by = {x["attributes"]["orgid"] + ":" + x["id"]: x for x in n}
ub = {x["id"]: x for x in u}


def native(id, slots):
    x = by[id]
    return [
        {
            "source": x["source_path"],
            "sha256": x["sha256"],
            "locator": s["locator"],
            "statement": s["xml"],
        }
        for s in x["slots"]
        if s["slot"] in slots
    ]


def uni(id, types):
    x = ub[id]
    return [
        {
            "source": x["source_path"],
            "sha256": x["source_sha256"],
            "locator": "/comments/" + str(i),
            "statement": s,
        }
        for i, s in enumerate(x["comments"])
        if s["commentType"] in types
    ]


rows = []


def add(key, issue, disposition, refs, primary=None):
    rows.append(
        {
            "id": key,
            "issue": issue,
            "required_disposition": disposition,
            "source_claims": refs,
            "parallel_primary_followup": primary,
            "status": "retain_distinction_before_maintained_curation",
        }
    )


add(
    "root-boundary-direction",
    "Five native members have four ordering links and two terminal branches. Reaction direction, pathway traversal and assay direction are different fields.",
    "Preserve all five members and both ethanol/acetate branches. Do not infer a 1:1 branch flux sum. Source layout selects reverse traversal for alcohol dehydrogenase and acetate kinase, although reaction objects are reversible.",
    native("META:PWY0-1477", ["reaction-list", "reaction-ordering", "reaction-layout"])
    + native("META:ACETATEKIN-RXN", ["left", "right", "reaction-direction"])
    + native("META:ALCOHOL-DEHYDROG-RXN", ["reaction-direction"]),
)
add(
    "root-generalized-narrative",
    "Root narrative says pathway within lumen, detoxification and cofactor recycling, and calls EutE assumed while newer individual evidence differs.",
    "Retain complete narrative as source assertions, not universal experimental facts. Specific biochemical experiments and conditional shell/aldehyde phenotypes require their own access/claim tiers.",
    native("META:PWY0-1477", ["comment", "species", "taxonomic-range"]),
    "2013 PMC3697265 model and 2022 PMC9481676 access/reading are owned by primary-evidence agent. External EutBC is speculative; newer EAL/EutA structure association supports inferred lumen, not every protein localization.",
)
add(
    "acetate-kinase-ec",
    "Native acetate-kinase reaction issues EC 2.7.2.15, despite its acetate equation and EutP/Q annotation.",
    "Retain native EC assertion and independently assessed issuer conflict. Do not silently replace it in raw evidence or equate propionate-specific EC chemistry.",
    native("META:ACETATEKIN-RXN", ["common-name", "ec-number", "left", "right"])
    + uni("Q9ZFV5", ["CATALYTIC ACTIVITY"]),
)
add(
    "mg1655-route-expression",
    "Native direct species includes TAX-511145, but all seventeen K12 UniProt entries have a CPZ-55 expression caution. UniProt organism 83333 is broader than MG1655.",
    "Keep native association, strain identity and inferred expression limitation separate. Neither intact MG1655 flux nor pathway absence is established here.",
    native("META:PWY0-1477", ["species"]) + uni("P0AEJ6", ["CAUTION"]),
)
add(
    "eutbc-stoichiometry",
    "Native direct components specify six EutB and six EutC, but prose says a hexamer of (alpha beta)2 dimers.",
    "Use exact six-plus-six source slots as the issued composition; flag contradictory prose. UniProt trimer of heterotetramers agrees with six-plus-six. Do not assert independent whole EAL activity for either subunit.",
    native("META:ETHAMLY-CPLX", ["comment", "component"]) + uni("P0AEJ6", ["SUBUNIT"]),
)
add(
    "eutbc-experimental-organism",
    "Native E. coli object blends NCIB 8114 work, K12/JM109 contexts and N-terminal truncated structural preparations.",
    "Source organism ownership is not a label for every experiment. Preserve non-K12 purification and construct limitations.",
    native("META:ETHAMLY-CPLX", ["comment", "species"])
    + native("META:ETHAMLY-ENZRXN", ["evidence", "cofactor"]),
)
add(
    "eutd-assay-direction",
    "EutD source assays, genetics and expression hosts have distinct scopes. EutD is not general Pta.",
    "Keep E. coli dimeric EutD, pyruvate activation and LT2 genetic results separate. Do not call the 2004 reverse-direction assay a direct forward kinetic measurement.",
    native("META:CPLX0-7912", ["comment", "component"])
    + native("META:ENZRXN0-7425", ["reaction-direction", "evidence", "regulated-by"])
    + uni("P41790", ["FUNCTION", "SUBCELLULAR LOCATION"]),
    "Primary PMID14996820 measures AcP+CoA to AcCoA in recombinant LT2 EutD. PMID26448059 supplies forward coupled EutD acetyl-P production supporting EutP/Q assays; primary agent owns exact main-text locators.",
)
add(
    "eute-assay-scope",
    "Native LT2 activity is mutant/inference supported; E. coli native activity is unpurified heterologous yeast evidence; updated LT2 UniProt adds biochemical evidence.",
    "Do not merge species or assay tiers. LT2 EutE both ALDH/ACR directions and NAD preference are biochemical claims; reporter targeting does not by itself prove all native cargo localization.",
    native("META:ENZRXN-26159", ["evidence"])
    + native("META:ENZRXN0-8531", ["evidence"])
    + uni(
        "P41793", ["FUNCTION", "BIOPHYSICOCHEMICAL PROPERTIES", "SUBCELLULAR LOCATION"]
    ),
    "Primary PMID21803884 read by parallel owner: LT2 eutE in BL21(DE3) RIL, N-terminal His6 ~90% pure; both ALDH/ACR, no alcohol-dehydrogenase activity in tested assays. Engineered MG1655 glucose fermentation is not native eut flux.",
)
add(
    "eutg-cofactors-branch",
    "LT2 native EutG relies on conditional mutant phenotype; UniProt K12 EutG reports NADH/NADPH aldehyde assays, while LT2 cofactor/iron assignments are inferred.",
    "Retain ethanol branch, but do not transfer purified kinetics or cofactor equivalence across species. The K12-derived experiment used recombinant crude extracts and similar observed rates.",
    native("META:ENZRXN-26158", ["evidence", "comment"])
    + uni("P76553", ["FUNCTION", "BIOPHYSICOCHEMICAL PROPERTIES"])
    + uni("P41795", ["CATALYTIC ACTIVITY", "COFACTOR"]),
    "Primary PMID22731523 / PMC3439341: AL626 crude extracts, gene from JCL16/BW25113, Fig3; 25mM aldehyde, 0.2mM NAD(P)H, 37C; no native MG1655/LT2 flux claim. 2013 EutG suppression result is attributed to unpublished work.",
)
add(
    "euth-transport-microstate",
    "UniProt EutH prose suggests protonated entry, while primary title/results concern uncharged ethanolamine. Native reaction material is +1 ethanolaminium.",
    "Do not make CHEBI:57603 ethanolaminium identical to neutral CHEBI:16000, or turn conditional membrane entry into a core enzymatic reaction or direct BMC delivery.",
    uni("P41796", ["FUNCTION", "SUBCELLULAR LOCATION"])
    + native("META:ETHANOL-AMINE", ["cml", "inchi", "inchi-key"]),
    "PMID15466042 author PDF title/results are uncharged ethanolamine; abstract repeats Eth0 for both species, a typography/extraction issue preserved by primary owner. Core owner independently acquired CHEBI:16000.",
)
add(
    "compartment-location-tiers",
    "ECOLI EutA has membrane location, EutG membrane and cytosol. UniProt often assigns BMC location by similarity/inference; native compartment anatomy describes cytosol/inner membrane, not a phospholipid BMC membrane.",
    "Retain issued location slots and evidence codes. GO organelle identity is not direct evidence for every enzyme location. EutA/EAL, EutT and EutP/Q have different localization certainty.",
    native("ECOLI:G7281-MONOMER", ["location"])
    + native("ECOLI:G7283-MONOMER", ["location"])
    + native("ECOLI:CCI-CYTOSOL-GN", ["parent", "surrounded-by", "surrounds"])
    + native("ECOLI:CCI-PM-BAC-NEG-GN", ["parent", "surrounded-by", "surrounds"])
    + uni("Q9ZFV4", ["SUBCELLULAR LOCATION"]),
    "2022 PMC9481676 supports EAL/EutA association/inferred lumen; EutT inside/outside explicitly unclear. EutP/Q native source location remains unknown.",
)
add(
    "eutn-oligomer",
    "Native EutN complex coefficient6 and crystal hexamer conflict with later solution pentamer annotation.",
    "Keep preparation-specific assembly forms; do not make six-chain physiological shell vertex composition an uncontested fact.",
    native("ECOLI:CPLX0-7613", ["component"])
    + uni("P0AEJ8", ["FUNCTION", "SUBUNIT"])
    + uni("P41792", ["SUBUNIT"]),
)
add(
    "shell-cargo-constructs",
    "EutL is a trimer/pseudohexamer; EutM/S are hexamers; EutK is monomeric in solution. Pore gating, cargo reporter targeting and artificial shells are distinct evidence.",
    "Preserve tag, G39V mutation and organism/construct scope. Crystal zinc opening does not prove physiological zinc dependence or ATP/cobalamin permeability. Reporter results do not localize every full native protein.",
    native("ECOLI:CPLX0-7801", ["comment", "component"])
    + native("ECOLI:CPLX0-7835", ["component"])
    + native("ECOLI:CPLX0-7836", ["component"])
    + uni("P63746", ["FUNCTION", "SUBUNIT"])
    + uni("Q9ZFU8", ["FUNCTION", "SUBUNIT"])
    + uni("P19265", ["SUBCELLULAR LOCATION"]),
    "PMID22428024 tests LT2 EutC first19 amino acids in reporters, not first35; failed K12 EutG first19 construct is not general native EutG exclusion.",
)
add(
    "eutpq-phenotype-location",
    "EutP and EutQ both show recombinant acetate kinase activity, but conditional EutQ deletion phenotype differs. EutQ/EutM coelution and assembly proposals do not prove a native outer location.",
    "Keep anaerobic ethanolamine+tetrathionate condition, tags, GTP alternative and measured cation behavior. Do not assert universal essentiality or a proven cytosol-facing direct targeting edge.",
    native("META:STM2468-MONOMER", ["comment", "location"])
    + native("META:STM2469-MONOMER", ["comment", "location"])
    + uni("Q9ZFV5", ["FUNCTION", "SUBUNIT", "DISRUPTION PHENOTYPE"])
    + uni("P0A208", ["FUNCTION", "DISRUPTION PHENOTYPE"]),
    "PMID26448059 / PMC4857615 and PMID27063436 are separately read. C-terminal His6 EutQ coelutes with EutM; cytosol-facing interaction is an assumed model, attempted in vivo validation failed from instability/stress.",
)
add(
    "eutt-cofactor-chemistry",
    "Root older EC 2.5.1.17 contrasts native dedicated EutT EC2.5.1.154; RXN-19336 writes two protons while UniProt/Rhea equation writes three. Native component coefficient is OMITTED, not an explicit homodimer.",
    "Keep ancillary EutT outside five members; preserve exact equation/missing coefficient and source class participants. UniProt dimer evidence must not be misrepresented as an explicit native coefficient.",
    native("META:PWY0-1477", ["comment"])
    + native("META:RXN-19336", ["ec-number", "left", "right"])
    + native("META:CPLX-9275", ["component"])
    + uni("Q9ZFV4", ["CATALYTIC ACTIVITY", "SUBUNIT"]),
)
add(
    "eutt-cobinamide-contradiction",
    "Native EutT says it does not adenosylate cob(I)inamide; UniProt function contains both inactivity and less-efficient activity, and a cobinamide reaction.",
    "Unresolved specificity conflict. Retain all issued statements; do not choose the convenient sentence or add cobinamide to the native root chemistry.",
    native("META:CPLX-9275", ["comment"])
    + uni("Q9ZFV4", ["FUNCTION", "CATALYTIC ACTIVITY"]),
    "PMID16636051 remains abstract-only after bounded access attempts, so specificity assays cannot resolve the contradiction in this preparation.",
)
add(
    "eutt-metal-donor-handoff",
    "Native EutT narrative mixes EutT experiments with CobA/PduO mechanism and proposed EAL cofactor delivery. FeII maximal activity does not establish exclusive physiological iron dependence; generic reduced flavoproteins do not identify an in vivo donor.",
    "Separate Zn copurification, FeII reconstituted maximum, other metal stimulation, assay reductant and proposed physiological role. No exact donor sequence or direct EutT-to-EAL handoff edge is accepted.",
    native("META:CPLX-9275", ["comment"])
    + native("META:ENZRXN-26161", ["cofactor", "evidence"])
    + native("META:Reduced-Flavoproteins", ["parent", "common-name"])
    + uni("Q9ZFV4", ["COFACTOR", "FUNCTION"]),
    "PMID24336938 primary: free dihydroflavin/Fre/NADH assay; physiological ferroprotein remains proposal. EutT localization explicitly unresolved in 2022.",
)
add(
    "regulation-context",
    "EutR transcriptional activation, EutA reactivation and in vitro enzyme inhibition are distinct relations. Ethanolaminium has three off-route regulation backlinks.",
    "Preserve EutR ligand-binding probability and source organism; do not promote serine-deaminase, beta-galactosidase or methyltransferase inhibition to EutR induction or new pathway members. Retain EutBC inhibitors and EutD pyruvate activation with assay scope.",
    uni("Q9ZFU7", ["FUNCTION", "INDUCTION"])
    + native("ECOLI:EG12190-MONOMER", ["comment"])
    + native("META:ETHANOL-AMINE", ["regulates"])
    + native("META:REG0-8619", ["regulated-entity", "regulator", "mode"])
    + native("META:REG0-8194", ["regulated-entity", "regulator", "mode"])
    + native("META:REG-9119", ["regulated-entity", "regulator", "mode"]),
)
add(
    "source-identities-and-classes",
    "META and ECOLI namespaces, generic protein classes, source labels and external issuer xrefs represent distinct identities and evidence levels. Some native chemical diagram SMILES contain generic placeholders.",
    "Keep namespace/class/detail flags. No manufactured CURIEs or schema extensions. Core14 exact chemical identity and direct NCBI strain issuer decisions are in separate frozen core packet, not inferred from matching names or masses.",
    native("META:Reduced-Flavoproteins", ["parent", "common-name"])
    + native("META:Oxidized-Flavoproteins", ["parent", "common-name"])
    + native("META:ETHANOL-AMINE", ["cml"]),
)
(R / "results/source-conflicts.json").write_text(
    json.dumps(rows, indent=2, ensure_ascii=False) + "\n"
)
print("conflict groups", len(rows))
