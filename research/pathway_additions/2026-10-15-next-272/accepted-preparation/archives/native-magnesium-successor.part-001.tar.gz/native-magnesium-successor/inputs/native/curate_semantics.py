from pathlib import Path
import json, collections, hashlib, xml.etree.ElementTree as E

R = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")


def put(n, x):
    (R / "results" / n).write_text(json.dumps(x, indent=2, ensure_ascii=False) + "\n")


u = json.loads((R / "results/uniprot-complete-projections.json").read_text())
n = json.loads((R / "results/all-native-projections.json").read_text())
e = json.loads((R / "results/ecoli-native-projections.json").read_text())
a = json.loads((R / "results/all71-activity-dispositions.json").read_text())
roles = {
    "eutA": (
        "reactivation",
        "EutA reactivates inactivated EutBC under Mg/ATP/free AdoCbl conditions. ATP-dependent cofactor exchange is mechanistic interpretation; this is distinct from EutT adenosylation. Do not turn assay Mg into a demonstrated bound-metal site. EcoCyc membrane location differs from UniProt compartment inference and newer localization needs separate primary scope.",
    ),
    "eutB": (
        "EAL alpha subunit",
        "Component of alpha6/beta6 EutBC; catalytic/cofactor annotations on a subunit do not establish isolated-subunit whole activity. Native prose hexamer-of-(alpha beta)2 wording conflicts with the direct six-plus-six slots. NCIB8114, JM109 and truncated recombinant proteins must not be relabeled MG1655 tests.",
    ),
    "eutC": (
        "EAL beta subunit and cargo signal",
        "Component of alpha6/beta6 EutBC. N-terminal cargo targeting is based on defined constructs, including reporter fusions; the native whole-complex location does not follow automatically from every fusion. Preserve the external model, inferred lumen interpretation and assembly differences.",
    ),
    "eutD": (
        "phosphotransacetylase",
        "Distinct EutD rather than general Pta. E. coli homodimer is directly sourced; LT2 homodimer annotation is by similarity. Reverse-direction acetate-assimilation kinetics are not direct forward catabolic kinetics. Genetic essentiality and bypass depend on conditions/background. E. coli location is explicitly unclear.",
    ),
    "eutE": (
        "acetylating aldehyde dehydrogenase",
        "Distinguish LT2 mutant/source assignment and separately verified biochemical literature from E. coli heterologous yeast assays. NAD preference, both directions, reporter targeting and heterologous constructs keep separate evidence scopes; no isolated whole-cell flux follows.",
    ),
    "eutG": (
        "ethanol-producing branch",
        "Preserve the second branch. LT2 alcohol chemistry and iron binding are inferred; mutant outcomes depend on pH, gas loss and carbon source. K12-derived recombinant crude-extract aldehyde assays show similar NADH/NADPH activities; these are not purified kinetics or proof of the LT2 cofactor preference. NAD recycling is a mechanism model, not measured universal flux.",
    ),
    "eutH": (
        "conditional membrane entry",
        "Source identifies an inner-membrane protein and hypothesizes pH-dependent ethanolamine entry. Database prose says protonated, whereas the separately pursued primary paper concerns uncharged ethanolamine. Native ETHANOL-AMINE is +1 ethanolaminium; do not equate it with neutral CHEBI:16000 or imply direct delivery into the metabolosome.",
    ),
    "eutJ": (
        "proposed chaperone/assembly role",
        "Chaperone, EAL protection/refolding and assembly roles remain proposed or by similarity; overexpression-induced BMC-like structures in E. coli are construct-specific. No supported additional core catalytic reaction is established.",
    ),
    "eutK": (
        "shell component",
        "EutK is monomeric in the tested solution and has a C-terminal HTH domain; nucleic-acid binding is suggested rather than demonstrated here. LT2 shell construction evidence does not turn every E. coli structural annotation into native MG1655 flux.",
    ),
    "eutL": (
        "shell trimer and pore",
        "EutL is a trimer forming a pseudohexamer, not a six-chain homomer. Open/closed and zinc-soaked crystal structures suggest gating; physiological zinc dependence and ATP/cobalamin transport through the pore are not demonstrated by pore dimensions.",
    ),
    "eutM": (
        "shell hexamer",
        "Hexameric pore architecture is source-supported; specific metabolite permeability and physiological flux are inferences. EutQ interaction and engineered Pdu substitution/SpyCatcher scaffolds retain their construct and organism scope.",
    ),
    "eutN": (
        "shell vertex candidate",
        "Native EcoCyc six-chain/crystal hexamer annotation differs from later UniProt solution pentamer evidence; retain both preparation scopes. Vertex and positively charged substrate transport functions remain proposed. No automatic six-chain physiological assembly is accepted.",
    ),
    "eutP": (
        "alternative acetate kinase",
        "LT2 recombinant EutP has acetate kinase activity, but anoxic ethanolamine+tetrathionate deletion phenotype differs from EutQ. GTP substitution and absence of divalent-cation requirement are assay-specific. BMC location remains inferred; K12 function is by similarity.",
    ),
    "eutQ": (
        "acetate kinase and assembly context",
        "LT2 EutQ acetate kinase and EutM-associated assembly effects are distinct assertions. The conditional anoxic phenotype, heterologous tags, GTP substitution and proposed cytoplasmic face placement remain explicit. Proposed EutE targeting is not a demonstrated direct catalytic or cargo-transfer edge.",
    ),
    "eutR": (
        "transcriptional regulation",
        "LT2 source supports activation of eut transcription, self-regulation and cobalamin competition; exact ligand binding remains probable. Infection/ssrB signaling is adjacent context, not a new core pathway member. K12 EutR assertions are largely homology-based and native EcoCyc annotation remains putative.",
    ),
    "eutS": (
        "shell hexamer and cargo targeting",
        "Distinguish bent native-like hexamers from flat G39V constructs, heterologous artificial shells, and N-terminal cargo reporters. Terminal tags can disrupt assembly. Shell bypass by overexpressed catalysts is conditional, not evidence that the natural shell is absent.",
    ),
    "eutT": (
        "cofactor adenosylation",
        "EutT-specific PPi+Pi chemistry differs from generic CobA/PduO triphosphate and the root older EC. FeII maximal assay activity does not prove an exclusive in vivo cofactor; Zn/Co/Mn observations remain scoped. UniProt cobinamide assertions conflict internally and with native prose. Generic flavoprotein reduction does not identify a physiological donor or prove direct EutT-to-EAL handoff.",
    ),
}


def evidences(v):
    if isinstance(v, dict):
        if "evidenceCode" in v:
            yield v
        for x in v.values():
            yield from evidences(x)
    elif isinstance(v, list):
        for x in v:
            yield from evidences(x)


up = []
claims = []
for x in sorted(u, key=lambda x: (x["organism"]["taxonId"], x["gene"])):
    role, note = roles[x["gene"]]
    taxon = x["organism"]["taxonId"]
    scope = (
        "K12 taxon83333; not MG1655-exclusive. All17 entries contain CPZ-55 caution with curator inference PMID9278503; no demonstrated intact MG1655 route is asserted."
        if taxon == 83333
        else "LT2 taxon99287 issuing protein identity. Individual experiments may use derivatives, constructs or heterologous hosts; identity is not direct flux evidence."
    )
    up.append(
        {
            "id": "UniProtKB:" + x["id"],
            "gene": x["gene"],
            "role": role,
            "disposition": "retain_issued_identity_and_scoped_mechanism_evidence",
            "semantic_assessment": note,
            "taxon_scope": scope,
            "source_path": x["source_path"],
            "source_sha256": x["source_sha256"],
            "entry_audit": x["audit"],
            "comment_count": len(x["comments"]),
            "mapping_policy": "BioCyc/KEGG crossreferences are leads; neither sequence/strain equivalence nor exact graph-node aliasing is approved by this preparation.",
        }
    )
    for i, c in enumerate(x["comments"]):
        typ = c["commentType"]
        if typ in [
            "BIOTECHNOLOGY",
            "INTERACTION",
            "MASS SPECTROMETRY",
            "SEQUENCE CAUTION",
        ]:
            d = "Retain measured/annotation context and exact construct or sequence scope; do not promote generic interactome or engineering observations to natural-route causal edges."
        elif typ == "CAUTION":
            d = "Must remain visible beside native MG1655 association: possible CPZ-55 expression limitation is curator inference, not proof of pathway absence."
        elif typ in ["SIMILARITY", "DOMAIN"]:
            d = "Retain structural/family and construct annotation; these do not independently prove native catalytic flux or location."
        elif typ in ["INDUCTION", "DISRUPTION PHENOTYPE"]:
            d = "Retain condition, strain, polarity, nutrient, cofactor and assay distinctions. Opposite phenotypes across conditions are not normalized to universal essentiality."
        elif typ == "PATHWAY":
            d = "Broad pathway association is supporting context; the five-member exact boundary comes from the native Pathway original."
        else:
            d = note
        claims.append(
            {
                "id": "UniProtKB:" + x["id"],
                "gene": x["gene"],
                "locator": "/" + str("comments") + "/" + str(i),
                "type": typ,
                "source_statement": c,
                "evidence_codes": list(
                    {json.dumps(q, sort_keys=True): q for q in evidences(c)}.values()
                ),
                "disposition": d,
                "scope": scope,
                "source_sha256": x["source_sha256"],
            }
        )
put("all34-protein-semantic-dispositions.json", up)
put("all-uniprot-comment-dispositions.json", claims)
# Every source own slot remains separately addressable. This is a complete machine inventory
# plus slot-type interpretation, not a claim of independent scientific acceptance.
slot_kinds = {
    "appears-in-left-side-of": "reverse chemical/reaction backlink; not automatic pathway membership or catalyst selection",
    "appears-in-right-side-of": "reverse chemical/reaction backlink; not automatic pathway membership or catalyst selection",
    "enzymatic-reaction": "reverse reaction/activity lead requiring full original and scoped disposition, not automatic ethanolamine catalyst",
    "common-name": "issuing name",
    "synonym": "issuing synonym; not independent exact alias",
    "systematic-name": "issuing systematic name",
    "abbrev-name": "issuing abbreviation",
    "parent": "source class/type; class flags remain distinct from instances",
    "subclass": "class child backlink; not pathway membership",
    "instance": "class instance backlink; not exact catalyst selection",
    "component": "physical composition with exact supplied coefficient; no independent whole catalysis by each subunit",
    "component-of": "assembly backlink; acquire selected assembly originals",
    "catalyzes": "native enzyme/activity link, requiring evidence-tier and taxon scope",
    "enzyme": "native activity/enzyme link, not enough alone to establish Eut relevance",
    "reaction": "native activity/reaction link",
    "reaction-direction": "native direction; distinguish pathway traversal and assay direction",
    "physiologically-relevant": "native boolean assertion, not independent flux measurement",
    "left": "exact source material occurrence, coefficient omission/explicit value and any location preserved",
    "right": "exact source material occurrence, coefficient omission/explicit value and any location preserved",
    "reaction-list": "exact pathway membership",
    "reaction-ordering": "native ordering, not measured flux ratio",
    "reaction-layout": "native selected direction and layout primaries",
    "in-pathway": "backlink/context, not automatic additional member",
    "pathway-link": "adjacent process connection; no invented transport reaction",
    "cofactor": "source cofactor assertion with evidence and preparation",
    "alternative-cofactor": "alternative cofactor with conditional scope; not universal equivalent",
    "cofactor-binding-comment": "binding/requirement comment, not assumed physiological equivalence",
    "alternative-substrate": "alternative activity material; not part of canonical source equation",
    "cofactors-of": "reverse chemical/activity backlink; do not import unrelated enzymes",
    "regulated-by": "source regulation lead with sign/effector; selected full originals retained",
    "regulates": "reverse regulator backlink; off-route targets remain excluded",
    "regulator": "exact regulator entity",
    "regulated-entity": "exact target activity/entity",
    "mode": "native sign; no inferred regulatory mechanism",
    "mechanism": "source regulatory mechanism and qualifier",
    "location": "source physical localization; preserve inferred/experimental scope and contradictions",
    "surrounded-by": "source compartment anatomy",
    "surrounds": "source compartment anatomy",
    "sensu": "taxon-sensitive compartment sense",
    "definition": "issuing class/compartment definition",
    "has-go-term": "annotation with own evidence; broad GO association does not define exact pathway or location proof",
    "has-feature": "sequence/construct feature with source positions and citation; not a new biological entity",
    "gene": "gene-product provenance; no automatic DNA node or regulation edge",
    "product": "gene-product provenance",
    "species": "source organism association; not proof of intact-pathway flux",
    "taxonomic-range": "broad expected range, not direct experimental association",
    "rank": "source taxon rank",
    "strain-name": "source strain identity",
    "subspecies-name": "source subspecies identity",
    "citation": "bibliographic pointer; not inspected primary text",
    "evidence": "source evidence codes and publication association; preserve purified/heterologous/mutant/inference distinctions",
    "comment": "complete biological narrative, read for route relevance/qualifiers; linked papers remain separate access tiers",
    "credits": "source curation/import provenance",
    "dblink": "external issuer mapping lead; no unverified equivalence",
    "accession-1": "source locus accession",
    "accession-2": "additional source locus accession",
    "goid": "native ontology linkage",
    "ec-number": "source EC assertion; known Ack and EutT discrepancies remain explicit",
    "orphan": "source orphan flag, not absence proof",
    "molecular-weight": "source molecular weight property",
    "molecular-weight-exp": "experimental molecular weight with preparation context",
    "molecular-weight-seq": "sequence-derived molecular weight",
    "monoisotopic-mw": "chemical mass property; no identity from mass alone",
    "pi": "source isoelectric point",
    "pka1": "source pKa",
    "gibbs-0": "source thermodynamic annotation; no flux inference",
    "inchi": "exact source chemical structure string, not automatically normalized",
    "inchi-key": "exact source chemical structure hash",
    "cml": "complete chemical diagram/atom/charge/formula/SMILES; generic placeholders are not exact structure authority",
    "km": "substrate-specific measured parameter with units/source, not substrate membership by inference",
    "kcat": "substrate/preparation-specific turnover with units/source",
    "vmax": "source maximum rate with units/preparation",
    "specific-activity": "source activity with preparation/conditions",
    "ph-opt": "assay pH optimum, not universal physiological condition",
    "temperature-opt": "assay temperature optimum",
    "left-end-position": "source genome coordinate",
    "right-end-position": "source genome coordinate",
    "transcription-direction": "source gene orientation",
}
slotrows = []
objs = []
ad = {x["activity"]: x for x in a}
enzroles = {x["enzyme"]: x for x in a}
for x in n + e:
    org = x["attributes"]["orgid"]
    fid = x["id"]
    base = {
        "id": org + ":" + fid,
        "type": x["type"],
        "source_path": x["source_path"],
        "source_sha256": x["sha256"],
        "own_slots": x["own_slot_count"],
    }
    if org == "META" and fid in ad:
        dis = ad[fid]["rationale"]
        status = ad[fid]["disposition"]
    elif org == "META" and fid in enzroles:
        dis = enzroles[fid]["rationale"]
        status = enzroles[fid]["disposition"]
    elif fid in ["REG0-8619", "REG0-8194", "REG-9119"]:
        dis = "Ethanolaminium inhibition of off-route serine deaminase, beta-galactosidase or ethanolamine methyltransferase. No EutR induction claim or new core member."
        status = "off_route_regulatory_context"
    elif x["type"] == "Regulation":
        dis = "Selected EutBC inhibitor or EutD activator statement. Preserve mode/mechanism/citation and preparation; no universal in vivo effect."
        status = "selected_regulatory_source"
    elif fid == "RXN-19336":
        dis = "EutT ancillary cofactor reaction, outside five native core members; generic redox protein classes and two-proton source equation preserved separately from Rhea/UniProt three-proton equation."
        status = "ancillary_cofactor_reaction"
    elif org == "ECOLI":
        dis = "Exact ECOLI-scoped source, never renamed META. Preserve physical assembly/location and putative assignments, with corresponding UniProt/primary semantic dispositions."
        status = "biological_closure_ecoli_source"
    elif fid in ["Oxidized-Flavoproteins", "Reduced-Flavoproteins"]:
        dis = "Generic source protein redox classes, not a selected physiological donor sequence or new catalyzing complex."
        status = "generic_cofactor_redox_context"
    elif fid in ["TAX-511145", "TAX-99287"]:
        dis = "Exact native direct strain object copied from core owner; NCBI issuer verification belongs to separate core packet. Native association does not prove intact flux."
        status = "direct_native_taxon"
    elif x["type"] == "Compound":
        dis = "Complete source chemical identity/structure and reverse backlinks retained. Core14 external mapping assessed separately; ancillary compounds remain native issued identities without unverified external equivalence. Do not expand entire chemical backlink universe."
        status = "core_or_ancillary_chemical"
    else:
        dis = "Complete selected source closure identity and assertions retained; exact mechanism context is in native and UniProt semantic ledgers. Root21 slots and five reactions retain accepted discovery scope."
        status = "selected_source_closure"
    objs.append({**base, "disposition": status, "semantic_assessment": dis})
    for s in x["slots"]:
        assert s["slot"] in slot_kinds, s["slot"]
        slotrows.append(
            {
                **base,
                "locator": s["locator"],
                "slot": s["slot"],
                "ordinal": s["ordinal"],
                "interpretation": slot_kinds[s["slot"]],
                "object_disposition": status,
                "xml_sha256": hashlib.sha256(s["xml"].encode()).hexdigest(),
                "source_slot": s,
            }
        )
put("all-native-object-dispositions.json", objs)
put("complete-native-slot-interpretations.json", slotrows)
put(
    "semantic-coverage-summary.json",
    {
        "native_objects": len(objs),
        "native_own_slots": len(slotrows),
        "metacyc_objects": len(n),
        "ecoli_objects": len(e),
        "uniprot_proteins": len(up),
        "uniprot_comment_statements": len(claims),
        "activity_dispositions": dict(collections.Counter(x["disposition"] for x in a)),
        "review_scope": "Author source preparation. Complete raw/source projections and per-object dispositions do not equal independent scientific review, sequence/alias acceptance, graph authoring, or exhaustion.",
    },
)
print(
    json.dumps(json.loads((R / "results/semantic-coverage-summary.json").read_text()))
)
