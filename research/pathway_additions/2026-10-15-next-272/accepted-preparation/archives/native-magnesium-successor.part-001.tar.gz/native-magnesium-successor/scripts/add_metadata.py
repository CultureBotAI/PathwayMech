from pathlib import Path
import json, hashlib, shutil, xml.etree.ElementTree as ET

R = Path(__file__).resolve().parents[1]
P = Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation")
I = Path("/private/tmp/pathwaymech-next-272-imodulondb-preparation")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def put(p, x):
    (R / p).write_text(json.dumps(x, indent=2) + "\n")


bindings = json.loads((R / "results/parent-bindings.json").read_text())


def cp(owner, rel, dest):
    p = owner / rel
    q = R / dest
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, q)
    bindings.append(
        {
            "owner": str(owner),
            "parent_path": rel,
            "path": dest,
            "bytes": q.stat().st_size,
            "sha256": sha(q),
        }
    )
    return q


q = cp(P, "originals/PMC4827028-efetch.xml", "originals/PMC4827028-efetch.xml")
cp(P, "receipts/PMC4827028-efetch.xml.json", "receipts/PMC4827028-efetch.xml.json")
cp(P, "results/source-reading-ledger.json", "inputs/primary/source-reading-ledger.json")
cp(P, "results/claim-ledger.json", "inputs/primary/claim-ledger.json")
r = ET.parse(q).getroot()
authors = [
    {"surname": c.findtext("name/surname"), "given_names": c.findtext("name/given-names")}
    for c in r.findall(".//front/article-meta/contrib-group/contrib")
    if c.get("contrib-type") == "author"
]
assert [x["surname"] for x in authors] == [
    "Held",
    "Kolb",
    "Perdue",
    "Hsu",
    "Bloch",
    "Quin",
    "Schmidt-Dannert",
]
ledger = json.loads((R / "inputs/primary/source-reading-ledger.json").read_text())
idx = next(i for i, x in enumerate(ledger["sources"]) if x["key"] == "S24")
old = ledger["sources"][idx]["citation"]
put(
    "results/citation-successor.json",
    {
        "parent_file": "results/source-reading-ledger.json",
        "parent_sha256": sha(P / "results/source-reading-ledger.json"),
        "locator": "/sources/" + str(idx) + "/citation",
        "key": "S24",
        "old": old,
        "successor": "Held, Kolb, Perdue et al.2016; PMID27063436; PMC4827028; DOI10.1038/srep24359",
        "reason": "Original article front matter lists Mark Held first; Maureen B. Quin is sixth author. Author-list correction only; no biological claim changes.",
        "source": "originals/PMC4827028-efetch.xml",
        "source_sha256": sha(q),
        "source_locator": './/front/article-meta/contrib-group/contrib[@contrib-type="author"]/name',
        "ordered_authors": authors,
        "scope": "Direct targeted bibliographic original inspection only; not renewed whole-paper reading or independent acceptance.",
    },
)
assert (
    sha(I / "artifact-manifest.json")
    == "faeb80b7709f36e6544b059f10700f22e545aa87e58b2cfc371a0be474a2e4dd"
)
for f in ["artifact-manifest.json", "freeze-proof.json", "HANDOFF.md"]:
    cp(I, f, "inputs/imodulondb/" + f)
q = cp(
    I,
    "raw-e_coli-modulome-76-genes.body.json",
    "inputs/imodulondb/raw-e_coli-modulome-76-genes.body.json",
)
x = json.loads(q.read_text())["genes"][4]
assert (
    x["gene_name"] == "eutH"
    and x["uniprot_id"] == "P76552"
    and "protonated" in x["uniprot_function"]
)
put(
    "results/contextual-euth-disposition.json",
    {
        "source": "inputs/imodulondb/raw-e_coli-modulome-76-genes.body.json",
        "source_sha256": sha(q),
        "locator": "/genes/4/uniprot_function",
        "gene": "eutH",
        "historical_uniprot_accession": "P76552",
        "source_statement": x["uniprot_function"],
        "disposition": "Retain this iModulonDB historical annotation exactly as expression-context source text. It repeats the protonated-substrate wording already in conflict with the neutral-substrate EutH primary interpretation in the accepted preparation scopes. Neither this field nor iModulon membership establishes transport microstate, catalytic chemistry, causal transport edge, native pathway flux or direct BMC delivery. No independent new EutH paper reading is claimed here.",
        "existing_primary_context_locator": "inputs/primary/claim-ledger.json: PMID15466042 claim and its existing qualification",
        "existing_native_context_locator": "inputs/native/source-conflicts.json: euth-transport-microstate",
    },
)
put("results/parent-bindings.json", bindings)
print(
    json.dumps(
        {
            "citation_corrected": "S24 Held et al.2016",
            "historical_context_field_preserved": "/genes/4/uniprot_function",
            "new_biological_claims": False,
        }
    )
)
