"""Read-only offline verification of bounded successor, without parent writes."""

from pathlib import Path
import hashlib, json, xml.etree.ElementTree as ET, collections

R = Path(__file__).resolve().parents[1]


def read(path):
    return json.loads((R / path).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


parent = {}
for label, expected in [
    ("native", "d7fe7fedf9315c241782ce9b26729804461dda646ba903da312fba0996054d13"),
    ("primary", "86974c5ce2562d549755f18b30fa27a14ac6c6d5007b476aaeefe105eaa36ada"),
    ("imodulondb", "faeb80b7709f36e6544b059f10700f22e545aa87e58b2cfc371a0be474a2e4dd"),
]:
    p = R / "inputs" / label / "artifact-manifest.json"
    assert sha(p) == expected
    m = json.loads(p.read_text())
    rows = m["files"] if isinstance(m, dict) else m
    parent[label] = {x["path"]: x for x in rows}
for b in read("results/parent-bindings.json"):
    p = R / b["path"]
    assert p.stat().st_size == b["bytes"] and sha(p) == b["sha256"]
    label = (
        "native"
        if "native-source-preparation" in b["owner"]
        else ("imodulondb" if "imodulondb" in b["owner"] else "primary")
    )
    if b["parent_path"] not in ["artifact-manifest.json", "freeze-proof.json"]:
        original = parent[label][b["parent_path"]]
        assert original["sha256"] == b["sha256"] and original["bytes"] == b["bytes"]
root = ET.parse(R / "originals/PMC4857615-efetch.xml").getroot()
reading = read("results/primary-reading.json")
assert len(reading) == 6
for x in reading:
    e = root.find(x["id_locator"])
    assert e is not None
    assert (
        hashlib.sha256(ET.tostring(e, encoding="utf-8")).hexdigest()
        == x["complete_element_xml_sha256"]
    )
    assert x["short_quote"] in " ".join(" ".join(e.itertext()).split())
assert sum(len(x["short_quote"].split()) for x in reading) == 22
replacements = read("results/successor-dispositions.json")
assert len(replacements) == 25
for x in replacements:
    f = R / "inputs/native" / Path(x["parent_file"]).name
    assert sha(f) == x["parent_file_sha256"]
    v = json.loads(f.read_text())
    for part in x["locator"].split("/")[1:]:
        v = v[int(part)] if isinstance(v, list) else v[part.replace("~1", "/").replace("~0", "~")]
    assert v == x["old_interpretation"]
    assert "absence of divalent-cation requirement" not in x["successor_interpretation"]
    assert (
        "6.6 mM MgCl2" in x["successor_interpretation"]
        and "do not infer magnesium-independent catalysis" in x["successor_interpretation"]
    )
assert sum(x["category"] == "direct_overstatement" for x in replacements) == 11
for x in read("results/database-assertions.json"):
    f = R / x["source"]
    assert sha(f) == x["sha256"]
    raw = json.loads(f.read_text())
    if x["accession"] in ["P0A208", "Q9ZFV5"]:
        assert raw["comments"][3]["note"]["texts"][0]["value"] == "Does not need divalent cations."
        assert raw["organism"]["taxonId"] == 99287
    else:
        assert raw["organism"]["taxonId"] == 83333 and x["assertion_locators"] == []
inv = read("results/occurrence-inventory.json")
assert (
    inv["hidden_and_ignored_included"]
    and inv["physical_files_scanned"] == 621
    and len(inv["matches"]) == 10
)
citation = read("results/citation-successor.json")
ledger = read("inputs/primary/source-reading-ledger.json")
assert (
    ledger["sources"][23]["citation"] == citation["old"]
    and citation["locator"] == "/sources/23/citation"
)
article = ET.parse(R / citation["source"]).getroot()
assert article.findtext('.//article-id[@pub-id-type="pmid"]') == "27063436"
assert article.findtext('.//article-id[@pub-id-type="doi"]') == "10.1038/srep24359"
assert [
    c.findtext("name/surname")
    for c in article.findall('.//front/article-meta/contrib-group/contrib[@contrib-type="author"]')
] == [a["surname"] for a in citation["ordered_authors"]]
ctx = read("results/contextual-euth-disposition.json")
assert read(ctx["source"])["genes"][4]["uniprot_function"] == ctx["source_statement"]
out = {
    "status": "pass",
    "parent_manifest_bindings": 3,
    "source_copy_bindings": len(read("results/parent-bindings.json")),
    "primary_elements": 6,
    "short_primary_quote_words": 22,
    "successor_interpretations": 25,
    "direct_overstatements_superseded": 11,
    "raw_source_assertions_preserved": True,
    "parents_untouched": True,
    "new_acquisition": False,
    "scope": "Offline correctness of supplementary source interpretation and bindings; independent acceptance remains external.",
}
print(json.dumps(out, indent=2))
