"""Bounded no-network successor; preserves and binds all frozen parents."""

from pathlib import Path
import json, hashlib, shutil, re, xml.etree.ElementTree as ET

R = Path(__file__).resolve().parents[1]
N = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
P = Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation")
for d in ["originals", "inputs/native", "inputs/primary", "receipts", "results"]:
    (R / d).mkdir(parents=True, exist_ok=True)


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def put(path, obj):
    (R / path).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")


bindings = []


def copy(owner, relative, dest):
    source = owner / relative
    target = R / dest
    shutil.copy2(source, target)
    bindings.append(
        {
            "owner": str(owner),
            "parent_path": relative,
            "path": dest,
            "bytes": target.stat().st_size,
            "sha256": digest(target),
        }
    )
    return target


for owner, label, expected in [
    (N, "native", "d7fe7fedf9315c241782ce9b26729804461dda646ba903da312fba0996054d13"),
    (P, "primary", "86974c5ce2562d549755f18b30fa27a14ac6c6d5007b476aaeefe105eaa36ada"),
]:
    assert digest(owner / "artifact-manifest.json") == expected
    for f in ["artifact-manifest.json", "freeze-proof.json", "HANDOFF.md"]:
        copy(owner, f, "inputs/" + label + "/" + f)
primary = copy(P, "originals/PMC4857615-efetch.xml", "originals/PMC4857615-efetch.xml")
copy(P, "receipts/PMC4857615-efetch.xml.json", "receipts/PMC4857615-efetch.xml.json")
for acc in ["P0A208", "Q9ZFV5", "P76555", "P76556"]:
    copy(N, "originals/UniProt-" + acc + ".json", "originals/UniProt-" + acc + ".json")
    copy(N, "receipts/UniProt-" + acc + ".json.json", "receipts/UniProt-" + acc + ".json.json")
for f in [
    "results/all34-protein-semantic-dispositions.json",
    "results/all-uniprot-comment-dispositions.json",
    "results/source-conflicts.json",
    "scripts/curate_semantics.py",
    "scripts/build_conflict_ledger.py",
]:
    copy(N, f, "inputs/native/" + Path(f).name)
put("results/parent-bindings.json", bindings)
root = ET.parse(primary).getroot()
up = {c: p for p in root.iter() for c in p}


def loc(el):
    parts = []
    while el is not None:
        parent = up.get(el)
        i = 1 if parent is None else [c for c in parent if c.tag == el.tag].index(el) + 1
        parts.append(el.tag + "[" + str(i) + "]")
        el = parent
    return "/" + ("/".join(reversed(parts)))


def para(id):
    return next(e for e in root.iter("p") if e.get("id") == id)


def clean(e):
    return re.sub(r"\s+", " ", " ".join(e.itertext())).strip()


items = [
    (
        "P13",
        "EutQ EDTA treatment result",
        "EutQ was dialyzed with 2 mM EDTA in buffer A without imidazole, three 2-hour buffer changes at 4 C; activity was reported unchanged against untreated enzyme. The comparison data are not shown.",
        "did not lose any activity",
    ),
    (
        "P14",
        "EutP EDTA treatment result",
        "EutP specific activity was reported unchanged after EDTA dialysis. This is a treatment comparison, not an explicitly documented magnesium-free reaction.",
        "did not have an effect",
    ),
    (
        "P20",
        "Authors\u2019 interpretation",
        "The authors infer no divalent-metal cofactor requirement and favor a nonmetalloprotein interpretation; these stronger statements are retained as author interpretation rather than independently established magnesium-free catalysis.",
        "did not require divalent metal cofactors",
    ),
    (
        "P39",
        "Coupled kinetic assay formulation",
        "The described acetate kinase kinetic assay adds 6.6 mM MgCl2 and uses pyruvate kinase/lactate dehydrogenase plus myokinase, ATP and substrates; reactions start with EutP or EutQ at 2 micromolar and run at 40 C. No separate magnesium-free EDTA-comparison assay formulation is specified.",
        "6.6 mM",
    ),
    (
        "P40",
        "HPLC reaction formulations",
        "AcP+ADP to acetate+ATP assays add 1 mM MgCl2. The reverse EutP/Q-to-EutD coupled assay also adds 1 mM MgCl2. Product reactions run at 37 C before HPLC.",
        "1 mM",
    ),
]
findings = []
for id, title, paraphrase, quote in items:
    e = para(id)
    text = clean(e)
    assert quote in text
    findings.append(
        {
            "source": "originals/PMC4857615-efetch.xml",
            "source_sha256": digest(primary),
            "pmid": "26448059",
            "id": id,
            "locator": loc(e),
            "id_locator": './/p[@id="' + id + '"]',
            "title": title,
            "paraphrase": paraphrase,
            "short_quote": quote,
            "complete_element_xml_sha256": hashlib.sha256(
                ET.tostring(e, encoding="utf-8")
            ).hexdigest(),
        }
    )
e = root.find('.//fig[@id="F8"]/caption/p')
assert e is not None
findings.append(
    {
        "source": "originals/PMC4857615-efetch.xml",
        "source_sha256": digest(primary),
        "pmid": "26448059",
        "id": "F8-caption",
        "locator": loc(e),
        "id_locator": './/fig[@id="F8"]/caption/p',
        "title": "EutQ 31P-NMR assay formulation",
        "paraphrase": "The caption specifies 5 mM MgCl2 and attributes nucleotide chemical-shift changes to magnesium complexation. This is additional evidence for magnesium-containing assay conditions, not proof of an enzyme-bound magnesium cofactor.",
        "short_quote": "5 mM",
        "complete_element_xml_sha256": hashlib.sha256(ET.tostring(e, encoding="utf-8")).hexdigest(),
    }
)
assert sum(len(x["short_quote"].split()) for x in findings) <= 25
put("results/primary-reading.json", findings)
db = []
for acc in ["P0A208", "Q9ZFV5", "P76555", "P76556"]:
    f = R / "originals" / ("UniProt-" + acc + ".json")
    raw = json.loads(f.read_text())
    claim = [
        (i, c)
        for i, c in enumerate(raw["comments"])
        if c.get("commentType") == "COFACTOR" and "divalent cations" in json.dumps(c)
    ]
    assert len(claim) == (1 if acc in ["P0A208", "Q9ZFV5"] else 0)
    db.append(
        {
            "source": str(f.relative_to(R)),
            "sha256": digest(f),
            "accession": acc,
            "gene": raw["genes"][0]["geneName"]["value"],
            "taxon": raw["organism"]["taxonId"],
            "assertion_locators": ["/comments/" + str(i) + "/note/texts/0/value" for i, c in claim],
            "database_assertions": [c for i, c in claim],
            "disposition": "Retain raw source annotation. For LT2 the experimentally supported scope is EDTA-treatment resistance with magnesium-containing documented assays; the stronger magnesium-independent conclusion is not established. K12 originals contain no equivalent COFACTOR absence assertion, so this must not be attributed directly to them.",
        }
    )
put("results/database-assertions.json", db)
qualification = "PMID26448059 reports no observed loss of EutP/Q activity after EDTA dialysis; its documented coupled kinetic assay adds 6.6 mM MgCl2, HPLC reactions add 1 mM MgCl2, and EutQ NMR adds 5 mM MgCl2. The EutQ EDTA comparison is data not shown and no distinct Mg-free assay is specified. Retain EDTA-treatment resistance under these documented Mg-containing assay conditions; do not infer magnesium-independent catalysis, absence of all metal requirements, or a specific enzyme-bound Mg cofactor. LT2 assay scope is not direct K12 evidence."
oldP = "GTP substitution and absence of divalent-cation requirement are assay-specific."
replacements = []


def add(rel, pointer, old, new, category):
    replacements.append(
        {
            "parent_file": rel,
            "parent_file_sha256": digest(N / rel),
            "locator": pointer,
            "category": category,
            "old_interpretation": old,
            "successor_interpretation": new,
            "status": "supersedes_interpretation_only_preserve_source_bytes",
            "basis": ["P13", "P14", "P20", "P39", "P40", "F8-caption"],
        }
    )


rel = "results/all34-protein-semantic-dispositions.json"
d = json.loads((N / rel).read_text())
roles = {}
for i, x in enumerate(d):
    if x["gene"] in ["eutP", "eutQ"]:
        old = x["semantic_assessment"]
        roles[x["gene"]] = old
        new = old.replace(oldP, "GTP substitution remains assay-specific.") + " " + qualification
        add(
            rel,
            "/" + str(i) + "/semantic_assessment",
            old,
            new,
            "direct_overstatement" if oldP in old else "related_PQ_scope_qualification",
        )
rel = "results/all-uniprot-comment-dispositions.json"
d = json.loads((N / rel).read_text())
for i, x in enumerate(d):
    if x["gene"] in roles and x["disposition"] == roles[x["gene"]]:
        old = x["disposition"]
        new = old.replace(oldP, "GTP substitution remains assay-specific.") + " " + qualification
        add(
            rel,
            "/" + str(i) + "/disposition",
            old,
            new,
            "direct_overstatement"
            if oldP in old
            else (
                "raw_COFACTOR_claim_requires_qualification"
                if x["type"] == "COFACTOR"
                else "related_PQ_scope_qualification"
            ),
        )
rel = "results/source-conflicts.json"
d = json.loads((N / rel).read_text())
for i, x in enumerate(d):
    if x["id"] == "eutpq-phenotype-location":
        old = x["required_disposition"]
        new = (
            old.replace(
                "and measured cation behavior", "and explicitly qualified EDTA-treatment results"
            )
            + " "
            + qualification
        )
        add(rel, "/" + str(i) + "/required_disposition", old, new, "grouped_PQ_scope_qualification")
put("results/successor-dispositions.json", replacements)
# Search physical files including hidden and gitignored files; report source/assertion copies separately.
needles = [
    "absence of divalent-cation requirement",
    "Does not need divalent cations",
    "measured cation behavior",
]
hits = []
scanned = 0
for p in sorted(q for q in N.rglob("*") if q.is_file()):
    scanned += 1
    try:
        s = p.read_text()
    except (UnicodeDecodeError, OSError):
        continue
    found = [t for t in needles if t in s]
    if not found:
        continue
    rel = str(p.relative_to(N))
    category = (
        "raw_issuer_or_search_preserve"
        if rel.startswith("originals/")
        else "frozen_historical_helper_preserve_but_superseded"
        if "initial-failed" in rel
        else "generator_requires_successor_interpretation"
        if rel.startswith("scripts/")
        else "source_projection_preserve_raw_assertion"
        if rel == "results/uniprot-complete-projections.json"
        else "scientific_interpretation_qualified_by_successor"
    )
    hits.append(
        {
            "parent_file": rel,
            "sha256": digest(p),
            "needles": found,
            "category": category,
            "line_numbers": {
                t: [i for i, line in enumerate(s.splitlines(), 1) if t in line] for t in found
            },
        }
    )
put(
    "results/occurrence-inventory.json",
    {
        "search_scope": str(N),
        "physical_files_scanned": scanned,
        "hidden_and_ignored_included": True,
        "literal_patterns": needles,
        "matches": hits,
        "limitations": "Literal-pattern occurrence search plus semantic audit of all four P/Q protein dispositions and all P/Q comment dispositions; not a claim of exhaustive literature or all conceivable paraphrase discovery. Exact affected interpretation JSON pointers are enumerated in successor-dispositions.",
    },
)
put(
    "results/successor-conclusion.json",
    {
        "finding": "next272-preparation-eutpq-divalent-cation-scope",
        "decision": "confirmed_with_assay_scope_refinement",
        "author_role": "original native source preparer independently re-read retained primary main at targeted scope; not independent successor acceptance",
        "retained_facts": [
            "LT2 EutP and EutQ acetate kinase activity remains supported.",
            "No reported loss of activity after EDTA dialysis is a valid reported treatment comparison.",
            "The published assay methods add magnesium; no separate magnesium-free EDTA-comparison formulation is specified.",
            "The paper and UniProt stronger no-divalent-metal interpretations remain preserved as source assertions.",
        ],
        "allowed_future_record_or_graph": [
            "Describe reversible acetate kinase catalysis with exact organism, expression/preparation and assay scope.",
            "If relevant, describe reported EDTA-treatment resistance measured under the documented magnesium-containing protocols.",
            "Retain magnesium as an assay constituent in evidence/prose where supported by schema, without inventing slots.",
        ],
        "prohibited_inferences": [
            "No blanket magnesium-independent, divalent-cation-independent, metal-free or cofactor-free catalytic mechanism.",
            "No new Mg-binding edge or fixed metal stoichiometry/physiological Mg requirement inferred merely from added MgCl2.",
            "No causal edge from EDTA resistance to demonstrated absence of a metalloprotein requirement.",
            "No transfer of LT2 treatment observations to K12 as direct experimental results.",
        ],
        "qualification": qualification,
        "affected_interpretations": len(replacements),
        "no_maintained_changes": True,
        "no_reacquisition": True,
    },
)
print(
    json.dumps(
        {
            "primary_elements_read": len(findings),
            "source_entries": len(db),
            "successor_interpretations": len(replacements),
            "direct_overstatements": sum(
                x["category"] == "direct_overstatement" for x in replacements
            ),
            "physical_search_matches": len(hits),
        },
        indent=2,
    )
)
