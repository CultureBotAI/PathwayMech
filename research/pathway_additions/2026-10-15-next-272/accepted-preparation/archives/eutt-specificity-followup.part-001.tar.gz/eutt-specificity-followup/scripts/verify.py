"""Verify this bounded evidence supplement without modifying its owner."""

from pathlib import Path
from xml.etree import ElementTree as ET
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def check(condition, message):
    global checks
    if not condition:
        raise ValueError(message)
    checks += 1


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for row in json.loads((ROOT / "results/parent-bindings.json").read_text()):
    path = ROOT / row["local_path"]
    check(path.is_file() and not path.is_symlink(), row["local_path"])
    check(path.stat().st_size == row["bytes"], row["local_path"] + " size")
    check(digest(path) == row["sha256"], row["local_path"] + " hash")

for path in sorted((ROOT / "receipts").glob("*.json")):
    value = json.loads(path.read_text())
    if isinstance(value, dict) and value.get("path"):
        body = ROOT / value["path"]
        check(body.stat().st_size == value["bytes"], str(path) + " body size")
        check(digest(body) == value["sha256"], str(path) + " body hash")

article = ET.fromstring((ROOT / "originals/PMC4504680-efetch.xml").read_bytes())
ids = {
    n.get("pub-id-type"): n.text
    for n in article.findall("./article/front/article-meta/article-id")
}
for key, value in [
    ("pmid", "25914129"),
    ("pmcid", "PMC4504680"),
    ("doi", "10.1002/anie.201501930"),
]:
    check(ids.get(key) == value, key)
check(len(article.findall("./article/body/p")) == 8, "complete eight-paragraph body")
check(len(article.findall(".//fig")) == 4, "four main figures")
check(len(article.findall(".//table-wrap")) == 1, "one main table")

for claim in json.loads((ROOT / "results/claim-dispositions.json").read_text()):
    check(0 < len(claim["source_assertion"]) <= 400, claim["id"] + " assertion length")
    path = ROOT / claim["source"]
    if path.suffix == ".xml":
        root = ET.fromstring(path.read_bytes())
        top, locator = claim["locator"].strip("/").split("/", 1)
        check(
            top == root.tag and len(root.findall(locator)) == 1,
            claim["id"] + " locator",
        )
    else:
        current = json.loads(path.read_text())
        for key in claim["locator"].strip("/").split("/"):
            current = current[int(key)] if isinstance(current, list) else current[key]
        check(bool(current), claim["id"] + " pointer")

for name in ["EutT-2006-institutional.pdf", "PMC4504680-SI.pdf"]:
    body = (ROOT / "originals" / name).read_bytes()
    check(
        not body.startswith(b"%PDF-") and b"<html" in body[:200].lower(),
        name + " retained HTML failure",
    )
error = ET.fromstring(
    (ROOT / "originals/PMC4504680-supporting-response.bin").read_bytes()
)
check(
    "not open access" in "".join(error.itertext()), "retained Europe PMC access error"
)

manifest = ROOT / "artifact-manifest.json"
if manifest.exists():
    value = json.loads(manifest.read_text())
    expected = {r["path"] for r in value["files"]} | {
        "artifact-manifest.json",
        "freeze-proof.json",
    }
    physical = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
    check(
        physical == expected,
        "complete physical inventory including hidden and ignored files",
    )
    for row in value["files"]:
        path = ROOT / row["path"]
        check(
            not path.is_symlink() and path.stat().st_size == row["bytes"],
            row["path"] + " size/type",
        )
        check(digest(path) == row["sha256"], row["path"] + " hash")
    proof = json.loads((ROOT / "freeze-proof.json").read_text())
    check(digest(manifest) == proof["manifest_sha256"], "manifest binding")
    check(digest(ROOT / "HANDOFF.md") == proof["handoff_sha256"], "handoff binding")

print(
    json.dumps(
        {
            "checks_passed": checks,
            "scope": "Finite provenance, locator, access-tier and physical integrity checks; scientific interpretation requires independent review.",
        }
    )
)
