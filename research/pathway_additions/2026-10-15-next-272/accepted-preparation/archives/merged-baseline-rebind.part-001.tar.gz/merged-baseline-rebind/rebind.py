"""Rebind a finite discovery packet to the actual merged corpus; no Git mutations."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
WORKTREE = Path("/private/tmp/pathwaymech-next-272-20261015")
RECEIPT = Path("/private/tmp/pathwaymech-next-272-ci/new-worktree-baseline.json")
BASE = "63ebb3b3e29ca1ed6472597104347d9fbc98f4a5"
MERGE = "54e768a985d07705ea25445804c83b4758646e37"
REVIEWED = "90695df63225de6f7379c9b48f0519287ac1896e"
checks = []
commands = []
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def now():
    return datetime.now(UTC).isoformat()


def check(name, condition, observed=None):
    checks.append({"check": name, "pass": bool(condition), "observed": observed})


def git(*args, input_data=None):
    command = ["git", *args]
    started = now()
    r = subprocess.run(command, cwd=WORKTREE, env=env, input=input_data, capture_output=True)
    commands.append(
        {
            "command": command,
            "cwd": str(WORKTREE),
            "GIT_OPTIONAL_LOCKS": "0",
            "started_utc": started,
            "finished_utc": now(),
            "exit_code": r.returncode,
            "stdout_bytes": len(r.stdout),
            "stdout_sha256": digest(r.stdout),
            "stderr": r.stderr.decode(),
        }
    )
    if r.returncode:
        raise RuntimeError(str(command) + ": " + r.stderr.decode())
    return r.stdout


def tree_records(revision):
    raw = git("ls-tree", "-r", "-z", revision, "--", "data/pathways")
    rows = {}
    for line in raw.split(b"\0"):
        if not line:
            continue
        metadata, path = line.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        name = path.decode()
        if name.endswith(".yaml"):
            rows[name] = {"mode": mode, "kind": kind, "oid": oid}
    return rows


if not RECEIPT.is_file():
    raise SystemExit("Root worktree receipt is not yet present. No Git command was run.")
(ROOT / "inputs/root-new-worktree-baseline.json").write_bytes(RECEIPT.read_bytes())
receipt_sha = digest(RECEIPT.read_bytes())
current = git("rev-parse", "HEAD").decode().strip()
merged_tree = git("rev-parse", MERGE + "^{tree}").decode().strip()
reviewed_tree = git("rev-parse", REVIEWED + "^{tree}").decode().strip()
check("actual worktree HEAD", current == MERGE, current)
check(
    "actual merge tree equals reviewed tree",
    merged_tree == reviewed_tree == "d2c58cc6e8c7a7650bdf8d4a91f69b2a54ff8bdb",
    merged_tree,
)
parents = git("rev-list", "--parents", "-n", "1", MERGE).decode().split()
check("actual merge has prior267 sole parent", parents == [MERGE, BASE], parents)
status_before = git("status", "--porcelain=v1")
(ROOT / "worktree-status-before.stdout").write_bytes(status_before)
check("new worktree clean before baseline checks", not status_before)
prior = tree_records(BASE)
actual = tree_records(MERGE)
reviewed = tree_records(REVIEWED)
check(
    "prior267 and actual268 committed record inventories", len(prior) == 267 and len(actual) == 268
)
check(
    "only acetate added to committed record set",
    set(actual) - set(prior) == {"data/pathways/methanogenesis-from-acetate.yaml"}
    and set(prior) <= set(actual),
)
check("reviewed268 exact Git record tree", actual == reviewed)
discovery = json.loads((ROOT / "inputs/prior267-baseline.json").read_text())
old = {r["path"]: r for r in discovery["records"]}
check("discovery267 exact committed path inventory", set(old) == set(prior))
paths = sorted(actual)
requested = "".join(actual[path]["oid"] + "\n" for path in paths).encode()
payload = git("cat-file", "--batch", input_data=requested)
position = 0
records = []
candidate_members = {
    "MetaCyc:" + name
    for name in [
        "ETHAMLY-RXN",
        "ACETALD-DEHYDROG-RXN",
        "PHOSACETYLTRANS-RXN",
        "ACETATEKIN-RXN",
        "ALCOHOL-DEHYDROG-RXN",
    ]
}
candidate_root_ids = {"MetaCyc:PWY0-1477", "EcoCyc:PWY0-1477", "GO:0046336"}
candidate_labels = {
    "ethanolamine utilization",
    "ethanolamine catabolic process",
    "ethanolamine degradation",
    "ethanolamine catabolism",
    "ethanolamine breakdown",
}
families = {
    "15313": {"15313", "15314", "15315", "15316"},
    "23288": {"23288", "23289", "23290", "23291"},
    "19521": {"19521", "19522", "19523", "19524"},
    "11352": {"11352", "11353", "11354", "11355"},
    "25290": {"25290", "25291", "25292", "25293"},
}
for path in paths:
    end = payload.index(b"\n", position)
    oid, kind, size = payload[position:end].decode().split()
    size = int(size)
    data = payload[end + 1 : end + 1 + size]
    position = end + 2 + size
    check(
        path + " complete committed blob",
        oid == actual[path]["oid"] and kind == "blob" and len(data) == size,
    )
    worktree_data = (WORKTREE / path).read_bytes()
    check(path + " actual worktree equals committed blob", worktree_data == data)
    if path in prior:
        check(path + " prior267 Git blob unchanged", prior[path] == actual[path])
        check(
            path + " discovery267 exact original bytes",
            digest(data) == old[path]["sha256"] and len(data) == old[path]["bytes"],
        )
    parsed = yaml.safe_load(data)
    declarations = (
        [parsed]
        + parsed.get("participants", [])
        + parsed.get("reactions", [])
        + parsed.get("taxa", [])
    )
    declared_ids = {item["id"] for item in declarations}
    references = {item["id"] for item in parsed.get("references", [])}
    overlaps = sorted(candidate_members & declared_ids)
    family_overlap = []
    for reaction in parsed.get("reactions", []):
        if reaction["id"].startswith("RHEA:"):
            rid = reaction["id"].split(":", 1)[1]
            for master, members in families.items():
                if rid in members:
                    family_overlap.append({"master": master, "reaction": reaction})
    root_match = parsed["id"] in candidate_root_ids
    label_match = parsed["label"].casefold() in candidate_labels
    check(path + " candidate root not maintained", not root_match and not label_match)
    records.append(
        {
            "path": path,
            "git_blob": oid,
            "bytes": size,
            "sha256": digest(data),
            "id": parsed["id"],
            "label": parsed["label"],
            "candidate_root_match": root_match,
            "candidate_label_match": label_match,
            "native_declared_member_overlap": overlaps,
            "native_reference_only_mentions": sorted(
                (candidate_members & references) - declared_ids
            ),
            "rhea_family_overlap": family_overlap,
            "description": parsed.get("description")
            if overlaps or family_overlap or "ethanol" in parsed["label"].casefold()
            else None,
            "taxa": parsed.get("taxa")
            if overlaps or family_overlap or "ethanol" in parsed["label"].casefold()
            else None,
        }
    )
check("complete batch payload consumed", position == len(payload))
actual_physical = {
    str(p.relative_to(WORKTREE))
    for p in (WORKTREE / "data/pathways").rglob("*")
    if p.is_file() and p.suffix in {".yaml", ".yml"}
}
check(
    "all hidden/ignored physical maintained YAML enumerated",
    actual_physical == set(actual),
    sorted(actual_physical - set(actual)),
)
accepted = json.loads((ROOT / "inputs/accepted-PR633-stage.json").read_text())
accepted_files = {r["path"]: r for r in accepted["files"]}
acetate_path = "data/pathways/methanogenesis-from-acetate.yaml"
acetate = next(r for r in records if r["path"] == acetate_path)
check(
    "acetate equals accepted review bytes",
    acetate["sha256"]
    == accepted_files[acetate_path]["sha256"]
    == "47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3",
)
pending_coverage = json.loads(
    (ROOT / "inputs/historical-core-authority-coverage.json").read_text()
)[1]
sources_path = "data/identifier_authorities/sources.json"
sources_data = (WORKTREE / sources_path).read_bytes()
check(
    "actual source snapshot equals previously pending reviewed snapshot",
    digest(sources_data)
    == pending_coverage["snapshot_sha256"]
    == accepted_files[sources_path]["sha256"],
)
check(
    "actual source snapshot equals committed blob",
    sources_data == git("show", MERGE + ":" + sources_path),
)
sources = json.loads(sources_data)
coverage = []
for historical in pending_coverage["core"]:
    key = historical["id"]
    term = sources["terms"].get(key)
    present = term is not None
    check(
        key + " pending authority inventory rebound",
        present == historical["present"] and term == historical["term"],
    )
    coverage.append(
        {
            "id": key,
            "present": present,
            "term": term,
            "scope": "Inventory only; not new scientific or issuing-identity acceptance.",
        }
    )
check(
    "actual authority 13 of core20",
    len(coverage) == 20 and sum(row["present"] for row in coverage) == 13,
)
binding = []
for path in [
    "conf/identifier_sources.json",
    "data/identifier_authorities/ontology.json",
    "src/pathwaymech/biocyc_acetate_methanogenesis.py",
    "docs/CAUSAL_GRAPHS.md",
]:
    data = (WORKTREE / path).read_bytes()
    check(path + " accepted reviewed binding", digest(data) == accepted_files[path]["sha256"])
    check(path + " committed binding", data == git("show", MERGE + ":" + path))
    binding.append({"path": path, "sha256": digest(data), "bytes": len(data)})
status_after = git("status", "--porcelain=v1")
(ROOT / "worktree-status-after-baseline.stdout").write_bytes(status_after)
check("new worktree clean after baseline checks", not status_after)
result = {
    "observed_utc": now(),
    "actual_merge": MERGE,
    "actual_tree": merged_tree,
    "prior267_base": BASE,
    "reviewed_head": REVIEWED,
    "root_receipt_sha256": receipt_sha,
    "checks": checks,
    "all_passed": all(c["pass"] for c in checks),
    "records": records,
    "actual_core_authority_inventory": coverage,
    "other_reviewed_bindings": binding,
    "pending_to_actual_disposition": (
        "The prospective 268-record scope is now exactly the actual merged 268-record baseline. "
        "All prior 267 records unchanged. Thirteen of the native core 20 IDs are inventoried "
        "in the actual snapshot; this does not approve new identifiers, a graph or biological flux."
    ),
}
(ROOT / "baseline-rebind-result.json").write_text(json.dumps(result, indent=2) + "\n")
(ROOT / "baseline-git-read-receipts.json").write_text(json.dumps(commands, indent=2) + "\n")
print(
    json.dumps(
        {
            "checks": len(checks),
            "all_passed": result["all_passed"],
            "records": len(records),
            "failed": [c for c in checks if not c["pass"]],
        },
        indent=2,
    )
)
