"""Bounded duplicate search in the actual merged worktree, including ignored files."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKTREE = Path("/private/tmp/pathwaymech-next-272-20261015")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def hits(data, patterns):
    text = data.decode("utf-8", errors="replace").casefold()
    result = []
    for pattern in patterns:
        value = pattern.casefold()
        count = text.count(value)
        if not count:
            continue
        contexts = []
        start = 0
        for _ in range(min(count, 5)):
            index = text.index(value, start)
            contexts.append(
                {
                    "character_offset": index,
                    "context": text[max(0, index - 140) : index + len(value) + 180],
                }
            )
            start = index + len(value)
        result.append(
            {"pattern": pattern, "count": count, "contexts": contexts, "context_limit": 5}
        )
    return result


baseline = json.loads((ROOT / "baseline-rebind-result.json").read_text())
if not baseline["all_passed"]:
    raise SystemExit("Baseline rebind must pass before this search.")
patterns = (ROOT / "inputs/candidate-search-patterns.txt").read_text().splitlines()
for value in [
    "MetaCyc:PWY0-1477",
    "EcoCyc:PWY0-1477",
    "META:PWY0-1477",
    "ECOLI:PWY0-1477",
    "ethanolamine-utilization",
    "ethanolamine-catabolism",
    "ethanolamine-degradation",
]:
    if value not in patterns:
        patterns.append(value)
for family in [
    range(15313, 15317),
    range(23288, 23292),
    range(19521, 19525),
    range(11352, 11356),
    range(25290, 25294),
]:
    for value in family:
        patterns.append("RHEA:" + str(value))
(ROOT / "effective-search-patterns.txt").write_text("\n".join(patterns) + "\n")
command = [
    "rg",
    "--no-ignore",
    "--hidden",
    "-l",
    "-i",
    "-F",
    "-f",
    str(ROOT / "effective-search-patterns.txt"),
    "-g",
    "!.git",
    "-g",
    "!.venv",
    ".",
]
started = datetime.now(UTC).isoformat()
r = subprocess.run(command, cwd=WORKTREE, capture_output=True)
(ROOT / "ordinary-search.stdout").write_bytes(r.stdout)
(ROOT / "ordinary-search.stderr").write_bytes(r.stderr)
if r.returncode not in (0, 1):
    raise RuntimeError(r.stderr.decode())
matches = []
for relative in r.stdout.decode().splitlines():
    path = WORKTREE / relative
    data = path.read_bytes()
    matches.append(
        {
            "path": relative.removeprefix("./"),
            "bytes": len(data),
            "sha256": digest(data),
            "hits": hits(data, patterns),
        }
    )
ordinary = {
    "started_utc": started,
    "finished_utc": datetime.now(UTC).isoformat(),
    "root": str(WORKTREE),
    "commit": baseline["actual_merge"],
    "command": command,
    "exit_code": r.returncode,
    "patterns": patterns,
    "matches": matches,
    "scope": (
        "Hidden and ignored ordinary text included. Git metadata and .venv excluded. "
        "Ripgrep default binary handling; no external symlink traversal. Container interiors "
        "require the separately stated finite decoding scope. Bare numeric substrings are leads, "
        "not exact identifiers."
    ),
}
(ROOT / "ordinary-search-result.json").write_text(json.dumps(ordinary, indent=2) + "\n")

inventory = []
symlinks = []
for path in WORKTREE.rglob("*"):
    relative = path.relative_to(WORKTREE)
    if any(part in (".git", ".venv") for part in relative.parts):
        continue
    if path.is_symlink():
        symlinks.append({"path": str(relative), "target": os.readlink(path)})
        continue
    if path.is_file() and path.suffix.lower() in {".gz", ".zip", ".xz", ".bz2", ".zst", ".tar"}:
        data = path.read_bytes()
        inventory.append({"path": str(relative), "bytes": len(data), "sha256": digest(data)})
(ROOT / "archive-physical-inventory.json").write_text(
    json.dumps(
        {
            "scope": (
                "Physical recognized container bytes only, including hidden/ignored files except "
                "Git metadata and .venv. No interior-search claim from inventory."
            ),
            "files": inventory,
            "symlinks_not_followed": symlinks,
        },
        indent=2,
    )
    + "\n"
)
historical = json.loads((ROOT / "inputs/historical-selected-compressed-search.json").read_text())
selected = []
for row in historical["files"]:
    path = WORKTREE / row["path"]
    data = path.read_bytes()
    assert digest(data) == row["sha256"]
    decoded = gzip.decompress(data)
    assert digest(decoded) == row["decoded_sha256"]
    selected.append(
        {
            "path": row["path"],
            "bytes": len(data),
            "sha256": digest(data),
            "decoded_bytes": len(decoded),
            "decoded_sha256": digest(decoded),
            "hits": hits(decoded, patterns),
        }
    )
assert len(selected) == 116
selected_result = {
    "scope": (
        "Exactly the 116 inherited selected gzip payloads were rehashed, fully decoded and freshly "
        "searched using the complete effective pattern list. Other and nested interiors remain "
        "unsearched. No global historical, synonym, pathway or source exhaustion "
        "conclusion follows."
    ),
    "files": selected,
}
(ROOT / "selected-compressed-search-result.json").write_text(
    json.dumps(selected_result, indent=2) + "\n"
)

root_patterns = {
    "PWY0-1477",
    "ethanolamine utilization",
    "MetaCyc:PWY0-1477",
    "EcoCyc:PWY0-1477",
    "META:PWY0-1477",
    "ECOLI:PWY0-1477",
    "ethanolamine-utilization",
}
exact_root_leads = []
for source, rows in [("ordinary", matches), ("selected-gzip", selected)]:
    for row in rows:
        chosen = [hit for hit in row["hits"] if hit["pattern"] in root_patterns]
        if chosen:
            exact_root_leads.append(
                {"scope": source, "path": row["path"], "sha256": row["sha256"], "hits": chosen}
            )
(ROOT / "exact-root-search-leads.json").write_text(json.dumps(exact_root_leads, indent=2) + "\n")
summary = {
    "patterns": len(patterns),
    "ordinary_matching_files": len(matches),
    "physical_containers": len(inventory),
    "physical_container_bytes": sum(x["bytes"] for x in inventory),
    "selected_gzip_count": len(selected),
    "selected_compressed_bytes": sum(x["bytes"] for x in selected),
    "selected_decoded_bytes": sum(x["decoded_bytes"] for x in selected),
    "selected_matching_payloads": sum(bool(x["hits"]) for x in selected),
    "exact_root_lead_objects": len(exact_root_leads),
    "no_global_exhaustion_claim": True,
}
(ROOT / "search-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
