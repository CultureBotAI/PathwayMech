"""Read-only finite replay; reuse completed full-file hashes with unchanged stat proof."""

import hashlib
import json
import runpy
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = []


def read(path):
    return json.loads((ROOT / path).read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(name, condition):
    if not condition:
        raise ValueError(name)
    checks.append(name)


for entry in read("results/baseline-bindings.json"):
    check(
        entry["local"] + " exact baseline copy",
        digest(Path(entry["source"])) == entry["sha256"] == digest(ROOT / entry["local"]),
    )
for entry in read("results/context-bindings.json"):
    parent = Path(entry["owner"])
    check(
        entry["source_path"] + " original context",
        digest(parent / entry["source_path"])
        == entry["sha256"]
        == digest(ROOT / entry["local_path"]),
    )
    check(
        entry["source_path"] + " context owner binding",
        digest(parent / "artifact-manifest.json") == entry["parent_manifest_sha256"],
    )
api = runpy.run_path(str(ROOT / "inputs/extractor.py.txt"))
snapshot = read("results/exact-eight-term-extraction.json")
baseline = read("inputs/ontology-baseline.json")
for source in read("results/source-verification.json"):
    path = Path(source["database"])
    stat = path.stat()
    check(
        path.name + " stable size/mtime",
        source["before"]
        == source["after"]
        == {"bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns},
    )
    check(
        path.name + " completed full-file hash",
        source["full_database_hash_matches"]
        and source["source"]["sha256"] == source["expected_full_database_sha256"]
        and source["source"]["sha256_scope"] == "uncompressed_semantic_sql_database",
    )
    key = next(key for key, value in snapshot["sources"].items() if value == source["source"])
    check(path.name + " exact pinned metadata", source["source"] == baseline["sources"][key])
    with sqlite3.connect(source["connection_uri"], uri=True) as connection:
        connection.execute("PRAGMA query_only=ON")
        terms, missing = api["extract_terms"](connection, source["selected_ids"], key)
        check(
            path.name + " unchanged extractor replay",
            not missing
            and terms
            == {identifier: snapshot["terms"][identifier] for identifier in source["selected_ids"]},
        )
        data = read("results/" + key.split("-")[0] + "-complete-statements.json")
        columns = [row[1] for row in connection.execute("PRAGMA table_info(statements)")]
        check(path.name + " all statement columns", columns == data["statement_columns"])
        for identifier, item in data["selection"].items():
            for field, name in [
                ("subject", "subject_statements"),
                ("stanza", "complete_stanza_statements"),
            ]:
                rows = [
                    dict(zip(columns, row, strict=True))
                    for row in connection.execute(
                        f"SELECT * FROM statements WHERE {field}=?", (identifier,)
                    ).fetchall()
                ]
                ordered = sorted(rows, key=lambda row: json.dumps(row, sort_keys=True))
                check(identifier + " " + name, ordered == item[name])
        for field, name in [
            ("subject", "ontology_subject_statements"),
            ("stanza", "ontology_stanza_statements"),
        ]:
            rows = [
                dict(zip(columns, row, strict=True))
                for row in connection.execute(
                    f"SELECT * FROM statements WHERE {field}=?", (data["ontology_subject"],)
                ).fetchall()
            ]
            check(
                path.name + " " + name,
                sorted(rows, key=lambda row: json.dumps(row, sort_keys=True)) == data[name],
            )
        check(
            path.name + " prefix table",
            [list(row) for row in sorted(connection.execute("SELECT * FROM prefix").fetchall())]
            == data["prefix_table"],
        )
for control in read("results/control-comparison.json"):
    check(
        control["id"] + " control exact",
        control["baseline"]
        == control["extracted"]
        == baseline["terms"][control["id"]]
        == snapshot["terms"][control["id"]],
    )
proposal = read("results/proposed-ontology.json")
delta = read("results/four-term-additive-proposal.json")
check(
    "only four additions",
    set(proposal["terms"]) - set(baseline["terms"])
    == set(delta["terms_added"])
    == {"GO:0031471", "GO:0031469", "CHEBI:16000", "NCBITaxon:99287"},
)
check(
    "all baseline terms unchanged",
    all(proposal["terms"][k] == v for k, v in baseline["terms"].items()),
)
check("all baseline sources unchanged", proposal["sources"] == baseline["sources"])
check(
    "additions exact extractor results",
    all(snapshot["terms"][k] == v for k, v in delta["terms_added"].items()),
)
check(
    "all proposal non-term data unchanged",
    {k: v for k, v in proposal.items() if k != "terms"}
    == {k: v for k, v in baseline.items() if k != "terms"},
)
print(
    json.dumps(
        {
            "status": "pass",
            "checks": checks,
            "count": len(checks),
            "full_hashes_repeated": False,
            "scope": "Author replay of selected SQL statements, controls and additive proposal; "
            "full file hashes were completed by unchanged read_source during preparation. "
            "This is not independent acceptance.",
        },
        indent=2,
    )
)
