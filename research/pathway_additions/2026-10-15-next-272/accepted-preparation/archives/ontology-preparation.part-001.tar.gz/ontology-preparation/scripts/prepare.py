"""Prepare eight selected terms and a four-term proposal from pinned immutable SQL."""

import hashlib
import json
import runpy
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE = Path("/private/tmp/pathwaymech-next-272-20261015")
DATABASES = Path("/private/tmp/pathwaymech-curation-authorities")
SPECS = [
    (
        "GO",
        "go.db",
        "018a7ef0a5bd1c0767abc3d71b413264a25be7579533daf5349f739cd9a122cd",
        ["GO:0031471", "GO:0031469", "GO:0005737"],
        ["GO:0043232"],
    ),
    (
        "CHEBI",
        "chebi.db",
        "26ad4890cdcf6ee357760d815dfee8f5ba81e0873e62cb379369b04205722b0f",
        ["CHEBI:16000", "CHEBI:57603"],
        [],
    ),
    (
        "NCBITaxon",
        "ncbitaxon.db",
        "89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d",
        ["NCBITaxon:99287", "NCBITaxon:511145", "NCBITaxon:83333"],
        ["NCBITaxon:strain", "TAXRANK:0001001", "NCBITaxon:90371"],
    ),
]
PROPOSED = ["GO:0031471", "GO:0031469", "CHEBI:16000", "NCBITaxon:99287"]
CONTROLS = ["GO:0005737", "CHEBI:57603", "NCBITaxon:511145", "NCBITaxon:83333"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    (ROOT / path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def stat(path):
    value = path.stat()
    return {"bytes": value.st_size, "mtime_ns": value.st_mtime_ns}


bindings = []
for relative, local in [
    ("scripts/build_ontology_identifier_snapshot.py", "extractor.py.txt"),
    ("data/identifier_authorities/ontology.json", "ontology-baseline.json"),
    ("pyproject.toml", "pyproject.toml"),
]:
    source = BASELINE / relative
    target = ROOT / "inputs" / local
    if target.exists():
        raise ValueError("Preparation cannot overwrite captured inputs")
    target.write_bytes(source.read_bytes())
    bindings.append(
        {
            "source": str(source),
            "local": str(target.relative_to(ROOT)),
            "sha256": digest(source),
            "bytes": source.stat().st_size,
        }
    )
dump("results/baseline-bindings.json", bindings)
baseline = json.loads((ROOT / "inputs/ontology-baseline.json").read_text())
if any(identifier in baseline["terms"] for identifier in PROPOSED):
    raise ValueError("Proposed addition already exists in exact baseline term map")
if any(identifier not in baseline["terms"] for identifier in CONTROLS):
    raise ValueError("Control must already exist in exact baseline term map")
api = runpy.run_path(str(ROOT / "inputs/extractor.py.txt"))
snapshot = {"version": 1, "sources": {}, "terms": {}}
source_checks = []
for prefix, filename, expected_hash, selected, context in SPECS:
    path = DATABASES / filename
    before = stat(path)
    started = datetime.now(UTC).isoformat()
    print(f"{prefix}: opened immutable database; hashing complete source", flush=True)
    uri = path.resolve().as_uri() + "?mode=ro&immutable=1"
    with sqlite3.connect(uri, uri=True) as connection:
        connection.execute("PRAGMA query_only=ON")
        source = api["read_source"](connection, path)
        if source["sha256"] != expected_hash:
            raise ValueError(f"{prefix}: full database hash mismatch")
        source_key = f"{prefix.lower()}-{source['version']}"
        if source != baseline["sources"][source_key]:
            raise ValueError(f"{prefix}: metadata differs from pinned baseline")
        terms, missing = api["extract_terms"](connection, selected, source_key)
        if missing:
            raise ValueError(f"{prefix}: unresolved identifiers: {missing}")
        columns = [row[1] for row in connection.execute("PRAGMA table_info(statements)")]

        def statements(field, identifier, connection=connection, columns=columns):
            if field not in {"subject", "stanza"}:
                raise ValueError("Unsupported selector")
            rows = connection.execute(
                f"SELECT * FROM statements WHERE {field}=?", (identifier,)
            ).fetchall()
            values = [dict(zip(columns, row, strict=True)) for row in rows]
            return sorted(values, key=lambda row: json.dumps(row, sort_keys=True))

        sets = {}
        for identifier in selected + context:
            sets[identifier] = {
                "role": "selected_or_control" if identifier in selected else "context_only",
                "subject_statements": statements("subject", identifier),
                "complete_stanza_statements": statements("stanza", identifier),
            }
        declarations = connection.execute(
            "SELECT subject, object FROM statements WHERE predicate='owl:versionIRI'"
        ).fetchall()
        if len(declarations) != 1:
            raise ValueError("Expected one ontology version declaration")
        ontology = declarations[0][0]
        dump(
            f"results/{prefix.lower()}-complete-statements.json",
            {
                "database": str(path),
                "source": source,
                "statement_columns": columns,
                "table_schema": connection.execute("PRAGMA table_info(statements)").fetchall(),
                "selection": sets,
                "ontology_subject": ontology,
                "ontology_subject_statements": statements("subject", ontology),
                "ontology_stanza_statements": statements("stanza", ontology),
                "prefix_table": sorted(connection.execute("SELECT * FROM prefix").fetchall()),
                "scope": "All columns/rows for exact subjects and complete stanzas; duplicates "
                "retained. Context terms are not proposed authority additions.",
            },
        )
        repeated, unresolved = api["extract_terms"](connection, selected, source_key)
        if repeated != terms or unresolved:
            raise ValueError("Same-connection extraction replay differs")
    after = stat(path)
    if before != after:
        raise ValueError(f"{prefix}: database size or mtime changed")
    snapshot["sources"][source_key] = source
    snapshot["terms"].update(terms)
    source_checks.append(
        {
            "database": str(path),
            "connection_uri": uri,
            "query_only": True,
            "before": before,
            "after": after,
            "unchanged": True,
            "source": source,
            "expected_full_database_sha256": expected_hash,
            "full_database_hash_matches": True,
            "metadata_exactly_matches_baseline": True,
            "started_utc": started,
            "finished_utc": datetime.now(UTC).isoformat(),
            "selected_ids": selected,
            "context_only_ids": context,
            "read_source_and_extract_terms_unchanged": True,
            "one_live_connection_for_hash_metadata_statements_and_replay": True,
        }
    )
    dump("results/source-verification.json", source_checks)
    print(f"{prefix}: full hash, metadata and extraction pass; handle closed", flush=True)
controls = []
for identifier in CONTROLS:
    term = snapshot["terms"][identifier]
    expected = baseline["terms"][identifier]
    if term != expected:
        raise ValueError(f"{identifier}: control differs")
    controls.append({"id": identifier, "extracted": term, "baseline": expected, "equal": True})
dump("results/control-comparison.json", controls)
dump("results/exact-eight-term-extraction.json", snapshot)
additions = {identifier: snapshot["terms"][identifier] for identifier in PROPOSED}
dump(
    "results/four-term-additive-proposal.json",
    {
        "baseline_sha256": digest(ROOT / "inputs/ontology-baseline.json"),
        "sources_added": {},
        "sources_modified": {},
        "terms_added": additions,
        "terms_modified": {},
        "terms_removed": {},
        "scope": "Four-term proposal subject to final graph selection and independent review.",
    },
)
proposal = json.loads(json.dumps(baseline))
proposal["terms"].update(additions)
if {k: v for k, v in proposal["terms"].items() if k not in PROPOSED} != baseline["terms"]:
    raise ValueError("Existing terms changed")
if proposal["sources"] != baseline["sources"]:
    raise ValueError("Source metadata changed")
dump("results/proposed-ontology.json", proposal)
dump(
    "results/extraction-summary.json",
    {
        "baseline_term_count": len(baseline["terms"]),
        "proposed_term_count": len(proposal["terms"]),
        "proposed_additions": PROPOSED,
        "unchanged_control_ids": CONTROLS,
        "existing_terms_changed": 0,
        "source_entries_changed": 0,
        "existing_terms_all_exactly_preserved": True,
        "all_jobs_terminal": True,
        "absence_scope": "Complete exact baseline JSON term map; no repository-wide absence claim.",
        "full_database_bytes_hashed": sum(c["before"]["bytes"] for c in source_checks),
        "independent_acceptance": False,
    },
)
print("Finite four-term preparation complete; independent review required", flush=True)
