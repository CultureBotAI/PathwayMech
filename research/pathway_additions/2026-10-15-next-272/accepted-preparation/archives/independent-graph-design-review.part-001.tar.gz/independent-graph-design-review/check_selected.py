"""Independent final selected design checks, reading retained bytes only."""

import argparse
import ast
import collections
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.root
    checks = []

    def check(label, actual, expected=True):
        checks.append(
            {"check": label, "pass": actual == expected, "actual": actual, "expected": expected}
        )

    def read(name):
        return json.loads((root / name).read_text())

    graph = read("results/recommended-selected-graph-payload.json")
    nodes = read("results/node-ledger.json")
    declared = {row["id"]: row for row in nodes if row["proposed_declaration"]}
    edges = graph["mechanistic_edges"]
    source_edges = [r["graph_edge"] for r in read("results/edge-ledger.json")]
    options = read("results/conditional-edge-options.json") + read(
        "results/alternative-activity-options.json"
    )
    option_edges = {r["graph_edge"]["id"]: r["graph_edge"] for r in options}
    selected = {
        r["edge_id"]: r["graph_edge"] for r in read("results/recommended-option-selection.json")
    }
    by_id = {r["id"]: r for r in edges}
    check("selected edge count", len(edges), 97)
    check("unique edge IDs", len(by_id), 97)
    check("source edge count", len(source_edges), 78)
    check("all 19 option payloads selected exactly", selected == option_edges)
    check(
        "selected payload is exact source plus option union",
        by_id == {e["id"]: e for e in source_edges + list(option_edges.values())},
    )
    payload_nodes = [*graph["participants"], *graph["reactions"], *graph["taxa"]]
    check("128 selected declarations", len(payload_nodes) + 1, 128)
    check(
        "selected IDs agree with node ledger",
        {r["id"] for r in payload_nodes} | {graph["id"]} == set(declared),
    )
    check(
        "authority needs are exactly declared IDs",
        {r["curie"] for r in read("results/selected-authority-needs.json")["rows"]}
        == set(declared),
    )
    refs = {r["id"]: r for r in graph["references"]}
    check("reference IDs unique", len(refs), len(graph["references"]))
    schema = Path("/private/tmp/pathwaymech-next-272-20261015/src/pathwaymech/schema.py")
    enums = {}
    for statement in ast.parse(schema.read_text()).body:
        if isinstance(statement, ast.Assign) and isinstance(statement.targets[0], ast.Name):
            name = statement.targets[0].id
            if name in {"ALLOWED_EDGE_PREDICATES", "NODE_CATEGORIES"}:
                enums[name] = ast.literal_eval(statement.value)
    for edge in edges:
        key = edge["id"]
        check(f"endpoints {key}", edge["subject"] in declared and edge["object"] in declared)
        check(f"predicate {key}", edge["predicate"] in enums["ALLOWED_EDGE_PREDICATES"])
        evidence = list(edge["evidence"])
        qualifiers = edge.get("endpoint_qualifiers", [])
        check(
            f"qualifier role uniqueness {key}",
            len({q["endpoint"] for q in qualifiers}),
            len(qualifiers),
        )
        for qualifier in qualifiers:
            check(
                f"qualifier exact protein/complex scope {key}/{qualifier['endpoint']}",
                declared[edge[qualifier["endpoint"]]]["category"] in {"protein", "complex"},
            )
            check(
                f"qualifier description bounds {key}/{qualifier['endpoint']}",
                0 < len(qualifier["description"]) <= 400,
            )
            check(
                f"qualifier kind {key}/{qualifier['endpoint']}",
                qualifier["kind"] in {"molecular_state", "experimental_construct"},
            )
            evidence.extend(qualifier["evidence"])
        for i, ev in enumerate(evidence):
            check(f"evidence reference {key}/{i}", ev["reference_id"] in refs)
            fields = [f for f in ("quote", "source_assertion") if f in ev]
            check(f"exact one assertion field {key}/{i}", len(fields), 1)
            check(f"assertion bounds {key}/{i}", 0 < len(ev[fields[0]]) <= 400)
            check(f"evidence locator {key}/{i}", bool(ev.get("source_locator")))
    for row in read("results/conditional-source-closure.json"):
        check(f"conditional source bytes {row['path']}", digest(Path(row["path"])), row["sha256"])
    source_rows = {r["reference_id"]: r for r in read("results/source-closure.json")}
    supplement = read("results/supplemental16-native-slot-design-dispositions.json")
    native_row = source_rows["EcoCyc:ETHAMLY-CPLX"]
    native_path = Path(native_row["owner"]) / native_row["path"]
    native = ET.parse(native_path).getroot().find("Protein[@frameid='ETHAMLY-CPLX']")
    check("exact EutA target object", native.get("orgid"), "ECOLI")
    check("supplement all own slots", len(supplement), len(native))
    check("supplement 16 own slots", len(native), 16)
    counts = collections.Counter()
    expected = {}
    for child in native:
        counts[child.tag] += 1
        loc = f"/ptools-xml/Protein[@frameid='ETHAMLY-CPLX']/{child.tag}[{counts[child.tag]}]"
        expected[loc] = ET.tostring(child, encoding="unicode")
    check("supplement exact locator coverage", set(expected) == {r["locator"] for r in supplement})
    for row in supplement:
        check(
            f"supplement slot bytes {row['locator']}", row["source_xml"], expected[row["locator"]]
        )
        check(
            f"supplement source digest {row['locator']}", row["source_sha256"], digest(native_path)
        )
        check(
            f"supplement semantic disposition {row['locator']}",
            bool(row["accepted_semantic_disposition"]),
        )
    components = {
        e["object"]: e
        for e in source_edges
        if e["predicate"] == "has_part" and e["subject"] == "EcoCyc:ETHAMLY-CPLX"
    }
    check(
        "EcoCyc target exact two subunits",
        set(components) == {"EcoCyc:EUTB-MONOMER", "EcoCyc:EUTC-MONOMER"},
    )
    check(
        "EcoCyc target both native coefficients six",
        [c.findtext("coefficient") for c in native.findall("component")],
        ["6", "6"],
    )
    protein_rows = read("biology-audit/protein-design-ledger.json")
    total_comments = 0
    for row in protein_rows:
        data = json.loads(Path(row["identity_source"]["path"]).read_text())
        comments = row["comment_evidence_bindings"]
        total_comments += len(comments)
        check(f"full comment count {row['id']}", len(comments), len(data.get("comments", [])))
        for i, binding in enumerate(comments):
            check(
                f"comment locator {row['id']}/{i}", binding["source"]["locator"], f"/comments/{i}"
            )
            check(
                f"comment type {row['id']}/{i}",
                binding["comment_type"],
                data["comments"][i]["commentType"],
            )
    check("298 full protein comment bindings", total_comments, 298)
    primary = read("biology-audit/primary-claim-design-ledger.json")
    check("32 primary claim dispositions", len(primary), 32)
    for row in primary:
        check(f"primary disposition {row['id']}", bool(row["recommendation"]))
        for binding in row["original_artifact_bindings"]:
            check(
                f"primary retained bytes {row['id']}/{binding['path']}",
                digest(Path(binding["path"])),
                binding["sha256"],
            )
    snapshots = {}
    for name in ["sources", "ontology"]:
        data = json.loads(
            (root / "baseline/data/identifier_authorities" / f"{name}.json").read_text()
        )
        snapshots.update(data["terms"])
    current_ids = set(declared) & set(snapshots)
    check("27 declared IDs already owned", len(current_ids), 27)
    for key in current_ids:
        check(
            f"preserve existing canonical label {key}",
            declared[key]["label"],
            snapshots[key]["label"],
        )
    for row in payload_nodes:
        check(
            f"payload label equals ledger {row['id']}", row["label"], declared[row["id"]]["label"]
        )
    historical = json.loads(
        (args.output.parent / "pre-freeze-final-independent-selected-checks.json").read_text()
    )
    previous = {row["check"]: row for row in historical["checks"]}
    concurrent_changes = []
    for row in read("results/baseline-file-rebind.json")["checks"]:
        prior = previous[f"actual merged file bytes {row['worktree_path']}"]
        check(
            f"independently observed baseline bytes {row['worktree_path']}",
            prior["pass"] and prior["actual"] == row["sha256"],
        )
        check(
            f"design baseline bytes {row['baseline_file']}",
            digest(root / row["baseline_file"]),
            row["sha256"],
        )
        current = digest(Path(row["worktree_path"]))
        if current != row["sha256"]:
            concurrent_changes.append(
                {"path": row["worktree_path"], "baseline": row["sha256"], "current": current}
            )
    cargo = by_id["option-eutc19-egfp-native-host-location"]
    check(
        "cargo exact endpoints",
        [cargo["subject"], cargo["predicate"], cargo["object"]],
        ["UniProtKB:P19265", "located_in", "GO:0031471"],
    )
    qualifier = cargo["endpoint_qualifiers"][0]
    check("cargo construct qualifier", qualifier["kind"], "experimental_construct")
    check(
        "cargo issued identity survives in qualifier",
        any(
            e["reference_id"] == "UniProtKB:P19265" and "/sequence/value" in e["source_locator"]
            for e in qualifier["evidence"]
        ),
    )
    source = Path(
        "/private/tmp/pathwaymech-next-272-primary-evidence-preparation/originals/cargo-2012-primary.xml"
    )
    article = ET.parse(source).getroot()
    methods = "".join(article.find("body[1]/sec[4]/sec[2]/p[1]").itertext())
    entry = json.loads(
        Path(
            "/private/tmp/pathwaymech-next-272-native-source-preparation/originals/UniProt-P19265.json"
        ).read_text()
    )
    check("cargo issued exact 19-residue primary motif", entry["sequence"]["value"][:19] in methods)
    check("cargo issued taxon", entry["organism"]["taxonId"], 99287)
    check("cargo LT2 primary source scope", "S. enterica LT2" in methods)
    check("cargo codon optimization retained", "codon" in qualifier["description"])
    gtp = [e for e in option_edges.values() if e["predicate"] == "has_input"]
    check("two alternative GTP activity inputs", len(gtp), 2)
    for edge in gtp:
        check(
            f"GTP exact tag and host scope in payload {edge['id']}",
            "BL21" in edge["description"]
            and "LT2" in edge["description"]
            and "Mg" in edge["description"],
        )
    result = {
        "scope": "Finite independent checks; scientific acceptance is separately reasoned.",
        "checks": checks,
        "all_passed": all(c["pass"] for c in checks),
        "concurrent_worktree_changes": concurrent_changes,
        "baseline_scope": (
            "Frozen copies match independently observed pre-implementation baseline bytes. "
            "Concurrent worktree edits are separate and are not accepted by this design review."
        ),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "checks": len(checks),
                "all_passed": result["all_passed"],
                "failed": [c for c in checks if not c["pass"]],
            }
        )
    )


if __name__ == "__main__":
    main()
