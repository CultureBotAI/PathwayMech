"""Bind a frozen author packet and copy only bounded review inputs."""

import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest_sha")
    parser.add_argument("handoff_sha")
    parser.add_argument("freeze_sha")
    args = parser.parse_args()
    author = Path("/private/tmp/pathwaymech-next-272-graph-design")
    owner = Path("/private/tmp/pathwaymech-next-272-independent-graph-design-review")
    expected = {
        "artifact-manifest.json": args.manifest_sha,
        "HANDOFF.md": args.handoff_sha,
        "freeze-proof.json": args.freeze_sha,
    }
    checks = []

    def check(key, actual, wanted):
        checks.append(
            {"check": key, "pass": actual == wanted, "actual": actual, "expected": wanted}
        )

    for name, value in expected.items():
        check(name, sha(author / name), value)
    manifest = json.loads((author / "artifact-manifest.json").read_text())
    rows = manifest["files"]
    physical = sorted(str(p.relative_to(author)) for p in author.rglob("*") if p.is_file())
    excluded = manifest.get("excluded_files", ["artifact-manifest.json", "freeze-proof.json"])
    check(
        "exact physical file inventory including hidden/ignored",
        sorted(set(physical) - set(excluded)),
        sorted(r["path"] for r in rows),
    )
    for row in rows:
        path = author / row["path"]
        check("bytes " + row["path"], path.stat().st_size, row["bytes"])
        check("digest " + row["path"], sha(path), row["sha256"])
    assert all(c["pass"] for c in checks), "Frozen author intake failed"
    copied = []
    for path in author.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(author)
        parts = rel.parts
        choose = len(parts) == 1 or parts[0] == "results"
        choose = choose or (parts[0] == "biology-audit" and path.suffix in {".json", ".md"})
        choose = choose or (
            parts[0] == "authority-audit" and len(parts) == 2 and path.suffix in {".json", ".md"}
        )
        if not choose:
            continue
        target = owner / "final-author-inputs" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        copied.append(
            {
                "original": str(path),
                "copy": str(target.relative_to(owner)),
                "bytes": target.stat().st_size,
                "sha256": sha(target),
            }
        )
    result = {
        "author_owner": str(author),
        "frozen_bindings": expected,
        "listed_file_count": len(rows),
        "physical_file_count": len(physical),
        "checks": checks,
        "all_passed": True,
        "copied_inputs": copied,
        "scope": "Full physical digest verification; bounded input copy; no source corpus copy.",
    }
    (owner / "final-author-intake.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "checks": len(checks),
                "listed": len(rows),
                "physical": len(physical),
                "copied": len(copied),
            }
        )
    )


if __name__ == "__main__":
    main()
