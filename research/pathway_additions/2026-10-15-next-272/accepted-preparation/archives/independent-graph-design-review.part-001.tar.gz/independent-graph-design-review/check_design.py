"""Independent finite ledger/source checks; writes only a requested scratch result."""

import argparse
import ast
import collections
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.inputs
    checks = []

    def check(key, actual, expected=True):
        checks.append(
            {"check": key, "pass": actual == expected, "actual": actual, "expected": expected}
        )

    def read(name):
        return json.loads((root / name).read_text())

    edges = read("results/edge-ledger.json")
    nodes = read("results/node-ledger.json")
    slots = read("results/all3689-native-slot-design-dispositions.json")
    base_slot_sources = {row["source_id"] for row in slots}
    closure = read("results/source-closure.json")
    source_by_id = {row["reference_id"]: row for row in closure}
    declared = {row["id"]: row for row in nodes if row["proposed_declaration"]}
    edge_by_id = {row["graph_edge"]["id"]: row["graph_edge"] for row in edges}
    check("all node IDs unique", len({row["id"] for row in nodes}), len(nodes))
    check("all edge IDs unique", len(edge_by_id), len(edges))
    check("all source IDs unique", len(source_by_id), len(closure))

    raw = {}
    native = {}
    expected_slots = {}
    for row in closure:
        path = Path(row["owner"]) / row["path"]
        data = path.read_bytes()
        check(f"source digest {row['reference_id']}", sha(data), row["sha256"])
        check(f"source size {row['reference_id']}", len(data), row["bytes"])
        if path.suffix == ".xml":
            tree = ET.fromstring(data)
            raw[row["reference_id"]] = tree
            if row["reference_id"].startswith(("MetaCyc:", "EcoCyc:")):
                prefix, frame = row["reference_id"].split(":", 1)
                org = "META" if prefix == "MetaCyc" else "ECOLI"
                candidates = [
                    x for x in tree if x.get("frameid") == frame and x.get("orgid") == org
                ]
                check(f"issuing top-level object {row['reference_id']}", len(candidates), 1)
                obj = candidates[0]
                native[row["reference_id"]] = obj
                if row["reference_id"] not in base_slot_sources:
                    continue
                ordinals = collections.Counter()
                for child in obj:
                    ordinals[child.tag] += 1
                    locator = (
                        f"/ptools-xml/{obj.tag}[@frameid='{frame}']/"
                        f"{child.tag}[{ordinals[child.tag]}]"
                    )
                    expected_slots[(row["reference_id"], locator)] = {
                        "xml_sha256": sha(ET.tostring(child, encoding="unicode").encode()),
                        "source_sha256": row["sha256"],
                        "slot": child.tag,
                        "ordinal": ordinals[child.tag],
                    }
    check("native complete originals", len(native), 229)
    check("base native slot sources", len(base_slot_sources), 228)
    check("own slots independently enumerated", len(expected_slots), 3689)
    check("slot row count", len(slots), 3689)
    observed = {(row["source_id"], row["locator"]): row for row in slots}
    check("slot keys unique", len(observed), len(slots))
    check("exact source slot inventory", set(observed) == set(expected_slots))
    for key, expected in expected_slots.items():
        row = observed[key]
        check(f"slot original projection {key}", all(row[k] == v for k, v in expected.items()))
        check(f"slot design disposition {key}", bool(row.get("design_disposition")))
        check(f"slot edge pointers {key}", all(x in edge_by_id for x in row["edge_keys"]))

    schema = Path("/private/tmp/pathwaymech-next-272-20261015/src/pathwaymech/schema.py")
    allowed = {}
    for stmt in ast.parse(schema.read_text()).body:
        if isinstance(stmt, ast.Assign) and isinstance(stmt.targets[0], ast.Name):
            name = stmt.targets[0].id
            if name in {"ALLOWED_EDGE_PREDICATES", "NODE_CATEGORIES"}:
                allowed[name] = ast.literal_eval(stmt.value)
    evidence_native = []
    for edge in edge_by_id.values():
        key = edge["id"]
        check(f"edge endpoints {key}", edge["subject"] in declared and edge["object"] in declared)
        check(f"edge predicate {key}", edge["predicate"] in allowed["ALLOWED_EDGE_PREDICATES"])
        qualifiers = edge.get("endpoint_qualifiers", [])
        check(f"qualifier roles {key}", len({q["endpoint"] for q in qualifiers}), len(qualifiers))
        evidence = list(edge["evidence"])
        for qual in qualifiers:
            check(
                f"qualifier protein kind {key}",
                declared[edge[qual["endpoint"]]]["category"] in {"protein", "complex"},
            )
            check(f"qualifier description length {key}", 0 < len(qual["description"]) <= 400)
            evidence.extend(qual["evidence"])
        for index, ev in enumerate(evidence):
            label = f"{key}/{index}"
            fields = [field for field in ("quote", "source_assertion") if field in ev]
            check(f"one evidence assertion {label}", len(fields), 1)
            check(f"evidence length {label}", bool(fields) and 0 < len(ev[fields[0]]) <= 400)
            check(f"evidence reference source {label}", ev["reference_id"] in source_by_id)
            if "source_assertion" in ev:
                check(f"evidence locator {label}", bool(ev.get("source_locator")))
            if ev["reference_id"] in native:
                locator = ev["source_locator"]
                found = raw[ev["reference_id"]].find(locator.removeprefix("/ptools-xml/"))
                check(f"native evidence locator resolves {label}", found is not None)
                evidence_native.append(
                    {
                        "edge": key,
                        "reference_id": ev["reference_id"],
                        "locator": locator,
                        "source_text": " ".join(found.itertext()) if found is not None else None,
                    }
                )

    pathway = native["MetaCyc:PWY0-1477"]
    member_ids = {
        "MetaCyc:" + x.attrib["frameid"] for x in pathway.findall("reaction-list/Reaction")
    }
    member_edges = {
        e["subject"]
        for e in edge_by_id.values()
        if e["predicate"] == "part_of" and e["object"] == "MetaCyc:PWY0-1477"
    }
    check("five exact native members", sorted(member_edges), sorted(member_ids))
    check("five members", len(member_ids), 5)
    source_orders = set()
    for order in pathway.findall("reaction-ordering"):
        target = "MetaCyc:" + order.find("Reaction").attrib["frameid"]
        for predecessor in order.findall("predecessor-reactions/Reaction"):
            source_orders.add(("MetaCyc:" + predecessor.attrib["frameid"], target))
    graph_orders = {
        (e["subject"], e["object"]) for e in edge_by_id.values() if e["predicate"] == "precedes"
    }
    check("four exact source orders", sorted(graph_orders), sorted(source_orders))
    check("four source orders", len(source_orders), 4)
    layouts = {
        "MetaCyc:" + row.find("Reaction").attrib["frameid"]: row.findtext("direction")
        for row in pathway.findall("reaction-layout")
    }
    occurrence_rows = read("results/core-occurrences.json")
    check("22 core occurrences", len(occurrence_rows), 22)
    ancillary_rows = []
    for row in read("results/ancillary-eutt-occurrences.json"):
        ancillary_rows.append(
            {
                **row,
                "reaction_id": "MetaCyc:RXN-19336",
                "material_id": row["participant_id"],
                "source_locator": row["locator"],
                "selected_direction": "L2R",
            }
        )
    for row in occurrence_rows + ancillary_rows:
        reaction = row["reaction_id"]
        source = raw[reaction].find(row["source_locator"].removeprefix("/ptools-xml/"))
        check(f"occurrence resolves {row['edge']}", source is not None)
        material = next(c for c in source if c.get("frameid"))
        check(
            f"occurrence material {row['edge']}",
            row["material_id"],
            "MetaCyc:" + material.attrib["frameid"],
        )
        coefficient = source.findtext("coefficient")
        check(
            f"occurrence coefficient {row['edge']}",
            row["effective_coefficient"],
            int(coefficient or "1"),
        )
        direction = layouts.get(reaction, "L2R")
        check(f"selected direction {row['edge']}", row["selected_direction"], direction)
        input_side = "left" if direction == "L2R" else "right"
        is_input = row["native_side"] == input_side
        edge = edge_by_id[row["edge"]]
        expected = (
            (row["material_id"], "consumes", reaction)
            if is_input
            else (reaction, "produces", row["material_id"])
        )
        check(
            f"occurrence graph direction {row['edge']}",
            [edge[k] for k in ("subject", "predicate", "object")],
            list(expected),
        )

    for row in read("results/composition-ledger.json"):
        element = raw[row["complex"]].find(row["source_locator"].removeprefix("/ptools-xml/"))
        check(
            f"component coefficient {row['edge']}",
            row["native_coefficient"],
            element.findtext("coefficient"),
        )
        child = element.find("Protein")
        prefix = row["complex"].split(":", 1)[0]
        check(
            f"component exact ID {row['edge']}",
            row["component"],
            prefix + ":" + child.attrib["frameid"],
        )
    for row in read("results/regulation-ledger.json"):
        obj = native[row["source_id"]]
        check(f"regulation mode {row['source_id']}", row["native_mode"], obj.findtext("mode"))
        for slot_name, field in [("regulator", "regulator"), ("regulated-entity", "target")]:
            child = next(iter(obj.find(slot_name)))
            check(
                f"regulation {field} {row['source_id']}",
                row[field],
                "MetaCyc:" + child.attrib["frameid"],
            )

    activities = read("results/all71-activity-design-dispositions.json")
    check("71 activity decisions", len(activities), 71)
    check("71 unique activity decisions", len({x["activity"] for x in activities}), 71)
    for row in activities:
        obj = native["MetaCyc:" + row["activity"]]
        check(
            f"activity enzyme {row['activity']}",
            row["enzyme"],
            obj.find("enzyme/Protein").attrib["frameid"],
        )
        check(
            f"activity reaction {row['activity']}",
            row["reaction"],
            obj.find("reaction/Reaction").attrib["frameid"],
        )
        check(f"activity decision {row['activity']}", bool(row["graph_design_decision"]))
    proteins = read("biology-audit/protein-design-ledger.json")
    check("34 exact protein design rows", len(proteins), 34)
    check("34 unique protein IDs", len({x["id"] for x in proteins}), 34)
    for row in proteins:
        source = row["identity_source"]
        data = Path(source["path"]).read_bytes()
        entry = json.loads(data)
        check(f"protein source hash {row['id']}", sha(data), source["sha256"])
        check(
            f"protein issuing ID {row['id']}", row["id"], "UniProtKB:" + entry["primaryAccession"]
        )
        check(
            f"protein taxon {row['id']}",
            row["taxon_id"],
            "NCBITaxon:" + str(entry["organism"]["taxonId"]),
        )
        check(f"protein decision {row['id']}", bool(row["representable_recommendation"]))
    output = {
        "scope": (
            "Finite source/ledger checks only; not scientific correctness or authority acceptance."
        ),
        "input_root": str(root),
        "checks": checks,
        "native_evidence_contexts": evidence_native,
        "all_passed": all(c["pass"] for c in checks),
    }
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(
        json.dumps(
            {
                "checks": len(checks),
                "all_passed": output["all_passed"],
                "failed": [c for c in checks if not c["pass"]],
            }
        )
    )


if __name__ == "__main__":
    main()
