"""Read-only verification of the exact EcoCyc EAL target supplement."""

import hashlib
import json
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def check(value, message):
    global checks
    if not value:
        raise ValueError(message)
    checks += 1


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = ROOT / "originals/ECOLI-ETHAMLY-CPLX.xml"
receipt = json.loads((ROOT / "receipts/ECOLI-ETHAMLY-CPLX.xml.json").read_text())
check(receipt["status"] == 200, "successful acquired XML")
check(receipt["sha256"] == digest(source), "receipt hash")
check(receipt["bytes"] == source.stat().st_size, "receipt size")
check(receipt["requested_url"] == receipt["final_url"], "unchanged request")
check(receipt["path"] == str(source.relative_to(ROOT)), "exact body path")
root = ET.fromstring(source.read_bytes())
check(root.findtext("metadata/query") == "ECOLI:ETHAMLY-CPLX", "exact target")
check(
    root.find("metadata/PGDB").attrib == {"orgid": "ECOLI", "version": "27.0"},
    "native PGDB/release",
)
entity = root.find("Protein")
check(
    entity.attrib
    == {
        "ID": "ECOLI:ETHAMLY-CPLX",
        "orgid": "ECOLI",
        "frameid": "ETHAMLY-CPLX",
        "detail": "full",
    },
    "full native protein identity",
)
projection = json.loads((ROOT / "results/complete-own-slot-reading.json").read_text())
check(len(entity) == 16, "all sixteen own slots")
check(not entity.findall("common-name"), "no own common name")
check(projection["source_sha256"] == digest(source), "projection source binding")
check(projection["root_attributes"] == root.attrib, "root attributes")
check(projection["entity_attributes"] == entity.attrib, "entity attributes")
check(projection["slot_counts"] == dict(Counter(n.tag for n in entity)), "slot counts")
check(
    projection["metadata_xml"] == ET.tostring(root.find("metadata"), encoding="unicode"),
    "full metadata retained",
)
for row, node in zip(projection["slots"], entity, strict=True):
    check(row["xml"] == ET.tostring(node, encoding="unicode"), "complete own slot XML")
    check(bool(row["disposition"]), "explicit slot disposition")
for row in json.loads((ROOT / "results/parent-bindings.json").read_text()):
    check(digest(ROOT / row["local_path"]) == row["sha256"], "copied parent binding")
    check(digest(Path(row["source_path"])) == row["sha256"], "unchanged parent source")
for row in json.loads((ROOT / "results/claim-proposals.json").read_text()):
    check(0 < len(row["source_assertion"]) <= 400, "bounded assertion")
    claim_root = ET.fromstring((ROOT / row["source"]).read_bytes())
    top, locator = row["locator"].strip("/").split("/", 1)
    check(claim_root.tag == top and len(claim_root.findall(locator)) == 1, "exact locator")
manifest_path = ROOT / "artifact-manifest.json"
if manifest_path.exists():
    manifest = json.loads(manifest_path.read_text())
    physical = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
    check(
        physical
        == {row["path"] for row in manifest["files"]}
        | {"artifact-manifest.json", "freeze-proof.json"},
        "complete physical inventory including hidden and ignored files",
    )
    for row in manifest["files"]:
        path = ROOT / row["path"]
        check(not path.is_symlink() and path.stat().st_size == row["bytes"], "manifest size")
        check(digest(path) == row["sha256"], "manifest hash")
    proof = json.loads((ROOT / "freeze-proof.json").read_text())
    check(digest(manifest_path) == proof["manifest_sha256"], "manifest binding")
    check(digest(ROOT / "HANDOFF.md") == proof["handoff_sha256"], "handoff binding")
print(json.dumps({"checks_passed": checks, "scientific_acceptance": "separate review"}))
