"""Acquire a named public source, retaining failures and exact response bytes."""

import hashlib
import http.client
import json
import sys
import urllib.error
import urllib.request
from datetime import UTC, datetime
from pathlib import Path

owner = Path(__file__).resolve().parents[1]
name, url = sys.argv[1:]
assert Path(name).name == name
body_path = owner / "originals" / name
receipt_path = owner / "receipts" / (name + ".json")
assert not body_path.exists() and not receipt_path.exists()
receipt = {"requested_url": url, "started_utc": datetime.now(UTC).isoformat()}
try:
    request = urllib.request.Request(
        url, headers={"User-Agent": "PathwayMech research source verification"}
    )
    try:
        response = urllib.request.urlopen(request, timeout=45)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        body = response.read()
        body_path.write_bytes(body)
        receipt.update(
            status=response.status,
            final_url=response.url,
            headers={
                k: v
                for k, v in response.headers.items()
                if k.lower() in {"content-type", "etag", "last-modified", "date"}
            },
            path=str(body_path.relative_to(owner)),
            bytes=len(body),
            sha256=hashlib.sha256(body).hexdigest(),
        )
except (OSError, ValueError, http.client.HTTPException) as error:
    receipt.update(error_type=type(error).__name__, error=str(error))
receipt["finished_utc"] = datetime.now(UTC).isoformat()
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
