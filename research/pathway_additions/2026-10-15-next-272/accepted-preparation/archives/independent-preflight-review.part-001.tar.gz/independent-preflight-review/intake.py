from pathlib import Path
import hashlib,json,shutil,datetime,stat
R=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-272-discovery-preparation');W=Path('/private/tmp/pathwaymech-next-271-20261015');expected={'artifact-manifest.json':'3b9ffe9f7c87c7d924aa6a2a5ac701ac9c5c5f01a04e1f0fd66935a88c8c7206','HANDOFF.md':'3eb65aafd8097f601c99f62eebdb40185a7b74a7bcadcb727a5ed4edb4f8b3da','freeze-proof.json':'b1ffea2cf29c59005095ac34a0b2f931e62787593bc0543315f4aeba374e4e6f'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in expected.items():assert sha(A/p)==h
m=json.loads((A/'artifact-manifest.json').read_text());f=json.loads((A/'freeze-proof.json').read_text());listed={x['path']:x for x in m['files']};assert len(listed)==len(m['files'])==408
physical={}
for p in A.rglob('*'):
 assert not p.is_symlink()
 if p.is_dir():continue
 assert stat.S_ISREG(p.stat().st_mode);rel=p.relative_to(A).as_posix();raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest();physical[rel]={'path':rel,'bytes':len(raw),'sha256':h}
 if rel in listed:assert len(raw)==listed[rel]['bytes'] and h==listed[rel]['sha256']
 dest=R/'inputs/author'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
assert set(physical)==set(listed)|{'artifact-manifest.json','freeze-proof.json'} and len(physical)==410
assert sum(x['bytes'] for x in listed.values())==27519594
(R/'results').mkdir();(R/'guidance').mkdir()
for rel in ['.claude/skills/add-pathway/SKILL.md','CLAUDE.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','src/pathwaymech/schema.py']:
 dest=R/'guidance'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/rel,dest)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':str(A),'release_hashes':expected,'listed_files':408,'physical_files':410,'listed_bytes':27519594,'physical_bytes':sum(x['bytes'] for x in physical.values()),'files':list(physical.values()),'full_hash_and_physical_verification':True,'hidden_ignored_included':True,'source_writes':False}
(R/'results/intake.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
