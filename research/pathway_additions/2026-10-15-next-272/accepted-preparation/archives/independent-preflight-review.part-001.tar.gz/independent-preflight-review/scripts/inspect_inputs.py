from pathlib import Path
import json
from html.parser import HTMLParser
P=Path(__file__).resolve().parents[1]; A=P/'inputs/author'
class Blocks(HTMLParser):
 def __init__(self):super().__init__();self.blocks=[];self.depth=0;self.tag='';self.buf=[]
 def handle_starttag(self,t,a):
  if not self.depth and t in ['p','h1','h2','h3','h4','caption']:
   self.depth=1;self.tag=t;self.buf=[]
  elif self.depth:self.depth+=1
 def handle_endtag(self,t):
  if self.depth:
   self.depth-=1
   if not self.depth:
    v=' '.join(''.join(self.buf).split())
    if v:self.blocks.append({'tag':self.tag,'text':v})
 def handle_data(self,d):
  if self.depth:self.buf.append(d)
for pmc in ['PMC1291257','PMC1447003']:
 p=Blocks();p.feed((A/'originals'/f'{pmc}.html').read_text()); rows=[{'block':i,**r} for i,r in enumerate(p.blocks,1)]
 (P/'readings'/f'{pmc}-blocks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(pmc,len(rows)); print('\n'.join(f"{r['block']}: {r['tag']} {r['text']}" for r in rows if r['tag'].startswith('h') or any(k in r['text'].lower() for k in ['glutathione','eutd','eutg','oxygen','ph 7','37°','strains used','all strains','volatil','compartment','table 1'])))
for f in ['native-complete-own-slot-projections.json','complete-root-slot-dispositions.json','source-and-corpus-overview.json','final-checks.json']:
 d=json.loads((A/'results'/f).read_text()); print(f,type(d).__name__,list(d)[:8] if isinstance(d,dict) else len(d))
