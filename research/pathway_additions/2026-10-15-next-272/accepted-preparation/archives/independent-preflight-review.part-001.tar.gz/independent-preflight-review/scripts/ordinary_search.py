from pathlib import Path
import concurrent.futures, hashlib, json, subprocess
P=Path(__file__).resolve().parents[1]; A=P/'inputs/author'
roots={'current_owned271':Path('/private/tmp/pathwaymech-next-271-20261015'),'original_checkout':Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')}
patterns=['PWY0-1477','ethanolamine utilization','ethanolamine catabolic process','ethanolamine degradation','ethanolamine catabolism','ethanolamine breakdown','GO:0046336','ETHAMLY-RXN']
pfile=P/'results/independent-ordinary-patterns.txt';pfile.write_text('\n'.join(patterns)+'\n')
def scan(pair):
 name,root=pair;argv=['rg','--no-ignore','--hidden','-l','-i','-F','-f',str(pfile),'-g','!.git','-g','!.venv','.']
 p=subprocess.run(argv,cwd=root,capture_output=True);(P/'logs'/f'ordinary-{name}.stdout').write_bytes(p.stdout);(P/'logs'/f'ordinary-{name}.stderr').write_bytes(p.stderr)
 rows=[]
 for rel in p.stdout.decode().splitlines():
  b=(root/rel).read_bytes(); s=b.decode('utf8',errors='replace'); lower=s.lower(); hits=[]
  for pattern in patterns:
   count=lower.count(pattern.lower())
   if count:
    pos=lower.index(pattern.lower());hits.append({'pattern':pattern,'count':count,'first_context':s[max(0,pos-100):pos+len(pattern)+180]})
  rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'hits':hits})
 return {'label':name,'root':str(root),'argv':argv,'returncode':p.returncode,'scope':'Ordinary text including hidden/ignored; .git/.venv and binary/compressed interiors excluded. First context is navigation only, not a complete semantic reading. Current checkout includes pending work; no merged271 assumption.','files':rows}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex: results=list(ex.map(scan,roots.items()))
(P/'results/independent-ordinary-search.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
print(json.dumps([{k:r[k] for k in ['label','returncode']}|{'matched_files':len(r['files'])} for r in results])); assert all(r['returncode'] in [0,1] for r in results)
