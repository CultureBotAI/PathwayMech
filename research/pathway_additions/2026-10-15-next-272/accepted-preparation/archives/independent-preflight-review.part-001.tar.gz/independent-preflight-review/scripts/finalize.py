from pathlib import Path
import datetime, hashlib, json, sys
P=Path(__file__).resolve().parents[1];A=P/'inputs/author';S=Path('/private/tmp/pathwaymech-next-272-discovery-preparation')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
intake=json.loads((P/'results/intake.json').read_text()); rows=intake['files']; expected={r['path'] for r in rows}
for owner in [A,S]:
 files=[p for p in owner.rglob('*') if p.is_file()];assert {str(p.relative_to(owner)) for p in files}==expected
 assert not any(p.is_symlink() for p in owner.rglob('*'))
 for r in rows:
  b=(owner/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes']
finish=datetime.datetime.now(datetime.timezone.utc).isoformat()
put(P/'results/final-source-stability.json',{'utc':finish,'original_owner':str(S),'copied_owner':'inputs/author','physical_files_each':len(rows),'all_original_and_copy_hashes_unchanged':True,'source_manifest_sha256':sha((S/'artifact-manifest.json').read_bytes()),'source_freeze_sha256':sha((S/'freeze-proof.json').read_bytes())})
metadata=json.loads((A/'originals/primary-metadata.json').read_text())['resultList']['result']
reading=[]
for r in metadata:
 row={'pmid':r['id'],'doi':r.get('doi'),'title':r['title'],'metadata_body_sha256':sha((A/'originals/primary-metadata.json').read_bytes()),'abstract_supplied':bool(r.get('abstractText')),'independent_scope':'Complete supplied abstract read; no main or supplement read here.' if r.get('abstractText') else 'Metadata only; no supplied abstract; no primary mechanism credit.'}
 if r['id']=='23920494':row['limit']='Review article, not new primary experimental evidence.'
 if r['id']=='16291677':row.update({'main':'originals/PMC1291257.html','main_sha256':sha((A/'originals/PMC1291257.html').read_bytes()),'independent_scope':'Abstract; LT2 derivative culture conditions; mutant/complementation and shell-bypass results; relevant captions; discussion. Paragraph/heading block navigation retained in readings/PMC1291257-blocks.json.','limits':'Targeted main text only. No full tables, figure pixels or SI. GSSG addition versus GSH discussion terminology retained; genetic rescue not purified assay.'})
 if r['id']=='16585748':row.update({'main':'originals/PMC1447003.html','main_sha256':sha((A/'originals/PMC1447003.html').read_bytes()),'independent_scope':'Abstract; LT2 strain, medium and aldehyde-release methods; selected pH/gas-exchange results and captions; discussion. Paragraph/heading block navigation retained in readings/PMC1447003-blocks.json.','limits':'Targeted main text only. No complete-table, figure-pixel or SI audit. Models, negative assays and conflicting EutD phenotypes remain qualified.'})
 if r['id'] in ['23585538','14996820']:row['limits']='Full supplied abstract only. Retained HTTP500 XML failure and HTTP200 CAPTCHA HTML are not full mains; no SI read.'
 reading.append(row)
put(P/'results/primary-reading-scopes.json',{'reviewer':'/root/next268_reaction_review_completion','network_requests_by_reviewer':0,'sources':reading,'not_claimed':['full primary closure','figure pixel review','all table reading','SI reading','unavailable main access','new universal localization or catalysis']})
checks=json.loads((P/'results/independent-checks.json').read_text());assert checks['failed']==0 and checks['passed']==593
searches=json.loads((P/'results/independent-ordinary-search.json').read_text());assert all(x['returncode']==0 for x in searches)
result={'verdict':'qualified_acceptance_for_complete_source_preparation_only','actionable_findings':[],'candidate_id':'MetaCyc:PWY0-1477','candidate_label':'ethanolamine utilization','reviewer':'/root/next268_reaction_review_completion','author':'/root/next272_candidate_discovery','start_utc':intake['utc'],'finish_utc':finish,'reviewed_author_manifest_sha256':intake['release_hashes']['artifact-manifest.json'],'structural_integrity_checks_passed':593,'structural_integrity_checks_failed':0,'original_and_copied_physical_files_each':410,'all_owned_jobs_terminal':True,'landed_base':{'commit':'63ebb3b3e29ca1ed6472597104347d9fbc98f4a5','tree':'5448122efcfbd8ae2ac90ad42e70557b03d9b78e','records':267},'pending_acetate':{'sha256':'47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3','records':1,'actual271_merged_rebind_required_before_curation_or_adapter':True},'native':{'root_own_slots':21,'member_reactions':5,'order_edges':4,'material_occurrences':22,'material_ids':14,'unresolved_low_detail_activity_occurrences':71},'ordinary_text_search':{'hidden_and_ignored_included':True,'excluded':['.git','.venv','binary/compressed interiors'],'patterns':8,'current_owned271_matching_files':37,'original_checkout_matching_files':29},'compressed_scope':{'fully_decoded_gzip_payloads':116,'compressed_bytes':3991511,'decoded_bytes':24849128,'matching_payloads':17,'author_historical_container_inventory':17025,'other_and_nested_interiors':'unsearched'},'primary_scope':'11 metadata records; all nine supplied abstracts read (including one review), two unavailable abstracts; targeted 2005 and 2006 mains. No full-table/figure-pixel/SI or inaccessible-main claim.','limits':['No maintained record or authority acceptance','No global novelty or source exhaustion','All 71 activity leads remain biological preparation work','Native/source and primary location, direction, EC, cofactor and strain conflicts preserved','Sulfate issue410 remains open; nitrogen fixation and ammonia oxidation unassessed','Licensing remains deferred to public release; retrieval does not imply clearance']}
put(P/'RESULT.json',result)
(P/'HANDOFF.md').write_text('''# Independent next272 preflight handoff

**Qualified acceptance to proceed with complete source preparation of MetaCyc:PWY0-1477, ethanolamine utilization. No actionable preflight defect.** This is not a maintained-record, authority, graph-completeness or source-exhaustion verdict.

Read REVIEW.md, RESULT.json and results/primary-reading-scopes.json for exact scope. The independently verified author release is manifest `3b9ffe9f7c87c7d924aa6a2a5ac701ac9c5c5f01a04e1f0fd66935a88c8c7206`; every one of its 410 physical files and its local copy remains exact. The structural/integrity replay passed 593 checks. All commands are terminal, and no maintained/source/Git/GitHub/runtime bytes were changed.

The complete native boundary is five reactions, four order links, 22 material occurrences and 14 material IDs. The 21 root slots are fully accounted for. All 71 low-detail activity occurrences remain unresolved biological source preparation, with no reduction to the two-reaction acetyl-CoA shorthand. Preserve EutBC composition, EutD/EutG conditional roles, shell/cargo scope, EutA/T handling, regulation, transport and strain distinctions.

The 267 records at actual landed commit `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5` / tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e`, plus the separately pending acetate record, do not contain this complete pathway. Exact blob, declaration and Rhea-family comparisons are retained. **Rebind to the actual next271 merged baseline before maintained curation or adapter work.**

Hidden/ignored ordinary text was included in both searches. Exactly 116 selected gzip payloads were decoded and independently replayed; 17 matched. The 17,025-container inventory is historical physical inventory only; other/nested interiors remain unsearched. There is no global absence claim.

The retained main-text readings are targeted 2005/2006 passages; 2013/2004 evidence is abstract-only with CAPTCHA/HTTP500 bodies explicitly excluded. No figure pixels, complete tables, SI or inaccessible mains were reviewed. Native blanket-lumen language, external-EutBC model, EutD background effects, EutG proposed roles and the kinase EC anomaly remain explicit. Unavailable historical papers must limit claims rather than trigger unbounded source hunting or erase supported native assertions.

Sulfate issue410 remains open with its donor-resolved DsrC prerequisite. Deferred and unassessed routes are not exhausted. The packet is frozen by artifact-manifest.json and freeze-proof.json; do not modify it.
''')
files=[]
for p in sorted(P.rglob('*')):
 assert not p.is_symlink()
 if p.is_file() and p.relative_to(P).as_posix() not in ['artifact-manifest.json','freeze-proof.json']:
  b=p.read_bytes();files.append({'path':p.relative_to(P).as_posix(),'bytes':len(b),'sha256':sha(b)})
manifest={'scope':'Complete physical independent preflight review owner, including hidden/ignored files and copied author attempts. Only the two integrity-envelope files are excluded from the inner inventory.','files':files,'listed_files':len(files),'listed_bytes':sum(r['bytes'] for r in files)}
put(P/'artifact-manifest.json',manifest)
put(P/'freeze-proof.json',{'utc':finish,'all_owned_jobs_terminal':True,'manifest':'artifact-manifest.json','manifest_sha256':sha((P/'artifact-manifest.json').read_bytes()),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':manifest['listed_bytes'],'handoff_sha256':sha((P/'HANDOFF.md').read_bytes()),'review_sha256':sha((P/'REVIEW.md').read_bytes()),'result_sha256':sha((P/'RESULT.json').read_bytes()),'source_unchanged':True})
# Exhaustively inspect the newly written envelopes and contents before release.
assert len([p for p in P.rglob('*') if p.is_file()])==len(files)+2
for r in files:
 b=(P/r['path']).read_bytes();assert sha(b)==r['sha256'] and len(b)==r['bytes']
print(json.dumps({'owner':str(P),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':manifest['listed_bytes'],'hashes':{n:sha((P/n).read_bytes()) for n in ['artifact-manifest.json','HANDOFF.md','REVIEW.md','RESULT.json','freeze-proof.json']}}))
