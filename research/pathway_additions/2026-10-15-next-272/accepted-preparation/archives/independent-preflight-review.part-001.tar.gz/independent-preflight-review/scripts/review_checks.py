from pathlib import Path
import collections, csv, gzip, hashlib, io, json, os, subprocess, sys, xml.etree.ElementTree as ET
import yaml
P=Path(__file__).resolve().parents[1]; A=P/'inputs/author'; W=Path('/private/tmp/pathwaymech-next-271-20261015')
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(name, ok, details=None): checks.append({'check':name,'pass':bool(ok),'details':details})
def dump(name,obj):(P/'results'/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def git(*args):
 p=subprocess.run(['git','--no-optional-locks',*args],cwd=W,capture_output=True)
 if p.returncode: raise RuntimeError((args,p.returncode,p.stderr.decode()))
 return p.stdout
base=json.loads((A/'results/baseline.json').read_text()); commit=base['commit']
check('actual landed base tree',git('rev-parse',commit+'^{tree}').decode().strip()==base['tree'],{'commit':commit,'tree':base['tree'],'pending_271_is_not_merged_baseline':True})
paths=git('ls-tree','-r','--name-only',commit,'--','data/pathways').decode().splitlines()
yamlpaths=[p for p in paths if Path(p).suffix.lower() in ['.yaml','.yml']]
check('267 baseline paths exact',set(yamlpaths)=={r['path'] for r in base['records']} and len(yamlpaths)==267)
records=[]
for r in base['records']:
 b=(A/'inputs/baseline'/r['path']).read_bytes(); committed=git('show',commit+':'+r['path'])
 check('baseline blob '+r['path'],b==committed and sha(b)==r['sha256'] and len(b)==r['bytes'])
 records.append(('baseline',Path(r['path']).name,b,yaml.safe_load(b)))
pending='data/pathways/methanogenesis-from-acetate.yaml'; b=(A/'inputs/pending271'/pending).read_bytes()
check('pending acetate bytes remain qualified',b==(W/pending).read_bytes() and sha(b)=='47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3')
records.append(('pending271',Path(pending).name,b,yaml.safe_load(b)))
physical=[]
for p in sorted((W/'data/pathways').rglob('*')):
 if p.is_file() and p.suffix.lower() in ['.yaml','.yml']:
  physical.append({'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'symlink':p.is_symlink()})
check('hidden ignored YAML inventory complete against finite corpus',set(r['path'] for r in physical)==set(yamlpaths)|{pending} and not any(r['symlink'] for r in physical),{'count':len(physical),'method':'Path.rglob includes hidden and ignored; only data/pathways YAML/YML; no archive interiors'})
dump('current-record-physical-inventory.json',physical)
expected={
 'ETHAMLY-RXN':(['ETHANOL-AMINE'],['AMMONIUM','ACETALD'],'LEFT-TO-RIGHT','L2R'),
 'ACETALD-DEHYDROG-RXN':(['ACETALD','CO-A','NAD'],['ACETYL-COA','NADH','PROTON'],'REVERSIBLE','L2R'),
 'PHOSACETYLTRANS-RXN':(['Pi','ACETYL-COA'],['ACETYL-P','CO-A'],'REVERSIBLE','L2R'),
 'ACETATEKIN-RXN':(['ADP','ACETYL-P'],['ATP','ACET'],'REVERSIBLE','R2L'),
 'ALCOHOL-DEHYDROG-RXN':(['ACETALD','NADH','PROTON'],['ETOH','NAD'],'REVERSIBLE','R2L')}
rootxml=ET.parse(A/'originals/META-PWY0-1477.xml').getroot(); root=rootxml.find('Pathway')
check('21 own root slots',len(root)==21)
memberids=[n.get('frameid') for n in root.findall('./reaction-list/Reaction')]
check('all five native members',len(memberids)==5 and set(memberids)==set(expected))
ordering=[(p.get('frameid'),o.find('Reaction').get('frameid')) for o in root.findall('reaction-ordering') for p in o.findall('./predecessor-reactions/Reaction')]
check('four native order edges',len(ordering)==4 and set(ordering)=={('ETHAMLY-RXN','ALCOHOL-DEHYDROG-RXN'),('ETHAMLY-RXN','ACETALD-DEHYDROG-RXN'),('ACETALD-DEHYDROG-RXN','PHOSACETYLTRANS-RXN'),('PHOSACETYLTRANS-RXN','ACETATEKIN-RXN')})
layout={s.find('Reaction').get('frameid'):s.findtext('direction') for s in root.findall('reaction-layout')};native=[];materials=[];act=[]
for fid,(left,right,direction,orient) in expected.items():
 path=A/'originals'/('META-'+fid+'.xml'); tree=ET.parse(path).getroot(); e=tree.find('Reaction')
 sides={s:[{'id':c[0].get('frameid'),'raw_coefficient':c.findtext('coefficient'),'compartments':[x.tag for x in c if 'compartment' in x.tag]} for c in e.findall(s)] for s in ['left','right']}
 selected=([v['id'] for v in sides['left']],[v['id'] for v in sides['right']])
 if orient=='R2L':selected=selected[::-1]
 check(fid+' full native identity',e.get('ID')=='META:'+fid and e.get('orgid')=='META' and e.get('detail')=='full' and tree.findtext('metadata/query')=='META:'+fid and tree.find('metadata/PGDB').attrib=={'orgid':'META','version':'27.0'})
 check(fid+' own versus selected direction',e.findtext('reaction-direction')==direction and layout[fid]==orient)
 check(fid+' selected equation',collections.Counter(selected[0])==collections.Counter(left) and collections.Counter(selected[1])==collections.Counter(right),{'inputs':selected[0],'outputs':selected[1]})
 check(fid+' omitted coefficients and compartments',all(t['raw_coefficient'] is None and not t['compartments'] for s in sides.values() for t in s))
 check(fid+' own common-name absent',e.find('common-name') is None)
 acts=[dict(a.attrib) for a in e.findall('./enzymatic-reaction/Enzymatic-Reaction')]
 act.extend([{'reaction':fid,**v} for v in acts]); materials.extend([v['id'] for s in sides.values() for v in s])
 native.append({'frameid':fid,'source_sha256':sha(path.read_bytes()),'own_direction':direction,'pathway_orientation':orient,'native_sides':sides,'selected_inputs':selected[0],'selected_outputs':selected[1],'activities':acts})
check('22 occurrence and 14 material denominator',len(materials)==22 and len(set(materials))==14)
check('71 low-detail activity occurrences only',len(act)==71 and all(a.get('detail')=='low' for a in act),{'occurrences':len(act),'unique_ids':len({a['frameid'] for a in act})})
check('native acetate kinase EC anomaly literal',ET.parse(A/'originals/META-ACETATEKIN-RXN.xml').findtext('./Reaction/ec-number').strip()=='EC-2.7.2.15')
slots=json.loads((A/'results/complete-root-slot-dispositions.json').read_text()); counts=collections.Counter()
for i,c in enumerate(root):
 counts[c.tag]+=1; r=slots[i]
 check('root own disposition '+str(i+1),r['slot']==c.tag and r['index']==counts[c.tag] and r['xml']==ET.tostring(c,encoding='unicode') and bool(r['disposition']))
check('two direct taxa and bacterial range distinct',[x.get('frameid') for x in root.findall('./species/Organism')]==['TAX-511145','TAX-99287'] and [x.get('frameid') for x in root.findall('./taxonomic-range/Organism')]==['TAX-2'])
dump('independent-native-boundary.json',{'root_sha256':sha((A/'originals/META-PWY0-1477.xml').read_bytes()),'members':memberids,'order_edges':ordering,'reactions':native,'materials':sorted(set(materials)),'activity_occurrences':act,'limits':'No full biological closure, material identity approval, flux summation or inferred transport.'})
rows=[]; members={'MetaCyc:'+x for x in expected}
for scope,name,b,d in records:
 ids={d['id']}|{n['id'] for field in ['taxa','participants','reactions'] for n in d.get(field,[])}
 refs={n['id'] for n in d.get('references',[])}
 rows.append({'scope':scope,'path':name,'sha256':sha(b),'id':d['id'],'label':d['label'],'root_exact_match':d['id']=='MetaCyc:PWY0-1477','root_label_match':d['label'].lower()=='ethanolamine utilization','declared_member_overlap':sorted(members&ids),'reference_only_member_mentions':sorted((refs-ids)&members)})
reported=json.loads((A/'results/all268-corpus-comparison-successor.json').read_text())['records']
check('all 268 corrected rows reproduce',sorted(rows,key=lambda x:(x['scope'],x['path']))==sorted(reported,key=lambda x:(x['scope'],x['path'])))
check('no candidate root in finite maintained declarations',not any(x['root_exact_match'] or x['root_label_match'] for x in rows))
dump('independent-declaration-comparison.json',rows)
rr=json.loads((A/'results/complete-table-rhea-family-overlaps.json').read_text()); raw=gzip.decompress((A/rr['source_compressed_path']).read_bytes());check('retained full Rhea direction bytes',sha(raw)==rr['decoded_sha256'])
tab=list(csv.reader(io.StringIO(raw.decode()),delimiter='\t')); family={value:row[0] for row in tab[1:] for value in row if value}
check('five native Rhea leads present as quartet members',{a:family[a] for a in rr['families']}==rr['families'])
overlaps=[]
for _,name,_,d in records:
 hits=[]
 for r in d.get('reactions',[]):
  if r['id'].startswith('RHEA:'):
   for a,f in rr['families'].items():
    if family.get(r['id'].split(':',1)[1])==f:hits.append({'native_xref_lead':'RHEA:'+a,'record_reaction':r['id'],'master':f})
 if hits:overlaps.append({'record':d['id'],'path':name,'hits':hits})
check('all formal Rhea-family overlaps reproduced',overlaps==rr['overlaps']);dump('independent-rhea-overlaps.json',overlaps)
acq=[]
for p in sorted((A/'receipts').glob('*.json')):
 d=json.loads(p.read_text()); path=d.get('path')
 if path:
  b=(A/path).read_bytes(); ok=sha(b)==d['sha256'] and len(b)==d['bytes'];check('receipt body '+p.name,ok)
  acq.append({'receipt':str(p.relative_to(A)),'path':path,'status':d.get('status'),'bytes':len(b),'sha256':sha(b)})
 elif p.name=='issue410-current-gh.json':
  b=(A/'originals/issue410-current-gh.json').read_bytes();check('authenticated issue receipt',sha(b)==d['sha256'] and len(b)==d['bytes'] and d['returncode']==0)
 else:acq.append({'receipt':str(p.relative_to(A)),'status':d.get('status'),'returncode':d.get('returncode'),'error':d.get('error'),'no_retained_body':True})
for pmc,doi in [('PMC1291257','10.1128/JB.187.23.8039-8046.2005'),('PMC1447003','10.1128/JB.188.8.2865-2874.2006')]:
 s=(A/'originals'/f'{pmc}.html').read_text();check('primary article identity '+pmc,doi.lower() in s.lower() and pmc in s and '<h1>' in s)
for pmc in ['PMC3697265','PMC355984']:
 s=(A/'originals'/f'{pmc}.html').read_text();check('CAPTCHA not article '+pmc,'captcha' in s.lower())
issue=json.loads((A/'originals/issue410-current-gh.json').read_text());check('issue410 retained state OPEN',issue['state']=='OPEN' and issue['number']==410 and 'DsrC' in issue['body'])
dump('independent-acquisition-bindings.json',acq)
# This finite prior selection is fully decoded; no other archive interior is examined.
sel=json.loads((A/'results/selected-compressed-search.json').read_text())['files']; old=json.loads((A/'inputs/prior-next270/compressed-history-content-scan.json').read_text())['files']; pats=(A/'results/candidate-search-patterns.txt').read_text().splitlines()
check('116 selected paths exactly inherited',len(sel)==116 and {r['path'] for r in sel}=={r['path'] for r in old})
arch=[]
for r in sel:
 path=W/r['path']; b=path.read_bytes(); dec=gzip.decompress(b); text=dec.decode('utf8',errors='replace').lower()
 check('selected gzip '+r['path'],sha(b)==r['sha256'] and len(b)==r['bytes'] and sha(dec)==r['decoded_sha256'] and len(dec)==r['decoded_bytes'])
 hits=[{'pattern':p,'count':text.count(p.lower())} for p in pats if p.lower() in text]
 check('selected gzip hits '+r['path'],hits==[{k:h[k] for k in ['pattern','count']} for h in r['hits']])
 arch.append({**{k:r[k] for k in ['path','sha256','bytes','decoded_sha256','decoded_bytes']},'hits':hits})
check('selected gzip denominators',sum(r['bytes'] for r in sel)==3991511 and sum(r['decoded_bytes'] for r in sel)==24849128 and sum(bool(r['hits']) for r in sel)==17)
inv=json.loads((A/'results/archive-physical-inventory.json').read_text())['files'];check('historical inventory denominator only',len(inv)==17025 and sum(r['bytes'] for r in inv)==1794475047 and len({r['path'] for r in inv})==17025)
dump('independent-selected-archive-replay.json',{'scope':'116 finite gzip payloads only; historical 17,025-container inventory is not an interior search or current-tree inventory; all other/nested interiors unsearched.','files':arch})
dump('independent-checks.json',{'checks':checks,'passed':sum(r['pass'] for r in checks),'failed':sum(not r['pass'] for r in checks)})
print(json.dumps({'checks':len(checks),'passed':sum(r['pass'] for r in checks),'failed':[r for r in checks if not r['pass']]}))
sys.exit(any(not r['pass'] for r in checks))
