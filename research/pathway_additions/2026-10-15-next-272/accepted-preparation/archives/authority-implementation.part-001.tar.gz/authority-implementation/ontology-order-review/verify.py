"""Independent finite review of the ontology serialization successor."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

OWNER = Path(__file__).resolve().parent
SUCCESSOR = Path("/private/tmp/pathwaymech-next-272-ontology-order-successor")
PARENT = Path("/private/tmp/pathwaymech-next-272-ontology-preparation")
BASELINE = Path(
    "/private/tmp/pathwaymech-next-272-20261015/data/identifier_authorities/ontology.json"
)
CHECKS = []


def check(condition, description):
    if not condition:
        raise AssertionError(description)
    CHECKS.append(description)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ordered(value):
    if isinstance(value, dict):
        return [(key, ordered(item)) for key, item in value.items()]
    if isinstance(value, list):
        return [ordered(item) for item in value]
    return value


def read(path):
    return json.loads(path.read_bytes())


def main():
    expected = {
        "artifact-manifest.json": (
            "114be3fe478c501277376e35fa1f53b9b527c94fc398211a699a4170b36199a2"
        ),
        "HANDOFF.md": "e6680731980e88813fd9e47304847655c50d6f6107e8c4db34597e3351a1e3ef",
        "freeze-proof.json": "0d6c8ce462a97fd9ff05df9cfd216e1de8b0ba49045fa76d8e863287e0151531",
        "proposed-ontology.json": (
            "8ab396c8de205cbdbb8ade07795536a4b20eec59f5ad4fe5afbc08c1486975c6"
        ),
    }
    for name, sha in expected.items():
        check(digest(SUCCESSOR / name) == sha, "exact successor " + name)
    manifest = read(SUCCESSOR / "artifact-manifest.json")
    paths = []
    for row in manifest["files"]:
        path = SUCCESSOR / row["path"]
        check(path.is_file() and not path.is_symlink(), "regular file " + row["path"])
        check(path.stat().st_size == row["bytes"], "length " + row["path"])
        check(digest(path) == row["sha256"], "hash " + row["path"])
        paths.append(row["path"])
    physical = {str(p.relative_to(SUCCESSOR)) for p in SUCCESSOR.rglob("*") if p.is_file()}
    check(
        physical == set(paths) | {"artifact-manifest.json", "freeze-proof.json"},
        "complete hidden/ignored physical inventory",
    )
    check(len(paths) == len(set(paths)) == 6 and len(physical) == 8, "six listed/eight physical")
    check(
        digest(PARENT / "artifact-manifest.json")
        == "99a5bec33bacc2dd7c959a4b59bd618d2b52978f917ab7ff11845dc7c2507bd1",
        "frozen author manifest",
    )
    check(
        (SUCCESSOR / "baseline.json").read_bytes() == BASELINE.read_bytes(),
        "baseline bytes match actual maintained baseline",
    )
    check(
        (SUCCESSOR / "baseline.json").read_bytes()
        == (PARENT / "inputs/ontology-baseline.json").read_bytes(),
        "baseline bytes match frozen author input",
    )
    check(
        (SUCCESSOR / "accepted-four-term-delta.json").read_bytes()
        == (PARENT / "results/four-term-additive-proposal.json").read_bytes(),
        "delta exact frozen author bytes",
    )
    review = Path(
        "/private/tmp/pathwaymech-next-272-independent-ontology-review/source-review-result.json"
    )
    check(
        (SUCCESSOR / "source-review-result.json").read_bytes() == review.read_bytes(),
        "source review exact root bytes",
    )
    baseline = read(BASELINE)
    delta = read(SUCCESSOR / "accepted-four-term-delta.json")
    candidate = read(SUCCESSOR / "proposed-ontology.json")
    original = read(PARENT / "results/proposed-ontology.json")
    check(delta["baseline_sha256"] == digest(BASELINE), "delta baseline binding")
    check(
        set(delta["terms_added"]) == {"GO:0031471", "GO:0031469", "CHEBI:16000", "NCBITaxon:99287"},
        "exact four identifiers",
    )
    for key in ("sources_added", "sources_modified", "terms_modified", "terms_removed"):
        check(delta[key] == {}, "empty delta " + key)
    check(list(candidate) == list(baseline), "top-level object key order unchanged")
    for key in baseline.keys() - {"terms"}:
        check(
            ordered(candidate[key]) == ordered(baseline[key]),
            "recursive source/top-level data unchanged " + key,
        )
    check(
        list(candidate["terms"]) == list(baseline["terms"]) + list(delta["terms_added"]),
        "complete term order remains prefix plus four additions",
    )
    for ident, term in baseline["terms"].items():
        check(
            ordered(candidate["terms"][ident]) == ordered(term),
            "recursive prior term unchanged " + ident,
        )
    for ident, term in delta["terms_added"].items():
        check(ident not in baseline["terms"], "addition absent baseline " + ident)
        check(
            ordered(candidate["terms"][ident]) == ordered(term), "exact recursive new term " + ident
        )

    def serializer(value):
        return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()

    check(
        serializer(baseline) == BASELINE.read_bytes(),
        "serializer exactly reproduces entire baseline bytes",
    )
    merged = read(BASELINE)
    merged["terms"].update(delta["terms_added"])
    check(
        serializer(merged) == (SUCCESSOR / "proposed-ontology.json").read_bytes(),
        "candidate exact append-only serialization",
    )
    check(candidate == original, "semantic equivalence with original sorted candidate")
    check(
        len(baseline["terms"]) == 2211 and len(candidate["terms"]) == 2215,
        "exact complete term counts",
    )
    from pathwaymech.identifiers import _load_authority

    check(
        _load_authority(SUCCESSOR / "proposed-ontology.json") == candidate["terms"],
        "unchanged full consumer accepts complete ontology candidate",
    )
    result = {
        "accepted": True,
        "reviewer": "/root/next272_authority_implementation",
        "scope": (
            "Independent mechanical acceptance of exact four-term ontology order correction only. "
            "No new independent scientific review or source database rehash is claimed."
        ),
        "checks_passed": len(CHECKS),
        "checks": CHECKS,
        "successor_manifest_sha256": digest(SUCCESSOR / "artifact-manifest.json"),
        "candidate_sha256": digest(SUCCESSOR / "proposed-ontology.json"),
        "baseline_sha256": digest(BASELINE),
        "prior_terms": 2211,
        "new_terms": 4,
        "sources_unchanged": True,
        "recursive_existing_key_order_preserved": True,
        "physical_inventory_includes_hidden_and_ignored": True,
    }
    (OWNER / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "checks"}))


if __name__ == "__main__":
    main()
