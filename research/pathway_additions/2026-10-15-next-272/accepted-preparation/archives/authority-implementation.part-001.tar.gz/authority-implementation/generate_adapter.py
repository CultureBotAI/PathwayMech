"""Prepare a scratch adapter from the bound original inventory; no maintained writes."""

from __future__ import annotations

import hashlib
import json
import pprint
from pathlib import Path
from xml.etree import ElementTree as ET

OWNER = Path(__file__).resolve().parent
BASE = Path("/private/tmp/pathwaymech-next-272-20261015")
INVENTORY = Path(
    "/private/tmp/pathwaymech-next-272-authority-design/provisional-selected-source-shapes.json"
)


def identifier(node):
    return ("MetaCyc:" if node.get("orgid") == "META" else "EcoCyc:") + node.get("frameid")


def main():
    inventory = json.loads(INVENTORY.read_bytes())
    rows = inventory["new_native_objects"]
    profiles = {}
    equations = {}
    materials = {}
    activities = {}
    complexes = set()
    components = {}
    ordering = []
    members = []
    object_tags = set()
    for row in rows:
        raw = Path(row["source_path"]).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == row["source_sha256"]
        entity = ET.fromstring(raw)[1]
        ident = row["id"]
        assert ident == identifier(entity)
        profiles[ident] = {
            "embedded_shapes": {
                (r["tag"], r["class"], r["detail"]): r["count"] for r in row["embedded_shapes"]
            },
            "is_class": row["is_class"],
            "parents": [(r["tag"], r["frameid"]) for r in row["parents"]],
            "slots": row["slots"],
            "tag": row["native_type"],
        }
        object_tags.update(r["tag"] for r in row["embedded_shapes"])
        object_tags.add(row["native_type"])
        if entity.tag == "Reaction":
            equation = {"direction": entity.findtext("reaction-direction")}
            for side in ("left", "right"):
                occurrences = []
                for wrapper in entity.findall(side):
                    material = next(
                        n for n in wrapper if n.tag not in {"coefficient", "compartment"}
                    )
                    role = {"tag": material.tag, "is_class": material.get("class") == "true"}
                    if material.get("frameid") in materials:
                        assert materials[material.get("frameid")] == role
                    materials[material.get("frameid")] = role
                    assert wrapper.find("compartment") is None
                    coefficient = wrapper.findtext("coefficient")
                    occurrences.append(
                        {
                            "material": identifier(material),
                            "native_type": material.tag,
                            "is_class": role["is_class"],
                            "coefficient": int(coefficient) if coefficient is not None else None,
                            "compartment": None,
                        }
                    )
                equation[side] = occurrences
            equations[ident] = equation
        if entity.tag == "Enzymatic-Reaction":
            activities[ident] = {
                slot: identifier(entity.find(slot)[0]) for slot in ("enzyme", "reaction")
            }
        if row["proposed_role"]["category"] == "complex":
            complexes.add(ident)
            components[ident] = [
                {
                    "id": identifier(wrapper.find("Protein")),
                    "coefficient": int(wrapper.findtext("coefficient"))
                    if wrapper.find("coefficient") is not None
                    else None,
                }
                for wrapper in entity.findall("component")
            ]
        if entity.tag == "Pathway":
            members = [identifier(n) for n in entity.find("reaction-list")]
            ordering = [
                {
                    "reaction": identifier(wrapper.find("Reaction")),
                    "predecessors": [identifier(n) for n in wrapper.find("predecessor-reactions")],
                }
                for wrapper in entity.findall("reaction-ordering")
            ]
    source = (BASE / "src/pathwaymech/biocyc_acetate_methanogenesis.py").read_text()
    header = source[: source.index("KIND =")]
    header = header.replace("METH-ACETATE-PWY", "PWY0-1477")
    header = header.replace("Prospective scope:", "Finite scope:")
    consts = {
        "PROFILES": profiles,
        "COMPLEXES": complexes,
        "MATERIAL_ROLES": materials,
        "NATIVE_MEMBERS": members,
        "EXACT_ORDERING": ordering,
        "EXACT_EQUATIONS": equations,
        "EXACT_ACTIVITIES": activities,
        "EXACT_COMPONENTS": components,
    }
    preamble = """META_KIND = "metacyc-ethanolamine-xml"
ECO_KIND = "ecocyc-ethanolamine-xml"
ETHANOLAMINE_KINDS = {META_KIND, ECO_KIND}
FIELD = "native_ethanolamine"
_NATIVE_IDENTITY_ATTRIBUTES = {"frameid", "orgid", "ID", "resource"}
"""
    preamble += (
        "_NATIVE_OBJECT_TAGS = " + pprint.pformat(object_tags, width=96, sort_dicts=True) + "\n"
    )
    preamble += (
        "\n".join(
            k + " = " + pprint.pformat(v, width=96, sort_dicts=True) for k, v in consts.items()
        )
        + "\n"
    )
    suffix = source[source.index("NODE_ROLES =") :]
    suffix = suffix.replace("ACETATE_METHANOGENESIS", "ETHANOLAMINE").replace(
        "acetate_methanogenesis", "ethanolamine"
    )
    suffix = suffix.replace(
        '    "native_ethanolamine_reaction": ("reactions", {"molecular_activity"}),',
        '    "native_ethanolamine_reaction": ("reactions", {"molecular_activity"}),\n'
        '    "native_ethanolamine_location": ("participants", {"cellular_component"}),',
    )
    suffix = suffix.replace(
        'return "META", "MetaCyc"',
        'return ("META", "MetaCyc") if kind == META_KIND else ("ECOLI", "EcoCyc")',
    )
    suffix = suffix.replace(
        "def _source_frame(source: dict) -> str:",
        "def _source_frame(source: dict, pgdb: str) -> str:",
    )
    suffix = suffix.replace(
        "all 52 selected acquisition receipts", "all 63 selected acquisition receipts"
    )
    suffix = suffix.replace("getxml\\?META:", "getxml\\?{pgdb}:")
    suffix = suffix.replace(
        "exact acquired native HTTPS META request", "exact acquired native HTTPS request"
    )
    suffix = suffix.replace("frame = _source_frame(source)", "frame = _source_frame(source, pgdb)")
    suffix = suffix.replace(
        'Counter(["species"]),',
        'Counter(["species"] if pgdb == "META" else ["species", "strain", "dblink"]),',
    )
    suffix = suffix.replace(
        'scalar(db, "species", True) == "MetaCyc",',
        'scalar(db, "species", True) == ("MetaCyc" if pgdb == "META" else "Escherichia coli"),',
    )
    eco_source = (BASE / "src/pathwaymech/biocyc_phenylacetate.py").read_text()
    eco = eco_source[
        eco_source.index(
            '    if pgdb == "ECOLI":', eco_source.index("def _envelope")
        ) : eco_source.index("    attributes(entity", eco_source.index("def _envelope"))
    ]
    suffix = suffix.replace(
        "    attributes(entity, frame, pgdb,", eco + "    attributes(entity, frame, pgdb,", 1
    )
    suffix = suffix.replace(
        'return {"id": "MetaCyc:" + frame, "native_type": tag, "is_class": is_class}',
        'return {"id": ("MetaCyc:" if pgdb == "META" else "EcoCyc:") + frame, '
        '"native_type": tag, "is_class": is_class}',
    )
    suffix = suffix.replace("acetate pathway equation materials", "ethanolamine equation materials")
    suffix = suffix.replace(
        '{"REVERSIBLE", "PHYSIOL-LEFT-TO-RIGHT", "PHYSIOL-RIGHT-TO-LEFT"}',
        '{"REVERSIBLE", "LEFT-TO-RIGHT", "PHYSIOL-LEFT-TO-RIGHT"}',
    )
    suffix = suffix.replace(
        'len(members) == 6 and set(members) == {prefix + ":" + f for f in NATIVE_MEMBERS}',
        "members == NATIVE_MEMBERS",
    )
    suffix = suffix.replace(
        "wrong complete METH-ACETATE-PWY native membership",
        "wrong complete PWY0-1477 native membership",
    )
    suffix = suffix.replace(
        '        result["reaction_list"] = members',
        """        result["reaction_list"] = members
        ordering = []
        for wrapper in entity.findall("reaction-ordering"):
            blank(wrapper)
            require(not wrapper.attrib and Counter(n.tag for n in wrapper)
                    == Counter({"Reaction": 1, "predecessor-reactions": 1}),
                    "invalid pathway ordering wrapper")
            reaction = ref_node(one(wrapper, "Reaction"), pgdb, "Reaction")["id"]
            predecessors = one(wrapper, "predecessor-reactions")
            blank(predecessors)
            require(not predecessors.attrib and len(predecessors) == 1,
                    "invalid pathway predecessor list")
            ordering.append({"reaction": reaction,
                "predecessors": [ref_node(n, pgdb, "Reaction")["id"] for n in predecessors]})
        require(ordering == EXACT_ORDERING, "wrong exact pathway reaction ordering")
        result["reaction_ordering"] = ordering""",
    )
    suffix = suffix.replace(
        "expected = KIND", 'expected = META_KIND if ident.startswith("MetaCyc:") else ECO_KIND'
    )
    output = OWNER / "biocyc_ethanolamine.py"
    output.write_text(header + preamble + "\n" + suffix)
    print(
        json.dumps(
            {
                "output": str(output),
                "profiles": len(profiles),
                "components": len(components),
                "equations": len(equations),
                "materials": len(materials),
                "source_inventory_sha256": hashlib.sha256(INVENTORY.read_bytes()).hexdigest(),
            }
        )
    )


if __name__ == "__main__":
    main()
