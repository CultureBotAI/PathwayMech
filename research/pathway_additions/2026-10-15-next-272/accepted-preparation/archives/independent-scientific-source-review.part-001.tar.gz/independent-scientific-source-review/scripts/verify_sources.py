"""Read-only finite source verification; it does not establish scientific truth."""
from pathlib import Path
import collections
import hashlib
import json
import xml.etree.ElementTree as ET

OWNERS = {
    'primary': (Path('/private/tmp/pathwaymech-next-272-primary-evidence-preparation'), '86974c5ce2562d549755f18b30fa27a14ac6c6d5007b476aaeefe105eaa36ada'),
    'native': (Path('/private/tmp/pathwaymech-next-272-native-source-preparation'), 'd7fe7fedf9315c241782ce9b26729804461dda646ba903da312fba0996054d13'),
}
checks = []
def check(name, condition, detail):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for key, (owner, expected) in OWNERS.items():
    manifest = json.loads((owner / 'artifact-manifest.json').read_text())
    rows = manifest['files']
    actual = {str(p.relative_to(owner)) for p in owner.rglob('*') if p.is_file()}
    required = {r['path'] for r in rows} | {'artifact-manifest.json', 'freeze-proof.json'}
    failures = [r['path'] for r in rows if not (owner/r['path']).is_file() or (owner/r['path']).stat().st_size != r['bytes'] or sha(owner/r['path']) != r['sha256']]
    check(key+'-manifest-binding', sha(owner/'artifact-manifest.json') == expected, expected)
    check(key+'-all-file-hashes-and-sizes', not failures, {'listed':len(rows), 'failures':failures})
    check(key+'-physical-inventory', actual == required, {'physical':len(actual),'extra':sorted(actual-required),'missing':sorted(required-actual),'hidden_and_ignored_included':True})
native=OWNERS['native'][0]
def obj(org, frame):
    root=ET.parse(native/'originals'/f'{org}-{frame}.xml').getroot()
    objects=[e for e in root if e.tag != 'metadata']
    assert len(objects)==1
    e=objects[0]
    assert e.get('frameid')==frame and e.get('orgid')==org and e.get('detail')=='full'
    return e
root=obj('META','PWY0-1477')
reactions=[x.get('frameid') for x in root.findall('reaction-list/Reaction')]
check('five-native-reactions',set(reactions)=={'ETHAMLY-RXN','ACETALD-DEHYDROG-RXN','PHOSACETYLTRANS-RXN','ACETATEKIN-RXN','ALCOHOL-DEHYDROG-RXN'},reactions)
check('root-own-slots-and-ordering',len(root)==21 and len(root.findall('reaction-ordering'))==4,{'slots':len(root),'orderings':len(root.findall('reaction-ordering'))})
lead_ids=set()
for rid in reactions:
    lead_ids.update(x.get('frameid') for x in obj('META',rid).findall('enzymatic-reaction/Enzymatic-Reaction'))
dispositions=json.loads((native/'results/all71-activity-dispositions.json').read_text())
dids=[x['activity'] for x in dispositions]
check('all-native-activity-leads-dispositioned',len(lead_ids)==71 and set(dids)==lead_ids and len(dids)==len(set(dids)),{'leads':len(lead_ids),'dispositions':len(dids)})
enzymes=set(); mismatch=[]
for d in dispositions:
    e=obj('META',d['activity'])
    eid=[x.get('frameid') for x in e.findall('enzyme/Protein')]
    rid=[x.get('frameid') for x in e.findall('reaction/Reaction')]
    if eid != [d['enzyme']] or rid != [d['reaction']]:mismatch.append(d['activity'])
    enzymes.update(eid)
for eid in enzymes:obj('META',eid)
check('71-activity-enzyme-reaction-bindings',not mismatch,mismatch)
check('68-linked-enzymes-plus-separate-eutd-subunit',len(enzymes)==68 and 'G7288-MONOMER' not in enzymes and obj('META','G7288-MONOMER').tag=='Protein',{'linked':len(enzymes),'additional_subunit':'G7288-MONOMER'})
c=collections.Counter(x['disposition'] for x in dispositions)
check('activity-disposition-counts',sorted(c.values())==[7,8,56],dict(c))
components=[(x.find('Protein').get('frameid'),x.findtext('coefficient')) for x in obj('META','ETHAMLY-CPLX').findall('component')]
check('eutbc-issued-six-plus-six',set(components)=={('EUTB-MONOMER','6'),('EUTC-MONOMER','6')},components)
t=obj('META','CPLX-9275').findall('component')
check('eutt-native-coefficient-is-omitted',len(t)==1 and t[0].find('coefficient') is None,{'component':t[0].find('Protein').get('frameid'),'coefficient':t[0].findtext('coefficient')})
u=[json.loads(p.read_text()) for p in sorted((native/'originals').glob('UniProt-*.json'))]
bytax=collections.defaultdict(list)
for e in u:bytax[e['organism']['taxonId']].append(e)
check('34-uniprot-17-genes-per-taxon',len(u)==34 and {k:len(v) for k,v in bytax.items()}=={83333:17,99287:17} and len({x['genes'][0]['geneName']['value'] for x in u})==17,{'taxa':{k:len(v) for k,v in bytax.items()}})
check('all-k12-cautions-present',all(any(c['commentType']=='CAUTION' and 'CPZ-55' in json.dumps(c) for c in x['comments']) for x in bytax[83333]),{'scope':'source curator cautions only, not proof of route absence'})
check('298-comments-retained',sum(len(x.get('comments',[])) for x in u)==298,{'count':sum(len(x.get('comments',[])) for x in u)})
reg=[]
for f in sorted((native/'originals').glob('META-REG*.xml')):
    e=obj('META',f.stem[len('META-'):]);reg.append({'id':e.get('frameid'),'target':e.find('regulated-entity/Enzymatic-Reaction').get('frameid'),'mode':e.findtext('mode')})
rc=collections.Counter(x['target'] for x in reg)
check('regulation-contexts',len(reg)==12 and rc['ETHAMLY-ENZRXN']==8 and rc['ENZRXN0-7425']==1,reg)
primary=OWNERS['primary'][0]
for name in ['PMC9481676-efetch.xml','PMC4857615-efetch.xml','cargo-2012-primary.xml','PMC3439341-efetch.xml','PMC4827028-efetch.xml']:
    e=ET.parse(primary/'originals'/name).getroot()
    check(name+'-main-body-present',e.find('.//body') is not None,{'body_paragraphs':len(e.findall('.//body//p'))})
for name in ['PMC355984-efetch.xml','PMC3697265-efetch.xml','PMC3187147-efetch.xml','PMC3911174-efetch.xml']:
    e=ET.parse(primary/'originals'/name).getroot()
    check(name+'-raw-body-not-claimed',e.find('.//body') is None,{'main_text_reviewed_only_as_retained_publisher_tool_projection':True})
for name in ['2022-supplement-EuropePMC.zip','EutPQ-supplement-EuropePMC.zip']:
    b=(primary/'originals'/name).read_bytes()
    check(name+'-not-a-supplement-zip',not b.startswith(b'PK'),{'prefix':b[:120].decode(errors='replace')})
print(json.dumps({'format':'finite-scientific-source-verification/1','checks':checks,'all_passed':all(x['passed'] for x in checks),'mechanical_scope_only':True},indent=2))
raise SystemExit(0 if all(x['passed'] for x in checks) else 1)
