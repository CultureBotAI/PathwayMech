"""One-time freeze of this scratch review; no writes to source parents."""
from pathlib import Path
import collections,datetime,hashlib,json
R=Path(__file__).resolve().parents[1]
assert not (R/'artifact-manifest.json').exists() and not (R/'freeze-proof.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((R/p).read_text())
parsed=[]
for p in sorted(R.rglob('*.json')):
 json.loads(p.read_text());parsed.append(str(p.relative_to(R)))
a=read('results/independent-activity-dispositions.json')['activities']
assert len(a)==71 and len(set(z['activity'] for z in a))==71
assert sorted(collections.Counter(z['independent_disposition'] for z in a).values())==[7,8,56]
for x in a:
 assert sha(Path(x['original_activity']))==x['activity_sha256']
 assert sha(Path(x['original_enzyme']))==x['enzyme_sha256']
c=read('results/independent-claim-dispositions.json')['claims'];assert len(c)==32 and len(set(z['id'] for z in c))==32
n=read('results/independent-native-conflict-dispositions.json');assert len(n)==19
for x in n:
 assert sha(Path(x['native_conflict_ledger']))==x['ledger_sha256']
 for s in x['source_locators']:assert sha(Path(s['source']))==s['sha256']
sc=read('results/reading-scope.json')['primary'];assert len(sc)==24
for x in sc:
 for f in x['bound_artifacts']:
  p=Path(x['original_owner'])/f['path'];assert sha(p)==f['sha256'] and p.stat().st_size==f['bytes']
for b in read('results/final-parent-bindings.json'):
 p=Path(b['owner'])
 for f,h in b['bindings'].items():assert sha(p/f)==h
 rows=json.loads((p/'artifact-manifest.json').read_text())['files']
 assert {str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()}=={x['path'] for x in rows}|{'artifact-manifest.json','freeze-proof.json'}
 assert all(sha(p/x['path'])==x['sha256'] and (p/x['path']).stat().st_size==x['bytes'] for x in rows)
assert read('results/independent-source-verification.json')['all_passed']
assert read('results/successor-verifier-replay.json')['exit_code']==0
validation={'status':'pass','json_files_parsed':len(parsed),'claims':32,'primary_scope_entries':24,'activity_dispositions':71,'native_conflict_dispositions':19,'all_bound_source_files_hash_and_size_verified':True,'three_parent_owners_reverified_unchanged':True,'full_physical_inventory_includes_hidden_and_ignored':True,'scope':'Mechanical completeness and binding checks; scientific interpretation is manual and bounded by reading-scope.json.'}
(R/'results/final-review-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
rows=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(R.rglob('*')) if p.is_file()]
manifest={'format':'finite-independent-scientific-source-review/1','owner':str(R),'author_agent':'/root/next272_scientific_source_review','files':rows}
(R/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(R/'artifact-manifest.json'),'handoff_sha256':sha(R/'HANDOFF.md'),'listed_file_count':len(rows),'physical_file_count':len(rows)+2,'listed_bytes':sum(x['bytes'] for x in rows),'all_jobs_terminal':True,'files_verified':True,'hidden_and_ignored_included':True,'parents_untouched':True,'scope':'Finite independent source-preparation review and successor acceptance; no maintained-record/graph acceptance.'}
(R/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}=={x['path'] for x in rows}|{'artifact-manifest.json','freeze-proof.json'}
assert all(sha(R/x['path'])==x['sha256'] and (R/x['path']).stat().st_size==x['bytes'] for x in rows)
print(json.dumps({**proof,'freeze_sha256':sha(R/'freeze-proof.json')},indent=2))
