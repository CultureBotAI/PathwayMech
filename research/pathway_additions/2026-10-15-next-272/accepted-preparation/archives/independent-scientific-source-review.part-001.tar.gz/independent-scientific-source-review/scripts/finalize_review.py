"""Construct finite independent review artifacts; never writes source owners."""
from pathlib import Path
import json,hashlib,datetime,xml.etree.ElementTree as ET,subprocess
R=Path(__file__).resolve().parents[1]
P=Path('/private/tmp/pathwaymech-next-272-primary-evidence-preparation')
N=Path('/private/tmp/pathwaymech-next-272-native-source-preparation')
S=Path('/private/tmp/pathwaymech-next-272-native-magnesium-successor')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,obj):(R/p).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
bindings=[]
for owner,hashes in [(P,['86974c5ce2562d549755f18b30fa27a14ac6c6d5007b476aaeefe105eaa36ada','279b0dca97a6e8d58c7415dc0cb6c113e0b4016b333bc57a9f0990dd9bec6b11','1d26dbbf28813f0d34c785a196babc085b7f1a727dd28a41c577d5e4b90610bb']),(N,['d7fe7fedf9315c241782ce9b26729804461dda646ba903da312fba0996054d13','e7d836919df954932e0a95790002e4b9d61e0c7d0039d75b719f3fa0a26d8ad3','5d138b2d3314b8b12ef9c674df7801814f16d26c7efc56038c708f28832be867']),(S,['0c06c20359e41a1b696fcc705cd34974ccae26a468349511958a2a8d99dba08e','60e2c3d1a94c5c6af74c0d553c32ba3925f3631b449dc271dfad683dd30d2eee','5233ef900c408d63272d33a595d473fc66cb68edbd2b279e2a0e21bf3a58ef26'])]:
 keys=['artifact-manifest.json','HANDOFF.md','freeze-proof.json']
 assert [sha(owner/k) for k in keys]==hashes
 rows=json.loads((owner/keys[0]).read_text())['files']
 actual={str(p.relative_to(owner)) for p in owner.rglob('*') if p.is_file()}
 assert actual=={x['path'] for x in rows}|{'artifact-manifest.json','freeze-proof.json'}
 assert all(sha(owner/x['path'])==x['sha256'] and (owner/x['path']).stat().st_size==x['bytes'] for x in rows)
 bindings.append({'owner':str(owner),'bindings':dict(zip(keys,hashes)),'listed_files':len(rows),'physical_files':len(actual),'listed_bytes':sum(x['bytes'] for x in rows),'hidden_and_ignored_included':True,'all_hashes_sizes_physical_membership_pass':True})
put('results/final-parent-bindings.json',bindings)
# Fix only this review's diagnostic projection. Preserve initial attempt explicitly.
a=R/'projections/all68-direct-enzyme-readings.json';old=R/'projections/all68-direct-enzyme-readings-attempt1.json'
if not old.exists():old.write_bytes(a.read_bytes())
x=json.loads(old.read_text());changed=[]
for d in x:
 e=ET.parse(N/'originals'/('META-'+d['id']+'.xml')).getroot()
 obj=[z for z in e if z.tag!='metadata'][0]
 d['locations']=[ET.tostring(z,encoding='unicode') for z in obj.findall('location')]
 d['original_source']=str(N/'originals'/('META-'+d['id']+'.xml'))
 if d['locations']:changed.append(d['id'])
put('projections/all68-direct-enzyme-readings.json',x)
put('results/projection-correction.json',{'initial':'projections/all68-direct-enzyme-readings-attempt1.json','successor':'projections/all68-direct-enzyme-readings.json','defect':'Initial diagnostic searched plural locations; source own slot is singular location. Empty projection fields were not used to infer absent locations.','corrected_nonempty_ids':changed,'scope':'Projection correction only. Native/primary owners unchanged; no biological conclusion changes.'})
# Conservative precision in manual claim scopes after final coverage audit.
c=json.loads((R/'results/independent-claim-dispositions.json').read_text())
for row in c['claims']:
 if row['id']=='P08':row['review_disposition']='Corroborated against targeted 2022 body results, discussion and methods plus Fig5 caption. Low versus high CNCbl growth and direct in-vitro EutA/EAL interaction are distinct evidence. No fixed complex ratio or EutT donor interaction is shown. Independent paragraph projection is distinct from article P identifiers; no complete methods-section reading claim.'
c['successor_acceptance']='results/successor-acceptance.json; original required-qualification statuses are retained as review history, now satisfied at preparation scope only.'
put('results/independent-claim-dispositions.json',c)
# Re-run original author's bounded verifier read-only; retain stdout locally.
r=subprocess.run(['python','-B',str(S/'scripts/verify.py')],capture_output=True,text=True)
assert r.returncode==0
put('results/successor-verifier-replay.json',{'command':['python','-B',str(S/'scripts/verify.py')],'exit_code':r.returncode,'stdout':json.loads(r.stdout),'stderr':r.stderr})
repl=json.loads((S/'results/successor-dispositions.json').read_text())
put('results/successor-acceptance.json',{'reviewer':'/root/next272_scientific_source_review','owner':str(S),'bindings':bindings[2],'decision':'accepted_for_preparation_with_explicit_limits','semantic_inspection':{'successor_fields':25,'direct_overstatements':11,'distinct_old_new_pairs':len(set((z['old_interpretation'],z['successor_interpretation']) for z in repl)),'all_distinct_pairs_and_each_locator_read':True,'primary_elements_rechecked':['P13','P14','P20','P39','P40','F8-caption'],'primary_original':str(P/'originals/PMC4857615-efetch.xml'),'source_sha256':sha(P/'originals/PMC4857615-efetch.xml'),'interpretation':'Reported EDTA-treatment resistance under documented Mg-containing assay protocols is supported. No separate Mg-free formulation is described; Q comparison is data not shown. Do not infer Mg-independent catalysis, a bound Mg cofactor, fixed metal stoichiometry or physiological metal requirement. K12 similarity annotations are not direct LT2 assay evidence.'},'findings':[{'id':'next272-preparation-eutpq-divalent-cation-scope','preparation_status':'corrected_by_accepted_immutable_successor','original_finding':'results/eutpq-metal-finding.json','issue':'https://github.com/CultureBotAI/PathwayMech/issues/634','issue_state':'open_per_root_verified_report','issue_closure_requirement':'Actual eventual merged-record and graph verification; this review does not close it.'},{'id':'next272-preparation-s24-first-author','preparation_status':'corrected_by_accepted_immutable_successor','original_finding':'results/s24-citation-finding.json','accepted_citation':'Held, Kolb, Perdue et al. 2016; PMID27063436; DOI10.1038/srep24359','scope':'Author-order correction only; biology unchanged.'}],'contextual_euth':'Historical iModulon /genes/4/uniprot_function preserved as a conflicting source annotation. It adds no transport microstate, chemistry, native flux or BMC delivery evidence. This is targeted field inspection, not independent whole-iModulon review.','source_assertions_preserved':True,'parents_unchanged':True,'maintained_record_review':False})
scopes=[
('S01','retained publisher web-tool main projection','270–282, 348–374, 393–425, 445–500, 558, 567; targeted methods/model/rescue and table legend','No raw main HTML/PDF; no figure pixels; external EutBC is explicitly untested.'),
('S02','retained publisher web-tool main projection','85–125 short main and captions','Raw XML is metadata/abstract. Reverse assay and plasmid rescue do not prove native localization.'),
('S03','official NCBI XML main','Targeted results, discussion, strain/assay methods and Figure5 caption; independent projection primarily objects2–40','No complete all-paragraph or SI/pixel claim; projection object ordinals differ from XML P IDs; internal caption ambiguity retained.'),
('S04','official NCBI XML main','Targeted results/methods/discussion, Tables1/2, Figures4/7–9 captions; successor re-read P13/P14/P20/P39/P40/F8','EutP negative SI remains unavailable; no full figure-pixel suite; Mg scope corrected.'),
('S05','official publisher XML main','Targeted reporter constructs/results/captions/methods; projection objects16,18–22,37–40,45,48,53,56,57','Supporting Word files acquired by preparer but not freshly independently semantically reviewed; movies/TIFFs uninspected.'),
('S06','official NCBI XML and exact original Figure3 image','Targeted EutG results, Table1, construction/lysate methods; all Figure3 EutG plotted rates inspected visually','Crude extracts from engineered JCL16/BW25113-related context, not purified kinetics or native LT2/MG1655 flux.'),
('S07','retained publisher web-tool main projection','119–120,176,179,189–196,204–222','LT2 donor, BL21 recombinant preparation and engineered MG1655 application kept separate; raw XML metadata only.'),
('S08','retained publisher web-tool main projection','100–123,151–248 methods/results','Raw XML metadata only; assay flavin/reductant and reconstitution do not establish physiological metal/donor exclusivity.'),
('S09','retained publisher web-tool main projection','112–134,173–204 methods/reactivation and captions','No direct native MG1655 localization or flux; no raw main claim.'),
('S10','author-hosted original PDF plus derived text and page renders','Original retained page1 and page5 pixels; targeted uncharged-substrate, pH/concentration and fusion prose','Not purified transport assay; no all-page pixel reading.'),
('S11','author-hosted PDF text projection','510–576 extract activity/genetic distinction','PDF pixels not independently reviewed; no homogeneous EutT kinetics inferred.'),
('S12','author-hosted PDF text projection','500–640 reporter/revertant/transcription results','Not complete main or direct ligand-binding proof.'),
('S13','author-hosted PDF text projection','22–82 abstract/introduction','Competition/autoinduction is model; remaining main not independently reviewed.'),
('S14','author-hosted PDF text projection','20–70 abstract/introduction','Gene inventory/homology does not establish all mechanisms; remaining main not independently reviewed.'),
('S15','acquired author-hosted PDF','No independent semantic reading','Acquisition acknowledged only; no independent biological claim based on this paper.'),
('S16','retained discovery original HTML and text projection','Methods86, results274–285, discussion288–295','GSSG methods/captions versus GSH discussion explicitly unresolved; no independent Starai original reading.'),
('S17','retained discovery original HTML and text projection','243–247,470–481 pH/gas loss/background discussion','Background explanation tentative; later washing result does not universally reconcile conditions.'),
('S18','EuropePMC returned abstract','Complete returned abstract PMID16636051','Abstract tier only; cobinamide conflict unresolved.'),
('S19','EuropePMC returned abstract','Complete returned abstract PMID21046341','Abstract tier only; detailed kinetic main not independently reviewed.'),
('S20','EuropePMC returned abstract','Complete returned abstract PMID19762342','Abstract tier only; truncated EAL structural context.'),
('S21','EuropePMC returned abstract','Complete returned abstract PMID24269999','Engineered yeast context only; not native route flux.'),
('S22','EuropePMC returned abstract','Complete returned abstract PMID26384570','Engineered yeast context only; not native route flux.'),
('S23','EuropePMC returned abstract','Complete returned abstract PMID27450681','Reporter encapsulation context; not full native protein localization.'),
('S24','official NCBI XML main','Targeted independent projection objects11–30,35–42; original author front matter','Tag orientation, artificial assembly and proposed cytoplasmic placement remain qualified; no SI/movie pixels.'),
]
ledger=json.loads((P/'results/source-reading-ledger.json').read_text())['sources']
rows=[]
for key,mode,read,limits in scopes:
 entry=next(z for z in ledger if z['key']==key)
 rows.append({'key':key,'citation_as_original_ledger':entry['citation'],'citation_successor':('Held, Kolb, Perdue et al. 2016; PMID27063436; DOI10.1038/srep24359' if key=='S24' else None),'original_owner':str(P),'source_ledger_locator':'/sources/'+str(ledger.index(entry)),'source_ledger_sha256':sha(P/'results/source-reading-ledger.json'),'bound_artifacts':entry['artifacts'],'access_mode':mode,'independent_reading_scope':read,'limits':limits})
put('results/reading-scope.json',{'scope':'Finite source-preparation review, not fresh complete whole-corpus or all-papers-fulltext review','primary':rows,'native':{'mechanical_intake':'All 619 listed/621 physical files hashed; 204 META/24 ECOLI full objects and 34 UniProt originals bound. This does not mean all 3,689 own slots independently interpreted.','semantic_read':'All71 activity lead original comments/directions/evidence labels and corresponding preparation dispositions; all68 linked enzyme narratives; selected separate EutD subunit; all24 ECOLI object top-level names/comments/components with targeted correct singular location inspection; selected complex/component and12 regulation objects; all34 protein semantic dispositions; all19 source-conflict groups.','uniprot':'All298 comments retained and mechanically counted; their136 distinct semantic value strings freshly read, with source references, alongside relevant complete catalytic/cofactor/kinetic objects for selected claims. Not a claim that every numeric/atomic field was independently scientifically reviewed.','taxonomy':'17 genes each for83333 and99287; all17 K12 CPZ-55 caution comments inspected as curator inference.'},'figure_pixels_independently_inspected':['EutH2004 retained PDF page1 render','EutH2004 retained PDF page5 render','EutG2012 original Figure3 image'],'failed_access':'Original packets preserve raw failed accesses, including HTTP200 XML error bodies with .zip suffix. No fresh network acquisition or access repair by this reviewer.','instructions':'Copied small instructions from next271 worktree before cleanup; applied add-pathway and review-yaml-record source-evidence rubrics, curation/graph/identifier constraints. These copies are context, not a verified merged next272 baseline.'})
put('RESULT.json',{'decision':'qualified_source_preparation_accepted_with_immutable_successor','candidate':'MetaCyc:PWY0-1477','independent_review_owner':str(R),'preparation_findings':2,'accepted_corrections':2,'github_issue_open':[634],'maintained_content_changed':False,'actual_record_or_graph_review':False,'curation_or_adapter_accepted':False,'fresh_exhaustion_claim':False,'all_jobs_terminal':True,'unresolved_prerequisites':['Bind actual verified merged baseline before maintained curation.','Core material/reaction/taxon authority acceptance is separately root-owned; do not substitute this biological review.','Design identifier-complete graph using source-backed authorities; no local invented CURIEs or predictions promoted to mechanism.','Review actual record/graph/evidence coverage and run repository gates once authored.','Keep issue634 open until actual merged-record verification.'],'remaining_source_limits':['EutT cobinamide conflict and physiological metal/reductant specificity unresolved.','EutT side of shell unresolved; native component coefficient omitted.','2013 external EutBC/private cofactor model not fully demonstrated.','Missing or uninspected supplements/figures and abstract-only papers remain explicitly limited.','No native MG1655 flux conclusion from K12 protein annotations or heterologous assays.']})
print('Review artifacts written; not frozen yet')
