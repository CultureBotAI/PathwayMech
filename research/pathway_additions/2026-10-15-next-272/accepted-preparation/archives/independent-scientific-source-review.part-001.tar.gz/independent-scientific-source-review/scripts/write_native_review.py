from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1]; N=Path('/private/tmp/pathwaymech-next-272-native-source-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
notes=[
'Root original five members/four ordering links independently checked. Preserve both branches; source graph direction is not a measured flux distribution.',
'Primary localized, biochemical and genetic results qualify the generalized root narrative. Whole-pathway lumen and private-pool model cannot be promoted wholesale to demonstrated mechanism.',
'Native EC assertion conflict retained; exact issuer correction is separately core-review-owned. This review accepts conflict preservation, not a new EC mapping.',
'All17 K12 CAUTION texts inspected. Taxon83333 protein scope, MG1655 association and CPZ-55 expression inference remain separate; neither full flux nor absence follows.',
'Direct component originals independently checked6+6. Prose ambiguity remains explicit; catalytic edge belongs to complex, not independently active chains.',
'Native narrative and PMID19762342 abstract support mixed experimental contexts and truncations; no single MG1655 label for every assay.',
'2004 publisher main supports LT2 donor reverse assay/plasmid rescue; 2010 E.coli evidence here is native annotation plus abstract. Keep native dimer/pyruvate findings at that tier.',
'2011 LT2 donor purified recombinant evidence adds direct ALDH/ACR biochemistry; engineered MG1655 fermentation is separate. E.coli yeast assays remain heterologous/unpurified.',
'Original2012 Fig3 visually checked and XML methods read. Crude-extract NADH/NADPH rates are similar; equality of cofactor preference, purified kinetics and native LT2 flux are unsupported.',
'EutH primary PDF pages1/5 and prose support uncharged-substrate interpretation. Charged native reaction participant cannot silently become neutral transport material; iModulon historical field is contextual conflict only.',
'Correct singular native location slots retain EutA membrane and EutG membrane/cytosol assertions. 2022 EutA/EAL association and EutT uncertain side must stay distinct from inference/by-similarity annotations.',
'Native six-chain/crystal and UniProt solution-pentamer annotations are preparation-specific; no uncontested physiological six-chain shell vertex accepted.',
'2012 engineered reporter and shell evidence read at targeted scope. Short peptide targeting, artificial EutS shells, pore crystal states and native full proteins are distinct claims.',
'Primary P/Q activity and conditional phenotype corroborated; original cation wording superseded by accepted Mg correction. No native outer-face location or direct targeting edge follows from tagged assembly/coelution.',
'Native EutT component coefficient omission independently verified. Ancillary chemistry and generic classes remain outside root five reactions. Separate UniProt dimer claim does not populate native coefficient.',
'Conflicting cobinamide statements remain unresolved. Abstract2006 plus2014 targeted main cannot settle all substrate-specific claims; do not cherry-pick or add root chemistry.',
'2014 main and2004 extract evidence distinguish Zn copurification, reconstituted FeII maximum, other metals and assay reductants. No physiologically exclusive iron/donor or direct EAL handoff established.',
'All12 regulation originals read:8 EutBC inhibition,1 EutD activation,3 off-route. EutR genetics/induction distinct from direct ligand binding; predicted FNR site remains prediction.',
'Namespace/class/detail identity cautions accepted. Core chemistry/taxon mapping remains separate specialist acceptance; no local CURIE invention or diagram-placeholder chemical equivalence.'
]
a=json.loads((N/'results/source-conflicts.json').read_text())
assert len(a)==len(notes)==19
out=[]
for i,(x,note) in enumerate(zip(a,notes)):
 out.append({'id':x['id'],'native_conflict_ledger':str(N/'results/source-conflicts.json'),'ledger_sha256':sha(N/'results/source-conflicts.json'),'locator':'/'+str(i),'independent_disposition':note,'source_locators':[{'source':str(N/z['source']),'sha256':z['sha256'],'locator':z['locator']} for z in x['source_claims']],'status':'accepted_with_magnesium_successor' if i==13 else 'qualified_preparation_disposition_supported'})
(R/'results/independent-native-conflict-dispositions.json').write_text(json.dumps(out,indent=2)+'\n')
a=json.loads((N/'results/all71-activity-dispositions.json').read_text())
rows=[]
for i,x in enumerate(a):
 note={'selected_native_eut_activity':'Selected at native authoritative assertion tier; preserve this activity-specific organism, construct and evidence qualifications. Primary upgrades/limits are separately enumerated in independent claim and conflict ledgers.','shared_same_taxon_or_adjacent_context':'Shared chemistry, related organism or adjacent microcompartment does not establish native membership in this five-reaction eut mechanism. Keep contextual only.','not_selected_unrelated_biological_context':'Independent original activity/enzyme narrative reading corroborates exclusion from this candidate route. Reaction association alone is insufficient to select a different biological context.'}[x['disposition']]
 if x['activity'] in ['ENZRXN-26157','ENZRXN-26156']:note+=' Accepted magnesium successor is mandatory; no Mg-independent or bound-Mg mechanism inferred.'
 rows.append({'activity':x['activity'],'reaction':x['reaction'],'enzyme':x['enzyme'],'independent_disposition':x['disposition'],'assessment':note,'native_rationale_bound_not_relabelled_as_independent_quote':x['rationale'],'preparation_ledger':str(N/'results/all71-activity-dispositions.json'),'preparation_locator':'/'+str(i),'original_activity':str(N/'originals'/('META-'+x['activity']+'.xml')),'activity_sha256':x['activity_sha256'],'original_enzyme':str(N/'originals'/('META-'+x['enzyme']+'.xml')),'enzyme_sha256':x['enzyme_sha256']})
(R/'results/independent-activity-dispositions.json').write_text(json.dumps({'scope':'All71 finite native leads, seven selected/eight contextual/56 excluded; semantic reading of original narratives, not all cited primary papers or every kinetic field.','activities':rows},indent=2)+'\n')
