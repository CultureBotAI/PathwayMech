"""Bounded offline checks of the design; this is not biological acceptance."""

import collections
import functools
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

R = Path(__file__).resolve().parents[1]
W = Path("/private/tmp/pathwaymech-next-272-20261015")
sys.dont_write_bytecode = True
sys.path.insert(0, str(W / "src"))
from pathwaymech import schema  # noqa: E402


def read(path):
    return json.loads(path.read_text())


@functools.cache
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


checks = []


def check(condition, assertion):
    if not condition:
        raise AssertionError(assertion)
    checks.append(assertion)


nodes = read(R / "results/node-ledger.json")
payload = read(R / "results/partial-graph-payload.json")
options = read(R / "results/conditional-edge-options.json") + read(
    R / "results/alternative-activity-options.json"
)
refs = {x["id"] for x in read(R / "results/conditional-reference-proposals.json")}
participants = {x["id"] for x in payload["participants"]}
reactions = {x["id"] for x in payload["reactions"]}
categories = {x["id"]: x.get("category") for x in payload["participants"] + payload["reactions"]}
all_ids = participants | reactions | {x["id"] for x in payload["taxa"]} | {payload["id"]}
qualified = {x for x in participants if categories.get(x) in {"protein", "complex"}}
activity = {x for x in participants if categories.get(x) == "molecular_activity"}
for label, edges in [
    ("default", payload["mechanistic_edges"]),
    ("options", [x["graph_edge"] for x in options]),
]:
    errors = []
    schema._validate_edges(
        edges,
        all_ids,
        participants,
        reactions,
        refs,
        errors,
        record_id=payload["id"],
        categories=categories,
        qualified_participants=qualified,
        activity_participants=activity,
    )
    check(not errors, label + " actual-schema edge validation: " + str(errors))
    check(len({x["id"] for x in edges}) == len(edges), label + " unique local edge keys")
for row in nodes:
    errors = []
    schema._validate_curie(row["id"], row["id"], errors)
    check(not errors, row["id"] + " issued-prefix syntax")
    if row["proposed_declaration"] and row["collection"] != "taxa":
        check(row["category"] in schema.NODE_CATEGORIES, row["id"] + " category")

core = read(R / "results/core-occurrences.json")
check(len(core) == 22, "22 complete core material occurrences")
check(len({x["reaction_id"] for x in core}) == 5, "five core source reactions")
check(
    all(x["source_coefficient"] is None and x["effective_coefficient"] == 1 for x in core),
    "all22 core omitted source coefficients remain explicit omitted/effective1",
)
check(
    len([x for x in payload["mechanistic_edges"] if x["id"].startswith("core-order-")]) == 4,
    "four source ordering relations",
)
check(
    len([x for x in payload["mechanistic_edges"] if x["id"].startswith("core-member-")]) == 5,
    "five core memberships",
)
check(
    not any(
        x["predicate"] in {"consumes", "produces", "occurs_in"}
        and payload["id"] in [x["subject"], x["object"]]
        for x in payload["mechanistic_edges"]
    ),
    "no inferred full-route net or universal compartment",
)
check(
    not any(
        x["predicate"] == "catalyzes"
        and x["subject"]
        in [
            "MetaCyc:EUTB-MONOMER",
            "MetaCyc:EUTC-MONOMER",
            "UniProtKB:P19264",
            "UniProtKB:P19265",
            "UniProtKB:P0AEJ6",
            "UniProtKB:P19636",
        ]
        for x in payload["mechanistic_edges"] + [v["graph_edge"] for v in options]
    ),
    "no EutBC subunit whole-reaction catalysis",
)
composition = read(R / "results/composition-ledger.json")
check(
    [x["native_coefficient"] for x in composition if x["complex"] == "MetaCyc:ETHAMLY-CPLX"]
    == ["6", "6"],
    "EutBC source six-plus-six retained",
)
check(
    next(x["native_coefficient"] for x in composition if x["complex"] == "MetaCyc:CPLX-9275")
    is None,
    "EutT source component coefficient stays absent",
)
activities = read(R / "results/all71-activity-design-dispositions.json")
counts = collections.Counter(x["disposition"] for x in activities)
check(
    len(activities) == 71 and len({x["activity"] for x in activities}) == 71,
    "71 distinct activity dispositions",
)
check(sorted(counts.values()) == [7, 8, 56], "activity dispositions7selected8adjacent56unrelated")
check(
    len({x["enzyme"] for x in activities}) == 68,
    "68 distinct linked enzyme objects; prior69plan included separate EutD subunit",
)
slots = read(R / "results/all3689-native-slot-design-dispositions.json")
check(
    len(slots) == 3689 and len({(x["source_id"], x["locator"]) for x in slots}) == 3689,
    "all3689 exact native own slots have separate design decisions",
)
check(
    all(
        x["accepted_native_slot_interpretation"] and x["accepted_native_object_disposition"]
        for x in slots
    ),
    "all own slots retain accepted semantic interpretation and object scope",
)
check(
    len(read(R / "biology-audit/protein-design-ledger.json")) == 34,
    "all34 individual UniProt protein designs",
)
check(
    len(read(R / "biology-audit/primary-claim-design-ledger.json")) == 32,
    "all32 accepted primary claims retained",
)
check(
    len(read(R / "results/accepted-eutt-followup-design.json")) == 6,
    "all6 accepted EutT successor claims retained",
)

# Verify original bytes and direct structured locators used by default edges.
closure = {x["reference_id"]: x for x in read(R / "results/source-closure.json")}
for identifier, row in closure.items():
    path = Path(row["owner"]) / row["path"]
    check(path.is_file() and sha(path) == row["sha256"], "original " + identifier + " exact hash")
for edge in payload["mechanistic_edges"]:
    evidence = list(edge["evidence"])
    for qualifier in edge.get("endpoint_qualifiers", []):
        evidence.extend(qualifier["evidence"])
    for ev in evidence:
        ref = closure[ev["reference_id"]]
        path = Path(ref["owner"]) / ref["path"]
        locator = ev["source_locator"]
        if ev["reference_id"].startswith(("MetaCyc:", "EcoCyc:")):
            root = ET.parse(path).getroot()
            check(
                bool(root.findall("." + locator.removeprefix("/" + root.tag))),
                edge["id"] + " native evidence locator resolves",
            )
        elif ev["reference_id"] == "PMID:26448059":
            root = ET.parse(path).getroot()
            check(
                all(root.find(x.strip()) is not None for x in locator.split("|")),
                edge["id"] + " exact primary XML locator resolves",
            )
for row in read(R / "results/conditional-source-closure.json"):
    check(
        sha(Path(row["path"])) == row["sha256"],
        "conditional source original " + row["reference_id"],
    )
for row in read(R / "results/supplemental-intake-bindings.json"):
    check(
        sha(Path(row["parent_owner"]) / row["parent_path"])
        == row["sha256"]
        == sha(R / row["copy_path"]),
        "supplement copy " + row["copy_path"],
    )
for row in read(R / "results/label-bindings.json")["decisions"]:
    check(
        next(x["label"] for x in nodes if x["id"] == row["id"]) == row["proposed_label"],
        row["id"] + " label decision applied",
    )
selected = {x["id"] for x in nodes if x["proposed_declaration"]}
matrix = read(R / "authority-audit/authority-needs-matrix.json")["rows"]
matrix += read(R / "results/supplemental-authority-needs.json")
check(
    {x["curie"] for x in matrix} == {x["id"] for x in nodes},
    "every inventoryID has exact authority assessment",
)
check(
    {x["curie"] for x in read(R / "results/selected-authority-needs.json")["rows"]} == selected,
    "authority selection exactly matches128proposedIDs",
)
check(len(nodes) == 269 and len(selected) == 128, "269inventoryIDs128selectedIDs")
supplemental_slots = read(R / "results/supplemental16-native-slot-design-dispositions.json")
check(len(supplemental_slots) == 16, "16supplemental EcoCyc EAL own slots retained")
supplemental_root = ET.parse(
    "/private/tmp/pathwaymech-next-272-euta-target-followup/originals/ECOLI-ETHAMLY-CPLX.xml"
).getroot()
for row in supplemental_slots:
    check(
        bool(supplemental_root.findall("." + row["locator"].removeprefix("/ptools-xml"))),
        "supplemental own slot " + row["locator"],
    )
selected_graph = read(R / "results/recommended-selected-graph-payload.json")
selected_errors = []
schema._validate_edges(
    selected_graph["mechanistic_edges"],
    all_ids,
    participants,
    reactions,
    refs,
    selected_errors,
    record_id=payload["id"],
    categories=categories,
    qualified_participants=qualified,
    activity_participants=activity,
)
check(not selected_errors, "complete97edge selected proposal actual-schema grammar")
check(len(selected_graph["mechanistic_edges"]) == 97, "all78source and19scoped options selected")
check(
    len({x["id"] for x in selected_graph["mechanistic_edges"]}) == 97,
    "selected edge IDs unique",
)
live_differences = []
for row in read(R / "results/baseline-file-rebind.json")["checks"]:
    repo_path = row["baseline_file"].removeprefix("baseline/")
    git_read = subprocess.run(
        ["git", "-C", str(W), "show", "54e768a985d07705ea25445804c83b4758646e37:" + repo_path],
        capture_output=True,
        check=True,
    )
    check(
        sha(R / row["baseline_file"])
        == hashlib.sha256(git_read.stdout).hexdigest()
        == row["sha256"],
        "immutable actual merge file rebind " + row["baseline_file"],
    )
    if sha(Path(row["worktree_path"])) != row["sha256"]:
        live_differences.append(row["worktree_path"])
output = {
    "status": "pass",
    "checks": len(checks),
    "scope": (
        "Offline graph grammar, exact inventories, source-byte/structured-locator "
        "bindings, label choices and actual-baseline file identity. Not independent"
        " scientific/design acceptance, authority-profile implementation, "
        "render/KGX validation or complete PathwayRecord validation."
    ),
    "all_jobs_terminal_at_verification": True,
    "baseline_binding_mode": "immutable actual merged Git object bytes",
    "live_worktree_differences_during_authorized_implementation": live_differences,
    "default_edges": len(payload["mechanistic_edges"]),
    "conditional_options": len(options),
    "checks_performed": checks,
}
(R / "results/verification.json").write_text(json.dumps(output, indent=2) + "\n")
print(json.dumps({k: v for k, v in output.items() if k != "checks_performed"}))
