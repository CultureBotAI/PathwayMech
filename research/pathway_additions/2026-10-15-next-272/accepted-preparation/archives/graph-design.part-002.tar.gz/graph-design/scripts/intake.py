import hashlib
import json
import shutil
import subprocess
from pathlib import Path

R = Path(__file__).resolve().parents[1]
C = "90695df63225de6f7379c9b48f0519287ac1896e"
for d in ["baseline", "inputs", "results", "originals"]:
    (R / d).mkdir(exist_ok=True)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


b = []
files = [
    "src/pathwaymech/schema.py",
    "src/pathwaymech/schema/pathwaymech.yaml",
    "src/pathwaymech/identifiers.py",
    "src/pathwaymech/biocyc_native_context.py",
    "docs/CAUSAL_GRAPHS.md",
    "docs/IDENTIFIERS.md",
    "docs/CURATION.md",
    "docs/HARMONIZATION.md",
    "CLAUDE.md",
    ".claude/skills/add-pathway/SKILL.md",
    "data/identifier_authorities/sources.json",
    "data/identifier_authorities/ontology.json",
]
for rel in files:
    p = R / "baseline" / rel
    p.parent.mkdir(exist_ok=True, parents=True)
    p.write_bytes(
        subprocess.run(["git", "show", C + ":" + rel], check=True, capture_output=True).stdout
    )
    b.append(
        {
            "path": str(p.relative_to(R)),
            "sha256": sha(p),
            "bytes": p.stat().st_size,
            "commit": C,
            "binding": (
                "reviewed-tree interim; root verified tree identical to actual633 merge, "
                "current-main rebind pending"
            ),
        }
    )
packets = {
    "native": (
        "/private/tmp/pathwaymech-next-272-native-source-preparation",
        "d7fe7fedf9315c241782ce9b26729804461dda646ba903da312fba0996054d13",
    ),
    "core": (
        "/private/tmp/pathwaymech-next-272-core-identity-preparation",
        "67f29b62064d86886bfc0767a42c2ee08a8b444045242ed7e4d1b4e398dc8e57",
    ),
    "primary": (
        "/private/tmp/pathwaymech-next-272-primary-evidence-preparation",
        "86974c5ce2562d549755f18b30fa27a14ac6c6d5007b476aaeefe105eaa36ada",
    ),
    "magnesium": (
        "/private/tmp/pathwaymech-next-272-native-magnesium-successor",
        "0c06c20359e41a1b696fcc705cd34974ccae26a468349511958a2a8d99dba08e",
    ),
    "context": (
        "/private/tmp/pathwaymech-next-272-imodulondb-preparation",
        "faeb80b7709f36e6544b059f10700f22e545aa87e58b2cfc371a0be474a2e4dd",
    ),
}
for key, (owner, expected) in packets.items():
    p = Path(owner)
    assert sha(p / "artifact-manifest.json") == expected
    for rel in ["HANDOFF.md", "artifact-manifest.json", "freeze-proof.json"]:
        q = R / "inputs" / key / rel
        q.parent.mkdir(exist_ok=True, parents=True)
        shutil.copy2(p / rel, q)
        b.append(
            {
                "path": str(q.relative_to(R)),
                "source": str(p / rel),
                "sha256": sha(q),
                "bytes": q.stat().st_size,
            }
        )
(R / "results/intake-bindings.json").write_text(json.dumps(b, indent=2) + "\n")
print(json.dumps({"baseline_files": len(files), "frozen_packets": len(packets)}))
