"Apply accepted scientific-successor precedence to this mutable design only."

import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]
T = Path("/private/tmp/pathwaymech-next-272-eutt-specificity-followup")
V = Path("/private/tmp/pathwaymech-next-272-independent-eutt-followup-review")
M = Path("/private/tmp/pathwaymech-next-272-native-magnesium-successor")


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    (R / "results" / name).write_text(json.dumps(value, indent=2) + "\n")


def binding(path, locator=None):
    row = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    if locator:
        row["locator"] = locator
    return row


ledger = read(T / "results/claim-dispositions.json")
for row in ledger:
    row["original_binding"] = binding(T / row["source"], row["locator"])
    row["independent_acceptance"] = binding(V / "artifact-manifest.json")
    row["graph_design_disposition"] = (
        (
            "Retain a source-attributed positive pre-reduced Co(I) result with "
            "unavailable SI explicit; no issued exact Co(I) "
            "cobinamide/adenosylcobinamide reaction has been identity-bound here, so do"
            " not invent a chemical node or catalytic edge."
        )
        if row["id"] == "eutt-pre-reduced-cobinamide"
        else (
            "Retain the reported coordination/binding distinction as a Zn-EutT/MgATP "
            "spectroscopic interpretation, not a physical-binding edge or physiological"
            " metal/flux claim."
        )
        if row["id"] == "eutt-coii-cobinamide-binding"
        else (
            "Retain substrate-site competition; Figure4 measured AdoCbl formation and "
            "does not itself identify adenosylcobinamide product. Do not relabel a "
            "competition assay as direct product analysis."
        )
        if row["id"] == "eutt-competition-direction"
        else "No direct EutT-to-EAL delivery edge; hypothesis only."
        if row["id"] == "eutt-direct-delivery-still-proposed"
        else (
            "Preserve the exact source assertion as conflicting evidence; do not "
            "promote it to a blanket negative or positive cobinamide mechanism."
        )
    )
write("accepted-eutt-followup-design.json", ledger)
precedence = {
    "rule": (
        "Raw frozen source assertions are retained. The following independently "
        "accepted successor interpretations control downstream design; older "
        "semantic fields remain attributable historical preparation, not current "
        "blanket conclusions."
    ),
    "magnesium_successor": binding(M / "artifact-manifest.json"),
    "magnesium_dispositions": read(M / "results/successor-dispositions.json"),
    "citation_correction": read(M / "results/citation-successor.json"),
    "historical_euth_context_correction": read(M / "results/contextual-euth-disposition.json"),
    "eutt_followup": ledger,
    "eutt_operational_correction": binding(
        Path(
            "/private/tmp/pathwaymech-next-272-eutt-followup-operational-correction/artifact-manifest.json"
        )
    ),
    "pending_lead_superseded": (
        "biology-audit/eutt-followup-lead.json is the earlier provisional reading. "
        "This accepted successor governs; its owner remains unchanged."
    ),
}
write("scientific-successor-precedence.json", precedence)
nodes = read(R / "results/node-ledger.json")
for row in nodes:
    if row["id"] in ["MetaCyc:CPLX-9275", "UniProtKB:Q9ZFV4", "UniProtKB:P65643"]:
        row["current_successor_disposition"] = (
            "2015 reports pre-reduced Co(I) cobinamide adenosylation; this conflicts "
            "with explicit native Co(I) inactivity and does not establish the UniProt "
            "Co(II)-starting equation. See accepted-eutt-followup-design.json; no "
            "direct handoff or donor inferred."
        )
    if row["id"] in ["UniProtKB:P0A208", "UniProtKB:Q9ZFV5"]:
        row["current_successor_disposition"] = (
            "EDTA-treatment resistance with added magnesium in documented assays; "
            "neither magnesium-independent catalysis nor obligatory bound magnesium "
            "follows."
        )
write("node-ledger.json", nodes)
slots = read(R / "results/all3689-native-slot-design-dispositions.json")
for row in slots:
    if row["source_id"] == "MetaCyc:CPLX-9275" and row["slot"] == "comment":
        row["current_successor_disposition"] = nodes[
            next(i for i, x in enumerate(nodes) if x["id"] == "MetaCyc:CPLX-9275")
        ]["current_successor_disposition"]
write("all3689-native-slot-design-dispositions.json", slots)
deferred = read(R / "results/deferred-claim-ledger.json")
for row in deferred:
    if row["design_key"].startswith("EutT-"):
        row["accepted_followup"] = ledger
deferred.append(
    {
        "design_key": "EutT-oxidation-state-specificity",
        "related_declared_ids": ["MetaCyc:CPLX-9275", "UniProtKB:Q9ZFV4", "UniProtKB:P65643"],
        "decision": (
            "retain_explicit_positive_primary_result_and_source_conflicts_"
            "without_unbound_reaction_edge"
        ),
        "predicate_considered_but_not_emitted": "catalyzes",
        "rationale": (
            "Pre-reduced Co(I) substrate and Co(II)-starting reaction are distinct. "
            "Existing native ancillary equation retains cobalamin, not a newly asserted"
            " cobinamide route. An exact issued reaction/material identity and "
            "construct-scoped evidence are prerequisites to any added positive Co(I) "
            "edge; the inaccessible SI prevents direct reinspection of those supporting"
            " assays."
        ),
        "accepted_followup": ledger,
    }
)
write("deferred-claim-ledger.json", deferred)
counts = read(R / "results/integration-summary.json")
counts["deferred_groups"] = len(deferred)
counts["accepted_eutt_followup_claims"] = len(ledger)
write("integration-summary.json", counts)
