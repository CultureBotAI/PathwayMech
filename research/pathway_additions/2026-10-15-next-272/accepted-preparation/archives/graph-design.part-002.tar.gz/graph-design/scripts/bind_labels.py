"""Bind proposed labels to existing owners or the actual merged name reader."""

import hashlib
import json
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

R = Path(__file__).resolve().parents[1]
W = Path("/private/tmp/pathwaymech-next-272-20261015")
sys.dont_write_bytecode = True
sys.path.insert(0, str(W / "src"))
from pathwaymech.biocyc_carrier import name  # noqa: E402


def read(path):
    return json.loads(path.read_text())


def write(filename, value):
    (R / "results" / filename).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


matrix = {x["curie"]: x for x in read(R / "authority-audit/authority-needs-matrix.json")["rows"]}
delta_path = R / "inputs/ontology-order-successor/accepted-four-term-delta.json"
ontology_delta = read(delta_path)["terms_added"]
nodes = read(R / "results/node-ledger.json")
decisions = []
for row in nodes:
    if not row["proposed_declaration"]:
        continue
    authority = matrix[row["id"]]
    original = row.setdefault("original_projection_label", row["label"])
    if authority["snapshot_matches"]:
        choices = {x["term"]["label"] for x in authority["snapshot_matches"]}
        assert len(choices) == 1
        label = next(iter(choices))
        reason = "Exact existing authority term owner preserved unchanged."
    elif authority.get("direct_common_names"):
        path = Path(authority["native_source"]["path"])
        entity = next(
            x for x in ET.parse(path).getroot() if x.get("frameid") == row["id"].split(":", 1)[1]
        )
        try:
            label = name(entity.find("common-name"), row["id"].split(":", 1)[1])
            reason = (
                "Direct native name decoded by actual merged biocyc_carrier.name(); no "
                "whitespace invented at inline markup boundaries."
            )
        except ValueError:
            # This exact issued acronym equals its frame token. Preserve the
            # direct source name, but do not pretend the generic parser passed.
            assert row["id"] == "MetaCyc:GDP" and authority["direct_common_names"] == ["GDP"]
            label = name(entity.find("common-name"), "")
            reason = (
                "Exact direct common-name GDP equals the frame token. name(common,'GDP') "
                "rejects an unresolved-frame interpretation; name(common,'') succeeds "
                "after independent direct-slot origin verification, as in the existing "
                "bounded acetate profile. No generic parser change or label allowlist needed."
            )
    elif authority.get("existing_name_extractor_trial"):
        label = authority["existing_name_extractor_trial"]["label"]
        reason = (
            "Canonical UniProt label from the existing name-extractor trial bound to "
            "the exact original."
        )
    elif authority.get("current_issuer_identity", {}).get("name"):
        label = authority["current_issuer_identity"]["name"]
        reason = (
            "Exact current issuing ontology identity; pinned ontology addition is "
            "separately reviewed."
        )
    else:
        label = original
        reason = (
            "Retain exact issuing GO/ChEBI label or explicitly contextual "
            "unnamed-native frame token; no canonical promotion."
        )
    row["label"] = label
    row["final_label_basis"] = reason
    if row["id"] in ontology_delta:
        assert label == ontology_delta[row["id"]]["label"]
        row["pinned_ontology_label_binding"] = {
            "path": str(delta_path),
            "sha256": hashlib.sha256(delta_path.read_bytes()).hexdigest(),
            "locator": "/terms_added/" + row["id"],
            "term": ontology_delta[row["id"]],
            "scope": "Root supplied independently accepted four-term delta; values match issuer.",
        }
    decisions.append(
        {
            "id": row["id"],
            "original_projection_label": original,
            "proposed_label": label,
            "changed": original != label,
            "basis": reason,
        }
    )
write("node-ledger.json", nodes)
labels = {x["id"]: x["label"] for x in nodes}
payload = read(R / "results/partial-graph-payload.json")
for collection in ["participants", "reactions", "taxa"]:
    for row in payload[collection]:
        row["label"] = labels[row["id"]]
write("partial-graph-payload.json", payload)
write(
    "label-bindings.json",
    {
        "parser_path": str(W / "src/pathwaymech/biocyc_carrier.py"),
        "parser_sha256": hashlib.sha256(
            (W / "src/pathwaymech/biocyc_carrier.py").read_bytes()
        ).hexdigest(),
        "decisions": decisions,
    },
)
