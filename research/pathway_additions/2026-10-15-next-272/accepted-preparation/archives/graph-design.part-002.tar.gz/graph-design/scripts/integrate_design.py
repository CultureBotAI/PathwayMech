"Join exact source, scientific, and authority dispositions in owned scratch."

import collections
import functools
import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]
N = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
C = Path("/private/tmp/pathwaymech-next-272-core-identity-preparation")
P = Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation")
M = Path("/private/tmp/pathwaymech-next-272-native-magnesium-successor")


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    (R / "results" / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


@functools.cache
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def binding(path, locator=None):
    value = {"path": str(path), "sha256": digest(path)}
    if locator:
        value["locator"] = locator
    return value


def native_id(identifier):
    return identifier.replace("META:", "MetaCyc:", 1).replace("ECOLI:", "EcoCyc:", 1)


nodes = read(R / "results/node-ledger.json")
matrix = read(R / "authority-audit/authority-needs-matrix.json")["rows"]
authority = {x["curie"]: x for x in matrix}
objects = read(N / "results/all-native-object-dispositions.json")
object_by_id = {native_id(x["id"]): x for x in objects}
slots = read(N / "results/complete-native-slot-interpretations.json")
slot_by_key = {(native_id(x["id"]), x["locator"]): x for x in slots}
slot_indices = {(native_id(x["id"]), x["locator"]): i for i, x in enumerate(slots)}
conflicts = read(N / "results/source-conflicts.json")
proteins = read(R / "biology-audit/protein-design-ledger.json")
claims = read(R / "biology-audit/primary-claim-design-ledger.json")
claim_by_id = {x["id"]: x for x in claims}
cross = read(R / "biology-audit/cross-cutting-constraints.json")

for node in nodes:
    row = authority[node["id"]]
    node["authority_design"] = {
        "matrix_row": matrix.index(row),
        "matrix_binding": binding(R / "authority-audit/authority-needs-matrix.json"),
        "snapshot_status": row["snapshot_status"],
        "integration_assessment": row.get(
            "integration_assessment",
            (
                "Exact issuing identity and existing extractor trial are inventoried; "
                "accepted authority entry/profile remains needed if absent."
            ),
        ),
        "interpretation": (
            "Exact ID selection needs its own supported profile; a retained source "
            "object or plausible label is not adapter acceptance."
        ),
    }
    if node["id"] in object_by_id:
        node["accepted_source_semantics"] = object_by_id[node["id"]]
write("node-ledger.json", nodes)

# Every own slot retains the accepted semantic interpretation and object scope.
rows = read(R / "results/all3689-native-slot-design-dispositions.json")
for row in rows:
    original = slot_by_key[(row["source_id"], row["locator"])]
    row["accepted_native_slot_interpretation"] = original["interpretation"]
    row["accepted_native_object_disposition"] = object_by_id[row["source_id"]]
    row["accepted_interpretation_binding"] = binding(
        N / "results/complete-native-slot-interpretations.json",
        f"/{slot_indices[(row['source_id'], row['locator'])]}",
    )
    row["relevant_conflict_groups"] = [
        x["id"]
        for x in conflicts
        if any(
            s["source"] == original["source_path"] and s["locator"] == row["locator"]
            for s in x["source_claims"]
        )
    ]
    row["review_scope"] = (
        "Reused accepted native semantic assessment with graph-disposition join; "
        "not a new claim of complete primary-paper reading."
    )
write("all3689-native-slot-design-dispositions.json", rows)

groups = {
    "EutA-reactivation": (
        ["P07", "P08", "P18", "P20"],
        ["compartment-location-tiers", "regulation-context"],
    ),
    "EutR-expression": (["P21", "P22", "P23"], ["regulation-context"]),
    "EutH-entry": (["P19"], ["euth-transport-microstate"]),
    "EutT-metal": (["P17", "P26"], ["eutt-metal-donor-handoff"]),
    "EutT-donor-handoff": (["P17", "P20", "P26"], ["eutt-metal-donor-handoff"]),
    "EutPQ-magnesium": (["P10"], ["eutpq-phenotype-location"]),
    "EutBC-location": (
        ["P02", "P07", "P08", "P12", "P28"],
        ["compartment-location-tiers", "eutbc-experimental-organism"],
    ),
    "EutT-location": (["P07", "P08"], ["compartment-location-tiers"]),
    "EutQ-face-cargo": (
        ["P09", "P11", "P32"],
        ["eutpq-phenotype-location", "shell-cargo-constructs"],
    ),
    "Cargo-reporters": (["P12", "P13", "P23", "P31", "P32"], ["shell-cargo-constructs"]),
    "Whole-route-flux": (
        ["P01", "P03", "P04", "P24", "P25"],
        ["root-generalized-narrative", "mg1655-route-expression", "root-boundary-direction"],
    ),
    "Alternative-activity-materials": (
        ["P10", "P14", "P15"],
        ["eutg-cofactors-branch", "eutpq-phenotype-location"],
    ),
}
deferred = read(R / "results/deferred-claim-ledger.json")
for row in deferred:
    pids, cids = groups[row["design_key"]]
    row["primary_claims"] = [claim_by_id[x] for x in pids]
    row["native_conflict_dispositions"] = [x for x in conflicts if x["id"] in cids]
    row["exact_protein_scope_dispositions"] = [
        x for x in proteins if x["id"] in row["related_declared_ids"]
    ]
    row["cross_cutting_constraints"] = [
        x
        for x in cross
        if (
            ("euth" in x["id"] and row["design_key"] == "EutH-entry")
            or ("magnesium" in x["id"] and row["design_key"] == "EutPQ-magnesium")
            or ("location" in x["id"] and "location" in row["design_key"])
        )
    ]
    row["representability_limit_kind"] = (
        "missing_exact_target_identity_or_nonmatching_relation"
        if row["design_key"]
        in [
            "EutA-reactivation",
            "EutR-expression",
            "EutH-entry",
            "EutQ-face-cargo",
            "Cargo-reporters",
        ]
        else "source_scope_or_unsupported_stronger_inference"
    )
write("deferred-claim-ledger.json", deferred)

# Exact acquisition metadata replaces inferred request-URL assumptions.
closure = read(R / "results/source-closure.json")
for row in closure:
    authority_row = authority.get(row["reference_id"], {})
    row["acquisition_evidence"] = authority_row.get(
        "native_source", authority_row.get("source_binding")
    )
    row["request_url_rule"] = (
        "Reference URL is a human follow-up link. Only a matching retained "
        "acquisition receipt establishes the actual request URL and retrieval time;"
        " historical reused ACETALD/Pi do not gain a new receipt."
    )
write("source-closure.json", closure)

# Proposed optional edges stay separate so independent review can choose a
# source-annotation or experimental-construct layer without silently upgrading it.
options = []
refs = {x["id"]: x for x in read(R / "results/reference-proposals.json")}


def evidence(accession, index, assertion):
    assert len(assertion) <= 400
    return {
        "reference_id": "UniProtKB:" + accession,
        "source_assertion": assertion,
        "source_locator": "/comments/" + str(index),
    }


def option(key, subject, predicate, target, assertion, ev, qualifier, claim_ids, gates, scope):
    assert len(assertion) <= 400 and len(qualifier) <= 400
    graph = {
        "id": key,
        "subject": subject,
        "predicate": predicate,
        "object": target,
        "description": assertion,
        "evidence": ev,
    }
    if qualifier:
        graph["endpoint_qualifiers"] = [
            {
                "endpoint": "subject",
                "kind": "experimental_construct" if claim_ids else "molecular_state",
                "description": qualifier,
                "evidence": ev,
            }
        ]
    options.append(
        {
            "design_key": key,
            "decision": "representable_option_pending_independent_design_choice",
            "graph_edge": graph,
            "scientific_scope": scope,
            "acceptance_conditions": gates,
            "primary_claims": [claim_by_id[x] for x in claim_ids],
            "source_original_bindings": [
                binding(
                    N / f"originals/UniProt-{subject.split(':', 1)[1]}.json", e["source_locator"]
                )
                for e in ev
            ]
            if subject.startswith("UniProtKB:")
            else [],
            "not_emitted_in_default_partial_payload": True,
        }
    )


for accession, comment in [("P0AEJ6", 1), ("P19636", 1), ("P19264", 2), ("P19265", 2)]:
    assertion = (
        "This issued EutB or EutC chain has a curated ethanolamine ammonia-lyase "
        "activity annotation; activity requires the EutBC heteromer. This edge "
        "denotes a subunit contribution, not isolated-chain catalysis."
    )
    subunit_index = 5 if accession == "P19264" else 6
    scoped_evidence = [
        evidence(
            accession,
            comment,
            "The issued chain carries an ethanolamine ammonia-lyase activity annotation. "
            "This source annotation does not demonstrate isolated-chain catalysis.",
        ),
        evidence(
            accession,
            subunit_index,
            "The SUBUNIT annotation supplies the EutB/EutC heteromer context. "
            "Direct, probable and rule/similarity evidence retain their distinct source tiers.",
        ),
    ]
    if accession in ["P0AEJ6", "P19636"]:
        scoped_evidence.append(
            evidence(
                accession,
                10 if accession == "P0AEJ6" else 11,
                "The K12 source retains the CPZ-55 expression caution as curator inference; "
                "it is not proof of demonstrated MG1655 intact-route flux or pathway absence.",
            )
        )
    option(
        "option-eutbc-subunit-" + accession,
        "UniProtKB:" + accession,
        "enables",
        "MetaCyc:ETHAMLY-RXN",
        assertion,
        scoped_evidence,
        (
            "Annotated chain functioning as part of EutBC; no separately active chain "
            "or demonstrated native whole-route flux. K12 entries retain the CPZ-55 "
            "expression caution."
        )
        if accession in ["P0AEJ6", "P19636"]
        else (
            "LT2 annotated chain functioning as part of the EutBC heteromer; native "
            "source MG1655 complex identity is not substituted."
        ),
        [],
        [
            (
                "Accept native/Rhea15313 exact chemistry correspondence from core packet; "
                "retain separate protein and native complex IDs."
            ),
            (
                "If enables is rendered as independent whole catalysis, omit this option "
                "and retain its explicit claim instead."
            ),
        ],
        "database functional annotation with heteromer dependence",
    )

enzyme_options = [
    (
        "P41793",
        "ACETALD-DEHYDROG-RXN",
        "catalyzes",
        ["P16"],
        (
            "LT2 H6-EutE expressed in BL21(DE3) RIL ZH103, approximately90% pure; "
            "ALDH/ACR assays with NAD(H). No alcohol-dehydrogenase activity in the "
            "tested assays."
        ),
    ),
    (
        "P41790",
        "PHOSACETYLTRANS-RXN",
        "catalyzes",
        ["P05", "P10"],
        (
            "Recombinant LT2 H6-EutD in BL21(DE3): 2004 directly tests acetyl-P+CoA to "
            "acetyl-CoA; 2016 coupled assays separately support the catabolic "
            "direction."
        ),
    ),
    (
        "P0A208",
        "ACETATEKIN-RXN",
        "catalyzes",
        ["P10"],
        (
            "Recombinant LT2 EutP from BL21(lambdaDE3) with removable His tag cleaved. "
            "Kinetic/HPLC assays contain6.6/1mM MgCl2; EDTA resistance does not show "
            "magnesium independence."
        ),
    ),
    (
        "Q9ZFV5",
        "ACETATEKIN-RXN",
        "catalyzes",
        ["P10"],
        (
            "Recombinant LT2 EutQ from BL21(lambdaDE3), His tag cleaved leaving Gly-Thr"
            " remnant. Kinetic/HPLC assays contain6.6/1mM MgCl2; no "
            "magnesium-independent inference."
        ),
    ),
    (
        "P76553",
        "ALCOHOL-DEHYDROG-RXN",
        "enables",
        ["P14", "P15"],
        (
            "JCL16/BW25113-derived eutG overexpressed from pAL158 in AL626 crude cell "
            "extracts. Reported NADH/NADPH rates have nonzero controls; these are not "
            "purified kinetic cofactor preferences."
        ),
    ),
]
for accession, reaction, predicate, pids, qualifier in enzyme_options:
    index = 1 if accession == "P76553" else 2
    assertion = (
        "The issued protein carries this reaction activity annotation; the "
        "experimental evidence is limited to the stated recombinant preparation and"
        " assay. No native intact-route flux or universal direction follows."
    )
    option(
        "option-uniprot-activity-" + accession,
        "UniProtKB:" + accession,
        predicate,
        "MetaCyc:" + reaction,
        assertion,
        [evidence(accession, index, assertion)],
        qualifier,
        pids,
        [
            (
                "Accept exact native/Rhea reaction chemistry correspondence; do not assert "
                "native/UniProt protein identity equivalence."
            ),
            (
                "Bind each primary preparation to the issued protein at stated "
                "taxon/construct scope before curation."
            ),
        ],
        "experimental activity with construct-specific endpoint qualifier",
    )

for accession in ["P41791", "P41792", "Q9ZFV7", "Q9ZFU8", "P0A1C9"]:
    assertion = (
        "This LT2 protein is annotated as an ethanolamine microcompartment shell "
        "component; its assembly evidence includes engineered shells. The component"
        " assertion does not prescribe shell stoichiometry, geometry, permeability "
        "or enzyme location."
    )
    option(
        "option-lt2-shell-" + accession,
        "UniProtKB:" + accession,
        "part_of",
        "GO:0031471",
        assertion,
        [
            evidence(accession, 0, assertion),
            evidence(
                accession,
                5,
                (
                    "Curated shell-component location annotation; assay and construct scope "
                    "remain explicit."
                ),
            ),
        ],
        (
            "LT2 gene product; functional assembly evidence includes engineered eut "
            "shells. Empty engineered cages and reporter targeting do not establish a "
            "complete native metabolosome or uniform native cargo topology."
        ),
        ["P12", "P13", "P23", "P32"],
        [
            (
                "Accept GO class membership as a component annotation, not an exact "
                "observed organelle instance."
            ),
            "Keep EutN solution/crystal geometry and EutS mutant/tag effects separate.",
        ],
        (
            "curated source annotation with experimental and similarity evidence "
            "distinguished in individual protein ledger"
        ),
    )

assertion = (
    "Reconstituted LT2 EutT has highest tested activity with FeII; Zn can "
    "copurify. This is a preparation-scoped metal requirement/response, not an "
    "exclusive demonstrated physiological ferroprotein claim."
)
option(
    "option-eutt-invitro-fe",
    "UniProtKB:Q9ZFV4",
    "has_cofactor",
    "MetaCyc:FE+2",
    assertion,
    [evidence("Q9ZFV4", 4, assertion)],
    (
        "Tag-cleaved JE6583-derived EutT expressed in BL21, "
        "metal-depleted/reconstituted preparation under the 2014 in-vitro assay. "
        "This edge is confined to the FeII-reconstituted active state."
    ),
    ["P17"],
    [
        "Verify exact source-native FeII chemical identity and tested protein binding.",
        (
            "If a renderer hides state qualifiers or treats this as exclusive native "
            "metal occupancy, omit the edge and retain the assay fact."
        ),
    ],
    "in-vitro FeII-reconstituted state only",
)
write("conditional-edge-options.json", options)

# Evidence for construct qualifiers cites the actually read primary projection,
# not just a database's catalytic-activity annotation. Retain access distinctions.
primary_sources = {
    "S02": ("14996820", "web-publisher-and-roth.json", "https://pubmed.ncbi.nlm.nih.gov/14996820/"),
    "S04": (
        "26448059",
        "PMC4857615-efetch.xml",
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC4857615/",
    ),
    "S05": ("22428024", "cargo-2012-primary.xml", "https://pubmed.ncbi.nlm.nih.gov/22428024/"),
    "S06": (
        "22731523",
        "PMC3439341-efetch.xml",
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC3439341/",
    ),
    "S07": (
        "21803884",
        "web-EutE-EutT-targeted-reading.json",
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC3187147/",
    ),
    "S08": (
        "24336938",
        "web-EutT2014-targeted-reading.json",
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC3911174/",
    ),
    "S14": ("10464203", "EutOperon-1999-author.pdf", "https://pubmed.ncbi.nlm.nih.gov/10464203/"),
    "S24": (
        "27063436",
        "PMC4827028-efetch.xml",
        "https://pmc.ncbi.nlm.nih.gov/articles/PMC4827028/",
    ),
}
option_refs = dict(refs)
option_sources = []
for row in options:
    evs = []
    for claim in row["primary_claims"]:
        # P15 numerical plot values are not asserted by any option; full image
        # evidence remains in the accepted claim ledger rather than cited as XML.
        if claim["id"] == "P15":
            continue
        pmid, filename, url = primary_sources[claim["source_key"]]
        artifact = next(
            x for x in claim["original_artifact_bindings"] if Path(x["path"]).name == filename
        )
        rid = "PMID:" + pmid
        option_refs[rid] = {
            "id": rid,
            "title": claim["source_key"] + " primary evidence; " + rid,
            "url": url,
            "source_version": claim["source_access"],
            "source_sha256": artifact["sha256"],
        }
        evs.append(
            {
                "reference_id": rid,
                "source_assertion": claim["accepted_claim"],
                "source_locator": artifact["locator"],
            }
        )
        option_sources.append(
            {
                "reference_id": rid,
                **artifact,
                "source_access": claim["source_access"],
                "reading_scope": claim["source_read_scope"],
            }
        )
    row["graph_edge"]["evidence"].extend(evs)
    if row["graph_edge"].get("endpoint_qualifiers"):
        row["graph_edge"]["endpoint_qualifiers"][0]["evidence"] = list(
            row["graph_edge"]["evidence"]
        )
write("conditional-edge-options.json", options)
write("conditional-reference-proposals.json", list(option_refs.values()))
write("conditional-source-closure.json", option_sources)

# Alternative substrate can be shown on the already-issued activity node; it
# cannot change the canonical reaction or imply an unmeasured GDP product.
alt = []
for activity, accession, paragraph in [
    ("ENZRXN-26156", "Q9ZFV5", "P13"),
    ("ENZRXN-26157", "P0A208", "P14"),
]:
    construct = (
        "LT2 EutQ expressed in BL21(lambdaDE3), removable N-terminal His tag cleaved "
        "leaving Gly-Thr before Met."
        if accession == "Q9ZFV5"
        else "LT2 EutP expressed in BL21(lambdaDE3), removable N-terminal His tag cleaved."
    )
    method_ev = {
        "reference_id": "PMID:26448059",
        "source_assertion": construct
        + " The coupled activity-assay formulation contains6.6mM MgCl2. "
        "No magnesium independence or physiological GTP preference follows.",
        "source_locator": (
            './/p[@id="P34"] | .//p[@id="P35"] | .//p[@id="P36"] | '
            './/p[@id="P37"] | .//p[@id="P39"]'
        ),
    }
    ev = {
        "reference_id": "PMID:26448059",
        "source_assertion": (
            "The assayed recombinant Eut protein accepts GTP as an alternative "
            "phosphoryl donor in the acetate kinase assay. Preserve assay conditions "
            "and do not replace the canonical ATP/ADP equation."
        ),
        "source_locator": f'.//p[@id="{paragraph}"]',
    }
    alt.append(
        {
            "design_key": "option-gtp-" + activity,
            "graph_edge": {
                "id": "option-gtp-" + activity,
                "subject": "MetaCyc:" + activity,
                "predicate": "has_input",
                "object": "MetaCyc:GTP",
                "description": construct
                + " Alternative GTP input under the Mg-containing coupled assay; "
                "no canonical ATP/ADP equation change or unmeasured GDP output.",
                "evidence": [ev, method_ev],
            },
            "decision": (
                "representable_alternative_activity_option_pending_independent_design_choice"
            ),
            "exact_original": binding(P / "originals/PMC4857615-efetch.xml", ev["source_locator"]),
            "enzyme_scope": "UniProtKB:" + accession,
            "conditions": (
                "Recombinant LT2, tag-cleaved preparation; kinetics with MgCl2. No "
                "unmeasured GDP output or new net equation."
            ),
            "not_emitted_in_default_partial_payload": True,
        }
    )
write("alternative-activity-options.json", alt)

selected_ids = {x["id"] for x in nodes if x["proposed_declaration"]}
write(
    "selected-authority-needs.json",
    {
        "scope": (
            "127 default proposed declarations; source-context inventory alone is not "
            "an authority-addition instruction."
        ),
        "rows": [x for x in matrix if x["curie"] in selected_ids],
        "counts": dict(collections.Counter(authority[x]["snapshot_status"] for x in selected_ids)),
    },
)
write(
    "integration-summary.json",
    {
        "proposed_nodes": len(selected_ids),
        "all_native_slots": len(rows),
        "individual_protein_dispositions": len(proteins),
        "primary_claim_dispositions": len(claims),
        "conditional_edges": len(options),
        "alternative_activity_edges": len(alt),
        "deferred_groups": len(deferred),
        "authority_scope_counts": dict(
            collections.Counter(authority[x]["snapshot_status"] for x in selected_ids)
        ),
        "review_status": (
            "Design only; independent design acceptance and implementation still pending."
        ),
    },
)
