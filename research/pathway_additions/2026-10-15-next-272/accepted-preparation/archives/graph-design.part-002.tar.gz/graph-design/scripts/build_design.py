"""Produce design ledgers; no maintained record, adapter or external write."""

import collections
import hashlib
import json
import xml.etree.ElementTree as ET
from pathlib import Path

R = Path(__file__).resolve().parents[1]
N = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
P = Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation")
C = Path("/private/tmp/pathwaymech-next-272-core-identity-preparation")
M = Path("/private/tmp/pathwaymech-next-272-native-magnesium-successor")


def get(owner, p):
    return json.loads((owner / p).read_text())


def put(p, x):
    (R / "results" / p).write_text(json.dumps(x, indent=2, ensure_ascii=False) + "\n")


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


native = get(N, "results/all-native-projections.json") + get(
    N, "results/ecoli-native-projections.json"
)
u = get(N, "results/uniprot-complete-projections.json")
activities = get(N, "results/all71-activity-dispositions.json")
boundary = get(N, "inputs/discovery/results/ethanolamine-boundary.json")
core = get(C, "results/material-identity-assessment.json")


def curie(org, fid):
    return ("MetaCyc:" if org == "META" else "EcoCyc:") + fid


nb = {curie(x["attributes"]["orgid"], x["id"]): x for x in native}
ub = {"UniProtKB:" + x["id"]: x for x in u}
selected = {
    x["activity"]: x for x in activities if x["disposition"] == "selected_native_eut_activity"
}
selenz = {x["enzyme"] for x in selected.values()}
extra = {
    "EUTB-MONOMER",
    "EUTC-MONOMER",
    "G7288-MONOMER",
    "CPLX-9275",
    "STM2467-MONOMER",
    "RXN-19336",
    "ENZRXN-26161",
    "Reduced-Flavoproteins",
    "Oxidized-Flavoproteins",
    "CCO-CYTOSOL",
}
refs = {}
sourceclosure = {}
nodes = []
nd = {}
edges = []
deferred = []


def ref_native(id):
    x = nb[id]
    refs[id] = {
        "id": id,
        "title": ("MetaCyc" if id.startswith("MetaCyc:") else "EcoCyc")
        + " full native "
        + x["type"]
        + " "
        + x["id"],
        "url": "https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?"
        + x["attributes"]["orgid"]
        + ":"
        + x["id"],
        "source_version": "27.0",
        "source_sha256": x["sha256"],
    }
    sourceclosure[id] = {
        "reference_id": id,
        "packet": "native",
        "owner": str(N),
        "path": x["source_path"],
        "sha256": x["sha256"],
        "bytes": x["bytes"],
        "locators": [],
    }
    return id


for id in nb:
    ref_native(id)
for id, x in ub.items():
    refs[id] = {
        "id": id,
        "title": x["name"].get("recommendedName", {}).get("fullName", {}).get("value", x["gene"]),
        "url": "https://rest.uniprot.org/uniprotkb/" + x["id"] + ".json",
        "source_version": str(x["audit"]),
        "source_sha256": x["source_sha256"],
    }
    sourceclosure[id] = {
        "reference_id": id,
        "packet": "native",
        "owner": str(N),
        "path": x["source_path"],
        "sha256": x["source_sha256"],
        "bytes": (N / x["source_path"]).stat().st_size,
        "locators": [],
    }
pmid = "PMID:26448059"
primary_path = "originals/PMC4857615-efetch.xml"
refs[pmid] = {
    "id": pmid,
    "title": "EutP and EutQ acetate kinase study",
    "citation": "Moore and Escalante-Semerena; PMID26448059; DOI10.1111/mmi.13243",
    "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC4857615/",
    "source_version": "retained official NCBI XML",
    "source_sha256": sha(P / primary_path),
}
sourceclosure[pmid] = {
    "reference_id": pmid,
    "packet": "primary",
    "owner": str(P),
    "path": primary_path,
    "sha256": sha(P / primary_path),
    "bytes": (P / primary_path).stat().st_size,
    "locators": [],
}


def ev(id, locator, assertion):
    assert len(assertion) <= 400, (id, len(assertion))
    sourceclosure[id]["locators"].append(locator)
    return {"reference_id": id, "source_assertion": assertion, "source_locator": locator}


def slot(id, name, ordinal=1):
    return next(s for s in nb[id]["slots"] if s["slot"] == name and s["ordinal"] == ordinal)


def nev(id, name, assertion, ordinal=1):
    return ev(id, slot(id, name, ordinal)["locator"], assertion)


def uev(id, typ, assertion, index=None):
    if index is None:
        index = next(i for i, c in enumerate(ub[id]["comments"]) if c["commentType"] == typ)
    return ev(id, "/comments/" + str(index), assertion)


def node(id, label, category, collection, scope, proposed=True, reason="", **kwargs):
    d = {
        "id": id,
        "label": label,
        "category": category,
        "collection": collection,
        "proposed_declaration": proposed,
        "scope": scope,
        "decision": reason,
        **kwargs,
    }
    nodes.append(d)
    nd[id] = d


for id, x in nb.items():
    org = x["attributes"]["orgid"]
    fid = x["id"]
    typ = x["type"]
    parents = {q["frameid"] for q in x["links"].get("parent", [])}
    category = {
        "Compound": "small_molecule",
        "Reaction": "molecular_activity",
        "Enzymatic-Reaction": "molecular_activity",
        "cco": "cellular_component",
        "Gene": "gene",
        "Pathway": "pathway",
    }.get(typ)
    if typ == "Protein":
        category = (
            "complex"
            if ("Protein-Complexes" in parents or "Protein-Small-Molecule-Complexes" in parents)
            else "protein"
        )
    if fid in ["ADENOSYLCOBALAMIN", "NAD", "NADH", "CO-A", "FE+2"]:
        category = "cofactor"
    proposed = (
        org == "ECOLI"
        or fid in selected
        or fid in selenz
        or fid in extra
        or typ == "Compound"
        or fid in boundary["root"]["members"]
        or fid == "PWY0-1477"
    )
    if typ in ["Regulation", "Gene", "Organism"]:
        proposed = False
    collection = (
        "record"
        if fid == "PWY0-1477" and org == "META"
        else "reactions"
        if typ == "Reaction"
        else "participants"
    )
    label = (x["common-name"] or [fid])[0]
    reason = (
        (
            "Propose exact source-native identity; canonical label/shape authority "
            "remains separately gated."
        )
        if proposed
        else (
            "Retain complete source context and disposition; not a graph entity "
            "required by the selected ethanolamine mechanism."
        )
    )
    if typ == "Regulation":
        reason = (
            "Native regulation object is relation evidence, not a fabricated biological"
            " node category; selected statements become edges, off-route targets remain"
            " contextual."
        )
    if fid in {
        x["activity"] for x in activities if x["disposition"] != "selected_native_eut_activity"
    }:
        reason = (
            "Full activity lead retained with per-enzyme taxon/relevance disposition; "
            "not selected as an ethanolamine activity."
        )
    node(
        id,
        label,
        category,
        collection,
        {
            "native_orgid": org,
            "native_type": typ,
            "class": x["attributes"].get("class") == "true",
            "native_taxa": [q.get("frameid") for q in x["links"].get("species", [])],
        },
        proposed,
        reason,
        source_path=x["source_path"],
        source_sha256=x["sha256"],
        label_basis="direct_native_common_name"
        if x["common-name"]
        else "contextual_native_frame_token_pending_authority",
        direction=(x["reaction-direction"][0].split()[0] if x["reaction-direction"] else None),
    )
for id, x in ub.items():
    node(
        id,
        refs[id]["title"],
        "protein",
        "participants",
        {
            "gene": x["gene"],
            "organism_taxon": x["organism"]["taxonId"],
            "source_scope": (
                "K12 taxon83333, CPZ-55 expression caution, not demonstrated MG1655 intact flux"
            )
            if x["organism"]["taxonId"] == 83333
            else ("LT2 source identity; donor, expression and assay strains remain claim-specific"),
        },
        True,
        (
            "Retain each issued protein identity separately; no automatic "
            "native/UniProt exact alias or sequence-equivalence merging."
        ),
        source_path=x["source_path"],
        source_sha256=x["source_sha256"],
    )
go = get(N, "originals/GO-microcompartment.json")
for x in go["results"]:
    id = x["id"]
    path = "originals/GO-microcompartment.json"
    refs[id] = {
        "id": id,
        "title": x["name"],
        "url": "https://www.ebi.ac.uk/QuickGO/term/" + id,
        "source_version": "retained live QuickGO response; see receipt",
        "source_sha256": sha(N / path),
    }
    sourceclosure[id] = {
        "reference_id": id,
        "packet": "native",
        "owner": str(N),
        "path": path,
        "sha256": sha(N / path),
        "bytes": (N / path).stat().st_size,
        "locators": ["/results[id=" + id + "]"],
    }
    node(
        id,
        x["name"],
        "cellular_component",
        "participants",
        {"term_scope": "GO cellular-component class, not a particular measured organelle instance"},
        True,
        (
            "Exact compartment class; does not localize every pathway enzyme or imply a"
            " phospholipid membrane."
        ),
    )
chebi = "CHEBI:16000"
path = "originals/CHEBI-16000.json"
assert (C / path).exists()
refs[chebi] = {
    "id": chebi,
    "title": "ethanolamine (neutral)",
    "url": "https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:16000",
    "source_version": "retained issuing ChEBI record; exact receipt in core packet",
    "source_sha256": sha(C / path),
}
sourceclosure[chebi] = {
    "reference_id": chebi,
    "packet": "core",
    "owner": str(C),
    "path": path,
    "sha256": sha(C / path),
    "bytes": (C / path).stat().st_size,
    "locators": ["issuing CHEBI:16000 identity/formula/charge and relationship"],
}
node(
    chebi,
    "ethanolamine",
    "small_molecule",
    "participants",
    {"chemical_microstate": "neutral; distinct from native MetaCyc:ETHANOL-AMINE +1"},
    True,
    (
        "Keep as explicit transport-context chemical. No invented transport "
        "activity, identity bridge or canonical reaction replacement."
    ),
)
for taxon, label in [
    (511145, "Escherichia coli K-12 substr. MG1655"),
    (99287, "Salmonella enterica serovar Typhimurium str. LT2"),
    (83333, "Escherichia coli K-12"),
]:
    node(
        "NCBITaxon:" + str(taxon),
        label,
        None,
        "taxa",
        {
            "taxon_scope": "direct native route association"
            if taxon != 83333
            else "protein source scope only"
        },
        taxon != 83333,
        (
            "Native association is not proof of whole-route flux. K12 protein scope "
            "remains explicit; do not broaden direct route taxa to all K12."
        ),
    )


def edge(
    key,
    subject,
    predicate,
    obj,
    description,
    evidence,
    basis,
    scope=None,
    qualifiers=None,
    decision="proposed_source_supported",
    sourcefacts=None,
):
    assert subject in nd and obj in nd, (key, subject, obj)
    payload = {
        "id": key,
        "subject": subject,
        "predicate": predicate,
        "object": obj,
        "description": description,
        "evidence": evidence,
    }
    if qualifiers:
        payload["endpoint_qualifiers"] = qualifiers
    row = {
        "design_key": key,
        "decision": decision,
        "basis": basis,
        "taxon_construct_assay_scope": scope or {},
        "graph_edge": payload,
        "source_facts": sourcefacts or [],
        "authority_gate": (
            "Every declared ID must pass accepted exact authority profile after "
            "baseline rebind; this design is not authority acceptance."
        ),
    }
    edges.append(row)
    return key


# Canonical source occurrences: selected route orientation without rewriting reaction directions.
occ = []
for rxn in boundary["reactions"]:
    id = "MetaCyc:" + rxn["frameid"]
    layout = next(
        q["direction"] for q in boundary["root"]["layout"] if q["reaction"] == rxn["frameid"]
    )
    for side in ["left", "right"]:
        for i, z in enumerate(rxn["sides"][side], 1):
            cid = "MetaCyc:" + z["id"]
            input_ = (side == "left") == (layout == "L2R")
            pred = "consumes" if input_ else "produces"
            sub, obj = (cid, id) if input_ else (id, cid)
            key = "core-" + rxn["frameid"] + "-" + side + "-" + str(i)
            assertion = (
                f"Native {side} occurrence {z['id']}; coefficient omitted (effective 1). "
                f"Pathway layout selects {layout}; reaction reversibility is separate."
            )
            e = [
                nev(id, side, assertion, i),
                nev(
                    "MetaCyc:PWY0-1477",
                    "reaction-layout",
                    f"Pathway layout selects {layout} traversal for {rxn['frameid']}.",
                    next(
                        s["ordinal"]
                        for s in nb["MetaCyc:PWY0-1477"]["slots"]
                        if s["slot"] == "reaction-layout" and rxn["frameid"] in s["xml"]
                    ),
                ),
            ]
            edge(
                key,
                sub,
                pred,
                obj,
                (
                    "Native selected-route material occurrence; this does not set a "
                    "physiological flux rate or branch ratio."
                ),
                e,
                "native_equation_and_pathway_layout",
                sourcefacts=[{"id": id, "locator": slot(id, side, i)["locator"]}],
            )
            occ.append(
                {
                    "edge": key,
                    "reaction_id": id,
                    "material_id": cid,
                    "native_side": side,
                    "source_coefficient": None,
                    "effective_coefficient": 1,
                    "selected_direction": layout,
                    "selected_role": "input" if input_ else "output",
                    "source_locator": slot(id, side, i)["locator"],
                }
            )
    edge(
        "core-member-" + rxn["frameid"],
        id,
        "part_of",
        "MetaCyc:PWY0-1477",
        "One of the five native pathway members.",
        [
            nev(
                "MetaCyc:PWY0-1477",
                "reaction-list",
                f"The native reaction-list includes {rxn['frameid']}.",
            )
        ],
        "native_pathway_membership",
    )
for i, x in enumerate(boundary["root"]["ordering"], 1):
    for pred in x["predecessors"]:
        edge(
            "core-order-" + str(i),
            "MetaCyc:" + pred,
            "precedes",
            "MetaCyc:" + x["reaction"],
            (
                "Native pathway ordering; no direct molecular channeling or measured flux "
                "ratio asserted."
            ),
            [
                nev(
                    "MetaCyc:PWY0-1477",
                    "reaction-ordering",
                    f"{pred} precedes {x['reaction']} in the native ordering.",
                    i,
                )
            ],
            "native_ordering",
        )
# Seven selected activity assertions, preserving enzymes and their exact native evidence scope.
qualtext = {
    "ENZRXN0-8531": (
        "E. coli EutE expressed in heterologous yeast; native activity evidence is "
        "unpurified. This is not a native MG1655 cell or purified-enzyme assay."
    ),
    "ENZRXN-26156": (
        "LT2 eutQ recombinant protein expressed in E. coli BL21; cleavable "
        "N-terminal His tag removed, leaving Gly-Thr before Met. Assays add MgCl2."
    ),
    "ENZRXN-26157": (
        "LT2 eutP recombinant protein expressed in E. coli BL21(lambdaDE3); "
        "cleavable N-terminal His tag removed. Assays add MgCl2."
    ),
}
for aid, a in selected.items():
    enzyme = "MetaCyc:" + a["enzyme"]
    activity = "MetaCyc:" + aid
    rxn = "MetaCyc:" + a["reaction"]
    db_ev = [
        nev(
            activity,
            "enzyme",
            f"Native activity {aid} assigns enzyme {a['enzyme']} to {a['reaction']}; "
            "its evidence tier and organism/preparation are retained.",
        ),
        nev(activity, "reaction", f"This native activity names reaction {a['reaction']}."),
    ]
    q = None
    if aid in qualtext:
        q = [
            {
                "endpoint": "subject",
                "kind": "experimental_construct",
                "description": qualtext[aid],
                "evidence": [
                    nev(
                        activity,
                        "evidence",
                        (
                            "The native evidence concerns heterologous protein assays; "
                            "full preparation"
                            " and magnesium qualifications are retained in the accepted "
                            "primary/successor ledgers."
                        ),
                    )
                ],
            }
        ]
    if aid in ["ENZRXN-26156", "ENZRXN-26157"]:
        q[0]["evidence"].extend(
            [
                ev(
                    "PMID:26448059",
                    './/p[@id="P34"] | .//p[@id="P35"] | .//p[@id="P36"] | .//p[@id="P37"]',
                    (
                        "The retained XML methods describe LT2-source alleles, BL21(lambdaDE3) "
                        "expression and removal of the cleavable N-terminal His tag; Gly-Thr "
                        "remnant is explicitly described for EutQ."
                    ),
                ),
                ev(
                    "PMID:26448059",
                    './/p[@id="P39"] | .//p[@id="P40"]',
                    (
                        "The reported kinetic and HPLC assays add 6.6 mM and 1 mM MgCl2 "
                        "respectively. EDTA-treatment resistance does not establish "
                        "magnesium-independent catalysis or an enzyme-bound Mg requirement."
                    ),
                ),
            ]
        )
    edge(
        "activity-enabler-" + aid,
        enzyme,
        "enables",
        activity,
        (
            "Exact native enzyme/activity assignment; evidence tier is not "
            "automatically a purified native-cell assay."
        ),
        db_ev,
        "native_gene_product_activity_assertion",
        {"source_taxa": a["source_taxa"], "scientific_disposition": a["rationale"]},
        q,
    )
    pred = "enables" if aid in ["ENZRXN-26158", "ENZRXN-26159", "ENZRXN0-8531"] else "catalyzes"
    edge(
        "core-enzyme-" + aid,
        enzyme,
        pred,
        rxn,
        a["rationale"],
        db_ev,
        "native_assignment_"
        + ("indirect_or_unpurified" if pred == "enables" else "biochemical_catalysis"),
        {"source_taxa": a["source_taxa"], "assay_scope": a["rationale"]},
        q,
    )
# Full selected assembly membership; top-level schema has no coefficient slot.
composition = []
for id, x in nb.items():
    if not nd[id]["proposed_declaration"] or nd[id]["category"] != "complex":
        continue
    for s in x["slots"]:
        if s["slot"] != "component":
            continue
        element = ET.fromstring(s["xml"])
        coefficient = element.findtext("coefficient")
        children = s["direct_objects"]
        for z in children:
            target = curie(z["orgid"], z["frameid"])
            conflict = ""
            if x["id"] == "ETHAMLY-CPLX":
                conflict = (
                    "Prose oligomer wording differs; preserve direct six-plus-six slots and "
                    "separate experimental scope."
                )
            if x["id"] == "CPLX0-7613":
                conflict = (
                    "Native/crystal coefficient6 differs from later solution-pentamer evidence;"
                    " no universal geometry."
                )
            if x["id"] == "CPLX-9275":
                conflict = "Native coefficient absent; separate UniProt homodimer cannot fill it."
            if x["id"] == "CPLX0-7801":
                conflict = "Three-chain trimer has pseudohexamer geometry; not six subunits."
            text = (
                f"Native component membership {z['frameid']}; "
                + (
                    "explicit coefficient " + coefficient + ". "
                    if coefficient is not None
                    else "coefficient omitted. "
                )
                + conflict
            )
            if target not in nd or not nd[target]["proposed_declaration"]:
                composition.append(
                    {
                        "complex": id,
                        "component": target,
                        "native_coefficient": coefficient,
                        "decision": "defer_missing_selected_full_identity",
                        "source_locator": s["locator"],
                        "assertion": text,
                    }
                )
                continue
            key = "component-" + x["attributes"]["orgid"] + "-" + x["id"] + "-" + z["frameid"]
            edge(
                key,
                id,
                "has_part",
                target,
                text,
                [ev(id, s["locator"], text)],
                "native_physical_membership",
                {"native_coefficient": coefficient, "conflict": conflict},
                sourcefacts=[{"id": id, "locator": s["locator"]}],
            )
            composition.append(
                {
                    "complex": id,
                    "component": target,
                    "native_coefficient": coefficient,
                    "edge": key,
                    "source_locator": s["locator"],
                    "assertion": text,
                }
            )
# Native enzyme regulation: source activity endpoints avoid invented direct binding.
regulation = []
for id, x in nb.items():
    if x["type"] != "Regulation":
        continue
    reg = x["links"].get("regulator", [])
    target = x["links"].get("regulated-entity", [])
    mode = " ".join(s["plain_text"] for s in x["slots"] if s["slot"] == "mode")
    off = x["id"] in ["REG0-8619", "REG0-8194", "REG-9119"]
    for a in reg:
        for b in target:
            sub = curie(a["orgid"], a["frameid"])
            obj = curie(b["orgid"], b["frameid"])
            row = {
                "source_id": id,
                "regulator": sub,
                "target": obj,
                "native_mode": mode,
                "source_hash": x["sha256"],
                "exact_slots": [{k: s[k] for k in ["slot", "locator", "xml"]} for s in x["slots"]],
                "decision": "off_route_context_no_graph_edge"
                if off
                else "propose_scoped_native_regulation",
            }
            if not off:
                pred = "inhibits" if "-" in mode else "activates"
                assert sub in nd and obj in nd
                text = (
                    "Native "
                    + ("inhibition" if pred == "inhibits" else "activation")
                    + (
                        " of the identified Eut activity; source assay/context only, not universal "
                        "in-vivo effect or physical ligand-binding proof."
                    )
                )
                key = "regulation-" + x["id"]
                edge(
                    key,
                    sub,
                    pred,
                    obj,
                    text,
                    [
                        nev(id, "regulator", "Native regulator " + a["frameid"] + "."),
                        nev(
                            id,
                            "regulated-entity",
                            "Native regulated activity " + b["frameid"] + ".",
                        ),
                        nev(id, "mode", "Native regulation sign is " + mode + "."),
                    ],
                    "native_regulation_assertion",
                    {"route_scope": "selected Eut assay context"},
                    sourcefacts=[{"id": id, "locator": s["locator"]} for s in x["slots"]],
                )
                row["edge"] = key
            regulation.append(row)
edge(
    "eutbc-adocbl",
    "MetaCyc:ETHAMLY-CPLX",
    "has_cofactor",
    "MetaCyc:ADENOSYLCOBALAMIN",
    (
        "EutBC requires adenosylcobalamin; cofactor belongs to the complete EAL "
        "complex, not independent full catalysis by either chain."
    ),
    [
        nev(
            "MetaCyc:ETHAMLY-ENZRXN",
            "cofactor",
            (
                "The native EAL activity explicitly names adenosylcobalamin as cofactor; "
                "cited experiments include non-K12 and recombinant preparations."
            ),
        )
    ],
    "native_cofactor_assertion",
)
# EutT ancillary source equation remains separate from the five core members.
tid = "MetaCyc:RXN-19336"
tx = nb[tid]
anc = []
for s in tx["slots"]:
    if s["slot"] not in ["left", "right"]:
        continue
    side = s["slot"]
    el = ET.fromstring(s["xml"])
    coeff = el.findtext("coefficient")
    effective = int(coeff) if coeff else 1
    for z in s["direct_objects"]:
        cid = curie(z["orgid"], z["frameid"])
        sub, obj = (cid, tid) if side == "left" else (tid, cid)
        key = "eutt-equation-" + side + "-" + str(s["ordinal"])
        text = (
            f"Ancillary native EutT equation: {side} {z['frameid']}, "
            + ("explicit coefficient " + coeff if coeff else "coefficient omitted, effective1")
            + ". Generic donor and source proton-count conflict remain unresolved."
        )
        edge(
            key,
            sub,
            "consumes" if side == "left" else "produces",
            obj,
            text,
            [ev(tid, s["locator"], text)],
            "native_ancillary_equation_assertion",
            {"not_core_member": True, "not_identified_physiological_donor": True},
            sourcefacts=[{"id": tid, "locator": s["locator"]}],
        )
        anc.append(
            {
                "edge": key,
                "native_side": side,
                "participant_id": cid,
                "native_coefficient": coeff,
                "effective_coefficient": effective,
                "locator": s["locator"],
            }
        )
edge(
    "eutt-native-activity",
    "MetaCyc:CPLX-9275",
    "enables",
    "MetaCyc:ENZRXN-26161",
    (
        "Native LT2 EutT enzyme/activity assignment; no direct EAL handoff or "
        "physiological donor identity follows."
    ),
    [nev("MetaCyc:ENZRXN-26161", "enzyme", "Native EutT activity identifies CPLX-9275 as enzyme.")],
    "native_ancillary_activity_assignment",
)
edge(
    "eutt-native-catalysis",
    "MetaCyc:CPLX-9275",
    "catalyzes",
    tid,
    (
        "Native EutT adenosylation assignment; source equation, generic redox "
        "participants and proton-count conflict remain explicit."
    ),
    [
        nev(
            "MetaCyc:ENZRXN-26161",
            "reaction",
            (
                "Native EutT activity identifies RXN-19336; this is ancillary to the five "
                "root members."
            ),
        )
    ],
    "native_ancillary_catalysis_assignment",
)
# Exact membrane identity and source-positive EutH localization.
# The transport reaction remains unissued.
edge(
    "euth-native-membrane",
    "EcoCyc:G7282-MONOMER",
    "located_in",
    "EcoCyc:CCI-PM-BAC-NEG-GN",
    (
        "Native EutH inner-membrane location; this is not a transport-microstate or"
        " direct metabolosome-delivery assertion."
    ),
    [
        nev(
            "EcoCyc:G7282-MONOMER",
            "location",
            (
                "The exact native ECOLI EutH source location is the Gram-negative inner "
                "membrane CCI-PM-BAC-NEG-GN."
            ),
        )
    ],
    "native_location_assertion",
    {"taxon": "ECOLI/MG1655 source owner, not demonstrated intact route flux"},
)
# No unsupported stronger predicates for tentative localization, binding or inferred stoichiometry.
constraints = [
    (
        "EutA-reactivation",
        ["EcoCyc:G7281-MONOMER", "UniProtKB:P76551", "UniProtKB:Q9ZFV2"],
        "activates",
        (
            "Retain ATP/Mg/free-AdoCbl-dependent reactivation as an explicit fact. An "
            "exact pairing of the tested EAL construct and native/UniProt complex "
            "identity is required before a typed activation edge; do not make free "
            "assay reagents EutA-bound cofactors."
        ),
    ),
    (
        "EutR-expression",
        ["EcoCyc:EG12190-MONOMER", "UniProtKB:Q9ZFU7", "UniProtKB:P36547"],
        "regulates",
        (
            "Genetic operon-expression regulation is supported, but no inspected exact "
            "operon/promoter entity is declared. Do not replace the target with a "
            "generic core reaction or claim direct ligand binding."
        ),
    ),
    (
        "EutH-entry",
        ["CHEBI:16000", "MetaCyc:ETHANOL-AMINE", "UniProtKB:P41796", "UniProtKB:P76552"],
        "enables",
        (
            "Neutral-substrate conditional entry model is retained. No exact transport "
            "activity/reaction ID is bound, and existing predicates cannot faithfully "
            "express transports from a protein to a chemical. Do not invent an activity"
            " or equate neutral with charged species."
        ),
    ),
    (
        "EutT-metal",
        [
            "MetaCyc:CPLX-9275",
            "UniProtKB:Q9ZFV4",
            "MetaCyc:FE+2",
            "MetaCyc:ZN+2",
            "MetaCyc:CO+2",
            "MetaCyc:MN+2",
        ],
        "has_cofactor",
        (
            "Retain native FeII cofactor annotation and Zn/FeII reconstitution data "
            "separately. A default unqualified physiological-metal edge would overstate"
            " scope; a future in-vitro state-qualified edge requires exact tested "
            "protein/complex binding and metal evidence acceptance."
        ),
    ),
    (
        "EutT-donor-handoff",
        [
            "MetaCyc:Reduced-Flavoproteins",
            "MetaCyc:Oxidized-Flavoproteins",
            "MetaCyc:CPLX-9275",
            "MetaCyc:ETHAMLY-CPLX",
        ],
        "provides_input_for",
        (
            "Generic source redox classes do not identify an in-vivo donor, and "
            "EutT-to-EAL cofactor handoff is proposed by analogy. No direct channeling "
            "or transfer edge."
        ),
    ),
    (
        "EutPQ-magnesium",
        [
            "MetaCyc:STM2468-MONOMER",
            "MetaCyc:STM2469-MONOMER",
            "UniProtKB:Q9ZFV5",
            "UniProtKB:P0A208",
            "MetaCyc:MG+2",
        ],
        "has_cofactor",
        (
            "EDTA resistance under documented Mg-containing assays supports neither "
            "magnesium independence nor a specific enzyme-bound Mg requirement; no "
            "positive or negative cofactor edge."
        ),
    ),
    (
        "EutBC-location",
        ["MetaCyc:ETHAMLY-CPLX", "UniProtKB:P19264", "UniProtKB:P19265", "GO:0031471"],
        "located_in",
        (
            "2013 outside model untested; 2022 LT2 EAL/EutA association and inferred "
            "lumen are construct/assay scoped. Do not place the source MG1655 complex "
            "from these LT2 results or assert every enzyme in the lumen."
        ),
    ),
    (
        "EutT-location",
        ["MetaCyc:CPLX-9275", "UniProtKB:Q9ZFV4", "GO:0031471"],
        "located_in",
        "Inside versus outside remains unresolved; no typed location edge.",
    ),
    (
        "EutQ-face-cargo",
        ["UniProtKB:Q9ZFV5", "UniProtKB:P41791", "GO:0031471"],
        "located_in",
        (
            "Tagged in-vitro EutQ/EutM association and assembly effects do not "
            "establish native cytoplasmic-face placement or cargo transfer. No "
            "interacts-with predicate exists; part_of would change the claim."
        ),
    ),
    (
        "Cargo-reporters",
        ["UniProtKB:P19265", "UniProtKB:P76553", "UniProtKB:P41793", "GO:0031471"],
        "located_in",
        (
            "Short EutC1-19 and other reporter constructs are not blanket full-length "
            "native location. Keep construct-specific observations in claim ledger "
            "until an exact tested construct endpoint and faithful location assertion "
            "can be represented."
        ),
    ),
    (
        "Whole-route-flux",
        ["MetaCyc:PWY0-1477"],
        "occurs_in",
        (
            "Do not assert universal whole-route lumen, aldehyde protection, "
            "cofactor-private-pool, native MG1655 flux or one traversal of each branch "
            "as a net equation."
        ),
    ),
    (
        "Alternative-activity-materials",
        ["UniProtKB:P76553", "UniProtKB:P0A208", "UniProtKB:Q9ZFV5", "MetaCyc:GTP", "MetaCyc:GDP"],
        "has_input",
        (
            "Preserve EutG NADPH/alternative-aldehyde and EutP/Q GTP assay facts. Do "
            "not amend the five canonical equations; alternate activity/material "
            "microstate identity needs separate exact binding. No guessed NADPH or "
            "aldehyde CURIE is emitted."
        ),
    ),
]
for key, ids, pred, why in constraints:
    deferred.append(
        {
            "design_key": key,
            "related_declared_ids": ids,
            "predicate_considered_but_not_emitted": pred,
            "decision": "retain_explicit_fact_defer_stronger_or_misidentified_edge",
            "rationale": why,
            "source_conflict_ledger": str(N / "results/source-conflicts.json"),
            "accepted_successor": str(M / "HANDOFF.md"),
        }
    )
# Every complete own slot gets a design disposition, not just the convenient graph subset.
edgebyfact = collections.defaultdict(list)
for e in edges:
    for f in e["source_facts"]:
        edgebyfact[(f["id"], f["locator"])].append(e["design_key"])
slotrows = []
context_slots = {
    "component",
    "component-of",
    "location",
    "surrounded-by",
    "surrounds",
    "cofactor",
    "alternative-cofactor",
    "cofactor-binding-comment",
    "cofactors-of",
    "regulated-by",
    "regulates",
    "regulator",
    "regulated-entity",
    "mode",
    "mechanism",
    "alternative-substrate",
    "in-pathway",
    "pathway-link",
    "species",
    "taxonomic-range",
    "has-go-term",
    "gene",
    "product",
    "comment",
}
for id, x in nb.items():
    for s in x["slots"]:
        keys = edgebyfact[(id, s["locator"])]
        if keys:
            dis = "represented_by_exact_source_edge"
        elif not nd[id]["proposed_declaration"] and x["type"] != "Regulation":
            dis = "source_context_or_unrelated_lead_retained_with_individual_relevance_disposition"
        elif s["slot"] in [
            "common-name",
            "synonym",
            "parent",
            "dblink",
            "inchi",
            "inchi-key",
            "cml",
            "credits",
            "citation",
            "evidence",
        ]:
            dis = "identity_or_evidence_metadata_retained_not_invented_mechanistic_edge"
        elif s["slot"] in context_slots:
            dis = "explicit_context_claim_retained_for_claim_specific_representability_review"
        else:
            dis = "complete_source_slot_retained_no_new_topological_implication"
        slotrows.append(
            {
                "source_id": id,
                "source_sha256": x["sha256"],
                "locator": s["locator"],
                "slot": s["slot"],
                "ordinal": s["ordinal"],
                "xml_sha256": hashlib.sha256(s["xml"].encode()).hexdigest(),
                "source_statement": s["plain_text"],
                "source_objects": s["direct_objects"],
                "design_disposition": dis,
                "edge_keys": keys,
            }
        )
# Full activity set: every excluded or adjacent item stays explicit and source-bound.
actrows = []
for x in activities:
    actrows.append(
        {
            **x,
            "graph_design_decision": "selected_activity_and_scoped_enzyme_edges"
            if x["activity"] in selected
            else "retain_context_no_ethanolamine_catalyst_edge",
            "graph_edge_keys": [
                e["design_key"] for e in edges if e["design_key"].endswith(x["activity"])
            ],
        }
    )
put("node-ledger.json", nodes)
put("edge-ledger.json", edges)
put("deferred-claim-ledger.json", deferred)
put("core-occurrences.json", occ)
put("ancillary-eutt-occurrences.json", anc)
put("composition-ledger.json", composition)
put("regulation-ledger.json", regulation)
put("all71-activity-design-dispositions.json", actrows)
put("all3689-native-slot-design-dispositions.json", slotrows)
for x in sourceclosure.values():
    x["locators"] = sorted(set(x["locators"]))
put("source-closure.json", list(sourceclosure.values()))
put("reference-proposals.json", list(refs.values()))


# Projection payload is a partial design using only existing graph fields; not a PathwayRecord.
def declaration(x):
    d = {"id": x["id"], "label": x["label"]}
    if x["category"] is not None:
        d["category"] = x["category"]
    if x["collection"] == "reactions" and x.get("direction"):
        d["direction"] = {
            "LEFT-TO-RIGHT": "left_to_right",
            "PHYSIOL-LEFT-TO-RIGHT": "left_to_right",
            "RIGHT-TO-LEFT": "right_to_left",
            "PHYSIOL-R2L": "right_to_left",
            "REVERSIBLE": "reversible",
        }.get(x["direction"], x["direction"])
    return d


payload = {
    "id": "MetaCyc:PWY0-1477",
    "participants": [
        declaration(x)
        for x in nodes
        if x["proposed_declaration"] and x["collection"] == "participants"
    ],
    "reactions": [
        declaration(x)
        for x in nodes
        if x["proposed_declaration"] and x["collection"] == "reactions"
    ],
    "taxa": [
        declaration(x) for x in nodes if x["proposed_declaration"] and x["collection"] == "taxa"
    ],
    "mechanistic_edges": [x["graph_edge"] for x in edges],
    "references": list(refs.values()),
}
put("partial-graph-payload.json", payload)
put(
    "design-counts.json",
    {
        "native_inventory": len(native),
        "all_native_slots": len(slotrows),
        "all_activity_leads": len(actrows),
        "selected_activities": len(selected),
        "all_uniprot": len(u),
        "node_inventory": len(nodes),
        "proposed_declarations": sum(x["proposed_declaration"] for x in nodes),
        "proposed_edges": len(edges),
        "core_occurrences": len(occ),
        "ancillary_eutt_occurrences": len(anc),
        "component_memberships": len(composition),
        "native_regulation_objects": len(regulation),
        "deferred_groups": len(deferred),
        "scope": (
            "Proposed design, not maintained curation, authority acceptance, complete "
            "primary literature review or flux model."
        ),
    },
)
print(json.dumps(get(R, "results/design-counts.json"), indent=2))
