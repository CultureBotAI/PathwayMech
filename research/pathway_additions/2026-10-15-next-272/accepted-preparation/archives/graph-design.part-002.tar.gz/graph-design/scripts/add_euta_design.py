"""Integrate the accepted exact EcoCyc EAL target without aliasing META."""

import collections
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET

R = Path(__file__).resolve().parents[1]
T = Path("/private/tmp/pathwaymech-next-272-euta-target-followup")
P = Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation")
ID = "EcoCyc:ETHAMLY-CPLX"
SOURCE = T / "originals/ECOLI-ETHAMLY-CPLX.xml"
PRIMARY = P / "originals/EutA-2004-publisher-web-reading.json"


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    (R / "results" / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evidence(reference, locator, assertion):
    assert len(assertion) <= 400
    return {"reference_id": reference, "source_locator": locator, "source_assertion": assertion}


root = ET.parse(SOURCE).getroot()
entity = next(x for x in root if x.get("frameid") == "ETHAMLY-CPLX")
prefix = "/ptools-xml/Protein[@frameid='ETHAMLY-CPLX']"
slot_reading = read(T / "results/complete-own-slot-reading.json")
nodes = read(R / "results/node-ledger.json")
assert ID not in {x["id"] for x in nodes}
nodes.append(
    {
        "id": ID,
        "label": "ETHAMLY-CPLX",
        "category": "complex",
        "collection": "participants",
        "proposed_declaration": True,
        "scope": {"native_orgid": "ECOLI", "source_metadata_taxon": "NCBITaxon:511145"},
        "decision": "Exact EutA-linked EcoCyc target; independent of META representation.",
        "source_path": str(SOURCE),
        "source_sha256": sha(SOURCE),
        "label_basis": "native_frame_id_no_own_common_name",
        "final_label_basis": "Exact contextual frame token; no invented canonical common-name.",
        "accepted_source_semantics": {
            "own_slots": 16,
            "components": slot_reading["components"],
            "conflict": "Explicit six-plus-six slots versus incompatible oligomer prose.",
            "independent_acceptance": (
                "/root/next272_core_and_context_review accepted all16 slots and four claims "
                "by collaboration message; final frozen graph review will bind acceptance."
            ),
        },
    }
)
write("node-ledger.json", nodes)
new_authority = {
    "curie": ID,
    "inventory_family": "full_native_object",
    "pgdb": "ECOLI",
    "native_type": "Protein",
    "snapshot_status": "absent_from_both_reviewed_term_snapshots",
    "integration_assessment": "new_exact_bounded_unnamed_heteromer_source_profile_required",
    "direct_common_names": [],
    "contextual_label": "ETHAMLY-CPLX",
    "native_source": {
        "path": str(SOURCE),
        "sha256": sha(SOURCE),
        "bytes": SOURCE.stat().st_size,
        "receipt_owner": str(T),
        "actual_request_provenance": "receipts/",
    },
    "source_preparation_disposition": slot_reading,
    "design_notes": [
        "Keep META and ECOLI complexes separate; do not infer exact protein equivalence.",
        "Two distinct six-copy components cannot use the old single-component homomer fallback.",
        "New activity and reaction pointers remain source context, not graph declarations.",
    ],
}
write("supplemental-authority-needs.json", [new_authority])
selected = read(R / "results/selected-authority-needs.json")
selected["rows"].append(new_authority)
selected["counts"] = dict(collections.Counter(x["snapshot_status"] for x in selected["rows"]))
selected["scope"] = "128 proposed declarations including exact supplemental EcoCyc EAL target."
write("selected-authority-needs.json", selected)

new_ref = {
    "id": ID,
    "title": "EcoCyc exact EutA-linked ethanolamine ammonia-lyase complex",
    "url": "https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?ECOLI:ETHAMLY-CPLX",
    "source_version": "ECOLI27.0; exact source has no own common-name",
    "source_sha256": sha(SOURCE),
}
primary_ref = {
    "id": "PMID:15466038",
    "title": "Mori et al.2004 EutA reactivation study",
    "url": "https://journals.asm.org/doi/10.1128/jb.186.20.6845-6854.2004",
    "source_version": "Retained publisher web-tool text; not downloaded raw publisher HTML",
    "source_sha256": sha(PRIMARY),
}
refs = read(R / "results/reference-proposals.json") + [new_ref]
write("reference-proposals.json", refs)
option_refs = read(R / "results/conditional-reference-proposals.json") + [new_ref, primary_ref]
write("conditional-reference-proposals.json", option_refs)
closure = read(R / "results/source-closure.json")
closure.append(
    {
        "reference_id": ID,
        "packet": "euta-target-followup",
        "owner": str(T),
        "path": "originals/ECOLI-ETHAMLY-CPLX.xml",
        "sha256": sha(SOURCE),
        "bytes": SOURCE.stat().st_size,
        "locators": [prefix + "/component[1]", prefix + "/component[2]", prefix + "/comment[1]"],
        "acquisition_evidence": "Exact retained receipt in frozen EutA target owner.",
    }
)
write("source-closure.json", closure)
option_closure = read(R / "results/conditional-source-closure.json")
option_closure.append(
    {
        "reference_id": "PMID:15466038",
        "path": str(PRIMARY),
        "sha256": sha(PRIMARY),
        "locator": "displayed L112–115,L123–128,L189–200",
        "source_access": (
            "Retained publisher tool projection; original prep/source limits retained."
        ),
    }
)
write("conditional-source-closure.json", option_closure)

edges = read(R / "results/edge-ledger.json")
composition = read(R / "results/composition-ledger.json")
for i, component in enumerate(slot_reading["components"], 1):
    target = component["id"]
    assertion = (
        f"Native EcoCyc component {target} has explicit coefficient6. "
        "Preserve the separate conflicting oligomer prose; no META equivalence."
    )
    key = "component-ECOLI-ETHAMLY-CPLX-" + target.split(":", 1)[1]
    graph = {
        "id": key,
        "subject": ID,
        "predicate": "has_part",
        "object": target,
        "description": assertion,
        "evidence": [evidence(ID, prefix + f"/component[{i}]", assertion)],
    }
    edges.append(
        {
            "design_key": key,
            "decision": "proposed_source_supported",
            "basis": "supplemental_exact_native_physical_membership",
            "graph_edge": graph,
            "source_facts": [{"id": ID, "locator": prefix + f"/component[{i}]"}],
            "taxon_construct_assay_scope": {"source_component_coefficient": 6},
            "authority_gate": (
                "Exact new bounded EcoCyc heteromer profile remains to be implemented."
            ),
        }
    )
    composition.append(
        {
            "complex": ID,
            "component": target,
            "native_coefficient": "6",
            "edge": key,
            "source_locator": prefix + f"/component[{i}]",
            "assertion": assertion,
        }
    )
write("edge-ledger.json", edges)
write("composition-ledger.json", composition)
payload = read(R / "results/partial-graph-payload.json")
payload["participants"].append({"id": ID, "label": "ETHAMLY-CPLX", "category": "complex"})
payload["references"] = refs
payload["mechanistic_edges"] = [x["graph_edge"] for x in edges]
write("partial-graph-payload.json", payload)

native_ev = [
    evidence(
        "EcoCyc:G7281-MONOMER",
        "/ptools-xml/Protein[@frameid='G7281-MONOMER']/comment[1]",
        "EcoCyc links EutA reactivation specifically to its ETHAMLY-CPLX target with "
        "ATP, magnesium and free adenosylcobalamin. This does not establish exact "
        "sequence identity of the recombinant assay materials.",
    ),
    evidence(
        ID,
        prefix + "/comment[1]",
        "The target complex own comment reciprocally describes EutA reactivation "
        "after substrate inactivation, citing Mori2004.",
    ),
]
assay_ev = evidence(
    "PMID:15466038",
    "publisher displayed L123–128,L189–194,L199–200",
    "Purified recombinant EutA reactivated ethanolamine-inactivated holoEAL in vitro "
    "with free AdoCbl, ATP and MgCl2. EAL was prepared from JM109/pUSI2ENd; that "
    "preparation was attributed to unpublished data. The CN-Cbl model assay is separate.",
)
source_ev = evidence(
    "PMID:15466038",
    "publisher displayed L112–115,L123,L189–191",
    "Eut-operon genes came from Kohara clone421(4E10); EutA was expressed in JM109 "
    "and purified. Recombinant EAL came from JM109/pUSI2ENd. These methods do not "
    "verify exact sequence identity to the native MG1655 source objects.",
)
graph = {
    "id": "option-euta-reactivates-inactive-ecoli-eal",
    "subject": "EcoCyc:G7281-MONOMER",
    "predicate": "activates",
    "object": ID,
    "description": (
        "Source-associated EutA restores activity of the substrate-inactivated recombinant "
        "EAL preparation with free AdoCbl, ATP and magnesium. This claim is confined to "
        "the qualified assay materials; it is not native intact-route flux "
        "or direct ligand binding."
    ),
    "evidence": native_ev + [assay_ev],
    "endpoint_qualifiers": [
        {
            "endpoint": "subject",
            "kind": "experimental_construct",
            "description": (
                "Purified recombinant E. coli EutA expressed in JM109; eut genes derived "
                "from Kohara clone421(4E10). The EcoCyc ID names the source-associated "
                "protein; exact assay/native sequence identity is not asserted."
            ),
            "evidence": [source_ev],
        },
        {
            "endpoint": "object",
            "kind": "molecular_state",
            "description": (
                "Ethanolamine-inactivated recombinant holoEAL prepared from "
                "JM109/pUSI2ENd, with preparation attributed to unpublished data. "
                "In-vitro assay uses20mM ATP,20mM MgCl2,10uM free AdoCbl,pH8,37C. "
                "This is distinct from the inactive CN-Cbl model complex."
            ),
            "evidence": [assay_ev],
        },
    ],
}
options = read(R / "results/conditional-edge-options.json")
options.append(
    {
        "design_key": graph["id"],
        "decision": "representable_option_after_exact_target_followup",
        "graph_edge": graph,
        "not_emitted_in_default_partial_payload": True,
        "acceptance_conditions": [
            "Maintain both endpoint qualifications and their primary evidence.",
            "Do not equate EcoCyc and META complexes or claim exact recombinant/native "
            "sequence identity.",
            "Keep CN-Cbl model activation and free assay cofactors separate from this edge.",
        ],
        "primary_source_binding": {"path": str(PRIMARY), "sha256": sha(PRIMARY)},
    }
)
write("conditional-edge-options.json", options)

# Retain all new own slots, without changing frozen native projections.
ordinal = collections.Counter()
supplemental_slots = []
for slot, reading in zip(entity, slot_reading["slots"], strict=True):
    ordinal[slot.tag] += 1
    locator = prefix + f"/{slot.tag}[{ordinal[slot.tag]}]"
    supplemental_slots.append(
        {
            "source_id": ID,
            "source_sha256": sha(SOURCE),
            "locator": locator,
            "slot": slot.tag,
            "ordinal": ordinal[slot.tag],
            "source_xml": reading["xml"],
            "accepted_semantic_disposition": reading["disposition"],
            "graph_disposition": (
                "Exact component edge"
                if slot.tag == "component"
                else "Native reactivation assertion with qualified experimental option"
                if slot.tag == "comment"
                else "Source identity/evidence/context retained; no new edge"
            ),
        }
    )
write("supplemental16-native-slot-design-dispositions.json", supplemental_slots)
write(
    "euta-target-claim-design.json",
    {
        "source_owner": str(T),
        "source_manifest_sha256": sha(T / "artifact-manifest.json"),
        "claim_proposals": read(T / "results/claim-proposals.json"),
        "primary_targeted_reading": ["L112–115", "L123–128", "L189–200"],
        "qualified_option": graph,
        "explicit_retained_additional_fact": (
            "The same study separately reports activation of the enzyme-CN-Cbl model complex. "
            "This observation is retained as narrative evidence, not conflated with "
            "inactive holoEAL."
        ),
    },
)
deferred = read(R / "results/deferred-claim-ledger.json")
for row in deferred:
    if row["design_key"] == "EutA-reactivation":
        row["predicate_considered"] = row.pop("predicate_considered_but_not_emitted")
        row["decision"] = "exact_native_target_resolved_scoped_activation_option_added"
        row["rationale"] = (
            "Exact EcoCyc target was acquired and independently reviewed. The qualified "
            "activation option preserves native association plus recombinant inactive-holoEAL "
            "scope; exact sequence aliasing and a universal activation claim remain unsupported."
        )
        row["resolved_by"] = "euta-target-claim-design.json"
        row["graph_option_key"] = graph["id"]
write("deferred-claim-ledger.json", deferred)
summary = read(R / "results/integration-summary.json")
summary.update(
    {
        "proposed_nodes": 128,
        "all_native_slots": 3705,
        "base_native_slots": 3689,
        "supplemental_native_slots": 16,
        "conditional_edges": 16,
        "alternative_activity_edges": 2,
        "default_edges": 78,
        "component_memberships": 11,
        "authority_scope_counts": selected["counts"],
    }
)
write("integration-summary.json", summary)
write(
    "final-design-counts.json",
    {
        **read(R / "results/design-counts.json"),
        **summary,
        "node_inventory": len(nodes),
        "native_inventory": 229,
        "proposed_declarations": 128,
        "proposed_edges": 78,
        "conditional_options_total": 18,
        "source_slots_total": 3705,
        "deferred_groups": len(deferred),
    },
)

labels = read(R / "results/label-bindings.json")
labels["decisions"].append(
    {
        "id": ID,
        "original_projection_label": "ETHAMLY-CPLX",
        "proposed_label": "ETHAMLY-CPLX",
        "changed": False,
        "basis": "Exact contextual frame token in a full independently inspected native complex.",
    }
)
write("label-bindings.json", labels)
alternatives = read(R / "results/alternative-activity-options.json")
selection = []
for row in options + alternatives:
    selection.append(
        {
            "edge_id": row["graph_edge"]["id"],
            "recommended_disposition": "include_with_complete_scoped_payload",
            "reason": (
                "A faithful existing-schema edge is supported at the stated source/assay "
                "scope. Preserve descriptions, evidence and both endpoint qualifications "
                "where present; no stronger unqualified replacement is accepted."
            ),
            "graph_edge": row["graph_edge"],
        }
    )
write("recommended-option-selection.json", selection)
selected_graph = dict(payload)
selected_graph["references"] = option_refs
selected_graph["mechanistic_edges"] = payload["mechanistic_edges"] + [
    x["graph_edge"] for x in selection
]
write("recommended-selected-graph-payload.json", selected_graph)
counts = read(R / "results/final-design-counts.json")
counts.update(
    {
        "recommended_selected_edges": len(selected_graph["mechanistic_edges"]),
        "ledger_groups_total": len(deferred),
        "unresolved_deferred_groups": len(deferred) - 1,
        "resolved_euta_identity_group": 1,
    }
)
write("final-design-counts.json", counts)
