"""Retain the directly supported native-host EutC reporter location."""

import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET

R = Path(__file__).resolve().parents[1]
P = Path("/private/tmp/pathwaymech-next-272-primary-evidence-preparation")
N = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
SOURCE = P / "originals/cargo-2012-primary.xml"


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    (R / "results" / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root = ET.parse(SOURCE).getroot()
paths = {}


def visit(node, path):
    paths[id(node)] = path
    counts = {}
    for child in node:
        counts[child.tag] = counts.get(child.tag, 0) + 1
        visit(child, path + f"/{child.tag}[{counts[child.tag]}]")


visit(root, "/" + root.tag)
elements = list(root.iter())
assert all(elements[i].tag == "p" for i in [334, 570, 677])
sequence = read(N / "originals/UniProt-P19265.json")["sequence"]["value"][:19]
assert sequence == "MDQKQIEEIVRSVMASMGQ"
binding = {
    "path": str(SOURCE),
    "sha256": sha(SOURCE),
    "locators": [paths[id(elements[i])] for i in [334, 570, 677]],
    "read_scope": "Targeted direct paragraph reading; accepted parent main/SI scopes retained.",
    "issued_sequence_check": {
        "path": str(N / "originals/UniProt-P19265.json"),
        "sha256": sha(N / "originals/UniProt-P19265.json"),
        "locator": "/sequence/value first19aminoacids",
        "result": "Exact19-residue prefix matches the primary methods EutC signal sequence.",
        "limit": "This binds the short motif; the construct is not a full-length native protein.",
    },
}
location_ev = {
    "reference_id": "PMID:22428024",
    "source_locator": paths[id(elements[334])] + " | " + paths[id(elements[570])],
    "source_assertion": (
        "In the native Salmonella arm, EutC1–19-EGFP localized under ethanolamine "
        "conditions. Anti-GFP accessibility after shell breakage, but not with intact "
        "isolated BMCs, supports internal reporter encapsulation. This is not "
        "full-length native EutC localization."
    ),
}
construct_ev = {
    "reference_id": "PMID:22428024",
    "source_locator": paths[id(elements[677])],
    "source_assertion": (
        "The methods identify the LT2 EutC first19-residue sequence fused to the "
        "N-terminus of EGFP. The signal sequence was codon-optimized for E. coli "
        "expression. Here only the tested native Salmonella-host reporter arm is selected."
    ),
}
identity_ev = {
    "reference_id": "UniProtKB:P19265",
    "source_locator": "/sequence/value residues1–19 | /organism/taxonId",
    "source_assertion": (
        "The issued P19265 sequence begins MDQKQIEEIVRSVMASMGQ and has taxon99287. "
        "This exact first19-residue prefix matches the primary Methods LT2 EutC motif "
        "used in the EGFP fusion; it does not make the reporter a full-length protein."
    ),
}
graph = {
    "id": "option-eutc19-egfp-native-host-location",
    "subject": "UniProtKB:P19265",
    "predicate": "located_in",
    "object": "GO:0031471",
    "description": (
        "The EutC1–19-EGFP reporter is encapsulated in native Salmonella Eut BMCs "
        "under the tested ethanolamine-inducing condition. The qualified reporter "
        "claim does not localize full-length EutC or the whole EAL complex."
    ),
    "evidence": [location_ev, construct_ev, identity_ev],
    "endpoint_qualifiers": [
        {
            "endpoint": "subject",
            "kind": "experimental_construct",
            "description": (
                "LT2 EutC residues1–19 fused to the N-terminus of EGFP, with "
                "codon-optimized signal sequence; constitutively expressed in the tested "
                "native Salmonella host grown on ethanolamine. This endpoint denotes the "
                "short fusion reporter, not full-length native EutC."
            ),
            "evidence": [construct_ev, location_ev, identity_ev],
        }
    ],
}
for ev in [location_ev, construct_ev, identity_ev]:
    assert len(ev["source_assertion"]) <= 400
assert len(graph["endpoint_qualifiers"][0]["description"]) <= 400
row = {
    "design_key": graph["id"],
    "decision": "representable_scoped_native_host_reporter_location",
    "graph_edge": graph,
    "not_emitted_in_default_partial_payload": True,
    "source_binding": binding,
    "acceptance_conditions": [
        "Keep the first19-residue EGFP construct and native-host assay qualification.",
        "Do not transfer this to the full-length protein, K12 EutG reporter or EAL complex.",
    ],
}
options = read(R / "results/conditional-edge-options.json")
options.append(row)
write("conditional-edge-options.json", options)
write("cargo-construct-claim-design.json", row)
selection = read(R / "results/recommended-option-selection.json")
selection.append(
    {
        "edge_id": graph["id"],
        "recommended_disposition": "include_with_complete_scoped_payload",
        "reason": "Direct native-host reporter encapsulation supports qualified location.",
        "graph_edge": graph,
    }
)
write("recommended-option-selection.json", selection)
selected_graph = read(R / "results/recommended-selected-graph-payload.json")
selected_graph["mechanistic_edges"].append(graph)
write("recommended-selected-graph-payload.json", selected_graph)
deferred = read(R / "results/deferred-claim-ledger.json")
for row in deferred:
    if row["design_key"] == "EutT-metal":
        row["predicate_considered"] = row.pop("predicate_considered_but_not_emitted")
        row["decision"] = "qualified_reconstituted_feii_option_selected_other_inferences_limited"
        row["rationale"] = (
            "The selected FeII cofactor edge is limited to the tested reconstituted EutT state. "
            "Zn copurification and alternative-metal observations remain separate. "
            "No exclusive physiological metal occupancy or native donor follows."
        )
        row["graph_option_key"] = "option-eutt-invitro-fe"
    if row["design_key"] == "Alternative-activity-materials":
        row["predicate_considered"] = row.pop("predicate_considered_but_not_emitted")
        row["decision"] = "gtp_activity_options_selected_other_material_identity_gaps_retained"
        row["rationale"] = (
            "Both exact EutP/Q activity-to-GTP inputs are selected with preparation/Mg scope "
            "inside their payloads. They do not alter canonical ATP/ADP chemistry or infer "
            "GDP output. EutG NADPH/alternate-aldehyde facts remain explicit without guessed "
            "activity or material-microstate identifiers."
        )
        row["graph_option_keys"] = ["option-gtp-ENZRXN-26156", "option-gtp-ENZRXN-26157"]
    if row["design_key"] == "Cargo-reporters":
        row["predicate_considered"] = row.pop("predicate_considered_but_not_emitted")
        row["decision"] = "native_host_eutc19_reporter_option_included_other_inferences_limited"
        row["rationale"] = (
            "The existing experimental_construct qualifier faithfully represents LT2 "
            "EutC1–19-EGFP encapsulation in the native Salmonella host. Include that "
            "location option. Retain the negative K12 EutG reporter and broader "
            "cargo/interaction observations separately; no full-length localization follows."
        )
        row["graph_option_key"] = graph["id"]
write("deferred-claim-ledger.json", deferred)
for filename in ["integration-summary.json", "final-design-counts.json"]:
    counts = read(R / "results" / filename)
    counts.update(
        {
            "conditional_edges": len(options),
            "conditional_options_total": 19,
            "recommended_selected_edges": 97,
            "cargo_reporter_context_partially_resolved": True,
        }
    )
    write(filename, counts)
