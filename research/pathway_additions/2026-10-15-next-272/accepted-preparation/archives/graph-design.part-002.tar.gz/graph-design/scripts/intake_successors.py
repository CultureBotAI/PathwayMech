"""Copy frozen supplemental decisions and preserve their immutable bindings."""

import hashlib
import json
from pathlib import Path

R = Path(__file__).resolve().parents[1]
PACKETS = {
    "merged-baseline-rebind": (
        "4fc40f4cdfcdc99ec012637e8c71d50a382f2f685e0f191227d328d404f2406a",
        [
            "HANDOFF.md",
            "REVIEW.md",
            "artifact-manifest.json",
            "freeze-proof.json",
            "baseline-rebind-result.json",
        ],
    ),
}
PACKETS["eutt-specificity-followup"] = (
    "1bad82f0d7f0c4856089af17879d90992fc871c9f0383b93e1eaa1a6d0b5b3fc",
    [
        "HANDOFF.md",
        "artifact-manifest.json",
        "freeze-proof.json",
        "results/claim-dispositions.json",
    ],
)
PACKETS["eutt-followup-operational-correction"] = (
    "cf8a9778e5fcde82d3cd7c62070f94347018bbd3ed8b9a10f98056e1082a1c65",
    [
        "HANDOFF.md",
        "artifact-manifest.json",
        "freeze-proof.json",
        "results/verify-parent.json",
        "results/lint.json",
    ],
)
PACKETS["independent-eutt-followup-review"] = (
    "a2caffec320c34ac8fe582c70eebe9e27e95843ba4a09fde86046d9949b56e21",
    ["HANDOFF.md", "REVIEW.md", "RESULT.json", "artifact-manifest.json", "freeze-proof.json"],
)
PACKETS["euta-target-followup"] = (
    "844a3654fde27c39d071e556c66514a3a59bb2fd095b7639e10a6ed022d0ce6d",
    [
        "HANDOFF.md",
        "artifact-manifest.json",
        "freeze-proof.json",
        "results/complete-own-slot-reading.json",
        "results/claim-proposals.json",
    ],
)
PACKETS["ontology-order-successor"] = (
    "114be3fe478c501277376e35fa1f53b9b527c94fc398211a699a4170b36199a2",
    [
        "HANDOFF.md",
        "artifact-manifest.json",
        "freeze-proof.json",
        "accepted-four-term-delta.json",
        "lineage.json",
        "source-review-result.json",
    ],
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


bindings = []
for key, (manifest, files) in PACKETS.items():
    owner = Path("/private/tmp/pathwaymech-next-272-" + key)
    assert sha(owner / "artifact-manifest.json") == manifest
    for filename in files:
        src = owner / filename
        dst = R / "inputs" / key / filename
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(src.read_bytes())
        bindings.append(
            {
                "parent_owner": str(owner),
                "parent_manifest_sha256": manifest,
                "parent_path": filename,
                "copy_path": str(dst.relative_to(R)),
                "sha256": sha(src),
                "bytes": src.stat().st_size,
            }
        )
(R / "results/supplemental-intake-bindings.json").write_text(json.dumps(bindings, indent=2) + "\n")
