"""Bounded graph design, reading frozen inputs; no network or maintained writes."""

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/pathwaymech-next-272-graph-design/biology-audit')
N = Path('/private/tmp/pathwaymech-next-272-native-source-preparation')
P = Path('/private/tmp/pathwaymech-next-272-primary-evidence-preparation')
S = Path('/private/tmp/pathwaymech-next-272-native-magnesium-successor')
V = Path('/private/tmp/pathwaymech-next-272-independent-scientific-source-review')
B = ROOT.parent / 'baseline'


def read(p):
    return json.loads(p.read_text())


def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def binding(p, locator):
    assert p.is_file(), p
    return {'path': str(p), 'sha256': digest(p), 'locator': locator}


def emit(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def evidence_values(z):
    if isinstance(z, dict):
        if 'evidenceCode' in z:
            yield z
        for v in z.values():
            yield from evidence_values(v)
    elif isinstance(z, list):
        for v in z:
            yield from evidence_values(v)


def tier(ev):
    codes = {x['evidenceCode'] for x in ev}
    labels = []
    if 'ECO:0000269' in codes:
        labels.append('database cites experimental evidence; paper scope still controls')
    if 'ECO:0000250' in codes:
        labels.append('similarity transfer; not experiment on this issued protein')
    if 'ECO:0000255' in codes:
        labels.append('sequence-model/rule inference')
    if 'ECO:0000305' in codes:
        labels.append('curator inference')
    return labels or ['retain supplied evidence codes; no experimental scope inferred from absence of a code']


# Each accession has an individual biological judgment; no cross-species substitution.
# Format: recommended representation; deferred claims; specific experimental/evidence scope.
SPEC = {
 'P76551': ('Identity and reactivation narrative. A future activates edge requires a verified E. coli EAL target identity and inactive-state plus recombinant-assay qualifications.', 'No has_cofactor edges to ATP, Mg or free AdoCbl merely because they were required in a reactivation mixture; no EutA adenosylation or fixed EutA:EAL assembly.', 'PMID15466038 recombinant E. coli/JM109-associated evidence. ATP-dependent cofactor exchange is probable; EcoCyc membrane versus UniProt BMC inference unresolved.'),
 'Q9ZFV2': ('Identity, LT2 EutA/EAL association narrative and EAL reactivation/protection role. Association with induced LT2 metabolosomes can be described without exclusive lumen location.', 'No LT2 EAL complex identity is created; no typed interaction, stoichiometric complex, direct EutT delivery or free-cofactor binding claim.', 'UniProt reactivation transfers by similarity; PMID15516577 protection evidence differs from adenosylation. P07/P08 independently accepted 2022 association and inferred lumen remain distinct.'),
 'P0AEJ6': ('Identity; retain explicit gene-product catalytic-activity annotation as complex-subunit context. Only conditional enables to the authority-verified annotated RHEA:15313, with subunit scope; native complex carries catalyzes.', 'No isolated EutB catalysis, no unverified exact alias to MetaCyc:EUTB-MONOMER or automatic EutBC assembly location.', 'Mixed direct database citations and HAMAP. Native preparation includes NCIB8114, JM109 and N-terminal truncation; these are not MG1655 experiments.'),
 'P19264': ('Identity; conditional enables to authority-verified annotated RHEA:15313 only as the explicit source gene-product/activity claim in EutBC.', 'No fabricated LT2 complex, isolated EutB catalyst, outside location or exclusive lumen assignment.', 'UniProt mixes HAMAP, experiment citation and curator inference. LT2 BMC placement is inferred partly from EutC; 2013 exterior proposal is untested.'),
 'P19636': ('Identity; conditional enables to authority-verified annotated RHEA:15313 as complex subunit; native complex carries catalyzes.', 'No isolated EutC catalysis or direct full-length BMC targeting inferred from LT2 reporter fusions.', 'E. coli active N-terminal truncation removes 28 residues; retain that construct. BMC targeting is similarity transfer, unlike the catalytic evidence.'),
 'P19265': ('Identity; conditional enables to authority-verified annotated RHEA:15313 as complex subunit. Qualified located_in for EutC(1–19)-reporter cargo may be retained if exact endpoint qualifier names the tested fusion and host.', 'No full-length location proof from a peptide-reporter experiment, no fabricated LT2 complex, and no generic EutS activation edge for cargo binding.', 'P12 tests first19 residues in defined fusions in native Salmonella and engineered C2566/JM109 systems. P31 is abstract tier; full-length inference stays explicit.'),
 'P77218': ('Identity; prefer the separately issued E. coli EutD complex for catalyzes and native composition. Its UniProt activity annotation can be retained separately pending activity authority binding.', 'No blanket BMC located_in and no physiological forward flux inferred from reverse assay or isolated-plasmid acetate rescue.', 'P27 abstract tier only for PMID21046341; database supplies purified activity and homodimer. UniProt explicitly says cytoplasm versus BMC is unclear.'),
 'P41790': ('Identity; qualified catalytic recommendation to verified phosphotransacetylase activity with LT2 H6-EutD recombinant assay scope and both separately supported directions.', 'No new LT2 homodimer identifier, universal essentiality or native shell permeability from plasmid complementation.', 'P05 H6-EutD in BL21(DE3) directly assays acetyl-P+CoA to acetyl-CoA. P10 coupled assay supplies separate forward support. Homodimer annotation is similarity-based.'),
 'P77445': ('Identity; heterologous yeast acetylating acetaldehyde-dehydrogenase assignment can be retained as scoped source annotation, separately from LT2 direct biochemical proof.', 'No direct native MG1655 flux or native lumen localization; no NAD cofactor edge that confuses reaction cosubstrate with tightly bound prosthetic group.', 'P29/P30 abstracts and native ENZRXN0-8531 unpurified heterologous activity. UniProt catalytic chemistry, EutS interaction and targeting transfer by similarity.'),
 'P41793': ('Identity; qualified catalyzes to verified acetylating acetaldehyde-dehydrogenase reaction after reaction binding, using LT2 H6-EutE biochemical experiment. Qualified EutE(1–21)-reporter targeting is a separate optional context claim.', 'Do not transfer reporter location to native full-length protein or claim alcohol dehydrogenase activity. EutE/EutS interaction has no exact allowed interaction predicate.', 'P16 BL21(DE3)RIL-expressed N-terminal His6 protein about90% pure, reversible ALDH/ACR and NAD(H) preference. Engineered MG1655 glucose fermentation is distinct. P31 targeting evidence is abstract tier.'),
 'P76553': ('Identity; preserve E. coli-derived aldehyde-reduction evidence with an experimental_construct qualifier that states overexpression in crude extracts, and explicit uncertainty if a catalytic edge is later selected.', 'No purified EutG kinetics, identical NADH/NADPH preference, LT2-specific inference or negative native location from failed 1–19 reporter.', 'P14/P15 JCL16/BW25113-derived eutG overexpressed in AL626; crude extracts with measurable control activity. Similar endpoint activities do not establish identical kinetics. Iron assignment is similarity-based.'),
 'P41795': ('Identity and inferred alcohol-dehydrogenase branch assignment; keep the root ethanol branch intact irrespective of whether a strong protein catalytic edge is deferred.', 'Defer strong LT2 catalyzes and has_cofactor iron edges; no measured NAD recycling ratio or exclusive BMC location.', 'UniProt reaction is curator-inferred; native ENZRXN-26158 is mutant-block evidence. K12 crude-extract assays are not experiments on this LT2 protein. Historical phenotypes depend on pH and gas loss.'),
 'P76552': ('Identity and source-specific inner-membrane annotation; transport role retained in narrative as similarity inference.', 'No transport reaction or neutral/protonated interconversion invented; no transport-to-metabolosome edge, and no transfer of LT2 Yfp assay as K12 experiment.', 'UniProt function and RHEA:32747 annotation transfer from LT2 and use charged CHEBI:57603. Primary EutH paper supports uncharged substrate hypothesis at low calculated neutral concentration.'),
 'P41796': ('Identity; optional located_in to independently verified inner-membrane component with EutH-Yfp qualifier for the functional fusion experiment. Describe pH-dependent uncharged ethanolamine entry as supported interpretation.', 'No fabricated neutral transport reaction and no consumes/produces on EutH itself. Charged RHEA:32747 annotation remains disputed contextual evidence; no exact neutral=ethanolaminium mapping.', 'P19 LT2-derived strains, calculated neutral EA threshold below25µM; peripheral functional fusion signal, not purified transport kinetics. Database protonated transport conflicts with the primary uncharged interpretation.'),
 'P77277': ('Identity and proposed chaperone/assembly narrative only.', 'No activates EutBC, catalyzes, has_cofactor or measured native BMC assembly claim.', 'K12 functional assertion is similarity transfer; dated EcoCyc lack-of-information text is not evidence of absence.'),
 'P0A206': ('Identity; describe overexpression-dependent EutJ+EutS BMC-like structures with host and construct scope.', 'Proposed protection/refolding/chaperone mechanism cannot become activates EutBC; no definite catalytic reaction or fixed shell composition.', 'UniProt function mixes PMID27063436 experimental overexpression with probable mechanism. Single EutS versus EutJ+EutS engineered phenotypes do not establish native direct molecular regulation.'),
 'P76540': ('Identity; native monomeric solution state and source shell-role inference remain annotated. No artificial complex node needed for a monomer.', 'No nucleic acid binding edge from HTH shape, no demonstrated native MG1655 shell function.', 'K12 shell association is probable/similarity. Solution monomer and structural HTH observation differ from hypothetical DNA/RNA binding.'),
 'Q9ZFU8': ('Identity; component of ethanolamine BMC shell may be represented by scoped part_of GO:0031471 after component interpretation, with recombinant shell-assembly evidence distinguished from native physiology.', 'No nucleic acid binding or fixed whole-shell stoichiometry. Do not turn monomer-by-similarity into a purified LT2 observation.', 'LT2 eutSMNLK coexpression in E. coli produces artificial shells; monomeric solution annotation transfers from K12.'),
 'P76541': ('Identity; preserve native EcoCyc:EutL trimer composition separately. Shell-role and BMC location remain source-annotated, not direct permeability proof.', 'No six-chain assembly from pseudohexamer shape, no has_cofactor Zn, ATP or cobalamin transport inferred from crystal pore size.', 'K12 crystal structures and zinc-soak conformational changes; physiological Zn relevance explicitly unclear. Trimer chain count is three.'),
 'P0A1C9': ('Identity; scoped part_of GO:0031471 shell component is representable with engineered-assembly evidence noted. Homotrimer geometry remains similarity annotation.', 'No fabricated LT2 trimer CURIE, specific transport or zinc gating physiological edge.', 'LT2 artificial eutSMNLK shells are experimental; trimer/pseudohexamer architecture transfers from K12/other ortholog, not identical direct evidence.'),
 'P0ABF4': ('Identity; source-native EutM hexamer composition may be retained separately; BMC role and pore geometry kept as source-annotated context.', 'No exact EutQ interaction edge, substrate-specific pore transfer, Pdu replacement or engineered scaffold promoted into native ethanolamine pathway.', 'K12 structures support hexamer/pore geometry. EutQ association and BMC location use similarity; pore permeability remains inference.'),
 'P41791': ('Identity; scoped part_of GO:0031471 shell component. Keep tagged EutM/EutQ co-elution as interaction narrative with exact construct scope.', 'No new interaction predicate or replacement activates edge; cytoplasmic-facing helix inference does not establish EutQ location. Pdu/SpyCatcher constructs stay outside this native graph.', 'P32 C-terminal His6 co-elution and engineered/native reporter phenotypes; geometry is similarity-based. Coexpression and direct interaction are separate assertions.'),
 'P0AEJ8': ('Identity; preserve crystal hexamer and solution pentamer as different preparation observations, separate from the native EcoCyc six-chain assembly statement.', 'No definitive physiological six-chain shell vertex or transported positively charged substrate.', 'K12 PMID17588214/18292340 crystals differ from PMID23456886 solution pentamer. Native assembly membership can be retained but coefficient6 cannot be silently generalized.'),
 'P41792': ('Identity; scoped shell-component part_of GO:0031471 is representable from coexpression evidence; pentamer architecture stays a similarity annotation.', 'No fabricated LT2 pentamer ID or borrowed EcoCyc six-chain composition.', 'LT2 shell construction is experimentally referenced; homopentamer annotation transfers from P0DUM1 and location from K12.'),
 'P76556': ('Identity and similarity-based acetate-kinase annotation; any future catalytic edge must explicitly retain this evidence tier.', 'Do not transfer LT2 direct assay, physiological P requirement, BMC localization or magnesium independence to K12.', 'K12 has no no-divalent-cation annotation. Accepted Mg successor applies as caution about LT2 assays, not a new K12 experiment.'),
 'P0A208': ('Identity; qualified catalyzes to independently verified acetate-kinase activity with recombinant LT2 assay scope. Keep GTP alternative and distinct phenotype in prose.', 'No magnesium-independent claim or has_cofactor Mg solely from added assay Mg; no fixed ATP handoff to EutA/T or established internal BMC location.', 'P09/P10 recombinant LT2 assays and conditional deletion results. Accepted successor: EDTA-resistant activity measured with magnesium-containing assays, not magnesium-free catalysis; P lacked the Q anoxic growth phenotype.'),
 'P76555': ('Identity and similarity-based acetate-kinase/assembly-hub annotation; maintain distinction from experimental LT2 evidence.', 'No exact native Q dimer ID, definite cytoplasmic-face localization, direct EutE targeting, or magnesium-independent claim.', 'K12 role and assembly annotations transfer by similarity; no K12 no-divalent-cation source annotation exists.'),
 'Q9ZFV5': ('Identity; qualified acetate-kinase catalyzes recommendation with recombinant LT2 scope. Assembly phenotype and tagged Q/M co-elution remain explicit contextual narratives.', 'No magnesium-independent or obligate Mg-cofactor edge; no fixed dimer, native outside location, cargo-transfer or ATP-channeling edge.', 'P09/P10 anoxic EA+tetrathionate and GSSG conditions differ from P. P32 interaction uses tagged constructs and failed in-vivo interaction mutants. Accepted Mg successor overrides broader database prose.'),
 'P36547': ('Identity and similarity-based transcriptional activator narrative.', 'No direct ligand-binding or has_cofactor AdoCbl; no activates metabolic reaction/pathway that substitutes for an exact operon transcription target.', 'UniProt K12 regulation largely similarity-based; native EcoCyc putative role is not experimental operon activation in MG1655.'),
 'Q9ZFU7': ('Identity; retain LT2 genetic support for eut operon transcription activation and autoinduction. A future activates edge needs exact identified transcription-process/operon target, not the metabolic reaction.', 'No inferred physical binding to ethanolamine/AdoCbl from induction; no EAL competition interaction edge or ssrB infection branch expansion.', 'P21 genetic reporters/revertants; P22 competition model read at abstract/intro tier. Promoter-binding annotation for ssrB/eutS is distinct and not fully inspected primary evidence here.'),
 'P63746': ('Identity; preserve source-native six-chain EutS assembly and distinct G39V construct geometry. Any BMC source-location claim retains inference tier.', 'No flat wild-type hexamer, generic cargo-targeting activation, or native single-protein shell conclusion.', 'K12 bent about40-degree structure; G39V changes shape. LT2 cargo recruitment is similarity transfer; N/C-terminal tags alter assembly in separate LT2 evidence.'),
 'Q9ZFV7': ('Identity; scoped part_of GO:0031471 shell role, with constructed EutS-only shells and targeted reporters distinguished. Qualified location for tested constructs is optional.', 'No native six-chain count from an unverified alias, no exact molecular interaction edge for cargo, no full-length EutE/EutC location inferred solely from reporter fusions.', 'P12/P13 eutS-alone engineered shells, G39V geometry and P31 reporter scope; terminal His tags disrupt assembly. Bent geometry is probable rather than new LT2 structure proof.'),
 'P65643': ('Identity; retain similarity-based EutT role and conflicts as ancillary narrative.', 'Defer detailed catalytic graph: native2 versus UniProt3 protons, cobinamide contradiction, unspecified physiological donor and BMC side. No exclusive FeII physiological requirement.', 'K12 EutT catalytic/cofactor/homodimer annotations transfer from LT2. No K12 biochemical or intact route proof follows.'),
 'Q9ZFV4': ('Identity; native EutT complex and source RXN-19336 are ancillary, separately preserved if selected by parent design. Scoped FeII cofactor annotation can be represented on verified native complex with purified assay qualification and alternatives.', 'No corrected equation, cobinamide reaction, identified physiological flavoprotein, direct delivery to EAL or definite lumen location. No dimer coefficient inserted into native missing-coefficient slot.', 'P17 tag-cleaved LT2 protein, anoxic free dihydroflavin/Fre/NADH assays, Zn copurification and maximal FeII reconstitution. P26 main unavailable; cobinamide specificity unresolved. P07 EutT compartment side unclear.'),
}

raw_proteins = sorted((N / 'originals').glob('UniProt-*.json'))
protein_rows = []
for path in raw_proteins:
    raw = read(path)
    accession = raw['primaryAccession']
    assert accession in SPEC, accession
    gene = raw['genes'][0]['geneName']['value']
    representation, deferred, scope = SPEC[accession]
    comments = []
    for i, comment in enumerate(raw.get('comments', [])):
        ev = list(evidence_values(comment))
        comments.append({'comment_type': comment['commentType'],
                         'source': binding(path, f'/comments/{i}'),
                         'evidence': ev, 'evidence_tiers': tier(ev)})
    row = {'id': f'UniProtKB:{accession}', 'category': 'protein', 'gene': gene,
           'taxon_id': f"NCBITaxon:{raw['organism']['taxonId']}",
           'identity_source': binding(path, '/primaryAccession'),
           'identity_scope_source': binding(path, '/organism'),
           'representable_recommendation': representation,
           'deferred_or_prohibited_claims': deferred,
           'experimental_and_inference_scope': scope,
           'top_graph_default': 'retain separately issued protein node; conditional edges require their listed identity/evidence qualifications',
           'comment_evidence_bindings': comments,
           'exact_alias_policy': 'No exact alias between UniProt, MetaCyc or EcoCyc is established by this design; no cross-strain substitution.'}
    if raw['organism']['taxonId'] == 83333:
        cautions = [x for x in comments if x['comment_type'] == 'CAUTION']
        assert cautions
        row['cpz55_scope'] = {'interpretation': 'MG1655 CPZ-55 insertion may impair expression; curator inference, neither demonstrated native flux nor proof of pathway absence. UniProt taxon83333 is not MG1655-exclusive.', 'source': cautions[0]['source']}
    if gene in {'eutP', 'eutQ'}:
        row['mandatory_successor'] = binding(S / 'results/successor-dispositions.json', '/changes' if isinstance(read(S / 'results/successor-dispositions.json'), dict) else '/')
        row['magnesium_interpretation'] = 'EDTA-treatment resistance under magnesium-containing coupled/HPLC/NMR assays. Neither metal-independent catalysis nor an obligate bound-Mg cofactor follows.'
    protein_rows.append(row)
assert len(protein_rows) == len(SPEC) == 34
emit('protein-design-ledger.json', protein_rows)

# Independent scientific review is used at its stated scope. This is design, not a new full-paper review.
claims = read(P / 'results/claim-ledger.json')['claims']
reviews = {x['id']: x for x in read(V / 'results/independent-claim-dispositions.json')['claims']}
sources = {x['key']: x for x in read(P / 'results/source-reading-ledger.json')['sources']}
DECISIONS = {
 'P01': ('context_only', 'Describe conditional EutD phenotype and inoculum washing; no essentiality predicate or unconditional pathway activation edge.'),
 'P02': ('defer_typed_location', 'Exterior/surface EutBC is explicitly untested; no located_in or occurs_in edge. Keep competing model in prose.'),
 'P03': ('context_only', 'Keep two branches but no fixed1:1 flux or private cofactor transfer. Preserve unpublished suppressor scope and contradictory Table7 symbols.'),
 'P04': ('context_only', 'Describe shell/plasmid contrast. No generic permeability edge, no AdhP addition as native EutG replacement.'),
 'P05': ('conditional_catalyzes', 'Qualified LT2 H6-EutD catalytic claim supports reverse phosphotransacetylase chemistry; verify exact protein/activity identities and retain recombinant BL21(DE3) context.'),
 'P06': ('context_only', 'Plasmid pta acs complementation is conditional growth evidence, not native metabolosome permeability or direct location.'),
 'P07': ('qualified_association_context', 'LT2 EAL/EutA/EutT association with induced metabolosomes is supported. EutA lumen remains inference and EutT side unresolved. No invented LT2 EAL complex or generic interaction predicate.'),
 'P08': ('context_only', 'Retain low/high CNCbl growth and EutA/EAL in-vitro association separately; no fixed complex stoichiometry, EutT handoff or absence-of-partners claim.'),
 'P09': ('context_only', 'Keep Q anoxic EA+tetrathionate phenotype distinct from P; starter glycerol, GSSG and expression conditions prevent unconditional essentiality edges.'),
 'P10': ('qualified_catalyzes', 'Recombinant P/Q acetate kinase and EutD coupled reaction support qualified catalytic edges to verified issued activities; no fixed physiological P flux. Apply magnesium successor.'),
 'P11': ('defer_typed_location', 'Internal ATP recycling, P/Q location, exact conflicting allele and kinetic value remain narrative; no provides_input_for handoff to EutA/T.'),
 'P12': ('qualified_located_in', 'Optional EutC(1–19)-reporter located_in verified ethanolamine BMC term, with subject experimental_construct qualifier naming cargo/host; no full-length EutBC extrapolation.'),
 'P13': ('context_only', 'Negative EutG(1–19) targeting is construct-specific; EutS artificial single-protein shells do not define native shell composition or native G exclusion.'),
 'P14': ('defer_strong_catalysis', 'Keep overexpressed EutG crude-extract aldehyde reduction as qualified evidence. No purified enzyme claim, same-strain flux inference or unqualified direct catalysis.'),
 'P15': ('context_only', 'Similar crude-extract endpoint activities and measurable controls do not demonstrate identical kinetics or NADPH cofactor use in native ethanolamine catabolism.'),
 'P16': ('qualified_catalyzes', 'N-terminal His6 LT2 EutE ALDH/ACR supports qualified catalytic edges to verified reaction; no alcohol dehydrogenase edge, no native MG1655 flux assertion.'),
 'P17': ('conditional_has_cofactor', 'Native EutT complex may carry source-scoped FeII has_cofactor with tag-cleaved anoxic assay and alternative-metal notes. Free dihydroflavin experiment does not identify native flavoprotein donor.'),
 'P18': ('conditional_activation_only', 'EutA reactivation could support activates a verified state-qualified EAL complex; exact recombinant protein/complex scope first. No has_cofactor from ATP/Mg/free AdoCbl mixture and no EutA adenosylation.'),
 'P19': ('qualified_location_context', 'Functional LT2 EutH-Yfp peripheral signal permits qualified location only with verified target. Describe uncharged-ethanolamine entry; no invented neutral transport reaction or charged=neutral alias.'),
 'P20': ('context_only', 'Extract adenosyltransferase elevation supports source-limited EutT role, not homogeneous protein, direct EAL delivery or EutA adenosylation.'),
 'P21': ('defer_exact_regulatory_edge', 'EutR transcription activation/self-regulation require exact operon or transcription process targets. Do not point activates to metabolic reaction or free ligand.'),
 'P22': ('context_only', 'Competition/autoinduction model at abstract-introduction tier is not inspected direct ligand-binding proof; no cofactor or interaction edge.'),
 'P23': ('context_only', 'Historical17-gene/five-shell-homologue statement informs participant inventory, not fixed physical shell stoichiometry or all direct functions.'),
 'P24': ('context_only', 'Conditional bypass of shell/EutA/EutE roles retains expression, medium and redox-additive distinctions; no universal dispensability or contradictory negative edge.'),
 'P25': ('context_only', 'Preserve EutD phenotype discrepancy and pH/gas-loss conditions. No universal reconciliation attributed to uninspected Starai main.'),
 'P26': ('defer_equation_resolution', 'Abstract PPi+Pi evidence does not settle full EutT proton count, cobinamide substrate, free flavin versus protein reductant or exact reduced-donor identity.'),
 'P27': ('source_annotation_only', 'E. coli EutD bidirectional activity may be retained at abstract/database scope. No uninspected exact construct, kinetic value or strain detail accepted.'),
 'P28': ('qualified_composition_context', 'Alpha6beta6 EAL and truncation effects at abstract tier corroborate qualified native complex membership; no full-length localization or invented LT2 complex.'),
 'P29': ('source_annotation_only', 'Engineered yeast replacement evidence can qualify E. coli EutE activity; no native MG1655 pathway or purified-enzyme claim.'),
 'P30': ('source_annotation_only', 'Engineered yeast eutE/mhpF evidence is scoped; no new native pathway members or isolated purified/native MG1655 activity conclusion.'),
 'P31': ('qualified_reporter_context', 'EutC1–19/EutE1–21 reporter targeting remains abstract-tier and construct-specific. No full-length cargo location or exact EutS interaction edge.'),
 'P32': ('context_only', 'Retain engineered/native assembly phenotypes and tagged EutQ/EutM co-elution; allowed predicates lack exact physical interaction. No native cytosolic-face location or direct cargo transfer. Cite Held et al.2016.'),
}
claim_rows = []
for i, c in enumerate(claims):
    source = sources[c['source']]
    artifact_bindings = []
    for a in source['artifacts']:
        if a['path'].startswith('results/'):
            continue
        p = P / a['path']
        assert digest(p) == a['sha256']
        artifact_bindings.append(binding(p, c['locator']))
    assert artifact_bindings, c
    status, decision = DECISIONS[c['id']]
    claim_rows.append({'id': c['id'], 'source_key': c['source'],
                       'accepted_claim': c['structured_assertion'], 'qualification': c['qualification'],
                       'design_disposition': status, 'recommendation': decision,
                       'original_artifact_bindings': artifact_bindings,
                       'source_locator_convention': 'Original source-reading-ledger locators: XML P/F identifiers, publisher displayed lines, element ordinals, PDF printed page, or named metadata abstract. Bindings retain every source artifact because some claims span multiple chunks; availability does not imply all chunks independently reread in this design.',
                       'source_access': source['access'], 'source_read_scope': source['actual_read_scope'],
                       'source_limits': source['limits'],
                       'accepted_claim_binding': binding(P / 'results/claim-ledger.json', f'/claims/{i}'),
                       'independent_review_binding': binding(V / 'results/independent-claim-dispositions.json', f'/claims/{i}'),
                       'independent_review': reviews[c['id']]})
assert len(claim_rows) == len(DECISIONS) == 32
emit('primary-claim-design-ledger.json', claim_rows)

# Compact cross-cutting constraints; parent owns the full native-edge inventory.
native = {(x['attributes']['orgid'], x['id']): x for fn in ['all-native-projections.json', 'ecoli-native-projections.json'] for x in read(N / 'results' / fn)}


def native_slots(org, frame, names):
    x = native[(org, frame)]
    return [binding(N / x['source_path'], s['locator']) for s in x['slots'] if s['slot'] in names]


constraints = [
 {'id': 'complex-only-eutbc-catalysis', 'recommendation': 'MetaCyc:ETHAMLY-CPLX catalyzes MetaCyc:ETHAMLY-RXN is the verified native complex/activity relationship; preserve native activity evidence and strain/construct scope. has_part to each native EutB/EutC chain retains coefficient6 in description because generic has_part has no stoichiometry field. Do not replace with subunit catalyzes.', 'sources': native_slots('META', 'ETHAMLY-CPLX', ['component', 'comment']) + native_slots('META', 'ETHAMLY-ENZRXN', ['enzyme', 'reaction', 'evidence', 'comment'])},
 {'id': 'eutd-composition', 'recommendation': 'Native EutD complex has two G7288-MONOMER chains. Keep META and ECOLI namespaces separate unless exact aliases independently verified. No new LT2 complex CURIE.', 'sources': native_slots('META', 'CPLX0-7912', ['component', 'comment']) + native_slots('ECOLI', 'CPLX0-7912', ['component'])},
 {'id': 'eutt-unspecified-native-component-count', 'recommendation': 'Native CPLX-9275 has STM2467-MONOMER membership with no coefficient. UniProt LT2 homodimer is a separate annotation; do not add native coefficient2 or exact alias without evidence.', 'sources': native_slots('META', 'CPLX-9275', ['component', 'comment']) + [binding(N / 'originals/UniProt-Q9ZFV4.json', '/comments/7')]},
 {'id': 'shell-geometry', 'recommendation': 'EcoCyc EutL is three-chain/pseudohexamer; M and S six-chain native slots; EutN six-chain native/crystal versus five-chain solution conflict remains visible. Whole-shell composition cannot be inferred by summing isolated oligomers.', 'sources': sum([native_slots('ECOLI', f, ['component', 'comment']) for f in ['CPLX0-7801', 'CPLX0-7835', 'CPLX0-7836', 'CPLX0-7613']], []) + [binding(N / 'originals/UniProt-P0AEJ8.json', '/comments/2')]},
 {'id': 'eutt-equation-ambiguity', 'recommendation': 'Keep RXN-19336 ancillary to five-member root; native2 versus UniProt3 proton counts and generic reductant discrepancy cannot be represented as valid alternative_interpretation because shared-ID coefficient changes are disallowed. Defer mechanistic decomposition and cobinamide expansion.', 'sources': native_slots('META', 'RXN-19336', ['left', 'right', 'comment']) + [binding(N / 'originals/UniProt-Q9ZFV4.json', '/comments/0'), binding(N / 'originals/UniProt-Q9ZFV4.json', '/comments/2'), binding(N / 'originals/UniProt-Q9ZFV4.json', '/comments/3')]},
 {'id': 'location-levels', 'recommendation': 'Do not blanket-locate the five reactions in a lumen. EutA membrane versus BMC annotations, EutD explicit uncertainty, EutG native membrane/cytosol versus inferred BMC, EutQ assumed cytoplasmic face, and EutT unknown side retain source-specific scope.', 'sources': native_slots('ECOLI', 'G7281-MONOMER', ['location']) + native_slots('ECOLI', 'G7283-MONOMER', ['location']) + [binding(N / 'originals/UniProt-P77218.json', '/comments/6'), binding(N / 'originals/UniProt-Q9ZFV5.json', '/comments/7')]},
 {'id': 'magnesium-successor', 'recommendation': 'Preserve EDTA-treatment resistance with Mg-containing assay conditions. No Mg-independent label; added Mg alone does not establish an obligatory bound-Mg cofactor. Applies experimentally to LT2, not an assay of K12.', 'sources': [binding(S / 'results/primary-reading.json', '/'), binding(S / 'results/successor-dispositions.json', '/'), binding(S / 'originals/PMC4857615-efetch.xml', './/*[@id="P39"]'), binding(S / 'originals/PMC4857615-efetch.xml', './/*[@id="P40"]')]},
 {'id': 'euth-microstate', 'recommendation': 'Charged native ethanolaminium and neutral ethanolamine are distinct. Retain source transport conflict; no neutral transport reaction or proton exchange invented. Exact membrane and neutral chemical authority checks belong to parent/core design.', 'sources': [binding(S / 'results/contextual-euth-disposition.json', '/'), binding(N / 'originals/UniProt-P41796.json', '/comments/0'), binding(N / 'originals/UniProt-P41796.json', '/comments/2'), binding(P / 'originals/EutH-2004-author.pdf', 'printed pp6885,6887–6889; Figure6; PDF pages1,5')]},
]
emit('cross-cutting-constraints.json', constraints)

policy = {'format': 'bounded-pathway-biology-design/1',
          'scope': '34 individual UniProt protein design dispositions,32 accepted primary-claim dispositions,8 cross-cutting constraints. Design recommendation only; no maintained curation, complete new primary rereading, identifier alias approval or scientific final acceptance.',
          'allowed_categories_used': ['protein', 'complex', 'cellular_component', 'molecular_activity', 'biological_process', 'cofactor'],
          'allowed_predicates_recommended_or_conditioned': ['catalyzes', 'enables', 'has_part', 'part_of', 'located_in', 'has_cofactor', 'activates'],
          'typed_edge_policy': 'Predicates only appear as recommendations. No record-ready edge is accepted without exact declared endpoints, source assertions, qualifier evidence and independent final record review. A proposed model does not become a stronger edge merely because a predicate exists.',
          'blocked_relations': ['physical interaction/binding has no exact allowed predicate; do not substitute activates/regulates/part_of', 'protein source annotation is not verified exact alias', 'no invented LT2 EAL/assembly/operon/activity identifiers', 'no mixed or inferred transport mechanism', 'no top-level assertion_status field to rescue speculative assertion'],
          'core_boundary': 'Five issued native reactions and both acetate and ethanol branches remain; this biological audit does not redefine the material graph.',
          'primary_acceptance_policy': 'All32 bounded claims inherit accepted independent scope. Paper artifacts are linked, not all reread here; original database comment evidence is read directly. S24 author correction and Mg successor are mandatory.',
          'source_bindings': [binding(B / 'docs/CAUSAL_GRAPHS.md', '/'), binding(B / 'src/pathwaymech/schema.py', 'ALLOWED_EDGE_PREDICATES; NODE_CATEGORIES'), binding(S / 'results/citation-successor.json', '/'), binding(V / 'results/successor-acceptance.json', '/')],
          'counts': {'proteins': len(protein_rows), 'protein_comment_bindings': sum(len(x['comment_evidence_bindings']) for x in protein_rows), 'primary_claims': len(claim_rows), 'cross_cutting_constraints': len(constraints)}}
emit('design-policy.json', policy)

# Bounded replay validation: exact cited file bytes and JSON-pointer existence.
def walk(z):
    if isinstance(z, dict):
        if {'path', 'sha256', 'locator'} <= z.keys():
            yield z
        for value in z.values():
            yield from walk(value)
    elif isinstance(z, list):
        for value in z:
            yield from walk(value)


bindings = list(walk([protein_rows, claim_rows, constraints, policy]))
for ref in bindings:
    path = Path(ref['path'])
    assert digest(path) == ref['sha256'], path
    pointer = ref['locator']
    if path.suffix == '.json' and pointer.startswith('/') and pointer != '/':
        value = read(path)
        for token in pointer[1:].split('/'):
            token = token.replace('~1', '/').replace('~0', '~')
            value = value[int(token)] if isinstance(value, list) else value[token]
schema = ast.parse((B / 'src/pathwaymech/schema.py').read_text())
constants = {node.targets[0].id: ast.literal_eval(node.value) for node in schema.body if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in {'ALLOWED_EDGE_PREDICATES', 'NODE_CATEGORIES'}}
assert set(policy['allowed_predicates_recommended_or_conditioned']) <= constants['ALLOWED_EDGE_PREDICATES']
assert set(policy['allowed_categories_used']) <= constants['NODE_CATEGORIES']
emit('verification.json', {'status': 'passed', 'protein_count': len(protein_rows), 'primary_claim_count': len(claim_rows), 'source_binding_count': len(bindings), 'unique_source_files': len({x['path'] for x in bindings}), 'all_source_hashes_match': True, 'json_pointer_bindings_resolve': True, 'allowed_schema_predicates_and_categories_only': True, 'repository_tests': 'not run: recommendation-only files in owned temporary directory', 'scientific_limit': 'Mechanical validation is not biological acceptance. No full-primary rereading claim.'})

# New parent-supplied original, explicitly outside the accepted frozen packet.
# Main P9/P10 read directly during this design; supplements/independent review pending.
followup = Path('/private/tmp/pathwaymech-next-272-eutt-specificity-followup/originals/PMC4504680-efetch.xml')
assert digest(followup) == 'eb04059b7233d069d2c243bccb2b08352399ba9657b8731d09f4225b213ea2b5'
emit('eutt-followup-lead.json', {
    'status': 'pending_parent_supplement_validation_and_independent_acceptance',
    'source': 'PMID25914129; PMC4504680; DOI10.1002/anie.201501930',
    'actual_read_scope_here': 'Main P9 and P10 only, direct XML reading; no supplement or figure-pixel inspection',
    'source_bindings': [binding(followup, './/*[@id="P9"]'), binding(followup, './/*[@id="P10"]')],
    'bounded_reading': 'P9 reports bioassay support for adenosylation of pre-reduced Co(I)Cbi as well as Co(I)Cbl, whereas Co(II)Cbi did not support the corresponding EutT-dependent bioassay and did not undergo the required axial-ligand removal. Competition experiments are described as consistent with weak alternative-substrate binding. Oxidation state and assay preparation may reconcile blanket database cobinamide statements.',
    'design_consequence': 'Do not write all-cobinamide inactivity. Preserve raw conflicting annotations while identifying oxidation state and pre-reduction as consequential scope. The main reading alone does not approve a new cobinamide reaction, repair native/UniProt proton coefficients or establish physiological reductant identity.',
    'handoff_status': 'P10 explicitly proposes direct EutT-to-EAL cofactor delivery; no provides_input_for or direct-interaction edge from this proposal.',
    'boundary': 'No additional member in the five-reaction core; parent will complete supplement/independent acceptance.'
})
