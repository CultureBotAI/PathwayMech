"""Read-only upper-bound identifier design audit; no authority publication."""

from __future__ import annotations

import base64
import hashlib
import importlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

OWNER = Path(__file__).resolve().parent
BASE = OWNER.parent / "baseline"
SUPPORT = OWNER / "reviewed-support"
NATIVE = Path("/private/tmp/pathwaymech-next-272-native-source-preparation")
CORE = Path("/private/tmp/pathwaymech-next-272-core-identity-preparation")
ROOT_PROBE = Path("/private/tmp/pathwaymech-next-272-authority-design/existing-profile-probe.json")
COMMIT = "90695df63225de6f7379c9b48f0519287ac1896e"
sys.path.insert(0, str(SUPPORT / "src"))
spec = importlib.util.spec_from_file_location(
    "reviewed_source_builder", SUPPORT / "scripts/build_source_identifier_snapshot.py"
)
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
biocyc_pathway = importlib.import_module("pathwaymech.biocyc_pathway")
ecocyc_named_complex = importlib.import_module("pathwaymech.ecocyc_named_complex")

inputs = {}


def binding(path: Path) -> dict:
    raw = path.read_bytes()
    result = {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    inputs[str(path)] = result
    return result


def read(path: Path):
    binding(path)
    return json.loads(path.read_text())


def write(name, value):
    (OWNER / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def trial(call):
    try:
        result = call()
        return {"accepted": True, "result": result}
    except (ValueError, KeyError) as exc:
        return {"accepted": False, "rejection_type": type(exc).__name__, "rejection": str(exc)}


snapshots = {
    name: read(BASE / "data/identifier_authorities" / name)
    for name in ["ontology.json", "sources.json"]
}
projections = read(NATIVE / "results/all-native-projections.json") + read(
    NATIVE / "results/ecoli-native-projections.json"
)
uni = read(NATIVE / "results/uniprot-complete-projections.json")
dispositions = {v["id"]: v for v in read(NATIVE / "results/all-native-object-dispositions.json")}
root_probe = read(ROOT_PROBE)
rebind = read(OWNER / "baseline-rebind.json")
reuse_rows = read(CORE / "results/reuse-bindings.json")["entries"]
root_probes = {v["id"]: v for v in root_probe["rows"]}
receipts = []
for directory in [NATIVE / "receipts", NATIVE / "inputs/core", CORE / "receipts"]:
    for path in sorted(directory.rglob("*.json")):
        value = json.loads(path.read_text())
        if isinstance(value, dict) and value.get("status") == 200 and value.get("sha256"):
            receipts.append((path, value))


def receipt_bindings(digest, url_fragment=None):
    matches = []
    for path, value in receipts:
        if value["sha256"] == digest and (
            url_fragment is None or url_fragment in value.get("url", "")
        ):
            matches.append(
                {
                    **binding(path),
                    "url": value.get("url"),
                    "final_url": value.get("final_url"),
                    "status": 200,
                }
            )
    return matches


def current_evidence(path, fragment=None):
    result = binding(path)
    result["receipts"] = receipt_bindings(result["sha256"], fragment)
    return result


def cache_matches(curie, raw_hash):
    matches = []
    for filename, data in snapshots.items():
        if curie not in data["terms"]:
            continue
        term = data["terms"][curie]
        source = data["sources"][term["source"]]
        embedded = []
        for field, value in source.items():
            if isinstance(value, dict) and "original_base64" in value:
                original = base64.b64decode(value["original_base64"], validate=True)
                embedded.append(
                    {
                        "field": field,
                        "native_id": value.get("id"),
                        "bytes": len(original),
                        "sha256": hashlib.sha256(original).hexdigest(),
                        "matches_current_original": hashlib.sha256(original).hexdigest()
                        == raw_hash,
                    }
                )
        matches.append(
            {
                "snapshot": str(BASE / "data/identifier_authorities" / filename),
                "term": term,
                "source_key": term["source"],
                "source": {
                    k: source[k]
                    for k in ["url", "version", "sha256", "kind", "sha256_scope", "license"]
                    if k in source
                },
                "source_hash_matches_current_original": source["sha256"] == raw_hash,
                "retained_complete_originals": embedded,
                "fresh_issuer_verification_from_snapshot_alone": False,
            }
        )
    return matches


modules = []
for name in [
    "biocyc_phenylacetate",
    "biocyc_glutaryl",
    "biocyc_methanogenesis",
    "biocyc_acetate_methanogenesis",
]:
    module = importlib.import_module("pathwaymech." + name)
    binding(SUPPORT / "src/pathwaymech" / (name + ".py"))
    modules.append((name, module))

rows = []
profile_trials = []
shape_trials = []
validation = {
    "native_originals_verified": 0,
    "native_own_slots_verified": 0,
    "uniprot_originals_verified": 0,
    "assertions": [],
}
for record in projections:
    pgdb = record["attributes"]["orgid"]
    prefix = {"META": "MetaCyc", "ECOLI": "EcoCyc"}[pgdb]
    curie = prefix + ":" + record["id"]
    original = NATIVE / record["source_path"]
    evidence = current_evidence(original, "getxml?" + pgdb + ":" + record["id"])
    assert evidence["sha256"] == record["sha256"] and evidence["bytes"] == record["bytes"]
    evidence["historical_reuse_bindings"] = [
        v for v in reuse_rows if v.get("sha256") == evidence["sha256"]
    ]
    assert evidence["receipts"] or evidence["historical_reuse_bindings"], curie
    urls = {r["url"] for r in evidence["receipts"]}
    assert len(urls) <= 1, (curie, urls)
    acquired_url = next(iter(urls)) if urls else None
    evidence["acquisition_scope"] = (
        "matching acquisition receipt retained"
        if urls
        else (
            "complete historical original retained by exact reuse binding; no "
            "matching acquisition receipt in audited packet"
        )
    )
    xml = ET.fromstring(original.read_bytes())
    entities = [n for n in xml if n.tag != "metadata"]
    assert len(entities) == 1
    entity = entities[0]
    assert entity.tag == record["type"] and entity.attrib == record["attributes"]
    assert entity.get("detail") == "full"
    assert xml.findtext("metadata/query") == pgdb + ":" + record["id"]
    assert xml.find("metadata/PGDB").attrib == record["version"]
    assert len(entity) == record["own_slot_count"] == len(record["slots"])
    assert [ET.tostring(n, encoding="unicode") for n in entity] == [
        s["xml"] for s in record["slots"]
    ]
    validation["native_originals_verified"] += 1
    validation["native_own_slots_verified"] += len(entity)
    parents = [{"type": n.tag, **n.attrib} for wrapper in entity.findall("parent") for n in wrapper]
    components = [
        {
            "objects": [{"type": n.tag, **n.attrib} for n in wrapper if n.tag != "coefficient"],
            "explicit_coefficient": wrapper.findtext("coefficient"),
        }
        for wrapper in entity.findall("component")
    ]
    activities = [
        {
            "type": n.tag,
            **n.attrib,
            "common_names": [v.text for v in n.findall("common-name")],
            "enzyme_refs": [v.attrib for v in n.findall("enzyme/Protein")],
            "reaction_refs": [v.attrib for v in n.findall("reaction/Reaction")],
        }
        for wrapper in entity.findall("catalyzes")
        for n in wrapper
    ]
    exact_profiles = []
    for module_name, module in modules:
        if curie not in module.PROFILES:
            continue
        kind = (
            module.META_KIND
            if module_name == "biocyc_phenylacetate" and pgdb == "META"
            else module.ECO_KIND
            if module_name == "biocyc_phenylacetate"
            else module.KIND
        )
        if acquired_url is None:
            exact_profiles.append(
                {
                    "curie": curie,
                    "kind": kind,
                    "not_run": (
                        "No actual acquisition receipt URL retained in audited packet; no "
                        "URL fabricated from XML base or profile convention."
                    ),
                }
            )
            continue
        source = {
            "url": acquired_url,
            "version": record["version"]["version"],
            "sha256": evidence["sha256"],
            "license": "Design probe only; acquisition licensing retained in source preparation",
        }
        result = trial(
            lambda m=module, s=source, k=kind, p=original: m.document(p.read_bytes(), s, k)
        )
        if result["accepted"]:
            result["result"] = {
                "id": result["result"]["id"],
                "native_type": result["result"]["projection"]["native_type"],
                "label_origin": result["result"]["projection"]["label_origin"],
            }
        test = {
            "curie": curie,
            "kind": kind,
            "code": str(SUPPORT / "src/pathwaymech" / (module_name + ".py")),
            "acquired_url": acquired_url,
            "original_sha256": evidence["sha256"],
            **result,
        }
        exact_profiles.append(test)
        profile_trials.append(test)
    shape = None
    if entity.tag == "Pathway":
        shape = trial(lambda e=entity, f=record["id"]: biocyc_pathway.project(e, f))
        shape["profile"] = "metacyc-pathway-xml.project"
    elif pgdb == "ECOLI" and entity.tag == "Protein" and components:
        shape = trial(lambda e=entity, f=record["id"]: ecocyc_named_complex.project(e, f))
        shape["profile"] = "ecocyc-named-protein-complex-xml.project"
    elif pgdb == "META" and entity.tag == "Protein" and not record["common-name"]:
        shape = trial(lambda e=entity, f=record["id"]: builder._metacyc_complex_activities(e, f))
        shape["profile"] = "metacyc-protein-xml unnamed homomer activity shape only"
    if shape:
        if shape["accepted"]:
            shape.pop("result")
        shape.update(
            curie=curie,
            scope=(
                "Raw entity shape only: does not bypass or validate issuing "
                "request grammar, full parser, whole snapshot or scientific "
                "assertions"
            ),
        )
        shape_trials.append(shape)
    matches = cache_matches(curie, evidence["sha256"])
    status = "present_exact_curie" if matches else "absent_from_both_reviewed_term_snapshots"
    old_untyped = bool(matches) and all("kind" not in m["source"] for m in matches)
    notes = []
    if matches:
        notes.append(
            "Preserve the existing selected authority owner unless a "
            "separately reviewed refresh is justified; current direct original"
            " is additional evidence, not automatic replacement."
        )
    else:
        notes.append(
            "Authority addition is needed only if this exact CURIE is selected"
            " on a named graph surface; context/excluded inventory does not "
            "require blanket addition."
        )
    if old_untyped:
        notes.append(
            "Existing cache is an untyped name/provenance assertion; it does "
            "not itself prove complete native object type, composition or "
            "current issuer verification."
        )
    if pgdb == "ECOLI":
        notes.append(
            "Keep EcoCyc namespace and MG1655 PGDB identity distinct from "
            "same-spelled META frame and K-12 UniProt taxon83333; aliases "
            "require independent proof."
        )
    if not record["common-name"]:
        notes.append(
            "No direct common-name: linked activity names and frame tokens are"
            " different label origins and cannot be silently substituted."
        )
    if entity.tag == "Enzymatic-Reaction":
        notes.append(
            "A native enzyme/activity assertion is distinct from its Reaction "
            "and Protein; context.activity validates references only and is "
            "not a generic standalone authority profile."
        )
    if entity.tag == "Regulation":
        notes.append(
            "Unnamed Regulation object records a directed source claim, not an"
            " independently named biochemical reaction or a universally "
            "supported physiological effect."
        )
    if entity.tag == "cco":
        notes.append(
            "Preserve native cco class/instance distinction and structural "
            "compartment scope; do not equate a cytosol/membrane identity with"
            " GO microcompartment or assign every enzyme to its lumen."
        )
    if entity.get("class") == "true" and entity.tag == "Protein":
        notes.append(
            "Whole generic flavoprotein redox class, not a chemically exact "
            "small molecule, sequence-specific protein or proved physiological"
            " electron donor."
        )
    if entity.tag == "Organism":
        notes.append(
            "Native Organism class is source taxonomy context; NCBITaxon "
            "issued identity must be grounded separately, not created by "
            "prefix replacement."
        )
    row = {
        "curie": curie,
        "inventory_family": "full_native_object",
        "upper_bound_only": True,
        "native_type": entity.tag,
        "is_class": entity.get("class") == "true",
        "pgdb": pgdb,
        "version": record["version"]["version"],
        "native_source": evidence,
        "acquired_url": acquired_url,
        "direct_common_names": [n.text for n in entity.findall("common-name")],
        "direct_synonyms": [n.text for n in entity.findall("synonym")],
        "direct_parents": parents,
        "direct_components": components,
        "direct_catalyzes": activities,
        "own_slot_counts": dict(sorted(Counter(n.tag for n in entity).items())),
        "source_preparation_disposition": dispositions[pgdb + ":" + record["id"]],
        "snapshot_status": status,
        "snapshot_matches": matches,
        "existing_exact_bounded_profile_trials": exact_profiles,
        "raw_entity_shape_trial": shape,
        "root_generic_full_reader_trial": root_probes.get(curie),
        "design_notes": notes,
    }
    if matches:
        native_need = "preserve_existing_selected_authority_owner"
    elif entity.tag == "Pathway":
        native_need = "new_reviewed_complete_pathway_shape_if_selected"
    elif entity.tag == "Reaction" and record["id"] == "RXN-19336":
        native_need = "new_reviewed_mixed_protein_class_and_coefficient_reaction_shape_if_selected"
    elif entity.tag == "Reaction":
        native_need = "existing_unnamed_reaction_semantics_but_acquired_request_contract_mismatch"
    elif entity.tag == "Protein" and entity.get("class") == "true":
        native_need = "new_reviewed_whole_flavoprotein_class_shape_if_selected"
    elif (
        entity.tag == "Protein" and not record["common-name"] and not (shape and shape["accepted"])
    ):
        native_need = "new_reviewed_unnamed_protein_or_heteromer_shape_if_selected"
    elif pgdb == "ECOLI" and entity.tag == "Protein" and not components:
        native_need = "new_reviewed_ecoli_polypeptide_shape_if_selected"
    elif pgdb == "ECOLI" and entity.tag == "Protein" and shape and not shape["accepted"]:
        native_need = "new_reviewed_complex_ancillary_evidence_shape_if_selected"
    elif entity.tag == "Protein":
        native_need = "existing_bounded_name_shape_candidate_but_acquired_request_contract_mismatch"
    elif entity.tag in {"Compound", "Enzymatic-Reaction", "Regulation", "Gene", "Organism", "cco"}:
        native_need = "new_exact_native_authority_scope_if_selected_or_keep_source_context"
    else:
        raise AssertionError(curie)
    row["integration_assessment"] = native_need
    if shape and shape["profile"] in {
        "metacyc-pathway-xml.project",
        "ecocyc-named-protein-complex-xml.project",
    }:
        mod = biocyc_pathway if entity.tag == "Pathway" else ecocyc_named_complex
        row["shape_slots_outside_existing_allowlist"] = sorted(
            set(row["own_slot_counts"]) - mod.CORE - mod.ANCILLARY
        )
    rows.append(row)

uni_trials = []
for record in uni:
    curie = "UniProtKB:" + record["id"]
    path = NATIVE / "originals" / ("UniProt-" + record["id"] + ".json")
    evidence = current_evidence(path, "/uniprotkb/" + record["id"] + ".json")
    raw = json.loads(path.read_text())
    assert raw["primaryAccession"] == record["id"]
    assert raw["organism"] == record["organism"]
    assert raw["entryAudit"] == record["audit"]
    assert raw["proteinDescription"] == record["name"]
    assert raw["comments"] == record["comments"]
    assert evidence["receipts"], curie
    names = list(builder.uniprot_terms(raw))
    assert len(names) == 1 and names[0][0] == curie
    validation["uniprot_originals_verified"] += 1
    test = {
        "curie": curie,
        "original_sha256": evidence["sha256"],
        "profile": "uniprot",
        "function": "build_source_identifier_snapshot.py:261 uniprot_terms",
        "naming_extraction_passed": True,
        "label": names[0][1],
        "synonyms": names[0][2],
        "limit": (
            "Name extraction only. This legacy parser does not validate "
            "URL/accession agreement, taxon, sequence, evidence codes or "
            "entry-version semantics; audit validates accession/taxon/audit "
            "against retained individual JSON separately."
        ),
    }
    uni_trials.append(test)
    matches = cache_matches(curie, evidence["sha256"])
    rows.append(
        {
            "curie": curie,
            "inventory_family": "canonical_uniprot_protein",
            "upper_bound_only": True,
            "native_source": evidence,
            "gene": record["gene"],
            "organism": record["organism"],
            "entry_audit": record["audit"],
            "snapshot_status": "present_exact_curie"
            if matches
            else "absent_from_both_reviewed_term_snapshots",
            "snapshot_matches": matches,
            "existing_name_extractor_trial": test,
            "design_notes": [
                (
                    "Use the supported uniprot name profile if selected, with complete"
                    " current canonical JSON and actual receipt provenance; biological"
                    " evidence and exact aliases need separate review."
                ),
                (
                    "K-12 taxon83333 entries are not automatically MG1655-only; LT2 "
                    "taxon99287 identities stay separate. No native-to-UniProt "
                    "equivalence is inferred from a dblink alone."
                ),
            ],
        }
    )

extra = []
go_path = NATIVE / "originals/GO-microcompartment.json"
go = read(go_path)
for ident in ["GO:0031471", "GO:0031469"]:
    found = [v for v in go["results"] if v["id"] == ident]
    assert len(found) == 1 and found[0]["isObsolete"] is False
    extra.append(
        (
            ident,
            current_evidence(go_path),
            found[0],
            (
                "Direct QuickGO term response; reviewed ontology builder uses "
                "semantic SQL database inputs, not this JSON as a drop-in "
                "authority input."
            ),
        )
    )
chebi_path = CORE / "originals/CHEBI-16000.json"
chebi = read(chebi_path)
assert chebi["chebi_accession"] == "CHEBI:16000"
extra.append(
    (
        "CHEBI:16000",
        current_evidence(chebi_path),
        {"id": chebi["chebi_accession"], "name": chebi["name"], "stars": chebi["stars"]},
        (
            "Direct ChEBI JSON current identity; neutral ethanolamine remains "
            "distinct from MetaCyc:ETHANOL-AMINE/CHEBI:57603 ethanolaminium. "
            "Existing ontology builder uses semantic SQL, not this JSON."
        ),
    )
)
for tax in ["511145", "99287", "83333"]:
    path = CORE / "originals" / ("NCBI-TAX-" + ("511145" if tax == "83333" else tax) + ".xml")
    xml = ET.fromstring(path.read_bytes())
    if tax == "83333":
        candidates = xml.findall("Taxon/LineageEx/Taxon")
        scope = (
            "Fresh issuing NCBI lineage child within whole 511145 response; "
            "not an independently acquired top-level 83333 entry or complete "
            "83333 record."
        )
    else:
        candidates = xml.findall("Taxon")
        scope = "Direct top-level NCBI Taxonomy record."
    found = [n for n in candidates if n.findtext("TaxId") == tax]
    assert len(found) == 1
    extra.append(
        (
            "NCBITaxon:" + tax,
            current_evidence(path),
            {
                "id": tax,
                "name": found[0].findtext("ScientificName"),
                "rank": found[0].findtext("Rank"),
                "scope": scope,
            },
            scope
            + (
                " Reviewed ontology builder's semantic SQL route remains distinct "
                "from these current issuer XML bytes."
            ),
        )
    )
for curie, evidence, identity, note in extra:
    matches = cache_matches(curie, evidence["sha256"])
    rows.append(
        {
            "curie": curie,
            "inventory_family": "requested_ontology_identity",
            "upper_bound_only": True,
            "native_source": evidence,
            "current_issuer_identity": identity,
            "snapshot_status": "present_exact_curie"
            if matches
            else "absent_from_both_reviewed_term_snapshots",
            "snapshot_matches": matches,
            "design_notes": [
                note,
                (
                    "Pinned snapshot presence is not fresh issuer verification. If "
                    "selected and absent, refresh through the supported ontology path "
                    "or review a new explicit issuer profile; do not copy graph labels"
                    " into authority."
                ),
            ],
        }
    )

assert len(rows) == 268 and len({r["curie"] for r in rows}) == 268
assert (
    validation["native_originals_verified"] == 228
    and validation["native_own_slots_verified"] == 3689
    and validation["uniprot_originals_verified"] == 34
)
validation["assertions"] = [
    (
        "228 unmodified whole native originals match every projected own "
        "slot, metadata query, top-level native identity and PGDB release"
    ),
    (
        "34 canonical UniProt originals match accession, organism, entry "
        "audit, protein description and comments"
    ),
    "All 268 exact CURIEs are unique; namespace spellings are preserved",
    "No network, installs, Git writes or authority refresh performed",
    (
        "All copied reviewed support files and baseline files match actual"
        " merge worktree byte-for-byte (baseline-rebind.json)"
    ),
]
summary = {
    "scope": "Upper-bound design inventory, not selected graph or authority-addition instructions",
    "reviewed_code_commit": COMMIT,
    "actual_current_main_rebind_pending": False,
    "actual_merge_baseline": rebind["actual_head"],
    "baseline_rebind": str(OWNER / "baseline-rebind.json"),
    "rows": len(rows),
    "families": dict(Counter(r["inventory_family"] for r in rows)),
    "snapshot_status_counts": dict(Counter(r["snapshot_status"] for r in rows)),
    "snapshot_status_by_family": {
        f: dict(Counter(r["snapshot_status"] for r in rows if r["inventory_family"] == f))
        for f in sorted({r["inventory_family"] for r in rows})
    },
    "native_types": dict(Counter(r["native_type"] for r in rows if "native_type" in r)),
    "native_by_namespace": dict(Counter(r["pgdb"] for r in rows if "pgdb" in r)),
    "native_own_slots": validation["native_own_slots_verified"],
    "native_unnamed_by_type": dict(
        Counter(
            r["native_type"]
            for r in rows
            if "direct_common_names" in r and not r["direct_common_names"]
        )
    ),
    "bounded_profile_trial_count": len(profile_trials),
    "bounded_profile_trials_accepted": sum(t["accepted"] for t in profile_trials),
    "bounded_profile_unique_ids_accepted": sorted(
        {t["curie"] for t in profile_trials if t["accepted"]}
    ),
    "native_existing_owners_with_identical_original_hash": sorted(
        r["curie"]
        for r in rows
        if r["inventory_family"] == "full_native_object"
        and any(m["source_hash_matches_current_original"] for m in r["snapshot_matches"])
    ),
    "uniprot_naming_trials_passed": len(uni_trials),
    "native_matching_receipt_count": sum(
        bool(r["native_source"]["receipts"])
        for r in rows
        if r["inventory_family"] == "full_native_object"
    ),
    "native_historical_reuse_without_matching_receipt": [
        r["curie"]
        for r in rows
        if r["inventory_family"] == "full_native_object" and not r["native_source"]["receipts"]
    ],
}
for path in [
    BASE / "src/pathwaymech/identifiers.py",
    BASE / "src/pathwaymech/biocyc_native_context.py",
    BASE / "docs/IDENTIFIERS.md",
    SUPPORT / "scripts/build_source_identifier_snapshot.py",
    SUPPORT / "src/pathwaymech/ecocyc_named_complex.py",
    SUPPORT / "src/pathwaymech/biocyc_pathway.py",
    SUPPORT / "src/pathwaymech/biocyc_carrier.py",
    NATIVE / "artifact-manifest.json",
    CORE / "artifact-manifest.json",
    OWNER / "reviewed-support-bindings.json",
]:
    binding(path)
write(
    "authority-needs-matrix.json",
    {
        "scope": summary["scope"],
        "reviewed_code_commit": COMMIT,
        "actual_current_main_rebind_pending": False,
        "actual_merge_baseline": rebind["actual_head"],
        "baseline_rebind": str(OWNER / "baseline-rebind.json"),
        "rows": rows,
    },
)
write(
    "existing-bounded-profile-trials.json",
    {
        "scope": (
            "Actual complete-source exact request trials for existing exact "
            "frame profiles; no URL replacement"
        ),
        "rows": profile_trials,
    },
)
write(
    "native-shape-trials.json",
    {
        "scope": "Shape-only diagnostics, never proof of full request/parser suitability",
        "rows": shape_trials,
    },
)
write("uniprot-name-trials.json", uni_trials)
write("verification.json", validation)
write("summary.json", summary)
write("input-bindings.json", sorted(inputs.values(), key=lambda v: v["path"]))
print(json.dumps(summary, indent=2))
