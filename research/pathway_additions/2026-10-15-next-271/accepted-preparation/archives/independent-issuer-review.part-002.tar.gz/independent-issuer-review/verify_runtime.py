from pathlib import Path
import json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=O/'inputs/frozen-issuer'
rows=json.loads((R/'results/runtime-verification.json').read_text())['files'];out=[]
for x in rows:
 p=Path(x['path']);h=hashlib.sha256(p.read_bytes()).hexdigest();assert h==x['sha256'] and p.stat().st_size==x['bytes'];out.append({'path':str(p),'bytes':p.stat().st_size,'sha256':h})
assert len(out)==77
(O/'results/independent-runtime-check.json').write_text(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':out,'all77_match':True,'scope':'Read-only exact existing runtime binding; no install, repair or new runtime.'},indent=2)+'\n');print('PASS77 runtime hashes')
