from pathlib import Path
import json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
def sha(b):return hashlib.sha256(b).hexdigest()
expected={'artifact-manifest.json':'7a3d6b3991b7ca720ae7ff79620e5a25f107127bc84bc5b58785510df397a950','HANDOFF.md':'42ca1c2585ca8ccc05a58b2aa2da8cc56773c315ec63004c9519f3870601e1d6','freeze-proof.json':'35bc8e63d07f58510f95a882b557be1b3ef5059c11c3f851817ba969401ea1ad'}
for n,h in expected.items():assert sha((R/n).read_bytes())==h,n
m=json.loads((R/'artifact-manifest.json').read_text());listed={x['path'] for x in m['files']};actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
assert actual==listed|{'artifact-manifest.json','freeze-proof.json'} and not any(p.is_symlink() for p in R.rglob('*'))
assert len(listed)==879 and len(actual)==881 and sum(x['bytes'] for x in m['files'])==35839254
for x in m['files']:
 b=(R/x['path']).read_bytes();assert sha(b)==x['sha256'] and len(b)==x['bytes'],x['path']
copied=[]
for n in sorted(actual):
 p=R/n;b=p.read_bytes();q=O/'inputs/frozen-issuer'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);copied.append({'path':n,'bytes':len(b),'sha256':sha(b)})
for x in json.loads((O/'prepared-inputs-manifest.json').read_text())['files']:
 p=O/x['path'];assert p.stat().st_size==x['bytes'] and sha(p.read_bytes())==x['sha256']
(O/'results').mkdir(exist_ok=True)
result={'intake_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':str(R),'release_hashes':expected,'listed':879,'physical':881,'listed_bytes':35839254,'hidden_and_ignored_included':True,'all_copied_exact':True,'prepared_inputs_unchanged':True,'files':copied,'scope':'Inventory and copy acceptance only; independent issuer scientific review pending.'}
(O/'results/issuer-intake.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS879 listed/881 physical;35,839,254 listed bytes; all copied exactly; prepared inputs unchanged.')
