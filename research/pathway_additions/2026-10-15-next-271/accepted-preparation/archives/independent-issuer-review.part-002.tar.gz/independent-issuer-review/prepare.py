from pathlib import Path
import json,hashlib,subprocess,os,datetime,collections,xml.etree.ElementTree as E
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review')
B=Path('/private/tmp/pathwaymech-next-271-20261015')
S=Path('/private/tmp/pathwaymech-next-271-source-preparation')
I=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
R=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
def sha(b):return hashlib.sha256(b).hexdigest()
def copy(p,q):
 b=p.read_bytes();q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return {'source':str(p),'copy':str(q.relative_to(O)),'bytes':len(b),'sha256':sha(b)}
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
def git(*args):return subprocess.check_output(['git','-C',str(B),*args],env=env)
head=git('rev-parse','HEAD').decode().strip();tree=git('rev-parse','HEAD^{tree}').decode().strip()
assert head=='63ebb3b3e29ca1ed6472597104347d9fbc98f4a5' and tree=='5448122efcfbd8ae2ac90ad42e70557b03d9b78e'
paths=['CLAUDE.md','.claude/skills/add-pathway/SKILL.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','docs/IDENTIFIERS.md','conf/identifier_policy.yaml','conf/identifier_sources.json','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','src/pathwaymech/identifiers.py','src/pathwaymech/biocyc_methanogenesis.py','src/pathwaymech/biocyc_phenylacetate.py','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json']
contracts=[]
for rel in paths:
 p=B/rel;b=p.read_bytes();committed=git('cat-file','blob',head+':'+rel);assert committed==b,rel
 row=copy(p,O/'inputs/baseline'/rel);row['committed_blob']=git('rev-parse',head+':'+rel).decode().strip();row['worktree_equals_committed_blob']=True;contracts.append(row)
receipt=copy(Path('/private/tmp/pathwaymech-next-271-ci/actual270-merged-baseline.json'),O/'inputs/actual270-merged-baseline.json')
plans=[]
for name,expected in [('initial-identity-scope.json','05fcd0cc3b19d7c4fe1b8c6ff633abac3fd42b1927de66d5d78e6cb47a511512'),('all-269-identity-scope-dispositions.json','a61fc56ef198aba19cd1bae42d5b595f2eb30f72b8dfc567f4e4a048c6fc1719')]:
 p=I/'results'/name;assert sha(p.read_bytes())==expected;plans.append(copy(p,O/'inputs/released-plan'/name))
plan=json.loads((O/'inputs/released-plan/initial-identity-scope.json').read_text()); rows=json.loads((O/'inputs/released-plan/all-269-identity-scope-dispositions.json').read_text());assert len(rows)==269 and len({x['frame'] for x in rows})==269
selected=[x for x in rows if x['selected']];assert len(selected)==91 and len(rows)-len(selected)==178
assert dict(collections.Counter(x['type'] for x in selected))==plan['selected_by_type']
assert {t:sorted(x['frame'] for x in selected if x['type']==t) for t in plan['selected_ids_by_type']}==plan['selected_ids_by_type']
source_names=set()
for p in (S/'originals/native').glob('*.xml'):
 n=next(x for x in E.parse(p).getroot() if x.tag!='metadata');source_names.add(n.get('frameid'))
 x=next(x for x in rows if x['frame']==n.get('frameid'));assert x['type']==n.tag and x['class']==(n.get('class')=='true')
assert source_names=={x['frame'] for x in rows}
accepted=[]
for n in ['HANDOFF.md','REVIEW.md','RESULT.json','artifact-manifest.json','freeze-proof.json','results/independent-claim-dispositions.json','results/independent-primary-reading-scope.json','results/final-integrity.json']:
 accepted.append(copy(R/n,O/'inputs/accepted-source-review'/n))
assert sha((R/'artifact-manifest.json').read_bytes())=='d18d6d594d87721ff4e4e53b69a1fecf166b645357d5c571c2604e95e2f9cd2d'
source_release=[]
for n in ['HANDOFF.md','ASSESSMENT.md','artifact-manifest.json','freeze-proof.json']:
 source_release.append(copy(S/n,O/'inputs/accepted-source'/n))
assert sha((S/'artifact-manifest.json').read_bytes())=='06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5'
result={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/next268_reaction_review_completion','status':'prepared; entire issuer owner still mutable and not accepted','baseline':{'head':head,'tree':tree,'receipt':receipt,'contracts':contracts,'scope':'Exact committed contract/snapshot binding only; no corpus novelty or historical-science review.'},'explicitly_released_plan_files':plans,'plan_counts':{'all_native_objects':269,'selected_for_identity_research':91,'excluded_from_this_identity_selection':178,'selected_by_type':plan['selected_by_type'],'selected_pointer_occurrences_author_plan':474},'plan_check_scope':'Exact hashes,269 identities/types/class flags and91/178 arithmetic checked; selection is provisional identity-research coverage, not final graph/authority selection or acceptance of unseen issuer outputs.','accepted_source_review_copies':accepted,'source_release_copies':source_release,'boundaries':['Do not mutate accepted source review.','Do not inspect mutable issuer outputs as final evidence; only two explicitly released plan files consumed.','Await complete immutable issuer manifest and HANDOFF.','No network, helpers, installs, maintained/Git/GH writes or full test runs.','No full taxonomy-cache rehash absent a concrete integrity reason.']}
(O/'PREPARATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'prepared':True,'head':head,'tree':tree,'committed_files_bound':len(contracts),'native_plan':{'selected':91,'excluded':178},'issuer_final_review_started':False},indent=2))
