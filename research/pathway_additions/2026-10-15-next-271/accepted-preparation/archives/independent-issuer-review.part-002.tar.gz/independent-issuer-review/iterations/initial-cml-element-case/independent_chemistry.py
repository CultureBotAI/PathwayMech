from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as E
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors as D
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=O/'inputs/frozen-issuer'
checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def obj(f):return next(x for x in E.parse(R/f'inputs/source/originals/native/META-{f}.xml').getroot() if x.tag!='metadata')
def comp(m):return dict(sorted(collections.Counter(x.GetSymbol() for x in Chem.AddHs(m).GetAtoms()).items()))
def cml_graph(c):
 rw=Chem.RWMol();idx={}
 for a in c.findall('atomArray/atom'):
  at=Chem.Atom(a.attrib['elementType'].title());at.SetFormalCharge(int(a.get('formalCharge','0')));idx[a.attrib['id']]=rw.AddAtom(at)
 for b in c.findall('bondArray/bond'):
  pair=(b.get('atomRefs2') or b.get('atomRefs')).split();rw.AddBond(*(idx[i] for i in pair),{'1':Chem.BondType.SINGLE,'2':Chem.BondType.DOUBLE,'3':Chem.BondType.TRIPLE,'A':Chem.BondType.AROMATIC}[b.attrib['order']])
 m=rw.GetMol();Chem.SanitizeMol(m);return m
plan=json.loads((R/'results/all-269-identity-scope-dispositions.json').read_text());selected=[x for x in plan if x['selected'] and (x['type']=='Compound' or x['type']=='Protein' and x['class'])]
ck('41 native materials',len(selected)==41);ck('35 concrete',sum(not x['class'] for x in selected)==35)
rows=[];concrete={};kegg_counts=collections.Counter();chebi_ids=set()
for row in selected:
 f=row['frame'];n=obj(f);p=R/f'inputs/source/originals/native/META-{f}.xml';c=n.find('cml/molecule');ni=n.findtext('inchi');m=Chem.MolFromInchi(ni) if ni else None
 z={'frame':f,'native_sha256':sha(p),'class':row['class'],'native_inchi':ni,'comparisons':[]}
 if not row['class']:
  ck(f+' native InChI imports',m is not None);ck(f+' supplied InChI key',n.findtext('inchi-key').removeprefix('InChIKey=')==Chem.MolToInchiKey(m))
  formula=c.find('formula').attrib['concise'].split();declared={formula[i]:int(formula[i+1]) for i in range(0,len(formula),2)}
  ck(f+' native elemental formula',comp(m)==dict(sorted(declared.items())));ck(f+' native charge',Chem.GetFormalCharge(m)==int(c.attrib['formalCharge']))
  cm=cml_graph(c);u=Chem.Mol(m);Chem.RemoveStereochemistry(u);ck(f+' CML standardized stereo-stripped connectivity',Chem.MolToInchi(cm)==Chem.MolToInchi(u))
  concrete[f]=(comp(m),Chem.GetFormalCharge(m));z.update(formula=D.CalcMolFormula(m),charge=Chem.GetFormalCharge(m),native_key=Chem.MolToInchiKey(m),cml_comparison_scope='standardized InChI after removing stereo from native InChI; no drawing stereo interpretation')
 for d in n.findall('dblink'):
  db=d.findtext('dblink-db');ident=d.findtext('dblink-oid')
  if db=='CHEBI':
   p=R/f'originals/ChEBI-{ident}.json';v=json.loads(p.read_text());chebi_ids.add(ident);ck(f+' ChEBI issuing identity '+ident,v['chebi_accession']=='CHEBI:'+ident and v['is_released'] is True)
   st=v.get('default_structure') or {};im=Chem.MolFromInchi(st['standard_inchi']) if st.get('standard_inchi') else None
   same=bool(m is not None and im is not None and Chem.MolToInchi(m)==Chem.MolToInchi(im));z['comparisons'].append({'issuer':'CHEBI','id':ident,'sha256':sha(p),'name':v['name'],'same_standard_inchi':same,'scope':'Class guard: no exact molecular alias' if row['class'] else 'Standardized InChI identity includes its represented stereo/isotope/charge scope; no automatic alias'})
   if not row['class']:ck(f+' direct ChEBI complete standardized match '+ident,same and comp(m)==comp(im) and Chem.GetFormalCharge(m)==Chem.GetFormalCharge(im))
  elif db=='LIGAND-CPD':
   p=R/f'originals/KEGG-{ident}.txt';t=p.read_text();ck(f+' KEGG exact entry '+ident,t.startswith('ENTRY       '+ident))
   q=R/f'originals/KEGG-{ident}.mol'
   if q.exists():
    km=Chem.MolFromMolBlock(q.read_text());ck(f+' KEGG mol imports '+ident,km is not None);same=bool(m is not None and Chem.MolToInchi(m)==Chem.MolToInchi(km));kegg_counts['same' if same else 'different']+=1
    z['comparisons'].append({'issuer':'KEGG','id':ident,'sha256':sha(p),'mol_sha256':sha(q),'same_standard_inchi':same,'formula':D.CalcMolFormula(km),'charge':Chem.GetFormalCharge(km)})
 rows.append(z)
ck('39 direct ChEBI originals',len(chebi_ids)==39);ck('33 direct KEGG MOL comparisons',sum(kegg_counts.values())==33);ck('15 equal18 different KEGG representations',dict(kegg_counts)=={'same':15,'different':18})
root=obj('METH-ACETATE-PWY');eqs=[]
for ref in root.findall('reaction-list/Reaction'):
 f=ref.attrib['frameid'];n=obj(f);delta=collections.Counter();q=0;unknown=[];terms=[]
 for side,sign in [('left',-1),('right',1)]:
  for wrap in n.findall(side):
   nodes=[x for x in wrap if x.get('frameid')];ck(f+' unique term',len(nodes)==1);ident=nodes[0].attrib['frameid'];coeff=int(wrap.findtext('coefficient') or 1);terms.append((side,ident,coeff))
   if ident not in concrete:unknown.append(ident);continue
   formula,charge=concrete[ident];q+=sign*coeff*charge
   for element,count in formula.items():delta[element]+=sign*coeff*count
 dd={k:v for k,v in sorted(delta.items()) if v};balanced=not dd and q==0 if not unknown else None
 if not unknown:ck(f+' complete native balance',balanced)
 eqs.append({'reaction':f,'terms':terms,'unknown_generic_terms':unknown,'known_element_delta':dd,'known_charge_delta':q,'complete_balance':balanced,'scope':'Own left-to-right signed equation; unknown classes prevent a complete balance; no inferred class formula or flux.'})
ck('three equations completely determined',sum(x['complete_balance'] is not None for x in eqs)==3)
expected=json.loads((R/'results/structure-distinction-followups.json').read_text())['native_equation_balances']
for x in eqs:
 a=next(y for y in expected if y['reaction']==x['reaction']);ck(x['reaction']+' author balance comparison',all(a[k]==x[k] for k in ['unknown_generic_terms','known_element_delta','known_charge_delta','complete_balance']))
out={'rdkit':rdBase.rdkitVersion,'checks':checks,'materials':rows,'native_balances':eqs,'kegg_comparison_counts':dict(kegg_counts),'limits':['No auto alias or authority acceptance.','CML stereo not interpreted; standard InChI normalization is its stated comparison scope.','Unknown generic carrier formulas not supplied.']}
(O/'results/independent-chemistry.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(checks),'independent chemistry/balance checks;',len(rows),'materials; KEGG',dict(kegg_counts))
