from pathlib import Path
import collections
import gzip
import hashlib
import json
import xml.etree.ElementTree as ET

O = Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
NS = 'http://rdf.rhea-db.org/'
graph = collections.defaultdict(list)
count = 0
with gzip.open(O / 'originals/rhea.rdf.gz', 'rb') as handle:
    for _, e in ET.iterparse(handle, events=['end']):
        if e.tag != '{' + RDF + '}Description':
            continue
        count += 1
        graph[e.get('{' + RDF + '}about')].extend([{'predicate': x.tag[1:].replace('}', ''), 'resource': x.get('{' + RDF + '}resource'), 'literal': x.text, 'attributes': dict(x.attrib)} for x in e])
        e.clear()


def vals(uri, pred):
    return [x['resource'] if x['resource'] is not None else x['literal'] for x in graph[uri] if x['predicate'] == NS + pred]


def one(uri, pred):
    v = set(vals(uri, pred))
    assert len(v) == 1, (uri, pred, v)
    return next(iter(v))


seeds = {'17829','21040','11355','19524','45196','45212'}
families = []
for line in (O / 'originals/rhea-directions.tsv').read_text().splitlines()[1:]:
    values = line.split('\t')
    if seeds & set(values):
        families.append(dict(zip(['master', 'left_to_right', 'right_to_left', 'bidirectional'], values)))
unresolved_seeds = seeds - {v for f in families for v in f.values()}
print('unresolved direction seeds', sorted(unresolved_seeds), flush=True)
seed_statements = {NS+s: graph[NS+s] for s in sorted(seeds)}
for s in sorted(unresolved_seeds): print(s, json.dumps(graph[NS+s]), flush=True)
wanted = {NS + value for family in families for value in family.values()} | {NS+s for s in seeds}
while True:
    added = {t['resource'] for u in wanted for t in graph[u]
             if t['resource'] in graph and (t['predicate'] in {NS + x for x in ['side', 'substrates', 'products', 'contains', 'compound', 'reactivePart', 'underlyingChebi', 'replacedBy', 'replaces', 'chebi', 'location']} or t['predicate'].startswith(NS + 'contains'))} - wanted
    if not added:
        break
    wanted |= added
equations = []
for family in families:
    for direction in ['left_to_right', 'right_to_left']:
        uri = NS + family[direction]
        sides = {}
        for role in ['substrates', 'products']:
            side = one(uri, role)
            terms = []
            for t in graph[side]:
                if not t['predicate'].startswith(NS + 'contains') or t['predicate'] == NS + 'contains':
                    continue
                coefficient = t['predicate'][len(NS + 'contains'):]
                compound = one(t['resource'], 'compound')
                terms.append({'coefficient': int(coefficient) if coefficient.isdecimal() else coefficient,
                              'participant': t['resource'], 'compound': compound,
                              'accession': vals(compound, 'accession'), 'name': vals(compound, 'name'),
                              'formula': vals(compound, 'formula'), 'charge': vals(compound, 'charge'),
                              'chebi': vals(compound, 'chebi'), 'underlyingChebi': vals(compound, 'underlyingChebi'),
                              'reactivePart': vals(compound, 'reactivePart'), 'location': vals(t['resource'], 'location')})
            sides[role] = terms
        equations.append({'id': family[direction], 'master': family['master'], 'direction': direction,
                          'equation': vals(uri, 'equation'), 'status': vals(NS + family['master'], 'status'), **sides})
out = {'source_sha256': hashlib.sha256((O / 'originals/rhea.rdf.gz').read_bytes()).hexdigest(),
       'release': (O / 'originals/rhea-release.properties').read_text(), 'description_count': count,
       'seeds': sorted(seeds), 'unresolved_direction_seeds': sorted(unresolved_seeds), 'seed_statements': seed_statements, 'direction_families': families, 'equations': equations,
       'complete_selected_statements': {u: graph[u] for u in sorted(wanted)}}
(O / 'results/rhea-all-bounded-replay.json').write_text(json.dumps(out, indent=2) + '\n')
print('RDF descriptions', count, 'selected statements', len(wanted))
print(json.dumps(families, indent=2))
for e in equations:
    print(e['id'], e['equation'], 'status', e['status'])
