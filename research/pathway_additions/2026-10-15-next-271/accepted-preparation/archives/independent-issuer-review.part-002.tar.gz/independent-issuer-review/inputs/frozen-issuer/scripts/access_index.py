from pathlib import Path
import hashlib,json
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def walk(x,path='$'):
 if isinstance(x,dict):
  yield path,x
  for k,v in x.items():yield from walk(v,path+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):yield from walk(v,path+f'[{i}]')
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
reuses=json.loads((R/'inputs/reused-originals.json').read_text());candidates=[]
for p in sorted((R/'inputs/prior270').rglob('*.json')):
 if 'receipts' not in str(p):continue
 for locator,v in walk(json.loads(p.read_text())):
  if v.get('sha256') and v.get('url'):candidates.append({'container':str(p.relative_to(R)),'container_sha256':sha(p),'json_locator':locator,'receipt':v})
hist=R/'inputs/rhea-ancestry/packet267/context/rhea/263-input-manifest.json'
for locator,v in walk(json.loads(hist.read_text())):
 if v.get('sha256') and v.get('url'):candidates.append({'container':str(hist.relative_to(R)),'container_sha256':sha(hist),'json_locator':locator,'historical_metadata':v})
out=[]
for r in reuses:
 matches=[x for x in candidates if (x.get('receipt') or x.get('historical_metadata'))['sha256']==r['sha256']]
 # Release-properties has exact historical hash/size/version but no HTTP response URL in that older metadata.
 assert matches or r['file']=='rhea-release.properties',r['file']
 out.append({'path':r['path'],'sha256':r['sha256'],'bytes':r['bytes'],'mode':'unchanged historical reuse; no fresh HTTP claim','source_receipts_or_metadata':matches,'limitation':'Release properties historical hash/size and source-version ancestry; an original HTTP response receipt/URL is not asserted.' if not matches else None})
fresh=[]
for name in ['issuer-jobs-fresh','issuer-jobs-network-retry','concrete-followups']:
 p=R/'receipts'/f'{name}.json'
 for i,x in enumerate(json.loads(p.read_text())):fresh.append({'receipt_file':str(p.relative_to(R)),'receipt_sha256':sha(p),'entry':i,**x,'body_classification':('sandbox DNS failure; no response body' if 'path' not in x else 'HTTP error body, not issuing content' if x['status']!=200 else 'successful issuing response; exact content type/identity checked in author audit')})
put('results/issuer-access-and-reuse-index.json',{'current_direct_attempts':fresh,'historical_reuses':out,'scope':'202 direct attempts:99 sandbox DNS failures,102 HTTP200 and1HTTP404. Separate ExPASy web-tool reading receipt is a tool projection, not another downloaded body.25 prior originals reused. Historical Rhea142 metadata is not fresh current-release acquisition.'})
print(len(fresh),'direct attempts;',len(out),'reuses')
