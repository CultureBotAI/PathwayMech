from pathlib import Path
import hashlib,json,shutil
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');S=Path('/private/tmp/pathwaymech-next-271-source-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bs=[]
def copy(p,q):
 q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():shutil.copyfile(p,q)
 assert sha(p)==sha(q);bs.append({'source':str(p),'copy':str(q.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size})
mf={x['path']:x for x in json.loads((S/'artifact-manifest.json').read_text())['files']};names=set()
for x in json.loads((S/'results/native-provenance-index.json').read_text()):
 names.add(x['receipt']);names.update(x.get('original_receipts',[]))
names.update(str(p.relative_to(S)) for p in (S/'inputs/frozen269-NA-provenance').rglob('*') if p.is_file())
for n in sorted(names):assert sha(S/n)==mf[n]['sha256'];copy(S/n,R/'inputs/source'/n)
for version,names in [('268',['artifact-manifest.json','source-copy-bindings.json']),('267',['artifact-manifest.json','input-copy-bindings.json','context-copy-bindings.json','context/rhea/263-input-manifest.json','context/rhea/265-context-input-bindings.json','context/rhea/266-input-copy-bindings.json'])]:
 base=Path('/private/tmp/pathwaymech-next-'+version+'-chemistry');m={x['path']:x for x in json.loads((base/'artifact-manifest.json').read_text())['files']}
 for n in names:
  if n in m:assert sha(base/n)==m[n]['sha256']
  copy(base/n,R/'inputs/rhea-ancestry'/('packet'+version)/n)
copy(Path('/private/tmp/pathwaymech-next-271-ci/actual270-merged-baseline.json'),R/'inputs/root-actual270-merged-baseline.json')
(R/'inputs/provenance-additional-bindings.json').write_text(json.dumps(bs,indent=2)+'\n');print(len(bs))
