from pathlib import Path
import datetime,hashlib,json
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (R/'artifact-manifest.json').exists() and not (R/'freeze-proof.json').exists()
audit=json.loads((R/'results/author-integrity-checks.json').read_text());assert all(x['pass'] for x in audit['checks'])
replay=json.loads((R/'results/deterministic-reproduction.json').read_text());assert all(x['exit_code']==0 for x in replay['commands']) and all(x['byte_identical'] for x in replay['outputs'])
files=[]
for p in sorted(R.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file():files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'schema_version':1,'scope':'Frozen bounded next271 issuer preparation; author analysis only, no independent issuer/authority/graph/maintained acceptance.','inventory_includes_hidden_and_ignored':True,'compressed_scope':'Complete retained pinned Rhea RDF parsed at documented selected scope. Other predecessor context not recursively decoded or globally scientifically reread.','exclusions':['artifact-manifest.json','freeze-proof.json'],'file_count':len(files),'listed_bytes':sum(x['bytes'] for x in files),'files':files}
(R/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(R/'artifact-manifest.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':manifest['listed_bytes'],'author_checks':audit['passed'],'offline_commands':len(replay['commands']),'exact_reproduced_outputs':len(replay['outputs']),'all_owned_handles_terminal':True,'terminal_scope':'Authoritative execution-handle exits and recorded subprocess statuses; optional sandbox ps was unavailable.','frozen':True,'no_further_writes':True}
(R/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert {str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}=={x['path'] for x in files}|set(manifest['exclusions'])
for x in files:assert sha(R/x['path'])==x['sha256'] and (R/x['path']).stat().st_size==x['bytes']
print(json.dumps({'owner':str(R),**proof,'HANDOFF_sha256':sha(R/'HANDOFF.md'),'freeze_sha256':sha(R/'freeze-proof.json')},indent=2))
