from pathlib import Path
import hashlib,json,shutil
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');P=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'artifact-manifest.json')=='d18d6d594d87721ff4e4e53b69a1fecf166b645357d5c571c2604e95e2f9cd2d'
m=json.loads((P/'artifact-manifest.json').read_text());bs=[]
for x in m['files']:assert sha(P/x['path'])==x['sha256'] and (P/x['path']).stat().st_size==x['bytes']
assert {str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
for n in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md','REVIEW.md','RESULT.json','results/independent-claim-dispositions.json','results/independent-primary-reading-scope.json']:
 p=P/n;q=R/'inputs/independent-source-review'/n;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copyfile(p,q);bs.append({'source':str(p),'copy':str(q.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size})
(R/'inputs/independent-source-review-bindings.json').write_text(json.dumps(bs,indent=2)+'\n')
(R/'results/independent-source-review-intake.json').write_text(json.dumps({'manifest_sha256':sha(P/'artifact-manifest.json'),'physical_files_verified':len(m['files'])+2,'no_actionable_findings':True,'disposition':'Qualified independent acceptance of all32 source claims at documented levels; not issuingidentity, maintainedrecord or baseline novelty acceptance. This issuer author also authored source preparation; acceptance is from distinct peer.','source_manifest_sha256':'06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5'},indent=2)+'\n')
print('verified',len(m['files'])+2,'copied',len(bs))
