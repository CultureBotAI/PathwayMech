from pathlib import Path
import collections,hashlib,json,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((R/n).read_text())
def check(name,value,detail=None):
 checks.append({'name':name,'pass':bool(value),'detail':detail});assert value,(name,detail)
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
for name in ['source-bindings','prior270-bindings','additional-context-bindings','provenance-additional-bindings','independent-source-review-bindings']:
 for b in load('inputs/'+name+'.json'):
  p=R/b['copy'];check('copy '+b['copy'],sha(p)==b['sha256'] and p.stat().st_size==b['bytes']);check('unchanged source '+b['source'],sha(Path(b['source']))==b['sha256'])
S=Path('/private/tmp/pathwaymech-next-271-source-preparation');m=json.loads((S/'artifact-manifest.json').read_text());check('source manifest',sha(S/'artifact-manifest.json')=='06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5')
for x in m['files']:check('source final '+x['path'],sha(S/x['path'])==x['sha256'] and (S/x['path']).stat().st_size==x['bytes'])
check('source physical inventory',{str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'})
fail=load('receipts/issuer-jobs-fresh.json');check('99 DNS failures retained',len(fail)==99 and all('path' not in x and 'nodename' in x['error'] for x in fail))
fresh=load('receipts/issuer-jobs-network-retry.json')+load('receipts/concrete-followups.json');check('103 actual HTTP attempts',len(fresh)==103);check('one actual404',[(x['file'],x['status']) for x in fresh if x['status']!=200]==[('KEGG-R00296.txt',404)])
for x in fresh:
 p=R/x['path'];check('HTTP original '+x['file'],sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
 if x['status']!=200:continue
 if x['file'].startswith('ChEBI-'):v=json.loads(p.read_text());check('ChEBI identity '+x['file'],v['chebi_accession']=='CHEBI:'+x['id'] and v['is_released'])
 elif x['file'].startswith('UniProt-'):check('UniProt identity '+x['file'],json.loads(p.read_text())['primaryAccession']==x['id'])
 elif x['file'].startswith('ENA-'):check('ENA identity '+x['file'],p.read_text().startswith('ID   '+x['id']+';'))
 elif x['file'].startswith('KEGG-') and p.suffix=='.txt':check('KEGG identity '+x['file'],p.read_text().startswith('ENTRY       '+p.stem.removeprefix('KEGG-')))
 elif x['file']=='GO-0016020.json':v=json.loads(p.read_text())['results'];check('GO identity',len(v)==1 and v[0]['id']=='GO:0016020' and v[0]['name']=='membrane' and not v[0]['isObsolete'])
reuse=load('inputs/reused-originals.json')
for x in reuse:check('reuseoriginal '+x['path'],sha(R/x['path'])==x['sha256'] and (R/x['path']).stat().st_size==x['bytes'])
check('25 reuse originals',len(reuse)==25)
rows=load('results/all-91-issuer-dispositions.json');check('91 unique objects',len(rows)==len({x['frame'] for x in rows})==91);check('no automatic aliases',not any(x['alias_promoted'] for x in rows))
for x in rows:
 p=R/x['native_path'];o=E.parse(p).getroot();native=[z for z in o if z.tag!='metadata'];check('native own envelope '+x['frame'],len(native)==1 and native[0].get('frameid')==x['frame'] and native[0].get('detail')=='full' and o.findtext('metadata/query')=='META:'+x['frame']);check('native bound '+x['frame'],sha(p)==x['native_sha256'])
allrows=load('results/all-269-identity-scope-dispositions.json');check('178 exclusions',len(allrows)==269 and sum(not x['selected'] for x in allrows)==178);check('474 pointeroccurrences',len(load('results/all-474-selected-pointer-dispositions.json'))==474);check('10 specialslots',len(load('results/non-dblink-public-pointer-occurrences.json'))==10)
chem=load('results/material-issuer-chemistry.json')['rows'];check('41materials sixclasses',len(chem)==41 and sum(x['class'] for x in chem)==6)
for c in chem:
 if c['class']:continue
 check('nativeCML '+c['frame'],c['cml_vs_stereo_removed_inchi_equal']);cs=[x for x in c['issuer_candidates'] if x['issuer']=='CHEBI'];check('concrete directChEBI '+c['frame'],len(cs)==1 and cs[0]['native_inchi_vs_issuer']['same_standard_inchi'])
check('six ChEBISMILES failures',sum(x.get('smiles_import',{}).get('present',False) and not x['smiles_import']['parsed'] for c in chem for x in c['issuer_candidates'] if x['issuer']=='CHEBI')==6)
eq=load('inputs/source/results/member-equations.json');occ=[x for e in eq for side in ['left','right'] for x in e[side]];check('six/29/19',len(eq)==6 and len(occ)==29 and len({x['frame'] for x in occ})==19);check('no materialcompartments',not any(x['compartment'] for x in occ));check('allreversible',all(e['source_direction']=='REVERSIBLE' for e in eq));check('selecteddirections',collections.Counter(e['selected_direction'] for e in eq)=={'L2R':4,'R2L':2});check('reaction ownnamesabsent',all(e['label'] is None for e in eq))
rhea=load('results/rhea-all-bounded-replay.json');check('fullRDF count',rhea['description_count']==326097);check('fivefamilies10directions',len(rhea['direction_families'])==5 and len(rhea['equations'])==10);st=rhea['seed_statements']['http://rdf.rhea-db.org/17829'];check('obsoleteexact',any(x['resource']=='http://rdf.rhea-db.org/Obsolete' for x in st));check('literalreplacement',any(x['literal']=='RHEA:17829 has been replaced by RHEA:21040' for x in st));check('no inventedreplacedBy',not any(x['predicate'].endswith('replacedBy') for x in st))
for f,rid in [('ACETATEKIN-RXN','11353'),('PHOSACETYLTRANS-RXN','19522')]:
 e=next(x for x in eq if x['frame']==f);re=next(x for x in rhea['equations'] if x['id']==rid)
 for side,rs in [('left','substrates'),('right','products')]:
  native=sorted((next(z['id'] for z in next(c for c in chem if c['frame']==x['frame'])['issuer_candidates'] if z['issuer']=='CHEBI'),x['coefficient']) for x in e[side]);iss=sorted((x['accession'][0].removeprefix('CHEBI:'),x['coefficient']) for x in re[rs]);check('exactchargedRhea '+f+' '+side,native==iss and not any(x['location'] for x in re[rs]))
ps=load('results/protein-issuer-comparison.json');check('fiveproteins',len(ps)==5)
for p in ps:check('one fullCDSmatch '+p['id'],sum(x['exact_full_sequence'] and not x['partial'] for x in p['ena_comparisons'])==1);check('species2210 '+p['id'],p['organism']['taxonId']==2210)
partial=[x for p in ps for x in p['ena_comparisons'] if x['partial']];check('16aa partialonly',len(partial)==1 and partial[0]['ena_length']==16 and partial[0]['prefix_equal'] and not partial[0]['exact_full_sequence'])
enas=load('results/ena-complete-feature-replay.json');cds=[x for e in enas for x in e['features'] if x['key']=='CDS'];check('seven translatedCDS includescontextORF',len(cds)==7 and all(x['translation_matches'] for x in cds))
tax=load('results/taxonomy-selected-lineages.json');check('seven pointedtaxa',set(tax)=={'NCBITaxon:'+x for x in ['2207','2208','2210','2214','2222','2224','28890']});org=next(x for x in rows if x['frame']=='ORG-5913');check('nativeTM1 no ownDB',not org['direct_pointer_occurrences'])
qc=load('results/taxonomy-query-receipt.json');p=Path(qc['cache']);check('cache unchanged size/mtime',p.stat().st_size==qc['size'] and p.stat().st_mtime_ns==qc['mtime_ns_after']);check('no14GBrehashclaim',qc['new_full_rehash'] is False)
for x in load('results/runtime-verification.json')['files']:check('runtime unchanged '+x['path'],sha(Path(x['path']))==x['sha256'])
claims=load('inputs/source/results/claim-ledger.json');check('32claims preserved',len(claims)==32)
for c in claims:
 for e in c['evidence']:check('claim evidence '+c['id']+' '+e['path'],sha(R/'inputs/source'/e['path'])==e['sha256'])
for p in R.rglob('*'):check('no symlink '+str(p.relative_to(R)),not p.is_symlink())
put('results/author-integrity-checks.json',{'scope':'Bounded author integrity and semantic invariants; not independent scientific acceptance or maintained corpus gates.','passed':len(checks),'checks':checks});print(len(checks),'author checks passed')
