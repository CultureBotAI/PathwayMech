from pathlib import Path
import hashlib,json,shutil
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');S=Path('/private/tmp/pathwaymech-next-271-source-preparation');P=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation');A=Path('/private/tmp/pathwaymech-next-270-independent-issuer-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
bs=[]
def cp(base,n,dst):
 q=R/dst;q.parent.mkdir(parents=True,exist_ok=True);p=base/n
 if q.exists():assert sha(q)==sha(p)
 else:shutil.copyfile(p,q)
 bs.append({'source':str(p),'copy':str(q.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size})
for c in json.loads((R/'inputs/source/results/claim-ledger.json').read_text()):
 for e in c['evidence']:
  assert sha(S/e['path'])==e['sha256'];cp(S,e['path'],'inputs/source/'+e['path'])
mf={x['path']:x for x in json.loads((P/'artifact-manifest.json').read_text())['files']}
for n in ['inputs/native/META-THMPT.xml','inputs/native/META-METHYL-THMPT.xml','originals/ChEBI-58103.json','originals/ChEBI-58116.json','results/material-issuer-chemistry.json','inputs/copied-input-bindings.json']:
 assert sha(P/n)==mf[n]['sha256'];cp(P,n,'inputs/prior270/'+n)
assert sha(A/'artifact-manifest.json')=='3d2baf4aa3bfbb0cf7278337e7796ea5c6c02c822ced83b7d4bfb6f611573a50';m=json.loads((A/'artifact-manifest.json').read_text())
for x in m['files']:assert sha(A/x['path'])==x['sha256'] and (A/x['path']).stat().st_size==x['bytes']
assert {str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()}=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
for n in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md','REVIEW.md','RESULT.json']:cp(A,n,'inputs/prior270-independent-review/'+n)
put('inputs/additional-context-bindings.json',bs);put('results/prior270-independent-acceptance-intake.json',{'manifest_sha256':sha(A/'artifact-manifest.json'),'physical_verified':len(m['files'])+2,'scope':'Prior270 issuer review accepted with stated limits. Reuse is exact selected bytes; this author task is not its own independent review.'})
print('bindings',len(bs),'priorreviewfiles',len(m['files'])+2)
