from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');P='/private/tmp/pathwaymech-next-263-verified-venv/bin/python';D='/private/tmp/npmech-rdkit-2026.03.5/bin/python3.13'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
groups=[('chemistry.py',D,['results/material-issuer-chemistry.json']),('followup_chemistry.py',D,['results/structure-distinction-followups.json']),('proteins.py',P,['results/ena-complete-feature-replay.json','results/protein-issuer-comparison.json','reading/selected-native-biological-slots.json']),('rhea_all_bounded.py',P,['results/rhea-all-bounded-replay.json']),('taxonomy.py',P,['results/taxonomy-complete-selected-statements.json','results/taxonomy-selected-lineages.json']),('dispositions.py',P,['results/all-91-issuer-dispositions.json','results/all-474-selected-pointer-dispositions.json','results/non-dblink-public-pointer-occurrences.json','results/identity-coverage-summary.json']),('access_index.py',P,['results/issuer-access-and-reuse-index.json'])]
files=[n for _,_,ns in groups for n in ns];before={n:sha(R/n) for n in files};keep=R/'iterations/offline-before';keep.mkdir(parents=True,exist_ok=False)
for n in files+['results/taxonomy-query-receipt.json']:
 q=keep/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,q)
env={**os.environ,'RDBASE':'/private/tmp/npmech-rdkit-2026.03.5/share/RDKit','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'};commands=[]
for name,python,ns in groups:
 cmd=[python,'-B',str(R/'scripts'/name)];stem=name.removesuffix('.py');start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (R/'receipts'/('offline-'+stem+'.stdout')).open('w') as out,(R/'receipts'/('offline-'+stem+'.stderr')).open('w') as err:cp=subprocess.run(cmd,stdout=out,stderr=err,env=env,cwd=R)
 commands.append({'argv':cmd,'exit_code':cp.returncode,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});assert cp.returncode==0,name
 for n in ns:assert sha(R/n)==before[n],n
 print(stem,'exact',len(ns),flush=True)
receipt={'commands':commands,'outputs':[{'path':n,'sha256_before':before[n],'sha256_after':sha(R/n),'byte_identical':True} for n in files],'taxonomy_receipt_scope':'New actual UTC receipt retained; selected statements and lineage outputs byte-identical. Initial query receipt preserved under iterations/offline-before. Cache was not fully rehashed.','network':False,'scientific_scope':'Deterministic author analyses, not independent acceptance.'}
(R/'results/deterministic-reproduction.json').write_text(json.dumps(receipt,indent=2)+'\n')
