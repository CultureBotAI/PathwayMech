from pathlib import Path
import hashlib,json,shutil
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
P=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
assert sha(P/'artifact-manifest.json')=='dfc7cef1e269d870034b347abb99af7dd473f434cd487a2083105bb7f439e851'
mf={x['path']:x for x in json.loads((P/'artifact-manifest.json').read_text())['files']}
bindings=[]
def cp(n,dst):
 p=P/n;q=R/dst;q.parent.mkdir(parents=True,exist_ok=True)
 if n in mf:assert sha(p)==mf[n]['sha256'] and p.stat().st_size==mf[n]['bytes']
 assert not q.exists();shutil.copyfile(p,q)
 bindings.append({'source':str(p),'copy':dst,'bytes':q.stat().st_size,'sha256':sha(q),'manifest_member':n in mf})
for n in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md','ASSESSMENT.md','READING-SCOPES.md','inputs/reused-issuing-originals.json','inputs/reused-acquisition-receipt-bindings.json','inputs/prior/rdkit-runtime-binding.json','results/taxonomy-query-receipt.json']:
 cp(n,'inputs/prior270/'+n)
for base in ['receipts','inputs/reused-acquisition-receipts','inputs/prior/taxon-review']:
 for p in sorted((P/base).rglob('*')):
  if p.is_file():cp(str(p.relative_to(P)),'inputs/prior270/'+str(p.relative_to(P)))
ptr=[x for x in json.loads((R/'results/direct-public-pointer-inventory.json').read_text()) if x['selected_owner'] and x['relationship'] in ('unification','PART-OF')]
jobs=[]
for db,pattern,prefix,suffix in [('CHEBI','https://www.ebi.ac.uk/chebi/backend/api/public/compound/{}/','ChEBI-','.json'),('LIGAND-CPD','https://rest.kegg.jp/get/cpd:{}','KEGG-','.txt'),('LIGAND-RXN','https://rest.kegg.jp/get/rn:{}','KEGG-','.txt'),('UNIPROT','https://rest.uniprot.org/uniprotkb/{}.json','UniProt-','.json'),('ENTREZ','https://www.ebi.ac.uk/ena/browser/api/embl/{}?download=false','ENA-','.embl')]:
 for id in sorted({x['id'] for x in ptr if x['db']==db}):
  occurrences=[x for x in ptr if x['db']==db and x['id']==id]
  jobs.append({'url':pattern.format(id),'file':prefix+id+suffix,'issuer':db,'id':id,'native_occurrences':occurrences})
for id in sorted({x['id'] for x in ptr if x['db']=='LIGAND-CPD'}-{'C06021','C00138','C00139'}):
 jobs.append({'url':f'https://rest.kegg.jp/get/{id}/mol','file':f'KEGG-{id}.mol','issuer':'KEGG structural original','id':id,'native_occurrences':[x for x in ptr if x['db']=='LIGAND-CPD' and x['id']==id]})
for id in ['2.7.2.15','2.7.2.1']:
 jobs.append({'url':f'https://enzyme.expasy.org/EC/{id}','file':f'EC-{id}.html','issuer':'ExPASy ENZYME','id':id,'scope':'Resolve exact native ACETATEKIN-RXN EC annotation and acetate comparator; not a protein identity search'})
alljobs=list(jobs);fresh=[];reuse=[]
for j in jobs:
 n='originals/'+j['file']
 if n in mf:
  cp(n,n);reuse.append({**j,'path':n,'bytes':(R/n).stat().st_size,'sha256':sha(R/n),'original_packet_manifest_sha256':sha(P/'artifact-manifest.json'),'fresh_acquisition':False,'provenance':'Retained prior270 receipt containers and reused-original ancestry; exact matching native own pointer occurrences listed here.'})
 else:fresh.append(j)
for name in ['rhea.rdf.gz','rhea-directions.tsv','rhea-release.properties']:
 n='originals/'+name;cp(n,n);reuse.append({'file':name,'path':n,'sha256':sha(R/n),'bytes':(R/n).stat().st_size,'fresh_acquisition':False,'scope':'Pinned release142 complete RDF/directions used for exact native seeds17829,11355,19524; no current-release claim','native_occurrences':[x for x in ptr if x['db']=='RHEA']})
runtime=json.loads((R/'inputs/prior270/inputs/prior/rdkit-runtime-binding.json').read_text())['binding']['files']
for x in runtime:assert sha(Path(x['path']))==x['sha256'] and Path(x['path']).stat().st_size==x['bytes']
put('results/runtime-verification.json',{'files':runtime,'verified_count':len(runtime),'fresh_sha256_checks':True,'runtime_unchanged':True})
put('inputs/prior270-bindings.json',bindings);put('inputs/issuer-jobs-all.json',alljobs);put('inputs/issuer-jobs-fresh.json',fresh);put('inputs/reused-originals.json',reuse)
print(json.dumps({'fresh_jobs':len(fresh),'reused_originals':len(reuse),'runtime_files':len(runtime),'prior_provenance_files':len(bindings)},indent=2))
