from pathlib import Path
import collections,hashlib,json,re,xml.etree.ElementTree as E
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors as D
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
def details(m):return {'formula':D.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'inchi':Chem.MolToInchi(m),'key':Chem.MolToInchiKey(m)}
rows={x['frame']:x for x in json.loads((R/'results/material-issuer-chemistry.json').read_text())['rows']};pairs=[]
for a,b in [('CPD-8','THMPT'),('CPD-9','METHYL-THMPT')]:
 p=R/'inputs/prior270/inputs/native'/('META-'+b+'.xml');o=next(x for x in E.parse(p).getroot() if x.tag!='metadata');am=Chem.MolFromInchi(rows[a]['native_inchi']);bm=Chem.MolFromInchi(o.findtext('inchi'));assert am and bm
 pairs.append({'current_native':a,'current_sha256':rows[a]['sha256'],'comparison_native':b,'comparison_path':str(p.relative_to(R)),'comparison_sha256':sha(p),'current':details(am),'comparison':details(bm),'standard_inchi_equal':Chem.MolToInchi(am)==Chem.MolToInchi(bm),'scope':'Different carbon/nitrogen/oxygen skeleton and charge; nativeSPT comment attributes extra glutamyl residue. Exact retained270 comparison, not fresh source and not pathway substitution.'})
p=R/'originals/KEGG-C00009.mol';m=Chem.MolFromMolBlock(p.read_text());assert m;pi=Chem.MolFromInchi(rows['Pi']['native_inchi']);phosphate={'path':str(p.relative_to(R)),'sha256':sha(p),'KEGG':details(m),'native_Pi':details(pi),'same_inchi':Chem.MolToInchi(m)==Chem.MolToInchi(pi)}
balances=[]
for e in json.loads((R/'inputs/source/results/member-equations.json').read_text()):
 unknown=[x['frame'] for side in ['left','right'] for x in e[side] if rows[x['frame']]['class']];delta=collections.Counter();charge=0
 for side,sign in [('left',-1),('right',1)]:
  for x in e[side]:
   n=rows[x['frame']]
   if n['class']:continue
   d=n['native_inchi_import']['details'];coef=sign*x['coefficient'];charge+=coef*d['charge']
   for element,num in re.findall(r'([A-Z][a-z]?)(\d*)',d['formula']):delta[element]+=coef*int(num or'1')
 balances.append({'reaction':e['frame'],'unknown_generic_terms':unknown,'known_element_delta':{k:v for k,v in sorted(delta.items()) if v},'known_charge_delta':charge,'complete_balance':not any(delta.values()) and charge==0 if not unknown else None,'scope':'Only own left/right coefficient equation; unknown generic terms prevent a full molecular balance. Partial residual is not a full imbalance or flux assertion.'})
put('results/structure-distinction-followups.json',{'rdkit':rdBase.rdkitVersion,'sarcinapterin_vs_methanopterin':pairs,'reaction_phosphate_endpoint':phosphate,'native_equation_balances':balances})
print(json.dumps({'pairs':[(x['current_native'],x['current']['formula'],x['comparison']['formula']) for x in pairs],'phosphate':phosphate,'balances':balances},indent=2))
