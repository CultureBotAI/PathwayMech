from pathlib import Path
import hashlib,json,xml.etree.ElementTree as E
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors as D
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def details(m):
 return {'formula':D.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'atoms':m.GetNumAtoms(),'bonds':m.GetNumBonds(),'standard_inchi':Chem.MolToInchi(m),'key':Chem.MolToInchiKey(m),'isomeric_smiles':Chem.MolToSmiles(m,isomericSmiles=True),'tetrahedral_centres':Chem.FindMolChiralCenters(m,includeUnassigned=True)}
def parse(fn,s):
 if not s:return None,{'present':False,'parsed':False}
 try:
  m=fn(s)
  return m,{'present':True,'parsed':m is not None,'details':details(m) if m is not None else None}
 except Exception as ex:return None,{'present':True,'parsed':False,'error':str(ex)}
def compare(a,b):
 if a is None or b is None:return {'possible':False}
 def iso(st):return a.GetNumAtoms()==b.GetNumAtoms() and a.GetNumBonds()==b.GetNumBonds() and a.HasSubstructMatch(b,useChirality=st) and b.HasSubstructMatch(a,useChirality=st)
 return {'possible':True,'same_formula_charge':(D.CalcMolFormula(a),Chem.GetFormalCharge(a))==(D.CalcMolFormula(b),Chem.GetFormalCharge(b)),'same_standard_inchi':Chem.MolToInchi(a)==Chem.MolToInchi(b),'isomorphic_with_stereo':iso(True),'isomorphic_without_stereo':iso(False)}
def cmlparse(c):
 if c is None:return None,{'present':False,'parsed':False}
 try:
  rw=Chem.RWMol();ix={}
  for a in c.findall('atomArray/atom'):
   element=a.get('elementType');atom=Chem.Atom(0) if element=='R' else Chem.Atom(element.title());atom.SetFormalCharge(int(a.get('formalCharge','0')));ix[a.get('id')]=rw.AddAtom(atom)
  for b in c.findall('bondArray/bond'):
   a,z=(b.get('atomRefs') or b.get('atomRefs2')).split();rw.AddBond(ix[a],ix[z],{'1':Chem.BondType.SINGLE,'2':Chem.BondType.DOUBLE,'3':Chem.BondType.TRIPLE,'A':Chem.BondType.AROMATIC}[b.get('order')])
  m=rw.GetMol();Chem.SanitizeMol(m)
  return m,{'present':True,'parsed':True,'details':details(m),'stereo_scope':'Connectivity/atom charges only; drawing wedges and coordinates not interpreted. InChI separately supplies stereo.'}
 except Exception as ex:return None,{'present':True,'parsed':False,'error':str(ex)}
scope=json.loads((R/'results/all-269-identity-scope-dispositions.json').read_text());rows=[]
for n in scope:
 if not n['selected'] or not (n['type']=='Compound' or n['type']=='Protein' and n['class']):continue
 f=n['frame'];p=R/'inputs/source/originals/native'/('META-'+f+'.xml');o=next(x for x in E.parse(p).getroot() if x.tag!='metadata');c=o.find('cml/molecule')
 ns=o.findtext("cml/molecule/string[@title='smiles']");ni=o.findtext('inchi');nm,np=parse(Chem.MolFromInchi,ni);sm,sp=parse(Chem.MolFromSmiles,ns);cm,cp=cmlparse(c)
 row={'frame':f,'type':o.tag,'class':n['class'],'label':n['label'],'roles':n['roles'],'path':str(p.relative_to(R)),'sha256':sha(p),'native_inchi':ni,'native_smiles':ns,'native_key':o.findtext('inchi-key'),'native_cml_formula':c.find('formula').get('concise') if c is not None and c.find('formula') is not None else None,'native_cml_charge':c.get('formalCharge') if c is not None else None,'native_inchi_import':np,'native_smiles_import':sp,'native_cml_import':cp,'native_inchi_vs_smiles':compare(nm,sm),'native_inchi_vs_cml_connectivity':compare(nm,cm),'issuer_candidates':[]}
 if nm and cm:
  u=Chem.Mol(nm);Chem.RemoveStereochemistry(u);row['cml_vs_stereo_removed_inchi_equal']=Chem.MolToInchi(cm)==Chem.MolToInchi(u)
 for i,d in enumerate(o.findall('dblink'),1):
  db=d.findtext('dblink-db');id=d.findtext('dblink-oid')
  if db not in ('CHEBI','LIGAND-CPD'):continue
  q=R/'originals'/f"{'ChEBI' if db=='CHEBI' else 'KEGG'}-{id}{'.json' if db=='CHEBI' else '.txt'}"
  z={'issuer':db,'id':id,'native_locator':f"/ptools-xml/{o.tag}[@frameid='{f}']/dblink[{i}]",'path':str(q.relative_to(R)),'sha256':sha(q),'bytes':q.stat().st_size}
  if db=='CHEBI':
   try:
    v=json.loads(q.read_text());assert v['chebi_accession']=='CHEBI:'+id and v['is_released'];st=v.get('default_structure') or {};im,ip=parse(Chem.MolFromInchi,st.get('standard_inchi'));ss,ssp=parse(Chem.MolFromSmiles,st.get('smiles'))
    z.update(name=v['name'],definition=v.get('definition'),chemical_data=v.get('chemical_data'),structure=st,ontology_relations=v.get('ontology_relations'),inchi_import=ip,smiles_import=ssp,issuing_inchi_vs_smiles=compare(im,ss),native_inchi_vs_issuer=compare(nm,im),native_cml_vs_issuer_connectivity=compare(cm,im))
   except Exception as ex:z['identity_or_parse_failure']=str(ex)
  else:
   text=q.read_text();z['entry_text']=text;z['identity_present']=text.startswith('ENTRY       '+id)
   m=R/'originals'/f'KEGG-{id}.mol'
   if m.exists():
    im,ip=parse(Chem.MolFromMolBlock,m.read_text());z.update(mol_path=str(m.relative_to(R)),mol_sha256=sha(m),mol_import=ip,native_inchi_vs_issuer=compare(nm,im),native_cml_vs_issuer_connectivity=compare(cm,im))
   else:z['mol_scope']='No structure requested for generic class; no exact molecular inference.'
  z['class_guard']='Native class remains generic even if issuer supplies a representative structure.' if n['class'] else 'Exact identity not inferred from label/xref alone; see charge/stereo/representation comparisons.'
  row['issuer_candidates'].append(z)
 rows.append(row)
assert len(rows)==41
(R/'results/material-issuer-chemistry.json').write_text(json.dumps({'rdkit':rdBase.rdkitVersion,'scope':'All41 selected native material identities; no automatic alias approval. Formula/charge/stereo and parser failures are explicit. CML stereo is not interpreted.','rows':rows},indent=2,ensure_ascii=False)+'\n')
for r in rows:print(r['frame'],'class' if r['class'] else 'molecule',r['native_inchi_import'].get('details',{}).get('formula'), 'CML',r.get('cml_vs_stereo_removed_inchi_equal'),'SMILES',r['native_inchi_vs_smiles'],[(x['issuer'],x['id'],x.get('native_inchi_vs_issuer'),x.get('identity_or_parse_failure')) for x in r['issuer_candidates']])
