from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
code=dict(zip((a+b+c for a in 'TCAG' for b in 'TCAG' for c in 'TCAG'),'FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'))
entries=[]
for p in sorted((R/'originals').glob('ENA-*.embl')):
 text=p.read_text();seq=''.join(re.findall('[acgt]+','\n'.join(text.split('\nSQ   ',1)[1].splitlines()[1:]))).upper();blocks=[]
 for line in text.splitlines():
  if not line.startswith('FT'):continue
  key=line[5:21].strip();value=line[21:].strip()
  if key:blocks.append({'key':key,'location':value,'raw_qualifiers':[]})
  elif blocks:blocks[-1]['raw_qualifiers'].append(value)
 for b in blocks:
  qs={};current=None
  for line in b['raw_qualifiers']:
   if line.startswith('/'):
    kv=line[1:].split('=',1);current=kv[0];qs.setdefault(current,[]).append(kv[1] if len(kv)>1 else '')
   elif current:qs[current][-1]+=' '+line
  qs={k:[v.strip('"') for v in vs] for k,vs in qs.items()};b['qualifiers']=qs
  if b['key']=='CDS':
   assert qs.get('transl_table',['11'])==['11'];m=re.fullmatch(r'(<?)(\d+)\.\.(>?)(\d+)',b['location']);assert m,b
   start,end=int(m[2]),int(m[4]);dna=seq[start-1:end];translation=''.join(code[dna[i:i+3]] for i in range(0,len(dna)-2,3));partial=bool(m[1] or m[3]);reported=''.join(qs.get('translation',[''])[0].split())
   if not m[1] and dna[:3] in ['TTG','CTG','ATT','ATC','ATA','ATG','GTG']:translation='M'+translation[1:]
   if translation.endswith('*'):translation=translation[:-1]
   b.update(dna_sha256=hashlib.sha256(dna.encode()).hexdigest(),dna_length=len(dna),translation_replayed=translation,translation_reported=reported,translation_matches=translation==reported,partial_cds=partial,translation_scope='Table11, exact simple interval, first-codon initiator M for complete5primeCDS, terminal stop removed; partial3prime retained.')
   assert translation==reported,(p,b['location'])
 entries.append({'accession':p.stem.removeprefix('ENA-'),'path':str(p.relative_to(R)),'sha256':sha(p),'header_lines':[x for x in text.splitlines() if x[:2] in ['ID','AC','DT','DE','OS','OC','RX','RT','RL']],'nucleotide_length':len(seq),'features':blocks})
proteins=[]
for p in sorted((R/'originals').glob('UniProt-*.json')):
 x=json.loads(p.read_text());id=p.stem.removeprefix('UniProt-');assert x['primaryAccession']==id
 matches=[]
 for en in entries:
  for b in en['features']:
   if b['key']!='CDS':continue
   if any(v.endswith(':'+id) for v in b['qualifiers'].get('db_xref',[])):
    s=b['translation_replayed'];u=x['sequence']['value'];diff=[{'position':i+1,'ENA':a,'UniProt':c} for i,(a,c) in enumerate(zip(s,u)) if a!=c]
    matches.append({'accession':en['accession'],'ena_path':en['path'],'ena_sha256':en['sha256'],'source_feature':next(z['qualifiers'] for z in en['features'] if z['key']=='source'),'location':b['location'],'protein_id':b['qualifiers']['protein_id'],'gene':b['qualifiers'].get('gene'),'product':b['qualifiers'].get('product'),'partial':b['partial_cds'],'ena_length':len(s),'uniprot_length':len(u),'exact_full_sequence':s==u,'prefix_equal':u.startswith(s),'aligned_differences':diff,'difference_scope':'Positionwise comparison only; length differences retained. A partial-CDS prefix match is not full identity.'})
 proteins.append({'id':id,'path':str(p.relative_to(R)),'sha256':sha(p),'organism':x['organism'],'organismHosts':x.get('organismHosts'),'proteinDescription':x['proteinDescription'],'genes':x.get('genes'),'entryAudit':x['entryAudit'],'proteinExistence':x.get('proteinExistence'),'sequence':x['sequence'],'comments':x.get('comments'),'features':x.get('features'),'references':x.get('references'),'uniProtKBCrossReferences':x.get('uniProtKBCrossReferences'),'ena_comparisons':matches,'scope':'Issuer annotation and sequence, not newly read primary experiments; retain evidence codes and paper access limitations.'})
scope=json.loads((R/'results/all-269-identity-scope-dispositions.json').read_text());native=[]
for n in scope:
 if not n['selected'] or n['type'] not in ['Protein','Gene','Enzymatic-Reaction','Regulation','Organism','cco']:continue
 p=R/'inputs/source/originals/native'/('META-'+n['frame']+'.xml');o=next(x for x in E.parse(p).getroot() if x.tag!='metadata')
 slots=[]
 for i,s in enumerate(o):
  if s.tag in ['credits','citation']:continue
  slots.append({'tag':s.tag,'locator':f"/ptools-xml/{o.tag}[@frameid='{n['frame']}']/{s.tag}[{len([x for x in list(o)[:i+1] if x.tag==s.tag])}]",'xml':E.tostring(s,encoding='unicode')})
 native.append({**n,'path':str(p.relative_to(R)),'sha256':sha(p),'slots':slots})
put('results/ena-complete-feature-replay.json',entries);put('results/protein-issuer-comparison.json',proteins);put('reading/selected-native-biological-slots.json',native)
for p in proteins:print(p['id'],[(x['accession'],x['protein_id'],x['ena_length'],x['uniprot_length'],x['exact_full_sequence'],x['prefix_equal'],x['aligned_differences']) for x in p['ena_comparisons']])
