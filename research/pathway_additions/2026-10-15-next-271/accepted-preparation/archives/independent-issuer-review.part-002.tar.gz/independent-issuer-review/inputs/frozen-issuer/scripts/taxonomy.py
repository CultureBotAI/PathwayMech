from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sqlite3
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');C=Path('/private/tmp/pathwaymech-curation-authorities/ncbitaxon.db')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
prior=json.loads((R/'inputs/prior270/results/taxonomy-query-receipt.json').read_text());before=C.stat()
assert before.st_size==prior['size'] and before.st_mtime_ns==prior['mtime_ns_after']
db=sqlite3.connect(C.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
def query(t):return [dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(t,))]
old=json.loads((R/'inputs/prior270/inputs/prior/taxon-review/independent-taxonomy-rows.json').read_text());controls={}
for t,rs in old.items():assert query(t)==rs;controls[t]={'rows':len(rs),'equal':True}
ptr=json.loads((R/'results/direct-public-pointer-inventory.json').read_text());ids={x['id'] for x in ptr if x['selected_owner'] and x['db']=='NCBI-TAXONOMY-DB' and x['relationship']=='unification'}
for p in (R/'originals').glob('UniProt-*.json'):ids.add(str(json.loads(p.read_text())['organism']['taxonId']))
rows={};lineages={}
for id in sorted(ids):
 t='NCBITaxon:'+id;rows[t]=query(t);chain=[];seen=set();cur=t
 while cur not in seen:
  seen.add(cur);rs=query(cur);label=[x['value'] for x in rs if x['predicate']=='rdfs:label'];parent=[x['object'] for x in rs if x['predicate']=='rdfs:subClassOf'];rank=[x['object'] for x in rs if x['predicate']=='obo:ncbitaxon#has_rank'];chain.append({'id':cur,'label':label,'parent':parent,'rank':rank})
  if len(parent)!=1 or parent[0] in seen:break
  cur=parent[0]
 lineages[t]=chain
metadata=[dict(x) for x in db.execute("select * from statements where predicate in ('owl:versionIRI','owl:versionInfo','dcterms:license')")];db.close();after=C.stat();assert before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns
put('results/taxonomy-complete-selected-statements.json',rows);put('results/taxonomy-selected-lineages.json',lineages);put('results/taxonomy-query-receipt.json',{'cache':str(C),'mode':'ro&immutable=1','whole_cache_hash_reused':prior['prior_full_hash_evidence'],'new_full_rehash':False,'prior_receipt_sha256':sha(R/'inputs/prior270/results/taxonomy-query-receipt.json'),'size':before.st_size,'mtime_ns_before':before.st_mtime_ns,'mtime_ns_after':after.st_mtime_ns,'same_mtime_as_prior_accepted_query':True,'nine_prior_statement_set_controls':controls,'metadata':metadata,'queried_ids':sorted(ids),'utc':datetime.now(timezone.utc).isoformat(),'scope':'Six pointed direct taxa and one range. ORG-5913 has no own public pointer and is not silently assigned a taxon. Protein and two ENA originals all name2210; TM-1 source-strain spelling is retained separately.'})
for t,c in lineages.items():print(t,c[0])
