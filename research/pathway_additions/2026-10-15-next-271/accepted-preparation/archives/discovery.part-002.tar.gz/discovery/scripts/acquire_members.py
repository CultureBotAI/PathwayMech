from pathlib import Path
import urllib.request,json,hashlib,datetime,sys
R=Path('/private/tmp/pathwaymech-next-271-discovery')
for fid in ['1.2.7.4-RXN','RXN-12908','ACETYLSYNCLTH-RXN','MTRMBARK-RXN','PHOSACETYLTRANS-RXN','ACETATEKIN-RXN']:
 url='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+fid
 receipt={'id':fid,'url':url,'attempt':sys.argv[1],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=40) as h: raw=h.read(); receipt.update(status=h.status,final_url=h.url,headers=dict(h.headers))
  dst=R/'originals'/('META-'+fid+'.xml'); assert not dst.exists();dst.write_bytes(raw)
  receipt.update(path=str(dst.relative_to(R)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 except Exception as e: receipt['error']=repr(e)
 (R/'receipts'/('member-'+fid+'-'+sys.argv[1]+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(fid,receipt.get('status'),receipt.get('error'),flush=True)
