from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT = Path('/private/tmp/pathwaymech-next-271-discovery')
EXCLUDED = {'artifact-manifest.json', 'freeze-proof.json'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def files():
    paths = sorted(ROOT.rglob('*'))
    assert not any(path.is_symlink() for path in paths), 'Symlink in packet'
    return [p for p in paths if p.is_file()]

def verify():
    manifest = json.loads((ROOT / 'artifact-manifest.json').read_text())
    observed = {p.relative_to(ROOT).as_posix() for p in files()}
    expected = {row['path'] for row in manifest['files']} | EXCLUDED
    assert observed == expected, (observed - expected, expected - observed)
    for row in manifest['files']:
        body = (ROOT / row['path']).read_bytes()
        assert len(body) == row['bytes'] and sha(body) == row['sha256'], row['path']
    proof = json.loads((ROOT / 'freeze-proof.json').read_text())
    assert sha((ROOT / 'artifact-manifest.json').read_bytes()) == proof['manifest_sha256']
    assert sha((ROOT / 'HANDOFF.md').read_bytes()) == proof['HANDOFF_sha256']
    assert len(observed) == proof['physical_files']
    return proof

if '--verify-only' not in sys.argv:
    assert not any((ROOT / x).exists() for x in EXCLUDED), 'Frozen proof already exists'
    entries = []
    for path in files():
        rel = path.relative_to(ROOT).as_posix()
        if rel in EXCLUDED:
            continue
        body = path.read_bytes()
        entries.append({'path': rel, 'bytes': len(body), 'sha256': sha(body)})
    manifest = {'owner': str(ROOT), 'files': entries, 'self_excluded': sorted(EXCLUDED)}
    (ROOT / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    proof = {
        'owner': str(ROOT),
        'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'listed_files': len(entries),
        'physical_files': len(entries) + 2,
        'listed_bytes': sum(row['bytes'] for row in entries),
        'manifest_sha256': sha((ROOT / 'artifact-manifest.json').read_bytes()),
        'HANDOFF_sha256': sha((ROOT / 'HANDOFF.md').read_bytes()),
        'ASSESSMENT_sha256': sha((ROOT / 'ASSESSMENT.md').read_bytes()),
        'self_excluded': sorted(EXCLUDED),
        'jobs': 'All owned acquisition, search and finalization jobs are terminal; initial interrupted search retained.',
        'claim': 'Frozen bounded author discovery/preflight only; no independent acceptance, global novelty, or maintained curation.',
        'baseline': 'e8ae5e445d3288717c31d3012611e226fd5cca34',
        'pending': 'Actual next270 merge rebind and complete source/issuer/primary closure.'
    }
    (ROOT / 'freeze-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
proof = verify()
print(json.dumps({**proof, 'freeze_sha256': sha((ROOT / 'freeze-proof.json').read_bytes()), 'verification': 'passed'}, indent=2))
