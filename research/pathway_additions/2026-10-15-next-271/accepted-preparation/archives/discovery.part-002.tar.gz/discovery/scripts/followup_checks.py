from pathlib import Path
import hashlib,json,subprocess,shutil,xml.etree.ElementTree as E,re
R=Path('/private/tmp/pathwaymech-next-271-discovery');W=Path('/private/tmp/pathwaymech-next-270-20261015');O=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech');H='e8ae5e445d3288717c31d3012611e226fd5cca34'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):(R/'results'/n).write_text(json.dumps(o,indent=2)+'\n')
P=Path('/private/tmp/pathwaymech-next-271-primary-boundary-probe');assert sha((P/'MANIFEST.json').read_bytes())=='7b51faa16826e3c75ac893ae2c50965f747571218eaf93854ac7de81a0433580';m=json.loads((P/'MANIFEST.json').read_text());checks=[]
for f in m['files']: assert sha((P/f['path']).read_bytes())==f['sha256']
for p in sorted(P.rglob('*')):
 if p.is_file():
  rel=str(p.relative_to(P));dst=R/'inputs/author-primary-probe'/rel;dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copyfile(p,dst);checks.append({'source':str(p),'copy':str(dst.relative_to(R)),'sha256':sha(p.read_bytes())})
put('author-primary-probe-intake.json',{'files':checks,'scope':'Mechanical retention and bounded reading by parent author; this delegated probe is author evidence, not an independent scientific acceptance. Raw PDF attempts failed; retained publisher extraction is not original PDF bytes.'})
patterns=['MetaCyc:CPD-8','MetaCyc:CPD-9','CHEBI:59924','CHEBI:64267','tetrahydrosarcinapterin','RHEA:11352','RHEA:11353','RHEA:11354','RHEA:19521','RHEA:19522','RHEA:19523','WikiPathways:WP5019','EC:2.7.2.15','EC:2.7.2.1','EC:2.3.1.8','2571608','8824151']
for p in (P/'inputs').glob('pmid-*.json'):
 d=json.loads(p.read_text())['resultList']['result'][0]
 if d.get('doi'):patterns.append(d['doi'])
pat=R/'results/followup-search-patterns.txt';pat.write_text('\n'.join(patterns)+'\n')
for tag,base in [('pending270-worktree',W),('original-checkout',O)]:
 cmd=['rg','--no-ignore','--hidden','-i','-F','--files-with-matches','-f',str(pat),'-g','!.git/**','-g','!.venv/**','.'];q=subprocess.run(cmd,cwd=base,capture_output=True,text=True);assert q.returncode in (0,1);hits=[]
 for line in q.stdout.splitlines():
  p=base/line;b=p.read_bytes();s=b.decode('utf8',errors='replace');lo=s.lower();matches=[]
  for patn in patterns:
   pos=lo.find(patn.lower())
   if pos>=0:matches.append({'pattern':patn,'first_context':s[max(0,pos-130):pos+len(patn)+200]})
  hits.append({'path':str(p.relative_to(base)),'bytes':len(b),'sha256':sha(b),'matches':matches})
 put('followup-ordinary-search-'+tag+'.json',{'command':cmd,'returncode':q.returncode,'stderr':q.stderr,'files':hits,'scope':'All matching ordinary text including hidden/ignored; .git/.venv and binary/container interiors excluded. First context per pattern retained, not a full-reading claim. Source snapshots and prior reports are mentions, not automatically maintained declarations.'})
 print(tag,len(hits),flush=True)
# Copy unchanged accepted snapshots to permit exact coverage replay, not an issuer update.
coverage=[]
for name in ['sources.json','ontology.json']:
 rel='data/identifier_authorities/'+name;b=subprocess.check_output(['git','show',H+':'+rel],cwd=W);dst=R/'inputs/landed266'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);d=json.loads(b)
 wanted=['MetaCyc:METH-ACETATE-PWY',*['MetaCyc:'+r['id'] for r in json.loads((R/'results/native-six-reactions.json').read_text())],*['MetaCyc:'+i for i in json.loads((R/'results/candidate-native-boundary.json').read_text())['equation_material_ids']],*['NCBITaxon:'+str(i) for i in [2207,2214,2208,2210,2222,2224,28890]]]
 coverage.append({'snapshot':rel,'sha256':sha(b),'source_metadata':d['sources'],'terms':{i:d['terms'].get(i) for i in wanted},'limit':'Exact current pinned snapshot coverage only. A missing snapshot row is not an invalid upstream ID; no new issuer acceptance or taxon alias inferred.'})
put('landed-authority-coverage.json',coverage)
print('complete')
