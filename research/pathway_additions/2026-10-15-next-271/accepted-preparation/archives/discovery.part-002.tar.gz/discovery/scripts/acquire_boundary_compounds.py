from pathlib import Path
import urllib.request,hashlib,json,datetime
R=Path('/private/tmp/pathwaymech-next-271-discovery')
for fid in ['CPD-8','CPD-9']:
 url='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+fid;r={'id':fid,'url':url,'purpose':'Bounded exact sarcinapterin versus pending270 methanopterin identity comparison','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(url,timeout=40) as h: b=h.read();r.update(status=h.status,final_url=h.url,headers=dict(h.headers))
  p=R/'originals'/('META-'+fid+'.xml');assert not p.exists();p.write_bytes(b);r.update(path=str(p.relative_to(R)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r['error']=repr(e)
 (R/'receipts'/('boundary-'+fid+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(fid,r.get('status'),r.get('error'),flush=True)
