from pathlib import Path
import hashlib,json,subprocess,shutil,datetime
R=Path('/private/tmp/pathwaymech-next-271-discovery')
WORK=Path('/private/tmp/pathwaymech-next-270-20261015')
B=Path('/private/tmp/pathwaymech-next-270-native-authority-implementation/baseline')
HEAD='e8ae5e445d3288717c31d3012611e226fd5cca34'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def put(rel,obj): (R/rel).write_text(json.dumps(obj,indent=2)+'\n')
bindings=[]
def cp(src,rel):
 raw=src.read_bytes(); dst=R/rel; dst.parent.mkdir(parents=True,exist_ok=True); assert not dst.exists(); dst.write_bytes(raw); bindings.append({'source':str(src),'copy':rel,'bytes':len(raw),'sha256':sha(raw)})
D=Path('/private/tmp/pathwaymech-next-270-discovery')
assert sha((D/'artifact-manifest.json').read_bytes())=='357c7c297bd3952e76ccd3386f4e518e98a83d0d7b989a7f3710ef54082e6621'
m=json.loads((D/'artifact-manifest.json').read_text())
for r in m['files']: assert sha((D/r['path']).read_bytes())==r['sha256']
for p in sorted(D.rglob('*')):
 if p.is_file(): cp(p,'inputs/prior-next270-discovery/'+str(p.relative_to(D)))
contracts=['CLAUDE.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','docs/IDENTIFIERS.md','conf/sources.yaml','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','.claude/skills/add-pathway/SKILL.md','templates/pathway_mechanism_research.md']
paths=sorted([str(p.relative_to(B)) for p in (B/'data/pathways').glob('*.yaml')]+contracts)
records=[]
for rel in paths:
 src=B/rel
 if not src.exists(): src=WORK/rel
 raw=src.read_bytes(); gitraw=subprocess.check_output(['git','show',HEAD+':'+rel],cwd=WORK)
 assert raw==gitraw,rel
 cp(src,'inputs/landed266/'+rel); records.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'git_blob':subprocess.check_output(['git','rev-parse',HEAD+':'+rel],cwd=WORK,text=True).strip()})
G=Path('/private/tmp/pathwaymech-next-270-native-graph-design')
assert sha((G/'artifact-manifest.json').read_bytes())=='906563c7d8eaafe6c9198bbd7f9b0bea75bebffe634a07285410a98bebbc4e48'
gm={r['path']:r for r in json.loads((G/'artifact-manifest.json').read_text())['files']}
selected=['HANDOFF.md','DESIGN.md','results/proposed-native-node-inventory.json','results/proposed-native-edge-inventory.json','results/proposed-native-reference-inventory.json','results/native-authority-requirements.json','results/all30-material-occurrence-design.json','results/all12-native-taxon-design-dispositions.json','artifact-manifest.json','freeze-proof.json']
for rel in selected:
 if rel in gm: assert sha((G/rel).read_bytes())==gm[rel]['sha256']
 cp(G/rel,'inputs/pending270-design/'+rel)
S=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
for rel in ['originals/native/META-METHFORM-PWY.xml','receipts/members-METHFORM-PWY.json','originals/native/META-2.1.1.86-RXN.xml']:
 if (S/rel).exists(): cp(S/rel,'inputs/pending270-source/'+rel)
put('results/input-bindings-initial.json',bindings)
put('results/landed-baseline.json',{'head':HEAD,'tree':subprocess.check_output(['git','rev-parse',HEAD+'^{tree}'],cwd=WORK,text=True).strip(),'paths':records,'pathway_count':len(list((R/'inputs/landed266/data/pathways').glob('*.yaml'))),'pending270':'Frozen graph proposal separately bound; actual pending270 record/merge not accepted here.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'copied':len(bindings),'baseline_paths':len(records)}))
