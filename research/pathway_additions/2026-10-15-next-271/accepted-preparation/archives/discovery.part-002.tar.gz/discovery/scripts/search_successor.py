from pathlib import Path
import hashlib,json,subprocess,gzip,tarfile,io,datetime
R=Path('/private/tmp/pathwaymech-next-271-discovery');W=Path('/private/tmp/pathwaymech-next-270-20261015');O=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech');H='e8ae5e445d3288717c31d3012611e226fd5cca34'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):(R/'results'/n).write_text(json.dumps(o,indent=2)+'\n')
patterns=(R/'results/search-patterns.txt').read_text().splitlines()
def find(t,pats,cap=15):
 lo=t.lower();out=[]
 for p in pats:
  needle=p.lower();start=lo.find(needle)
  if start<0:continue
  count=lo.count(needle);contexts=[];i=start
  while i>=0 and len(contexts)<cap:
   contexts.append(t[max(0,i-160):i+len(p)+250]);i=lo.find(needle,i+len(needle))
  out.append({'pattern':p,'occurrences':count,'contexts':contexts,'context_limit_per_pattern':cap})
 return out
for tag,base in [('pending270-worktree',W),('original-checkout',O)]:
 cmd=['rg','--no-ignore','--hidden','--files-with-matches','-i','-F','-f',str(R/'results/search-patterns.txt'),'-g','!.git/**','-g','!.venv/**','.'];q=subprocess.run(cmd,cwd=base,capture_output=True,text=True);assert q.returncode in (0,1),q.stderr;hits=[]
 (R/'results'/('search-matched-paths-'+tag+'.txt')).write_text(q.stdout)
 for f in q.stdout.splitlines():
  p=base/f;b=p.read_bytes();ms=find(b.decode('utf8',errors='replace'),patterns);hits.append({'path':str(p.relative_to(base)),'bytes':len(b),'sha256':sha(b),'literal_matches':ms})
 put('ordinary-text-search-'+tag+'.json',{'command':cmd,'root':str(base),'returncode':q.returncode,'stderr':q.stderr,'scope':'Hidden and ignored ordinary text included; .git and .venv excluded; compressed and binary interiors not covered. Working tree includes pending270, separately from bound landed266. Each literal counted with first15 contexts, not a full-reading claim.','files':hits})
 print(tag,len(hits),sum(f['bytes'] for f in hits),flush=True)
old=json.loads((R/'inputs/prior-next270-discovery/results/compressed-history-content-scan.json').read_text());oldpatterns=(R/'inputs/prior-next270-discovery/results/exact-preflight-search-patterns.txt').read_text().splitlines();additional=[p for p in patterns if p not in oldpatterns];arr=[]
for f in old['files']:
 b=(W/f['path']).read_bytes();assert sha(b)==f['compressed_sha256'];raw=gzip.decompress(b);assert sha(raw)==f['decoded_sha256'];arr.append({'path':f['path'],'compressed_sha256':sha(b),'decoded_sha256':sha(raw),'decoded_bytes':len(raw),'prior_result_hits':f['hits'],'additional_pattern_hits':find(raw.decode('utf8',errors='replace'),additional),'scope':'Prior old-pattern result reused after compressed and decoded identity; newly searched only added next271 patterns.'})
put('selected-compressed-reuse-and-additional-search.json',{'files':arr,'count':len(arr),'decoded_bytes':sum(f['decoded_bytes'] for f in arr),'reused_prior_patterns':oldpatterns,'additional_patterns':additional,'other_archive_interiors':'Not searched globally. Prior archive path inventory is not a full content absence proof.'});print('reused compressed',len(arr),flush=True)
changed=subprocess.check_output(['git','diff','--name-only','7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105',H],cwd=W,text=True).splitlines();archives=[p for p in changed if p.endswith(('.tar.gz','.tgz','.zip','.gz'))];outer=[];bind=[]
for rel in archives:
 b=(W/rel).read_bytes();got=subprocess.check_output(['git','show',H+':'+rel],cwd=W);assert b==got;bind.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
 if rel.endswith(('.tar.gz','.tgz')):
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tf:
   for m in tf:
    if not m.isfile():continue
    raw=tf.extractfile(m).read();item={'archive':rel,'path':m.name,'bytes':len(raw),'sha256':sha(raw),'nested_archive_opaque':m.name.endswith(('.gz','.zip','.tar','.tgz'))}
    if not item['nested_archive_opaque'] and b'\0' not in raw:item.update(literal_matches=find(raw.decode('utf8',errors='replace'),patterns),text_search=True)
    else:item['text_search']=False
    outer.append(item)
 else:
  raw=gzip.decompress(b) if rel.endswith('.gz') else b'';outer.append({'archive':rel,'path':'<single gzip payload>' if raw else '<not decoded>','bytes':len(raw),'sha256':sha(raw) if raw else None,'text_search':bool(raw) and b'\0' not in raw,'literal_matches':find(raw.decode('utf8',errors='replace'),patterns) if raw and b'\0' not in raw else []})
put('new-landed269-archive-outer-search.json',{'archive_bindings':bind,'members':outer,'limit':'Changed landed269 archive outer members only. Nested archives and binary contents are opaque; no recursive global search. Single gzip payloads searched when text.'})
print(json.dumps({'patterns':len(patterns),'prior_selected_gz':len(arr),'new_landed_archives':len(archives),'outer_members':len(outer),'outer_text':sum(m.get('text_search',False) for m in outer),'outer_nested':sum(m.get('nested_archive_opaque',False) for m in outer)}),flush=True)
put('search-successor-terminal.json',{'status':'complete','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Bounded searches described in individual receipts; initial regex context-extraction attempt interrupted and retained at search.stderr/stdout; successor uses equivalent case-folded literal counting and capped contexts.'})
