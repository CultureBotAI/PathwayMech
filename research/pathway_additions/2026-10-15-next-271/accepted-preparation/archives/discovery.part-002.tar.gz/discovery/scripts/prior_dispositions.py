from pathlib import Path
import json,hashlib,shutil
R=Path('/private/tmp/pathwaymech-next-271-discovery');W=Path('/private/tmp/pathwaymech-next-270-20261015')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):(R/'results'/n).write_text(json.dumps(o,indent=2)+'\n')
rootpats={'METH-ACETATE-PWY','methanogenesis from acetate','aceticlastic pathway','aceticlastic methanogenesis','acetoclastic methanogenesis','methanogenesis from acetic acid'}
memberpats={'1.2.7.4-RXN','RXN-12908','ACETYLSYNCLTH-RXN','MTRMBARK-RXN','PHOSACETYLTRANS-RXN','ACETATEKIN-RXN'}
rows=[]
for tag in ['pending270-worktree','original-checkout']:
 for f in json.loads((R/'results'/('ordinary-text-search-'+tag+'.json')).read_text())['files']:
  ms=[m for m in f['literal_matches'] if m['pattern'] in rootpats|memberpats]
  if not ms:continue
  p=f['path']
  if p=='reports/causal_graph_review/metacyc-review.json':d='Prior native-to-Rhea coverage review for PWY0-1312, not candidate METH-ACETATE membership. Preserve shared Ack/Pta chemistry and opposite pathway direction.'
  elif p.startswith('data/identifier_authorities/'):d='Existing authority metadata embeds compound backlinks/regulated activity context and, in pending270, root general narrative. Exact snapshot term-owner check does not contain the candidate pathway or six Reaction terms. Embedded mention is not term ownership or record curation.'
  elif '/accepted-preparation/inventory.json' in p or '/integration-preparation/inventory.json' in p:d='Retention inventory points to the already preserved discovery lead, not a maintained candidate or independent new acceptance.'
  elif p.endswith('web-search-and-open-results.json'):d='Pending270 author-source acquisition/search context includes generic aceticlastic discussion; no candidate-specific primary or all-taxon acceptance follows.'
  elif 'root-0-matches.json' in p or 'root-1-matches.json' in p:d='Earlier gallate preflight captured CPD-7/Corrinoid context from native authority source. It does not reject or curate METH-ACETATE-PWY.'
  elif p.endswith('complete-direct-slot-ledger.json'):d='Earlier gallate ledger carries compound reaction backlinks. These are contextual objects, not candidate member curation or physiological pathway acceptance.'
  elif p.endswith(('META-METHFORM-PWY.xml','META-METHANOGENESIS-PWY.xml')):d='Native neighboring-pathway comment cites acetate pathway in general methanogenesis background. Six-member boundary and source-only scope remain separate; read retained next270 root and METHFORM source.'
  elif p.endswith('.xml'):d='Native compound original or fixture contains appears-in-side/regulation/low-detail activity backlink. Preserve possible future reuse only after original hash, exact identity, full detail and biological scope checks; it is not a maintained pathway/reaction declaration.'
  else:raise AssertionError(p)
  rows.append({'search_root':tag,'path':p,'sha256':f['sha256'],'matched_literals':[m['pattern'] for m in ms],'occurrence_counts':{m['pattern']:m['occurrences'] for m in ms},'disposition':d,'reading_scope':'Full candidate/member matching contexts inspected; not all unrelated content in the complete file read.'})
put('ordinary-prior-mention-dispositions.json',rows)
# Preserve complete ignored prior report and exact selected existing-pathway review.
p=W/'reports/causal_graph_review/metacyc-review.json';b=p.read_bytes();dst=R/'inputs/prior-mentions/metacyc-review.json';dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);d=json.loads(b);selected=[]
def walk(x,loc='$'):
 if isinstance(x,dict):
  if any(v=='MetaCyc:PWY0-1312' or v=='acetate and ATP formation from acetyl-CoA I' for v in x.values() if isinstance(v,str)):selected.append({'locator':loc,'object':x})
  for k,v in x.items():walk(v,loc+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):walk(v,f'{loc}[{i}]')
walk(d);put('prior-PWY0-1312-review-projection.json',{'source':str(p),'copy':str(dst.relative_to(R)),'sha256':sha(b),'selected':selected})
print(json.dumps({'ordinary_dispositions':len(rows),'selected_prior_review_objects':len(selected),'prior_review_sha256':sha(b)}))
