from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,re,html
R=Path('/private/tmp/pathwaymech-next-271-discovery')
paths=[R/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml',*sorted((R/'originals').glob('META-*.xml'))]
rows=[]
for p in paths:
 root=E.fromstring(p.read_bytes()); obj=next(x for x in root if x.tag!='metadata'); fid=obj.get('frameid'); assert obj.get('detail')=='full'; assert root.findtext('metadata/query')=='META:'+fid
 slots=[]; ct={}
 for x in obj:
  ct[x.tag]=ct.get(x.tag,0)+1;slots.append({'slot':x.tag,'occurrence':ct[x.tag],'locator':f"/ptools-xml/{obj.tag}[@frameid='{fid}']/{x.tag}[{ct[x.tag]}]",'xml':E.tostring(x,encoding='unicode'),'text':''.join(x.itertext()),'direct_objects':[dict(tag=y.tag,**y.attrib) for y in x if y.get('frameid')]})
 row={'file':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'ptools_version':root.get('ptools-version'),'metadata':E.tostring(root.find('metadata'),encoding='unicode'),'identity':obj.attrib,'tag':obj.tag,'slots':slots}
 rows.append(row)
(R/'results/native-complete-own-slot-projections.json').write_text(json.dumps(rows,indent=2)+'\n')
with (R/'results/native-readings.txt').open('w') as out:
 for r in rows:
  out.write('\n### '+r['identity']['frameid']+' '+r['sha256']+'\n')
  for s in r['slots']:
   if s['slot'] in {'credits','in-pathway','parent','reaction-list','reaction-ordering','reaction-layout','species','taxonomic-range','pathway-link','super-pathways'}:continue
   out.write(s['locator']+'\n'+s['xml']+'\n')
print(json.dumps({'objects':len(rows),'own_slots':sum(len(r['slots']) for r in rows),'bytes':(R/'results/native-readings.txt').stat().st_size}))
