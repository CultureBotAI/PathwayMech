from pathlib import Path
import json,re,hashlib,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-discovery');W=Path('/private/tmp/pathwaymech-next-270-20261015')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):(R/'results'/n).write_text(json.dumps(o,indent=2)+'\n')
d=json.loads((R/'results/followup-ordinary-search-pending270-worktree.json').read_text());rows=[]
exact=['MetaCyc:CPD-8','MetaCyc:CPD-9','CHEBI:59924','CHEBI:64267','tetrahydrosarcinapterin','2571608','8824151']
for f in d['files']:
 p=W/f['path'];b=p.read_bytes();t=b.decode('utf8',errors='replace');hits=[]
 for s in exact:
  for m in re.finditer(r'(?<![A-Za-z0-9_-])'+re.escape(s)+r'(?![A-Za-z0-9_-])',t,re.I):hits.append({'pattern':s,'context':t[max(0,m.start()-180):m.end()+240]})
 if hits:rows.append({'path':f['path'],'sha256':sha(b),'hits':hits})
put('exact-followup-mentions.json',rows)
# Complete own-root slots, including metadata and editorial slots, each with bounded disposition.
root=E.parse(R/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml').getroot();o=root.find('Pathway');counts={};out=[]
dispositions={'parent':'Broad methanogenesis class, not a native member or exact alias.','credits':'Retain creation/revision provenance, not experimental evidence.','comment':'Source narrative read completely; route-specific component leads and generic background separated in HANDOFF; cited papers not automatically inspected primary support.','pathway-link':'Boundary/cofactor-synthesis link only; METHFORM remains downstream of methyl-CoM.','super-pathways':'PWY-6830 contextual superpathway, not a member reaction.','in-pathway':'PWY-6830 contextual superpathway, not a member reaction.','evidence':'EV-AS-TAS / PMID12102556 is traceable-author/review provenance, not direct route-wide experiment.','synonym':'Source-native lexical alternative only; no broader pathway equivalence inferred.','taxonomic-range':'Historical phylum range, not direct species association or experimental flux evidence.','reaction-ordering':'Preserve every explicit predecessor edge; two branches from ACDS are not serialized into a single six-step linear chain.','species':'Seven source associations, including two genera and ungrounded ORG-5913; exact taxon/activation scope unresolved, all retained for source preparation.','reaction-layout':'Selected orientation and primary graphical participants only; complete equations separately acquired for all six reactions.','common-name':'Exact native pathway label retained, with methyl-CoM membership endpoint explained.','reaction-list':'Exactly six native Reaction members verified independently from original; do not extend with Acs or downstream methane reaction.'}
for x in o:
 counts[x.tag]=counts.get(x.tag,0)+1;assert x.tag in dispositions,x.tag;out.append({'slot':x.tag,'index':counts[x.tag],'locator':f"/ptools-xml/Pathway[@frameid='METH-ACETATE-PWY']/{x.tag}[{counts[x.tag]}]",'xml':E.tostring(x,encoding='unicode'),'disposition':dispositions[x.tag]})
put('complete-native-root-dispositions.json',{'root_sha256':sha((R/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml').read_bytes()),'metadata_xml':E.tostring(root.find('metadata'),encoding='unicode'),'root_attributes':root.attrib,'object_attributes':o.attrib,'own_slot_count':len(out),'dispositions':out})
print(json.dumps({'exact_followup_files':len(rows),'root_own_slots':len(out),'scopes':[{'path':r['path'],'hits':len(r['hits'])} for r in rows]}))
