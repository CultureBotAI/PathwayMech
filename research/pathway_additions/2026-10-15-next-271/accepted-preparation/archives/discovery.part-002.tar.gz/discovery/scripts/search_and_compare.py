from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as E,yaml,collections,gzip,tarfile,io
R=Path('/private/tmp/pathwaymech-next-271-discovery'); W=Path('/private/tmp/pathwaymech-next-270-20261015'); O=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech'); H='e8ae5e445d3288717c31d3012611e226fd5cca34'
def sha(b): return hashlib.sha256(b).hexdigest()
def put(name,o): (R/'results'/name).write_text(json.dumps(o,indent=2)+'\n')
root=E.parse(R/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml').getroot().find('Pathway'); members=[e.get('frameid') for e in root.findall('reaction-list/Reaction')];dirs={s.find('Reaction').get('frameid'):s.findtext('direction') for s in root.findall('reaction-layout')}
patterns=['METH-ACETATE-PWY','methanogenesis from acetate','aceticlastic pathway','aceticlastic methanogenesis','acetoclastic methanogenesis','methanogenesis from acetic acid',*members,'METHANOGENESIS-PWY','M00357','M00567','R00235','R09096','R04347','R04541','Wood-Ljungdahl','PWY0-1312']
patterns+=sorted(set(re.findall(r'pubmed/(\d+)',root.findtext('comment'))+['12102556']))
rxns=[];xrefs=[];materials=[];activities=[]
for fid in members:
 p=R/'originals'/('META-'+fid+'.xml'); obj=E.parse(p).getroot().find('Reaction');row={'id':fid,'sha256':sha(p.read_bytes()),'direction_native':obj.findtext('reaction-direction'),'direction_pathway':dirs[fid],'common_name':obj.findtext('common-name'),'synonyms':[s.text for s in obj.findall('synonym')],'in_pathway':[s.get('frameid') for s in obj.findall('in-pathway/Pathway')],'ec_numbers':[s.text for s in obj.findall('ec-number')],'equation':{}}
 for side in ['left','right']:
  row['equation'][side]=[]
  for i,s in enumerate(obj.findall(side),1):
   item=next(c for c in s if c.get('frameid'));mat={'id':item.get('frameid'),'native_type':item.tag,'class':item.get('class')=='true','coefficient':int(s.findtext('coefficient','1')),'coefficient_explicit':s.find('coefficient') is not None,'compartment':E.tostring(s.find('compartment'),encoding='unicode') if s.find('compartment') is not None else None,'locator':f"/ptools-xml/Reaction[@frameid='{fid}']/{side}[{i}]"}
   row['equation'][side].append(mat);materials.append(dict(reaction=fid,native_side=side,selected_side=('inputs' if ((side=='left')==(dirs[fid]=='L2R')) else 'outputs'),**mat))
 for s in obj.findall('dblink'):
  x={'reaction':fid,'db':s.findtext('dblink-db'),'id':s.findtext('dblink-oid'),'relation':s.findtext('dblink-relationship'),'url':s.findtext('dblink-URL')};xrefs.append(x)
  patterns.append(x['id'])
 for s in obj.findall('enzymatic-reaction/Enzymatic-Reaction'):
  activities.append({'reaction':fid,'id':s.get('frameid'),'detail':s.get('detail'),'enzymes':[c.get('frameid') for c in s.findall('enzyme/Protein')],'name':s.findtext('common-name')})
 row['enzymes_not_used']=[s.get('frameid') for s in obj.findall('enzymes-not-used/Protein')];rxns.append(row)
patterns=list(dict.fromkeys(patterns));(R/'results/search-patterns.txt').write_text('\n'.join(patterns)+'\n');rx=re.compile('|'.join(map(re.escape,patterns)),re.I)
put('native-six-reactions.json',rxns);put('native-material-occurrences.json',materials);put('native-xref-leads-not-equivalences.json',xrefs);put('native-activity-prerequisites.json',activities)
records=[];overlaps=[]
for p in sorted((R/'inputs/landed266/data/pathways').glob('*.yaml')):
 d=yaml.safe_load(p.read_text());ids={n['id'] for key in ['participants','reactions','taxa','references'] for n in d.get(key,[])}|{d['id']};matches=sorted(set(m.group() for m in rx.finditer(p.read_text())))
 r={'path':str(p.relative_to(R/'inputs/landed266')),'id':d['id'],'label':d['label'],'sha256':sha(p.read_bytes()),'exact_native_member_declarations':sorted(ids.intersection({'MetaCyc:'+x for x in members})),'matched_search_literals':matches}
 records.append(r)
 if matches: overlaps.append(r)
put('all266-record-comparison.json',records)
for tag,base in [('pending270-worktree',W),('original-checkout',O)]:
 cmd=['rg','--no-ignore','--hidden','--files-with-matches','-i','-F','-f',str(R/'results/search-patterns.txt'),'-g','!.git/**','-g','!.venv/**','.'];q=subprocess.run(cmd,cwd=base,capture_output=True,text=True);assert q.returncode in (0,1),q.stderr;hits=[]
 for f in q.stdout.splitlines():
  p=base/f;b=p.read_bytes();t=b.decode('utf8',errors='replace');ms=list(rx.finditer(t));hits.append({'path':str(p.relative_to(base)),'bytes':len(b),'sha256':sha(b),'matched_literals':sorted(set(m.group() for m in ms)),'contexts':[t[max(0,m.start()-160):min(len(t),m.end()+250)] for m in ms[:15]],'matched_occurrences':len(ms),'context_limit':15})
 put('ordinary-text-search-'+tag+'.json',{'command':cmd,'root':str(base),'returncode':q.returncode,'stderr':q.stderr,'scope':'Hidden and ignored ordinary text included; .git and .venv excluded; binary/compressed interior not covered. Working tree includes pending270 and is not itself the landed baseline. Contexts capped; not full reading claim.','files':hits})
 print(tag,len(hits),flush=True)
old=json.loads((R/'inputs/prior-next270-discovery/results/compressed-history-content-scan.json').read_text());oldpatterns=(R/'inputs/prior-next270-discovery/results/exact-preflight-search-patterns.txt').read_text().splitlines();additional=[p for p in patterns if p not in oldpatterns];rxadd=re.compile('|'.join(map(re.escape,additional)),re.I);arr=[]
for f in old['files']:
 b=(W/f['path']).read_bytes();assert sha(b)==f['compressed_sha256'];raw=gzip.decompress(b);assert sha(raw)==f['decoded_sha256'];t=raw.decode('utf8',errors='replace');ms=list(rxadd.finditer(t));arr.append({'path':f['path'],'compressed_sha256':sha(b),'decoded_sha256':sha(raw),'decoded_bytes':len(raw),'reused_prior_patterns':oldpatterns,'prior_result_hits':f['hits'],'additional_pattern_hits':[{'pattern':m.group(),'context':t[max(0,m.start()-180):min(len(t),m.end()+250)]} for m in ms],'scope':'Prior old-pattern result reused after compressed and decoded identity; newly searched only added next271 patterns.'})
put('selected-compressed-reuse-and-additional-search.json',{'files':arr,'count':len(arr),'decoded_bytes':sum(f['decoded_bytes'] for f in arr),'additional_patterns':additional,'other_archive_interiors':'Not searched globally. See prior full archive path inventory, not a full content absence proof.'})
changed=subprocess.check_output(['git','diff','--name-only','7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105',H],cwd=W,text=True).splitlines();archives=[p for p in changed if p.endswith(('.tar.gz','.tgz','.zip','.gz'))];outer=[]
for rel in archives:
 p=W/rel;b=p.read_bytes();got=subprocess.check_output(['git','show',H+':'+rel],cwd=W);assert b==got
 if rel.endswith(('.tar.gz','.tgz')):
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tf:
   for m in tf:
    if not m.isfile():continue
    raw=tf.extractfile(m).read(); item={'path':m.name,'bytes':len(raw),'sha256':sha(raw),'nested_archive_opaque':m.name.endswith(('.gz','.zip','.tar','.tgz'))}
    if not item['nested_archive_opaque'] and b'\0' not in raw:
     t=raw.decode('utf8',errors='replace');ms=list(rx.finditer(t));item.update(matches=[{'pattern':v.group(),'context':t[max(0,v.start()-120):min(len(t),v.end()+200)]} for v in ms],text_search=True)
    else:item['text_search']=False
    outer.append(dict(archive=rel,archive_sha256=sha(b),**item))
 else: outer.append({'archive':rel,'archive_sha256':sha(b),'not_decoded':True})
put('new-landed269-archive-outer-search.json',{'changed_archives':archives,'members':outer,'nested_limit':'Only changed landed269 archive outer members searched when nonbinary text; nested containers retained as opaque. Not recursive global scan.'})
print(json.dumps({'records':len(records),'overlapping_records':len(overlaps),'patterns':len(patterns),'members':len(rxns),'material_occurrences':len(materials),'material_ids':len({m['id'] for m in materials}),'activities':len(activities),'prior_selected_gz':len(arr),'new_landed_archives':len(archives),'outer_members':len(outer)}))
