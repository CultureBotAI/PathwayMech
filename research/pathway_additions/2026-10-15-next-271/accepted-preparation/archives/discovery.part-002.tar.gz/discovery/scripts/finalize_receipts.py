from pathlib import Path
import json,hashlib,datetime,re,collections,xml.etree.ElementTree as E,subprocess
R=Path('/private/tmp/pathwaymech-next-271-discovery');W=Path('/private/tmp/pathwaymech-next-270-20261015')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):(R/'results'/n).write_text(json.dumps(o,indent=2)+'\n')
rootpats={'METH-ACETATE-PWY','methanogenesis from acetate','aceticlastic pathway','aceticlastic methanogenesis','acetoclastic methanogenesis','methanogenesis from acetic acid'}
memberpats={'1.2.7.4-RXN','RXN-12908','ACETYLSYNCLTH-RXN','MTRMBARK-RXN','PHOSACETYLTRANS-RXN','ACETATEKIN-RXN'}
a=json.loads((R/'results/new-landed269-archive-outer-search.json').read_text());rows=[]
for m in a['members']:
 hs=[x for x in m.get('literal_matches',[]) if x['pattern'] in rootpats|memberpats]
 if hs:
  assert not any(h['pattern'] in rootpats for h in hs)
  rows.append({'archive':m['archive'],'member':m['path'],'sha256':m['sha256'],'patterns':[h['pattern'] for h in hs],'disposition':'Shared native Compound backlinks, low-detail activity/regulation context and preserved projections/authority metadata from glutaryl and earlier source inputs; not a METH-ACETATE-PWY record, rejection or pathway acceptance. Full candidate/member matching contexts read; unrelated contents are not a new scientific review.'})
old=json.loads((R/'results/selected-compressed-reuse-and-additional-search.json').read_text());older=[]
for m in old['files']:
 if m['additional_pattern_hits']:older.append({'path':m['path'],'compressed_sha256':m['compressed_sha256'],'patterns':[h['pattern'] for h in m['additional_pattern_hits']],'disposition':'PWY0-1312 corpus bookkeeping or existing Rhea quartet/numeric matches; no exact acetate-methanogenesis candidate disposition. No authority equivalence follows from untyped numeric hits.'})
put('compressed-prior-mention-dispositions.json',{'new_landed_member_mentions':rows,'old_selected_additional_mentions':older,'limits':'Only the documented 86-pattern finite archive scan. Later compound alias and helper DOI/PMID follow-ups are ordinary-text/corpus checks, not an additional global archive pass.'})
# Follow-up exact evidence/identity accounting against all retained landed records (no prefix inference).
pats=(R/'results/followup-search-patterns.txt').read_text().splitlines();fr=[]
for p in sorted((R/'inputs/landed266/data/pathways').glob('*.yaml')):
 b=p.read_bytes();s=b.decode();matches=[]
 for pat in pats:
  if re.search(r'(?<![A-Za-z0-9_-])'+re.escape(pat)+r'(?![A-Za-z0-9_-])',s,re.I):matches.append(pat)
 fr.append({'path':str(p.relative_to(R/'inputs/landed266')),'sha256':sha(b),'exact_token_hits':matches})
put('all266-followup-exact-token-check.json',fr)
# Each acquired original has its own full-detail identity and source receipt.
orig=[]
for p in sorted((R/'originals').glob('META-*.xml')):
 t=E.parse(p).getroot();o=next(x for x in t if x.tag!='metadata');fid=o.get('frameid');receipt=R/'receipts'/('boundary-'+fid+'.json' if fid in ['CPD-8','CPD-9'] else 'member-'+fid+'-network.json');r=json.loads(receipt.read_text());assert sha(p.read_bytes())==r['sha256'];assert o.get('detail')=='full' and o.get('ID')=='META:'+fid and t.findtext('metadata/query')=='META:'+fid and t.findtext('metadata/num_results')=='1';orig.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'type':o.tag,'id':fid,'version':t.get('ptools-version'),'receipt':str(receipt.relative_to(R)),'url':r['url']})
put('acquired-originals-verified.json',orig)
# Copied source manifest and declared bindings are rehashed; do not bind mutable whole working trees as immutable.
b=json.loads((R/'results/input-bindings-initial.json').read_text());checks=[]
for x in b:
 p=R/x['copy'];assert sha(p.read_bytes())==x['sha256'];src=Path(x['source']);assert sha(src.read_bytes())==x['sha256'];checks.append({'copy':x['copy'],'sha256':x['sha256'],'source_unchanged':True})
land=json.loads((R/'results/landed-baseline.json').read_text());assert land['pathway_count']==266
for x in land['paths']:assert sha((R/'inputs/landed266'/x['path']).read_bytes())==x['sha256']
put('final-input-recheck.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial_bound_inputs':checks,'landed_records_unchanged':266,'fresh_originals_receipt_verified':len(orig),'prior_discovery_manifest_sha256':sha((R/'inputs/prior-next270-discovery/artifact-manifest.json').read_bytes()),'authority_probe_is_only_pinned_inventory':True,'maintained_changes':'None by this task. Parent concurrent pending270 work is not frozen or accepted by this discovery.'})
summary={'landed_records':266,'root_own_slots':34,'native_members':6,'native_order_edges':5,'equation_material_occurrences':29,'material_ids':19,'low_detail_activities':45,'direct_taxon_associations':7,'acquired_native_originals':len(orig),'ordinary_main_matches':{},'ordinary_followup_matches':{},'prior_selected_gzip':len(old['files']),'prior_selected_decoded_bytes':old['decoded_bytes'],'landed269_changed_archives':len(a['archive_bindings']),'changed_archive_compressed_bytes':sum(x['bytes'] for x in a['archive_bindings']),'changed_outer_member_occurrences':len(a['members']),'changed_outer_member_bytes':sum(x['bytes'] for x in a['members']),'changed_text_member_occurrences':sum(x.get('text_search',False) for x in a['members']),'nested_containers_opaque':sum(x.get('nested_archive_opaque',False) for x in a['members']),'new_archive_member_mentions':len(rows),'old_selected_added_pattern_hit_files':len(older),'root_candidate_hit_in_selected_compressed_scopes':False,'science_status':'preliminary candidate for source preparation, not curated or independently accepted','baseline_rebind_pending':'actual next270 merge'}
for tag in ['pending270-worktree','original-checkout']:
 summary['ordinary_main_matches'][tag]=len(json.loads((R/'results'/('ordinary-text-search-'+tag+'.json')).read_text())['files']);summary['ordinary_followup_matches'][tag]=len(json.loads((R/'results'/('followup-ordinary-search-'+tag+'.json')).read_text())['files'])
put('summary.json',summary);print(json.dumps(summary))
