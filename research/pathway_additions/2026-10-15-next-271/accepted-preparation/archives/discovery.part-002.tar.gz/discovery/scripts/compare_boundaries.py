from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as E,yaml,collections
R=Path('/private/tmp/pathwaymech-next-271-discovery');W=Path('/private/tmp/pathwaymech-next-270-20261015');H='e8ae5e445d3288717c31d3012611e226fd5cca34'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):(R/'results'/n).write_text(json.dumps(o,indent=2)+'\n')
rel='conf/rhea_directions.json';b=subprocess.check_output(['git','show',H+':'+rel],cwd=W);p=R/'inputs/landed266'/rel;p.write_bytes(b);d=json.loads(b)
xrefs=json.loads((R/'results/native-xref-leads-not-equivalences.json').read_text());families=[]
for x in xrefs:
 if x['db']!='RHEA':continue
 master=d['directions'].get(x['id']);hits=[]
 for p in (R/'inputs/landed266/data/pathways').glob('*.yaml'):
  y=yaml.safe_load(p.read_text())
  for rr in y.get('reactions',[]):
   if rr['id'].startswith('RHEA:') and master and d['directions'].get(rr['id'].split(':',1)[1])==master:hits.append({'record':y['id'],'path':str(p.relative_to(R/'inputs/landed266')),'reaction':rr})
 families.append(dict(native=x['reaction'],native_xref=x['id'],pinned_master=master,existing_family_hits=hits))
put('pinned-rhea-family-overlaps.json',{'source_pin':d['source'],'conf_sha256':sha(b),'family_hits':families,'limit':'Native xrefs are candidate relations. Pinned quartet normalization identifies reaction-family overlap; it does not independently accept native material/charge/stereo equivalence or select physiological direction.'})
root=E.parse(R/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml').getroot().find('Pathway');mats=json.loads((R/'results/native-material-occurrences.json').read_text());equations=json.loads((R/'results/native-six-reactions.json').read_text())
net=collections.Counter()
for m in mats:net[m['id']]+=m['coefficient']*(1 if m['selected_side']=='outputs' else -1)
order=[]
for s in root.findall('reaction-ordering'):
 after=s.find('Reaction').get('frameid')
 for x in s.findall('predecessor-reactions/Reaction'):order.append({'before':x.get('frameid'),'after':after})
taxa=[]
for i,s in enumerate(root.findall('species'),1):
 o=s.find('Organism');taxa.append({'id':o.get('frameid'),'native_label':o.findtext('common-name'),'rank':o.findtext('rank'),'ncbi_native_asserted':[q.findtext('dblink-oid') for q in o.findall('dblink') if q.findtext('dblink-db')=='NCBI-TAXONOMY-DB'],'synonyms':[q.text for q in o.findall('synonym')],'locator':f"/ptools-xml/Pathway[@frameid='METH-ACETATE-PWY']/species[{i}]/Organism",'prerequisite':'Resolve exact current issuing taxon, native rank/label and strain scope; native association alone does not validate every step in every taxon.'})
put('candidate-native-boundary.json',{'id':'MetaCyc:METH-ACETATE-PWY','label':root.findtext('common-name'),'root_sha256':sha((R/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml').read_bytes()),'members':[x.get('frameid') for x in root.findall('reaction-list/Reaction')],'order':order,'source_synonyms':[s.text for s in root.findall('synonym')],'equation_material_occurrences':len(mats),'equation_material_ids':sorted({m['id'] for m in mats}),'native_reaction_all_reversible':all(e['direction_native']=='REVERSIBLE' for e in equations),'all_occurrences_compartment_unspecified':all(m['compartment'] is None for m in mats),'formal_exact_id_sum':dict(sorted((k,v) for k,v in net.items() if v)),'net_limit':'Formal source equation sum using exact IDs and listed coefficients only; not mass/charge balance, physiological flux, public-identifier equivalence, electron recovery, ATP yield or complete methane production.','species':taxa,'range':'Native TAX-28890 Euryarchaeota is range context, not direct taxon-specific experimental proof.','evidence':{'code':'EV-AS-TAS','publication':'PMID:12102556','scope':'Traceable author statement; cited publication is a review, not direct experiment.'},'linked_only':[x.get('frameid') for x in root.findall('pathway-link/link-target/Pathway')],'superpathway':[x.get('frameid') for x in root.findall('super-pathways/Pathway')]})
# Complete source values for the two direct carrier bodies; no chemistry normalization.
carrier=[]
for fid in ['CPD-8','CPD-9']:
 p=R/'originals'/('META-'+fid+'.xml');o=E.parse(p).getroot().find('Compound');mol=o.find('cml/molecule');carrier.append({'id':fid,'sha256':sha(p.read_bytes()),'label':o.findtext('common-name'),'inchi':o.findtext('inchi'),'inchi_key':o.findtext('inchi-key'),'cml_formula':mol.find('formula').attrib,'cml_charge':mol.get('formalCharge'),'cml_smiles':mol.findtext("string[@title='smiles']"),'comment':o.findtext('comment'),'xref_leads':[{x.tag:x.text for x in s} for s in o.findall('dblink')],'limit':'No issuing external alias accepted. Source CML structure and InChI need stereochemical/microstate reconciliation; the two different structures share the same short CML SMILES string, which must not establish identity.'})
# Pending reaction source is already retained from accepted source preparation.
p=R/'inputs/pending270-source/originals/native/META-2.1.1.86-RXN.xml';o=E.parse(p).getroot().find('Reaction');pending={'id':'2.1.1.86-RXN','sha256':sha(p.read_bytes()),'native_direction':o.findtext('reaction-direction'),'equation_xml':[E.tostring(x,encoding='unicode') for x in o if x.tag in {'left','right'}]}
put('carrier-and-pending270-boundary-comparison.json',{'carriers':carrier,'pending_Mtr':pending,'decision':'Distinct native sarcinapterin and methanopterin carriers and source equations. MTRMBARK-RXN has four unlocated terms and no Na term. Pending270 2.1.1.86-RXN has explicitly located methanopterin/CoM terms and two Na transported from inside to outside. Shared methyl-CoM endpoint and same broad activity theme do not make them exact aliases. Absence of source Na in MTRMBARK is not proof of physiological sodium independence.'})
print(json.dumps({'materials':len(mats),'distinct_materials':len({m['id'] for m in mats}),'direct_taxa':len(taxa),'rhea_families':families,'net':dict(net)}))
