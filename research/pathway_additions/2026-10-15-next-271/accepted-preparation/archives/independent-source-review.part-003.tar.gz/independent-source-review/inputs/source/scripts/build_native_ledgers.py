from pathlib import Path
import collections,hashlib,html,json,re,xml.etree.ElementTree as E
from html.parser import HTMLParser
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,x):(R/'results'/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.text=[];self.links=[]
 def handle_data(self,x):self.text.append(x)
 def handle_starttag(self,t,a):
  if t=='a' and dict(a).get('href'):self.links.append(dict(a)['href'])
def plain(t):p=Text();p.feed(t or '');return ''.join(p.text)
objects={};inventory=[]
for p in sorted((R/'originals/native').glob('*.xml')):
 b=p.read_bytes();root=E.fromstring(b);os=[x for x in root if x.tag!='metadata'];assert len(os)==1;o=os[0];f=o.get('frameid');assert f not in objects
 assert o.get('detail')=='full' and o.get('ID')=='META:'+f and o.get('orgid')=='META' and root.findtext('metadata/query')=='META:'+f
 objects[f]=(p,o);inventory.append({'frame':f,'type':o.tag,'class':o.get('class')=='true','label':plain(o.findtext('common-name')),'all_common_names':[plain(s.text) for s in o.findall('common-name')],'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b),'metadata':E.tostring(root.find('metadata'),encoding='unicode'),'envelope_attributes':dict(root.attrib),'object_attributes':dict(o.attrib)})
pw=objects['METH-ACETATE-PWY'][1];members=[x.get('frameid') for x in pw.findall('reaction-list/Reaction')]
assert len(members)==6
directions={x.find('Reaction').get('frameid'):x.findtext('direction') for x in pw.findall('reaction-layout')}
taxa=[x.get('frameid') for x in pw.findall('species/Organism')];ranges=[x.get('frameid') for x in pw.findall('taxonomic-range/Organism')]
follow={'Enzymatic-Reaction':{'enzyme','cofactor','regulated-by','alternative-substrate','alternative-cofactor'},'Protein':{'component','gene','species','locations','location','cofactor','prosthetic-group','modified-form','unmodified-form','regulated-by'},'Gene':{'product','species','regulated-by'},'Regulation':{'regulator','regulated-entity'}}
backlinks={'appears-in-left-side-of','appears-in-right-side-of','cofactors-of','regulates','component-of','catalyzes','surrounds','surrounded-by','subclass','instance'}
metadata={'credits','has-feature','parent','has-go-term'}
slots=[];refs=[];forward=[];comments=[];citations=[];cards=[];components=[];genes=[];orgs=[];regulations=[];materials=[]
def walk(node,path):
 if node.get('frameid'):yield node,path
 n=collections.Counter()
 for child in node:
  n[child.tag]+=1
  yield from walk(child,path+'/'+child.tag+'['+str(n[child.tag])+']')
for f,(p,o) in objects.items():
 counts=collections.Counter();cards.append('\n### '+f+' | '+o.tag+' | class='+str(o.get('class')=='true')+' | '+str(p.relative_to(R)))
 for i,s in enumerate(o,1):
  counts[s.tag]+=1;locator=f"/ptools-xml/{o.tag}[@frameid='{f}']/{s.tag}[{counts[s.tag]}]"
  role='retained own scalar/structured contextual statement'
  isforward=o.get('class')!='true' and s.tag in follow.get(o.tag,set())
  if isforward:role='finite biological forward context; pathway applicability assessed separately'
  elif s.tag in backlinks:role='backlink/class-membership context; not recursive pathway expansion'
  elif s.tag in metadata:role='source identity/class/editorial annotation; no direct mechanism claim'
  if o.tag=='Pathway' and f!='METH-ACETATE-PWY':role='complete boundary-only source pathway; no member expansion'
  xml=E.tostring(s,encoding='unicode');rlist=list(walk(s,locator));slots.append({'owner':f,'owner_type':o.tag,'own_slot_index':i,'slot':s.tag,'source_locator':locator,'xml':xml,'sha256_of_projection_xml':sha(xml.encode()),'role':role,'frame_reference_count':len(rlist)})
  for n,(x,loc) in enumerate(rlist,1):
   direct=x in list(s) or (s.tag in {'alternative-substrate','alternative-cofactor'} and any(x in list(w) for w in s if w.tag in {'substrate','cofactor','alternate'}))
   ref={'owner':f,'slot':s.tag,'own_slot_index':i,'source_locator':loc,'ordinal':n,'target':x.get('frameid'),'type':x.tag,'attributes':dict(x.attrib),'full_original_present':x.get('frameid') in objects,'direct_slot_endpoint':direct,'role':role if direct or not isforward else 'embedded nested context; full target own slots govern finite expansion'};refs.append(ref)
   if isforward and direct and x.tag not in {'Publication','Evidence-Code','Person','Organization'}:forward.append(ref)
   if x.tag=='Publication':citations.append({'owner':f,'source_locator':loc,'native_publication':x.get('frameid'),'scope':'native citation pointer only; paper reading assessed separately'})
  if s.tag=='comment':
   parser=Text();parser.feed(s.text or '');comments.append({'owner':f,'source_locator':locator,'text':''.join(parser.text),'links':parser.links})
   for link in parser.links:
    m=re.search(r'(?:pubmed/|list_uids=)(\d+)',link)
    if m:citations.append({'owner':f,'source_locator':locator,'pmid':m.group(1),'url':link,'scope':'native comment citation lead; not a paper quote'})
  if s.tag not in metadata|backlinks|{'cml'}:cards.append(locator+'\n'+(plain(s.text) if len(s)==0 else xml))
  if o.tag=='Protein' and s.tag=='component':components.append({'complex':f,'component':s[0].get('frameid'),'coefficient_literal':s.findtext('coefficient'),'source_locator':locator,'xml':xml})
 if o.tag=='Gene':genes.append({'frame':f,'label':plain(o.findtext('common-name')),'products':[x.get('frameid') for x in o.findall('product/Protein')],'xrefs':[E.tostring(s,encoding='unicode') for s in o.findall('dblink')],'scope':'native source identity only; external sequence/strain aliases not verified'})
 if o.tag=='Organism':orgs.append({'frame':f,'label':plain(o.findtext('common-name')),'rank':o.findtext('rank'),'strain_name':o.findtext('strain-name'),'role':'direct pathway association' if f in taxa else 'direct pathway range' if f in ranges else 'bounded catalyst/context taxonomy','xrefs':[E.tostring(s,encoding='unicode') for s in o.findall('dblink')],'scope':'native taxon statement; issuing NCBI grounding remains separate'})
 if o.tag=='Regulation' and o.get('class')!='true':regulations.append({'frame':f,'mode':o.findtext('mode'),'regulator':[x.get('frameid') for x in o.findall('regulator/*')],'regulated_entity':[x.get('frameid') for x in o.findall('regulated-entity/*')],'physiologically_relevant':o.findtext('physiologically-relevant'),'mechanism':o.findtext('mechanism'),'comments':[plain(s.text) for s in o.findall('comment')],'citation_xml':[E.tostring(s,encoding='unicode') for s in o.findall('citation')]})
 if o.tag=='Compound' or o.get('class')=='true' and o.tag=='Protein':
  cm=o.find('cml/molecule');materials.append({'frame':f,'type':o.tag,'class':o.get('class')=='true','label':plain(o.findtext('common-name')),'cml_formula':cm.find('formula').get('concise') if cm is not None and cm.find('formula') is not None else None,'cml_charge':cm.get('formalCharge') if cm is not None else None,'smiles':cm.findtext("string[@title='smiles']") if cm is not None else None,'inchi':o.findtext('inchi'),'inchikey':o.findtext('inchi-key'),'xrefs':[E.tostring(s,encoding='unicode') for s in o.findall('dblink')],'identity_disposition':'native original only; external stereo/microstate/alias acceptance excluded'})
equations=[];occurrences=[];activity_occ=[]
for f in members:
 o=objects[f][1];eq={'frame':f,'source_direction':o.findtext('reaction-direction'),'selected_direction':directions[f],'label':o.findtext('common-name'),'ec':[s.text for s in o.findall('ec-number')]}
 for side in ('left','right'):
  terms=[]
  for i,s in enumerate(o.findall(side),1):
   x=next(x for x in s if x.get('frameid'));loc=f"/ptools-xml/Reaction[@frameid='{f}']/{side}[{i}]";term={'frame':x.get('frameid'),'type':x.tag,'class_in_occurrence':x.get('class')=='true','coefficient':int(s.findtext('coefficient') or 1),'coefficient_explicit':s.find('coefficient') is not None,'compartment':[x.get('frameid') for x in s.findall('compartment/*')],'source_locator':loc};terms.append(term);occurrences.append(dict(term,reaction=f,side=side))
  eq[side]=terms
 eq['enzymes_not_used']=[x.get('frameid') for x in o.findall('enzymes-not-used/*')]
 for i,x in enumerate(o.findall('enzymatic-reaction/Enzymatic-Reaction'),1):
  a=objects[x.get('frameid')][1];enz=[n.get('frameid') for n in a.findall('enzyme/Protein')];enzspecies=[{'enzyme':e,'taxa':[n.get('frameid') for n in objects[e][1].findall('species/Organism')]} for e in enz]
  activity_occ.append({'reaction':f,'activity':x.get('frameid'),'low_detail_occurrence':dict(x.attrib),'enzyme':enz,'enzyme_species':enzspecies,'direction':a.findtext('reaction-direction'),'physiologically_relevant':a.findtext('physiologically-relevant'),'activity_label':plain(a.findtext('common-name')),'source_locator':f"/ptools-xml/Reaction[@frameid='{f}']/enzymatic-reaction/Enzymatic-Reaction[{i}]",'qualified_pathway_context':'pending manual source/primary disposition'})
 equations.append(eq)
assert len(occurrences)==29 and len({x['frame'] for x in occurrences})==19 and len(activity_occ)==45
unresolved=[x for x in forward if not x['full_original_present']]
summary={'full_objects':len(objects),'object_types':dict(collections.Counter(o.tag for _,o in objects.values())),'members':6,'material_occurrences':len(occurrences),'material_ids':len({x['frame'] for x in occurrences}),'activity_occurrences':len(activity_occ),'own_slots':len(slots),'reference_occurrences':len(refs),'forward_reference_occurrences':len(forward),'unresolved_forward':unresolved,'component_occurrences':len(components),'regulations':len(regulations),'direct_taxa':taxa,'range':ranges,'scope':'Finite own-slot closure of selected pathway context, not global backlink expansion or accepted final graph.'}
for n,x in [('native-object-inventory.json',inventory),('native-own-slot-ledger.json',slots),('native-reference-occurrences.json',refs),('native-forward-closure.json',forward),('native-comments.json',comments),('native-citation-leads.json',citations),('complex-components.json',components),('gene-ledger.json',genes),('taxon-ledger.json',orgs),('regulation-ledger.json',regulations),('material-identity-ledger.json',materials),('member-equations.json',equations),('member-material-occurrences.json',occurrences),('activity-occurrences.json',activity_occ),('native-closure-summary.json',summary)]:put(n,x)
(R/'reading/native-noneditorial-own-slots.txt').write_text('\n'.join(cards)+'\n')
print(json.dumps(summary,indent=2))
