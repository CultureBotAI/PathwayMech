from pathlib import Path
import collections,hashlib,json,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
checks=[]
def check(name,ok,detail=None):
 checks.append({'check':name,'passed':bool(ok),'detail':detail})
 assert ok,(name,detail)
bindings=read(R/'inputs/predecessor-bindings.json')
for x in bindings:check('predecessor source and copy unchanged',sha(Path(x['source']))==x['sha256']==sha(R/x['copy']),x['copy'])
prov={}
for p in sorted((R/'receipts').glob('*-network.json')):
 x=read(p)
 if 'native_validation' not in x:continue
 check('new native request exact full original',x['status']==200 and x['native_validation']['accepted_exact_full'],p.name)
 check('new native raw body/promoted body hash',sha(R/x['body'])==x['sha256']==sha(R/x['output']),x['frame'])
 check('new native META27',x['native_validation']['pgdb_version']=='27.0',x['frame'])
 prov[x['frame']]={'mode':'new successful acquisition','receipt':str(p.relative_to(R)),'url':x['url'],'sha256':x['sha256'],'body':x['output']}
for p in sorted((R/'receipts').glob('*-reuses.json')):
 for x in read(p):
  check('frozen270 selected body exact',sha(Path(x['path']))==x['sha256']==sha(R/x['copy']),x['frame'])
  check('frozen270 manifest identity',sha(Path(x['source_manifest']))==x['manifest_sha256'],x['frame'])
  for b in x['copied_receipts']:check('frozen270 receipt exact',sha(Path(b['source']))==b['sha256']==sha(R/b['copy']),b['copy'])
  prov[x['frame']]={'mode':'frozen270 exact original reuse','receipt':str(p.relative_to(R)),'original_receipts':[b['copy'] for b in x['copied_receipts']],'sha256':x['sha256'],'body':x['copy']}
for x in read(R/'receipts/discovery-native-reuse.json'):
 check('discovery native exact',sha(R/x['source'])==x['sha256']==sha(R/x['copy']),x['frame'])
 check('discovery acquisition digest retained',x['sha256'] in (R/x['receipt']).read_text(),x['frame'])
 prov[x['frame']]={'mode':'accepted discovery body reuse','receipt':x['receipt'],'sha256':x['sha256'],'body':x['copy']}
check('one complete provenance per full native original',len(prov)==269 and {x['body'] for x in prov.values()}=={str(p.relative_to(R)) for p in (R/'originals/native').glob('*.xml')})
for x in read(R/'receipts/NA-reuse-chain.json')['bindings']:check('NA full reuse chain unchanged',sha(Path(x['source']))==x['sha256']==sha(R/x['copy']),x['copy'])
for x in read(R/'receipts/pdf-reader-binding.json')['inputs']:check('existing PDF reader/source unchanged',sha(Path(x['executed_or_source']))==x['sha256']==sha(R/x['copy']),x['copy'])
objects={};names=[]
for f,x in prov.items():
 root=E.parse(R/x['body']).getroot();o=next(n for n in root if n.tag!='metadata');objects[f]=o
 check('full root native envelope',o.get('frameid')==f and o.get('ID')=='META:'+f and o.get('orgid')=='META' and o.get('detail')=='full' and root.findtext('metadata/query')=='META:'+f,f)
 x['metadata_xml']=E.tostring(root.find('metadata'),encoding='unicode');x['attributes']=dict(o.attrib)
 if len(o.findall('common-name'))>1:names.append({'frame':f,'names':[n.text for n in o.findall('common-name')],'disposition':'All direct names retained. First-label convenience field is not an authority label selection.'})
put('results/native-provenance-index.json',[dict(frame=f,**x) for f,x in sorted(prov.items())]);put('results/multiple-direct-name-dispositions.json',names)
summary=read(R/'results/native-closure-summary.json');check('native finite closure counts',summary['full_objects']==269 and summary['members']==6 and summary['material_occurrences']==29 and summary['material_ids']==19 and summary['activity_occurrences']==45 and not summary['unresolved_forward'])
forward=read(R/'results/native-forward-closure.json');check('all338 selected forward occurrences have full originals',len(forward)==338 and all(x['target'] in objects for x in forward))
check('last traversal has no new jobs',read(R/'results/closure7-jobs.json')==[])
members=[n.get('frameid') for n in objects['METH-ACETATE-PWY'].findall('reaction-list/Reaction')]
check('six own reaction names absent',all(not objects[f].findall('common-name') for f in members))
check('native Ack EC anomaly retained',objects['ACETATEKIN-RXN'].findtext('ec-number')=='EC-2.7.2.15')
check('all source directions reversible',all(objects[f].findtext('reaction-direction')=='REVERSIBLE' for f in members))
check('root ordering five',len(objects['METH-ACETATE-PWY'].findall('reaction-ordering'))==5)
check('ORG5913 no own external pointer; native species rank',not objects['ORG-5913'].findall('dblink') and objects['ORG-5913'].findtext('rank')=='species')
check('no equation material location supplied',all(not x['compartment'] for x in read(R/'results/member-material-occurrences.json')))
check('full native pathway taxa seven',len(objects['METH-ACETATE-PWY'].findall('species'))==7)
check('qualified activity/regulation counts',sum(x['activity'] in {'ENZRXN-481','ENZRXN-482','ENZRXN-541','ENZRXN-362','ENZRXN-18980','ENZRXN-19881','ENZRXN-24491'} for x in read(R/'results/all-45-activity-dispositions.json'))==7 and sum(x['qualified_context'] for x in read(R/'results/all-27-regulation-dispositions.json'))==7)
check('all source components18, qualified8',len(read(R/'results/all-component-dispositions.json'))==18 and sum(x['disposition'].startswith('Qualified') for x in read(R/'results/all-component-dispositions.json'))==8)
for x in read(R/'results/native-own-slot-ledger.json'):
 check('every own slot locator resolves',E.parse(R/prov[x['owner']]['body']).getroot().find(x['source_locator'].removeprefix('/ptools-xml/')) is not None,x['source_locator'])
claims=read(R/'results/claim-ledger.json')
for x in claims:
 for e in x['evidence']:check('claim source digest',sha(R/e['path'])==e['sha256'],x['id']+':'+e['path'])
check('claim accounting20native12primary',len(claims)==32 and len({x['id'] for x in claims})==32)
paper_dois={'P01':'10.1128/jb.168.3.1053-1058.1986','P04':'10.1128/jb.172.12.7145-7150.1990','P05':'10.1128/jb.171.10.5430-5435.1989','P07':'10.1128/jb.178.2.340-346.1996','P08':'10.1128/jb.178.23.6849-6856.1996'}
for x in claims:
 if x['id'] in paper_dois:
  for e in x['evidence']:check('publisher reading receipt contains exact paper DOI',paper_dois[x['id']] in (R/e['path']).read_text(),x['id']+':'+e['path'])

primary=[]
for p in sorted((R/'receipts').glob('primary-*.json')):
 x=read(p)
 if not isinstance(x,dict) or 'url' not in x:continue
 if 'sha256' in x:check('primary attempt body exact',sha(R/x['output'])==x['sha256'],p.name)
 body=(R/x['output']).read_bytes() if (R/x['output']).exists() else b''
 kind='PDF original/reprint retained' if body.startswith(b'%PDF-') else 'JSON metadata' if x['output'].endswith('.json') and x.get('status')==200 else 'metadata XML, no complete article-body claim' if x['output'].endswith('.xml') and x.get('status')==200 else 'HTML or failed response; not a PDF/full-main original'
 primary.append({'name':x['name'],'url':x['url'],'status':x.get('status'),'error':x.get('error'),'receipt':str(p.relative_to(R)),'body':x['output'] if body else None,'sha256':x.get('sha256'),'bytes':len(body),'classification':kind})
put('results/primary-access-ledger.json',primary)
check('only two successful retained primary PDF bodies',sum(x['classification']=='PDF original/reprint retained' for x in primary)==2)
put('results/integrity-checks.json',{'all_passed':True,'count':len(checks),'checks':checks,'native_originals':len(prov),'primary_attempts':len(primary),'scope':'Source/preparation assertions only; not independent scientific acceptance, authority validation, merged270 rebind or final record validation.'})
print(json.dumps({'all_passed':True,'checks':len(checks),'native_originals':len(prov),'primary_attempts':len(primary),'multiple_direct_name_objects':len(names)}))
