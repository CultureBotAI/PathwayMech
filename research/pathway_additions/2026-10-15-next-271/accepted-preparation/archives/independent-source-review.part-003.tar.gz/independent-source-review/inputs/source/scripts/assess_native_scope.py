from pathlib import Path
import collections, hashlib, json, xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
def read(n):return json.loads((R/n).read_text())
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inv=read('results/native-object-inventory.json'); objects={x['frame']:E.parse(R/x['path']).getroot()[1] for x in inv}
qualified={
 'ENZRXN-18980':'Native thermophila carbonyl-oxidation component. Source cofactors and cyanide regulation are retained as native assertions; PMID3023296 measured the whole complex and is not component-specific proof.',
 'ENZRXN-19881':'Native thermophila corrinoid/Fe-S component methyltransferase, reversible. Keep separate from explicitly excluded whole CPLX-461; no independently read exact component assay is certified here.',
 'ENZRXN-24491':'Native thermophila beta acetyl-CoA activity; direction is absent. Native 2010 mechanism citation remains unread primary context, not newly verified isolated cleavage.',
 'ENZRXN-541':'Native thermophila source-only presumed sarcinapterin-specific activity. Own comment says it has not been identified. Do not promote to experimental identification or assign eight invented subunits.',
 'ENZRXN-362':'Native barkeri reversible membrane methyltransferase; comment concerns methanol oxidation and possible two-step activity. Preserve limited characterization and distinguish from thermophila presumptive enzyme.',
 'ENZRXN-482':'Native thermophila Pta activity with K+/ammonium alternatives and source membrane location. Assay/kinetic/regulatory statements remain native or exact primary scoped; not all-seven-taxa support.',
 'ENZRXN-481':'Native thermophila Ack activity with Mg2+ and explicit alternative cofactors/substrates. Source homodimer and chemical inhibitors are distinct from physiological regulation.'}
activities=read('results/activity-occurrences.json')
for x in activities:
 a=x['activity'];x['qualified_pathway_context']='qualified native methanogenic context, with limitations' if a in qualified else 'context-only member backlink; not demonstrated catalyst for this methanogenic pathway'
 x['disposition']=qualified.get(a,'Complete own activity/enzyme/taxon context retained. Its direct enzyme species is outside the native methanogenic catalyst set; reaction membership and physiologically-relevant=true alone do not establish pathway participation. No mechanistic assertion or citation is transferred from this context.')
 x['source_original']=next(i['path'] for i in inv if i['frame']==a)
 x['source_sha256']=sha(R/x['source_original'])
put('results/all-45-activity-dispositions.json',activities)
assert len(activities)==45 and sum(x['activity'] in qualified for x in activities)==7
forward=read('results/native-forward-closure.json'); adjacency=collections.defaultdict(set)
for x in forward:adjacency[x['owner']].add(x['target'])
q=set(qualified)|{'CPLX-461'}; todo=list(q)
while todo:
 f=todo.pop()
 for t in adjacency[f]:
  if t not in q:q.add(t);todo.append(t)
materials={x['frame'] for x in read('results/member-material-occurrences.json')};direct=set(read('results/native-closure-summary.json')['direct_taxa']);ranges={'TAX-28890'}
dis=[]
for x in inv:
 f=x['frame'];roles=[]
 if f=='METH-ACETATE-PWY':roles.append('selected source root')
 if x['type']=='Reaction':roles.append('one of six native members; no direct common-name')
 if f in materials:roles.append('native equation material; exact source chemistry and generic scope')
 if f in qualified:roles.append('qualified activity; see all-45 disposition')
 elif x['type']=='Enzymatic-Reaction':roles.append('context-only member backlink activity')
 if f in q:roles.append('qualified forward biological context; no automatic claim or final graph promotion')
 if f=='CPLX-461':roles.append('explicit enzymes-not-used whole-complex context for RXN-12908; retain hierarchy without enables inference')
 if f in direct:roles.append('direct native pathway taxon association; strain/activation scope remains qualified')
 if f in ranges:roles.append('native taxonomic range, not a direct organism observation')
 if x['type']=='Pathway' and f!='METH-ACETATE-PWY':roles.append('boundary/cofactor/superpathway context only; no member expansion')
 if not roles:roles.append('finite acquired context of member-linked activities; retained but not a demonstrated methanogenic-route assertion')
 x=dict(x,roles=roles,reading_scope='Envelope, own-slot inventory, selected biological/identity fields and applicability reviewed; all slots/references mechanically retained. No claim that every literature citation, database backlink, sequence or editorial note was independently scientifically verified.')
 dis.append(x)
put('results/all-native-object-dispositions.json',dis)
regs=read('results/regulation-ledger.json')
for x in regs:
 x['qualified_context']=any(t in qualified for t in x['regulated_entity'])
 x['disposition']='Retain source chemical inhibition with exact activity identity; absent physiologically-relevant slot is not a positive physiological-regulation claim. Primary-specific limitations in claim ledger.' if x['qualified_context'] else 'Unrelated activity context; do not transfer to the methanogenic pathway.'
assert sum(x['qualified_context'] for x in regs)==7
put('results/all-27-regulation-dispositions.json',regs)
comps=read('results/complex-components.json')
for x in comps:x['disposition']='Qualified native hierarchy; coefficients describe source assemblies, not independent stoichiometry verification in every paper.' if x['complex'] in q else 'Context-only other-organism complex; no pathway mechanism transfer.'
put('results/all-component-dispositions.json',comps)
slots=read('results/native-own-slot-ledger.json');refs=read('results/native-reference-occurrences.json')
put('results/own-slot-disposition-summary.json',{'slots':len(slots),'references':len(refs),'slot_roles':dict(collections.Counter(x['role'] for x in slots)),'reference_roles':dict(collections.Counter(x['role'] for x in refs)),'all_owners_disposed':set(x['owner'] for x in slots)<=set(x['frame'] for x in dis),'full_reference_scope':'All nested occurrences retained, including duplicates and low-detail parents; only explicitly selected direct own-slot endpoints and alternative wrappers drive closure. Reference-only source/database/editorial/class/backlink objects are not promoted.'})
print(json.dumps({'objects':len(dis),'qualified_activities':7,'context_only_activities':38,'regulations':len(regs),'qualified_regulations':7,'components':len(comps),'qualified_component_occurrences':sum(x['complex'] in q for x in comps)}))
