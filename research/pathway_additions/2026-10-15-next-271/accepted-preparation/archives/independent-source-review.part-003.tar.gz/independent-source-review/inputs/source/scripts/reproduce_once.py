from pathlib import Path
import hashlib,json,subprocess
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
names=['native-object-inventory.json','native-own-slot-ledger.json','native-reference-occurrences.json','native-forward-closure.json','native-comments.json','native-citation-leads.json','complex-components.json','gene-ledger.json','taxon-ledger.json','regulation-ledger.json','material-identity-ledger.json','member-equations.json','member-material-occurrences.json','activity-occurrences.json','native-closure-summary.json','all-45-activity-dispositions.json','all-native-object-dispositions.json','all-27-regulation-dispositions.json','all-component-dispositions.json','own-slot-disposition-summary.json','claim-ledger.json']
paths=[R/'results'/n for n in names]+[R/'reading/native-noneditorial-own-slots.txt']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(R)):digest(p) for p in paths};commands=[]
for script in ['build_native_ledgers.py','assess_native_scope.py','build_claims.py']:
 cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B',str(R/'scripts'/script)]
 with (R/'results'/('reproduce-'+script+'.stdout')).open('wb') as out,(R/'results'/('reproduce-'+script+'.stderr')).open('wb') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
 commands.append({'command':cmd,'exit_code':r.returncode});assert r.returncode==0
after={str(p.relative_to(R)):digest(p) for p in paths};assert before==after
(R/'results/deterministic-reproduction.json').write_text(json.dumps({'all_passed':True,'outputs':len(paths),'before':before,'after':after,'commands':commands,'scope':'Offline author ledger reproduction from exact retained originals; no scientific self-acceptance or new network retrieval.'},indent=2)+'\n')
print(json.dumps({'all_passed':True,'byte_identical_outputs':len(paths)}))
