from pathlib import Path
import concurrent.futures,datetime,hashlib,json,sys,urllib.request,urllib.error
R=Path('/private/tmp/pathwaymech-next-271-source-preparation');batch=sys.argv[1]
jobs=json.loads((R/'inputs'/f'{batch}-jobs.json').read_text())
def get(job):
 result=dict(job,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rp=R/'receipts'/f"{batch}-{job['name']}.json";assert not rp.exists();body=None
 try:
  req=urllib.request.Request(job['url'],headers={'User-Agent':'Mozilla/5.0 (compatible; PathwayMech source research)'})
  with urllib.request.urlopen(req,timeout=50) as h:body=h.read();result.update(status=h.status,final_url=h.url,headers=dict(h.headers))
 except urllib.error.HTTPError as e:body=e.read();result.update(status=e.code,error=repr(e),headers=dict(e.headers))
 except Exception as e:result['error']=repr(e)
 if body is not None:
  p=R/job['output'];assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body);result.update(bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),pdf_magic=body.startswith(b'%PDF-'),xml_or_html_prefix=body[:150].decode('ascii',errors='replace'))
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();rp.write_text(json.dumps(result,indent=2)+'\n');print(job['name'],result.get('status'),result.get('bytes'),result.get('pdf_magic'),result.get('error',''),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:out=list(pool.map(get,jobs))
(R/'results'/f'{batch}-summary.json').write_text(json.dumps([{'name':x['name'],'status':x.get('status'),'pdf_magic':x.get('pdf_magic'),'error':x.get('error')} for x in out],indent=2)+'\n')
