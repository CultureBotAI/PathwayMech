from pathlib import Path
import concurrent.futures,datetime,hashlib,json,sys,urllib.request,urllib.error,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-source-preparation');batch=sys.argv[1];attempt=sys.argv[2]
jobs=json.loads((R/'results'/f'{batch}-jobs.json').read_text())
def get(job):
 encoded=job['output'].split('/')[-1].removeprefix('META-').removesuffix('.xml');name=f'{batch}-{encoded}-{attempt}'
 rp=R/'receipts'/(name+'.json');assert not rp.exists();result=dict(job,batch=batch,attempt=attempt,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());body=None
 try:
  req=urllib.request.Request(job['url'],headers={'User-Agent':'PathwayMech-source-research/1.0'})
  with urllib.request.urlopen(req,timeout=50) as h:body=h.read();result.update(status=h.status,final_url=h.url,headers=dict(h.headers))
 except urllib.error.HTTPError as e:body=e.read();result.update(status=e.code,error=repr(e),headers=dict(e.headers))
 except Exception as e:result['error']=repr(e)
 if body is not None:
  bp=R/'originals/native-attempts'/(name+'.body');bp.parent.mkdir(exist_ok=True);bp.write_bytes(body);result.update(body=str(bp.relative_to(R)),bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
  try:
   root=E.fromstring(body);objs=[x for x in root if x.tag!='metadata'];o=objs[0];f=job['frame']
   assert root.tag=='ptools-xml' and len(objs)==1 and root.findtext('metadata/query')=='META:'+f and root.findtext('metadata/num_results')=='1'
   assert o.get('frameid')==f and o.get('ID')=='META:'+f and o.get('orgid')=='META' and o.get('detail')=='full'
   assert root.find('metadata/PGDB').get('version')=='27.0' and root.find('metadata/PGDB').get('orgid')=='META'
   result['native_validation']={'accepted_exact_full':True,'type':o.tag,'attributes':dict(o.attrib),'query':root.findtext('metadata/query'),'pgdb_version':'27.0','xml_base':root.get('{http://www.w3.org/XML/1998/namespace}base')}
   dst=R/job['output'];assert not dst.exists();dst.write_bytes(body)
  except Exception as e:result['native_validation']={'accepted_exact_full':False,'error':repr(e)}
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();rp.write_text(json.dumps(result,indent=2)+'\n')
 print(job['frame'],result.get('status'),result.get('native_validation',{}).get('accepted_exact_full'),result.get('error',''),flush=True)
 return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(get,jobs))
out={'batch':batch,'attempt':attempt,'jobs':len(jobs),'accepted':sum(x.get('native_validation',{}).get('accepted_exact_full',False) for x in results),'failed':[x['frame'] for x in results if not x.get('native_validation',{}).get('accepted_exact_full',False)]}
(R/'results'/f'{batch}-{attempt}-summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
