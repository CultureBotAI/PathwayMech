from pathlib import Path
import datetime,hashlib,json,os,subprocess
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
assert not (R/'artifact-manifest.json').exists() and not (R/'freeze-proof.json').exists()
audit=json.loads((R/'results/integrity-checks.json').read_text());repro=json.loads((R/'results/deterministic-reproduction.json').read_text());assert audit['all_passed'] and repro['all_passed']
for x in json.loads((R/'inputs/predecessor-bindings.json').read_text()):assert sha(Path(x['source']))==x['sha256']==sha(R/x['copy'])
for x in json.loads((R/'results/native-provenance-index.json').read_text()):assert sha(R/x['body'])==x['sha256']
for x in json.loads((R/'results/claim-ledger.json').read_text()):
 for e in x['evidence']:assert sha(R/e['path'])==e['sha256']
ps=subprocess.run(['ps','-Ao','pid=,command='],text=True,capture_output=True,check=True)
tokens=['acquire_native.py','acquire_primary.py','build_native_ledgers.py','assess_native_scope.py','build_claims.py','audit_packet.py','reproduce_once.py','read_pdf ']
live=[s for s in ps.stdout.splitlines() if str(R) in s and any(t in s for t in tokens)]
assert not live,live
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
put('results/final-operation-receipt.json',{'checked_utc':now,'known_owned_workers_live':live,'process_scope':'Exact current owner plus named acquisition/render/ledger/audit/reproduction workers only. Unrelated processes excluded.','terminal_tool_handles':{'21524':0,'67488':0,'39782':0,'98301':0,'58834':0,'39416':0,'8698':0,'46511':0,'17083':0,'2673':0,'64084':0,'65775':0,'39643':1},'known_failure':'39643 first claim-builder receipt path typo; preserved and corrected before release.','all_final_checks_passed':True,'integrity_assertions':audit['count'],'deterministic_outputs':repro['outputs'],'freeze_process':'This receipt precedes the final inventory. Terminal freezer exit is reported separately, never pre-attested here.'})
files=[]
for p in sorted(R.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file():files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
put('artifact-manifest.json',{'schema_version':1,'scope':'Complete bounded next271 native/primary source preparation; no maintained or scientific acceptance claim.','inventory_includes_hidden_and_ignored':True,'nested_archives':'Opaque retained predecessor bytes; no new recursive scientific or global history inspection.','exclusions':['artifact-manifest.json','freeze-proof.json'],'file_count':len(files),'listed_bytes':sum(x['bytes'] for x in files),'files':files})
for x in files:assert (R/x['path']).stat().st_size==x['bytes'] and sha(R/x['path'])==x['sha256']
put('freeze-proof.json',{'frozen':True,'frozen_utc':now,'manifest_sha256':sha(R/'artifact-manifest.json'),'listed_files':len(files),'physical_files':len(files)+2,'handoff_sha256':sha(R/'HANDOFF.md'),'assessment_sha256':sha(R/'ASSESSMENT.md'),'all_manifest_members_rehashed':True,'known_owned_workers_live':[],'limits':'Author preparation only; independent review and actual270 merged-baseline rebind remain required. No further writes authorized inside this frozen owner.'})
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()};assert actual=={x['path'] for x in files}|{'artifact-manifest.json','freeze-proof.json'}
print(json.dumps({'owner':str(R),'listed_files':len(files),'physical_files':len(actual),'listed_bytes':sum(x['bytes'] for x in files),'manifest_sha256':sha(R/'artifact-manifest.json'),'handoff_sha256':sha(R/'HANDOFF.md'),'freeze_sha256':sha(R/'freeze-proof.json'),'integrity_assertions':audit['count'],'reproduced_outputs':repro['outputs'],'all_passed':True},indent=2))
