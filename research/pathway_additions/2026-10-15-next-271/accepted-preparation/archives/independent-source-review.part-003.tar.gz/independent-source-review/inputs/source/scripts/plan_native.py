from pathlib import Path
import json,hashlib,shutil,sys,urllib.parse,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-source-preparation');batch=sys.argv[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
objects={}
for p in (R/'originals/native').glob('*.xml'):
 root=E.parse(p).getroot();o=next(x for x in root if x.tag!='metadata');objects[o.get('frameid')]=(p,o)
root=objects['METH-ACETATE-PWY'][1];members=[x.get('frameid') for x in root.findall('reaction-list/Reaction')]
occ=[]
def add(owner,slot,i,node,role):
 if node.get('frameid'):occ.append({'owner':owner,'slot':slot,'own_slot_index':i,'target':node.get('frameid'),'type':node.tag,'role':role})
if batch=='direct':
 for f in members:
  o=objects[f][1]
  for i,s in enumerate(o,1):
   if s.tag in ('left','right','enzymatic-reaction','enzymes-not-used'):
    for x in s:
     if x.get('frameid'):add(f,s.tag,i,x,{'left':'equation-material','right':'equation-material','enzymatic-reaction':'member-linked-activity','enzymes-not-used':'explicit-excluded-catalyst-context'}[s.tag])
    for x in s.findall('compartment/*'):add(f,s.tag,i,x,'equation-location')
 for i,s in enumerate(root,1):
  if s.tag in ('species','taxonomic-range','pathway-link','super-pathways'):
   for x in s.iter():
    if x is not s and x.get('frameid'):add('METH-ACETATE-PWY',s.tag,i,x,'direct-pathway-organism' if s.tag=='species' else 'bounded-pathway-context')
else:
 follow={'Enzymatic-Reaction':{'enzyme','cofactor','regulated-by','alternative-substrate','alternative-cofactor'},'Protein':{'component','gene','species','locations','location','cofactor','prosthetic-group','modified-form','unmodified-form','regulated-by'},'Gene':{'product','species','regulated-by'},'Regulation':{'regulator','regulated-entity'}}
 for f,(_,o) in objects.items():
  if o.get('class')=='true':continue
  for i,s in enumerate(o,1):
   if s.tag not in follow.get(o.tag,set()):continue
   endpoints=list(s)
   if s.tag in ('alternative-substrate','alternative-cofactor'):
    endpoints=[x for wrapper in s if wrapper.tag in ('substrate','cofactor','alternate') for x in wrapper]
   for x in endpoints:
    if x.tag not in ('Evidence-Code','Publication','Person','Organization'):add(f,s.tag,i,x,'biological-forward-context; pathway qualification separate')
 for i,s in enumerate(root,1):
  if s.tag=='pathway-link':
   for x in s.iter():
    if x is not s and x.get('frameid'):add('METH-ACETATE-PWY',s.tag,i,x,'boundary-only pathway/material context; no member expansion')
by={}
for x in occ:by.setdefault(x['target'],[]).append(x)
cat={x['frame']:x for x in json.loads((R/'inputs/frozen270-reuse-catalog.json').read_text())};reused=[];jobs=[]
for f,reasons in sorted(by.items()):
 if f in objects:continue
 encoded=urllib.parse.quote(f,safe='-._+')
 output='originals/native/META-'+encoded+'.xml'
 if f in cat and cat[f]['receipts']:
  x=cat[f];p=Path(x['path']);b=p.read_bytes();assert sha(b)==x['sha256'];(R/output).write_bytes(b);rpaths=[]
  for rp in x['receipts']:
   p=Path(rp);dst=R/'inputs/frozen270-receipts'/p.name;dst.parent.mkdir(exist_ok=True);rb=p.read_bytes()
   if dst.exists():assert dst.read_bytes()==rb
   else:dst.write_bytes(rb)
   rpaths.append({'source':rp,'copy':str(dst.relative_to(R)),'sha256':sha(rb)})
  reused.append(dict(x,copy=output,reasons=reasons,copied_receipts=rpaths,mode='exact frozen270 body/version and receipt reuse; no fresh retrieval'))
 else:jobs.append({'frame':f,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+encoded,'output':output,'reasons':reasons})
put('results/'+batch+'-occurrences.json',occ);put('receipts/'+batch+'-reuses.json',reused);put('results/'+batch+'-jobs.json',jobs)
print(json.dumps({'batch':batch,'occurrences':len(occ),'targets':len(by),'reused':len(reused),'network_jobs':len(jobs),'already_full':len(set(by)&set(objects))}))
