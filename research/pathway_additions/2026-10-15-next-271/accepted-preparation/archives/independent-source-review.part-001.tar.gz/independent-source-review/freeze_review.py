from pathlib import Path
import json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'artifact-manifest.json').exists() and not (O/'freeze-proof.json').exists()
assert not any(p.is_symlink() for p in O.rglob('*'))
assert json.loads((O/'RESULT.json').read_text())['status']=='qualified_acceptance'
rows=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file()]
manifest={'schema_version':1,'scope':'Independent bounded next271 source/primary preparation review; no maintained/issuer/global novelty acceptance.','inventory_includes_hidden_and_ignored':True,'compressed_scope':'Predecessor archive bytes were bound but not newly recursively decoded or scientifically reread.','exclusions':['artifact-manifest.json','freeze-proof.json'],'file_count':len(rows),'listed_bytes':sum(x['bytes'] for x in rows),'files':rows}
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'review_sha256':sha(O/'REVIEW.md'),'result_sha256':sha(O/'RESULT.json'),'listed_files':len(rows),'physical_files':len(rows)+2,'listed_bytes':manifest['listed_bytes'],'all_owned_commands_terminal':True,'no_live_source_writer_or_task':True,'scope':'Only this reviewer owner frozen; no claim about unrelated peer/root processes.','no_further_writes_planned':True}
(O/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n')
actual={str(p.relative_to(O)) for p in O.rglob('*') if p.is_file()};assert actual=={x['path'] for x in rows}|{'artifact-manifest.json','freeze-proof.json'}
for x in rows:assert sha(O/x['path'])==x['sha256'] and (O/x['path']).stat().st_size==x['bytes']
print(json.dumps({'owner':str(O),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'freeze_sha256':sha(O/'freeze-proof.json'),'review_sha256':sha(O/'REVIEW.md'),'listed':len(rows),'physical':len(rows)+2,'listed_bytes':manifest['listed_bytes']},indent=2))
