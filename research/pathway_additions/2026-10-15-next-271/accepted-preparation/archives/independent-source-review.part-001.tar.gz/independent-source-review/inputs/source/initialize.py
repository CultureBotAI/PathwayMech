from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
P=Path('/private/tmp/pathwaymech-next-271-independent-preflight-review')
S=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
for d in ['inputs','originals/native','originals/primary','receipts','results','reading','scripts']:(R/d).mkdir(parents=True,exist_ok=True)
man=json.loads((P/'artifact-manifest.json').read_text());assert sha((P/'artifact-manifest.json').read_bytes())=='493020bca61eaaea938a0c3730ebf6fabc5fc036698776fc963fbbccce44bf23'
expected={x['path']:x for x in man['files']};physical=[x for x in P.rglob('*') if x.is_file()];assert len(physical)==499
assert {x.relative_to(P).as_posix() for x in physical}==set(expected)|{'artifact-manifest.json','freeze-proof.json'}
bindings=[]
for p in physical:
 assert not p.is_symlink()
 b=p.read_bytes();rel=p.relative_to(P).as_posix()
 if rel in expected:assert sha(b)==expected[rel]['sha256'] and len(b)==expected[rel]['bytes']
 target=R/'inputs/accepted-preflight'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 bindings.append({'source':str(p),'copy':str(target.relative_to(R)),'bytes':len(b),'sha256':sha(b)})
put('inputs/predecessor-bindings.json',bindings)
D=R/'inputs/accepted-preflight/inputs/discovery'
sources=[(D/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml',D/'inputs/prior-next270-discovery/results/acquisition-network-METH-ACETATE-PWY.json')]
for row in json.loads((D/'results/acquired-originals-verified.json').read_text()):sources.append((D/row['path'],D/row['receipt']))
reuses=[]
for p,receipt in sources:
 o=E.parse(p).getroot();obj=next(x for x in o if x.tag!='metadata');frame=obj.get('frameid');target=R/'originals/native'/('META-'+frame+'.xml');target.write_bytes(p.read_bytes())
 reuses.append({'frame':frame,'source':str(p.relative_to(R)),'receipt':str(receipt.relative_to(R)),'copy':str(target.relative_to(R)),'sha256':sha(p.read_bytes()),'mode':'unchanged accepted discovery original; no fresh retrieval'})
put('receipts/discovery-native-reuse.json',reuses)
sm=json.loads((S/'artifact-manifest.json').read_text());si={x['path']:x for x in sm['files']};catalog=[]
for p in sorted((S/'originals/native').glob('*.xml')):
 rel=p.relative_to(S).as_posix();b=p.read_bytes();assert sha(b)==si[rel]['sha256']
 try:
  root=E.fromstring(b);os=[x for x in root if x.tag!='metadata'];o=os[0]
  assert len(os)==1 and o.get('detail')=='full' and o.get('orgid')=='META' and root.findtext('metadata/query')=='META:'+o.get('frameid')
 except Exception:continue
 receipts=[]
 for rp in (S/'receipts').glob('*.json'):
  x=json.loads(rp.read_text())
  if (x.get('output')==rel and x.get('status')==200) or x.get('copy')==rel:receipts.append(str(rp))
 catalog.append({'frame':o.get('frameid'),'type':o.tag,'class':o.get('class')=='true','path':str(p),'sha256':sha(b),'bytes':len(b),'source_manifest':str(S/'artifact-manifest.json'),'manifest_sha256':sha((S/'artifact-manifest.json').read_bytes()),'receipts':receipts})
put('inputs/frozen270-reuse-catalog.json',catalog)
for n in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md','ASSESSMENT.md']:
 target=R/'inputs/frozen270-source'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((S/n).read_bytes())
put('results/initial-operations.json',{'predecessor_physical_verified':len(physical),'native_discovery_reused':len(reuses),'frozen270_catalog':len(catalog),'failed_read_probes':['META-ENZRXN-541.xml not in frozen270 source originals','META-CPLX-322.xml not in frozen270 source originals'],'scope':'Read failures are exact requested paths, not global absence searches; no maintained or frozen-owner mutation.'})
print(json.dumps({'copied_preflight':len(physical),'reused_native':len(reuses),'catalog':len(catalog)}))
