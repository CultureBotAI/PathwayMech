from pathlib import Path
import json, hashlib, collections, xml.etree.ElementTree as E, urllib.parse, re
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
O=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
checks=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,v):
    checks.append({'check':n,'passed':bool(v)})
    if not v: raise AssertionError(n)
def j(p): return json.loads(p.read_text())
def store(n,v): (O/'results'/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
discovery=[]
for x in j(R/'receipts/discovery-native-reuse.json'):
    p=R/x['source']; q=R/x['copy']; receipt=R/x['receipt']; rr=j(receipt)
    ck(x['frame']+' discovery exact original',p.read_bytes()==q.read_bytes() and sha(p)==x['sha256'])
    ck(x['frame']+' original successful receipt',rr['status']==200 and rr['sha256']==sha(p))
    ck(x['frame']+' original exact query',urllib.parse.unquote(urllib.parse.urlsplit(rr['url']).query)=='META:'+x['frame'])
    discovery.append({'frame':x['frame'],'body_sha256':sha(p),'receipt':x['receipt'],'receipt_sha256':sha(receipt),'status':rr['status'],'url':rr['url'],'reused_not_fresh':True})
ck('nine discovery reuses',len(discovery)==9)
reuses=[]
for rp in [R/'receipts/direct-reuses.json',*sorted((R/'receipts').glob('closure*-reuses.json'))]:
    for x in j(rp):
        p=Path(x['path']); q=R/x['copy']; manifest=Path(x['source_manifest'])
        ck(x['frame']+' earlier manifest identity',sha(manifest)==x['manifest_sha256'])
        row=next(v for v in j(manifest)['files'] if v['path']==str(p.relative_to(manifest.parent)))
        ck(x['frame']+' earlier manifest member',row['sha256']==sha(p)==x['sha256'] and row['bytes']==len(p.read_bytes())==x['bytes'])
        ck(x['frame']+' reused body exact',p.read_bytes()==q.read_bytes())
        copies=[]
        for c in x['copied_receipts']:
            src=Path(c['source']); dest=R/c['copy']; rr=j(dest)
            ck(x['frame']+' historical receipt exact '+src.name,src.read_bytes()==dest.read_bytes() and sha(src)==c['sha256'])
            copies.append({'receipt':c['copy'],'sha256':sha(dest),'keys':sorted(rr) if isinstance(rr,dict) else 'list'})
            if isinstance(rr,dict) and rr.get('status')==200:
                ck(x['frame']+' historical 200 binding',rr['sha256']==sha(q))
                ck(x['frame']+' historical 200 query',urllib.parse.unquote(urllib.parse.urlsplit(rr['url']).query)=='META:'+x['frame'])
        reuses.append({'frame':x['frame'],'body_sha256':sha(q),'source_manifest_sha256':sha(manifest),'receipts':copies,'reused_not_fresh':True})
ck('19 distinct frozen270 reuses',len(reuses)==len({x['frame'] for x in reuses})==19)
na=j(R/'receipts/NA-reuse-chain.json')
for x in na['bindings']:
    ck('NA historical binding '+x['copy'],Path(x['source']).read_bytes()==(R/x['copy']).read_bytes() and sha(R/x['copy'])==x['sha256'])
n=na['exact_successful_acquisition']; ck('NA literal bare-query acquisition',n['status']==200 and urllib.parse.urlsplit(n['url']).query=='META:NA+' and n['sha256']==sha(R/'originals/native/META-NA+.xml'))
na_container=j(R/'inputs/frozen269-NA-provenance/receipts/supplements-and-query-retry.json')
def walk(v):
    if isinstance(v,dict):
        yield v
        for w in v.values(): yield from walk(w)
    elif isinstance(v,list):
        for w in v: yield from walk(w)
ck('NA exact successful row retained in original container',any(v==n for v in walk(na_container)))
# Every direct primary request is classified by bytes, not by URL or status alone.
access=[]
for rp in sorted((R/'receipts').glob('primary-*.json')):
    rr=j(rp); p=R/rr['output']; b=p.read_bytes()
    ck(rp.name+' exact body',sha(p)==rr['sha256'] and len(b)==rr['bytes'])
    ck(rp.name+' PDF magic truthful',b.startswith(b'%PDF-')==rr['pdf_magic'])
    access.append({'receipt':str(rp.relative_to(R)),'receipt_sha256':sha(rp),'body':rr['output'],'body_sha256':sha(p),'bytes':len(b),'status':rr['status'],'pdf_magic':b.startswith(b'%PDF-'),'url':rr['url']})
ck('40 primary request receipts retained',len(access)==40)
ck('exactly two actual primary PDFs',sum(x['pdf_magic'] for x in access)==2)
# MED identity is separate from full-text access.
abstracts=[]
for pmid,doi,path in [
    ('8824151','10.1007/s002030050384','inputs/accepted-preflight/inputs/discovery/inputs/author-primary-probe/inputs/pmid-8824151.json'),
    ('8626532','10.1074/jbc.271.14.8352','originals/primary/epmc-8626532.json'),
    ('11607176','10.1073/pnas.88.8.3272','originals/primary/epmc-11607176.json'),
    ('12657792','10.1107/s0907444903001987','originals/primary/epmc-12657792.json')]:
    doc=j(R/path); rs=doc['resultList']['result']; ck(pmid+' single MED result',len(rs)==1 and rs[0]['id']==pmid and rs[0]['source']=='MED'); a=rs[0]
    ck(pmid+' matching DOI',a['doi'].lower()==doi.lower()); ck(pmid+' substantive abstract',len(a['abstractText'])>400)
    abstracts.append({'pmid':pmid,'doi':a['doi'],'path':path,'sha256':sha(R/path),'title':a['title'],'abstract_characters':len(a['abstractText']),'scope':'complete indexed primary abstract, not full main'})
nc=E.parse(R/'originals/primary/ncbi-efetch-11607176.xml').getroot()
ck('11607176 metadata contains exact PMID',any(e.text=='11607176' for e in nc.iter('article-id') if e.get('pub-id-type')=='pmid'))
ck('11607176 metadata body genuinely absent',nc.find('.//body') is None)
# Native chemical strings and classes are inspected literally, not normalized into identities.
materials=[]
for frame in ['CPD-8','CPD-9','CoM','Me-CoM','ATP','CoI-Corrinoid-Fe-S-proteins','Methylated-corrinoid-Fe-S-Proteins','Oxidized-ferredoxins','Reduced-ferredoxins']:
    p=R/f'originals/native/META-{frame}.xml'; n=next(e for e in E.parse(p).getroot() if e.tag!='metadata'); m=n.find('cml/molecule'); f=n.find('cml/molecule/formula')
    materials.append({'frame':frame,'sha256':sha(p),'type':n.tag,'class':n.get('class'),'formula':f.get('concise') if f is not None else None,'charge':m.get('formalCharge') if m is not None else None,'smiles':n.findtext("cml/molecule/string[@title='smiles']"),'inchi':n.findtext('inchi'),'own_compartments':[e.tag for e in n if e.tag in ('compartment','location','locations')]})
a,b=materials[:2]; ck('CPD8/9 distinct formula and InChI',a['formula']!=b['formula'] and a['inchi']!=b['inchi']); ck('CPD8/9 same short SMILES',a['smiles']==b['smiles'] and a['smiles'] is not None)
ck('CoM/MeCoM generic short SMILES',materials[2]['smiles']=='[R]' and materials[3]['smiles']=='C[R]'); ck('ATP generic purine base string','[a purine base]' in materials[4]['smiles'])
ck('four exact native carrier Protein classes',all(x['type']=='Protein' and x['class']=='true' and x['formula'] is None for x in materials[5:]))
# All seven native direct organisms and all member location slots, read from exact originals.
pathway=next(e for e in E.parse(R/'originals/native/META-METH-ACETATE-PWY.xml').getroot() if e.tag=='Pathway')
taxa=[]
for ref in pathway.findall('species/Organism')+pathway.findall('taxonomic-range/Organism'):
    frame=ref.get('frameid'); p=R/f'originals/native/META-{frame}.xml'; n=next(e for e in E.parse(p).getroot() if e.tag!='metadata'); taxa.append({'frame':frame,'sha256':sha(p),'label':n.findtext('common-name'),'rank':n.findtext('rank'),'parents':[x.get('frameid') for x in n.findall('parent/Organism')],'own_dblinks':[E.tostring(x,encoding='unicode') for x in n.findall('dblink')],'scope':'range' if frame=='TAX-28890' else 'direct association'})
ck('seven direct source taxa plus range',len(taxa)==8 and sum(x['scope']=='direct association' for x in taxa)==7)
org=next(x for x in taxa if x['frame']=='ORG-5913'); ck('ORG5913 rank/parent/no own db link',org['rank']=='species' and org['parents']==['TAX-2207'] and org['own_dblinks']==[])
locations=[]
for frame in ['CPLX-322','CPLX-481','PTAMSARC-MONOMER']:
    p=R/f'originals/native/META-{frame}.xml'; n=next(e for e in E.parse(p).getroot() if e.tag=='Protein'); ids=[e.get('frameid') for e in n.findall('location/cco')]; ck(frame+' exact native membrane location',ids==['CCO-MEMBRANE']); locations.append({'frame':frame,'sha256':sha(p),'native_location_ids':ids,'scope':'source protein localization; not reaction material compartment or membrane side'})
store('supplemental-binding-checks.json',checks)
store('supplemental-binding-summary.json',{'checks':len(checks),'discovery_reuses':discovery,'frozen270_reuses':reuses,'NA_chain_scope':'Only exact native sodium original, manifest entry and successful literal query row rebound; unrelated outputs in historical receipt not replayed.','primary_access':access,'abstracts':abstracts,'native_chemical_diagnostics':materials,'direct_native_taxa_and_range':taxa,'native_protein_locations':locations})
print('PASS',len(checks),'checks; primary requests',len(access),'PDFs',sum(x['pdf_magic'] for x in access),'discovery reuses',len(discovery),'frozen270 reuses',len(reuses))
