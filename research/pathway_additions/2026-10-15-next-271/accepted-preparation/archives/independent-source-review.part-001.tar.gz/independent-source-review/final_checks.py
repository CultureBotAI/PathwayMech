from pathlib import Path
import hashlib,json,datetime
R=Path('/private/tmp/pathwaymech-next-271-source-preparation');O=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((R/'artifact-manifest.json').read_text()); expected={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}; assert actual==expected and not any(p.is_symlink() for p in R.rglob('*'))
for x in m['files']:
 p=R/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],x['path']
releases={'artifact-manifest.json':'06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5','HANDOFF.md':'c4c05803d9e57dc6a3c212be7be3dc798b98ec24e3e48d7b1c07325674a7798d','freeze-proof.json':'1dd9ff1f6c7242725cd083e354ed728e8bf59133cd1f5ba7037bd80976d719fa'}
for n,h in releases.items(): assert sha(R/n)==h
initial=json.loads((O/'results/source-intake.json').read_text())
for x in initial['retained_selected']:
 p=O/'inputs/source'/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],str(p)
claims=json.loads((O/'results/independent-claim-dispositions.json').read_text());assert len(claims)==32 and {c['claim_id'] for c in claims}=={f'N{i:02}' for i in range(1,21)}|{f'P{i:02}' for i in range(1,13)}
for name in ['independent-native-checks.json','supplemental-binding-checks.json']:
 rows=json.loads((O/'results'/name).read_text());assert all(x['passed'] for x in rows)
assert len(json.loads((O/'results/publisher-content-bindings.json').read_text()))==11
for x in json.loads((O/'results/visual-reading-bindings.json').read_text()):assert sha(Path(x['source']))==sha(O/x['copy'])==x['sha256']
result={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_owner':str(R),'release_hashes':releases,'all_1708_physical_source_files_unchanged':True,'listed_bytes':sum(x['bytes'] for x in m['files']),'selected_input_copies_verified':len(initial['retained_selected']),'all32_independent_claim_dispositions_present':True,'native_checks':2803,'supplemental_checks':253,'publisher_claim_receipt_bindings':11,'visual_images_bound':3,'hidden_and_ignored_included':True,'no_fresh_recursive_compressed_content_review':True,'source_only_bounded_review_not_maintained_or_issuer_acceptance':True}
(O/'results/final-integrity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
