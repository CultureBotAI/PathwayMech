from pathlib import Path
import json,hashlib,gzip,xml.etree.ElementTree as E,collections
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=O/'inputs/frozen-issuer';NS='http://rdf.rhea-db.org/';RD='http://www.w3.org/1999/02/22-rdf-syntax-ns#'
checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
graph=collections.defaultdict(list);count=0
with gzip.open(R/'originals/rhea.rdf.gz','rb') as handle:
 for _,node in E.iterparse(handle,events=['end']):
  if node.tag!='{'+RD+'}Description':continue
  count+=1;uri=node.attrib['{'+RD+'}about']
  for child in node:
   namespace,local=child.tag[1:].split('}',1);graph[uri].append({'predicate':namespace+local,'resource':child.get('{'+RD+'}resource'),'literal':child.text,'attributes':dict(child.attrib)})
  node.clear()
ck('complete pinned RDF description count',count==326097)
def values(uri,pred):return [t['resource'] if t['resource'] is not None else t['literal'] for t in graph[uri] if t['predicate']==pred]
def single(uri,pred):
 v=set(values(uri,NS+pred));ck(uri+' unique '+pred,len(v)==1);return next(iter(v))
author=json.loads((R/'results/rhea-all-bounded-replay.json').read_text());selected=author['complete_selected_statements']
for uri,rows in selected.items():ck(uri+' complete selected original statements',graph[uri]==rows)
seeds={'17829','21040','11355','19524','45196','45212'};families=[]
for line in (R/'originals/rhea-directions.tsv').read_text().splitlines()[1:]:
 cols=line.split('\t')
 if seeds&set(cols):families.append(cols)
ck('five selected directional families',len(families)==5);ck('only obsolete seed outside direction table',seeds-{v for row in families for v in row}=={'17829'})
ck('17829 exact obsolete status',values(NS+'17829',NS+'status')==[NS+'Obsolete'])
comments=values(NS+'17829','http://www.w3.org/2000/01/rdf-schema#comment');ck('17829 literal replacement comment','RHEA:17829 has been replaced by RHEA:21040' in comments)
ck('no structured replacedBy asserted',values(NS+'17829',NS+'replacedBy')==[])
equations=[]
for master,ltr,rtl,bidir in families:
 pairs=[]
 for ident in [ltr,rtl]:
  terms={}
  for role in ['substrates','products']:
   side=single(NS+ident,role);rows=[]
   for t in graph[side]:
    pred=t['predicate']
    if not pred.startswith(NS+'contains') or pred==NS+'contains':continue
    coeff=pred.removeprefix(NS+'contains');ck(ident+' integer exact stoichiometry',coeff.isdigit());participant=t['resource'];compound=single(participant,'compound')
    rows.append({'coefficient':int(coeff),'participant':participant,'compound':compound,'accession':values(compound,NS+'accession'),'name':values(compound,NS+'name'),'formula':values(compound,NS+'formula'),'charge':values(compound,NS+'charge'),'chebi':values(compound,NS+'chebi'),'underlyingChebi':values(compound,NS+'underlyingChebi'),'reactivePart':values(compound,NS+'reactivePart'),'location':values(participant,NS+'location')})
   terms[role]=rows
  a=next(x for x in author['equations'] if x['id']==ident);ck(ident+' exact equation and material roles',a['substrates']==terms['substrates'] and a['products']==terms['products'] and a['equation']==values(NS+ident,NS+'equation'))
  equations.append({'id':ident,'master':master,'equation':values(NS+ident,NS+'equation'),**terms});pairs.append(terms)
 def signature(rows):return sorted((x['compound'],x['coefficient'],tuple(x['location'])) for x in rows)
 ck(master+' exact reverse stoichiometry',signature(pairs[0]['substrates'])==signature(pairs[1]['products']) and signature(pairs[0]['products'])==signature(pairs[1]['substrates']))
# Explicit narrower reactive-part interpretation in21040 family, rather than generic native carrier alias.
e=next(x for x in equations if x['master']=='21040');names=[n for role in ['substrates','products'] for t in e[role] for n in t['name']]
ck('21040 explicit2Fe2S carrier scope',any('[2Fe-2S]' in n for n in names))
result={'checks':checks,'description_count':count,'source_sha256':hashlib.sha256((R/'originals/rhea.rdf.gz').read_bytes()).hexdigest(),'release_properties':(R/'originals/rhea-release.properties').read_text(),'families':families,'obsolete_seed':graph[NS+'17829'],'equations':equations,'selected_statement_uris':sorted(selected),'scope':'Complete RDF parsed for bounded selected statement replay only. Historical142 acquisition metadata retained; no current release, global discovery or generic-carrier exact alias claim.'}
(O/'results/independent-rhea.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS',len(checks),'Rhea checks;',count,'descriptions parsed;',len(selected),'selected URI statement sets;',len(equations),'directional equations')
