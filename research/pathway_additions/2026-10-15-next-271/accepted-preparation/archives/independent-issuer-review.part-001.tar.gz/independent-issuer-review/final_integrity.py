from pathlib import Path
import json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
releases=[('/private/tmp/pathwaymech-next-271-issuer-preparation','7a3d6b3991b7ca720ae7ff79620e5a25f107127bc84bc5b58785510df397a950',879,881),('/private/tmp/pathwaymech-next-271-source-preparation','06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5',1706,1708),('/private/tmp/pathwaymech-next-271-independent-source-review','d18d6d594d87721ff4e4e53b69a1fecf166b645357d5c571c2604e95e2f9cd2d',1011,1013)]
rows=[]
for path,digest,listed,physical in releases:
 p=Path(path);assert sha(p/'artifact-manifest.json')==digest;m=json.loads((p/'artifact-manifest.json').read_text());actual={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()};assert actual=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'};assert len(m['files'])==listed and len(actual)==physical;assert not any(x.is_symlink() for x in p.rglob('*'))
 for x in m['files']:assert sha(p/x['path'])==x['sha256'] and (p/x['path']).stat().st_size==x['bytes'],(path,x['path'])
 rows.append({'owner':path,'manifest_sha256':digest,'listed':listed,'physical':physical,'all_listed_exact':True,'complete_physical_inventory_including_hidden_ignored':True,'freeze_sha256':sha(p/'freeze-proof.json'),'HANDOFF_sha256':sha(p/'HANDOFF.md')})
intake=json.loads((O/'results/issuer-intake.json').read_text())
for x in intake['files']:
 p=O/'inputs/frozen-issuer'/x['path'];assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes'];assert sha(Path(intake['owner'])/x['path'])==x['sha256']
for x in json.loads((O/'prepared-inputs-manifest.json').read_text())['files']:
 p=O/x['path'];assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes']
counts={}
for name in ['independent-chemistry','independent-sequences-taxonomy','independent-rhea','independent-bindings','independent-representation-limits']:
 v=json.loads((O/'results'/f'{name}.json').read_text());assert all(x['passed'] for x in v['checks']);counts[name]=len(v['checks'])
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frozen_owners':rows,'issuer_copy_files_exact':len(intake['files']),'prepared_files_exact':len(json.loads((O/'prepared-inputs-manifest.json').read_text())['files']),'independent_check_counts':counts,'independent_checks_total':sum(counts.values()),'scope':'Final original/copy integrity and bounded independent result integrity. No new taxonomy whole-cache hash, global primary review, maintained suite or acceptance.'}
(O/'results/final-integrity.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',sum(x['physical'] for x in rows),'original physical files;',len(intake['files']),'issuer copies;',sum(counts.values()),'bounded independent checks')
