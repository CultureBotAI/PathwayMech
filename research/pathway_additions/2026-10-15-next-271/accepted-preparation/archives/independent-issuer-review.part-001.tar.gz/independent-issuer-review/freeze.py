from pathlib import Path
import json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'artifact-manifest.json').exists() and not (O/'freeze-proof.json').exists()
result=json.loads((O/'RESULT.json').read_text());result['review_finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['chemistry','sequences-taxonomy','rhea','bindings','representation','final-integrity']:
 assert (O/(name+'.stdout')).read_text().startswith('PASS'),name
assert not any(p.is_symlink() for p in O.rglob('*'))
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file()]
m={'owner':str(O),'reviewer':'/root/next268_reaction_review_completion','scope':'Complete frozen independent issuer-review owner, including exact copied inputs, failed attempts and terminal results.','excluded_self_reference':['artifact-manifest.json','freeze-proof.json'],'hidden_and_ignored_included':True,'files':files}
(O/'artifact-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
f={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'independent_checks':result['independent_checks'],'all_owned_handles_terminal':True,'terminal_scope':'Observed execution-handle exits for final scripts, with initial failed harness attempts retained; no ps-based absence claim.','frozen':True,'no_further_writes':True}
(O/'freeze-proof.json').write_text(json.dumps(f,indent=2)+'\n')
assert {str(p.relative_to(O)) for p in O.rglob('*') if p.is_file()}=={x['path'] for x in files}|{'artifact-manifest.json','freeze-proof.json'}
for x in files:assert sha(O/x['path'])==x['sha256'] and (O/x['path']).stat().st_size==x['bytes'],x['path']
print(json.dumps({'owner':str(O),**f,'HANDOFF_sha256':sha(O/'HANDOFF.md'),'REVIEW_sha256':sha(O/'REVIEW.md'),'RESULT_sha256':sha(O/'RESULT.json'),'freeze_sha256':sha(O/'freeze-proof.json')},indent=2))
