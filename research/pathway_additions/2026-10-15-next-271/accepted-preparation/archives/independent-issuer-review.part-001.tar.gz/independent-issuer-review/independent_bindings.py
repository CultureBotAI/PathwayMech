from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as E,re,html
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=O/'inputs/frozen-issuer'
checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((R/n).read_text())
plan=load('results/all-269-identity-scope-dispositions.json');selected={x['frame']:x for x in plan if x['selected']};disp=load('results/all-91-issuer-dispositions.json');dp={x['frame']:x for x in disp};ck('exact91 selected dispositions',len(dp)==len(disp)==91 and set(dp)==set(selected))
ck('released269 plan unchanged',sha(R/'results/all-269-identity-scope-dispositions.json')=='a61fc56ef198aba19cd1bae42d5b595f2eb30f72b8dfc567f4e4a048c6fc1719')
objects={};pointer_rows=[];non_dblink=[];roles=[];known=json.loads((O/'inputs/baseline/data/identifier_authorities/sources.json').read_text())['terms']
for f,x in selected.items():
 p=R/dp[f]['native_path'];n=next(e for e in E.parse(p).getroot() if e.tag!='metadata');objects[f]=n
 ck(f+' exact native identity/type/class/hash',n.get('frameid')==f and n.tag==x['type']==dp[f]['type'] and (n.get('class')=='true')==x['class']==dp[f]['class'] and sha(p)==dp[f]['native_sha256']);ck(f+' no alias promoted',dp[f]['alias_promoted'] is False)
 for i,d in enumerate(n.findall('dblink'),1):
  pointer_rows.append((f,n.tag,d.findtext('dblink-db'),d.findtext('dblink-oid'),d.findtext('dblink-relationship'),(d.findtext('dblink-URL') or ''),f"/ptools-xml/{n.tag}[@frameid='{f}']/dblink[{i}]"))
 for tag in ['ec-number','goid','has-go-term']:
  for i,s in enumerate(n.findall(tag),1):non_dblink.append((f,tag,f"/ptools-xml/{n.tag}[@frameid='{f}']/{tag}[{i}]",E.tostring(s,encoding='unicode')))
 ident='MetaCyc:'+f;term=known.get(ident);roles.append({'frame':f,'native_type':n.tag,'class':x['class'],'direct_common_names':[html.unescape(re.sub('<[^>]+>','',s.text or '')) for s in n.findall('common-name')],'direct_synonyms':[html.unescape(re.sub('<[^>]+>','',s.text or '')) for s in n.findall('synonym')],'existing_authority_term':term,'scope':'Existing baseline coverage only, not final graph selection, new authority implementation or renamed native label.'})
pointers=load('results/all-474-selected-pointer-dispositions.json')
def key(x):return tuple(x[k] for k in ['owner','type','db','id','relationship','native_url','locator'])
ck('all474 exact own pointer occurrence multiset',len(pointer_rows)==474 and collections.Counter(pointer_rows)==collections.Counter(key(x) for x in pointers))
for x in pointers:ck(x['locator']+' explicit outcome',bool(x.get('result')) and x['selected_owner'] is True)
flat=[y for x in disp for y in x['direct_pointer_occurrences']];ck('all91 nested pointer sets exact',collections.Counter(key(x) for x in flat)==collections.Counter(pointer_rows))
ck('all10 non-dblink public slots exact',len(non_dblink)==10 and sorted(non_dblink)==sorted(tuple(x[k] for k in ['owner','tag','locator','xml']) for x in load('results/non-dblink-public-pointer-occurrences.json')))
# Exact copied provenance, including original declarations of unsuccessful requests.
index=load('results/issuer-access-and-reuse-index.json');counts=collections.Counter()
for x in index['current_direct_attempts']:
 p=R/x['receipt_file'];ck(x['receipt_file']+' receipt digest',sha(p)==x['receipt_sha256']);entry=json.loads(p.read_text())[x['entry']];ck(x['receipt_file']+str(x['entry'])+' literal original request row',all(x.get(k)==v for k,v in entry.items()))
 if 'status' not in x:
  counts['DNS failures']+=1;ck(x['file']+' failed attempt no invented body claim','sha256' not in x and 'bytes' not in x and 'error' in x);continue
 counts[str(x['status'])]+=1;p=R/x['path'];ck(x['path']+' response body binding',sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
ck('202 exact attempts separated',len(index['current_direct_attempts'])==202 and dict(counts)=={'DNS failures':99,'200':102,'404':1})
reused=index['historical_reuses'];ck('25 reused originals',len(reused)==25)
def resolve(v,loc):
 ck('JSON locator grammar '+loc,loc.startswith('$'));rest=loc[1:]
 while rest:
  m=re.match(r'\.([^\.\[]+)|\[(\d+)\]',rest);ck('JSON locator token '+rest,m is not None);v=v[m[1]] if m[1] is not None else v[int(m[2])];rest=rest[m.end():]
 return v
for x in reused:
 p=R/x['path'];ck(x['path']+' exact reuse hash/length',sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
 for c in x['source_receipts_or_metadata']:
  p=R/c['container'];ck(c['container']+' exact reuse container',sha(p)==c['container_sha256']);v=resolve(json.loads(p.read_text()),c['json_locator']);expected=c.get('receipt',c.get('historical_metadata'));ck(c['container']+' exact selected provenance row',v==expected)
  if 'sha256' in v:ck(x['path']+' provenance body hash',v['sha256']==x['sha256'])
 if not x['source_receipts_or_metadata']:ck(x['path']+' explicit historical receipt limitation',x['path']=='originals/rhea-release.properties' and bool(x['limitation']))
# Rebind all copy declarations to still-frozen originals; not global scientific rereading.
binding_files=['inputs/source-bindings.json','inputs/prior270-bindings.json','inputs/independent-source-review-bindings.json','inputs/provenance-additional-bindings.json','inputs/additional-context-bindings.json']
bound=[]
for name in binding_files:
 for x in load(name):
  p=R/x['copy'];src=Path(x['source']);ck(x['copy']+' copy declared digest',sha(p)==x['sha256'] and p.stat().st_size==x['bytes']);ck(x['copy']+' source unchanged',src.read_bytes()==p.read_bytes());bound.append(x)
go=load('originals/GO-0016020.json');g=go['results'][0];ck('GO exact membrane term only',go['numberOfHits']==1 and g['id']=='GO:0016020' and g['isObsolete'] is False and g['name']=='membrane' and g['aspect']=='cellular_component')
enz=[]
for ident,label in [('2.7.2.1','acetate kinase'),('2.7.2.15','propionate kinase')]:
 p=R/f'originals/EC-{ident}.html';t=html.unescape(re.sub('<[^>]+>',' ',p.read_text()));t=re.sub(r'\s+',' ',t);part=t[t.index('Accepted Name'):t.index('Cross-references')];ck(ident+' exact accepted class name','Accepted Name '+label in part)
 if ident=='2.7.2.15':ck(ident+' acetate substrate overlap','Both propanoate and acetate can act as a substrate.' in part)
 enz.append({'id':ident,'sha256':sha(p),'identity_comment_excerpt':part,'scope':'Class identity/substrate range only; no transfer to exact native protein or changed source EC.'})
out={'checks':checks,'native_existing_authority_scope':roles,'all474_pointer_outcome_counts':dict(collections.Counter(x['result'] for x in pointers)),'direct_request_counts':dict(counts),'historical_reuse_count':len(reused),'source_binding_count':len(bound),'enzymes':enz,'scope':'Complete finite native/pointer/provenance accounting; authority implementation and every unexpanded secondary-xref equivalence remain unaccepted.'}
(O/'results/independent-bindings.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(checks),'finite identity/pointer/provenance checks;',len(bound),'copied original bindings')
