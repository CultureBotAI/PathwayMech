from pathlib import Path
import json,xml.etree.ElementTree as E,collections
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors as D
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=O/'inputs/frozen-issuer';checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def obj(f,prior=False):
 p=R/('inputs/prior270/inputs/native' if prior else 'inputs/source/originals/native')/('META-'+f+'.xml')
 return next(x for x in E.parse(p).getroot() if x.tag!='metadata')
def mol(f,prior=False):return Chem.MolFromInchi(obj(f,prior).findtext('inchi'))
def info(m):return {'formula':D.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'inchi':Chem.MolToInchi(m)}
# Direct39 only; historical retained candidate originals are not silently added to denominator.
ids=sorted({d.findtext('dblink-oid') for row in json.loads((R/'results/all-91-issuer-dispositions.json').read_text()) for d in obj(row['frame']).findall('dblink') if d.findtext('dblink-db')=='CHEBI'})
ck('39 direct ChEBI originals',len(ids)==39);fail=[]
for ident in ids:
 v=json.loads((R/f'originals/ChEBI-{ident}.json').read_text());s=v.get('default_structure') or {}
 if s.get('smiles') and Chem.MolFromSmiles(s['smiles']) is None:fail.append(ident)
ck('six direct SMILES import failures',set(fail)=={'59924','64267','37565','61402','37568','46398'})
for ident in fail:ck(ident+' supplied InChI imports',Chem.MolFromInchi(json.loads((R/f'originals/ChEBI-{ident}.json').read_text())['default_structure']['standard_inchi']) is not None)
pairs=[]
for cur,prior in [('CPD-8','THMPT'),('CPD-9','METHYL-THMPT')]:
 a=info(mol(cur));b=info(mol(prior,True));ck(cur+' differs from '+prior,a['inchi']!=b['inchi'] and a['charge']==-4 and b['charge']==-3 and a['formula']!=b['formula']);pairs.append({'native':cur,'retained_prior':prior,'native_structure':a,'prior_structure':b})
p=Chem.MolFromMolBlock((R/'originals/KEGG-C00009.mol').read_text());q=mol('Pi');ck('KEGG neutral phosphate distinct from native dianion',info(p)['inchi']!=info(q)['inchi'] and Chem.GetFormalCharge(p)==0 and Chem.GetFormalCharge(q)==-2)
c=obj('CPD-7');m=mol('CPD-7');ck('CPD7 remains native class',c.get('class')=='true');ck('CPD7 CML declares hydrogens',c.find('cml/molecule/formula').get('concise')=='H 4 S 4 FE 4');ck('CPD7 InChI four disconnected Fe and S each',len(Chem.GetMolFrags(m))==8 and D.CalcMolFormula(m)=='Fe4S4' and Chem.GetFormalCharge(m)==0)
# Match coefficients through actual direct native ChEBI identities; do not infer physiological direction.
rhea=json.loads((O/'results/independent-rhea.json').read_text())['equations'];eqmatches=[]
for frame,master in [('ACETATEKIN-RXN','11352'),('PHOSACETYLTRANS-RXN','19521')]:
 n=obj(frame);native={}
 for side in ['left','right']:
  terms=[]
  for term in n.findall(side):
   a=next(x for x in term if x.get('frameid'));chem=obj(a.get('frameid'));accessions=[d.findtext('dblink-oid') for d in chem.findall('dblink') if d.findtext('dblink-db')=='CHEBI'];ck(frame+' one direct ChEBI per term',len(accessions)==1);terms.append(('CHEBI:'+accessions[0],int(term.findtext('coefficient') or 1)))
  native[side]=sorted(terms)
 matches=[]
 for eq in [x for x in rhea if x['master']==master]:
  sides={k:sorted((t['accession'][0],t['coefficient']) for t in eq[k]) for k in ['substrates','products']}
  if native['left']==sides['substrates'] and native['right']==sides['products']:matches.append(eq['id'])
 ck(frame+' one exact source equation orientation',len(matches)==1);eqmatches.append({'native':frame,'matched_directional_Rhea':matches[0],'native_sides':native,'scope':'Own equation orientation and chemical coefficients only; not activity direction or pathway flux.'})
out={'checks':checks,'direct_chebi_smiles_failure_ids':fail,'SPT_vs_THMPT':pairs,'phosphate':{'KEGG':info(p),'native':info(q)},'CPD7':{'declared_cml_formula':c.find('cml/molecule/formula').get('concise'),'inchi_graph':info(m),'disconnected_components':len(Chem.GetMolFrags(m)),'scope':'Native class with inconsistent representations; no molecular alias, oxidation or ligand assignment.'},'specific_equation_matches':eqmatches,'scope':'Parser outcomes, exact chemical representations and finite equation comparisons; no issuer invalidation or native-class normalization.'}
(O/'results/independent-representation-limits.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(checks),'representation-limit checks')
