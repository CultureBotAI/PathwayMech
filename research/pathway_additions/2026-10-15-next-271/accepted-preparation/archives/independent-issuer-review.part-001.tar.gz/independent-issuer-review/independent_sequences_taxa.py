from pathlib import Path
import json,re,hashlib,collections,sqlite3,datetime
O=Path('/private/tmp/pathwaymech-next-271-independent-issuer-review');R=O/'inputs/frozen-issuer'
checks=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
groups={'F':'TTT TTC','L':'TTA TTG CTT CTC CTA CTG','I':'ATT ATC ATA','M':'ATG','V':'GTT GTC GTA GTG','S':'TCT TCC TCA TCG AGT AGC','P':'CCT CCC CCA CCG','T':'ACT ACC ACA ACG','A':'GCT GCC GCA GCG','Y':'TAT TAC','*':'TAA TAG TGA','H':'CAT CAC','Q':'CAA CAG','N':'AAT AAC','K':'AAA AAG','D':'GAT GAC','E':'GAA GAG','C':'TGT TGC','W':'TGG','R':'CGT CGC CGA CGG AGA AGG','G':'GGT GGC GGA GGG'}
codons={c:aa for aa,cs in groups.items() for c in cs.split()};ck('complete genetic code table',len(codons)==64)
cds=[];ena=[]
for p in sorted((R/'originals').glob('ENA-*.embl')):
 text=p.read_text();identity=re.search(r'^ID\s+(\S+); SV (\d+);.*; (\d+) BP\.$',text,re.M);ck(p.name+' exact accession header',identity is not None and identity[1]==p.stem[4:]);seqpart=text.split('\nSQ   ',1)[1].split('\n',1)[1].split('//',1)[0];dna=re.sub(r'[^acgt]','',seqpart).upper();ck(p.name+' declared complete DNA length',len(dna)==int(identity[3]));features=[]
 for f in re.finditer(r'^FT   (\S+)\s+([^\n]+)\n((?:FT {19}[^\n]*\n)*)',text,re.M):
  key,loc,raw=f.groups();raw='\n'.join(line[21:] for line in raw.splitlines());qual=collections.defaultdict(list)
  for q in re.finditer(r'/([A-Za-z_]+)=(?:"([^"]*)"|([^\n]+))',raw,re.S):qual[q[1]].append(re.sub(r'\s+',' ',q[2] if q[2] is not None else q[3]).strip())
  features.append({'key':key,'location':loc.strip(),'qualifiers':dict(qual)})
 source=[x for x in features if x['key']=='source'];ck(p.name+' single source feature',len(source)==1);s=source[0]['qualifiers'];ck(p.name+' exact organism/strain',s['organism']==['Methanosarcina thermophila'] and s['strain']==['TM-1'] and 'taxon:2210' in s['db_xref'])
 for f in features:
  if f['key']!='CDS':continue
  q=f['qualifiers'];loc=f['location'];m=re.fullmatch(r'(<?)(\d+)\.\.(>?)(\d+)',loc);ck(p.name+' CDS interval '+loc,m is not None);ck(p.name+' table11/codon1 '+loc,q['transl_table']==['11'] and q['codon_start']==['1']);part=dna[int(m[2])-1:int(m[4])];ck(p.name+' in-bounds CDS '+loc,len(part)==int(m[4])-int(m[2])+1 and len(part)%3==0)
  translated=''.join(codons[part[i:i+3]] for i in range(0,len(part),3));ck(p.name+' no internal stops '+loc,'*' not in translated[:-1]);partial=bool(m[1] or m[3])
  if not m[1]:ck(p.name+' valid table11 initiation '+loc,part[:3] in ['TTG','CTG','ATT','ATC','ATA','ATG','GTG']);translated='M'+translated[1:]
  if not m[3]:ck(p.name+' complete CDS stop '+loc,translated.endswith('*'));translated=translated[:-1]
  expected=''.join(q['translation'][0].split());ck(p.name+' exact reported translation '+loc,translated==expected)
  cds.append({'accession':identity[1],'sequence_version':identity[2],'source_sha256':sha(p),'location':loc,'partial':partial,'protein_id':q['protein_id'],'gene':q.get('gene'),'db_xref':q.get('db_xref',[]),'dna_length':len(part),'dna_sha256':hashlib.sha256(part.encode()).hexdigest(),'amino_acids':translated,'length':len(translated),'source_scope':s})
 ena.append({'path':str(p.relative_to(R)),'sha256':sha(p),'header':identity[0],'features':features,'nucleotide_length':len(dna),'nucleotide_sha256':hashlib.sha256(dna.encode()).hexdigest()})
ck('seven CDS across two ENA originals',len(cds)==7 and len(ena)==2)
proteins=[]
for p in sorted((R/'originals').glob('UniProt-*.json')):
 x=json.loads(p.read_text());ident=p.stem.removeprefix('UniProt-');ck(ident+' issuing identity',x['primaryAccession']==ident and x['organism']['taxonId']==2210);seq=x['sequence']['value'];ck(ident+' sequence length/md5',len(seq)==x['sequence']['length'] and hashlib.md5(seq.encode()).hexdigest().upper()==x['sequence']['md5'])
 matches=[c for c in cds if 'UniProtKB/Swiss-Prot:'+ident in c['db_xref']];full=[c for c in matches if not c['partial']];ck(ident+' unique full CDS',len(full)==1);ck(ident+' exact full sequence',full[0]['amino_acids']==seq)
 for c in matches:
  if c['partial']:ck(ident+' partial only16 prefix',ident=='Q50538' and c['accession']=='U66032' and c['length']==16 and seq.startswith(c['amino_acids']))
 proteins.append({'id':ident,'sha256':sha(p),'length':len(seq),'full_cds':[{'accession':c['accession'],'location':c['location'],'protein_id':c['protein_id']} for c in full],'partial_cds':[{'accession':c['accession'],'location':c['location'],'length':c['length']} for c in matches if c['partial']],'taxon':x['organism'],'gene':x.get('genes'),'entry_audit':x['entryAudit'],'features':x.get('features'),'comments':x.get('comments'),'references':x.get('references'),'scope':'Current full issuing sequence compared to exact ENA CDS; not absent native sequence, assay construct or every cited experiment.'})
ck('five protein lengths',sorted(x['length'] for x in proteins)==[170,436,468,469,806])
# Fresh selected queries only; already accepted whole-cache hash explicitly reused.
receipt=json.loads((R/'results/taxonomy-query-receipt.json').read_text());C=Path(receipt['cache']);before=C.stat();ck('taxonomy cache recorded size/mtime',before.st_size==receipt['size'] and before.st_mtime_ns==receipt['mtime_ns_after'])
db=sqlite3.connect(C.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
def query(t):return [dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(t,))]
author=json.loads((R/'results/taxonomy-complete-selected-statements.json').read_text());taxa={};chains={}
for tax,expected in author.items():
 rows=query(tax);ck(tax+' all selected statements',rows==expected);taxa[tax]=rows;chain=[];seen=set();cur=tax
 while cur not in seen:
  seen.add(cur);rows=query(cur);parent=[x['object'] for x in rows if x['predicate']=='rdfs:subClassOf'];chain.append({'id':cur,'label':[x['value'] for x in rows if x['predicate']=='rdfs:label'],'parent':parent,'rank':[x['object'] for x in rows if x['predicate']=='obo:ncbitaxon#has_rank']})
  if len(parent)!=1 or parent[0] in seen:break
  cur=parent[0]
 chains[tax]=chain
ck('all seven complete lineages',chains==json.loads((R/'results/taxonomy-selected-lineages.json').read_text()))
controls=json.loads((R/'inputs/prior270/inputs/prior/taxon-review/independent-taxonomy-rows.json').read_text())
for tax,expected in controls.items():ck(tax+' prior selected-row control',query(tax)==expected)
db.close();after=C.stat();ck('taxonomy cache unchanged afterquery',before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns)
out={'checks':checks,'ena':ena,'CDS':cds,'proteins':proteins,'taxonomy':{'queried_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cache':str(C),'size':before.st_size,'mtime_ns':before.st_mtime_ns,'prior_full_hash':receipt['whole_cache_hash_reused'],'new_full_cache_rehash':False,'selected_statements':taxa,'lineages':chains,'controls':list(controls),'scope':'Fresh read-only selected statements/lineages; reused full-cache hash evidence; no new strain equivalence or current network taxonomy.'}}
(O/'results/independent-sequences-taxonomy.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(checks),'checks;',len(cds),'CDS;',len(proteins),'full proteins;',len(taxa),'taxa;',len(controls),'controls')
