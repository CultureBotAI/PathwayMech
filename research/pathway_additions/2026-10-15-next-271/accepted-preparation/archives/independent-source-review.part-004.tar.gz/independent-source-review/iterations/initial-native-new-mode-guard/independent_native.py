from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as E,urllib.parse,html,re
R=Path('/private/tmp/pathwaymech-next-271-source-preparation');O=Path('/private/tmp/pathwaymech-next-271-independent-source-review');D=O/'results';reading=O/'reading';reading.mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest();checks=[]
def ck(name,v):
 checks.append({'check':name,'passed':bool(v)})
 if not v:raise AssertionError(name)
def load(n):return json.loads((R/'results'/n).read_text())
def ids(node,path):return [x.get('frameid') for x in node.findall(path)]
def txt(n):return html.unescape(re.sub('<[^>]+>','',n or ''))
obj={};paths={};nrefs=0;ownslots=0
for p in sorted((R/'originals/native').glob('*.xml')):
 root=E.parse(p).getroot();top=[n for n in root if n.tag!='metadata'];ck(str(p.name)+' single entity',len(top)==1);n=top[0];f=n.get('frameid');ck(f+' full envelope',n.get('detail')=='full' and n.get('ID')=='META:'+f and n.get('orgid')=='META' and root.findtext('metadata/query')=='META:'+f and root.findtext('metadata/num_results')=='1' and root.find('metadata/PGDB').get('version')=='27.0');ck(f+' unique',f not in obj);obj[f]=n;paths[f]=p;ownslots+=len(n);nrefs+=sum(x.get('frameid') is not None for s in n for x in s.iter())
 ck(f+' names at most one',len(n.findall('common-name'))<=1)
ck('269 full objects',len(obj)==269);ck('3628 own slots',ownslots==3628);ck('61473 nested frame references',nrefs==61473)
root=obj['METH-ACETATE-PWY'];members=ids(root,'reaction-list/Reaction');ck('six members',len(members)==6);ck('five order links',len(root.findall('reaction-ordering'))==5);ck('seven direct taxa',len(ids(root,'species/Organism'))==7)
aeq={x['frame']:x for x in load('member-equations.json')};amats=load('member-material-occurrences.json');actual_mats=[];act=[];eqs=[]
for f in members:
 n=obj[f];selection=next(x.findtext('direction') for x in root.findall('reaction-layout') if x.find('Reaction').get('frameid')==f);ck(f+' own reversible',n.findtext('reaction-direction')=='REVERSIBLE');ck(f+' no own label',n.find('common-name') is None);ck(f+' selected direction',selection==aeq[f]['selected_direction']);terms={}
 for side in ['left','right']:
  terms[side]=[]
  for s in n.findall(side):
   ns=[x for x in s if x.get('frameid')];ck(f+' material endpoint',len(ns)==1);x=ns[0];t=(x.get('frameid'),int(s.findtext('coefficient') or 1),ids(s,'compartment/*'));terms[side].append(t);actual_mats.append((f,side,*t))
  ck(f+' '+side+' equation matches',terms[side]==[(x['frame'],x['coefficient'],x['compartment']) for x in aeq[f][side]])
 for a in n.findall('enzymatic-reaction/Enzymatic-Reaction'):
  q=obj[a.get('frameid')];enz=ids(q,'enzyme/Protein');act.append({'reaction':f,'activity':a.get('frameid'),'enzyme':enz,'taxa':[(e,ids(obj[e],'species/Organism')) for e in enz],'label':txt(q.findtext('common-name')),'direction':q.findtext('reaction-direction'),'physiologically_relevant':q.findtext('physiologically-relevant')})
 eqs.append({'reaction':f,'selection':selection,'terms':terms,'ec':[s.text for s in n.findall('ec-number')]})
ck('29 materials and19 IDs',len(actual_mats)==29 and len({x[2] for x in actual_mats})==19);ck('29 unlocated',all(not x[4] for x in actual_mats));ck('45 activities',len(act)==45)
ad={x['activity']:x for x in load('all-45-activity-dispositions.json')}
for x in act:
 a=ad[x['activity']];ck(x['activity']+' disposition identity',x['reaction']==a['reaction'] and x['enzyme']==a['enzyme'] and x['taxa']==[(y['enzyme'],y['taxa']) for y in a['enzyme_species']] and x['direction']==a['direction']);x['qualified']=a['qualified_pathway_context'].startswith('qualified');x['disposition']=a['disposition']
qualified={x['activity'] for x in act if x['qualified']};ck('seven qualified contexts',len(qualified)==7)
follow={'Enzymatic-Reaction':{'enzyme','cofactor','regulated-by','alternative-substrate','alternative-cofactor'},'Protein':{'component','gene','species','locations','location','cofactor','prosthetic-group','modified-form','unmodified-form','regulated-by'},'Gene':{'product','species','regulated-by'},'Regulation':{'regulator','regulated-entity'}}
forward=[]
for f,n in obj.items():
 if n.get('class')=='true':continue
 for s in n:
  if s.tag not in follow.get(n.tag,set()):continue
  ends=list(s)
  if s.tag in {'alternative-substrate','alternative-cofactor'}:ends=[x for w in s if w.tag in {'substrate','cofactor','alternate'} for x in w]
  for x in ends:
   if x.get('frameid') and x.tag not in {'Publication','Evidence-Code','Person','Organization'}:
    t=x.get('frameid');ck(f+' '+s.tag+' '+t+' resolved',t in obj);forward.append((f,s.tag,t,x.tag))
ck('338 finite biological forward occurrences',len(forward)==338);ck('forward ledger exact',collections.Counter(forward)==collections.Counter((x['owner'],x['slot'],x['target'],x['type']) for x in load('native-forward-closure.json')))
comps=[];regs=[]
for f,n in obj.items():
 if n.tag=='Protein':
  for s in n.findall('component'):comps.append((f,ids(s,'Protein')[0],s.findtext('coefficient')))
 if n.tag=='Regulation':regs.append((f,n.findtext('mode'),ids(n,'regulator/*'),ids(n,'regulated-entity/*'),n.findtext('physiologically-relevant')))
ck('18 components',len(comps)==18);ck('components exactly source',comps==[(x['complex'],x['component'],x['coefficient_literal']) for x in load('all-component-dispositions.json')]);ck('27 regulations',len(regs)==27)
areg={x['frame']:x for x in load('all-27-regulation-dispositions.json')}
for f,mode,reg,targets,phys in regs:
 a=areg[f];ck(f+' complete regulation',mode==a['mode'] and reg==a['regulator'] and targets==a['regulated_entity'] and phys==a['physiologically_relevant'] and a['qualified_context']==bool(set(targets)&qualified))
# All proof paths and native locators resolve to the exact input bodies.
claims=load('claim-ledger.json')
for c in claims:
 for e in c['evidence']:
  p=R/e['path'];ck(c['id']+' evidence SHA '+e['path'],h(p.read_bytes())==e['sha256'])
  if e['path'].endswith('.xml') and e['path'].startswith('originals/native/'):
   loc=e['locator'];root=E.parse(p).getroot(); q='.'+loc.removeprefix('/ptools-xml');ck(c['id']+' native locator '+loc,root.find(q) is not None)
# Receipt bindings distinguish new attempts, discovery copies and historical reuses.
prov=load('native-provenance-index.json');pc=collections.Counter()
for row in prov:
 p=R/row['body'];ck(row['frame']+' provenance body',h(p.read_bytes())==row['sha256']);pc[row['mode']]+=1
 if row['mode']=='new successful exact full acquisition':
  rr=json.loads((R/row['receipt']).read_text());ck(row['frame']+' acquisition 200',rr['status']==200);ck(row['frame']+' acquisition bytes',p.read_bytes()==(R/rr['body']).read_bytes() and h(p.read_bytes())==rr['sha256']);ck(row['frame']+' exact request query',urllib.parse.unquote(urllib.parse.urlsplit(rr['url']).query)=='META:'+row['frame'])
# Independently produce compact source-reading cards, not author interpretations.
lines=[]
for x in act:
 f=x['activity'];n=obj[f];lines.append('\nACTIVITY '+json.dumps(x,ensure_ascii=False))
 for s in n:
  if s.tag in {'comment','cofactor','alternative-substrate','alternative-cofactor','regulated-by','enzyme','reaction-direction','evidence'}:lines.append(s.tag+': '+(txt(s.text) if not len(s) else E.tostring(s,encoding='unicode')))
qnodes=set(qualified)|{'CPLX-461'}
changed=True
while changed:
 old=len(qnodes)
 for f,slot,t,typ in forward:
  if f in qnodes:qnodes.add(t)
 changed=len(qnodes)>old
for f,n in obj.items():
 if f in qnodes and n.tag=='Protein' or f in ids(root,'species/Organism'):
  lines.append('\nOBJECT '+f+' '+n.tag+' '+txt(n.findtext('common-name')))
  for s in n:
   if s.tag in {'comment','species','locations','cofactor','prosthetic-group','component','gene','rank','strain-name','dblink'}:lines.append(s.tag+': '+(txt(s.text) if not len(s) else E.tostring(s,encoding='unicode')))
lines.append('\nALL REGULATIONS\n'+json.dumps(regs,indent=2));lines.append('\nALL COMPONENTS\n'+json.dumps(comps,indent=2));(reading/'native-biology.txt').write_text('\n'.join(lines)+'\n')
# Decode the retained web text without fetching; retain exact raw hash bindings.
web=[]
for p in (R/'receipts').glob('web-*.json'):
 data=json.loads(p.read_text());t=data if isinstance(data,str) else json.dumps(data,indent=2);out=reading/(p.stem+'.txt');out.write_text(t);web.append({'receipt':str(p.relative_to(R)),'receipt_sha256':h(p.read_bytes()),'decoded':str(out.relative_to(O)),'characters':len(t)})
(D/'web-text-bindings.json').write_text(json.dumps(web,indent=2)+'\n');(D/'independent-native-checks.json').write_text(json.dumps(checks,indent=2)+'\n');(D/'independent-native-summary.json').write_text(json.dumps({'counts':dict(collections.Counter(n.tag for n in obj.values())),'ownslots':ownslots,'references':nrefs,'equations':eqs,'activities':act,'components':comps,'regulations':regs,'provenance_modes':pc,'checks':len(checks)},indent=2)+'\n');print('PASS',len(checks),'checks',dict(pc))
