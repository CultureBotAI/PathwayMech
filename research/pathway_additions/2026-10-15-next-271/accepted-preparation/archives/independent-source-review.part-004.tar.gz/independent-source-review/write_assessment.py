from pathlib import Path
import json,hashlib,datetime
R=Path('/private/tmp/pathwaymech-next-271-source-preparation'); O=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v): (O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
notes={
'N01':'Independently parsed the full root plus six reaction originals: six member IDs, five order slots, 29 left/right occurrences and 19 material IDs. The later Acs alternative is primary context, not a seventh native member.',
'N02':'All six intrinsic directions are REVERSIBLE; root layouts select four L2R and two R2L. Activity directions were checked separately for all45 activities. Source selection does not establish observed physiological flux.',
'N03':'Root pathway links and selected Mtr endpoint delimit methyl-CoM. Methane formation, cofactor regeneration and neighboring superpathway claims remain outside the six members.',
'N04':'All seven direct species slots were independently parsed, including both Methanothrix entries. These are source associations; P05/P06 do not support assigning Ack/Pta to every listed taxon.',
'N05':'Exact full ORG-5913 has native rank species, parent TAX-2207 and no own dblink. This bounded object-level absence is not a database-wide absence or a new issuing strain mapping.',
'N06':'All six full Reaction objects lack an own common-name; ACETATEKIN-RXN has the literal EC-2.7.2.15. Nested Enzymatic-Reaction names do not repair either source anomaly.',
'N07':'Own CML formulas C35H48N7O19P and C36H50N7O19P, distinct InChIs and charge -4 coexist with identical abbreviated SMILES. Literal diagnostic reproduced; exact issuer/stereochemical identity was not inferred.',
'N08':'Four equation carriers are full native Protein classes, without own molecular formulas. CoM [R], Me-CoM C[R] and ATP purine-placeholder strings independently confirmed. No normalization to specific proteins or molecules.',
'N09':'The exact RXN-12908 enzymes-not-used slot names whole CPLX-461; ENZRXN-19881 names CPLX-442. Keeping the whole assembly hierarchy is compatible with excluding it from the isolated activity assertion.',
'N10':'All18 component occurrences compared exactly. Eight qualified occurrences are 4/8/8 whole assembly, alpha2/epsilon2, delta1/gamma1 and Ack dimer. Source coefficients are not experimentally re-established from older preparations.',
'N11':'The thermophila activity own comment explicitly says presumed/not identified; its complex proposes eight subunits without a concrete component expansion. No sequence or experimental identification follows.',
'N12':'Barkeri activity comment is methanol-oxidation context with limited characterization and a possible two-step process. Both Mtr complexes have native CCO-MEMBRANE location; all29 reaction terms remain unlocated.',
'N13':'Pta membrane location/K+ and ammonium alternate, Ack Mg2+ and three metal/six substrate alternatives were read from exact own slots, including nested alternate wrappers. These do not assert operation with every substitute in vivo.',
'N14':'Native FeS/Ni/Zn and direct-assay citation are real; P01 assayed the whole five-subunit preparation. Metal content cannot identify an isolated alpha/epsilon binding site or cofactor essentiality.',
'N15':'Native delta factor-III assignment conflicts with complex corrinoid/CdhE wording. P07 uses separately expressed reconstituted proteins with hydroxocobalamin and explicitly cannot firmly assign native factor III. The conflict remains visible.',
'N16':'Alpha historical metal-cluster prose and beta 2010 acetyl-intermediate prose are source annotations with separate dates/protein scopes. PMID20202935 main was not acquired/read in this bounded review; no primary certification of that mechanism.',
'N17':'All27 regulation objects checked; seven qualified inhibitory annotations target three exact native activities, and every own physiological-relevance slot is absent. KCN whole-complex assay is not identical to native HCN/component specificity.',
'N18':'All45 member activity occurrences resolve to exact full objects. Seven methanogenic contexts versus38 contextual other-organism activities were reviewed individually; source backlinks do not prove the entire route.',
'N19':'Root comment and root evidence are broader narrative/review assertions. Quarter/three-quarter methyl-CoM and respiratory text were not imported as acetate-route stoichiometry, universal mechanism or primary quotation.',
'N20':'Literal partial EC-2.1.1 is preserved. All gene/protein xrefs remain source pointers pending exact issuing-original/strain/sequence review; no fully specified EC or external identity invented.',
'P01':'Publisher Methods/Results/Discussion and table/figure-caption text supports whole-complex CO oxidation, measured five polypeptides/metals, conditional F420 negative and KCN inhibition. 23C assay, MV acceptor and TM-1 preparation were kept distinct from later studies; cleavage/subunit roles remained prospective.',
'P02':'Thesis front matter identifies the published manuscript; full SectionIV body supports isotope-dependent Ni-Fe-C EPR and acetyl-CoA perturbation after CO-to-N2 handling. Controls and the unresolved direct/allosteric interpretation prevent a successful isolated-cleavage claim. Thesis bytes are not asserted journal-identical.',
'P03':'Table1 on thesis PDF73 was visually read, with Methods PDF64-65. Extract Ack/Pta activities, partial-purification kinetic scope and ND=not determined are preserved. No numerical claim in author ledger confuses purified enzyme, extract or absent activity.',
'P04':'Publisher full substantive text and Tables1-2 support 55C artificial methyl-iodide/CO/CoA synthesis; added ferredoxin was unnecessary, methylcobalamin failed, CO2/TiIII substitution and isotope results were conditional. Resolved-component inactivity and cyanide-site interpretations are not definitive mechanistic proofs.',
'P05':'Publisher substantive main text/tables support Opfikon AMP-forming Acs, conditional Ack/Pta nondetection, dimeric preparation and apparent ATP cooperativity. Source prints DMS2139; no silent strain-ID correction, genus gene-absence inference or route-member replacement.',
'P06':'Exact MED8824151 indexed abstract supports CALS-1 extract ATP-dependent methane formation, predominant AMP and tested acetyl-CoA negative. Full main/Methods/SI were not read. No exact ATP stoichiometry or strain-equivalence claim.',
'P07':'Publisher Methods/Results/Discussion supports BL21(DE3) constructs pMJ587/pMJ602, inclusion-body solubilization and Fe/sulfide/hydroxocobalamin reconstitution. CdhD base-on and CdhE base-off observations are construct-dependent; low corrinoid occupancy precludes firm factor-III subunit assignment.',
'P08':'Selected publisher Methods/Results/Discussion and captions support cdhABC alpha/epsilon/beta and 8.7kb transcript in acetate-grown thermophila. Multiple promoter/processing and ORF function remain interpretations. Entire paper/sequence image was not newly read base-by-base; no isolated catalytic assignment or issuer verification.',
'P09':'Retained six-page institutional main PDF read in full; Fig1 on PDF2 and Fig2 on PDF3 visually inspected. Barkeri alpha2epsilon2 has nine clusters, but FAD is modeled/unobserved, ligand CO/formyl unresolved and proposed channels/electron routes are not flux proof. SI inaccessible, low-pH anaerobic crystallization and different species/component preserved.',
'P10':'Exact MED8626532 abstract only supports separated partial-proteolysis components. No main-assay reread or intact physiological cleavage certification from truncated-beta acetyltransferase.',
'P11':'Exact MED11607176 abstract supports detergent resolution. Retained NCBI XML contains matching PMID/front matter and no body, confirmed programmatically. Full main/preparation/cofactor reconstitution scope remains unavailable.',
'P12':'Exact MED12657792 abstract describes preliminary thermophila alpha2epsilon2 crystallization, not a final atomic structure or exact same-strain construct. Failed guessed IUCR path has no scientific authority.'}
claims=json.loads((R/'results/claim-ledger.json').read_text()); assert set(notes)=={x['id'] for x in claims}
ledger=[]
for c in claims:
 ledger.append({'claim_id':c['id'],'author_statement':c['statement'],'author_evidence_level':c['evidence_level'],'author_disposition':c['disposition'],'evidence_bindings':c['evidence'],'review_disposition':'accepted within the explicitly bounded source/primary scope','review_assessment':notes[c['id']]})
write('results/independent-claim-dispositions.json',ledger)
images=[]
for rel in ['reading/terlesky-thesis/page-073.png','reading/gong2008/page-002.png','reading/gong2008/page-003.png']:
 p=R/rel; q=O/'inputs/visually-read'/rel; q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());images.append({'source':str(p),'copy':str(q.relative_to(O)),'sha256':sha(p),'bytes':p.stat().st_size,'scope':'author-rendered PDF image independently visually inspected; not a new render'})
write('results/visual-reading-bindings.json',images)
reading=[
 {'claims':['P01'],'pmid':'3023296','scope':'Full substantive publisher Methods/Results/Discussion and table/figure captions across retained open02/open03 text; journal PDF bytes not acquired; no independent visual page inspection.','doi':'10.1128/jb.168.3.1053-1058.1986'},
 {'claims':['P02','P03'],'pmid':'2824458','scope':'Retained thesis PDF front matter1-4 and complete SectionIV body62-76; methods/results/three figure captions and Table1. Only Table1 PDF73 visually inspected by this reviewer. Other thesis chapters not claimed read, regardless of149-page rendering.','identity_note':'PMID/published manuscript identity grounded in thesis front matter; no fresh external DOI resolution or journal-byte equality claimed.'},
 {'claims':['P04'],'pmid':'2123865','scope':'Full substantive publisher Methods/Results/Discussion, Tables1-2 and figure captions from open06/find07/final_read01. No publisher PDF bytes independently downloaded.','doi':'10.1128/jb.172.12.7145-7150.1990'},
 {'claims':['P05'],'pmid':'2571608','scope':'Full substantive publisher Methods/Results/Discussion, Tables1-3 and figure captions from open05/open09. No publisher PDF bytes independently downloaded.','doi':'10.1128/jb.171.10.5430-5435.1989'},
 {'claims':['P06'],'pmid':'8824151','scope':'Complete indexed MED abstract only; main unavailable.','doi':'10.1007/s002030050384'},
 {'claims':['P07'],'pmid':'8550451','scope':'Publisher main extracted Methods/Results/Discussion and captions across cdhde01/cdhde02, especially constructs/reconstitution/final uncertainty; no base-by-base sequence-image reading or newly obtained PDF bytes.','doi':'10.1128/jb.178.2.340-346.1996'},
 {'claims':['P08'],'pmid':'8955306','scope':'Selected extracted Methods lines85-199 and226-246 plus Results/Discussion lines238-462 and relevant captions. Not a claim of newly reading every line of the eight-page main, references or sequence figure.','doi':'10.1128/jb.178.23.6849-6856.1996'},
 {'claims':['P09'],'pmid':'18621675','scope':'Entire retained institutional six-page main text including main figures/Methods/reference page; visual Fig1 PDF2 and Fig2 PDF3. Gong SI inaccessible and not read.','doi':'10.1073/pnas.0800415105'},
 {'claims':['P10'],'pmid':'8626532','scope':'Complete indexed MED abstract only; main unavailable.','doi':'10.1074/jbc.271.14.8352'},
 {'claims':['P11'],'pmid':'11607176','scope':'Complete indexed MED abstract and NCBI metadata/front matter only; no body.','doi':'10.1073/pnas.88.8.3272'},
 {'claims':['P12'],'pmid':'12657792','scope':'Complete indexed MED abstract only; main unavailable.','doi':'10.1107/s0907444903001987'}]
write('results/independent-primary-reading-scope.json',reading)
print('Wrote',len(ledger),'independent claim dispositions;',len(reading),'paper scopes;',len(images),'visual bindings')
