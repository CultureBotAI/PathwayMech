from pathlib import Path
import hashlib,json,datetime,shutil
out=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
packets=[('discovery','/private/tmp/pathwaymech-next-271-discovery','c602b4d2e491b1efd99769a988b34930f096d78049ac1fa9874fe1de379aa97b',['HANDOFF.md','ASSESSMENT.md']),('independent-preflight','/private/tmp/pathwaymech-next-271-independent-preflight-review','493020bca61eaaea938a0c3730ebf6fabc5fc036698776fc963fbbccce44bf23',['HANDOFF.md','REVIEW.md'])]
def sha(b): return hashlib.sha256(b).hexdigest()
rows=[]
for label,loc,expected,docs in packets:
 p=Path(loc); raw=(p/'artifact-manifest.json').read_bytes(); assert sha(raw)==expected
 m=json.loads(raw); listed={x['path'] for x in m['files']}; actual={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()}; assert actual==listed|{'artifact-manifest.json','freeze-proof.json'}
 assert not any(x.is_symlink() for x in p.rglob('*'))
 for row in m['files']:
  b=(p/row['path']).read_bytes(); assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['path']
 target=out/'inputs'/label; target.mkdir(parents=True)
 copied=[]
 for name in docs+['artifact-manifest.json','freeze-proof.json']:
  b=(p/name).read_bytes(); (target/name).write_bytes(b); copied.append({'path':name,'sha256':sha(b),'bytes':len(b)})
 rows.append({'owner':loc,'manifest_sha256':expected,'listed_files':len(listed),'physical_files':len(actual),'listed_bytes':sum(x['bytes'] for x in m['files']),'all_physical_integrity_verified':True,'copied_documents':copied})
base=Path(packets[0][1])/'inputs/landed266'
contracts=['.claude/skills/add-pathway/SKILL.md','CLAUDE.md','docs/CURATION.md','docs/CAUSAL_GRAPHS.md','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml']
cr=[]
for rel in contracts:
 b=(base/rel).read_bytes(); t=out/'inputs/contracts'/rel;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b);cr.append({'path':rel,'sha256':sha(b),'bytes':len(b)})
result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'/root/next268_reaction_review_completion','state':'prepared; source author freeze pending','packets':rows,'contracts':cr,'scope':'Independent next271 native/source scientific review; no source-owner read yet, network acquisition, maintained/Git/GH/runtime mutation or global novelty claim. Full file integrity is not full scientific rereading. Copied contracts are landed266 discovery inputs; actual270 merge rebind remains separate.','independence':'Reviewer did not author next271 discovery/source candidate; prior next270 source/issuer/record reviews only reused if actual claims recur and explicitly scoped.'}
(out/'preparation-intake.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'PREPARED-SCOPE.md').write_text('''# Independent next271 source review preparation\n\nDiscovery and independent preflight are frozen and fully hash-verified; their complete HANDOFF/ASSESSMENT and HANDOFF/REVIEW were read. Applicable source-evidence, role, scope, direction and native-identity contracts were read from their frozen inputs. This is preparation, not acceptance of the unpublished source packet.\n\nAfter explicit source freeze, verify its complete manifest and acquisition/body bindings; independently reproduce six members/five order links, 29 material occurrences/19 identities and selected-versus-own directions. Review all 45 activity contexts, proposed 27 regulations/18 component occurrences, enzyme/complex/component distinctions, cofactors/locations/taxa and explicit exclusions against full native originals. Assess all 30 bounded primary claims against actually retained original text/figures/tables, preserving preparation, strain, assay direction/donor and exact access/reading limits. Counts from the pending packet are provisional until independently reproduced.\n\nSpecific hazards: Ack/Pta versus Acs taxon/preparation scope; seven direct taxa versus range/backlinks and unresolved ORG-5913; native acetate-kinase EC anomaly; whole-complex CPLX-461 exclusion versus CPLX-442 methyl-transfer activity; carrier classes and inconsistent abbreviated CPD-8/9 SMILES; missing source transport is not sodium independence; methyl-CoM boundary excludes methane formation/respiration; synthetic methyl-iodide assays do not establish full catabolic flux. Authoritative structured assertions may support exact source-limited claims without invented paper quotations or unnecessary proof gates.\n\nNo helpers, new network research, broad source hunt, maintained authoring, issuer acceptance, global exhaustion conclusion or actual270 merged-baseline rebind in this preparation. All writes stay in this scratch owner. Author source owner has not been read.\n''')
print(json.dumps({'packets':[{k:r[k] for k in ('owner','listed_files','physical_files','listed_bytes')} for r in rows],'state':result['state']},indent=2))
