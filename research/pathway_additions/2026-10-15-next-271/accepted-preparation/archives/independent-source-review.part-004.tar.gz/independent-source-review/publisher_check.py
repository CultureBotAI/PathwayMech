from pathlib import Path
import json,re,hashlib
R=Path('/private/tmp/pathwaymech-next-271-source-preparation')
O=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
dois={'P01':'10.1128/jb.168.3.1053-1058.1986','P04':'10.1128/jb.172.12.7145-7150.1990','P05':'10.1128/jb.171.10.5430-5435.1989','P07':'10.1128/jb.178.2.340-346.1996','P08':'10.1128/jb.178.23.6849-6856.1996'}
out=[]
for c in json.loads((R/'results/claim-ledger.json').read_text()):
    if c['id'] not in dois: continue
    for e in c['evidence']:
        raw=(R/e['path']).read_bytes(); assert hashlib.sha256(raw).hexdigest()==e['sha256']
        text=json.loads(raw); blocks=[s.strip() for s in re.split('-{50,}',text) if dois[c['id']] in s.strip().split('\n')[0]]
        counts=[len(re.findall(r'^L\d+@P\d+:',s,re.M)) for s in blocks]
        assert blocks and max(counts)>30,(c['id'],e['path'])
        out.append({'claim':c['id'],'doi':dois[c['id']],'receipt':e['path'],'sha256':e['sha256'],'matched_substantive_blocks':len(blocks),'line_counts':counts,'matching_headers':[b.split('\n')[0] for b in blocks]})
(O/'results/publisher-content-bindings.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',len(out),'claim-to-publisher receipt bindings, each with a matching DOI header and substantive line-numbered content; not PDF-byte retrieval or complete-paper reading proof.')
