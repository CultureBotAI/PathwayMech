from pathlib import Path
import json,hashlib,datetime,shutil
R=Path('/private/tmp/pathwaymech-next-271-source-preparation'); O=Path('/private/tmp/pathwaymech-next-271-independent-source-review'); (O/'results').mkdir(exist_ok=True)
h=lambda b:hashlib.sha256(b).hexdigest()
raw=(R/'artifact-manifest.json').read_bytes(); assert h(raw)=='06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5'
m=json.loads(raw); actual={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}; expect={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}; assert actual==expect
checks=[]
for row in m['files']:
 p=R/row['path'];assert not p.is_symlink(); b=p.read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'],row['path']; checks.append(row)
for name,sha in [('HANDOFF.md','c4c05803d9e57dc6a3c212be7be3dc798b98ec24e3e48d7b1c07325674a7798d'),('freeze-proof.json','1dd9ff1f6c7242725cd083e354ed728e8bf59133cd1f5ba7037bd80976d719fa')]:assert h((R/name).read_bytes())==sha
# Keep compact core text and source originals; PNG pages and historical nested packets remain hash-bound author inputs.
selected=[]
for p in R.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if len(rel.parts)==1 or rel.parts[0] in {'originals','receipts','reading','scripts'} or (rel.parts[0]=='results' and p.suffix=='.json'):
  if p.suffix.lower() in {'.png','.jpg','.jpeg'}:continue
  t=O/'inputs/source'/rel;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,t); selected.append({'path':str(rel),'sha256':h(p.read_bytes()),'bytes':p.stat().st_size})
record={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':str(R),'manifest_sha256':h(raw),'listed':len(m['files']),'physical':len(actual),'listed_bytes':sum(x['bytes'] for x in m['files']),'all_files_verified':True,'inventory':checks,'retained_selected':selected,'scope':'Whole physical integrity including hidden/ignored; no claim to scientifically reread historical archives or all rendered pages.'}
(O/'results/source-intake.json').write_text(json.dumps(record,indent=2)+'\n')
for name in ['claim-ledger.json','all-45-activity-dispositions.json','all-27-regulation-dispositions.json','all-component-dispositions.json','native-provenance-index.json','native-forward-closure.json','member-reaction-equations.json','primary-access-ledger.json']:
 p=R/'results'/name
 if p.exists():
  d=json.loads(p.read_text()); print(name,type(d).__name__,len(d),list(d)[:12] if isinstance(d,dict) else d[:1])
print('INTAKE PASS',len(actual),'files; copies',len(selected))
