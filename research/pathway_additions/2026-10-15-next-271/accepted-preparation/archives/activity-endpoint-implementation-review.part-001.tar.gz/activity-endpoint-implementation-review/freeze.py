from pathlib import Path
import json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-activity-endpoint-implementation-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
i=json.loads((O/'inputs/intake.json').read_text());p=json.loads((O/'results/probes.json').read_text());assert all(x['passed'] for x in p['checks']);assert not (O/'artifact-manifest.json').exists()
r={'status':'accepted','reviewer':'/root/next268_reaction_review_completion','issue':630,'issue_closure':'pending verified integration/merge','started_utc':i['utc'],'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_head':i['head'],'baseline_tree':i['tree'],'product_owners':i['owners'],'fresh_assertions':len(p['checks']),'fresh_differential_guard_cases':len(p['cases']),'fresh_HTML_KGX_fixtures':3,'prior_proof_physical_files':62,'reused_root_targeted_tests':96,'preserved_root_red_failures':2,'findings':[],'no_full_suite_repeat':True,'no_science_or_final_graph_acceptance':True,'no_maintained_git_network_runtime_mutations':True,'all_owned_commands_terminal':True}
(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n')
assert not any(p.is_symlink() for p in O.rglob('*'))
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file()]
m={'owner':str(O),'hidden_and_ignored_included':True,'excluded_self_reference':['artifact-manifest.json','freeze-proof.json'],'files':files};(O/'artifact-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
f={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'all_owned_commands_terminal':True,'frozen':True,'no_further_writes':True};(O/'freeze-proof.json').write_text(json.dumps(f,indent=2)+'\n')
assert {str(p.relative_to(O)) for p in O.rglob('*') if p.is_file()}=={x['path'] for x in files}|{'artifact-manifest.json','freeze-proof.json'}
for x in files:assert sha(O/x['path'])==x['sha256']
print(json.dumps({**f,'owner':str(O),'HANDOFF_sha256':sha(O/'HANDOFF.md'),'REVIEW_sha256':sha(O/'REVIEW.md'),'RESULT_sha256':sha(O/'RESULT.json'),'freeze_sha256':sha(O/'freeze-proof.json')},indent=2))
