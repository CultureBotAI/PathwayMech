from pathlib import Path
import sys,json,copy,importlib.util,csv,hashlib,datetime,itertools
O=Path('/private/tmp/pathwaymech-next-271-activity-endpoint-implementation-review');sys.path.insert(0,str(O/'runtime-copy/src'))
import pathwaymech.schema as new
from pathwaymech.kgx import kgx_nodes,kgx_edges,write_kgx,LOCAL_PREDICATE_CURIES
from pathwaymech.cli import _record_page
from pathwaymech.strict import validator,TARGET_CLASS
from lxml import html
spec=importlib.util.spec_from_file_location('review_baseline_schema',O/'inputs/baseline/src/pathwaymech/schema.py');old=importlib.util.module_from_spec(spec);sys.modules[spec.name]=old;spec.loader.exec_module(old)
checks=[];cases=[]
def ck(n,v):
 checks.append({'check':n,'passed':bool(v)})
 if not v:raise AssertionError(n)
def outcome(mod,r):
 try:mod.validate_record(copy.deepcopy(r));return []
 except mod.ValidationError as e:return e.errors
base=json.loads((O/'inputs/prior-proof/fixtures/current-authority-blocked-input.json').read_text());activity=base['participants'][0]['id'];chemical=base['participants'][1]['id'];reaction=base['reactions'][0]['id'];root=base['id']
base['participants'] += [{'id':'UniProtKB:TEST','label':'protein','category':'protein'},{'id':'GO:0005737','label':'compartment','category':'cellular_component'},{'id':'gomodel:test/process','label':'process','category':'biological_process'}]
base['taxa']=[{'id':'NCBITaxon:562','label':'taxon'}];ids=[root,reaction,*[n['id'] for n in base['participants']],base['taxa'][0]['id'],'gomodel:test/missing'];part={x['id'] for x in base['participants']}
for predicate,subject,obj in itertools.product(sorted(new.ALLOWED_EDGE_PREDICATES),ids,ids):
 r=copy.deepcopy(base);r['mechanistic_edges'][0].update(predicate=predicate,subject=subject,object=obj);before=outcome(old,r);after=outcome(new,r);expected=predicate in {'has_input','has_output'} and subject==activity and obj in part
 ck('grid '+predicate+' '+subject+' '+obj,(bool(before) and not after) if expected else before==after)
 cases.append({'kind':'endpoint_grid','predicate':predicate,'subject':subject,'object':obj,'before':before,'after':after,'intended_new_admission':expected})
# Every supported category plus absent/invalid category, duplicate orders and consistent repeats.
for pred,cat,reverse in itertools.product(['has_input','has_output'],[None,*sorted(new.NODE_CATEGORIES),'invalid'],[False,True]):
 r=copy.deepcopy(base);node={'id':activity,'label':'second declaration'}
 if cat is not None:node['category']=cat
 r['participants'].append(node)
 if reverse:r['participants'].reverse()
 r['mechanistic_edges'][0].update(predicate=pred);before=outcome(old,r);after=outcome(new,r)
 ck('duplicate '+str((pred,cat,reverse)),not after if cat=='molecular_activity' else bool(after) and before==after)
 cases.append({'kind':'duplicate_guard','predicate':pred,'category':cat,'reverse':reverse,'before':before,'after':after})
for pred,collection in itertools.product(['has_input','has_output'],['taxa','reactions','root']):
 r=copy.deepcopy(base);r['mechanistic_edges'][0]['predicate']=pred
 if collection=='root':r['id']=activity
 else:r[collection].append({'id':activity,'label':'colliding identity'})
 before=outcome(old,r);after=outcome(new,r);ck('collision '+pred+collection,before==after and (bool(after) if collection=='taxa' else not after));cases.append({'kind':'cross_section_collision','predicate':pred,'collection':collection,'before':before,'after':after})
# Endpoint qualification remains protein/complex-only, even for newly admitted activity.
for pred in ['has_input','has_output']:
 r=copy.deepcopy(base);r['mechanistic_edges'][0]['predicate']=pred;r['mechanistic_edges'][0]['endpoint_qualifiers']=[{'endpoint':'subject','kind':'experimental_construct','description':'Synthetic illegal activity construct qualifier','evidence':copy.deepcopy(r['mechanistic_edges'][0]['evidence'])}]
 err=outcome(new,r);ck('activity qualifier remains illegal '+pred,any('protein or complex participant' in e for e in err));cases.append({'kind':'qualifier_guard','predicate':pred,'after':err})
# Invalid collection shapes remain ValidationError, not a crash from activity-set comprehension.
for v in [None,{},'invalid',42,[],[None]]:
 r=copy.deepcopy(base);r['participants']=v;before=outcome(old,r);after=outcome(new,r);ck('invalid participant shape '+repr(v),bool(after) and before==after)
# Three real pipeline fixtures: two synthetic directions and exact six alternative inputs.
checker=validator();outputs=[]
for name in ['current-authority-blocked-input','current-authority-blocked-output','source-ack-six-alternatives']:
 r=json.loads((O/'inputs/prior-proof/fixtures'/f'{name}.json').read_text());saved=copy.deepcopy(r);ck(name+' formerly rejected',bool(outcome(old,r)));ck(name+' closed unchanged schema',not checker.validate(r,TARGET_CLASS).results);record=new.validate_record(r);ck(name+' validator does not mutate source',r==saved and record.reactions==saved['reactions'])
 text=_record_page(record);p=O/'results'/f'{name}.html';p.parent.mkdir(exist_ok=True);p.write_text(text);doc=html.fromstring(text);nodes_path,edges_path=write_kgx([record],O/'results'/name)
 with nodes_path.open() as f:ns={x['id']:x for x in csv.DictReader(f,delimiter='\t')}
 with edges_path.open() as f:es=list(csv.DictReader(f,delimiter='\t'))
 ck(name+' edge count',len(es)==len(r['mechanistic_edges']))
 references={x['id']:x for x in r['references']}
 for edge,exported in zip(r['mechanistic_edges'],es,strict=True):
  ck(name+edge['id']+' TSV endpoints',(exported['subject'],exported['predicate'],exported['object'])==(edge['subject'],LOCAL_PREDICATE_CURIES[edge['predicate']],edge['object']))
  ck(name+edge['id']+' full evidence and description',json.loads(exported['evidence'])==edge['evidence'] and exported['description']==edge.get('description',''))
  ck(name+edge['id']+' reference metadata',json.loads(exported['reference_metadata'])==[references[k] for k in sorted({x['reference_id'] for x in edge['evidence']})])
  links=doc.xpath('//a[@data-subject=$s][@data-predicate=$p][@data-object=$o]',s=edge['subject'],p=edge['predicate'],o=edge['object']);ck(name+edge['id']+' directed graph link',len(links)==1)
  anchor=links[0].get('href')[1:];rows=doc.xpath('//*[@id=$i]',i=anchor);ck(name+edge['id']+' visible evidence anchor',len(rows)==1);rowtext=rows[0].text_content();ck(name+edge['id']+' visible ordinary description',edge.get('description','') in rowtext)
  for ev in edge['evidence']:ck(name+edge['id']+' visible full evidence',all(ev[k] in rowtext for k in ['source_assertion','source_locator'] if k in ev))
  if edge['predicate'] in ['has_input','has_output']:
   ck(name+edge['id']+' activity KGX category',ns[edge['subject']]['category']=='biolink:MolecularActivity' and ns[edge['subject']]['source_category']=='molecular_activity')
 outputs.append({'fixture':name,'source_sha256':hashlib.sha256((O/'inputs/prior-proof/fixtures'/f'{name}.json').read_bytes()).hexdigest(),'edges':len(es),'reactions_unchanged':True,'html':str(p.relative_to(O))})
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'cases':cases,'outputs':outputs,'scope':'Independent actual-product-versus-committed-baseline differential endpoint and unchanged pipeline probes. Synthetic combinations test validator behavior, not biological assertions; source fixture reuses the independently reviewed Ack scope.'}
(O/'results/probes.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',len(checks),'assertions;',len(cases),'differential/guard cases;3 HTML/KGX outputs')
