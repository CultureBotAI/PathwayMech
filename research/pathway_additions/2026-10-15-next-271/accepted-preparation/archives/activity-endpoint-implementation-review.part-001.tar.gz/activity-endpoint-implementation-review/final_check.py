from pathlib import Path
import json,hashlib,subprocess,os,datetime
O=Path('/private/tmp/pathwaymech-next-271-activity-endpoint-implementation-review');W=Path('/private/tmp/pathwaymech-next-271-20261015');i=json.loads((O/'inputs/intake.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for family in ['owners','proof','context_package','root_ci']:
 for x in i[family]:
  assert sha(O/x['copy'])==x['sha256'] and (O/x['copy']).stat().st_size==x['bytes']
  if family in ['owners','proof']:assert sha(Path(x['source']))==x['sha256']
proof=Path('/private/tmp/pathwaymech-next-271-activity-endpoint-review');actual={str(p.relative_to(proof)) for p in proof.rglob('*') if p.is_file()};assert actual=={str(Path(x['source']).relative_to(proof)) for x in i['proof']}
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');unchanged=[]
for name in ['kgx.py','graph_view.py','cli.py','reaction_mechanisms.py','strict.py','schema/pathwaymech.yaml']:
 rel='src/pathwaymech/'+name;original=subprocess.check_output(['git','show',i['head']+':'+rel],cwd=W,env=env);current=(O/'runtime-copy'/rel).read_bytes();assert original==current;unchanged.append({'path':rel,'sha256':hashlib.sha256(original).hexdigest(),'equals_committed_baseline':True})
p=json.loads((O/'results/probes.json').read_text());assert len(p['checks'])==1559 and all(x['passed'] for x in p['checks']);new=[x for x in p['cases'] if x.get('intended_new_admission')];assert len(new)==10
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'three_product_owners_exact':i['owners'],'prior_proof_physical62_unchanged':True,'all_copied_inputs_exact':True,'unchanged_pipeline_owners':unchanged,'independent_assertions':1559,'independent_cases':1449,'new_grid_admissions':10,'new_grid_admission_scope':'2 input/output predicates times5 declared participants for one unambiguous activity subject; not proof that arbitrary synthetic biological statements are true.','original_root_targeted96_receipt_reused':True,'root_initial2_red_failures_preserved':True,'no_full_suite_repeated':True}
(O/'results/final-integrity.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS3 actual maintained owners exact;62 proof originals unchanged;6 pipeline owners baseline-exact;1559 checks')
