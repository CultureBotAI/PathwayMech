from pathlib import Path
import json,hashlib,datetime,subprocess,os
O=Path('/private/tmp/pathwaymech-next-271-activity-endpoint-implementation-review');W=Path('/private/tmp/pathwaymech-next-271-20261015');P=Path('/private/tmp/pathwaymech-next-271-activity-endpoint-review');C=Path('/private/tmp/pathwaymech-next-271-ci')
def sha(b):return hashlib.sha256(b).hexdigest()
def copy(p,q):
 b=p.read_bytes();q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return {'source':str(p),'copy':str(q.relative_to(O)),'bytes':len(b),'sha256':sha(b)}
assert sha((P/'manifest.json').read_bytes())=='bd4a9af6ce303c9d8af920bd4e6ce223ae989f9c16c0d3dc2264de3659908dc8'
m=json.loads((P/'manifest.json').read_text());actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file()};assert actual=={x['path'] for x in m['files']}|{'manifest.json','freeze.json'} and len(actual)==62
for x in m['files']:assert sha((P/x['path']).read_bytes())==x['sha256'] and (P/x['path']).stat().st_size==x['bytes']
proof=[copy(P/n,O/'inputs/prior-proof'/n) for n in sorted(actual)]
receipt=json.loads((C/'activity-endpoint-product-changes.json').read_text());owners=[];baseline=[]
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,env=env,text=True).strip();assert head=='63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'
for x in receipt['files']:
 p=W/x['path'];assert sha(p.read_bytes())==x['sha256'] and p.stat().st_size==x['bytes'];owners.append(copy(p,O/'inputs/current'/x['path']))
 b=subprocess.check_output(['git','show',head+':'+x['path']],cwd=W,env=env);q=O/'inputs/baseline'/x['path'];q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);baseline.append({'path':x['path'],'sha256':sha(b),'bytes':len(b),'commit':head})
package=[copy(p,O/'runtime-copy/src'/p.relative_to(W/'src')) for p in sorted((W/'src/pathwaymech').rglob('*')) if p.is_file() and p.suffix in {'.py','.yaml'}]
ci=[copy(C/n,O/'inputs/root-ci'/n) for n in ['activity-endpoint-product-changes.json','root-intake-next271-activity-endpoint-review.json','activity-endpoint-red-result.json','activity-endpoint-red.stdout','activity-endpoint-red.stderr','activity-endpoint-targeted-result.json','activity-endpoint-targeted.stdout','activity-endpoint-targeted.stderr','activity-endpoint-issue-body.md']]
diff=subprocess.check_output(['git','diff','--',*(x['path'] for x in receipt['files'])],cwd=W,env=env);(O/'actual-product.patch').write_bytes(diff)
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=W,env=env,text=True).strip(),'owners':owners,'baseline':baseline,'proof':proof,'context_package':package,'root_ci':ci,'scope':'Exact maintained3-owner intake and original proof verification; no implementation acceptance yet.'};(O/'inputs/intake.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS3 maintained owners;62 frozen proof files;',len(package),'package context files')
