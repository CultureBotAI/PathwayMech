At baseline `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, the Python validator rejects `has_input` and `has_output` when the subject is a participant explicitly typed `molecular_activity`.

`docs/CAUSAL_GRAPHS.md` and the LinkML predicate descriptions define these as activity-to-participant assertions. Native Enzymatic-Reaction authorities already place activity identities in `participants` with category `molecular_activity`. However, `src/pathwaymech/schema.py::_validate_edge_endpoint_types` admits only reaction-list IDs and the record root as subjects.

Independent reproduction with the already supported `MetaCyc:ENZRXN-702` passes both closed LinkML and the actual identifier consumer, while Python rejects either material predicate. Moving that node into `reactions` makes Python accept the edge but makes the identifier consumer reject the node with `ENTITY_TYPE_MISMATCH`. This confirms the conflict without relying on a pending authority entry.

This affects the acetate-pathway candidate: exact native activity `MetaCyc:ENZRXN-481` supplies six alternative-substrate slots, for dTTP, ITP, UTP, GTP, CTP and propanoate. A source-scoped reproducer using all six slots passes the unchanged closed LinkML schema, but Python rejects all six edges with `has_input must point from an activity or pathway to a participant`. The original native activity SHA-256 is `28175b59b20cd53dc232791532146b5a12408773c9400ecc49f4e22b60f3e17e`.

Moving these alternatives onto the issued canonical reaction would change their source scope. The activity should remain a distinct, typed endpoint, and every alternative should retain its evidence and qualification rather than become a new canonical reaction term or simultaneous substrate requirement.

Acceptance:

- Permit `has_input` and `has_output` subjects that are unambiguously declared participant-only `molecular_activity` nodes.
- Preserve existing root/reaction behavior and all other predicate rules; add no field, predicate or identifier-label exception.
- Reject untyped/physical/taxon subjects and conflicting duplicate declarations regardless of order.
- Verify both validators, exact SVG endpoints, KGX MolecularActivity type, and full description/evidence retention.
- Keep the six native activity alternatives distinct from the canonical acetate-kinase equation.

This is a validator defect discovered during graph design, not a claim that the pending pathway has been curated or independently accepted. The pre-fix reproducer, independent review and regression results will be retained with the eventual change.
