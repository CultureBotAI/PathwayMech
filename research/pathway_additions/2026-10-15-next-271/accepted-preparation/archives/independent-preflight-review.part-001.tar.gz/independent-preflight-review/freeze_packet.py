from pathlib import Path
import json,hashlib,datetime
R=Path('/private/tmp/pathwaymech-next-271-independent-preflight-review')
def sha(b):return hashlib.sha256(b).hexdigest()
for f in ['audit.stdout','archive-audit.stdout','final-checks.stdout','write-review.stdout']:
 d=json.loads((R/f).read_text());assert d.get('all_passed',True)
for f in ['audit.stderr','archive-audit.stderr','final-checks.stderr','write-review.stderr']:assert (R/f).read_bytes()==b''
assert not (R/'artifact-manifest.json').exists() and not (R/'freeze-proof.json').exists()
files=[]
for p in sorted(R.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file():files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
manifest={'owner':str(R),'files':files,'exclusions':['artifact-manifest.json','freeze-proof.json'],'scope':'All physical regular files including hidden and ignored; complete retained author packet is under inputs/discovery.'}
(R/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof={'owner':str(R),'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(f['bytes'] for f in files),'manifest_sha256':sha((R/'artifact-manifest.json').read_bytes()),'HANDOFF_sha256':sha((R/'HANDOFF.md').read_bytes()),'REVIEW_sha256':sha((R/'REVIEW.md').read_bytes()),'RESULT_sha256':sha((R/'RESULT.json').read_bytes()),'jobs':'All owned jobs terminal0; failed read attempts retained in OPERATIONS.json.','verdict':'Qualified acceptance for bounded source preparation only; no actionable findings.'}
(R/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
physical={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()}
assert physical=={f['path'] for f in files}|{'artifact-manifest.json','freeze-proof.json'}
for f in files:
 p=R/f['path'];assert p.stat().st_size==f['bytes'] and sha(p.read_bytes())==f['sha256']
print(json.dumps(dict(proof,freeze_sha256=sha((R/'freeze-proof.json').read_bytes())),indent=2))
