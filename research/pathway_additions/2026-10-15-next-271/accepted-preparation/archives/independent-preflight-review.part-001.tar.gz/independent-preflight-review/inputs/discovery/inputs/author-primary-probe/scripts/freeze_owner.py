from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
excluded={'MANIFEST.json','FREEZE.json'}
entries=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.relative_to(ROOT).as_posix() not in excluded:
        body=path.read_bytes();entries.append({'path':path.relative_to(ROOT).as_posix(),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
native=ROOT/'inputs/META-METH-ACETATE-PWY.xml'
assert hashlib.sha256(native.read_bytes()).hexdigest()=='c07ebef86298854af9494a5309ee9453fb9a014b4d1dd5c016278648cb90b5ec'
manifest={'format':'pathwaymech-bounded-scratch-manifest-v1','listed_files':len(entries),'listed_bytes':sum(e['bytes'] for e in entries),'files':entries}
mp=ROOT/'MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
freeze={'owner':str(ROOT),'status':'frozen-read-only-handoff','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),'handoff_sha256':hashlib.sha256((ROOT/'HANDOFF.md').read_bytes()).hexdigest(),'listed_files':len(entries),'physical_files':len(entries)+2,'listed_bytes':manifest['listed_bytes'],'scientific_scope':'bounded preflight; no final record/source-closure acceptance'}
(ROOT/'FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n')
for entry in entries:
    path=ROOT/entry['path'];assert path.stat().st_size==entry['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
assert len([p for p in ROOT.rglob('*') if p.is_file()])==len(entries)+2
print(json.dumps({**freeze,'freeze_sha256':hashlib.sha256((ROOT/'FREEZE.json').read_bytes()).hexdigest()},indent=2))
