# Operations and reproduction limits

Owner: `/private/tmp/pathwaymech-next-271-discovery`. Author: `/root/next268_current_bigg_completion`. This author previously prepared portions of pending270 source/graph/authority work. That overlap is disclosed; this packet makes no independent acceptance claim for it. The delegated primary helper completed its bounded probe and released its slot. No additional helper is running for this owner.

The applicable local add-pathway skill and repository contracts were read and retained. No record, authority snapshot, governed file, runtime, Git state or GitHub state was changed. This is finite discovery; full-corpus runtime gates, pages and record review were not run or claimed.

## Retained implementation

All Python scripts are in `scripts/`. They used the pre-existing `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`; there was no installation or environment repair. Their absolute owner and source paths are intentional acquisition-time bindings. Do not run them in this frozen owner. Replay in a fresh scratch copy, update only its owner root, and preserve this packet.

- `initialize.py` copied/hash-bound the complete earlier discovery, exact landed266 record/contracts and selected pending270 design/source inputs. `landed-baseline.json` records the actual Git commit and blob checks. Git commands were read-only.
- `acquire_members.py` and `acquire_boundary_compounds.py` retained exact request URLs, response bytes and receipts. The initial member requests failed sandbox DNS; the same bounded HTTPS requests succeeded with network access. All six failure receipts remain. Reacquisition is not a deterministic source replay; review the retained original bytes instead.
- `project_native.py` and `compare_boundaries.py` build source-owned projections and branch/direction/material comparisons. The seven-object own-slot projection predates the two compound acquisitions and intentionally describes only root plus six reactions. Compound data have their own later comparison and source receipts.
- `search_and_compare.py` produced baseline/native inventory work, then stalled in expensive Python regex context extraction. The verified own process was interrupted with SIGINT, exit 130. `results/search.stdout` and `search.stderr` preserve it. Its unfinished search is not used as absence evidence.
- `search_successor.py` reran the same 86 literal search patterns using bounded context extraction and completed exit 0. It verified the prior selected gzip compressed/decoded identities and directly bound every newly landed changed archive to its Git blob before reading outer members. See its terminal receipt and raw stdout/stderr.
- `followup_checks.py`, `prior_dispositions.py` and `disposition_followup.py` completed additional pinned Rhea/authority/corpus checks and explicit prior-mention/root-slot dispositions. Follow-up literal prefix hits are distinguished from exact identifier tokens. Source cross-references are leads, not accepted chemical aliases.
- `finalize_receipts.py` completed exit 0, wrote exact inventories and verified all initial source copies and eight acquired bodies. Its stdout/stderr are retained. This does not assert every file in the concurrently edited pending270 working tree stayed unchanged.

All266 corpus comparisons can be replayed from retained `inputs/landed266` bytes. Original-response parsing and primary reading can be replayed from retained sources or textual tool receipts at the stated access level. Full replay of the search across repository working trees requires those original point-in-time trees; they are not copied wholesale. Full replay of the 76 changed archive payloads requires the bound Git blobs, and of the earlier116 payloads requires the hash-bound archived files. Their exact hashes/member inventories and observed matches are retained. Nested archive contents were not recursively inspected. The previous archive inventory therefore does not establish complete historical content coverage.

The author primary helper packet is physically complete and its manifest was independently rehashed by this author. This mechanical check does not turn author research into independent scientific acceptance. All six retained abstracts and the materially relevant publisher-extracted Jetten main-text context were read. The primary PDF request produced HTML/403; no visual page inspection or original PDF-byte closure is claimed. The other primary mains and SI remain open.

## Freeze verification

`scripts/freeze_packet.py` inventories all physical regular files, including hidden and ignored files, rejects symbolic links, and excludes only the two root proof files from the manifest to avoid circular hashes. It verifies every listed size/hash and exact physical file set after writing the manifest and freeze proof. The manifest is the immutable byte contract. A reviewer can rerun its verification logic read-only; do not invoke its creation branch on this frozen owner.

The packet is preliminary against pending270. Its root, equation, primary and source-identity qualifications must remain intact when preparing the next stage. Only an actual merged-baseline rebind can update ownership/duplication conclusions after270 lands.
