from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlencode
import datetime, hashlib, json

ROOT = Path(__file__).resolve().parents[1]
REQUESTS = [(f'pmid-{p}.json', 'https://www.ebi.ac.uk/europepmc/webservices/rest/search?' + urlencode({'query':f'EXT_ID:{p} AND SRC:MED','format':'json','resultType':'core'})) for p in ['3023296','2824458','2123865','12102556','2571608','8824151']]
REQUESTS += [('Jetten1989-publisher.pdf','https://journals.asm.org/doi/epdf/10.1128/jb.171.10.5430-5435.1989')]

for name, url in REQUESTS:
    receipt = {'url':url,'attempted_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'GET','user_agent':'PathwayMech bounded scientific source assessment'}
    try:
        with urlopen(Request(url, headers={'User-Agent':receipt['user_agent']}),timeout=25) as response:
            body=response.read()
            receipt.update(status=response.status,final_url=response.url,headers=dict(response.headers))
    except HTTPError as error:
        body=error.read()
        receipt.update(status=error.code,error=repr(error),headers=dict(error.headers))
    except Exception as error:
        body=None
        receipt['error']=repr(error)
    if body is not None:
        path=ROOT/'inputs'/name
        path.write_bytes(body)
        receipt.update(path=str(path.relative_to(ROOT)),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),pdf_magic=body.startswith(b'%PDF-'))
    (ROOT/'acquisition'/f'http-02-{name}.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({key:receipt.get(key) for key in ['url','status','bytes','sha256','pdf_magic','error']}))
