from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import datetime, hashlib, json
ROOT=Path(__file__).resolve().parents[1]
url='https://europepmc.org/articles/PMC210380?pdf=render'
receipt={'url':url,'attempted_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'method':'GET','purpose':'One archive link explicitly supplied by PMID2571608 metadata; retain primary main already read through publisher web extraction'}
try:
    with urlopen(Request(url,headers={'User-Agent':'PathwayMech bounded scientific source assessment'}),timeout=25) as response:
        body=response.read();receipt.update(status=response.status,final_url=response.url,headers=dict(response.headers))
except HTTPError as error:
    body=error.read();receipt.update(status=error.code,error=repr(error),headers=dict(error.headers))
except Exception as error:
    body=None;receipt['error']=repr(error)
if body is not None:
    name='Jetten1989-archive.pdf' if body.startswith(b'%PDF-') else 'Jetten1989-archive-response.bin'
    path=ROOT/'inputs'/name;path.write_bytes(body)
    receipt.update(path=str(path.relative_to(ROOT)),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),pdf_magic=body.startswith(b'%PDF-'))
(ROOT/'acquisition/http-03-jetten-archive.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
