from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'inputs/META-METH-ACETATE-PWY.xml'
body=path.read_bytes();xml=ET.fromstring(body);p=xml.find('Pathway')
def entity(x):
    return {'frameid':x.get('frameid'),'id':x.get('ID'),'rank':x.findtext('rank'),'label':x.findtext('common-name'),'synonyms':[e.text for e in x.findall('synonym')],'taxon_dblinks':[e.findtext('dblink-oid') for e in x.findall('dblink') if e.findtext('dblink-db')=='NCBI-TAXONOMY-DB']}
comment=p.findtext('comment')
native={
 'source':'/private/tmp/pathwaymech-next-270-discovery/originals/META-METH-ACETATE-PWY.xml',
 'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),
 'source_metadata':{'ptools_version':xml.get('ptools-version'),'xml_base':xml.get('{http://www.w3.org/XML/1998/namespace}base'),'PGDB':dict(xml.find('metadata/PGDB').attrib),'query':xml.findtext('metadata/query'),'num_results':xml.findtext('metadata/num_results')},
 'pathway':p.attrib,'label':p.findtext('common-name'),'synonyms':[x.text for x in p.findall('synonym')],
 'members':[x.get('frameid') for x in p.findall('reaction-list/Reaction')],
 'selected_directions':{x.find('Reaction').get('frameid'):x.findtext('direction') for x in p.findall('reaction-layout')},
 'links':[{'via':x[0].get('frameid'),'target':[e.get('frameid') for e in x.findall('link-target/Pathway')]} for x in p.findall('pathway-link')],
 'species_associations':[entity(x) for x in p.findall('species/Organism')],
 'taxonomic_range':[entity(x) for x in p.findall('taxonomic-range/Organism')],
 'evidence':[{'code':x.find('Evidence-Code').get('frameid'),'publication':x.find('Publication').get('frameid'),'pmid':x.findtext('Publication/pubmed-id'),'title':x.findtext('Publication/title')} for x in p.findall('evidence')],
 'comment_pmids':list(dict.fromkeys(re.findall(r'pubmed/(\d+)',comment))),
 'comment_named_citations':re.findall(r'object=%5b([^%]+)%5d',comment),
 'interpretive_limit':'Native source assertions and finite complete root membership only; layout primaries are incomplete equations; source associations are not organism-specific proof of every member.'
}
(ROOT/'results/native-root-facts.json').write_text(json.dumps(native,indent=2)+'\n')
metadata=[]
for path in sorted((ROOT/'inputs').glob('pmid-*.json')):
    data=json.loads(path.read_text());expected=path.stem.removeprefix('pmid-');assert data['hitCount']==1
    item=data['resultList']['result'][0];assert item['id']==expected and item['source']=='MED'
    metadata.append({'pmid':expected,'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'title':item.get('title'),'authors':item.get('authorString'),'year':item.get('pubYear'),'doi':item.get('doi'),'pmcid':item.get('pmcid'),'types':item.get('pubTypeList'),'full_text_links':item.get('fullTextUrlList')})
(ROOT/'results/verified-metadata-index.json').write_text(json.dumps({'validated_exact_id_count':len(metadata),'entries':metadata},indent=2)+'\n')
print(json.dumps(native,indent=2))
