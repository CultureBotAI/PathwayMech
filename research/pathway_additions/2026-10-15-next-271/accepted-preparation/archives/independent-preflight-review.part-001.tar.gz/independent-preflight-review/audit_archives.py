from pathlib import Path
import hashlib,json,subprocess,gzip,tarfile,io,collections
R=Path('/private/tmp/pathwaymech-next-271-independent-preflight-review');A=R/'inputs/discovery';W=Path('/private/tmp/pathwaymech-next-270-20261015');H='e8ae5e445d3288717c31d3012611e226fd5cca34';OLD='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105'
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
def ck(v,s):
 checks.append({'check':s,'pass':bool(v)})
 if not v:raise AssertionError(s)
def load(n):return json.loads((A/n).read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
patterns=['METH-ACETATE-PWY','methanogenesis from acetate','aceticlastic pathway','aceticlastic methanogenesis','acetoclastic methanogenesis','methanogenesis from acetic acid','1.2.7.4-RXN','RXN-12908','ACETYLSYNCLTH-RXN','MTRMBARK-RXN','PHOSACETYLTRANS-RXN','ACETATEKIN-RXN']
hits=[];unique_contexts={}
def scan(b,loc,authorhits):
 t=b.decode('utf8',errors='replace');s=t.lower();found={p:s.count(p.lower()) for p in patterns if p.lower() in s}
 expected={h['pattern']:h['occurrences'] for h in authorhits if h['pattern'] in patterns}
 ck(found==expected,'bounded member/root hits '+loc)
 if found:
  hits.append({'location':loc,'sha256':sha(b),'counts':found})
  if sha(b) not in unique_contexts:
   contexts=[]
   for p in found:
    start=0
    for i in range(min(found[p],15)):
     k=s.find(p.lower(),start);contexts.append({'pattern':p,'context':t[max(0,k-180):k+len(p)+300]});start=k+len(p)
   unique_contexts[sha(b)]={'location':loc,'contexts':contexts}
new=load('results/new-landed269-archive-outer-search.json');changed=git('diff','--name-only',OLD,H).decode().splitlines();archivepaths=[p for p in changed if p.endswith(('.tar.gz','.tgz','.zip','.gz'))]
ck(archivepaths==[x['path'] for x in new['archive_bindings']],'complete changed archive set 76')
ck(len(archivepaths)==76,'76 changed archives')
byarchive=collections.defaultdict(list)
for row in new['members']:byarchive[row['archive']].append(row)
counts=collections.Counter();bindings=[]
for arch in new['archive_bindings']:
 b=git('show',H+':'+arch['path']);ck(sha(b)==arch['sha256'] and len(b)==arch['bytes'],'exact committed archive '+arch['path']);bindings.append(arch)
 decoded=[]
 if arch['path'].endswith(('.tar.gz','.tgz')):
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tf:
   decoded=[(m.name,tf.extractfile(m).read()) for m in tf if m.isfile()]
 else:
  ck(arch['path'].endswith('.gz'),'supported finite single gzip');decoded=[('<single gzip payload>',gzip.decompress(b))]
 expected=byarchive[arch['path']];ck(len(decoded)==len(expected),'exact member number '+arch['path'])
 for (name,raw),row in zip(decoded,expected):
  ck(name==row['path'] and sha(raw)==row['sha256'] and len(raw)==row['bytes'],'exact outer member '+arch['path']+'::'+name)
  opaque=name.endswith(('.gz','.zip','.tar','.tgz'));text=not opaque and b'\0' not in raw
  ck(text==row['text_search'],'classification '+arch['path']+'::'+name)
  counts['members']+=1;counts['decoded_bytes']+=len(raw);counts['opaque_nested']+=opaque;counts['text_members']+=text
  if text:scan(raw,arch['path']+'::'+name,row.get('literal_matches',[]))
ck(counts['members']==5084 and counts['text_members']==4706 and counts['opaque_nested']==263,'outer counts stated')
old=load('results/selected-compressed-reuse-and-additional-search.json');oldbytes=0
for f in old['files']:
 b=(W/f['path']).read_bytes();ck(sha(b)==f['compressed_sha256'],'selected old compressed '+f['path']);raw=gzip.decompress(b);ck(sha(raw)==f['decoded_sha256'] and len(raw)==f['decoded_bytes'],'selected old decoded '+f['path']);oldbytes+=len(raw)
 # Old reused search uses a different hits shape; independently re-search candidate/root/member strings and retain all matches rather than assert shape equivalence.
 t=raw.decode('utf8',errors='replace').lower();found={p:t.count(p.lower()) for p in patterns if p.lower() in t}
 if found:hits.append({'location':f['path'],'sha256':sha(raw),'counts':found})
ck(len(old['files'])==116 and oldbytes==24849128,'selected old scope')
# Ordinary records are point-in-time and pending owner evolves: only static source files rehashed, not a current whole-tree absence claim.
ordinary=[]
for tag in ['original-checkout','pending270-worktree']:
 d=load('results/ordinary-text-search-'+tag+'.json');ck('--no-ignore' in d['command'] and '--hidden' in d['command'],'ignored hidden command '+tag)
 counts1=0
 for f in d['files']:
  selected=[m for m in f['literal_matches'] if m['pattern'] in patterns]
  if selected:ordinary.append({'search_root':tag,'path':f['path'],'sha256':f['sha256'],'matches':selected});counts1+=bool(selected)
 ck(len(d['files'])==({'original-checkout':343,'pending270-worktree':534}[tag]),'ordinary observed counts '+tag)
put={'checks':checks,'new_archive_counts':dict(counts),'new_compressed_bytes':sum(f['bytes'] for f in bindings),'old_selected_count':len(old['files']),'old_selected_decoded_bytes':oldbytes,'bounded_patterns':patterns,'matches':hits,'ordinary_point_in_time_mentions':ordinary,'unique_outer_contexts':list(unique_contexts.values()),'limits':'Fresh exact76 Git archive outer member decoding/hashes and12 candidate/root/member literal patterns, not all86 aliases replayed. Fresh116 prior selected gzip compressed/decoded identity and same12-pattern scan. Nested containers and binary interiors opaque. Ordinary tree receipts re-read, not re-run on evolving parent tree. No global historical absence or source exhaustion.'}
(R/'results/archive-and-search-audit.json').write_text(json.dumps(put,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':True,'new':dict(counts),'new_compressed_bytes':put['new_compressed_bytes'],'old_count':len(old['files']),'old_bytes':oldbytes,'unique_outer_contexts':len(unique_contexts)}))
