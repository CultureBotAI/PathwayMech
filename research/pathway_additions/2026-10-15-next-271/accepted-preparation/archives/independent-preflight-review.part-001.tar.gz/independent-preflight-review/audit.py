from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as E,collections,re,gzip,tarfile,io
import yaml
R=Path('/private/tmp/pathwaymech-next-271-independent-preflight-review')
A=Path('/private/tmp/pathwaymech-next-271-discovery')
W=Path('/private/tmp/pathwaymech-next-270-20261015')
H='e8ae5e445d3288717c31d3012611e226fd5cca34';TREE='1c03509290f5c76048cb293bdd19c1f57143059c'
checks=[]
def ck(test,msg):
 checks.append({'check':msg,'pass':bool(test)})
 if not test: raise AssertionError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(n,o):
 p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2)+'\n')
def rd(n):return json.loads((A/n).read_text())
def git(*args):return subprocess.check_output(['git',*args],cwd=W)
manifest=rd('artifact-manifest.json');files=manifest['files']
ck(sha((A/'artifact-manifest.json').read_bytes())=='c602b4d2e491b1efd99769a988b34930f096d78049ac1fa9874fe1de379aa97b','author exact manifest')
ck(sha((A/'freeze-proof.json').read_bytes())=='f8dc2d52890a7c605bd3d09e5aaf86f494844d401a98af8e26b04e9bdfa4e80f','author exact freeze')
ck(sha((A/'HANDOFF.md').read_bytes())=='1c42da0802bffa0c781bab9324f8a6e7130561c3e1a56fdb91391f09cf26545a','author exact handoff')
physical=[]
for p in sorted(A.rglob('*')):
 ck(not p.is_symlink(),'no author symlink '+str(p.relative_to(A)))
 if p.is_file():physical.append(str(p.relative_to(A)))
ck(set(physical)=={f['path'] for f in files}|{'artifact-manifest.json','freeze-proof.json'},'exact physical set includes hidden/ignored')
ck(len(files)==470 and len(physical)==472 and sum(f['bytes'] for f in files)==51064764,'author counts')
for f in files:
 b=(A/f['path']).read_bytes();ck(len(b)==f['bytes'] and sha(b)==f['sha256'],'author file '+f['path'])
# Retain exact complete author packet for repeatable finite verification, no author writes.
D=R/'inputs/discovery'
ck(not D.exists(),'fresh review input destination')
shutil.copytree(A,D)
for rel in physical:ck((D/rel).read_bytes()==(A/rel).read_bytes(),'copy '+rel)
raw=git('cat-file','commit',H)
ck(hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==H,'raw commit identity')
ck(raw.splitlines()[0]==b'tree '+TREE.encode(),'raw commit tree')
(R/'results').mkdir(exist_ok=True);(R/'results/baseline-commit.txt').write_bytes(raw)
rows=[]
for line in git('ls-tree','-r',H).decode().splitlines():
 meta,path=line.split('\t');mode,typ,oid=meta.split();rows.append({'path':path,'mode':mode,'type':typ,'oid':oid})
rec=[r for r in rows if r['path'].startswith('data/pathways/') and r['path'].endswith('.yaml')]
ck(len(rec)==266,'exact landed266 record set')
base=rd('results/landed-baseline.json');ck(base['head']==H and base['tree']==TREE,'author baseline identities')
for item in base['paths']:
 b=git('show',H+':'+item['path']);ck(len(b)==item['bytes'] and sha(b)==item['sha256'],'baseline bytes '+item['path'])
 ck(git('rev-parse',H+':'+item['path']).decode().strip()==item['git_blob'],'baseline blob '+item['path'])
 ck(b==(A/'inputs/landed266'/item['path']).read_bytes(),'baseline retained '+item['path'])
for rel in ['conf/rhea_directions.json','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json']:
 ck(git('show',H+':'+rel)==(A/'inputs/landed266'/rel).read_bytes(),'additional pinned input '+rel)
put('results/baseline-git-inventory.json',{'head':H,'tree':TREE,'record_files':rec,'author_baseline_paths':len(base['paths']),'additional_paths':3})
rootpath=A/'inputs/prior-next270-discovery/originals/META-METH-ACETATE-PWY.xml'
root=E.parse(rootpath).getroot().find('Pathway')
proj=rd('results/native-complete-own-slot-projections.json')
# Every original selected for own-slot projection, exact serialized slots and full texts.
for row in proj:
 p=A/row['file'];x=E.parse(p).getroot();o=next(c for c in x if c.tag!='metadata')
 ck(row['sha256']==sha(p.read_bytes()) and row['identity']==o.attrib and row['tag']==o.tag,'native projection identity '+o.get('frameid'))
 ck(len(row['slots'])==len(o),'all own slots '+o.get('frameid'))
 for stored,child in zip(row['slots'],o):
  ck(stored['xml']==E.tostring(child,encoding='unicode') and stored['text']==''.join(child.itertext()),'exact own slot '+stored['locator'])
ck(len(proj)==7,'root and six reaction projections')
rootdisp=rd('results/complete-native-root-dispositions.json')
ck(len(root)==34 and rootdisp['own_slot_count']==34,'34 own root slots disposed')
for child,stored in zip(root,rootdisp['dispositions']):ck(E.tostring(child,encoding='unicode')==stored['xml'] and bool(stored['disposition']),'root slot disposition '+stored['locator'])
members=[x.get('frameid') for x in root.findall('reaction-list/Reaction')]
dirs={x.find('Reaction').get('frameid'):x.findtext('direction') for x in root.findall('reaction-layout')}
order=[{'before':b.get('frameid'),'after':x.find('Reaction').get('frameid')} for x in root.findall('reaction-ordering') for b in x.findall('predecessor-reactions/Reaction')]
boundary=rd('results/candidate-native-boundary.json');ck(members==boundary['members'] and order==boundary['order'],'complete members and branches')
reactions=[];materials=[];activities=[];native=[]
for fid in members:
 p=A/'originals'/('META-'+fid+'.xml');doc=E.parse(p).getroot();o=doc.find('Reaction')
 ck(doc.get('ptools-version')=='27.0' and doc.findtext('metadata/query')=='META:'+fid and doc.findtext('metadata/num_results')=='1','native query '+fid)
 ck(o.attrib=={'ID':'META:'+fid,'orgid':'META','frameid':fid,'detail':'full'},'native own identity '+fid)
 eq={}
 for side in ['left','right']:
  eq[side]=[]
  for i,s in enumerate(o.findall(side),1):
   entity=[x for x in s if x.get('frameid')];ck(len(entity)==1,'one direct material '+fid+side+str(i));n=entity[0]
   loc=s.find('compartment');m={'id':n.get('frameid'),'native_type':n.tag,'class':n.get('class')=='true','coefficient':int(s.findtext('coefficient','1')),'coefficient_explicit':s.find('coefficient') is not None,'compartment':None if loc is None else next(iter(loc)).get('frameid'),'locator':f"/ptools-xml/Reaction[@frameid='{fid}']/{side}[{i}]"}
   eq[side].append(m)
   sel='inputs' if (side=='left')==(dirs[fid]=='L2R') else 'outputs'
   materials.append(dict(reaction=fid,native_side=side,selected_side=sel,**m))
 reactions.append({'id':fid,'sha256':sha(p.read_bytes()),'direction_native':o.findtext('reaction-direction'),'direction_pathway':dirs[fid],'common_name':o.findtext('common-name'),'synonyms':[x.text for x in o.findall('synonym')],'in_pathway':[x.get('frameid') for x in o.findall('in-pathway/Pathway')],'ec_numbers':[x.text for x in o.findall('ec-number')],'equation':eq,'enzymes_not_used':[x.get('frameid') for x in o.findall('enzymes-not-used/Protein')]})
 for a in o.findall('enzymatic-reaction/Enzymatic-Reaction'):
  activities.append({'reaction':fid,'id':a.get('frameid'),'detail':a.get('detail'),'enzymes':[x.get('frameid') for x in a.findall('enzyme/Protein')],'name':a.findtext('common-name')})
 native.append({'frame':fid,'own_slots':len(o),'activities':len(o.findall('enzymatic-reaction/Enzymatic-Reaction'))})
ck(reactions==rd('results/native-six-reactions.json'),'all six independent reaction projections equal')
ck(materials==rd('results/native-material-occurrences.json'),'all 29 independent material projections equal')
ck(activities==rd('results/native-activity-prerequisites.json'),'all45 independent activity projections equal')
ck(len(materials)==29 and len({m['id'] for m in materials})==19 and len(activities)==45,'source totals')
net=collections.Counter()
for m in materials:net[m['id']]+=m['coefficient']*(1 if m['selected_side']=='outputs' else -1)
ck(dict(sorted((k,v) for k,v in net.items() if v))==boundary['formal_exact_id_sum'],'formal exact-ID diagnostic only')
ck(all(m['compartment'] is None for m in materials),'all29 unspecified compartments')
ck(all(r['direction_native']=='REVERSIBLE' and r['common_name'] is None for r in reactions),'all six own reversible and common-name absent')
ck([r for r in reactions if r['id']=='RXN-12908'][0]['enzymes_not_used']==['CPLX-461'],'whole-complex exclusion')
ck([r for r in reactions if r['id']=='ACETATEKIN-RXN'][0]['ec_numbers']==['EC-2.7.2.15'],'native EC anomaly preserved')
taxa=[]
for s in root.findall('species'):
 o=s.find('Organism');taxa.append({'id':o.get('frameid'),'label':o.findtext('common-name'),'rank':o.findtext('rank'),'ncbi':[x.findtext('dblink-oid') for x in o.findall('dblink') if x.findtext('dblink-db')=='NCBI-TAXONOMY-DB']})
ck(len(taxa)==7 and sum(t['rank']=='genus' for t in taxa)==2,'seven associations two genera')
ck(taxa[-1]=={'id':'ORG-5913','label':'Methanosarcina TM-1','rank':'species','ncbi':[]},'native TM1 unresolved no NCBI link')
for t,s in zip(taxa,boundary['species']):ck(t['id']==s['id'] and t['label']==s['native_label'] and t['rank']==s['rank'] and t['ncbi']==s['ncbi_native_asserted'],'taxon projection '+t['id'])
for row in rd('results/acquired-originals-verified.json'):
 b=(A/row['path']).read_bytes();r=rd(row['receipt']);ck(sha(b)==row['sha256']==r['sha256'] and len(b)==row['bytes']==r['bytes'],'new original receipt '+row['id']);ck(r['status']==200 and r['url']==row['url'] and r['url'].startswith('https://'),'successful exact HTTPS '+row['id'])
car=[]
for fid in ['CPD-8','CPD-9']:
 o=E.parse(A/'originals'/('META-'+fid+'.xml')).getroot().find('Compound');mol=o.find('cml/molecule');car.append({'id':fid,'formula':mol.find('formula').get('concise'),'charge':mol.get('formalCharge'),'inchi':o.findtext('inchi'),'smiles':mol.findtext("string[@title='smiles']"),'atoms':len(mol.findall('atomArray/atom')),'bonds':len(mol.findall('bondArray/bond'))})
ck(car[0]['smiles']==car[1]['smiles'] and car[0]['inchi']!=car[1]['inchi'] and car[0]['formula']!=car[1]['formula'],'distinct carriers with defective shared SMILES')
pending=E.parse(A/'inputs/pending270-source/originals/native/META-2.1.1.86-RXN.xml').getroot().find('Reaction')
ck(len(pending.findall('left'))+len(pending.findall('right'))==6,'pending Mtr six material occurrences')
for side,compartment in [('left','CCO-IN'),('right','CCO-OUT')]:
 term=[x for x in pending.findall(side) if x.find('Compound').get('frameid')=='NA+'][0]
 ck(term.findtext('coefficient')=='2' and term.find('compartment/cco').get('frameid')==compartment,'pending sodium exact '+side)
# All266 duplicate checks using independent literal and token searches.
patterns=(A/'results/search-patterns.txt').read_text().splitlines();follow=(A/'results/followup-search-patterns.txt').read_text().splitlines();search=[]
for item in rec:
 b=git('cat-file','blob',item['oid']);p=A/'inputs/landed266'/item['path'];ck(b==p.read_bytes(),'corpus direct blob '+item['path'])
 y=yaml.safe_load(b);ids=[y['id']]+[n['id'] for k in ['taxa','participants','reactions'] for n in y.get(k,[])]
 hits=[s for s in patterns+follow if s.lower() in b.decode().lower()]
 exact=[s for s in patterns+follow if re.search(r'(?<![A-Za-z0-9_-])'+re.escape(s)+r'(?![A-Za-z0-9_-])',b.decode(),re.I)]
 ck(y['id']!='MetaCyc:METH-ACETATE-PWY','candidate root not existing '+item['path'])
 ck(not set('MetaCyc:'+s for s in members)&set(ids),'native member declaration not existing '+item['path'])
 search.append({'path':item['path'],'id':y['id'],'sha256':sha(b),'literal_hits':hits,'exact_hits':exact})
# Rebind the 26 core authority claims, not eventual biological closure.
auth=rd('results/landed-authority-coverage.json')
for row in auth:
 src=json.loads((A/'inputs/landed266'/row['snapshot']).read_text());ck(sha((A/'inputs/landed266'/row['snapshot']).read_bytes())==row['sha256'],'authority snapshot hash');ck(src['sources']==row['source_metadata'],'authority source metadata')
 for ident,term in row['terms'].items():ck(src['terms'].get(ident)==term,'authority term '+ident)
core=['MetaCyc:METH-ACETATE-PWY']+['MetaCyc:'+s for s in members]+['MetaCyc:'+s for s in {m['id'] for m in materials}]
existing={i for row in auth for i in core if row['terms'].get(i) is not None}
ck(len(core)==26 and len(existing)==9,'core authority 9 present 17 missing baseline only')
put('results/independent-native-projection.json',{'members':members,'order':order,'reactions':reactions,'materials':materials,'activities':activities,'taxa':taxa,'carriers':car,'source_counts':native,'existing_core_ids':sorted(existing)})
put('results/independent-all266-search.json',search)
put('results/initial-audit-checks.json',checks)
print(json.dumps({'checks':len(checks),'author_files':len(physical),'baseline_records':len(rec),'materials':len(materials),'activities':len(activities),'all_passed':True}))
