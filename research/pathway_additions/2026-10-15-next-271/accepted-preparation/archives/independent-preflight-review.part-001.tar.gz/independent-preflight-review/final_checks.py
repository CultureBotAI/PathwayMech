from pathlib import Path
import json,hashlib,re,datetime
R=Path('/private/tmp/pathwaymech-next-271-independent-preflight-review');A=R/'inputs/discovery';P=A/'inputs/author-primary-probe'
checks=[]
def ck(v,msg):
 checks.append({'check':msg,'pass':bool(v)})
 if not v:raise AssertionError(msg)
def sha(b):return hashlib.sha256(b).hexdigest()
rows=[]
for f in sorted((P/'inputs').glob('pmid-*.json')):
 d=json.loads(f.read_text());pmid=f.stem.split('-')[1];res=d['resultList']['result'];ck(len(res)==1 and res[0]['id']==pmid and res[0]['source']=='MED','primary exact identity '+pmid)
 receipt=json.loads((P/'acquisition'/('http-02-'+f.name+'.receipt.json')).read_text());ck(receipt['sha256']==sha(f.read_bytes()),'primary original hash '+pmid)
 rows.append({'pmid':pmid,'sha256':sha(f.read_bytes()),'title':res[0]['title'],'doi':res[0].get('doi'),'publication_types':res[0]['pubTypeList'],'reading':'complete original metadata and abstract only; Jetten separately targeted extracted main'})
ck(len(rows)==6,'six metadata originals')
ck(not (P/'inputs/Jetten1989-publisher.pdf').read_bytes().startswith(b'%PDF-'),'failed HTML is not PDF')
text=json.loads((P/'acquisition/web-04-primary-pdf-and-api-access.json').read_text());ck('Opfikon strain' in text and 'L195@P2: TABLE 1.' in text and 'L202@P2: Acetate kinase 2.7.2.1 NDb' in text and 'L203@P2: Phosphate acyltransferase 2.3.1.8 ND' in text and 'L208@P2: b ND, Not detected.' in text,'Jetten exact extracted scope and table footnote')
# Recheck source owner physical completeness after entire read-only review.
source=Path('/private/tmp/pathwaymech-next-271-discovery');m=json.loads((source/'artifact-manifest.json').read_text())
paths=[p for p in source.rglob('*') if p.is_file()]
ck({str(p.relative_to(source)) for p in paths}=={f['path'] for f in m['files']}|{'artifact-manifest.json','freeze-proof.json'},'final physical source set includes hidden ignored')
for f in m['files']:ck(sha((source/f['path']).read_bytes())==f['sha256'] and (source/f['path']).stat().st_size==f['bytes'],'final author unchanged '+f['path'])
for name in ['artifact-manifest.json','freeze-proof.json']:ck((source/name).read_bytes()==(A/name).read_bytes(),'proof unchanged '+name)
(R/'results/final-metadata-and-source-checks.json').write_text(json.dumps({'checks':checks,'primary':rows,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':True}))
