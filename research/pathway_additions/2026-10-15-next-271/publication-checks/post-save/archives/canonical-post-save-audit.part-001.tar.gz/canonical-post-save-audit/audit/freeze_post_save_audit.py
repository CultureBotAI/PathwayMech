from pathlib import Path
import os,json,yaml,hashlib,shutil,datetime
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review');D=Path('/private/tmp/pathwaymech-next-271-canonical-post-save-audit');R=Path('/private/tmp/pathwaymech-next-271-20261015');RID='20261016T044353Z-acetate-methanogenesis-maintained-record-review'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def walk(root):
 out=[]
 for cur,ds,fs in os.walk(root):
  for d in ds:assert not (Path(cur)/d).is_symlink()
  for f in fs:
   p=Path(cur)/f;assert p.is_file() and not p.is_symlink();out.append(dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=sha(p)))
 return sorted(out,key=lambda x:x['path'])
for k in ['canonical-validate-v2','canonical-save-v2','canonical-check-v2']:
 assert json.loads((O/f'operations/{k}-receipt.json').read_text())['exit_code']==0
pair=R/'reviews/structured'/RID;review=yaml.safe_load((pair/'review.yaml').read_text());assert review['review_id']==RID and review['verdict']=='pass_with_limitations' and review['findings']==[]
for x in review['source']['inputs']:assert sha(R/x['path'])==x['sha256'],x['path']
source_index=json.loads((O/'pre-save-evidence/SOURCE-INVENTORY.json').read_text());old={x['path']:x['sha256'] for x in source_index['files']}
assert not D.exists();D.mkdir()
selected=[];omitted=[]
for x in walk(O):
 if x['path'].startswith('pre-save-evidence/'):continue
 if x['path']=='completed-review.yaml':omitted.append(dict(path=x['path'],sha256=x['sha256'],reason='Final completed review content is retained by the governed immutable pair; no duplicate saved-pair payload in post-audit.'));continue
 if old.get(x['path'])==x['sha256']:continue
 dest=D/'audit'/x['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(O/x['path'],dest);assert sha(dest)==x['sha256'];selected.append(x)
result=dict(status='complete',verdict=review['verdict'],review_id=RID,started_at=review['started_at'],finished_at=review['finished_at'],findings=0,canonical_inputs=len(review['source']['inputs']),checks=len(review['checks']),assessments=len(review['assessments']),evidence=len(review['evidence']),saved_pair=[dict(path=str(x.relative_to(R)),bytes=x.stat().st_size,sha256=sha(x)) for x in [pair/'review.yaml',pair/'review.md']],governed_validate_save_check_exit_codes=[0,0,0],base_check='63ebb3b3e29ca1ed6472597104347d9fbc98f4a5',frozen_pre_save_manifest='34a1ebc6ec6a2b978cd14bcad2b97c92f6720b352ae096da3930f7a42bc9a839',source_snapshot_scope='Only changed/new canonical-owner files since the already-retained pre-save cutoff; hidden/ignored included; final completed pair omitted as payload.',source_snapshot_files=len(selected),source_snapshot_bytes=sum(x['bytes'] for x in selected),all_owned_jobs_terminal=True,no_full_suite_repeat=True,limits=['Qualified native/primary scientific scope and original failures retained.','iModulonDB current native target applicability not_applicable; no negative biology.','Browser interaction/pixel QA unavailable.','No Git/GitHub/record/page/history/runtime mutation by reviewer; only governed review pair written.','Post-save audit is not an input to its own canonical review; no cycle.'])
dump(D/'RESULT.json',result);dump(D/'SOURCE-DELTA.json',dict(pre_save_source_inventory_sha256=sha(O/'pre-save-evidence/SOURCE-INVENTORY.json'),selected=selected,omitted=omitted))
(D/'HANDOFF.md').write_text(f'''# Completed canonical scientific review and post-save audit\n\nQualified pass with zero actionable findings. The governed immutable pair is `reviews/structured/{RID}/review.yaml` and `review.md`. The full review binds421 current input files,22 checks,22 evidence-linked assessments and15 evidence entries. Actual start/finish are retained in RESULT.json; all current input hashes were rechecked before this freeze.\n\nGoverned validate, save and `check --base 63ebb3b3e29ca1ed6472597104347d9fbc98f4a5` all terminated with exit0. The first scratch validation rejected a start-time-prefixed review ID; that unsuccessful draft/receipt is retained and no pair was saved by it. The corrected finish-time ID validates/saves/checks successfully. Two earlier supporting-file harness assumptions likewise remain with their corrected successor; no failed attempt is relabelled clean.\n\nRequired root gates are reused at exact bound states:7591 passed/3 empty custom-command parametrizations skipped/7 dependency warnings; full validation268 records/21683 evidence/516 histories/current pages; final lint/staged whitespace/vendored checks passed. Separate authority3752 and integration29404 assertion reviews are accepted at their explicit limits. No full suite was rerun by this reviewer.\n\nThe record remains SHA47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3. Its source-selected route, taxon ranks, unresolved seventh native association, presumed Mtr, component/whole-complex distinctions, alternatives and primary/chemistry limitations remain explicit. Prior primary reading is reused with attribution, not represented as fresh whole-primary reading. Current iModulonDB has no matched native target dataset; browser interaction/pixel QA remains unavailable. Licensing remains deferred by user instruction.\n\nThis owner contains only new/changed audit files after the already retained pre-save snapshot, including operations, inspections, supporting reassessments, attempted drafts and exact receipts. It does not duplicate the1.8MB frozen pre-save owner or copy the final saved pair. Pair identities/hashes are references in RESULT.json. This post-save packet is deliberately not an input to its own review. No later publication/merge acceptance or issue closure is claimed. All owned jobs are terminal.\n''')
# Plain spacing for the compact human handoff; identifiers/hashes in RESULT remain exact.
h=D/'HANDOFF.md';text=h.read_text()
for a,b in {'binds421':'binds 421','files,22':'files, 22','checks,22':'checks, 22','and15':'and 15','exit0':'exit 0','states:7591':'states: 7591','validation268':'validation 268','records/21683':'records / 21,683','evidence/516':'evidence / 516','authority3752':'authority 3,752','integration29404':'integration 29,404','SHA47':'SHA 47','the1.8MB':'the 1.8 MB'}.items():text=text.replace(a,b)
h.write_text(text)
listed=walk(D);dump(D/'artifact-manifest.json',dict(schema_version=1,created_at=now(),scope='Complete physical post-save audit; hidden/ignored included; excludes manifest/freeze self-reference; nested containers opaque.',listed_files=len(listed),listed_bytes=sum(x['bytes'] for x in listed),files=listed))
freeze=dict(frozen_at=now(),manifest_sha256=sha(D/'artifact-manifest.json'),handoff_sha256=sha(D/'HANDOFF.md'),listed_files=len(listed),physical_files=len(listed)+2,listed_bytes=sum(x['bytes'] for x in listed),all_owned_jobs_terminal=True)
dump(D/'freeze-proof.json',freeze);assert len(walk(D))==len(listed)+2
for x in listed:assert sha(D/x['path'])==x['sha256']
print(json.dumps(dict(owner=str(D),**freeze,freeze_sha256=sha(D/'freeze-proof.json'),saved_pair=result['saved_pair']),indent=2))
