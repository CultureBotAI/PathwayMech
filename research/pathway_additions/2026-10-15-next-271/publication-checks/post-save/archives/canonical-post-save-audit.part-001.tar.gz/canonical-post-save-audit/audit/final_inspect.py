from pathlib import Path
import os,subprocess,json,datetime,hashlib
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review');R=Path('/private/tmp/pathwaymech-next-271-20261015')
paths=set(json.loads((O/'packaging-inputs.json').read_text()))
for p in (R/'research/pathway_additions/2026-10-15-next-271').rglob('*'):
 if p.is_file():assert not p.is_symlink();paths.add(str(p.relative_to(R)))
args=['uv','run','--no-sync','python','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for p in sorted(paths):args+=['--input',p]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONPATH='src:.',UV_NO_SYNC='1',UV_OFFLINE='1',UV_PROJECT_ENVIRONMENT='/private/tmp/pathwaymech-next-263-verified-venv',UV_CACHE_DIR=str(O/'temporary/uv-cache'))
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(args,cwd=R,env=env,capture_output=True)
for x,v in [('stdout',r.stdout),('stderr',r.stderr)]:(O/f'operations/final-inspect.{x}').write_bytes(v)
(O/'operations/final-inspect-receipt.json').write_text(json.dumps(dict(command=args,started_at=start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode),indent=2)+'\n');assert r.returncode==0
new={x['path']:x['sha256'] for x in json.loads(r.stdout)['source']['inputs']};old={x['path']:x['sha256'] for x in json.loads((O/'operations/packaging-successor-inspect-v3.stdout').read_text())['source']['inputs']};delta=dict(inputs=len(new),added=sorted(set(new)-set(old)),changed=[dict(path=p,before=h,after=new[p]) for p,h in old.items() if new[p]!=h]);(O/'assessments/final-input-delta.json').write_text(json.dumps(delta,indent=2)+'\n');print(json.dumps({k:v for k,v in delta.items() if k!='added'},indent=2));print('added',len(delta['added']))
