from pathlib import Path
import os,json,subprocess,datetime,hashlib,re,yaml
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review');R=Path('/private/tmp/pathwaymech-next-271-20261015');p=O/'completed-review.yaml'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
r=yaml.safe_load(p.read_text())
keys={'summary','details','scope_note','description','independence_basis','native_verdict','value','definition','topic','reason'}
def clean(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if isinstance(v,str) and k in keys:
    v=re.sub(r'\b(all|All|Initial|initial|expanded|final|Final|exact|after|before|new|old|native|across|with|only|total|snapshot|manifest|SVG)(?=[0-9])',r'\1 ',v)
    v=re.sub(r'(?<=[0-9])(?=(?:passed|skipped|warnings|records|histories|evidence|seconds|inputs|files|keys|organisms|native|taxa|terms|assertions|record|activity|original|source|support|checks)\b)', ' ',v)
    v=re.sub(r'(?<=\d), (?=\d{3}(?!\d))',',',v);v=v.replace('E.coli','E. coli');x[k]=v
   else:clean(v)
 elif isinstance(x,list):
  for v in x:clean(v)
clean(r);finish=datetime.datetime.now(datetime.timezone.utc);r['finished_at']=finish.isoformat(timespec='seconds').replace('+00:00','Z');r['review_id']=finish.strftime('%Y%m%dT%H%M%SZ')+'-acetate-methanogenesis-maintained-record-review';p.write_text(yaml.safe_dump(r,sort_keys=False,allow_unicode=True,width=105))
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONPATH='src:.',UV_NO_SYNC='1',UV_OFFLINE='1',UV_PROJECT_ENVIRONMENT='/private/tmp/pathwaymech-next-263-verified-venv',UV_CACHE_DIR=str(O/'temporary/uv-cache'))
for name,suffix in [('canonical-validate-v2',['validate',str(p)]),('canonical-save-v2',['save','--content',str(p)]),('canonical-check-v2',['check','--base','63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'])]:
 cmd=['uv','run','--no-sync','python','scripts/record_review.py']+suffix;start=now();q=subprocess.run(cmd,cwd=R,env=env,capture_output=True)
 for x,v in [('stdout',q.stdout),('stderr',q.stderr)]:(O/f'operations/{name}.{x}').write_bytes(v)
 (O/f'operations/{name}-receipt.json').write_text(json.dumps(dict(command=cmd,started_at=start,finished_at=now(),exit_code=q.returncode,stdout_sha256=hashlib.sha256(q.stdout).hexdigest(),stderr_sha256=hashlib.sha256(q.stderr).hexdigest()),indent=2)+'\n')
 print(name,q.returncode,q.stdout.decode(),q.stderr.decode(),flush=True)
 if q.returncode:raise SystemExit(q.returncode)
