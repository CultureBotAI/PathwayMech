from pathlib import Path
import os,json,hashlib,datetime,subprocess,ast,shutil,re
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review');R=Path('/private/tmp/pathwaymech-next-271-20261015');C=Path('/private/tmp/pathwaymech-next-271-ci')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
b=json.loads((C/'candidate-packaging-successor-bindings.json').read_text());assert len(b['files'])==251
for x in b['files']:assert sha(R/x['path'])==x['sha256']
inputs=sorted(set(json.loads((O/'expanded-inputs.json').read_text())+[x['path'] for x in b['files']]))
dump(O/'packaging-inputs.json',inputs)
args=['uv','run','--no-sync','python','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for p in inputs:args+=['--input',p]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONPATH='src:.',UV_NO_SYNC='1',UV_OFFLINE='1',UV_PROJECT_ENVIRONMENT='/private/tmp/pathwaymech-next-263-verified-venv',UV_CACHE_DIR=str(O/'temporary/uv-cache'))
start=now();r=subprocess.run(args,cwd=R,env=env,capture_output=True)
for ext,data in [('stdout',r.stdout),('stderr',r.stderr)]:(O/f'operations/packaging-successor-inspect-v2.{ext}').write_bytes(data)
dump(O/'operations/packaging-successor-inspect-v2-receipt.json',dict(command=args,started_at=start,finished_at=now(),exit_code=r.returncode));assert r.returncode==0
old={x['path']:x['sha256'] for x in json.loads((O/'operations/authority-expanded-inspect.stdout').read_text())['source']['inputs']};new={x['path']:x['sha256'] for x in json.loads(r.stdout)['source']['inputs']};changed=[dict(path=p,before=h,after=new[p]) for p,h in old.items() if new[p]!=h]
format_result=json.loads((C/'packaging-formatting-result.json').read_text());ast_results=[]
for item in format_result['files']:
 original=R/item['original_path'];current=R/item['path'];assert sha(original)==old[item['path']]
 trees=[ast.parse(p.read_text()) for p in [original,current]]
 for t in trees:t.body=[x for x in t.body if not isinstance(x,(ast.Import,ast.ImportFrom))]
 equal=ast.dump(trees[0],include_attributes=False)==ast.dump(trees[1],include_attributes=False);assert equal
 constants=[[repr(x.value) for x in ast.walk(ast.parse(p.read_text())) if isinstance(x,ast.Constant)] for p in [original,current]];assert sorted(constants[0])==sorted(constants[1])
 ast_results.append(dict(path=item['path'],original_retained=item['original_path'],non_import_ast_identical=equal,all_literal_values_identical=True,current_sha256=sha(current)))
attribute='research/pathway_additions/2026-10-15-next-271/authority-source-originals/.gitattributes';original=(C/'authority-originals-gitattributes-before-packaging-fix.txt').read_bytes();assert hashlib.sha256(original).hexdigest()==old[attribute]
current=(R/attribute).read_bytes();assert current==b'# Preserve exact issuing-source XML, including original end-of-line spaces.\n/originals/*.xml -text whitespace=-blank-at-eol\nacquisition/*.json -text\n';assert original==b'originals/*.xml -text\nacquisition/*.json -text\n'
page=json.loads((C/'render-pages-history-successor-result.json').read_text());html=(R/'pages/records/MetaCyc_METH-ACETATE-PWY.html').read_text();assert sha(R/'pages/records/MetaCyc_METH-ACETATE-PWY.html')==page['new_page_sha256'];assert html.count(page['changed_after_text'])==1
reversed_page=html.replace(page['changed_after_text'],page['changed_before_text']);assert hashlib.sha256(reversed_page.encode()).hexdigest()==page['old_page_sha256']
svg=re.findall(r'<svg\b[^>]*class="[^"]*pathway-network-svg[^\"]*"[\s\S]*?</svg>',html);assert len(svg)==1
assert hashlib.sha256(svg[0].encode()).hexdigest()=='0c7e4a5122b83c0b06c9bbf5aec837437b7a18c3fa7adfac27cb8e7134eba99c'
expected={x['path'] for x in format_result['files']}|{attribute,'pages/records/MetaCyc_METH-ACETATE-PWY.html'};assert {x['path'] for x in changed}==expected
for f in ['candidate-packaging-successor-bindings.json','render-pages-history-successor-result.json','packaging-formatting-result.json','source-whitespace-successor-binding.json','staged-diff-packaging-successor-result.json']:
 shutil.copyfile(C/f,O/'inputs/root-checks'/f)
dump(O/'assessments/supporting-successor-assessment.json',dict(at=now(),inspected_inputs=len(new),prior_inputs=len(old),changed_inputs=changed,new_inputs=sorted(set(new)-set(old)),helpers=ast_results,attribute_change='XML preservation rule anchored to /originals/*.xml with -text preserved, narrow whitespace=-blank-at-eol added and explanatory comment; acquisition rule unchanged. No XML bytes changed.',page_history_only_replacement_reconstructs_old_hash=True,network_svg_sha256='0c7e4a5122b83c0b06c9bbf5aec837437b7a18c3fa7adfac27cb8e7134eba99c',record_and_authority_core_unchanged=True,scope='Direct reading and independent AST/constants/history reversal proof of all six changed previously inspected supporting inputs; no rerun of full gates or global authority approval.'))
print(json.dumps(dict(inspected_inputs=len(new),changed_previous_inputs=len(changed),non_import_ast_and_constants_exact=True,page_only_history_change=True),indent=2))
