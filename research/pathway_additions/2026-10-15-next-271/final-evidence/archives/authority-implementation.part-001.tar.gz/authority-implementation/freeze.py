"""Record terminal receipts, bind released owners, and freeze this author packet."""
from pathlib import Path
import hashlib
import json
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
wt = Path('/private/tmp/pathwaymech-next-271-20261015')
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def dump(rel, value):
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def file(rel):
    raw = (root / rel).read_bytes()
    return {'path': rel, 'bytes': len(raw), 'sha256': sha(raw)}

checks = [
    ('focused-final', ['python -B -m pytest -q tests/test_acetate_methanogenesis_authority.py'],
     'tests-final', 0, '396 passed in 10.01s'),
    ('regression-initial', ['python -B -m pytest -q tests/test_methanogenesis_authority.py tests/test_biocyc_carrier_authority.py tests/test_source_identifier_snapshot.py tests/test_identifiers.py tests/test_identifier_snapshot_builders.py'],
     'regression', 1, '1008 passed; five subprocess imports failed without PYTHONPATH'),
    ('regression-import-successor', ['PYTHONPATH=/private/tmp/pathwaymech-next-271-20261015/src python -B -m pytest -q tests/test_biocyc_carrier_authority.py -k test_native_provenance_order_is_stable_across_processes'],
     'regression-environment-successor', 0, '5 passed, 570 deselected in 4.02s'),
    ('actual-identifier-gate', ['PYTHONPATH=src python -B - (identifier_errors(Path.cwd()); assert unchanged record SHA)'],
     'maintained-identifier-gate-successor', 0, '268 records, zero errors'),
    ('lint', ['python -B -m ruff check src/pathwaymech/biocyc_acetate_methanogenesis.py src/pathwaymech/identifiers.py scripts/build_source_identifier_snapshot.py tests/test_acetate_methanogenesis_authority.py'],
     'lint-release', 0, 'All checks passed'),
    ('tracked-owned-diff-check', ['git diff --check -- src/pathwaymech/identifiers.py scripts/build_source_identifier_snapshot.py conf/identifier_sources.json data/identifier_authorities/sources.json data/identifier_authorities/ontology.json docs/IDENTIFIERS.md'],
     'diff-check-successor', 0, 'exit 0'),
    ('reproduction-seed-271', ['PYTHONHASHSEED=271 python -B build_additions.py --output ' + str(root / 'reproduction-a')],
     'reproduction-a', 0, '52 native and five taxonomy additions, no integration'),
    ('reproduction-seed-172', ['PYTHONHASHSEED=172 python -B build_additions.py --output ' + str(root / 'reproduction-b')],
     'reproduction-b', 0, '52 native and five taxonomy additions, no integration'),
    ('public-source-builder-cli', ['PYTHONPATH=src python -B scripts/build_source_identifier_snapshot.py --manifest ' + str(root / 'results/proposed-source-manifest.json') + ' --cache-dir ' + str(root / 'build-2/cache') + ' --records ' + str(root / 'build-2/selection') + ' --output ' + str(root / 'cli-source-additions.json')],
     'cli-build', 0, '52 sources and terms; bytes equal helper function output'),
    ('release-verification', ['python -B verify_release.py'],
     'release-verification', 0, '7634 author preservation/source/input checks'),
]
dump('results/check-receipts.json', {
    'runtime': '/private/tmp/pathwaymech-next-263-verified-venv/bin/python',
    'scope': 'Author focused checks; no full-suite or independent acceptance claim.',
    'commands_use_runtime_abbreviation_python': True,
    'checks': [{'name': name, 'commands': command, 'authoritative_returncode': code,
                'outcome': outcome, 'logs': [file(prefix + ext) for ext in ('.stdout','.stderr')]}
               for name, command, prefix, code, outcome in checks],
    'earlier_failed_attempts_retained': ['collection-initial.stderr','collection-successor.stderr',
       'adapter-generation.stderr','build-1.stderr','tests-initial.stdout','lint-initial.stdout',
       'maintained-identifier-gate.stderr','regression.stdout','diff-check.stderr'],
})
for row in json.loads((root / 'results/maintained-owner-bindings.json').read_text())['files']:
    assert sha((wt / row['path']).read_bytes()) == row['sha256'], row['path']
    assert sha((root / row['copy']).read_bytes()) == row['sha256'], row['copy']
assert (root / 'cli-source-additions.json').read_bytes() == (root / 'reproduction-a/source-additions.json').read_bytes()
dump('results/final-cutoff.json', {
    'utc': datetime.now(timezone.utc).isoformat(), 'all_owned_jobs_terminal': True,
    'owned_maintained_files': 175, 'all_maintained_and_frozen_copy_hashes_match': True,
    'cli_source_delta': file('cli-source-additions.json'),
    'source_snapshot': file('maintained/data/identifier_authorities/sources.json'),
    'ontology_snapshot': file('maintained/data/identifier_authorities/ontology.json'),
    'authority_review_pending': True, 'final_project_gates_pending_root': True,
})
exclusions = {'artifact-manifest.json','freeze-proof.json'}
files = []
for path in sorted(root.rglob('*')):
    if path.is_symlink():
        raise ValueError('Unexpected symbolic link: ' + str(path))
    if path.is_file() and str(path.relative_to(root)) not in exclusions:
        files.append(file(str(path.relative_to(root))))
dump('artifact-manifest.json', {'version': 1,
    'scope': 'All physical files including hidden/ignored files; manifest and freeze proof self-excluded. No global or recursive nested-container scientific inventory claim.',
    'files': files})
for row in files:
    assert file(row['path']) == row
dump('freeze-proof.json', {
    'utc': datetime.now(timezone.utc).isoformat(),
    'manifest_sha256': sha((root / 'artifact-manifest.json').read_bytes()),
    'handoff_sha256': sha((root / 'HANDOFF.md').read_bytes()),
    'listed_files': len(files), 'physical_files': len(files) + 2,
    'listed_bytes': sum(r['bytes'] for r in files),
    'all_owned_jobs_terminal': True, 'all_member_hashes_replayed': True,
    'all_owned_maintained_files_rehashed_unchanged': 175,
    'scope': 'Author authority implementation release for independent review only.'})
print(json.dumps({
    'manifest': sha((root / 'artifact-manifest.json').read_bytes()),
    'handoff': sha((root / 'HANDOFF.md').read_bytes()),
    'freeze': sha((root / 'freeze-proof.json').read_bytes()),
    'listed': len(files), 'physical': len(files) + 2,
    'listed_bytes': sum(r['bytes'] for r in files),
}, indent=2))
