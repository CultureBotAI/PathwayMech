"""Build the finite additive adapter from frozen originals and wire its boundaries."""
from pathlib import Path
from collections import Counter
import json
import pprint
import re
from xml.etree import ElementTree as ET

OWN = Path(__file__).resolve().parent
WT = Path('/private/tmp/pathwaymech-next-271-20261015')
rows = json.loads((OWN / 'results/all-52-native-profile-inventory.json').read_text())
def fmt(value):
    return pprint.pformat(value, width=99, sort_dicts=True)

profiles, equations, activities, components, materials = {}, {}, {}, {}, {}
complexes = set()
tags = {r['tag'] for r in json.loads((OWN / 'results/embedded-object-shape-inventory.json').read_text())}
for r in rows:
    e = ET.fromstring((OWN / r['body']).read_bytes())[1]
    ident = r['id']
    shape = Counter((n.tag, n.get('class', ''), n.get('detail', ''))
                    for n in e.iter() if n is not e and n.get('frameid') is not None)
    profiles[ident] = {'tag': r['tag'], 'is_class': r['is_class'], 'slots': r['slots'],
        'parents': [(n['tag'], n['frame']) for n in r['parents']],
        'embedded_shapes': dict(shape)}
    if r['tag'] == 'Reaction':
        eq = {'direction': e.findtext('reaction-direction')}
        for side in ('left', 'right'):
            eq[side] = []
            for wrapper in e.findall(side):
                n = next(n for n in wrapper if n.tag not in {'coefficient', 'compartment'})
                assert wrapper.find('compartment') is None
                coeff = wrapper.find('coefficient')
                eq[side].append({'material': 'MetaCyc:' + n.get('frameid'), 'native_type': n.tag,
                    'is_class': n.get('class') == 'true',
                    'coefficient': int(coeff.text) if coeff is not None else None, 'compartment': None})
                materials[n.get('frameid')] = {'tag': n.tag, 'is_class': n.get('class') == 'true'}
        equations[ident] = eq
    if r['tag'] == 'Enzymatic-Reaction':
        activities[ident] = {s: 'MetaCyc:' + e.find(s)[0].get('frameid') for s in ('enzyme','reaction')}
    if r['expected_category'] == 'complex':
        complexes.add(ident)
        components[ident] = []
        for w in e.findall('component'):
            coeff = w.find('coefficient')
            components[ident].append({'id': 'MetaCyc:' + w.find('Protein').get('frameid'),
                'coefficient': int(coeff.text) if coeff is not None else None})

old = (OWN / 'inputs/baseline/src/pathwaymech/biocyc_methanogenesis.py').read_text()
text = old.replace('methanogenesis', 'acetate_methanogenesis').replace('METHANOGENESIS', 'ACETATE_METHANOGENESIS')
text = text.replace('metacyc-acetate_methanogenesis-xml', 'metacyc-acetate-methanogenesis-xml')
text = text.replace('ACETATE_METHANOGENESIS-PWY', 'METH-ACETATE-PWY')
text = text.replace('all 92 selected', 'all 52 selected')
start, end = text.index('PROFILES = '), text.index('NODE_ROLES = ')
text = text[:start] + ('PROFILES = ' + fmt(profiles) + '\nCOMPLEXES = ' + fmt(complexes)
    + '\nMATERIAL_ROLES = ' + fmt(materials) + '\nNATIVE_MEMBERS = '
    + fmt({ident.split(':', 1)[1] for ident in equations})
    + '\nEXACT_EQUATIONS = ' + fmt(equations) + '\nEXACT_ACTIVITIES = ' + fmt(activities)
    + '\nEXACT_COMPONENTS = ' + fmt(components) + '\n') + text[end:]
text = text.replace('    "native_acetate_methanogenesis_protein":',
                    '    "native_acetate_methanogenesis_protein_class": ("participants", {"protein"}),\n'
                    '    "native_acetate_methanogenesis_protein":')
# No new location identities: the single membrane node keeps its existing owner.
text = text.replace('    "native_acetate_methanogenesis_location": ("participants", {"cellular_component"}),\n', '')
start, end = text.index('    if ident in UNNAMED_HOMOMERS:'), text.index('    aliases = sorted(')
text = text[:start] + text[end:]
text = text.replace('"Protein": "complex" if ident in COMPLEXES else "protein",',
    '"Protein": "protein_class" if native["is_class"] else (\n'
    '            "complex" if ident in COMPLEXES else "protein"\n        ),')
text = text.replace('            bool(components) and len({r["id"] for r in components}) == len(components),\n'
                    '            "empty or duplicate native complex components",',
                    '            len({r["id"] for r in components}) == len(components)\n'
                    '            and components == EXACT_COMPONENTS[ident],\n'
                    '            "unsupported or duplicate native complex components",')
# Empty composition is permitted only for the two exact, source-typed complexes.
text = text.replace('        result["reaction_direction"] = direction',
    '        require(\n            {**result["sides"], "direction": direction} == EXACT_EQUATIONS[ident],\n'
    '            "native equation differs from the bounded original scope",\n        )\n'
    '        result["reaction_direction"] = direction')
text = text.replace('            result[slot] = ref_node(wrapper[0], pgdb, tag)["id"]',
    '            result[slot] = ref_node(wrapper[0], pgdb, tag)["id"]\n'
    '            require(result[slot] == EXACT_ACTIVITIES[ident][slot], "wrong exact activity link")')
# This source has no located equation occurrences; transport from the CO2 pathway is not reusable.
start, end = text.index('        if compartment is not None:\n            blank(compartment)'), text.index('        result.append(', text.index('def _side'))
text = text[:start] + '        require(compartment is None, "acetate pathway equation materials are unlocated")\n' + text[end:]
# Validate complete parent identities and every embedded object shape, not just surviving attributes.
needle = '    # Check every embedded native identity while retaining uninterpreted context.'
insert = '''    parents = []
    for wrapper in entity.findall("parent"):
        blank(wrapper)
        require(not wrapper.attrib and len(wrapper) == 1, "invalid direct parent")
        node = wrapper[0]
        parent = _literal_ref(node, pgdb, entity.tag, is_class=True)
        parents.append((node.tag, parent["id"].split(":", 1)[1]))
    require(parents == PROFILES[ident]["parents"], "native parent/type scope mismatch")
    shapes = Counter()
'''
text = text.replace(needle, insert + needle)
text = text.replace('        native = node.get("orgid", "") + ":" + node.get("frameid", "")', '''        require(node.tag in _NATIVE_OBJECT_TAGS, "unknown embedded native object type")
        expected_attrs = {"frameid", "orgid"}
        if "ID" in node.attrib:
            expected_attrs |= {"ID", "detail"}
            require(node.get("detail") in {"low", "full"}, "invalid embedded detail")
        else:
            expected_attrs.add("resource")
        if "class" in node.attrib:
            require(node.get("class") == "true", "invalid embedded class flag")
            expected_attrs.add("class")
        require(set(node.attrib) == expected_attrs, "invalid embedded identity attributes")
        if node is not entity:
            shapes[(node.tag, node.get("class", ""), node.get("detail", ""))] += 1
        native = node.get("orgid", "") + ":" + node.get("frameid", "")''')
text = text.replace('    return root, entity, ident',
    '    require(shapes == PROFILES[ident]["embedded_shapes"], "incomplete embedded object shapes")\n'
    '    return root, entity, ident')
# Reject untyped legacy claims for charged form values as well as bare queries.
text = text.replace('            params = parse_qs(url.query)\n'
    '            tokens = [v for name in ("id", "object") for v in params.get(name, [])]',
    '            params = parse_qs(url.query)\n'
    '            tokens = [v for name in ("id", "object") for v in params.get(name, [])]\n'
    '            # Rejection recognition also preserves literal plus signs in legacy values.\n'
    '            tokens += [unquote(value) for field in url.query.split("&")\n'
    '                       for key, sep, value in [field.partition("=")]\n'
    '                       if sep and unquote(key) in {"id", "object"}]')
text = text.replace('and url.query.startswith(("META:", "ECOLI:"))',
                    'and unquote(url.query).startswith(("META:", "ECOLI:"))')
(WT / 'src/pathwaymech/biocyc_acetate_methanogenesis.py').write_text(text)

# Each integration is additive to the exact original baseline; no previous profile changes.
for relative in ['src/pathwaymech/identifiers.py', 'scripts/build_source_identifier_snapshot.py']:
    text = (OWN / ('inputs/baseline/' + relative)).read_text()
    import_text = '''from pathwaymech.biocyc_acetate_methanogenesis import (
    ACETATE_METHANOGENESIS_KINDS,
    acetate_methanogenesis_metadata,
    acetate_methanogenesis_term,
    validate_acetate_methanogenesis_assertions,
    validate_acetate_methanogenesis_metadata,
)
from pathwaymech.biocyc_acetate_methanogenesis import FIELD as ACETATE_METHANOGENESIS_FIELD
from pathwaymech.biocyc_acetate_methanogenesis import NODE_ROLES as ACETATE_METHANOGENESIS_NODE_ROLES
'''
    if relative.startswith('scripts/'):
        import_text = import_text.replace('    validate_acetate_methanogenesis_metadata,\n', '')
        import_text = import_text.replace('from pathwaymech.biocyc_acetate_methanogenesis import FIELD as ACETATE_METHANOGENESIS_FIELD\n', '')
        import_text = import_text.replace('from pathwaymech.biocyc_acetate_methanogenesis import NODE_ROLES as ACETATE_METHANOGENESIS_NODE_ROLES\n', '')
    else:
        import_text = import_text.replace('    acetate_methanogenesis_metadata,\n', '')
    idx = text.index('from pathwaymech.biocyc_methanogenesis import')
    text = text[:idx] + import_text + text[idx:]
    if relative.startswith('src/'):
        text = text.replace('    fields.update({kind: METHANOGENESIS_FIELD for kind in METHANOGENESIS_KINDS})',
            '    fields.update({kind: METHANOGENESIS_FIELD for kind in METHANOGENESIS_KINDS})\n'
            '    fields.update({kind: ACETATE_METHANOGENESIS_FIELD\n'
            '                   for kind in ACETATE_METHANOGENESIS_KINDS})')
        text = text.replace('                METHANOGENESIS_FIELD,',
                            '                METHANOGENESIS_FIELD,\n                ACETATE_METHANOGENESIS_FIELD,')
        text = text.replace('| GLUTARYL_KINDS | METHANOGENESIS_KINDS | {',
                            '| GLUTARYL_KINDS | METHANOGENESIS_KINDS | ACETATE_METHANOGENESIS_KINDS | {')
        needle = '        if metadata.get("kind") in METHANOGENESIS_KINDS:'
        text = text.replace(needle, '        if metadata.get("kind") in ACETATE_METHANOGENESIS_KINDS:\n'
            '            validate_acetate_methanogenesis_metadata(metadata)\n'
            '        elif ACETATE_METHANOGENESIS_FIELD in metadata:\n'
            '            raise ValueError("acetate methanogenesis metadata requires its matching kind")\n' + needle)
        text = text.replace('    validate_methanogenesis_assertions(data["sources"], [])',
            '    validate_methanogenesis_assertions(data["sources"], [])\n'
            '    validate_acetate_methanogenesis_assertions(data["sources"], [])')
        start = text.index('        elif source_kind in METHANOGENESIS_KINDS:')
        end = text.index('\n        elif ', start + 10)
        block = text[start:end]
        text = text[:end] + '\n' + block.replace('METHANOGENESIS', 'ACETATE_METHANOGENESIS').replace('methanogenesis', 'acetate_methanogenesis') + text[end:]
        needle = '    return data["terms"]'
        text = text.replace(needle, '    validate_acetate_methanogenesis_assertions(\n'
            '        data["sources"], [(ident, term["source"]) for ident, term in data["terms"].items()]\n'
            '    )\n' + needle)
        text = text.replace('PHENYLACETATE_NODE_ROLES | GLUTARYL_NODE_ROLES | METHANOGENESIS_NODE_ROLES',
                            'PHENYLACETATE_NODE_ROLES | GLUTARYL_NODE_ROLES | METHANOGENESIS_NODE_ROLES\n'
                            '                | ACETATE_METHANOGENESIS_NODE_ROLES')
    else:
        needle = '    carrier_sources = {'
        text = text.replace(needle, '    acetate_methanogenesis_sources = {\n'
            '        index: acetate_methanogenesis_metadata(entry, cache_dir)\n'
            '        if entry["kind"] in ACETATE_METHANOGENESIS_KINDS else entry\n'
            '        for index, entry in enumerate(entries)\n    }\n'
            '    validate_acetate_methanogenesis_assertions(acetate_methanogenesis_sources, [])\n' + needle)
        text = text.replace('| GLUTARYL_KINDS | METHANOGENESIS_KINDS\n',
                            '| GLUTARYL_KINDS | METHANOGENESIS_KINDS | ACETATE_METHANOGENESIS_KINDS\n')
        needle = '        elif entry["kind"] in METHANOGENESIS_KINDS:'
        text = text.replace(needle, '        elif entry["kind"] in ACETATE_METHANOGENESIS_KINDS:\n'
            '            metadata = acetate_methanogenesis_sources[entry_index]\n'
            '            identifier, typed_term = acetate_methanogenesis_term(metadata, key)\n'
            '            parsed_terms = [(identifier, typed_term["label"], typed_term["synonyms"])]\n' + needle)
        needle = '            if entry["kind"] in METHANOGENESIS_KINDS:'
        text = text.replace(needle, '            if entry["kind"] in ACETATE_METHANOGENESIS_KINDS:\n'
            '                terms[identifier] = acetate_methanogenesis_term(metadata, key)[1]\n' + needle)
        text = text.replace('    validate_methanogenesis_assertions(all_aceto_sources, all_aceto_claims)',
            '    validate_methanogenesis_assertions(all_aceto_sources, all_aceto_claims)\n'
            '    validate_acetate_methanogenesis_assertions(all_aceto_sources, all_aceto_claims)')
    (WT / relative).write_text(text)
print('Wrote one finite adapter and additive producer/consumer hooks.')
