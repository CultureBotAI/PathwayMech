"""Reproduce only new authorities, preserving every pinned baseline owner/order."""
from __future__ import annotations
import argparse
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import yaml

OWN = Path(__file__).resolve().parent
WT = Path('/private/tmp/pathwaymech-next-271-20261015')
sys.path[:0] = [str(WT / 'src'), str(WT)]
from scripts.build_source_identifier_snapshot import build_snapshot
from pathwaymech.identifiers import _load_authority

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

args = argparse.ArgumentParser()
args.add_argument('--output', type=Path, required=True)
args.add_argument('--integrate', action='store_true')
args = args.parse_args()
out = args.output
out.mkdir(parents=True, exist_ok=True)
base = OWN / 'inputs/baseline'
for relative in ['data/identifier_authorities/sources.json', 'data/identifier_authorities/ontology.json',
                 'conf/identifier_sources.json']:
    copy = base / relative
    if not copy.exists():
        copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(WT / relative, copy)

entries = json.loads((OWN / 'results/proposed-source-manifest.json').read_text())
rows = json.loads((OWN / 'results/all-52-native-profile-inventory.json').read_text())
manifest = out / 'manifest.json'
dump(manifest, entries)
cache = out / 'cache'
for entry, row in zip(entries, rows, strict=True):
    raw = (OWN / row['body']).read_bytes()
    assert sha(raw) == entry['sha256']
    target = cache / entry['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
record = {'id': 'MetaCyc:METH-ACETATE-PWY', 'participants': [], 'reactions': []}
for row in rows:
    if row['expected_section'] not in {'record', 'root'}:
        record[row['expected_section']].append({'id': row['id']})
corpus = out / 'selection'
corpus.mkdir(exist_ok=True)
(corpus / 'authority-selection.yaml').write_text(yaml.safe_dump(record, sort_keys=False))
delta = build_snapshot(manifest, corpus, cache)
assert set(delta['terms']) == {r['id'] for r in rows}
assert len(delta['sources']) == len(delta['terms']) == 52
dump(out / 'source-additions.json', delta)
old_source = json.loads((base / 'data/identifier_authorities/sources.json').read_text())
merged = json.loads(json.dumps(old_source))
for section in ('sources', 'terms'):
    assert not (merged[section].keys() & delta[section].keys())
    merged[section].update(delta[section])
    assert list(merged[section])[:len(old_source[section])] == list(old_source[section])
    assert all(merged[section][key] == value for key, value in old_source[section].items())
dump(out / 'sources.json', merged)
_load_authority(out / 'sources.json')

old_ontology = json.loads((base / 'data/identifier_authorities/ontology.json').read_text())
taxrows = json.loads((OWN / 'inputs/taxonomy/taxonomy-complete-selected-statements.json').read_text())
spec = importlib.util.spec_from_file_location('pinned_ontology_extractor', base / 'scripts/build_ontology_identifier_snapshot.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
import sqlite3
with sqlite3.connect(':memory:') as connection:
    connection.execute('CREATE TABLE statements (subject TEXT, predicate TEXT, value TEXT)')
    ids = ['NCBITaxon:2207', 'NCBITaxon:2208', 'NCBITaxon:2210', 'NCBITaxon:2214', 'NCBITaxon:2222', 'NCBITaxon:2224']
    for ident in ids:
        for row in taxrows[ident]:
            connection.execute('INSERT INTO statements VALUES (?,?,?)', (row['subject'], row['predicate'], row['value']))
    key = old_ontology['terms']['NCBITaxon:2208']['source']
    taxterms, missing = module.extract_terms(connection, ids, key)
assert not missing and taxterms['NCBITaxon:2208'] == old_ontology['terms']['NCBITaxon:2208']
ontology = json.loads(json.dumps(old_ontology))
for ident, term in taxterms.items():
    if ident not in ontology['terms']:
        ontology['terms'][ident] = term
assert len(ontology['terms']) - len(old_ontology['terms']) == 5
assert ontology['sources'] == old_ontology['sources']
assert list(ontology['terms'])[:len(old_ontology['terms'])] == list(old_ontology['terms'])
assert all(ontology['terms'][key] == value for key, value in old_ontology['terms'].items())
dump(out / 'ontology.json', ontology)
_load_authority(out / 'ontology.json')
old_conf = json.loads((base / 'conf/identifier_sources.json').read_text())
assert not ({e['key'] for e in old_conf} & {e['key'] for e in entries})
dump(out / 'identifier_sources.json', old_conf + entries)

if args.integrate:
    for filename, rel in [('sources.json','data/identifier_authorities/sources.json'),
                          ('ontology.json','data/identifier_authorities/ontology.json'),
                          ('identifier_sources.json','conf/identifier_sources.json')]:
        shutil.copyfile(out / filename, WT / rel)
    owner = WT / 'research/pathway_additions/2026-10-15-next-271/authority-source-originals'
    fixtures = WT / 'tests/fixtures/acetate_methanogenesis_authority'
    owner.mkdir(parents=True, exist_ok=True)
    fixtures.mkdir(parents=True, exist_ok=True)
    dump(owner / 'manifest.json', entries)
    dump(fixtures / 'manifest.json', entries)
    storage = {}
    for entry, row in zip(entries, rows, strict=True):
        raw = (OWN / row['body']).read_bytes()
        filename = Path(row['body']).name
        target = owner / 'originals' / filename
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(raw)
        receipt = owner / 'acquisition' / (filename.removesuffix('.xml') + '.json')
        receipt.parent.mkdir(exist_ok=True)
        shutil.copyfile(OWN / 'inputs/acquisition' / receipt.name, receipt)
        packed = gzip.compress(raw, mtime=0)
        packed_name = filename + '.gz'
        (fixtures / packed_name).write_bytes(packed)
        storage[entry['path']] = {'path': packed_name, 'bytes': len(raw), 'sha256': sha(raw),
                               'compressed_bytes': len(packed), 'compressed_sha256': sha(packed)}
    dump(fixtures / 'storage.json', storage)
    dump(owner / 'selected-original-bindings.json', rows)
    for rel in ['taxonomy-complete-selected-statements.json','taxonomy-selected-lineages.json','taxonomy-query-receipt.json']:
        target = owner / 'taxonomy' / rel
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(OWN / 'inputs/taxonomy' / rel, target)
    for rel in ['five-additive-taxonomy-term-proposals.json','taxonomy-probe.json']:
        shutil.copyfile(OWN / 'results' / rel, owner / 'taxonomy' / rel)
    (owner / '.gitattributes').write_text('originals/*.xml -text\nacquisition/*.json -text\n')
dump(out / 'reproduction-receipt.json', {
    'native_additions': 52, 'taxonomy_additions': 5, 'all_existing_owner_objects_and_order_preserved': True,
    'source_snapshot_sha256': sha((out / 'sources.json').read_bytes()),
    'ontology_snapshot_sha256': sha((out / 'ontology.json').read_bytes()),
    'manifest_sha256': sha((out / 'identifier_sources.json').read_bytes()),
    'scope': 'Only the new 52 full XML originals and five pinned taxa are projected; no historical cache rebuild or full taxonomy rehash.',
})
print(json.dumps({'native': 52, 'taxa': 5, 'output': str(out), 'integrated': args.integrate}))
