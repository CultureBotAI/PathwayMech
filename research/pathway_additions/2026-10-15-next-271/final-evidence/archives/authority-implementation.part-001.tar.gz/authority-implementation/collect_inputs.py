"""Collect and inventory bounded planning inputs; no authority implementation."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path
import sqlite3
import subprocess
import sys
from xml.etree import ElementTree as ET

OUT = Path(__file__).resolve().parent
WT = Path('/private/tmp/pathwaymech-next-271-20261015')
GRAPH = Path('/private/tmp/pathwaymech-next-271-graph-design')
ISSUER = Path('/private/tmp/pathwaymech-next-271-issuer-preparation')
CI = Path('/private/tmp/pathwaymech-next-271-ci')
BASE = '63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'
TREE = '5448122efcfbd8ae2ac90ad42e70557b03d9b78e'
KIND = 'metacyc-acetate-methanogenesis-xml'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(path, value):
    p = OUT / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

bindings = []
def copy(source, destination, expected=None):
    raw = source.read_bytes()
    if expected:
        assert sha(raw) == expected, str(source)
    dest = OUT / destination
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    bindings.append({'source': str(source), 'copy': destination, 'bytes': len(raw), 'sha256': sha(raw)})
    return raw

def manifest_copy(root, relative, dest=None):
    manifest = json.loads((root / 'artifact-manifest.json').read_text())
    expected = {r['path']: r['sha256'] for r in manifest['files']}[relative]
    return copy(root / relative, dest or ('inputs/' + root.name + '/' + relative), expected)

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WT, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=WT, text=True).strip()
assert (head, tree) == (BASE, TREE)

baseline_files = [
    'src/pathwaymech/biocyc_methanogenesis.py', 'src/pathwaymech/biocyc_carrier.py',
    'src/pathwaymech/biocyc_native_context.py', 'src/pathwaymech/biocyc_p321.py',
    'src/pathwaymech/identifiers.py', 'scripts/build_source_identifier_snapshot.py',
    'scripts/build_ontology_identifier_snapshot.py', 'tests/test_methanogenesis_authority.py',
    'tests/test_identifier_snapshot_builders.py', 'tests/test_identifiers.py',
    'tests/test_source_identifier_snapshot.py', 'conf/identifier_policy.yaml',
    'docs/IDENTIFIERS.md', '.claude/skills/add-pathway/SKILL.md',
]
base_rows = []
for rel in baseline_files:
    raw = copy(WT / rel, 'inputs/baseline/' + rel)
    committed = subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=WT)
    assert raw == committed, rel
    base_rows.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw), 'equals_merged_blob': True})
for rel in ['src/pathwaymech/schema.py', 'docs/CAUSAL_GRAPHS.md', 'tests/test_graph_context.py']:
    raw = copy(WT / rel, 'inputs/endpoint-successor/' + rel)
    base_rows.append({'path': rel, 'bytes': len(raw), 'sha256': sha(raw), 'equals_merged_blob': False,
                      'scope': 'Released issue 630 endpoint successor; not an authority implementation change.'})

for rel in ['authority-implementation-preflight.json', 'activity-endpoint-product-changes.json',
            'root-intake-next271-activity-endpoint-review.json',
            'root-intake-next271-independent-issuer-review.json',
            'root-intake-next271-merged-baseline-independent-rebind.json']:
    copy(CI / rel, 'inputs/root-receipts/' + rel)
assert sha((GRAPH / 'artifact-manifest.json').read_bytes()) == 'c680126985a8447ac0ef5d9f3f6ea14512c55cb74e1a1cc3ca948c0dcf8e1882'
for rel in ['artifact-manifest.json', 'freeze-proof.json']:
    copy(GRAPH / rel, 'inputs/graph/' + rel)
for rel in ['HANDOFF.md', 'DESIGN.md', 'results/native-authority-demand.json',
            'results/taxon-dispositions.json', 'results/all269-node-and-context-dispositions.json',
            'results/reference-original-bindings.json', 'design/prospective-record.yaml']:
    manifest_copy(GRAPH, rel, 'inputs/graph/' + rel)
for rel in ['artifact-manifest.json', 'freeze-proof.json']:
    copy(ISSUER / rel, 'inputs/issuer-proof/' + rel)
for rel in ['results/taxonomy-complete-selected-statements.json',
            'results/taxonomy-selected-lineages.json', 'results/taxonomy-query-receipt.json']:
    manifest_copy(ISSUER, rel, 'inputs/taxonomy/' + Path(rel).name)

sys.path.insert(0, str(WT / 'src'))
from pathwaymech.biocyc_carrier import name

demand = [r for r in json.loads((GRAPH / 'results/native-authority-demand.json').read_text())
          if r['id'].startswith('MetaCyc:')]
refs = {r['id']: r for r in json.loads((GRAPH / 'results/reference-original-bindings.json').read_text())}
sources_raw = (WT / 'data/identifier_authorities/sources.json').read_bytes()
ontology_raw = (WT / 'data/identifier_authorities/ontology.json').read_bytes()
sources = json.loads(sources_raw)
ontology = json.loads(ontology_raw)
conf_raw = (WT / 'conf/identifier_sources.json').read_bytes()
conf = json.loads(conf_raw)
assert sources_raw == subprocess.check_output(['git', 'show', BASE + ':data/identifier_authorities/sources.json'], cwd=WT)
assert ontology_raw == subprocess.check_output(['git', 'show', BASE + ':data/identifier_authorities/ontology.json'], cwd=WT)
assert conf_raw == subprocess.check_output(['git', 'show', BASE + ':conf/identifier_sources.json'], cwd=WT)
dump('results/baseline-snapshot-owner-inventory.json', {
    'scope': 'Fresh complete JSON owner/order inventory; no historical source-cache rebuild.',
    'sources_snapshot': {'path': str(WT / 'data/identifier_authorities/sources.json'), 'sha256': sha(sources_raw),
                         'bytes': len(sources_raw)},
    'ontology_snapshot': {'path': str(WT / 'data/identifier_authorities/ontology.json'), 'sha256': sha(ontology_raw),
                          'bytes': len(ontology_raw)},
    'conf_manifest': {'path': str(WT / 'conf/identifier_sources.json'), 'sha256': sha(conf_raw),
                     'bytes': len(conf_raw), 'entries': len(conf)},
    'owners': {kind: {section: [
        {'ordinal': i, 'key': k, 'canonical_object_sha256': sha(json.dumps(v, sort_keys=True, ensure_ascii=False).encode())}
        for i, (k, v) in enumerate(data[section].items())] for section in ('sources', 'terms')}
        for kind, data in [('sources', sources), ('ontology', ontology)]},
})
existing = [r for r in demand if r['id'] in sources['terms']]
new = [r for r in demand if r['id'] not in sources['terms']]
assert len(existing) == 17 and len(new) == 52 and all(r['existing'] for r in existing)
dump('results/preserved-17-native-owners.json', {
    'terms': {r['id']: sources['terms'][r['id']] for r in existing},
    'sources': {sources['terms'][r['id']]['source']: sources['sources'][sources['terms'][r['id']]['source']]
                for r in existing},
    'instructions': 'Keep exact previous objects, owner keys, values and insertion order; do not re-own these IDs.'})

profiles, manifests, nested_shapes, source_contexts = [], [], Counter(), Counter()
for row in new:
    ident, frame = row['id'], row['id'].split(':', 1)[1]
    ref = refs[ident]
    assert row['sha256'] == ref['sha256']
    raw = copy(GRAPH / ref['body'], 'inputs/originals/META-' + frame + '.xml', ref['sha256'])
    copy(GRAPH / ref['request_receipt'], 'inputs/acquisition/META-' + frame + '.json', ref['receipt_sha256'])
    tree = ET.fromstring(raw)
    entity = tree[1]
    attrs = {'ID': 'META:' + frame, 'orgid': 'META', 'frameid': frame, 'detail': 'full'}
    if row['native_class']:
        attrs['class'] = 'true'
    assert entity.tag == row['native_type'] and entity.attrib == attrs
    assert tree.find('metadata/query').text == 'META:' + frame
    assert tree.find('metadata/PGDB').attrib == {'orgid': 'META', 'version': '27.0'}
    assert tree.find('metadata/num_results').text == '1'
    common = entity.findall('common-name')
    assert len(common) <= 1
    label = name(common[0], '') if common else frame
    assert label == row['label'], (ident, label, row['label'])
    parents = [{'tag': n.tag, 'frame': n.get('frameid'), 'class': n.get('class')}
               for wrapper in entity.findall('parent') for n in wrapper]
    components = []
    for wrapper in entity.findall('component'):
        components.append({'xml': ET.tostring(wrapper, encoding='unicode')})
    for n in entity.iter():
        if n is entity:
            continue
        if n.get('frameid') is not None:
            nested_shapes[(n.tag, tuple(sorted(n.attrib)), n.get('class'), n.get('detail'))] += 1
            source_contexts[n.get('frameid')] += 1
    profiles.append({
        'id': ident, 'tag': entity.tag, 'is_class': row['native_class'],
        'slots': dict(sorted(Counter(n.tag for n in entity).items())),
        'parents': parents, 'component_occurrences': components,
        'label_audit_only_not_profile_allowlist': label,
        'label_origin': 'direct_common_name' if common else 'native_frame_id',
        'direct_synonyms': sorted({name(n, '') for n in entity.findall('synonym')} - {label}),
        'expected_section': row['section'], 'expected_category': row['category'],
        'body': 'inputs/originals/META-' + frame + '.xml', 'sha256': sha(raw),
        'source_path': str(GRAPH / ref['body']), 'source_receipt_path': str(GRAPH / ref['request_receipt']),
        'source_receipt_sha256': ref['receipt_sha256'], 'request_url': ref['request_url'],
        'xml_base': tree.get('{http://www.w3.org/XML/1998/namespace}base'),
        'ptools_version': tree.get('ptools-version'), 'version': '27.0',
        'reuse_scope': ref['provenance']['mode'],
    })
    manifests.append({'key': 'acetate271-META-' + frame, 'kind': KIND,
        'path': 'acetate271/META-' + frame + '.xml', 'url': ref['request_url'], 'version': '27.0',
        'license': 'BioCyc license; redistribution review deferred until public release', 'sha256': sha(raw)})
assert not ({r['key'] for r in manifests} & {r['key'] for r in conf})
dump('results/proposed-source-manifest.json', manifests)
dump('results/all-52-native-profile-inventory.json', profiles)
dump('results/embedded-object-shape-inventory.json', [
    {'tag': k[0], 'attribute_keys': list(k[1]), 'class': k[2], 'detail': k[3], 'occurrences': v}
    for k, v in sorted(nested_shapes.items(), key=lambda p: repr(p[0]))])
dump('results/embedded-context-frequency.json', dict(sorted(source_contexts.items())))

taxa = json.loads((GRAPH / 'results/taxon-dispositions.json').read_text())
rows = json.loads((OUT / 'inputs/taxonomy/taxonomy-complete-selected-statements.json').read_text())
selected = [r['public_id'] for r in taxa if r['declared']]
assert len(selected) == 6 and set(selected) & ontology['terms'].keys() == {'NCBITaxon:2208'}
tax_source = ontology['terms']['NCBITaxon:2208']['source']
spec = importlib.util.spec_from_file_location('bounded_ontology_plan_probe', OUT / 'inputs/baseline/scripts/build_ontology_identifier_snapshot.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
connection = sqlite3.connect(':memory:')
connection.execute('CREATE TABLE statements (subject TEXT, predicate TEXT, value TEXT)')
for ident in selected:
    for row in rows[ident]:
        connection.execute('INSERT INTO statements VALUES (?,?,?)', (row['subject'], row['predicate'], row['value']))
projected, missing = module.extract_terms(connection, sorted(selected), tax_source)
connection.close()
assert not missing and projected['NCBITaxon:2208'] == ontology['terms']['NCBITaxon:2208']
for row in taxa:
    if not row['declared']:
        continue
    ident = row['public_id']
    assert projected[ident]['label'] == row['issuing_label']
    assert [s['object'] for s in rows[ident] if s['predicate'] == 'obo:ncbitaxon#has_rank'] == [row['issuing_rank']]
query_receipt = json.loads((OUT / 'inputs/taxonomy/taxonomy-query-receipt.json').read_text())
cache = Path(query_receipt['cache'])
st = cache.stat()
assert st.st_size == query_receipt['size'] and st.st_mtime_ns == query_receipt['mtime_ns_after']
assert ontology['sources'][tax_source]['sha256'] == query_receipt['whole_cache_hash_reused']['sha256']
dump('results/five-additive-taxonomy-term-proposals.json', {k: v for k, v in projected.items() if k not in ontology['terms']})
dump('results/taxonomy-probe.json', {
    'scope': 'Unchanged extract_terms on accepted selected issuing rows in memory; no database rehash or fresh network.',
    'source_key_preserved': tax_source, 'source_metadata_preserved': ontology['sources'][tax_source],
    'existing_term_preserved': {'NCBITaxon:2208': projected['NCBITaxon:2208']},
    'cache_size': st.st_size, 'cache_mtime_ns': st.st_mtime_ns,
    'matches_accepted_receipt_size_mtime': True,
    'new_ids': sorted(k for k in projected if k not in ontology['terms']),
    'selected_ranks': {r['public_id']: r['issuing_rank'] for r in taxa if r['declared']},
    'not_selected': ['MetaCyc:ORG-5913', 'MetaCyc:TAX-28890', 'NCBITaxon:28890'],
})

conflicts = json.loads((GRAPH / 'results/all269-node-and-context-dispositions.json').read_text())
dump('results/scope-counts.json', {
    'native_graph_demand': len(demand), 'existing_native': len(existing), 'new_native': len(new),
    'new_type_class_counts': dict(Counter(r['tag'] + (' class' if r['is_class'] else ' instance') for r in profiles)),
    'new_category_counts': dict(Counter(r['expected_category'] for r in profiles)),
    'frame_only': [r['id'] for r in profiles if r['label_origin'] == 'native_frame_id'],
    'charged_requests': [r['id'] for r in profiles if '+' in r['id']],
    'direct_taxa': 6, 'new_taxa': 5, 'existing_taxa': ['NCBITaxon:2208'],
    'scope': 'Coverage and planned source kinds only; no adapter, snapshot, graph acceptance or final record gate.',
})
dump('results/baseline-owner-bindings.json', {'head': head, 'tree': TREE, 'files': base_rows})
dump('results/input-bindings.json', bindings)
print(json.dumps({'copied_inputs': len(bindings), 'native': len(demand), 'new_native': len(new),
                  'new_taxa': 5, 'profile_inventory': len(profiles), 'status': 'planning probes passed'}))
