# Independent graph-design review: acetate methanogenesis

**Qualified acceptance for this frozen graph design; zero actionable findings.** The 89-edge proposal faithfully projects the selected native assertions and preserves the accepted scientific/issuer limits on the relevant incident claims. It is suitable to guide additive authority implementation and a maintained-record draft. This verdict does not accept a future authority adapter, exact public aliases, the final maintained record, browser interaction or pixel rendering, or release/publication gates.

Reviewer `/root/next271_independent_preflight` did not author the source/issuer preparations, this graph design, maintained record or authority implementation. Earlier reviewer work supplied independent discovery/baseline checks and the activity-endpoint defect assessment. That defect's scratch candidate is **not** treated here as independent approval of its own implementation. A different reviewer and root accepted the exact maintained issue #630 implementation, as recorded in `inputs/accepted-root/root-intake-next271-activity-endpoint-implementation-review.json`. The present review exercises the accepted schema against the graph without redoing the implementation review.

## Frozen inputs and actual contracts

Author owner `/private/tmp/pathwaymech-next-271-graph-design` is bound to manifest `c680126985a8447ac0ef5d9f3f6ea14512c55cb74e1a1cc3ca948c0dcf8e1882`, HANDOFF `505382b3d8fb837de6e644266fd0ea5fc3ac194ff9accb2173c9727f68634dc8`, and freeze `20d9e5413f12e6ce147897fa2534cec8bca8edf1f8f943893a21d59635ccc530`. Its complete 1,698-file physical inventory (1,696 listed; 160,050,176 listed bytes) was independently walked without ignore filtering, hashed, copied and rechecked. Hidden/ignored files are included. Historical nested archive containers remain opaque; this is no archive-content or source-exhaustion claim.

The prospective YAML hash is `a8d7b717bca51f75ca9340dfc33507bb236d26614616587375494140eafd1775`. All 133 copied baseline files independently match the Git blobs at actual merged HEAD `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e`. This is the 267-record baseline, not the earlier unmerged candidate. The endpoint successor is separately bound: schema `b3f0c28ded2e0e665c15cf0a0e4a8e19ffc1d9bdfd397aa8383ad6a13baf4214`, docs `9d0eab4e76b22c194614cb7d309f2726e16331e5a7552c660bd5075e7497d8b2`, tests `6b8225b6d2bb266ba18d29e6e28c5cd48dcc0c40a6e0794098ab1b0cf77b1a71`. These match the actual working files and author copies at intake; they are not misrepresented as already in the baseline Git tree.

The accepted source manifest is `06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5`; the copied 32-claim ledger is freshly rebound to that manifest and original (`808fad64b13434072e4cae86b49ef8679eff116e569f41a03cf0baed664cd765`). Every original claim field remains unchanged in the graph disposition ledger. Source independent review and issuer independent review are reused at their root-accepted scopes; the latter manifest is `7b29470655c06c86c98f4d20cdb93d153a5bf32f7639f54c1d86727b5dbe47bb`. This review checks their application to the graph, not a new literature or chemistry investigation.

## Independent reconstruction of the graph

The reviewer parsed all 269 full native originals, selected the same seven previously independently prepared activity contexts, and reconstructed the graph from own source slots rather than running author generation/check code. The resulting multiset of directed edges and complete native-node closure exactly matches the proposal:

| Assertion family | Edges | Independent result |
|---|---:|---|
| Root members / predecessor links | 6 / 5 | Exact six members and branching order |
| Canonical material occurrences | 29 | 19 IDs; 14 consumes and 15 produces |
| Enzyme→activity / enzyme→reaction | 7 / 7 | Exact native association scopes |
| Complex components | 8 | Literal selected coefficients retained |
| Direct / alternative cofactors | 7 / 4 | Correct enzyme endpoints and replacements |
| Alternative substrates | 6 | Exact ENZRXN-481 inputs, separate equation |
| Physical membrane locations | 3 | One native membrane identity |
| Negative regulations | 7 | Exact chemicals and native activity targets |

All six own reaction directions are REVERSIBLE. Four root-selected L2R and two R2L orientations independently determine the material-edge directions. Every occurrence preserves its coefficient, explicit versus implicit-one distinction and absence of a compartment. The route ends at methyl-CoM; methane production, sodium coupling, borrowed membrane sides, another pathway's carrier equation and a seventh Acs reaction are not added.

Whole CPLX-461 has only the supported assembly context. Its explicit `enzymes-not-used` exclusion from RXN-12908 is visible on incident claims; it is not assigned that isolated methyltransferase activity. The alpha2/epsilon2, delta1/gamma1, whole-complex 4/8/8, and Ack monomer2 coefficients agree with native component slots. `enables` preserves the two distinct source association layers without claiming a new isolated-component catalysis experiment or equating an activity with a generic reaction.

The six alternative substrates are TTP, ITP, UTP, GTP and CTP replacing ATP, plus propionate replacing acetate. Each has exact subject ENZRXN-481 and a source locator; each description says alternative, not simultaneous, and retains the source evidence level. Canonical ATP + acetate ⇄ ADP + acetyl phosphate remains unchanged. Three membrane assertions target physical proteins/complexes; none assigns the 29 equation materials a compartment. Seven inhibitors target the exact three native activities, with absent physiological relevance preserved.

## Identities, qualifications and exclusions

The independently derived node closure is 69 native identities: root, six reactions, 41 materials, 13 nonclass proteins/complexes, seven enzyme-specific activities and one membrane class. Six NCBI taxa are additional record declarations. Exact native activities remain `participants/molecular_activity`; issued reactions remain `reactions/molecular_activity`. Generic corrinoid and ferredoxin Protein classes remain protein material states, not precise species-specific proteins or narrower reactive parts. Source-class identity does not imply a molecular structure or a particular cofactor site.

Current authority coverage independently agrees with the demand ledger: 17 existing native terms and NCBITaxon:2208 are preserved, leaving **52 native and five direct NCBI additions**. Existing canonical labels are unchanged. New labels come from normalized own common names; the six reactions, CPLX-322, CPLX-481 and PTAMSARC-MONOMER correctly use proposed literal frame-token fallbacks. These are bounded authority demands, not permission for a global name fallback or weakening existing profiles. No native/public exact alias is promoted.

The six taxon declarations have exact pinned issuing labels and ranks: two genera, four species. ORG-5913 is a seventh native association, with species rank and no own public pointer; membership context retains that fact without inventing an NCBI identity. TAX-28890 stays range context. The selected taxonomy rows are retained and hash-bound; reference hashes identify the separately verified full pinned SQLite cache. This review did not rehash the 14 GB database or claim fresh individual HTTP responses.

All 269 node/context dispositions, 1,530 own-slot inventory entries, 45 member-activity occurrences, 18 full-context component occurrences and 27 regulation objects are accounted for. The selected seven activities exclude 38 other-organism occurrences. Reference-only genes, regulation frames and native organisms are not forced into graph nodes merely to reach a research-object count. The seven actual gene/product relationships are retained on incident protein evidence and in their inverse ledger; no unsupported `encodes`, gene `has_part`, or gene `enables` edge is fabricated.

Material scientific qualifications are retained where their claims are exported:

- Presumed/unidentified thermophila Mtr is qualified on both association edges and its location; incompletely characterized barkeri Mtr remains distinct. Neither acquires invented subunits, sequence or transport proof.
- CPD-8/CPD-9 retain sarcinapterin identity, charge and incomplete-short-SMILES warning. Generic CPD-7/Corrinoids, native carrier classes and narrower public structures are not collapsed into aliases.
- Ack's native EC-2.7.2.15 and Mtr's partial EC remain literal source facts. Rhea 17829's obsolete/replacement comment does not become exact native equivalence; a KEGG access failure does not become historical absence.
- Whole-complex metal/CO/KCN experiments do not establish isolated alpha/epsilon metal sites or neutral-HCN physiology. Native regulation and cofactor assertions retain those limits.
- CdhD/CdhE source cofactor disagreement remains explicit. Heterologous BL21(DE3) inclusion-body/reconstitution results are contextual evidence, not new native cofactor edges or a definitive factor-III assignment. The current graph therefore does not need to present a modified assay construct as the endpoint of a new native binding claim.
- Beta mechanism prose with unread primary main, historical alpha cluster assignments, artificial methyl-iodide synthesis, isotope spectroscopy, partial proteolysis, abstract-only reports, and inaccessible Gong SI keep their separate evidence scopes. The later issuing sequence comparison is distinguished from earlier source-reading limits.
- Condition-specific Methanothrix Acs observations qualify the native Ack/Pta membership and taxa; they do not replace the source route or assert universal gene absence.

The 32 source/primary dispositions retain their original statements, evidence and access limits. All 12 primary contexts appear with the accepted reading level on their designated incident edges. Broader family lists in the native-claim ledger are coverage groupings, not a claim that each listed edge directly proves every family statement; exact evidence occurrences and native locators provide the finer mapping.

## Validation, export and limitations

**9,751 fresh independent assertions passed**: 8,792 graph/original/shape/projection checks plus 959 accepted-claim/baseline/exclusion-provenance checks. The earlier 97 preparation checks, 208 endpoint-contract checks, author's 4,509 checks, root's 96 endpoint tests and the separate implementation review are not included in that number.

The complete fixture passes actual accepted successor Python validation and closed LinkML. All 368 native evidence-locator occurrences (184 distinct reference/locator pairs) resolve exactly once. All 118 reference identities have their retained original-body/hash binding or explicit external taxonomy-cache binding; acquisition receipt hashes are checked where supplied. Topology, coefficients and source orientation were reconstructed directly rather than inferred from passing schema validation.

Fresh actual KGX output has all 75 declared nodes and 89 edges, preserving directed endpoints, explicit categories, descriptions, complete evidence, endpoint qualifiers and reference metadata. All 69 native nodes appear once in the static SVG; the six unconnected taxon declarations remain record/KGX context rather than fictitious graph links. All complete edge descriptions appear in the generated page. The reviewer inspected the actual records, distinct description segments and evidence mapping; the page was structurally parsed, not assessed in an interactive browser or as pixels. Root also reported browser-provider unavailability. No browser-interaction or visual-layout certification is claimed.

These graph assertions use descriptions/evidence to preserve conditional alternatives, coefficients and scientific limits because the current graph contract has no separate structured slots for all of them. A consumer discarding that context and retaining only bare triples loses material meaning. This known representation limit is explicitly retained; the design does not invent unsupported fields to conceal it.

Three unsuccessful reviewer harness assumptions are retained: complex typing from component lists alone, failure to normalize native double whitespace, and defaulting a context coefficient while comparing its literal absence. Actual originals justified the corrections; they are not graph defects. Earlier preparation's plural-slot error is also retained. Details and terminal process receipts are in `OPERATIONS.md` and `operations/`. No failed author/graph result is suppressed.

No maintained/Git/GitHub/runtime writes, network access, helper agents, installations, new scientific-source searches or full-corpus suite were used. All owned processes are terminal. There is no new whole-repository absence, global novelty or source-exhaustion assertion. Final authority implementation, maintained curation, visual/browser QA, canonical scientific record review and project/publication gates remain separate.
