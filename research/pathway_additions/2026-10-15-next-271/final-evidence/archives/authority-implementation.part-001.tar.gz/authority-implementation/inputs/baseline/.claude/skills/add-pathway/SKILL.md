---
name: add-pathway
description: Add one microbial pathway mechanism as a PathwayMech YAML record with exact identifier checks, local participant and reaction nodes, edge-level evidence, refreshed pages, and local validation. Use for a named pathway or paper lead; use source-triage for reusable database adoption.
allowed-tools: Bash, Read, Grep, Glob, WebSearch, WebFetch, Edit, Write
metadata:
  category: curation
  requires_database: false
  requires_internet: true
  version: 1.1.0
---

# Add a PathwayMech Record

Turn one named microbial pathway, or one bounded literature lead, into a
validated YAML record under `data/pathways/`.

Search hits, pathway-database pages, and Deep Research reports are leads. Only
inspected primary sources, reviewed pathway definitions, or authoritative
database records should support a committed identifier, participant, reaction,
or mechanistic edge.

## Boundaries

- Add one pathway per task. If a request names a pathway family, split it into
  exact records whose identifiers and edges can be reviewed independently.
- Accept pathways with explicit biochemical, regulatory, biosynthetic, or
  physiological steps in microbes.
- Reject broad umbrella processes, unrelated pathway-map collages, pure
  phenotypes, single reactions, single enzymes, and taxon-level pathway
  predictions that lack mechanistic evidence.
- Do not mark an optional field as absent because the source omits it. This
  schema is intentionally small; leave unsupported nodes and edges out.
- Do not invent a local CURIE. `src/pathwaymech/schema.py` currently accepts
  `GO`, `gomodel`, `WikiPathways`, `MetaCyc`, `EcoCyc`, `KEGG`, `RHEA`, `RHEA-COMP`, `MIBiG`,
  `ModelSEED`, `BiGG`, `BV-BRC`, `Reactome`, `PathBank`, `PMN`, `CHEBI`, `CAS`,
  `ChemSpider`, `HMDB`, `LIPIDMAPS`, `PubChem`, `EC`, `ECO`, `Ensembl`,
  `Entrez`, `NCBIProtein`, `SGD`, `TubercuList`, `UniProtKB`, `NCBITaxon`,
  `GTDB`, `GO_REF`, `PMID`, and `DOI`.

## Read First

- `CLAUDE.md` for the record contract.
- `docs/CURATION.md` for the curation surface and provenance rule.
- `docs/HARMONIZATION.md` for the identifier sources this corpus harmonizes.
- `docs/CAUSAL_GRAPHS.md` for biological component roles, source directions,
  cofactor conditions, and structured evidence.
- `templates/pathway_mechanism_research.md` for research reports that can seed
  the first draft.
- `conf/sources.yaml` for sources already considered for ingestion.
- `src/pathwaymech/schema.py` for the required fields, CURIE prefixes,
  predicate enum, and evidence quote length limit.
- The closest records in `data/pathways/`, when any exist. Copy their local
  shape, not their claims.

## Prove the Pathway Is Missing

Before writing a record, search exact identifiers and labels across the whole
repository, including ignored and hidden files:

```bash
rg --no-ignore --hidden -n -F "<GO-or-WikiPathways-or-MetaCyc-or-KEGG-id>" . -g '!/.git' -g '!/.venv'
rg --no-ignore --hidden -n -F "<exact pathway label>" . -g '!/.git' -g '!/.venv'
rg --no-ignore --hidden -n -F "<RHEA-or-MIBiG-or-PMID-or-DOI>" . -g '!/.git' -g '!/.venv'
```

Search the candidate GO, GO-CAM, WikiPathways, MetaCyc, KEGG, Rhea, MIBiG,
Reactome, PathBank, PMN, ModelSEED, BiGG, BV-BRC, and VEuPathDB identifiers;
exact pathway labels and synonyms; defining reaction IDs; source accessions;
and DOI or PMID evidence. Never use a bare prefix such as `GO:` or `PMID:` to
prove absence.

If a prior mention exists in `research/`, read it before continuing. A rejected
candidate, source gap, or unresolved identifier conflict changes the work from
record addition to follow-up research.

## Identity and Nodes

Choose the record `id` from the narrowest exact external pathway identifier:

- use `GO` when the biological-process term exactly denotes the pathway;
- use `MetaCyc` or `KEGG` when the database entry is the curated pathway being
  represented;
- do not collapse alternative routes, species-specific variants, or adjacent
  modules merely because they share a display name.

Declare every node used by an edge in one of the local node lists:

- `taxa`: microbial scope with `NCBITaxon` or `GTDB` identifiers;
- `participants`: small molecules, lipids, cofactors, enzymes, proteins,
  complexes, DNA, RNA, or cellular components as supported by the mechanism, with
  `CHEBI`, `LIPIDMAPS`, `EC`, `UniProtKB`, or native pathway-diagram xref
  identifiers such as `CAS`, `ChemSpider`, `HMDB`, `PubChem`, `Ensembl`,
  `Entrez`, `NCBIProtein`, or `TubercuList`;
- `reactions`: reaction nodes with `RHEA`, `gomodel`, `WikiPathways`,
  `MetaCyc`, `KEGG`, `Reactome`, `PathBank`, or `PMN` identifiers.

Resolve every CURIE at its issuing authority before committing it. Leave a node
out when the identifier is still a guess; a shorter true graph is better than a
full pathway map with invented accessions.

## Mechanistic Edges

Every edge must:

- use an `id` unique within the record;
- use one of the predicates in `ALLOWED_EDGE_PREDICATES`;
- set `subject` and `object` to the record id or a locally declared taxon,
  participant, or reaction id;
- cite at least one local `references` entry by `reference_id`;
- use either a verbatim `quote` or a faithful `source_assertion`, at most 400
  characters; a structured assertion also requires its exact `source_locator`.

Attach evidence to the narrowest edge it supports. An inspected structured
database statement may support its explicit mechanism assertion; preserve its
evidence codes and inference limits. A database's citation of a paper does not
make generated database prose a quotation from that paper. Preserve conflicting
directions, cofactor conditions, and biological scope in the record and review
ledger instead of silently choosing a convenient source.

When an issued reaction combines transformations that primary evidence resolves
into smaller steps, use the optional `reaction_mechanisms` contract in
`docs/CAUSAL_GRAPHS.md`. Its local keys identify evidence-bearing claims within
one record; they are not CURIEs, authority terms, or top-level reaction nodes.
Keep the issued reaction and source assertions intact. A decomposition must
reconcile exact material identities and integer coefficients to the selected
source equation. An alternative interpretation must explicitly account for each
identity difference with evidence; equation reconciliation alone does not prove
chemical identity or physiological flux. Keep unobserved intermediates in
proposed hypotheses rather than inventing chemical identifiers.

Use `detail_only_participant_ids` only for participants that belong solely to the
nested interpretation. Check the complete source membership independently;
an isolated source component must remain in the source graph. Verify that pages
show both representations and all nested evidence, and that KGX preserves the
complete detail in the parent reaction's record-specific context. Do not flatten
local steps into public biological nodes or transfer their catalysts onto a
source net reaction.

## Write and Verify

Create one YAML file under `data/pathways/`, named with a stable lower-case
ASCII slug for the pathway. Then run:

```bash
just render-pages
just validate
just test
just lint
git diff --check
```

`pages/` is generated from `data/pathways/`. Render it before validating:
`just validate` includes `just check-pages`, which fails while `pages/` is not
what the records render to. Commit the rendered pages with the record, and do
not edit generated pathway pages by hand.

`just validate` also runs `just validate-strict`: the record must fit the
closed LinkML schema in `src/pathwaymech/schema/pathwaymech.yaml`, so a key it
does not declare is an error, and an optional key is omitted rather than set
to null. The allowed CURIE prefixes and edge predicates live in both that
schema and `src/pathwaymech/schema.py`; a new one goes into both, in the same
pull request.

## Report

End with the new record id, label, and YAML path; every GO, GO-CAM,
WikiPathways, MetaCyc, EcoCyc, KEGG, Rhea, MIBiG, Reactome, PathBank, PMN, ModelSEED,
BiGG, BV-BRC, ChEBI, LIPIDMAPS, CAS, ChemSpider, HMDB, PubChem, EC, Ensembl, Entrez,
NCBIProtein, SGD, TubercuList, UniProtKB, NCBITaxon, GTDB, PMID, and DOI
identifier added;
the strongest identity and mechanism sources; any edges deliberately left out;
whether duplicate searches included ignored and hidden files; and every
validation command that passed or was unavailable.
