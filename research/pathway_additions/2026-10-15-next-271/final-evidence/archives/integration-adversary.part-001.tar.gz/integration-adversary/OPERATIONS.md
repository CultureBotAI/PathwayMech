# Operations and reproduction

The review used the existing next271 worktree at base
63ebb3b3e29ca1ed6472597104347d9fbc98f4a5. All writes are under this reviewer-owned
scratch directory. No helper agents were spawned. Every own process is terminal.

`integration_probe.initial.py.txt`, `RESULT.initial.json`, `checks.initial.json`
and `probe-initial.*` preserve the initial attempt. Its exec session 81489
terminated with exit 0; findings are in the JSON rather than the process code.
The corrected `integration_probe.py` used the root's packaging successor
binding. Session 96963 terminated with exit 0; `RESULT.json` has zero failures.
The final invocation was:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONPATH=src:. \
PATHWAY_REVIEW_BINDINGS=/private/tmp/pathwaymech-next-271-ci/candidate-packaging-successor-bindings.json \
/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B /private/tmp/pathwaymech-next-271-integration-adversary/integration_probe.py
```

The probe supports `PATHWAY_REVIEW_ROOT` and `PATHWAY_REVIEW_BINDINGS` for a
separately reconstructed equivalent pre-PR worktree. It requires the exact Git
base and uncommitted candidate files. It writes results beside the script;
copy it to a new scratch owner before replaying a frozen review. The original
candidate archives and source originals remain required in that worktree;
selected copies here are not a claim to contain the whole candidate.

Four portable checks ran in parallel against the actual formatted maintained
helpers. Sessions 9115, 60508 and 38358 all terminated with exit 0; the fourth
command completed immediately with exit 0. Commands and logs are recorded in
`portable-replay-independent-result.json`. They used only the standard-library
Python3 runtime recorded in `portable-runtime.json`, with assertions enabled.
They did not require original scratch packet owners or modify the archives.

Small independent checks verified the authority-author copies and record
reference joins, helper AST equivalence and Git attribute scope, accepted-design
SVG/record projection, structured-evidence markup, and the actual production
semantic/KGX consumers. Their results are separate JSON files. Root's lint,
staged-diff and rerender receipts are copied with a `root-` prefix and are
explicitly attributed to root; they are not fresh reviewer executions.

No full suite, source rereading, browser/pixel inspection, GitHub mutation,
network retrieval, environment installation or repair occurred. Final physical
inventory uses filesystem traversal including hidden/ignored files, rejecting
symlinks. The artifact manifest and freeze proof self-exclude only themselves.
