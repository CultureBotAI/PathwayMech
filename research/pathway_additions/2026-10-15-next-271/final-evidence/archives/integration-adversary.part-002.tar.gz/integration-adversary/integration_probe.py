"""Read-only independent checks of the actual pre-PR integration boundary."""
from __future__ import annotations
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
from collections import Counter
from datetime import datetime, timezone

import yaml
from lxml import html

ROOT = Path(os.environ.get('PATHWAY_REVIEW_ROOT', '/private/tmp/pathwaymech-next-271-20261015'))
OWNER = Path(__file__).resolve().parent
BASE = '63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'
BINDINGS = Path(os.environ.get('PATHWAY_REVIEW_BINDINGS', '/private/tmp/pathwaymech-next-271-ci/full-gates-input-bindings.json'))
RECORD = 'data/pathways/methanogenesis-from-acetate.yaml'
RID = 'MetaCyc:METH-ACETATE-PWY'
checks = []
def check(name, passed, details=None):
    checks.append({'name': name, 'pass': bool(passed), **({'details': details} if details is not None else {})})
def sha(body):
    return hashlib.sha256(body).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)
def old(path):
    return git('show', BASE + ':' + path)
def js(path):
    return json.loads((ROOT/path).read_bytes())
def tsv(body):
    return list(csv.DictReader(io.StringIO(body.decode()), delimiter='\t'))
def norm(s):
    return ' '.join(s.split())

inputs = json.loads(BINDINGS.read_bytes())
(OWNER/'candidate-input-bindings.json').write_bytes(BINDINGS.read_bytes())
check('base head', git('rev-parse', 'HEAD').decode().strip() == BASE)
check('base tree', git('rev-parse', BASE+'^{tree}').decode().strip() == '5448122efcfbd8ae2ac90ad42e70557b03d9b78e')
check('branch', git('branch', '--show-current').decode().strip() == 'feat/pathway-next-271-20261015')
for item in inputs['files']:
    p = ROOT/item['path']
    b = p.read_bytes()
    check('candidate bytes '+item['path'], not p.is_symlink() and len(b)==item['bytes'] and sha(b)==item['sha256'])
bound = {x['path'] for x in inputs['files']}
changed = set(git('diff', 'HEAD', '--name-only', '-z').decode().strip('\0').split('\0'))-{''}
untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().strip('\0').split('\0'))-{''}
check('all candidate diff files bound', changed|untracked == bound, {'extra': sorted((changed|untracked)-bound), 'missing': sorted(bound-(changed|untracked))})
(OWNER/'changed-paths.json').write_text(json.dumps(sorted(changed|untracked), indent=2)+'\n')
(OWNER/'code-review.diff').write_bytes(git('diff', BASE, '--', 'src/pathwaymech/schema.py','src/pathwaymech/identifiers.py','scripts/build_source_identifier_snapshot.py','docs/CAUSAL_GRAPHS.md','docs/IDENTIFIERS.md','tests/test_graph_context.py'))

# Full current physical YAML inventory is independent of Git ignores.
physical = sorted(p.relative_to(ROOT).as_posix() for p in (ROOT/'data/pathways').rglob('*') if p.is_file() and p.suffix in {'.yaml','.yml'})
old_paths = [p for p in git('ls-tree','-r','--name-only',BASE,'data/pathways').decode().splitlines() if p.endswith(('.yaml','.yml'))]
check('exact one added record, including hidden/ignored physical files', set(physical) == set(old_paths)|{RECORD})
for p in old_paths:
    check('previous record bytes '+p, (ROOT/p).read_bytes()==old(p))
old_pages = git('ls-tree','-r','--name-only',BASE,'pages/records').decode().splitlines()
for p in old_pages:
    check('previous record page bytes '+p, (ROOT/p).read_bytes()==old(p))
governed = ['scripts/.vendored_canon_ref']
import re
claude = (ROOT/'CLAUDE.md').read_text()
governed += re.findall(r'`([^`]+)`', claude.split('These 18 files',1)[1].split('Never edit one here',1)[0])
governed = [p for p in governed if (ROOT/p).is_file()]
for p in governed:
    check('governed bytes '+p, (ROOT/p).read_bytes()==old(p))

record = yaml.safe_load((ROOT/RECORD).read_bytes())
native = {record['id']: {'id':record['id'],'label':record['label']}}
for section in ('participants','reactions'):
    native.update({n['id']: n for n in record[section]})
nodes = {**native, **{n['id']:n for n in record['taxa']}}
check('new record counts', (len(native),len(nodes),len(record['mechanistic_edges']),len(record['references']))==(69,75,89,118))
check('reaction versus activity identities disjoint', not ({n['id'] for n in record['participants']} & {n['id'] for n in record['reactions']}))
edges = record['mechanistic_edges']
check('six activity alternative inputs', len([e for e in edges if e['predicate']=='has_input']) == 6 and all(e['subject']=='MetaCyc:ENZRXN-481' for e in edges if e['predicate']=='has_input'))
check('only canonical equation material edges', Counter(e['predicate'] for e in edges)['consumes']+Counter(e['predicate'] for e in edges)['produces']==29)
check('native all reversible', len(record['reactions'])==6 and all(n['direction']=='reversible' for n in record['reactions']))
check('no invented biological nodes from references', set(nodes)=={record['id']}|{n['id'] for s in ('participants','reactions','taxa') for n in record[s]})

source_old=json.loads(old('data/identifier_authorities/sources.json'))
source_new=js('data/identifier_authorities/sources.json')
onto_old=json.loads(old('data/identifier_authorities/ontology.json'))
onto_new=js('data/identifier_authorities/ontology.json')
for label,a,b,delta in [('source owners',source_old['sources'],source_new['sources'],52),('source terms',source_old['terms'],source_new['terms'],52),('ontology owners',onto_old['sources'],onto_new['sources'],0),('ontology terms',onto_old['terms'],onto_new['terms'],5)]:
    check(label+' finite additive size', len(b)-len(a)==delta)
    check(label+' old order', list(b)[:len(a)]==list(a))
    for key in a:
        check(label+' prior object '+key, b.get(key)==a[key])
new_native=set(source_new['terms'])-set(source_old['terms'])
new_taxa=set(onto_new['terms'])-set(onto_old['terms'])
check('new authority terms exactly graph demand', new_native==set(native)-set(source_old['terms']))
check('new taxonomy exactly graph demand', new_taxa==set(nodes)-set(native)-set(onto_old['terms']))
check('old manifest prefix preserved', js('conf/identifier_sources.json')[:-52]==json.loads(old('conf/identifier_sources.json')))

old_edges=tsv(old('pages/downloads/edges.tsv'))
new_edges=tsv((ROOT/'pages/downloads/edges.tsv').read_bytes())
old_edge_map={r['id']:r for r in old_edges}
new_edge_map={r['id']:r for r in new_edges}
check('KGX edge IDs unique', len(new_edges)==len(new_edge_map))
for key,row in old_edge_map.items():
    check('old KGX edge exact '+key, new_edge_map.get(key)==row)
added=[r for r in new_edges if r['id'] not in old_edge_map]
check('89 added exported edges',len(added)==89)
check('new KGX order retained',[(e['subject'],e['object']) for e in added]==[(e['subject'],e['object']) for e in edges])
predicates={'has_input':'RO:0002233','has_output':'RO:0002234','part_of':'BFO:0000050','has_part':'BFO:0000051','located_in':'RO:0001025','occurs_in':'BFO:0000066','precedes':'pathwaymech:precedes','consumes':'pathwaymech:consumes','produces':'pathwaymech:produces','enables':'pathwaymech:enables','catalyzes':'pathwaymech:catalyzes','has_cofactor':'pathwaymech:has_cofactor','inhibits':'pathwaymech:inhibits'}
refs={r['id']:r for r in record['references']}
for e,row in zip(edges,added):
    cited=sorted({x['reference_id'] for x in e['evidence']} | {x['reference_id'] for q in e.get('endpoint_qualifiers',[]) for x in q['evidence']})
    check('new KGX edge semantic fields '+e['id'], row['subject']==e['subject'] and row['object']==e['object'] and row['predicate']==predicates[e['predicate']] and row['description']==e.get('description','') and json.loads(row['evidence'])==e['evidence'] and json.loads(row['reference_metadata'])==[refs[x] for x in cited] and row['source_records']=='|'.join(cited) and json.loads(row['endpoint_qualifiers'] or '[]')==e.get('endpoint_qualifiers',[]))

old_nodes=tsv(old('pages/downloads/nodes.tsv'))
new_nodes=tsv((ROOT/'pages/downloads/nodes.tsv').read_bytes())
old_node_map={r['id']:r for r in old_nodes}
new_node_map={r['id']:r for r in new_nodes}
check('KGX node IDs unique',len(new_nodes)==len(new_node_map))
check('exact 57 added exported biological identities',set(new_node_map)-set(old_node_map)==new_native|new_taxa)
changes=[]
for key,row in old_node_map.items():
    now=new_node_map[key]
    if key not in nodes:
        check('unrelated KGX node exact '+key,now==row)
    else:
        ctx=json.loads(now['source_contexts'])
        check('shared KGX context preserved '+key,[x for x in ctx if x['record_id']!=RID]==json.loads(row['source_contexts']))
        dif={k:[row[k],now[k]] for k in row if row[k]!=now[k] and k!='source_contexts'}
        if dif: changes.append({'id':key,'non_context_changes':dif})
        expected_category=set(row['category'].split('|'))
        expected_source_category=set(filter(None,row['source_category'].split('|')))
        local=nodes[key].get('category')
        if local:
            expected_source_category.add(local)
            category_map={'small_molecule':'biolink:SmallMolecule','cofactor':'biolink:ChemicalEntity','chemical_entity':'biolink:ChemicalEntity','protein':'biolink:Protein','cellular_component':'biolink:CellularComponent','molecular_activity':'biolink:MolecularActivity','complex':'biolink:MacromolecularComplex'}
            expected_category.add(category_map[local])
        check('shared KGX intended union and no other mutation '+key,
            all(now[k]==row[k] for k in row if k not in {'source_contexts','category','source_category'})
            and now['category']=='|'.join(sorted(expected_category))
            and now['source_category']=='|'.join(sorted(expected_source_category)))
for key,node in nodes.items():
    row=new_node_map[key]
    ctx=[x for x in json.loads(row['source_contexts']) if x['record_id']==RID]
    section='pathway' if key==RID else next(s for s in ('participants','reactions','taxa') if key in {n['id'] for n in record[s]})
    expected={'record_id':RID,'collection':section,**({'label':record['label']} if key==RID else node)}
    check('new KGX node context exact '+key,ctx==[expected])
    if section=='participants' and node.get('category')=='molecular_activity':
        check('new activity retains molecular kind '+key,row['category']=='biolink:MolecularActivity')
(OWNER/'shared-node-delta.json').write_text(json.dumps(changes,indent=2)+'\n')
manifest=js('pages/downloads/manifest.json')
for name in ('nodes.tsv','edges.tsv'):
    raw=(ROOT/'pages/downloads'/name).read_bytes()
    check('download manifest '+name,manifest['files'][name]=={'sha256':sha(raw),'rows':len(tsv(raw))})
check('manifest exact 268-record version',manifest['pathway_records']==268 and manifest['version']=='sha256:'+sha((ROOT/'pages/downloads/nodes.tsv').read_bytes()+(ROOT/'pages/downloads/edges.tsv').read_bytes()))

page=html.fromstring((ROOT/'pages/records/MetaCyc_METH-ACETATE-PWY.html').read_bytes())
ids=page.xpath('//*[@id]/@id')
check('new page DOM IDs unique',len(ids)==len(set(ids)))
for href in page.xpath('//*[@href]/@href'):
    if href.startswith('#'):
        check('new page internal target '+href,href[1:] in ids)
ge=page.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," graph-edge ")]')
gn=page.xpath('//*[@data-node-id and contains(concat(" ",normalize-space(@class)," ")," graph-node ")]')
check('page exact 69 native nodes',len(gn)==69 and {x.get('data-node-id') for x in gn}==set(native))
check('page exact 89 graph edges',len(ge)==89)
for i,(e,el) in enumerate(zip(edges,ge),1):
    check('page graph orientation '+e['id'],(el.get('data-subject'),el.get('data-predicate'),el.get('data-object'))==(e['subject'],e['predicate'],e['object']))
    row=page.xpath('//*[@id=$target]',target=el.get('href')[1:])
    check('page evidence row exists '+e['id'],len(row)==1 and row[0].tag=='tr')
    text=norm(' '.join(row[0].itertext()))
    check('page preserves description '+e['id'],norm(e.get('description','')) in text)
    for j,ev in enumerate(e['evidence']):
        check('page preserves evidence text '+e['id']+'/'+str(j),norm(ev.get('quote',ev.get('source_assertion',''))) in text)
        if 'source_locator' in ev:
            check('page preserves locator '+e['id']+'/'+str(j),norm(ev['source_locator']) in text)
for taxon in record['taxa']:
    check('page retains nongraph taxon '+taxon['id'],taxon['id'] in page.text_content() and taxon['label'] in page.text_content())
for token in ['ORG-5913','presumed','alternative','Methanothrix','CPLX-461','methyl-CoM']:
    check('page retains qualification '+token,token in page.text_content())
old_index=json.loads(old('pages/pathway_index.json'))
new_index=js('pages/pathway_index.json')
check('old pathway index rows exact',[r for r in new_index['records'] if r['id']!=RID]==old_index['records'])
rows=[r for r in new_index['records'] if r['id']==RID]
check('one new pathway index entry',len(rows)==1)
check('index exact taxon and reaction scope', rows[0]['taxa']==record['taxa'] and rows[0]['reactions']==[n['id'] for n in record['reactions']])

for item in inputs['files']:
    p=ROOT/item['path']
    check('final unchanged input '+item['path'],sha(p.read_bytes())==item['sha256'])
result={'utc':datetime.now(timezone.utc).isoformat(),'base':BASE,'candidate_binding_sha256':sha(BINDINGS.read_bytes()),'assertions':len(checks),'failures':[c for c in checks if not c['pass']],'counts':{'candidate_files':len(inputs['files']),'old_records':len(old_paths),'old_record_pages':len(old_pages),'old_edges':len(old_edges),'old_nodes':len(old_nodes),'new_edges':len(added),'new_native_authorities':len(new_native),'new_taxa':len(new_taxa)},'limits':['Pre-PR candidate only; no exact commit or PR acceptance.','No full suite, source science, authority fuzzing, browser interaction, or pixel verification.','Physical pathway inventory includes hidden/ignored files. Archive contents are not re-decoded here.']}
(OWNER/'checks.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n')
(OWNER/'RESULT.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2))
