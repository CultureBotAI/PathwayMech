from pathlib import Path
import hashlib,json,subprocess,os,datetime
R=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-271-20261015');A=Path('/private/tmp/pathwaymech-next-271-authority-implementation');owner='research/pathway_additions/2026-10-15-next-271/authority-source-originals';rel=owner+'/.gitattributes';want='2fdf457c0d6c3ab3dcf16c1d8f6b7e21c27641eac324e902f17dfd9af934881c'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((R/'results/implementation-intake.json').read_text());bindings=x['maintained_owners']['files'];checks=[]
def ck(name,val):
 checks.append({'check':name,'pass':bool(val)})
 if not val:raise AssertionError(name)
ck('exact root successor hash',sha(W/rel)==want)
successor=R/'successor'/rel;successor.parent.mkdir(parents=True,exist_ok=True);successor.write_bytes((W/rel).read_bytes())
lines=[s for s in successor.read_text().splitlines() if s and not s.startswith('#')]
ck('exact narrow two rule values',lines==['/originals/*.xml -text whitespace=-blank-at-eol','acquisition/*.json -text'])
for item in bindings:
 ck('actual maintained binding '+item['path'],sha(W/item['path'])==(want if item['path']==rel else item['sha256']))
originals=[b for b in bindings if b['path'].startswith(owner+'/originals/') and b['path'].endswith('.xml')]
ck('all 52 XML owners remain exact',len(originals)==52)
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');commands=[]
def run(args,label,expect=None):
 p=subprocess.run(args,cwd=W,env=env,capture_output=True);out=R/'results'/('attribute-'+label+'.stdout');err=R/'results'/('attribute-'+label+'.stderr');out.write_bytes(p.stdout);err.write_bytes(p.stderr)
 commands.append({'label':label,'argv':args,'cwd':str(W),'returncode':p.returncode,'stdout':str(out.relative_to(R)),'stderr':str(err.relative_to(R))})
 if expect is not None:ck('command '+label+' return code',p.returncode==expect)
 return p
paths=[b['path'] for b in originals]+[owner+'/acquisition/META-ACET.json',owner+'/other.xml',owner+'/originals/nested/other.xml','src/pathwaymech/biocyc_acetate_methanogenesis.py','data/pathways/methanogenesis-from-acetate.yaml','docs/IDENTIFIERS.md']
p=run(['git','-c','core.attributesFile=/dev/null','check-attr','-z','text','whitespace','diff','--',*paths],'actual-scope',0)
parts=p.stdout.decode().split('\0');assert parts[-1]=='';parts=parts[:-1];attrs={}
for i in range(0,len(parts),3):path,key,value=parts[i:i+3];attrs.setdefault(path,{})[key]=value
for item in originals:
 ck('source EOL exemption scoped '+item['path'],attrs[item['path']]=={'text':'unset','whitespace':'-blank-at-eol','diff':'unspecified'})
for path in paths[52:]:
 ck('outside XML scope has no EOL exemption '+path,attrs[path]['whitespace']=='unspecified' and attrs[path]['diff']=='unspecified')
# Command-local attribute option only; no index/config/repository writes.
probe=R/'attribute-probes';probe.mkdir(exist_ok=True)
(probe/'rule').write_text('* -text whitespace=-blank-at-eol\n');(probe/'upstream.xml').write_text('<source>native bytes</source>  \n');(probe/'outside.py').write_text('x = 1  \n');(probe/'conflict.xml').write_text('<<<<<<< ours\n<source/>\n=======\n<other/>\n>>>>>>> theirs\n')
run(['git','-c','core.attributesFile='+str(probe/'rule'),'diff','--no-index','--check','/dev/null',str(probe/'upstream.xml')],'source-eol-control',1)
run(['git','-c','core.attributesFile=/dev/null','diff','--no-index','--check','/dev/null',str(probe/'outside.py')],'outside-eol-control',3)
run(['git','-c','core.attributesFile='+str(probe/'rule'),'diff','--no-index','--check','/dev/null',str(probe/'conflict.xml')],'source-conflict-control',3)
# Author packet retains the original uncorrected file and every released byte.
m=json.loads((A/'artifact-manifest.json').read_text());physical={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file()};ck('frozen implementation exact physical inventory',physical=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'})
for item in m['files']:ck('author unchanged '+item['path'],sha(A/item['path'])==item['sha256'] and (A/item['path']).stat().st_size==item['bytes'])
ck('author original attribute preserved',sha(A/'maintained'/rel)=='c51280faf468639ed6606a0953b6d30dccfd9cea6634420408b1b65865aab01f')
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'results':checks,'findings':[],'successor':{'path':rel,'sha256':want,'prior_sha256':'c51280faf468639ed6606a0953b6d30dccfd9cea6634420408b1b65865aab01f'},'other_owners_unchanged':174,'originals_unchanged':52,'actual_attributes':attrs,'commands':commands,'scope':'Root-authored single attribute successor; complete original frozen implementation remains unchanged. Read-only git check-attr and no-index checks with ephemeral command-local attributes, no Git/index/config mutation. No acceptance of later root pages or full-suite results.'}
(R/'results/attribute-successor-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'findings':0}))
