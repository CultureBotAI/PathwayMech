from pathlib import Path
import base64,gzip,hashlib,importlib.util,json,sqlite3,sys,datetime
R=Path(__file__).resolve().parent;C=R/'candidate';B=R/'inputs/baseline'
sys.path[:0]=[str(R/'runtime-copy/src'),str(R/'runtime-copy')]
from scripts.build_source_identifier_snapshot import build_snapshot
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def ck(name,value):
 checks.append({'check':name,'pass':bool(value)})
 if not value:raise AssertionError(name)
owner=C/'research/pathway_additions/2026-10-15-next-271/authority-source-originals'
bindings=read(owner/'selected-original-bindings.json');manifest=read(owner/'manifest.json')
fixture=C/'tests/fixtures/acetate_methanogenesis_authority';storage=read(fixture/'storage.json')
ck('exact 52 retained source bindings',len(bindings)==52)
ck('fixture manifest matches source manifest',read(fixture/'manifest.json')==manifest)
for row,entry in zip(bindings,manifest,strict=True):
 frame=row['id'].split(':',1)[1];raw=(owner/'originals'/('META-'+frame+'.xml')).read_bytes();recpath=owner/'acquisition'/('META-'+frame+'.json');receipt=read(recpath)
 ck('retained XML matches independent original '+frame,raw==(R/'inputs/native'/('META-'+frame+'.xml')).read_bytes())
 ck('issuer body hash binding '+frame,sha(raw)==row['sha256']==entry['sha256']==receipt['sha256'])
 ck('issuer request actual binding '+frame,entry['url']==row['request_url']==receipt['url'])
 ck('receipt exact frozen original '+frame,recpath.read_bytes()==Path(row['source_receipt_path']).read_bytes() and sha(recpath.read_bytes())==row['source_receipt_sha256'])
 ck('successful response receipt '+frame,receipt['status']==200)
 st=storage[entry['path']];compressed=(fixture/st['path']).read_bytes()
 ck('fixture compressed binding '+frame,len(compressed)==st['compressed_bytes'] and sha(compressed)==st['compressed_sha256'])
 ck('fixture decoded exact original '+frame,gzip.decompress(compressed)==raw and len(raw)==st['bytes'] and sha(raw)==st['sha256'])
# Use the unchanged pinned extractor against accepted complete selected rows in memory only.
p=B/'scripts/build_ontology_identifier_snapshot.py';spec=importlib.util.spec_from_file_location('independent_ontology',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
tax=read(owner/'taxonomy/taxonomy-complete-selected-statements.json');old=read(B/'data/identifier_authorities/ontology.json')
ids=['NCBITaxon:2207','NCBITaxon:2208','NCBITaxon:2210','NCBITaxon:2214','NCBITaxon:2222','NCBITaxon:2224']
with sqlite3.connect(':memory:') as conn:
 conn.execute('CREATE TABLE statements (subject TEXT,predicate TEXT,value TEXT)')
 for ident in ids:
  for row in tax[ident]:conn.execute('INSERT INTO statements VALUES (?,?,?)',(row['subject'],row['predicate'],row['value']))
 terms,missing=m.extract_terms(conn,ids,old['terms']['NCBITaxon:2208']['source'])
ck('all six pinned statement projections supported',not missing)
ck('existing 2208 exact control',terms['NCBITaxon:2208']==old['terms']['NCBITaxon:2208'])
for ident,term in terms.items():
 if ident not in old['terms']:old['terms'][ident]=term
# Independent build output from genuine scratch-cache originals (no historical cache projection).
built=build_snapshot(R/'probe-work/manifest.json',R/'probe-work/records',R/'probe-work')
merged=read(B/'data/identifier_authorities/sources.json')
for section in ['sources','terms']:
 ck('new '+section+' disjoint',not(set(merged[section])&set(built[section])))
 merged[section].update(built[section])
newconf=read(B/'conf/identifier_sources.json')+manifest
out=R/'reproduced';out.mkdir(exist_ok=True)
for name,value,target in [('sources.json',merged,C/'data/identifier_authorities/sources.json'),('ontology.json',old,C/'data/identifier_authorities/ontology.json'),('identifier_sources.json',newconf,C/'conf/identifier_sources.json')]:
 raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode();(out/name).write_bytes(raw)
 ck('independent additive byte reproduction '+name,raw==target.read_bytes())
result={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'findings':[],'results':checks,'scope':'52 exact original/receipt/fixture bindings; new-only source build; six selected taxonomy statement projections with five new terms and existing control; no fresh full database query/hash or historical cache rebuild.'}
(R/'results/independent-reproduction.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'findings':0}))
