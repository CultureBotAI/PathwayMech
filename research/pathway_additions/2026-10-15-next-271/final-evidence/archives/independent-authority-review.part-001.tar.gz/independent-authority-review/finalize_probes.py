from pathlib import Path
import json,hashlib,sys,shutil,datetime
from xml.etree import ElementTree as ET
R=Path(__file__).resolve().parent;sys.path[:0]=[str(R/'runtime-copy/src'),str(R/'runtime-copy')]
from pathwaymech import biocyc_acetate_methanogenesis as A
from scripts.build_source_identifier_snapshot import build_snapshot
attempt=R/'attempts/continuation-local-bindings';attempt.mkdir(exist_ok=True)
for name in ['continue_probes.py','continue-probes.stdout','continue-probes.stderr']:
 shutil.copy2(R/name,attempt/name)
for name in ['probe-progress.json','probe-results-live.json']:
 shutil.copy2(R/'results'/name,attempt/name)
(attempt/'DISPOSITION.md').write_text('The completed continuation passed all term, downgrade, and record-role cases except two producer calls whose wrapper lacked the local records path. They were recorded as NameError, not product acceptances. Final serialization then lacked the representative-map local. This terminal successor replays only those two calls with the bound scratch selection, independently supplies the deterministic representative map and two final scope checks, and combines the already persisted passing results. No product change.\n')
live=json.loads((attempt/'probe-results-live.json').read_text());assert live['phase']=='all 51 nonroot native record roles';rows=live['results'];assert len(rows)==2497
expected={'producer preselection conflicting full originals':'conflict-manifest.json','producer duplicate source keys':'duplicate-manifest.json'}
assert {r['check'] for r in rows if not r['pass']}==set(expected)
reruns=[]
for row in rows:
 if row['check'] not in expected:continue
 assert row['detail']['unexpected_exception']=='NameError' and "records" in row['detail']['message']
 try:build_snapshot(R/'probe-work'/expected[row['check']],R/'probe-work/records',R/'probe-work')
 except ValueError as exc:
  result={'check':row['check'],'pass':True,'detail':{'exception':'ValueError','message':str(exc)}}
 else:raise AssertionError('product accepted '+row['check'])
 reruns.append(result);row.update(result)
oracle=json.loads((R/'results/independent-native-profile-oracle.json').read_text());oldids={r['id'] for r in oracle if not r['new_authority_required']};newids={r['id'] for r in oracle if r['new_authority_required']}
new=json.loads((R/'candidate/data/identifier_authorities/sources.json').read_text());old=json.loads((R/'inputs/baseline/data/identifier_authorities/sources.json').read_text())
rows.extend([{'check':'existing source profiles not promoted','pass':not(set(A.PROFILES)&oldids)},{'check':'no reference-only new authority IDs','pass':set(new['terms'])-set(old['terms'])==newids}])
assert all(x['pass'] for x in rows)
reps={}
for row in sorted([o for o in oracle if o['id'] in newids],key=lambda o:(R/o['original_copy']).stat().st_size):
 entity=ET.fromstring((R/row['original_copy']).read_bytes())[1]
 for index,node in enumerate(entity.iter()):
  if index and node.get('frameid'):reps.setdefault(node.tag,{'id':row['id'],'index':index,'attributes':node.attrib})
result={'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(rows),'findings':[],'results':rows,'native_positive_sources':52,'observed_tag_representatives':reps,'execution_scope':'1926 persisted passing semantic checks; continuation passes remaining cases; two continuation NameError fixture bindings rerun successfully here; original attempts preserved. Not a claim of one uninterrupted final run.','reruns':reruns,'prose_count_correction':{'historical_prepared_scope_all_slots':1530,'actual_oracle_all_slots':sum(sum(x['direct_slot_multiplicities'].values()) for x in oracle),'new_slots':989}}
(R/'results/independent-probes.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(rows),'findings':0,'reruns':reruns}))
