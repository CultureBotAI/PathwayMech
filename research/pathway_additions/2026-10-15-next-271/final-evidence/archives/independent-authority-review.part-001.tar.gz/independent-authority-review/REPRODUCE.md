# Bounded independent reproduction

Use the existing verified interpreter with `PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1` and `-B`. Do not install or update anything. Scripts write only this owned scratch directory and read the bound inputs.

- `review_probes.py` is the corrected standalone independent probe program. Actual review evidence preserves completed phases and continuation chronology rather than asserting a final uninterrupted execution. `continue_probes.py` and `finalize_probes.py` retain that execution path; final results are in `results/independent-probes.json`.
- `review_reproduction.py` checks all 52 original/receipt/fixture bindings and independently reproduces all three additive outputs. Exact frozen receipt paths remain explicit inputs. It does not access or rehash the full external taxonomy cache.
- `review_attribute_successor.py` binds root's one-file released successor, queries actual attributes, runs read-only no-index controls and verifies original frozen implementation integrity. It requires the exact owned worktree until publication binding; all accepted bytes and command logs are retained here.
- `intake_implementation.py` records the original 175-owner release. Do not rerun it against the post-successor worktree expecting the original attribute hash; its terminal historical receipt is intentional.

Final reproduction and reviews must use separate output owners if these files have been frozen. Preserve original attempts and logs. No full suite or broad science rerun is necessary for this bounded result.
