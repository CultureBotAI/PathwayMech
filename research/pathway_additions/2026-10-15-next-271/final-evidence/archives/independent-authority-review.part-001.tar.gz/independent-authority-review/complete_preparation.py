from pathlib import Path
import json,collections,xml.etree.ElementTree as E,hashlib,datetime
from html.parser import HTMLParser
O=Path('/private/tmp/pathwaymech-next-271-independent-authority-review');rows=json.loads((O/'results/independent-native-profile-oracle.json').read_text())
class Text(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.parts=[]
 def handle_data(self,data):self.parts.append(data)
def normal(s):
 p=Text();p.feed(s);p.close();return ' '.join(''.join(p.parts).split())
labels=[];tags=collections.Counter();sides=[];components=[]
for row in rows:
 n=next(x for x in E.parse(O/row['original_copy']).getroot() if x.tag!='metadata');common=row['direct_common_names'];assert len(common)<=1;label=normal(common[0]) if common else row['id'].split(':',1)[1]
 if row['new_authority_required']:assert label==row['graph_label']
 labels.append({'id':row['id'],'source_derived_label':label,'source_synonyms':sorted({normal(x) for x in row['direct_synonyms']}-{label}),'name_origin':'direct_common_name' if common else 'native_frame_id','preserve_existing_owner':not row['new_authority_required']})
 for x in n.iter():
  if {'frameid','orgid','ID','resource'} & x.attrib.keys():tags[x.tag]+=1
 if n.tag=='Reaction':
  for side in ['left','right']:
   for i,x in enumerate(n.findall(side),1):
    nodes=[z for z in x if z.get('frameid')];assert len(nodes)==1;z=nodes[0];coeff=x.find('coefficient');assert x.find('compartment') is None;sides.append({'reaction':row['id'],'side':side,'ordinal':i,'material':'MetaCyc:'+z.get('frameid'),'native_type':z.tag,'class':z.get('class')=='true','coefficient_literal':None if coeff is None else coeff.text,'effective_coefficient':1 if coeff is None else int(coeff.text),'compartment':None})
 if row['expected_category']=='complex':
  for i,x in enumerate(n.findall('component'),1):
   z=next(z for z in x if z.get('frameid'));coeff=x.find('coefficient');components.append({'complex':row['id'],'ordinal':i,'component':'MetaCyc:'+z.get('frameid'),'coefficient_literal':None if coeff is None else coeff.text})
assert len(sides)==29 and len({x['material'] for x in sides})==19 and len(components)==8
stmts=json.loads((O/'inputs/graph/inputs/issuer/results/taxonomy-complete-selected-statements.json').read_text());ont=json.loads((O/'inputs/baseline/data/identifier_authorities/ontology.json').read_text());key=ont['terms']['NCBITaxon:2208']['source'];tax=[]
for ident in ['NCBITaxon:2207','NCBITaxon:2210','NCBITaxon:2214','NCBITaxon:2222','NCBITaxon:2224']:
 a=stmts[ident];labels0={r['value'] for r in a if r['predicate']=='rdfs:label' and r['value']};assert len(labels0)==1;label=next(iter(labels0));tax.append({'id':ident,'expected_term':{'label':label,'synonyms':sorted({r['value'] for r in a if r['predicate']=='oio:hasExactSynonym' and r['value'] and r['value']!=label}),'source':key},'rank':[r['object'] for r in a if r['predicate']=='obo:ncbitaxon#has_rank'],'scope':'Accepted pinned selected statements; not a fresh cache query/hash.'})
out={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'all_native_count':69,'new_native_count':52,'new_profile_type_counts':dict(collections.Counter(x['xml_type'] for x in rows if x['new_authority_required'])),'new_direct_slot_total':sum(sum(x['direct_slot_multiplicities'].values()) for x in rows if x['new_authority_required']),'all_direct_slot_total':sum(sum(x['direct_slot_multiplicities'].values()) for x in rows),'observed_nested_identity_tag_counts':dict(sorted(tags.items())),'source_names':labels,'reaction_occurrences':sides,'complex_components':components,'five_expected_taxonomy_terms':tax,'existing_taxon_2208':ont['terms']['NCBITaxon:2208'],'scope':'Independent input expectations only. No unreleased implementation inspection or acceptance.'}
(O/'results/prepared-expectations.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS independent source labels, 29 unlocated material occurrences, 8 component occurrences, 5 taxonomy projections; no product tested')
