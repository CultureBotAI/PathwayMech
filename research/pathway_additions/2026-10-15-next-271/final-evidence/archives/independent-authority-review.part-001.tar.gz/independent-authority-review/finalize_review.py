from pathlib import Path
import datetime,hashlib,json,os
R=Path(__file__).resolve().parent
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
intake=read(R/'results/implementation-intake.json');logic=read(R/'results/independent-probes.json');repro=read(R/'results/independent-reproduction.json');attr=read(R/'results/attribute-successor-review.json')
assert not logic['findings'] and not repro['findings'] and not attr['findings']
assert (logic['checks'],repro['checks'],attr['checks'])==(2499,373,880)
for x in read(R/'prepared-inputs-manifest.json')['files']:
 assert sha(R/x['path'])==x['sha256']
for x in intake['copies']:
 assert sha(R/x['copy'])==x['sha256']
expected={x['path']:x['sha256'] for x in intake['committed_dependencies']}
for x in intake['maintained_owners']['files']:
 if x['path'].endswith('.py') and x['path'].startswith(('src/','scripts/')):expected[x['path']]=x['sha256']
actual={p.relative_to(R/'runtime-copy').as_posix() for p in (R/'runtime-copy').rglob('*') if p.is_file()}
assert actual==set(expected)
for p,h in expected.items():assert sha(R/'runtime-copy'/p)==h
put(R/'results/runtime-bindings.json',{'baseline_commit':'63ebb3b3e29ca1ed6472597104347d9fbc98f4a5','files':[{'path':k,'sha256':v} for k,v in sorted(expected.items())],'scope':'116 committed dependency files plus the new adapter; released producer/consumer files replace their exact baseline counterparts. No package/runtime installation or maintained mutation. These are authority probes, not a rerun of current schema/pages or full corpus gates.'})
old_scope=R/'candidate/research/pathway_additions/2026-10-15-next-271/authority-source-originals'
trailing=[]
for p in sorted((old_scope/'originals').glob('*.xml')):
 for i,line in enumerate(p.read_bytes().splitlines(),1):
  if line.endswith((b' ',b'\t')):trailing.append({'file':p.name,'line':i,'body_sha256':sha(p)})
put(R/'results/original-source-trailing-space-inventory.json',{'occurrences':trailing,'count':len(trailing),'scope':'Byte-level trailing space/tab lines in all 52 unchanged XML originals; retained unchanged, not repaired.'})
result={'status':'qualified_acceptance','finished_utc':now,'implementation_review_started_utc':intake['utc'],'preparation_utc':read(R/'PREPARATION.json')['prepared_utc'],'reviewer':'/root/next268_reaction_review_completion','implementation_author':'/root/next268_current_bigg_completion','independence':'Reviewer did not author authority implementation or graph design. Reviewer authored earlier independent source/issuer/endpoint reviews and mechanical retention, reused at their explicit accepted scopes. Root authored the one-file packaging successor.','input':{'owner':intake['author_owner'],'manifest_sha256':intake['release_hashes']['artifact-manifest.json'],'handoff_sha256':intake['release_hashes']['HANDOFF.md'],'freeze_sha256':intake['release_hashes']['freeze-proof.json'],'listed':638,'physical':640,'listed_bytes':140940072,'maintained_files_at_initial_intake':175},'baseline':{'commit':'63ebb3b3e29ca1ed6472597104347d9fbc98f4a5','tree':'5448122efcfbd8ae2ac90ad42e70557b03d9b78e'},'accepted_successor':attr['successor'],'independent_checks':{'authority_semantics_and_roles':2499,'original_receipt_fixture_and_additive_reproduction':373,'attribute_scope_and_unchanged_owners':880,'total':3752},'actionable_open_findings':[],'resolved_packaging_observation':{'origin':'root full-gate observation; independently confirmed missing original EOL whitespace exemption and qualified successor','original_file_sha256':attr['successor']['prior_sha256'],'successor_sha256':attr['successor']['sha256'],'source_bytes_changed':False,'scope':'Directory-local rule exempts only trailing spaces for direct originals/*.xml; conflict markers and outside whitespace remain checked.'},'new_native':52,'preserved_native_demand':17,'new_taxa':5,'preserved_taxon':'NCBITaxon:2208','native_original_slots':{'new_52':989,'all_69':1415},'execution':'Passing phases are combined with explicit continuation and two corrected producer-case reruns. Every failed reviewer harness attempt is retained; this does not assert one uninterrupted final probe run.','no_new_science_claim':True,'limits':['No fresh literature or source-science rereview; source/issuer/graph conclusions reused only at accepted scopes.','No global alias promotion, chemical equivalence, missing subunit inference, taxon-strain mapping, or activity-to-whole-pathway inference.','No fresh full taxonomy cache query/hash; unchanged extractor was run on accepted complete selected statements.','No historical full source-cache rebuild; exact finite additions reproduce the released three outputs.','Root owns later full suite, current generated-page freshness, histories, packaging helper formatting, canonical review and publication. Those are not accepted by this bounded implementation review.','No maintained/Git/index/GitHub/network/runtime writes, no helpers or installations. Git commands were read-only check-attr/no-index comparisons.']}
put(R/'RESULT.json',result)
(R/'REVIEW.md').write_text('''# Independent next271 authority implementation review

Accepted within the bounded implementation scope, including root's explicitly released one-file attribute successor. No remaining actionable authority finding was identified. This is not final whole-record, page, full-suite or publication acceptance.

## Exact basis and independence

The author packet is `/private/tmp/pathwaymech-next-271-authority-implementation`, manifest `cab1f0897c6a41ada6a11752b8df1e6ce00adc1884df91c7936ad79fe22672d4`: 638 listed / 640 physical files and 140,940,072 listed bytes. Initial intake independently checked every listed hash, physical file including hidden/ignored files, and all 175 maintained owner bytes. Its exact original remains unchanged. Baseline is actual merge `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e`.

The reviewer did not author the implementation or native graph. Earlier independent source, issuer and endpoint reviews were authored by this reviewer and reused only at their accepted scopes; they are not claimed as newly independent primary literature or chemistry work. Graph acceptance is separately authored and retained by root. All probes ran on bound scratch copies of the exact released producer, consumer and adapter plus committed dependency copies.

## Implementation assessment

The new kind is finite and separate from prior profiles. All 52 new profile IDs, own type/class, direct-slot multiplicities, parent identities and embedded shapes agree with independent expectations prepared before release. Their 989 own slots, nine exact frame-label fallbacks, direct source aliases, six reversible equations with 29 unlocated material occurrences, seven enzyme/activity mappings and eight component occurrences are preserved. The 69 original objects together contain 1,415 own slots: the earlier prepared prose's 1,530 was a reviewer transcription mistake, corrected here without rewriting the frozen prepared inputs. No product count defect resulted.

Producer and consumer both accept all genuine originals, preserve canonical original base64 and rederive complete projections and terms. Rehashed malformed bodies fail semantic guards, not incidental hash/projection mismatch: complete attribute stripping and individual identity deletion/mismatch cover all 14 observed native object tag types; legitimate scalar, CML and PGDB controls remain valid. Own type/class, metadata, version, query, envelope, parents, slot multiplicities, material identities/classes, coefficients (including omitted versus explicit one), invented compartments, duplicate members, component quantities and exact activity links were challenged. Source-name changes that are internally coherent remain source-derived; conflicting owners and forged projections/terms fail.

Request-only downgrade probes exercise both preselection producer and full consumer boundaries, including unselected sources, all recognized hosts, bare native requests, literal/encoded charged frames and id/object forms. Unrelated host/path/query/suffix and ECOLI cases do not become these META profiles. Acquisition acceptance remains strict to the actual literal request; broader recognition is rejection-only. Duplicate owner keys, incompatible typed metadata and altered term owner/type/label/synonyms are rejected.

Every one of the 51 nonroot new declarations passes its independently expected category/section and fails incorrect labels, sections or categories even with a broad contextual-label waiver. Activities remain molecular_activity participants; protein classes do not become physical complexes. The root, reaction and participant roles remain separate. Generic graph, page and KGX contracts are not modified by this authority patch; endpoint support has its separate accepted review.

All prior source/ontology owner objects, terms and insertion order remain exact, including the 17 existing native demands and NCBITaxon:2208. There are precisely 52 source and five taxonomy additions; genes, regulations, range and reference-only identifiers are not promoted. Full source and ontology consumers load all 3,479 and 2,211 terms respectively. The unchanged ontology extractor reproduces the five new terms and existing control from accepted selected statements, retaining rank and synonym distinctions without a fresh full-cache hash claim.

## Reproduction and evidence bindings

The independent finite build reproduces source additions, and merging only those additions reproduces sources.json, ontology.json and identifier_sources.json byte-for-byte. All 52 retained XML bodies equal independent original copies; acquisition receipt/body/URL bindings and compressed fixture hashes/decoded bodies match exactly. These include nine accepted discovery-body reuses and 43 successful acquisitions, not 52 fresh requests. No historical cache rebuild or broad source acquisition occurred.

The final receipts contain 2,499 distinct authority/record-role checks, 373 original-binding/reproduction checks, and 880 attribute/inventory checks, all passing. Author receipts were read separately: 396 focused tests pass; regression initially recorded 1,008 passes and five environment/import failures, with exactly those five corrected-environment successor tests passing. The original failed attempts remain visible. Root's later full gates are independent and are not represented as complete here.

## Packaging successor

The frozen original `.gitattributes` (`c51280fa…`) lacked the established trailing-space exemption for exact upstream XML. Root's released successor is `2fdf457c0d6c3ab3dcf16c1d8f6b7e21c27641eac324e902f17dfd9af934881c`. The rule `/originals/*.xml -text whitespace=-blank-at-eol` is restricted to direct source originals; the existing acquisition JSON text rule is unchanged. Actual Git attribute queries confirm no new exemption for acquisition JSON, unrelated or nested XML, code, record data or docs. Read-only no-index controls preserve source EOL spaces and reject outside trailing whitespace and source conflict markers. Their exit statuses explicitly account for the no-index difference bit. All other 174 maintained owners and all 52 XML bodies remain exact. The original release and corrected file are separately retained.

## Attempts and limits

Reviewer fixture mistakes are retained under `attempts/`: taxonomy list shape, an empty positive term map, omitted alias adjustment for a renamed source, shared mutable fixture metadata, continuation-only local bindings, and no-index exit interpretation. Passing phases were persisted; only missing/corrected continuation cases were replayed. The final receipt does not claim an uninterrupted final run. These failures are distinguished from product behavior, and all owned jobs are terminal.

The accepted scientific limits remain: source-only associations, presumed Mtr/component gaps, generic carriers, native EC and short-SMILES conflicts, taxonomy rank/range and strain distinctions, cofactor and direction limits, and unavailable primary scopes. No new chemical/public equivalence or biological inference is supplied by this adapter. This review does not accept root's later page freshness correction, helper formatting, histories, final corpus gates, canonical review, or merge/publication. No maintained, Git/index, GitHub, network, runtime or frozen-source writes were made.
''')
(R/'REPRODUCE.md').write_text('''# Bounded independent reproduction

Use the existing verified interpreter with `PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1` and `-B`. Do not install or update anything. Scripts write only this owned scratch directory and read the bound inputs.

- `review_probes.py` is the corrected standalone independent probe program. Actual review evidence preserves completed phases and continuation chronology rather than asserting a final uninterrupted execution. `continue_probes.py` and `finalize_probes.py` retain that execution path; final results are in `results/independent-probes.json`.
- `review_reproduction.py` checks all 52 original/receipt/fixture bindings and independently reproduces all three additive outputs. Exact frozen receipt paths remain explicit inputs. It does not access or rehash the full external taxonomy cache.
- `review_attribute_successor.py` binds root's one-file released successor, queries actual attributes, runs read-only no-index controls and verifies original frozen implementation integrity. It requires the exact owned worktree until publication binding; all accepted bytes and command logs are retained here.
- `intake_implementation.py` records the original 175-owner release. Do not rerun it against the post-successor worktree expecting the original attribute hash; its terminal historical receipt is intentional.

Final reproduction and reviews must use separate output owners if these files have been frozen. Preserve original attempts and logs. No full suite or broad science rerun is necessary for this bounded result.
''')
(R/'HANDOFF.md').write_text(f'''# Frozen independent next271 authority review

Qualified acceptance, no open authority implementation finding. The exact root-authored attribute successor is included; other root changes and final corpus/page/publication gates remain outside this review.

- Review basis: author manifest `{intake['release_hashes']['artifact-manifest.json']}`, 638 listed / 640 physical, 140,940,072 listed bytes; initial actual 175 owners exact.
- Successor attribute: `{attr['successor']['sha256']}`; all other 174 owners and 52 XML bytes unchanged. Original author packet remains exact.
- Checks: 2,499 authority semantics/roles + 373 original/reproduction + 880 attribute/integrity = 3,752 passing assertions. No author full suite was repeated.
- Scope: exact 52 native + five taxonomy additions, prior objects/order preserved; 989 new slots, 29 unlocated material occurrences, seven activities, eight components. Complete source and ontology snapshots load; three additive output files reproduce exactly.
- See `REVIEW.md` for the substantive verdict, `RESULT.json` for structured limits, `results/independent-probes.json`, `results/independent-reproduction.json`, and `results/attribute-successor-review.json` for terminal evidence. `attempts/` preserves every failed reviewer harness attempt. No one-run claim is made.
- Independence: reviewer did not author implementation/graph; earlier independent scientific and endpoint reviews are reused at their stated scopes, not newly reread or self-accepted.
- All owned tool processes are terminal. No maintained/Git/GitHub/network/runtime/source writes. Finished UTC: {now}.

This packet is immutable after its `artifact-manifest.json` and `freeze-proof.json` are written. All regular physical files, including hidden/ignored files and failed attempts, are inventoried. Nested fixture gzip bodies were explicitly checked only within the stated 52-source scope; no unrelated archive-reading claim is made.
''')
(R/'OPERATIONS.md').write_text('''# Review operations

Preparation bound the committed baseline and independent 69-object expectations before release. The exact 640-file author packet and 175 maintained files were then read/hash-verified. Implementation logic, producer/consumer diffs, complete tests, source docs and author command receipts were inspected. No ASSESSMENT.md existed in this released packet; HANDOFF/REPRODUCE/OPERATIONS/check-receipts were the actual reporting inputs. This was a path navigation observation, not a wider absence claim.

Owned terminal sessions: intake 13331 (0); initial probe 45666 (1, taxonomy fixture); probe 79597 (1, empty positive fixture); probe 4408 (1, renamed-source alias fixture); probe 26064 (1, shared fixture mutation); independent reproduction 31804 (0); continuation 43812 (1, omitted helper); continuation 76217 (1, wrapper local bindings/final serialization); finalizer (0, two missing producer cases replayed); initial attribute wrapper (1, no-index status interpretation); corrected attribute session 64810 (0). Initial preparation's committed filename navigation failure is retained separately. No live handles remain.

The completed 1,926 semantic checks are retained verbatim, continuation records the remaining role/owner/request checks, and the terminal finalizer replaces only the two wrapper NameError outcomes after actually executing their producer calls. Original files/receipts for each attempt remain under attempts/. Positive setup repeats are not double-counted in 2,499 distinct authority checks. Corrected standalone probe source is retained for future reproduction in a fresh owner.

No helpers, dependency installations, network calls, maintained edits or Git/index mutations. Git read commands and no-index comparisons are confined to evidence gathering; command-local attribute options do not modify configuration. Original native bytes, frozen author packet, and prepared input manifest remain unchanged. A new successor copy holds root's explicitly released attribute delta without replacing the original candidate copy.
''')
# No new checks after this point; freeze includes all regular files except the self-referential envelope pair.
files=[]
for p in sorted(R.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file() and p.relative_to(R).as_posix() not in {'artifact-manifest.json','freeze-proof.json'}:
  files.append({'path':p.relative_to(R).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'owner':str(R),'created_utc':now,'files':files,'listed_files':len(files),'listed_bytes':sum(x['bytes'] for x in files),'inventory_scope':'Every regular physical file including hidden/ignored files; no symlinks. Manifest and freeze envelope excluded from listing only.'}
put(R/'artifact-manifest.json',manifest)
freeze={'owner':str(R),'frozen_utc':now,'manifest_sha256':sha(R/'artifact-manifest.json'),'handoff_sha256':sha(R/'HANDOFF.md'),'review_sha256':sha(R/'REVIEW.md'),'result_sha256':sha(R/'RESULT.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'all_owned_jobs_terminal':True,'status':'qualified_acceptance','remaining_findings':0}
put(R/'freeze-proof.json',freeze)
print(json.dumps({**freeze,'freeze_sha256':sha(R/'freeze-proof.json')},indent=2))
