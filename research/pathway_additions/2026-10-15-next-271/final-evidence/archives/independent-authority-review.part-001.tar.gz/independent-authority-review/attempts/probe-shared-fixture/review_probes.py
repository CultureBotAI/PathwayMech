from __future__ import annotations
import base64,copy,hashlib,json,sys,re,traceback,datetime,itertools
from pathlib import Path
from collections import Counter
from xml.etree import ElementTree as ET
R=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'runtime-copy/src'),str(R/'runtime-copy')]
from pathwaymech import biocyc_acetate_methanogenesis as A
from pathwaymech.identifiers import _load_authority,identifier_errors
from scripts.build_source_identifier_snapshot import build_snapshot
import yaml
W=R/'probe-work';W.mkdir(exist_ok=True)
rows=[];findings=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def check(name,cond,detail=None):
 rows.append({'check':name,'pass':bool(cond),'detail':detail})
 if not cond:findings.append(rows[-1])
def reject(name,fn):
 try:fn()
 except (ValueError,ET.ParseError) as e:
  check(name,True,{'exception':type(e).__name__,'message':str(e)});return str(e)
 except Exception as e:
  check(name,False,{'unexpected_exception':type(e).__name__,'message':str(e)});return str(e)
 check(name,False,'unexpected acceptance');return 'ACCEPTED'
def consume(value):
 p=W/'consumer.json';save(p,value);return _load_authority(p)
def snapshot(meta,key='selected'):
 ident,term=A.acetate_methanogenesis_term(meta,key)
 return {'version':1,'sources':{key:meta},'terms':{ident:term}}
def checkpoint(phase):
 save(R/'results/probe-results-live.json',{'phase':phase,'results':rows})
 save(R/'results/probe-progress.json',{'phase':phase,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(rows),'findings':findings})
 print(phase,len(rows),'checks',len(findings),'findings',flush=True)
B=R/'inputs/baseline';C=R/'candidate'
old=load(B/'data/identifier_authorities/sources.json');new=load(C/'data/identifier_authorities/sources.json')
oldo=load(B/'data/identifier_authorities/ontology.json');newo=load(C/'data/identifier_authorities/ontology.json')
oldc=load(B/'conf/identifier_sources.json');newc=load(C/'conf/identifier_sources.json')
oracle=load(R/'results/independent-native-profile-oracle.json');expect=load(R/'results/prepared-expectations.json')
newids={r['id'] for r in oracle if r['new_authority_required']};oldids={r['id'] for r in oracle if not r['new_authority_required']}
check('finite profile equals independent 52-demand',set(A.PROFILES)==newids)
check('configuration retains all prior entries and order',newc[:len(oldc)]==oldc)
check('configuration exactly 52 appended',len(newc)-len(oldc)==52)
for section in ['sources','terms']:
 check('all prior source '+section+' retain values',all(new[section].get(k)==v for k,v in old[section].items()))
 check('all prior source '+section+' retain order',[k for k in new[section] if k in old[section]]==list(old[section]))
 check('all prior ontology '+section+' retain values',all(newo[section].get(k)==v for k,v in oldo[section].items()))
 check('all prior ontology '+section+' retain order',[k for k in newo[section] if k in oldo[section]]==list(oldo[section]))
check('source term exact additions',set(new['terms'])-set(old['terms'])==newids)
check('source owner exact 52 additions',len(new['sources'])-len(old['sources'])==52)
check('taxonomy source owners unchanged',newo['sources']==oldo['sources'])
expected_taxa={row['id']:row['expected_term'] for row in expect['five_expected_taxonomy_terms']}
check('taxonomy exact five additions',set(newo['terms'])-set(oldo['terms'])==set(expected_taxa))
for ident,value in expected_taxa.items():check('taxonomy exact projection '+ident,newo['terms'][ident]==value)
for ident in oldids|{'NCBITaxon:2208'}:
 s,t=(oldo,newo) if ident.startswith('NCBI') else (old,new)
 check('preserved demanded existing owner '+ident,t['terms'][ident]==s['terms'][ident])
entries={e['url'].split('META:',1)[1]:e for e in newc if e['kind']==A.KIND};metas={};native={}
for o in oracle:
 if o['id'] not in newids:continue
 ident=o['id'];frame=ident.split(':',1)[1];body=(R/o['original_copy']).read_bytes();root=ET.fromstring(body);entity=root[1]
 native[frame]=body;p=A.PROFILES[ident]
 check('profile type/class '+ident,p['tag']==entity.tag and p['is_class']==(entity.get('class')=='true'))
 check('profile complete direct slots '+ident,p['slots']==Counter(n.tag for n in entity))
 check('profile exact parents '+ident,p['parents']==[(n[0].tag,n[0].get('frameid')) for n in entity.findall('parent')])
 embedded=[n for n in entity.iter() if n is not entity and (n.get('frameid') is not None or n.get('orgid') is not None or n.get('resource') is not None or n.get('ID') is not None)]
 check('profile exact embedded shapes '+ident,p['embedded_shapes']==Counter((n.tag,n.get('class',''),n.get('detail','')) for n in embedded))
 entry=entries[frame];dest=W/entry['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
 meta=A.acetate_methanogenesis_metadata(entry,W);metas[frame]=meta;projection=meta[A.FIELD]['projection']
 check('producer matches maintained original '+ident,new['sources'][entry['key']]==meta)
 check('producer preserves exact body '+ident,base64.b64decode(meta[A.FIELD]['original_base64'])==body)
 names=next(x for x in expect['source_names'] if x['id']==ident)
 check('independent direct name '+ident,projection['label']==names['source_derived_label'] and projection['synonyms']==names['source_synonyms'] and projection['label_origin']==names['name_origin'])
 check('exact complete own slots '+ident,projection['slots']==[{'ordinal':i,'name':n.tag,'xml':ET.tostring(n,encoding='unicode')} for i,n in enumerate(entity,1)])
 check('genuine full consumer '+ident,consume(snapshot(meta))==snapshot(meta)['terms'])
 check('maintained term exactly rederived '+ident,A.acetate_methanogenesis_term(meta,entry['key'])==(ident,new['terms'][ident]))
 if entity.tag=='Reaction':
  check('own native direction '+ident,projection['reaction_direction']==entity.findtext('reaction-direction'))
  for side in ['left','right']:
   wanted=[{'material':x['material'],'native_type':x['native_type'],'is_class':x['class'],'coefficient':int(x['coefficient_literal']) if x['coefficient_literal'] is not None else None,'compartment':None} for x in expect['reaction_occurrences'] if x['reaction']==ident and x['side']==side]
   check('independent occurrence projection '+ident+'/'+side,projection['sides'][side]==wanted)
 if entity.tag=='Enzymatic-Reaction':
  check('independent exact activity links '+ident,all(projection[slot]=='MetaCyc:'+entity.find(slot)[0].get('frameid') for slot in ['enzyme','reaction']))
 if ident in A.COMPLEXES:
  wanted=[{'id':'MetaCyc:'+n.find('Protein').get('frameid'),'coefficient':int(n.findtext('coefficient')) if n.find('coefficient') is not None else None} for n in entity.findall('component')]
  check('independent component projection '+ident,projection['components']==wanted)
check('new slots independently summed',sum(sum(A.PROFILES[i]['slots'].values()) for i in newids)==989)
check('all original slots independently summed',sum(sum(o['direct_slot_multiplicities'].values()) for o in oracle)==expect['all_direct_slot_total'])
checkpoint('all profiles and additions')
# A producer build over exactly 52 independently supplied originals, not author replay code.
manifest=W/'manifest.json';save(manifest,list(entries.values()))
records=W/'records';records.mkdir(exist_ok=True);(records/'only.yaml').write_text(yaml.safe_dump({'id':'MetaCyc:METH-ACETATE-PWY','participants':[{'id':x} for x in sorted(newids-{'MetaCyc:METH-ACETATE-PWY'})]}))
built=build_snapshot(manifest,records,W)
check('independent complete producer source delta',built['sources']=={k:v for k,v in new['sources'].items() if k not in old['sources']})
check('independent complete producer term delta',built['terms']=={k:v for k,v in new['terms'].items() if k not in old['terms']})
check('whole snapshot consumer preserves 3479 terms',_load_authority(C/'data/identifier_authorities/sources.json')==new['terms'])
check('whole ontology consumer preserves 2211 terms',_load_authority(C/'data/identifier_authorities/ontology.json')==newo['terms'])
checkpoint('independent production build and whole consumers')
# All mutation bodies receive updated source hash, exact original bytes, envelope and slot serialization.
def mutated(frame,root):
 raw=ET.tostring(root,encoding='utf-8',xml_declaration=True);meta=copy.deepcopy(metas[frame]);meta['sha256']=sha(raw)
 n=meta[A.FIELD];n['original_base64']=base64.b64encode(raw).decode();n['root_attributes']=dict(root.attrib);n['metadata_xml']=ET.tostring(root.find('metadata'),encoding='unicode')
 n['projection']['slots']=[{'ordinal':i,'name':x.tag,'xml':ET.tostring(x,encoding='unicode')} for i,x in enumerate(root[1],1)]
 return raw,meta
def both(frame,label,root):
 raw,meta=mutated(frame,root);entry=copy.deepcopy(entries[frame]);entry['path']='mutant.xml';entry['sha256']=sha(raw);(W/'mutant.xml').write_bytes(raw)
 a=reject('producer semantic '+label,lambda:A.acetate_methanogenesis_metadata(entry,W))
 value=snapshot(metas[frame]);value['sources']['selected']=meta
 b=reject('consumer semantic '+label,lambda:consume(value))
 check('not incidental hash/projection failure '+label,all(s not in a+b for s in ['original hash mismatch','projection does not match original bytes','authority has no terms']))
# Locate each observed native tag in smallest released original; robust against whole-attribute removal.
representatives={}
for frame,body in sorted(native.items(),key=lambda kv:len(kv[1])):
 e=ET.fromstring(body)[1]
 for index,node in enumerate(e.iter()):
  if node is not e and node.tag in expect['observed_nested_identity_tag_counts'] and node.get('frameid'):
   representatives.setdefault(node.tag,(frame,index,dict(node.attrib)))
check('all 14 observed identity tag representatives',set(representatives)==set(expect['observed_nested_identity_tag_counts']))
for tag,(frame,index,attrs) in representatives.items():
 for label,remove in [('all',list(attrs))]+[(k,[k]) for k in ['frameid','orgid','ID' if 'ID' in attrs else 'resource']]:
  root=ET.fromstring(native[frame]);node=list(root[1].iter())[index]
  for k in remove:node.attrib.pop(k,None)
  both(frame,tag+' strip '+label,root)
 for label in ['wrong-org','wrong-link','both-links','false-class','unknown-tag']:
  root=ET.fromstring(native[frame]);node=list(root[1].iter())[index]
  if label=='wrong-org':node.set('orgid','ECOLI')
  elif label=='wrong-link':node.set('ID' if 'ID' in node.attrib else 'resource','ECOLI:WRONG')
  elif label=='both-links':node.set('resource','getxml?META:'+node.get('frameid'));node.set('ID','META:'+node.get('frameid'))
  elif label=='false-class':node.set('class','false')
  else:node.tag='UnrecognizedNativeObject'
  both(frame,tag+' '+label,root)
# Positive reserialization includes legitimate PGDB metadata/scalar/CML nodes; no syntactic false rejection.
for frame in sorted(set(v[0] for v in representatives.values())|{'CPD-8','CPD-9'}):
 raw,meta=mutated(frame,ET.fromstring(native[frame]));value=snapshot(metas[frame]);value['sources']['selected']=meta;check('valid reserialization control '+frame,consume(value)==value['terms'])
checkpoint('nested identity semantics')
# Envelope, own identity/slot, provenance, exact biochemistry; all sources are rehashed.
for frame in ['ACET','CPD-8','Corrinoids','CoI-Corrinoid-Fe-S-proteins','CPLX-322','CPLX-461','PTAMSARC-MONOMER','ENZRXN-481','ACETATEKIN-RXN','METH-ACETATE-PWY','K+']:
 for label in ['own-attrs','own-type','own-class','slot-removed','slot-duplicated','pgdb-stripped','version','query','service','base','count','extra-envelope']:
  root=ET.fromstring(native[frame]);e=root[1]
  if label=='own-attrs':e.attrib.clear()
  elif label=='own-type':e.tag='Gene'
  elif label=='own-class':e.set('class','true' if e.get('class')!='true' else 'false')
  elif label=='slot-removed':e.remove(e[-1])
  elif label=='slot-duplicated':e.append(copy.deepcopy(e[-1]))
  elif label=='pgdb-stripped':root.find('metadata/PGDB').attrib.clear()
  elif label=='version':root.set('ptools-version','28.0')
  elif label=='query':root.find('metadata/query').text='META:WRONG'
  elif label=='service':root.find('metadata/service_name').text='getxml2'
  elif label=='base':root.set('{http://www.w3.org/XML/1998/namespace}base','https://example.org/getxml?META:'+frame)
  elif label=='count':root.find('metadata/num_results').text='2'
  else:ET.SubElement(root,'extra')
  both(frame,frame+' '+label,root)
for ident in sorted(A.EXACT_EQUATIONS):
 frame=ident.split(':',1)[1]
 for side in ['left','right']:
  root0=ET.fromstring(native[frame]);wrappers=root0[1].findall(side)
  for index,w in enumerate(wrappers):
   for label in ['coefficient-zero','coefficient-one-explicit','material-mismatch','class-mismatch','invent-compartment']:
    root=ET.fromstring(native[frame]);n=root[1].findall(side)[index];material=next(x for x in n if x.tag not in {'coefficient','compartment'})
    if label.startswith('coefficient'):
     coeff=n.find('coefficient')
     if coeff is None:coeff=ET.SubElement(n,'coefficient',{'datatype':'integer'})
     coeff.text='0' if label.endswith('zero') else ('1' if coeff.text!='1' else '2')
    elif label=='material-mismatch':material.set('frameid','WRONG');material.set('resource','getxml?META:WRONG')
    elif label=='class-mismatch':material.set('class','false' if material.get('class')=='true' else 'true')
    else:ET.SubElement(n,'compartment')
    both(frame,frame+'/'+side+'/'+str(index)+'/'+label,root)
 for label in ['direction','duplicate-left-term']:
  root=ET.fromstring(native[frame]);e=root[1]
  if label=='direction':e.find('reaction-direction').text='PHYSIOL-LEFT-TO-RIGHT'
  else:
   a=e.findall('left');a[1].clear();a[1].extend(copy.deepcopy(list(a[0])))
  both(frame,frame+'/'+label,root)
for ident in sorted(A.EXACT_ACTIVITIES):
 for slot in ['enzyme','reaction']:
  frame=ident.split(':',1)[1];root=ET.fromstring(native[frame]);n=root[1].find(slot)[0];n.set('frameid','WRONG');n.set('resource','getxml?META:WRONG');both(frame,frame+'/'+slot,root)
for ident in sorted(A.COMPLEXES):
 frame=ident.split(':',1)[1];root=ET.fromstring(native[frame]);components=root[1].findall('component')
 if not components:
  w=ET.SubElement(root[1],'component');ET.SubElement(w,'Protein',{'frameid':'WRONG','orgid':'META','resource':'getxml?META:WRONG'});both(frame,frame+'/invent-components',root)
 else:
  for i,_ in enumerate(components):
   root=ET.fromstring(native[frame]);w=root[1].findall('component')[i];c=w.find('coefficient')
   if c is None:c=ET.SubElement(w,'coefficient',{'datatype':'integer'})
   c.text='999';both(frame,frame+'/component-coefficient/'+str(i),root)
for frame in ['METH-ACETATE-PWY']:
 root=ET.fromstring(native[frame]);m=root[1].find('reaction-list');m[0].attrib.update(m[1].attrib);both(frame,'duplicate pathway member',root)
checkpoint('envelope and complete biochemical scope')
# Coherent wrong-name source is allowed alone, but conflicting copies and term forgeries are forbidden.
frame='ACET';root=ET.fromstring(native[frame]);root[1].find('common-name').text='a coherent different issuing name';raw,changed=mutated(frame,root)
changed[A.FIELD]['projection']['label']='a coherent different issuing name'
changed[A.FIELD]['projection']['synonyms']=sorted({n.text for n in root[1].findall('synonym')}-{'a coherent different issuing name'})
check('source-derived labels not hardcoded allowlist',consume(snapshot(changed))==snapshot(changed)['terms'])
value=snapshot(metas[frame]);value['sources']['conflict']=changed;reject('consumer conflicting full originals',lambda:consume(value))
e2=copy.deepcopy(entries[frame]);e2.update(key='conflict',path='conflict.xml',sha256=sha(raw));(W/'conflict.xml').write_bytes(raw)
save(W/'conflict-manifest.json',[entries[frame],e2]);reject('producer preselection conflicting full originals',lambda:build_snapshot(W/'conflict-manifest.json',records,W))
save(W/'duplicate-manifest.json',[entries[frame],entries[frame]]);reject('producer duplicate source keys',lambda:build_snapshot(W/'duplicate-manifest.json',records,W))
for frame in metas:
 for field,val in [('label','invented'),('synonyms',['invented']),('label_kind','contextual'),('entity_type','native_pathway'),('source','missing')]:
  value=snapshot(metas[frame]);ident='MetaCyc:'+frame
  if value['terms'][ident].get(field)==val:val='wrong'
  value['terms'][ident][field]=val;reject('consumer exact term '+frame+'/'+field,lambda:consume(value))
# Unknown envelope fields/field-kind pairs, base64 noncanonical, original fields cannot be smuggled.
for label in ['field-kind','missing-kind','extra-field','base64-whitespace','missing-projection']:
 value=snapshot(metas['ACET']);m=value['sources']['selected']
 if label=='field-kind':m['kind']='metacyc-compounds'
 elif label=='missing-kind':del m['kind']
 elif label=='extra-field':m[A.FIELD]['invented']=True
 elif label=='base64-whitespace':m[A.FIELD]['original_base64']+='\n'
 else:del m[A.FIELD]['projection']
 reject('consumer typed metadata '+label,lambda:consume(value))
checkpoint('term and owner assertions')
# Request-only downgrade catches an unselected legacy source, plus strict provenance and negative controls.
good=entries['ACET'];one=W/'one-record';one.mkdir(exist_ok=True);(one/'one.yaml').write_text('id: MetaCyc:ACET\n')
urls=[]
for host in [A.HOST,'biocyc.org','www.biocyc.org','metacyc.org','www.metacyc.org']:
 for token in ['META:K+','META:K%2B','META%3AK%2b','id=META:K+','object=META:K%2B','id=K%2B','META:PTAMSARC-MONOMER']:
  urls.append('https://'+host+'/getxml?'+token)
for url in urls:
 legacy={**good,'key':'legacy','kind':'metacyc-compounds','url':url}
 save(W/'downgrade-manifest.json',[good,legacy]);reject('producer unselected downgrade '+url,lambda:build_snapshot(W/'downgrade-manifest.json',one,W))
 value=snapshot(metas['ACET']);value['sources']['legacy']={k:legacy[k] for k in ['url','version','sha256','license']};reject('consumer unselected downgrade '+url,lambda:consume(value))
for url in ['https://example.org/getxml?META:K+','https://biocyc.org/unrelated?META:K+','ftp://biocyc.org/getxml?META:K+','https://biocyc.org/getxml?note=META:K%2B','https://biocyc.org/getxml?META:K%2B-suffix','https://biocyc.org/getxml?META:K%2B&other=1','https://biocyc.org/getxml?META:ATP','https://biocyc.org/getxml?ECOLI:K%2B']:
 try:A.validate_acetate_methanogenesis_assertions({'unrelated':{'url':url}},[]);check('negative URL scope '+url,True)
 except Exception as e:check('negative URL scope '+url,False,str(e))
for frame in ['CA+2','CO+2','K+','NI+2','ZN+2']:
 for replacement in ['%2B','%2b','%20',' ']:
  entry=copy.deepcopy(entries[frame]);entry['url']=entry['url'].replace('+',replacement)
  reject('strict actual acquired URL '+frame+'/'+replacement,lambda:A.acetate_methanogenesis_metadata(entry,W))
checkpoint('request downgrade and provenance boundaries')
# Consumer role checks against broad contextual-label waiver, independently built record roots.
rolebase=W/'roles';(rolebase/'data/pathways').mkdir(parents=True,exist_ok=True);(rolebase/'conf').mkdir(exist_ok=True)
policy={'version':1,'namespaces':{'MetaCyc':{'snapshot':'authority.json','policy':'canonical_or_synonym'}},'contextual_labels':[{'namespace':'MetaCyc','sections':['participants','reactions','taxa'],'record_prefixes':['MetaCyc'],'reason':'independent adversarial context'}]}
(rolebase/'conf/identifier_policy.yaml').write_text(yaml.safe_dump(policy))
anchor='MetaCyc:METH-ACETATE-PWY';anchor_meta=metas['METH-ACETATE-PWY'];anchor_term=A.acetate_methanogenesis_term(anchor_meta,'root')[1]
for o in oracle:
 if o['id'] not in newids or o['id']==anchor:continue
 frame=o['id'].split(':',1)[1];meta=metas[frame];ident,term=A.acetate_methanogenesis_term(meta,'item')
 authority={'version':1,'sources':{'root':anchor_meta,'item':meta},'terms':{anchor:anchor_term,ident:term}};save(rolebase/'authority.json',authority)
 for mode in ['valid','label','section','category']:
  rec={'id':anchor,'label':anchor_term['label'],'taxa':[],'participants':[],'reactions':[]};node={'id':ident,'label':term['label'],'category':o['expected_category']};section=o['expected_section']
  if mode=='label':node['label']='invented broad contextual label'
  elif mode=='section':section='reactions' if section=='participants' else 'participants'
  elif mode=='category':node['category']='gene'
  rec[section].append(node);(rolebase/'data/pathways/one.yaml').write_text(yaml.safe_dump(rec));errors=identifier_errors(rolebase)
  check('record '+ident+'/'+mode,(not errors) if mode=='valid' else bool(errors),errors)
checkpoint('all 51 nonroot native record roles')
# Finite references are not promoted; profile never borrows existing identities.
check('existing source profiles not promoted',not (set(A.PROFILES)&oldids))
check('no reference-only new authority IDs',set(new['terms'])-set(old['terms'])==newids)
save(R/'results/independent-probes.json',{'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(rows),'findings':findings,'results':rows,'native_positive_sources':len(metas),'observed_tag_representatives':representatives,'prose_count_correction':{'historical_prepared_scope_all_slots':1530,'actual_oracle_all_slots':sum(sum(x['direct_slot_multiplicities'].values()) for x in oracle),'new_slots':989}})
print(json.dumps({'checks':len(rows),'findings':findings},indent=2),flush=True)
