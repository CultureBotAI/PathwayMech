from pathlib import Path
import hashlib,json
owner=Path(__file__).resolve().parent
code=(owner/'review_probes.py').read_text()
retained=owner/'attempts/probe-shared-fixture/probe-results-live.json'
prior=json.loads(retained.read_text())
assert prior['phase']=='envelope and complete biochemical scope' and len(prior['results'])==1926 and all(x['pass'] for x in prior['results'])
ns={'__name__':'__main__','__file__':str(owner/'review_probes.py')}
exec(compile(code.split('# A producer build')[0],str(owner/'review_probes.py'),'exec'),ns)
assert not ns['findings'] and len(ns['rows'])==591
ns['rows']=prior['results'];ns['findings']=[]
receipt={'retained_completed_checks':1926,'retained_result_sha256':hashlib.sha256(retained.read_bytes()).hexdigest(),'fresh_metadata_setup_checks':591,'corrected_main_script_sha256':hashlib.sha256(code.encode()).hexdigest(),'scope':'Reuses only persisted terminal passing phases; remaining phases execute now with independent source-fixture copies.'}
(owner/'results/continuation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
exec(compile('# Coherent wrong-name source'+code.split('# Coherent wrong-name source',1)[1],str(owner/'review_probes.py'),'exec'),ns)
