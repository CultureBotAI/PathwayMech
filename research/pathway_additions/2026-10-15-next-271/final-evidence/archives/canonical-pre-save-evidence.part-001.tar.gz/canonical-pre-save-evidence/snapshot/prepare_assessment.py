from pathlib import Path
import subprocess,json,hashlib,os,datetime,shutil,collections
import yaml
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review'); R=Path('/private/tmp/pathwaymech-next-271-20261015'); C=Path('/private/tmp/pathwaymech-next-271-ci'); A=Path('/private/tmp/pathwaymech-next-271-authority-implementation'); G=Path('/private/tmp/pathwaymech-next-271-graph-design')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
def dump(p,x): p.write_text(json.dumps(x,indent=2)+'\n')
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PYTHONPATH='src:.',UV_NO_SYNC='1',UV_OFFLINE='1',UV_PROJECT_ENVIRONMENT='/private/tmp/pathwaymech-next-263-verified-venv',UV_CACHE_DIR=str(O/'temporary/uv-cache'))
def run(name,args,cwd=R):
 start=now(); r=subprocess.run(args,cwd=cwd,env=env,capture_output=True);(O/f'operations/{name}.stdout').write_bytes(r.stdout);(O/f'operations/{name}.stderr').write_bytes(r.stderr);dump(O/f'operations/{name}-receipt.json',dict(command=args,cwd=str(cwd),started_at=start,finished_at=now(),exit_code=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()));return r
bindings=json.loads((A/'results/maintained-owner-bindings.json').read_text()); assert len(bindings['files'])==175
for f in bindings['files']: assert sha(R/f['path'])==f['sha256'],f['path']
extra=['pages/records/MetaCyc_METH-ACETATE-PWY.html','history/records/methanogenesis-from-acetate/2026-10-16T041228Z-codex-762804.yaml']
inputs=sorted(set(json.loads((O/'initial-inputs.json').read_text())+[f['path'] for f in bindings['files']]+extra))
dump(O/'expanded-inputs.json',inputs)
args=['uv','run','--no-sync','python','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for p in inputs:args+=['--input',p]
r=run('authority-expanded-inspect',args);assert r.returncode==0
initial=json.loads((O/'operations/initial-inspect.stdout').read_text());latest=json.loads(r.stdout);old={x['path']:x['sha256'] for x in initial['source']['inputs']};new={x['path']:x['sha256'] for x in latest['source']['inputs']}
changes=[dict(path=p,before=h,after=new.get(p)) for p,h in old.items() if new.get(p)!=h];assert not changes
for sub in ['authority','root-checks','prior-reviews','imodulondb']:(O/'inputs'/sub).mkdir(exist_ok=True)
for rel in ['HANDOFF.md','OPERATIONS.md','results/maintained-owner-bindings.json','results/check-receipts.json']:
 p=A/rel;shutil.copyfile(p,O/'inputs/authority'/p.name)
for f in ['maintained-page-static-check.json','maintained-page-static-initial-assumption.json','render-pages-result.json','render-pages.stdout','render-pages.stderr','record-history-result.json','record-history.stdout','record-history.stderr','vendored-check-result.json','vendored-check.stdout','vendored-check.stderr','root-intake-next271-independent-source-review.json','root-intake-next271-independent-issuer-review.json','root-intake-next271-independent-graph-review.json','root-intake-next271-activity-endpoint-implementation-review.json','root-intake-next271-graph-evidence-retention.json','root-intake-next271-authority-implementation.json']:
 p=C/f
 if p.exists():shutil.copyfile(p,O/'inputs/root-checks'/f)
shutil.copyfile(C/'graph-preview/browser-qa-result.json',O/'inputs/root-checks/browser-qa-result.json')
for owner in ['independent-source-review','independent-issuer-review','merged-baseline-independent-rebind','independent-graph-review','activity-endpoint-implementation-review']:
 dest=O/'inputs/prior-reviews'/owner;dest.mkdir(exist_ok=True)
 for f in ['HANDOFF.md','REVIEW.md','RESULT.json']:
  p=Path('/private/tmp/pathwaymech-next-271-'+owner)/f
  if p.exists():shutil.copyfile(p,dest/f)
target=R/'data/pathways/methanogenesis-from-acetate.yaml'; draft=G/'design/prospective-record.yaml';actual=yaml.safe_load(target.read_text()); accepted=yaml.safe_load(draft.read_text());assert sha(target)=='47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3'
fields=[]
def leaves(obj,path='$'):
 if isinstance(obj,dict):
  for k,v in obj.items():yield from leaves(v,path+'.'+k)
 elif isinstance(obj,list):
  for i,v in enumerate(obj):yield from leaves(v,f'{path}[{i}]')
 else:yield path,obj
ac=dict(leaves(actual));dr=dict(leaves(accepted));diff=[dict(path=p,accepted=dr.get(p),maintained=ac.get(p)) for p in sorted(set(ac)|set(dr)) if ac.get(p)!=dr.get(p)];assert len(diff)==1 and diff[0]['path']=='$.description'
dump(O/'assessments/record-field-rebind.json',dict(at=now(),target_sha256=sha(target),accepted_draft_sha256=sha(draft),leaf_count=len(ac),differences=diff,all_other_leaf_values_identical=True,keys=list(actual),counts={k:len(actual[k]) for k in ['taxa','participants','reactions','mechanistic_edges','references']}))
dump(O/'assessments/inspection-expansion.json',dict(at=now(),initial_inputs=len(old),expanded_inputs=len(new),changed_initial_inputs=changes,added_inputs=sorted(set(new)-set(old)),authority_status='Frozen author implementation; independent acceptance pending at this inspection. Initial and expanded snapshots both retained.'))
# Entire current record is parsed above; render every string once plus exact path occurrences for readable semantic assessment, without skipping any leaf.
strings={}
for p,v in ac.items():
 if isinstance(v,str):strings.setdefault(v,[]).append(p)
with (O/'assessments/entire-record-string-reading.txt').open('w') as f:
 for value,paths in strings.items():f.write('\n'+', '.join(paths)+'\n'+value+'\n')
dump(O/'assessments/all-field-values.json',ac)
claw=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/culturebotai-claw')
for p in [claw/'src/kg_microbe_sources/__main__.py',claw/'src/kg_microbe_sources/imodulondb.py',claw/'docs/reviews/2026-09-25-imodulondb-mech-integration-research.md']:
 shutil.copyfile(p,O/'inputs/imodulondb'/p.name)
r=run('imodulondb-runner-help',[str(claw/'.venv/bin/kg-microbe-sources'),'imodulondb','--help'],claw)
dump(O/'assessments/imodulondb-scope.json',dict(at=now(),runner=str(claw/'.venv/bin/kg-microbe-sources'),help_exit=r.returncode,live_datasets_query='not_run',live_search_query='not_run',reason='Parent explicitly bounded this review offline unless a concrete unresolved scientific question needs network. Record makes no transcriptomic module claim; no such question identified. This is a skipped optional cross-check, not an unavailable installed adapter or a proved absence of dataset coverage.',historical_context='Local 2026-09-25 CLAW research report lists20 organisms/28 datasets and no Methanosarcina/Methanothrix entries; report is historical contextual lead, not fresh API response or current absence evidence.',biological_scope='E. coli expression/reconstitution host is not the native archaeal pathway taxon. Transcriptomic membership could supply context only; no iModulon evidence used for catalysis/identity/direction/taxa.'))
print(json.dumps(dict(initial_inputs=len(old),expanded_inputs=len(new),record_leaf_count=len(ac),record_difference=diff,runner_help_exit=r.returncode),indent=2))
