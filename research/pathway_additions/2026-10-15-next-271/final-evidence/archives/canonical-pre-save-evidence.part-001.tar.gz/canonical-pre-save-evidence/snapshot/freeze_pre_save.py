from pathlib import Path
import os,shutil,json,hashlib,datetime
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review');D=O/'pre-save-evidence';assert not D.exists();D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
def inventory(root):
 a=[]
 for cur,ds,fs in os.walk(root):
  for d in ds:assert not (Path(cur)/d).is_symlink()
  for f in fs:
   p=Path(cur)/f;assert p.is_file() and not p.is_symlink();a.append(dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=sha(p)))
 return sorted(a,key=lambda x:x['path'])
files=[x for x in inventory(O) if not x['path'].startswith('pre-save-evidence/')]
for x in files:
 src=O/x['path'];dest=D/'snapshot'/x['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest);assert sha(dest)==x['sha256'] and sha(src)==x['sha256']
(D/'SOURCE-INVENTORY.json').write_text(json.dumps(dict(at=now(),source=str(O),files=files,scope='All existing physical files in canonical scratch owner at pre-save cutoff, including hidden/ignored cache receipt files and failed attempts. The pre-save output directory itself is excluded from its own source snapshot. No final canonical review pair exists at this cutoff.'),indent=2)+'\n')
(D/'HANDOFF.md').write_text('''# Pre-save canonical scientific evidence\n\nThis frozen subset supports root retention before the canonical review is saved. Read `snapshot/assessments/SCIENTIFIC-ASSESSMENT.md` and `snapshot/OPERATIONS.md`. It contains the complete physical pre-save canonical scratch snapshot, including both inspections, all2,545 maintained field values, exact accepted-graph comparison, selected75-node authority identity binding, source/issuer/graph review scope, successful iModulonDB applicability output and failed sandbox attempt. Hidden and ignored files are included.\n\nNo actionable scientific finding has emerged. This is not the final canonical verdict: independent authority acceptance, final full project gates and explicit reinspection of any changed supporting inputs remain required. In particular, root is correcting packaging-only helper lint/whitespace policy after initial full-gate failures. Record/source/graph claims are unchanged; no completed required-gate result is inferred.\n\nThe actual target remains SHA47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3 at base63ebb3b3e29ca1ed6472597104347d9fbc98f4a5/tree5448122efcfbd8ae2ac90ad42e70557b03d9b78e. Initial64 and expanded240 inputs are separately retained, allinitialhashes unchanged at the secondinspect. All175 authority-owned files matched the released author binding; this is not its independent implementation acceptance.\n\niModulonDB's authorized live call returned28 keys/20 organisms with no matchednative target. This finite applicability result is not negative biology. The installedrunner exists and no search/summarize applies; E.coli host datasets were not substituted. No broader network inquiry or runtime installation occurred. Browser/pixelQA remainsunavailable; staticgraph equivalence is not browser certification.\n\nAll owned jobs are terminal. No maintained/Git/GitHub changes occurred. Later finalization is deliberately outside this immutable subset; future savedreviewpair hashes are not included, preventing a circular provenance dependency. Nested earlier containers are referenced through existing retained evidence, not expanded by this subset.\n''')
listed=inventory(D)
manifest=dict(schema_version=1,created_at=now(),scope='Complete immutable pre-save evidence subset; hidden/ignored included; excludes artifact-manifest.json and freeze-proof.json to avoid self-reference.',file_count=len(listed),listed_bytes=sum(x['bytes'] for x in listed),files=listed)
(D/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze=dict(frozen_at=now(),manifest_sha256=sha(D/'artifact-manifest.json'),handoff_sha256=sha(D/'HANDOFF.md'),listed_files=len(listed),physical_files=len(listed)+2,listed_bytes=manifest['listed_bytes'],all_owned_jobs_terminal=True,not_final_canonical_verdict=True)
(D/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n')
final=inventory(D);assert len(final)==len(listed)+2
for x in listed:assert sha(D/x['path'])==x['sha256']
print(json.dumps(dict(owner=str(D),**freeze,freeze_sha256=sha(D/'freeze-proof.json')),indent=2))
