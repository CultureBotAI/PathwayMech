# Independent implementation review: issue630

Accepted at the exact three maintained file hashes below. No actionable defect found. The root-authored change fixes the confirmed activity-subject rejection while preserving the existing endpoint contract outside `has_input`/`has_output`. This is implementation acceptance, not final pathway/science or merge acceptance; issue630 should remain open until the reviewed fix is merged and verified.

| Actual maintained owner | SHA256 |
| --- | --- |
| `src/pathwaymech/schema.py` | `b3f0c28ded2e0e665c15cf0a0e4a8e19ffc1d9bdfd397aa8383ad6a13baf4214` |
| `tests/test_graph_context.py` | `6b8225b6d2bb266ba18d29e6e28c5cd48dcc0c40a6e0794098ab1b0cf77b1a71` |
| `docs/CAUSAL_GRAPHS.md` | `9d0eab4e76b22c194614cb7d309f2726e16331e5a7552c660bd5075e7497d8b2` |

Baseline is commit63ebb3b3e29ca1ed6472597104347d9fbc98f4a5/tree5448122efcfbd8ae2ac90ad42e70557b03d9b78e. The actual diff, committed before-files, current after-files and exact runtime source copies are retained. Final rechecking confirms the three maintained owners and all62 files of the prior finding/proof owner remain unchanged. The complete prior proof manifest is `bd4a9af6ce303c9d8af920bd4e6ce223ae989f9c16c0d3dc2264de3659908dc8`; its experimental patch was inspected as prior evidence, not substituted for the actual product or self-accepted.

## Narrowness and ambiguity

`validate_record` constructs a separate activity-participant set. An ID must be in participants, absent from taxa/reactions/root for this new route, and every same-ID participant declaration must explicitly have category `molecular_activity`. This avoids the existing last-write-wins categories map. Missing categories, all supported nonactivity categories, invalid categories and conflicting duplicate orders cannot gain admission. Consistent same-category duplicates preserve existing duplicate policy.

That set is threaded only to the input/output endpoint test. The shared `processes = reactions | {record_id}` is unchanged. Objects still must be declared participants and both endpoints must resolve locally; this change does not newly define which participant categories are valid biological inputs or outputs. Evidence and separate authority validation remain necessary. Participant/taxon collisions cannot acquire the new admission. Root/reaction collisions can still pass their pre-existing process branch: this is preserved legacy behavior, not a new global identity-uniqueness guarantee. The documentation's phrase “this admission” correctly scopes that distinction.

The independent differential grid evaluates all17 supported predicates over nine local/missing endpoint IDs. It includes physical, activity, process, cellular-component, reaction, pathway and taxon roles. Its only ten behavior differences are the two input/output predicates from the one unambiguous activity subject to five declared participants. All other error lists and outcomes are identical to the committed baseline. Additional probes cover every category with both duplicate orders, cross-section collisions, malformed participant collections and the unchanged protein/complex-only endpoint-qualifier rule. These synthetic combinations establish validator behavior, not biological truth.

## Tests and downstream behavior

The new maintained positive tests are meaningful: they fail at the actual old endpoint gate, then exercise closed LinkML, Python validation, visible HTML evidence anchors and KGX category/predicate/description/evidence preservation. Negative tests cover the excluded categories, ambiguous declarations, taxon collision and unrelated predicates. The retained root red run records two expected failures; the root's subsequent96 targeted tests passed. I read and retained these receipts rather than repeating that suite.

Fresh independently authored probes against copies of the actual product pass1,559 assertions across1,449 differential/guard cases. Three pipeline fixtures cover synthetic `has_input`, synthetic `has_output`, and the source-qualified six Ack alternatives. All pass unchanged closed LinkML. Actual HTML contains every directed endpoint triple and its unique evidence anchor; ordinary evidence rows retain complete descriptions, source assertions and locators. KGX TSV roundtrip retains all endpoints, RO:0002233/0002234, explicit MolecularActivity category, source category, descriptions, complete evidence and reference metadata including source hashes. Validation does not mutate the fixtures or canonical reaction declarations.

The six Ack alternatives remain six enzyme-specific activity input assertions and four separate canonical reaction material edges. The fixture's conditional/replaced-substrate qualifications remain visible and exported. Bare RO triples alone do not encode alternative/non-simultaneous use; consumers need the retained descriptions and evidence. No output biology is inferred from the synthetic output test. No enzyme-specific activity is moved into the reaction collection, and no alternate compound is silently added to the canonical equation.

Renderer, KGX, reaction-mechanism validator, strict validator and closed schema bytes were checked against the committed baseline; none changed. The existing graph shape for a participant activity remains a participant shape with explicit declared type, which does not change its KGX identity or directed evidence semantics. No new schema slot/category, reaction-detail semantics or authority role is introduced.

## Scope and disposition

Reviewer `/root/next268_reaction_review_completion` did not author the maintained fix, its tests/docs or the prior independent finding/proof. Earlier next271 scientific/issuer reviews by this reviewer are separate frozen work and were not reopened. The six-alternative source fixture reuses the prior accepted finite source scope; this is not a new primary review or final graph acceptance.

All own commands are terminal0; no failed independent probe occurred. There was no network, helper, install, maintained write, Git/GitHub mutation or full corpus suite. Original red failures are preserved as root history, not counted as review failures. Physical inventory includes hidden/ignored files. Parent owns full integration gates, final publication binding and issue closure after verified merge.
