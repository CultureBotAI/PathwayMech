from pathlib import Path
import json,yaml,hashlib,datetime,subprocess,shutil,collections,re
O=Path('/private/tmp/pathwaymech-next-271-canonical-record-review');R=Path('/private/tmp/pathwaymech-next-271-20261015');P=Path('/private/tmp/pathwaymech-next-271-source-preparation');Peer=Path('/private/tmp/pathwaymech-next-271-independent-source-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
def baseline(p):return json.loads(subprocess.run(['git','show','63ebb3b3e29ca1ed6472597104347d9fbc98f4a5:'+p],cwd=R,capture_output=True,check=True).stdout)
a=yaml.safe_load((R/'data/pathways/methanogenesis-from-acetate.yaml').read_text());s=json.loads((R/'data/identifier_authorities/sources.json').read_text());t=json.loads((R/'data/identifier_authorities/ontology.json').read_text());old_s=baseline('data/identifier_authorities/sources.json');old_t=baseline('data/identifier_authorities/ontology.json');rows=[]
for kind,nodes in [('root',[a]),('participants',a['participants']),('reactions',a['reactions']),('taxa',a['taxa'])]:
 for node in nodes:
  i=node['id'];src=t if i.startswith('NCBITaxon:') else s;old=old_t if i.startswith('NCBITaxon:') else old_s;term=src['terms'][i];assert term['label']==node['label'],i
  rows.append(dict(id=i,role=kind,category=node.get('category'),label=node['label'],authority_entity_type=term.get('entity_type'),source=term['source'],label_kind=term.get('label_kind'),existing=i in old['terms'],old_term_equal=(term==old['terms'][i]) if i in old['terms'] else None))
assert len(rows)==75 and len({r['id'] for r in rows})==75
assert sum(r['existing'] for r in rows if r['id'].startswith('MetaCyc:'))==17
assert sum(not r['existing'] for r in rows if r['id'].startswith('MetaCyc:'))==52
assert sum(not r['existing'] for r in rows if r['id'].startswith('NCBITaxon:'))==5
assert all(r['old_term_equal'] is not False for r in rows)
dump(O/'assessments/selected-authority-binding.json',dict(at=now(),status='mechanical current-record identity binding; full independent authority acceptance remains separate',source_snapshot_sha256=sha(R/'data/identifier_authorities/sources.json'),ontology_sha256=sha(R/'data/identifier_authorities/ontology.json'),source_manifest_sha256=sha(R/'conf/identifier_sources.json'),nodes=rows))
response=(O/'operations/imodulondb-live-datasets-network.stdout').read_text();data=[]
for line in response.splitlines():
 if line.startswith('| `'):
  cols=[x.strip() for x in line.split('|')[1:-1]];data.append(dict(key=cols[0].strip('`'),organism=cols[1],dataset=cols[2]))
assert len(data)==28 and len({x['organism'] for x in data})==20
terms=['methanosarcina','methanothrix','methanosaeta']
hits=[x for x in data if any(z in (x['key']+' '+x['organism']).lower() for z in terms)];assert not hits
summary=dict(at=now(),status='not_applicable',runner_available=True,returned_datasets=28,returned_organisms=20,matched_native_target_datasets=hits,finite_terms=terms,scope='Complete returned CLI inventory from https://imodulondb.org/api/datasets; current response at recorded time, not global/historical absence. Exact stdout is adapter-rendered projection, not a raw HTTP-body archive.',earlier_failure='Sandbox DNS, exit2, preserved. Authorized network-enabled retry exit0.',search_and_summarize='not_applicable because no returned organism/dataset matches native target; E. coli heterologous host not substituted',negative_biological_inference=False,data=data)
dump(O/'assessments/imodulondb-final-applicability.json',summary)
for p in [P/'results/claim-ledger.json',Peer/'results/independent-primary-reading-scope.json',Peer/'results/independent-claim-dispositions.json']:
 shutil.copyfile(p,O/'inputs/prior-reviews'/p.name)
claims=json.loads((P/'results/claim-ledger.json').read_text());assert len(claims)==32
# All frozen scientific statements and source scope metadata were already checked in the accepted graph review; these are reused, not new primary reads.
dump(O/'assessments/claim-scope-reading.json',dict(at=now(),claim_ledger_sha256=sha(P/'results/claim-ledger.json'),accepted_prior_claims=32,primary_claims=12,paper_scopes=11,method='Read canonical target and full prior source/issuer/graph prose, rebind all unchanged target fields; reuse exact prior primary-access/read scopes. No fresh whole-primary or literature review claimed.',statements=[dict(id=x['id'],statement=x['statement'],evidence_level=x['evidence_level'],disposition=x.get('disposition'),reading_scope=x.get('reading_scope')) for x in claims]))
print(json.dumps(dict(record_nodes=75,native_existing=17,native_added=52,taxa_added=5,imodulondb=summary['status'],full_record_leaf_rebind=2545),indent=2))
