from pathlib import Path
import json,hashlib,datetime,subprocess,os
O=Path('/private/tmp/pathwaymech-next-271-independent-authority-review');A=Path('/private/tmp/pathwaymech-next-271-authority-implementation');W=Path('/private/tmp/pathwaymech-next-271-20261015');expected={'artifact-manifest.json':'cab1f0897c6a41ada6a11752b8df1e6ce00adc1884df91c7936ad79fe22672d4','HANDOFF.md':'7e30e69070da276ccac533945483ddef8a639d60d7a00f6b2676c1ced8745568','freeze-proof.json':'3158a3c20f35fb9d0d0f5a7bff3737ef49bf0e5d725c27864105996f3c1fd41c'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(p,q):
 q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());return {'source':str(p),'copy':q.relative_to(O).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
for n,h in expected.items():assert sha(A/n)==h
m=json.loads((A/'artifact-manifest.json').read_text());actual={p.relative_to(A).as_posix() for p in A.rglob('*') if p.is_file()};assert actual=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'} and len(actual)==640 and len(m['files'])==638;assert not any(p.is_symlink() for p in A.rglob('*'))
for x in m['files']:assert sha(A/x['path'])==x['sha256'] and (A/x['path']).stat().st_size==x['bytes']
for x in json.loads((O/'prepared-inputs-manifest.json').read_text())['files']:assert sha(O/x['path'])==x['sha256'] and (O/x['path']).stat().st_size==x['bytes']
own=json.loads((A/'results/maintained-owner-bindings.json').read_text());assert len(own['files'])==175;copies=[]
for x in own['files']:
 assert sha(A/x['copy'])==x['sha256'] and sha(W/x['path'])==x['sha256'];copies.append(copy(A/x['copy'],O/'candidate'/x['path']))
# Copy only current implementation reports/results/top-level retained logs and scripts; not its repeated cache trees.
for p in sorted(A.iterdir()):
 if p.is_file():copies.append(copy(p,O/'inputs/implementation'/p.name))
for p in sorted((A/'results').rglob('*')):
 if p.is_file():copies.append(copy(p,O/'inputs/implementation/results'/p.relative_to(A/'results')))
# Stable committed dependency modules; overlay only released owned Python files.
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0');head=own['baseline_commit'];paths=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'src/pathwaymech','scripts'],cwd=W,env=env,text=True).splitlines();deps=[]
for rel in paths:
 if not (rel.endswith('.py') or rel.endswith('.yaml')):continue
 b=subprocess.check_output(['git','show',head+':'+rel],cwd=W,env=env);q=O/'runtime-copy'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);deps.append({'path':rel,'sha256':hashlib.sha256(b).hexdigest(),'baseline_commit':head})
for x in own['files']:
 if x['path'].endswith('.py') and x['path'].startswith(('src/','scripts/')):copy(A/x['copy'],O/'runtime-copy'/x['path'])
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_owner':str(A),'release_hashes':expected,'listed':638,'physical':640,'listed_bytes':sum(x['bytes'] for x in m['files']),'all_input_hashes_verified':True,'hidden_ignored_included':True,'prepared_snapshot_unchanged':True,'maintained_owners':own,'copies':copies,'committed_dependencies':deps,'scope':'Full frozen implementation inventory and exact actual175-owner binding, selected stable copies only. Independent code/probe verdict pending.'};(O/'results/implementation-intake.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS638 listed/640 physical;',len(own['files']),'actual maintained owners;',len(copies),'selected copies;',len(deps),'committed dependencies; prepared inputs unchanged')
