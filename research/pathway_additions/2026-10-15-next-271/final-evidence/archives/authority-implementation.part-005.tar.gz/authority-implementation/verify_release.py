"""Bind exact implementation bytes and replay the finite addition/preservation checks."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
from xml.etree import ElementTree as ET

OWN = Path(__file__).resolve().parent
WT = Path('/private/tmp/pathwaymech-next-271-20261015')
sys.path[:0] = [str(WT / 'src'), str(WT)]
from pathwaymech.biocyc_acetate_methanogenesis import (
    EXACT_ACTIVITIES, EXACT_COMPONENTS, EXACT_EQUATIONS, PROFILES,
)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def dump(rel, value):
    p = OWN / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def copied(path, relative):
    raw = path.read_bytes()
    dest = OWN / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(raw)
    return {'source': str(path), 'copy': relative, 'bytes': len(raw), 'sha256': sha(raw)}

checks = []
def check(name, ok):
    assert ok, name
    checks.append(name)

counts = {section: {} for section in ('sources', 'terms')}
for filename in ['sources.json','ontology.json']:
    before = json.loads((OWN / 'inputs/baseline/data/identifier_authorities' / filename).read_text())
    after = json.loads((WT / 'data/identifier_authorities' / filename).read_text())
    for section in ('sources','terms'):
        check(filename + ' old ' + section + ' order', list(after[section])[:len(before[section])] == list(before[section]))
        for key, value in before[section].items():
            check(filename + ' preserved ' + section + ' ' + key, after[section][key] == value)
        counts[section][filename] = {'before': len(before[section]), 'after': len(after[section])}
    check(filename + ' current reproduction a', (WT / 'data/identifier_authorities' / filename).read_bytes() == (OWN / 'reproduction-a' / filename).read_bytes())
    check(filename + ' fresh seed reproduction b', (OWN / 'reproduction-a' / filename).read_bytes() == (OWN / 'reproduction-b' / filename).read_bytes())
old_conf = json.loads((OWN / 'inputs/baseline/conf/identifier_sources.json').read_text())
new_conf = json.loads((WT / 'conf/identifier_sources.json').read_text())
check('manifest old entry order and objects', new_conf[:len(old_conf)] == old_conf)
check('52 manifest additions', len(new_conf) - len(old_conf) == 52)
check('manifest fresh seed byte reproduction', (WT / 'conf/identifier_sources.json').read_bytes() == (OWN / 'reproduction-a/identifier_sources.json').read_bytes() == (OWN / 'reproduction-b/identifier_sources.json').read_bytes())
check('source additions fresh seed bytes', (OWN / 'reproduction-a/source-additions.json').read_bytes() == (OWN / 'reproduction-b/source-additions.json').read_bytes())
check('52 profiles', len(PROFILES) == 52)
check('989 direct source slots', sum(sum(p['slots'].values()) for p in PROFILES.values()) == 989)
check('six equations', len(EXACT_EQUATIONS) == 6)
check('29 unlocated occurrences', sum(len(eq[s]) for eq in EXACT_EQUATIONS.values() for s in ('left','right')) == 29 and all(x['compartment'] is None for eq in EXACT_EQUATIONS.values() for s in ('left','right') for x in eq[s]))
check('six reversible equations', all(eq['direction'] == 'REVERSIBLE' for eq in EXACT_EQUATIONS.values()))
check('seven exact activity links', len(EXACT_ACTIVITIES) == 7)
check('eight component occurrences', sum(len(v) for v in EXACT_COMPONENTS.values()) == 8)
check('only two empty complex component lists', {k for k,v in EXACT_COMPONENTS.items() if not v} == {'MetaCyc:CPLX-322','MetaCyc:CPLX-481'})

original_owner = 'research/pathway_additions/2026-10-15-next-271/authority-source-originals'
rows = json.loads((OWN / 'results/all-52-native-profile-inventory.json').read_text())
for row in rows:
    file = Path(row['body']).name
    check('retained source original ' + row['id'], sha((WT / original_owner / 'originals' / file).read_bytes()) == row['sha256'])
    file = file.removesuffix('.xml') + '.json'
    check('retained acquisition receipt ' + row['id'], sha((WT / original_owner / 'acquisition' / file).read_bytes()) == row['source_receipt_sha256'])
base_rows = json.loads((OWN / 'results/baseline-owner-bindings.json').read_text())['files']
changed = {'src/pathwaymech/identifiers.py','scripts/build_source_identifier_snapshot.py','docs/IDENTIFIERS.md'}
for row in base_rows:
    if row['path'] not in changed:
        check('untouched bound prior owner ' + row['path'], sha((WT / row['path']).read_bytes()) == row['sha256'])

review = Path('/private/tmp/pathwaymech-next-271-independent-graph-review')
check('accepted graph manifest', sha((review / 'artifact-manifest.json').read_bytes()) == '04a24f56a0b657318fa2961a5bf041954ca7f5d0b00922b868f11463dc61b651')
review_manifest = {r['path']: r for r in json.loads((review / 'artifact-manifest.json').read_text())['files']}
extra_inputs = []
for rel in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md','REVIEW.md','RESULT.json']:
    raw = (review / rel).read_bytes()
    if rel in review_manifest:
        check('selected graph acceptance ' + rel, sha(raw) == review_manifest[rel]['sha256'])
    extra_inputs.append(copied(review / rel, 'inputs/accepted-graph-review/' + rel))
extra_inputs.append(copied(Path('/private/tmp/pathwaymech-next-271-ci/root-intake-next271-independent-graph-review.json'), 'inputs/root-receipts/root-intake-next271-independent-graph-review.json'))
record = WT / 'data/pathways/methanogenesis-from-acetate.yaml'
check('root record unchanged', sha(record.read_bytes()) == '47d1c71951ce5806e5c9570ee00b2ab9f8634158251ee06821a0f77017b0eca3')
extra_inputs.append(copied(record, 'inputs/maintained-record.yaml'))
dump('results/accepted-successor-inputs.json', extra_inputs)

owned = [
    'src/pathwaymech/biocyc_acetate_methanogenesis.py', 'src/pathwaymech/identifiers.py',
    'scripts/build_source_identifier_snapshot.py', 'conf/identifier_sources.json',
    'data/identifier_authorities/sources.json', 'data/identifier_authorities/ontology.json',
    'tests/test_acetate_methanogenesis_authority.py', 'docs/IDENTIFIERS.md',
]
for directory in [original_owner, 'tests/fixtures/acetate_methanogenesis_authority']:
    owned += [str(p.relative_to(WT)) for p in sorted((WT / directory).rglob('*')) if p.is_file()]
bindings = []
for rel in owned:
    p = WT / rel
    check('regular owned file ' + rel, p.is_file() and not p.is_symlink())
    result = copied(p, 'maintained/' + rel)
    result['path'] = rel
    bindings.append(result)
dump('results/maintained-owner-bindings.json', {'worktree': str(WT), 'baseline_commit': '63ebb3b3e29ca1ed6472597104347d9fbc98f4a5', 'baseline_tree': '5448122efcfbd8ae2ac90ad42e70557b03d9b78e', 'files': bindings})
for row in json.loads((OWN / 'results/input-bindings.json').read_text()):
    check('copied input unchanged ' + row['copy'], sha((OWN / row['copy']).read_bytes()) == row['sha256'])
    # Live baseline integration owners are superseded; all frozen sources stay immutable.
    if '/private/tmp/pathwaymech-next-271-20261015/' not in row['source']:
        check('frozen origin unchanged ' + row['source'], sha(Path(row['source']).read_bytes()) == row['sha256'])
dump('results/release-verification.json', {'passed': len(checks), 'failures': [], 'snapshot_counts': counts, 'owned_files': len(bindings), 'checks': checks})
print(json.dumps({'checks': len(checks), 'owned_files': len(bindings), 'snapshot_counts': counts}))
