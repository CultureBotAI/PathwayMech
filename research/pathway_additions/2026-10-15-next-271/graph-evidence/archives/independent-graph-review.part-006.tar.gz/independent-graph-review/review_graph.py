"""Independent graph/original/projection checks. No author generation/check scripts imported."""
from pathlib import Path
from collections import Counter
from dataclasses import asdict
import hashlib,json,re,sys
import yaml
from lxml import etree as ET,html
O=Path(__file__).resolve().parent;D=O/'inputs/frozen-design';S=D/'inputs/issuer/inputs/source/originals/native'
sys.path.insert(0,str(D/'inputs/endpoint-successor/src'))
from pathwaymech.schema import validate_record
from pathwaymech.strict import validator,TARGET_CLASS
from pathwaymech.kgx import kgx_nodes,kgx_edges,write_kgx,EXPLICIT_CATEGORIES
from pathwaymech.cli import _record_page
from pathwaymech.site_display import plain_label
checks=[]
def ck(name,value,expected=True):
 result={'check':name,'pass':value==expected,'actual':value,'expected':expected};checks.append(result)
 if not result['pass']:
  save('checks-partial.json',checks);raise AssertionError(name+': '+repr(value)+' != '+repr(expected))
def save(name,value): (O/'independent'/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def read(name):return json.loads((D/'results'/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
record=yaml.safe_load((D/'design/prospective-record.yaml').read_text());edges=record['mechanistic_edges'];emap={e['id']:e for e in edges}
refs={r['id']:r for r in record['references']};nodes={n['id']:n for f in ['participants','reactions','taxa'] for n in record[f]};nodes[record['id']]={'id':record['id'],'label':record['label']}
ck('unique nodes',len(nodes),sum(len(record[f]) for f in ['participants','reactions','taxa'])+1);ck('unique edges',len(emap),len(edges));ck('unique references',len(refs),len(record['references']))
ck('closed LinkML',len(validator().validate(record,TARGET_CLASS).results),0)
validated=validate_record(record);ck('actual accepted successor schema',sha(D/'inputs/endpoint-successor/src/pathwaymech/schema.py'),'b3f0c28ded2e0e665c15cf0a0e4a8e19ffc1d9bdfd397aa8383ad6a13baf4214')
# Freshly parse all full native originals, not projections.
trees={};own={}
for p in sorted(S.glob('META-*.xml')):
 tree=ET.parse(str(p));top=[x for x in tree.getroot() if x.tag!='metadata'];ck('single top object '+p.name,len(top),1)
 obj=top[0];frame=obj.get('frameid');ck('full own object '+frame,obj.get('detail'),'full');ck('frame filename '+frame,p.name,'META-'+frame+'.xml');trees[frame]=tree;own[frame]=obj
ck('complete retained native original count',len(own),269)
P=own['METH-ACETATE-PWY'];members=[x.get('frameid') for x in P.findall('reaction-list/Reaction')]
ck('members',len(members),6);ck('actual reaction set',sorted(n['id'] for n in record['reactions']),sorted('MetaCyc:'+x for x in members))
orient={x.find('Reaction').get('frameid'):x.findtext('direction') for x in P.findall('reaction-layout')}
expected=[]
def add(subject,predicate,obj,frame,locator,kind,**facts):
 expected.append({'subject':'MetaCyc:'+subject,'predicate':predicate,'object':'MetaCyc:'+obj,'source_frame':frame,'locator':locator,'kind':kind,**facts})
def loc(frame,tag,index=None):return '/ptools-xml/'+own[frame].tag+"[@frameid='"+frame+"']/"+tag+(f'[{index}]' if index is not None else '')
for n,x in enumerate(members,1):add('METH-ACETATE-PWY','has_part',x,'METH-ACETATE-PWY',loc('METH-ACETATE-PWY','reaction-list',1)+f'/Reaction[{n}]','membership')
for n,x in enumerate(P.findall('reaction-ordering'),1):
 target=x.find('Reaction').get('frameid')
 for prev in x.findall('predecessor-reactions/Reaction'):add(prev.get('frameid'),'precedes',target,'METH-ACETATE-PWY',loc('METH-ACETATE-PWY','reaction-ordering',n),'order')
materials=set();occ=[]
for frame in members:
 r=own[frame];ck('own reversible '+frame,r.findtext('reaction-direction'),'REVERSIBLE');ck('declared direction '+frame,nodes['MetaCyc:'+frame]['direction'],'reversible')
 for side in ['left','right']:
  for n,slot in enumerate(r.findall(side),1):
   entity=next(x for x in slot if x.get('frameid'));f=entity.get('frameid');materials.add(f)
   coefficient=slot.findtext('coefficient');c=coefficient or '1';ck('material unlocated '+frame+side+str(n),len(slot.findall('compartment')),0)
   consume=(side=='left')==(orient[frame]=='L2R')
   add(f if consume else frame,'consumes' if consume else 'produces',frame if consume else f,frame,loc(frame,side,n),'material',coefficient=c,explicit=coefficient is not None,source_side=side,orientation=orient[frame])
   occ.append({'reaction':frame,'source_side':side,'index':n,'material':f,'coefficient':c,'explicit':coefficient is not None,'selected_direction':orient[frame]})
ck('material occurrences',len(occ),29);ck('canonical material IDs',len(materials),19)
# Seven finite activities were independently prepared before reading author design.
prepared=json.loads((O/'results/expected-qualified-source-coverage.json').read_text());selected=prepared['activities'];ck('qualified activities',len(selected),7)
proteins=set();activities=set();cofactor_objects=set();alt_objects=set();regframes=set()
for row in selected:
 a=row['activity'];obj=own[a];enz=obj.find('enzyme')[0].get('frameid');rx=obj.find('reaction')[0].get('frameid');activities.add(a);proteins.add(enz)
 ck('activity accepted reaction '+a,rx,row['reaction']);ck('activity accepted enzyme '+a,[enz],row['enzyme']);ck('selected activity own hash '+a,sha(S/('META-'+a+'.xml')),row['source_sha256'])
 add(enz,'enables',a,a,loc(a,'enzyme',1),'enzyme_activity')
 add(enz,'enables',rx,a,loc(a,'reaction',1),'enzyme_reaction')
 for n,slot in enumerate(obj.findall('cofactor'),1):
  f=slot[0].get('frameid');cofactor_objects.add(f);add(enz,'has_cofactor',f,a,loc(a,'cofactor',n),'cofactor')
 for n,slot in enumerate(obj.findall('alternative-cofactor'),1):
  base=slot.find('cofactor')[0].get('frameid');f=slot.find('alternate')[0].get('frameid');cofactor_objects.add(f);add(enz,'has_cofactor',f,a,loc(a,'alternative-cofactor',n),'alternative_cofactor',replaces=base)
 for n,slot in enumerate(obj.findall('alternative-substrate'),1):
  base=slot.find('substrate')[0].get('frameid');f=slot.find('alternate')[0].get('frameid');alt_objects.add(f);add(a,'has_input',f,a,loc(a,'alternative-substrate',n),'alternative_substrate',replaces=base)
 regframes.update(x.get('frameid') for x in obj.findall('regulated-by/Regulation'))
# Whole CPLX-461 is selected assembly context, explicitly excluded as RXN-12908 catalyst.
ck('whole complex excluded by original',own['RXN-12908'].find('enzymes-not-used')[0].get('frameid'),'CPLX-461')
proteins.add('CPLX-461')
for p in sorted(list(proteins)):
 for n,slot in enumerate(own[p].findall('component'),1):
  component=slot[0].get('frameid');proteins.add(component);add(p,'has_part',component,p,loc(p,'component',n),'component',coefficient=slot.findtext('coefficient') or '1')
locations=set()
for p in sorted(proteins):
 for n,slot in enumerate(own[p].findall('location'),1):
  f=slot[0].get('frameid');locations.add(f);add(p,'located_in',f,p,loc(p,'location',n),'location')
regulators=set()
for f in sorted(regframes):
 reg=own[f];ck('negative regulation '+f,reg.findtext('mode'),'-');ck('physiology absent '+f,reg.find('physiologically-relevant') is None)
 actor=reg.find('regulator')[0].get('frameid');target=reg.find('regulated-entity')[0].get('frameid');ck('regulation targets selected activity '+f,target in activities);regulators.add(actor)
 add(actor,'inhibits',target,f,loc(f,'regulated-entity',1),'inhibition')
expected_nodes={'METH-ACETATE-PWY'}|set(members)|materials|activities|proteins|cofactor_objects|alt_objects|regulators|locations
actual_native={k.split(':',1)[1] for k in nodes if k.startswith('MetaCyc:')}
ck('complete derived native node set',sorted(actual_native),sorted(expected_nodes));ck('native nodes',len(expected_nodes),69);ck('derived total edges',len(expected),89)
actual_counts=Counter((e['subject'],e['predicate'],e['object']) for e in edges);expected_counts=Counter((e['subject'],e['predicate'],e['object']) for e in expected)
ck('all directed triples from source slots',sorted(actual_counts.items()),sorted(expected_counts.items()))
matched=[]
for x in expected:
 candidates=[e for e in edges if all(e[k]==x[k] for k in ['subject','predicate','object']) and any(v['reference_id']=='MetaCyc:'+x['source_frame'] and v.get('source_locator')==x['locator'] for v in e['evidence'])]
 ck('exact source occurrence '+x['kind']+' '+x['source_frame']+' '+x['locator'],len(candidates),1)
 e=candidates[0];desc=e['description'];matched.append({**x,'edge_id':e['id']})
 if x['kind'] in ['material','component']:ck('coefficient incident '+e['id'],'coefficient '+str(x['coefficient']) in desc)
 if x['kind']=='material':
  ck('source orientation incident '+e['id'],'root selects '+x['orientation'] in desc);ck('unlocated incident '+e['id'],'no supplied compartment' in desc)
  ck('explicitness incident '+e['id'],('explicitly supplied' if x['explicit'] else 'implicit default 1') in desc)
 if x['kind'].startswith('alternative'):
  ck('alternative replacement '+e['id'],x['replaces'] in desc);ck('not simultaneous '+e['id'],'simultaneous' in desc)
 if x['kind']=='inhibition':ck('source physiology limit '+e['id'],'physiological-relevance slot is absent' in desc)
ck('every edge matched exactly once',sorted(x['edge_id'] for x in matched),sorted(emap))
save('independent-source-projection.json',matched);save('independent-material-occurrences.json',occ)
# Exact native locator resolution and independent reference-byte binding.
bindings={x['id']:x for x in read('reference-original-bindings.json')};ck('reference binding IDs',sorted(bindings),sorted(refs))
for rid,b in bindings.items():
 r=refs[rid]
 if 'body' in b:
  ck('reference body exists '+rid,(D/b['body']).is_file());ck('reference body hash '+rid,sha(D/b['body']),b['sha256']);ck('declared reference hash '+rid,r.get('source_sha256'),b['sha256'])
 else:
  ck('only taxonomy external cache '+rid,rid.startswith('NCBITaxon:'));ck('selected taxonomy bytes '+rid,sha(D/b['selected_rows']),b['selected_rows_sha256']);ck('taxonomy reference full cache digest '+rid,r.get('source_sha256'),b['external_original_sha256'])
 if b.get('request_receipt'):ck('request receipt hash '+rid,sha(D/b['request_receipt']),b['receipt_sha256'])
locators=[]
for edge in edges:
 for v in edge['evidence']:
  rid=v['reference_id'];locator=v.get('source_locator');ck('evidence source_assertion only '+edge['id']+rid,'source_assertion' in v and 'quote' not in v)
  if rid.startswith('MetaCyc:'):
   frame=rid.split(':',1)[1];selected_nodes=trees[frame].xpath(locator);ck('native locator '+edge['id']+' '+locator,len(selected_nodes),1)
   locators.append({'edge_id':edge['id'],'reference_id':rid,'locator':locator,'resolved_xml':ET.tostring(selected_nodes[0],encoding='unicode')})
save('resolved-native-locators.json',locators)
# Names, roles and authority demand are computed independently from own objects/current snapshots.
sourceauth=json.loads((D/'inputs/baseline/data/identifier_authorities/sources.json').read_text())['terms']
ontoauth=json.loads((D/'inputs/baseline/data/identifier_authorities/ontology.json').read_text())['terms']
allauth=sourceauth|ontoauth
new_native=[];existing=[];fallback=[]
for frame in sorted(expected_nodes):
 n=nodes['MetaCyc:'+frame];obj=own[frame];ident=n['id']
 if ident in allauth:
  ck('existing exact canonical label '+ident,n['label'],allauth[ident]['label']);existing.append(ident)
 else:
  common=obj.findtext('common-name');name=' '.join(plain_label(common).split()) if common else frame
  ck('native own label '+ident,n['label'],name);new_native.append(ident)
  if not common:fallback.append(frame)
 if frame in activities:ck('activity category '+frame,n.get('category'),'molecular_activity');ck('activity participants '+frame,any(x['id']==ident for x in record['participants']))
 elif frame in members:ck('reaction category '+frame,n.get('category'),'molecular_activity')
 elif frame in locations:ck('membrane category '+frame,n.get('category'),'cellular_component')
 elif obj.tag=='Protein':ck('protein category '+frame,n.get('category'),'complex' if obj.get('class') != 'true' and (obj.findall('component') or any(x.get('frameid')=='Protein-Complexes' for x in obj.findall('parent/Protein'))) else 'protein')
 elif obj.tag=='Compound':ck('compound category '+frame,n.get('category'),'cofactor' if frame in cofactor_objects else 'chemical_entity' if obj.get('class')=='true' else 'small_molecule')
ck('existing native authority count',len(existing),17);ck('new native authority count',len(new_native),52);ck('fallback names',sorted(fallback),sorted(members+['CPLX-322','CPLX-481','PTAMSARC-MONOMER']))
public=[];native_assoc=[];taxon_rows=json.loads((D/'inputs/issuer/results/taxonomy-complete-selected-statements.json').read_text())
for slot in P.findall('species'):
 frame=slot[0].get('frameid');obj=own[frame];native_assoc.append(frame)
 links=[x.findtext('dblink-oid') for x in obj.findall('dblink') if x.findtext('dblink-db')=='NCBI-TAXONOMY-DB']
 if links:
  ck('one own taxon pointer '+frame,len(links),1);ident='NCBITaxon:'+links[0];public.append(ident)
 else:ck('unresolved native association identity',frame,'ORG-5913')
ck('seven native direct associations',len(native_assoc),7);ck('six direct issuing taxon declarations',sorted(n['id'] for n in record['taxa']),sorted(public));ck('range excluded from direct taxa','NCBITaxon:28890' not in nodes)
for ident in public:
 rows=taxon_rows[ident]
 labels=[x['value'] for x in rows if x['predicate']=='rdfs:label' and x['subject']==ident]
 ck('issuing canonical taxonomy label '+ident,labels,[nodes[ident]['label']])
 ranks=[x['object'] for x in rows if x['predicate']=='obo:ncbitaxon#has_rank' and x['subject']==ident]
 ck('issuing rank '+ident,ranks,['NCBITaxon:'+('genus' if ident in ['NCBITaxon:2207','NCBITaxon:2222'] else 'species')])
new_taxa=[x for x in public if x not in allauth];ck('missing taxa count',len(new_taxa),5)
demand=read('native-authority-demand.json');ck('demand covers exactly all declarations',sorted(x['id'] for x in demand),sorted(nodes))
for x in demand:ck('demand existing decision '+x['id'],x['existing'],x['id'] in allauth);ck('demand exact declared label '+x['id'],x['label'],nodes[x['id']]['label'])
save('authority-demand-independent.json',{'existing_native':existing,'missing_native':new_native,'missing_taxa':new_taxa,'fallbacks':fallback,'total_declared':len(nodes),'pending_authority_implementation':True})
# Complete exclusion/own-slot inventories, and real gene/product dispositions.
ledger=read('all269-node-and-context-dispositions.json');ck('269 disposition coverage',sorted(x['frame'] for x in ledger),sorted(own))
for x in ledger:ck('node disposition '+x['frame'],x['graph_disposition']=='graph node',x['frame'] in expected_nodes)
slots=read('all-selected-own-slot-design-dispositions.json');selected91={x['frame'] for x in ledger if x['selected']};ck('selected source object count',len(selected91),91)
expected_slots=[]
for f in selected91:
 counts=Counter()
 for pos,child in enumerate(own[f],1):counts[child.tag]+=1;expected_slots.append((f,child.tag,pos,counts[child.tag]))
ck('complete selected own-slot inventory',sorted((x['frame'],x['slot'],x['own_slot_position'],x['tag_occurrence']) for x in slots),sorted(expected_slots))
for x in slots:
 ck('own-slot disposition nonempty '+x['frame']+str(x['own_slot_position']),bool(x.get('disposition')))
 ck('own-slot source resolves '+x['frame']+str(x['own_slot_position']),len(trees[x['frame']].xpath(x['locator'])),1)
 ck('own-slot incident edges exist '+x['frame']+str(x['own_slot_position']),all(e in emap for e in x['direct_graph_edges']))
# 45 native activity occurrences, including explicit excluded other-organism contexts.
actual_activities=[(f,x.get('frameid')) for f in members for x in own[f].findall('enzymatic-reaction/Enzymatic-Reaction')]
a_ledger=read('all45-activity-dispositions.json');ck('45 occurrence inventory',sorted((x['reaction'],x['activity']) for x in a_ledger),sorted(actual_activities));ck('activity count',len(actual_activities),45)
for f,a in actual_activities:
 if a not in activities:ck('excluded activity not graph '+a,'MetaCyc:'+a not in nodes)
genes=read('gene-dispositions.json');ck('seven genes',len(genes),7)
for g in genes:
 f=g['gene'].split(':',1)[1];p=own[f].find('product')[0].get('frameid');ck('own gene product '+f,g['product'],'MetaCyc:'+p);ck('no invented gene node '+f,g['gene'] not in nodes)
 for eid in g['incident_edges']:ck('gene evidence on incident edge '+f+eid,g['evidence'] in emap[eid]['evidence']);ck('gene product incident '+f+eid,'MetaCyc:'+p in [emap[eid]['subject'],emap[eid]['object']])
ck('no forbidden encodes invented','encodes' not in {e['predicate'] for e in edges})
# Accepted primary statements copied faithfully; access/disposition stays on affected edges.
claims=read('all32-claim-to-design-dispositions.json');ck('32 source/primary claims',len(claims),32)
for c in claims:
 for eid in c['design_edges']:ck('claim disposition target exists '+c['id']+eid,eid in emap)
 if c['id'].startswith('P'):
  for eid in c['design_edges']:
   e=emap[eid];ck('primary statement incident '+c['id']+eid,any(v.get('source_assertion')==c['statement'] for v in e['evidence']));ck('primary reading level incident '+c['id']+eid,c['evidence_level'] in e['description'])
# Known limitations must be on all affected exact incident associations.
for eid in ['native-052','native-053','native-075']:ck('presumed Mtr qualification '+eid,'PRESUMED' in emap[eid]['description'] and 'not been identified' in emap[eid]['description'])
for eid in ['native-054','native-055','native-074']:ck('barkeri limitation '+eid,'incompletely characterized' in emap[eid]['description'])
for eid in ['native-067','native-068']:ck('construct limits '+eid,'BL21(DE3)' in emap[eid]['description'] and 'Hydroxocobalamin is not factor III' in emap[eid]['description'])
# Actual independent projections: full semantics and evidence, not only a count.
knodes=kgx_nodes([validated]);kedges=kgx_edges([validated]);ck('KGX declaration count',len(knodes),75);ck('KGX edge count',len(kedges),89)
for node in knodes:
 n=nodes[node.id]
 if n.get('category'):ck('KGX declared type '+node.id,node.category,EXPLICIT_CATEGORIES[n['category']])
for original,projected in zip(edges,kedges):
 ck('KGX subject '+original['id'],projected.subject,original['subject']);ck('KGX object '+original['id'],projected.object,original['object']);ck('KGX description '+original['id'],projected.description,original['description']);ck('KGX evidence '+original['id'],json.loads(projected.evidence),original['evidence'])
 expectedrefs=[refs[r] for r in sorted({v['reference_id'] for v in original['evidence']})];ck('KGX complete reference metadata '+original['id'],json.loads(projected.reference_metadata),expectedrefs)
 ck('KGX qualifiers '+original['id'],json.loads(projected.endpoint_qualifiers) if projected.endpoint_qualifiers else [],original.get('endpoint_qualifiers',[]))
page=_record_page(validated);(O/'independent/page.html').write_text(page);doc=html.fromstring(page)
svg_ids=doc.xpath('//a[@data-node-id]/@data-node-id');ck('graph all native nodes once',sorted(svg_ids),sorted('MetaCyc:'+x for x in expected_nodes))
for e in edges:ck('page complete edge description '+e['id'],e['description'] in doc.text_content())
write_kgx([validated],O/'independent/kgx')
save('checks.json',checks);summary={'checks':len(checks),'failures':sum(not x['pass'] for x in checks),'expected_edge_roles':dict(Counter(x['kind'] for x in expected)),'native_locator_occurrences':len(locators),'distinct_native_locators':len({(x['reference_id'],x['locator']) for x in locators}),'native_nodes':len(expected_nodes),'taxa':len(public),'edges':len(edges),'source_objects':len(own),'selected_own_slots':len(slots),'named_source_claims':len(claims),'authority_missing_native':len(new_native),'authority_missing_taxa':len(new_taxa),'actual_projection':True}
save('summary.json',summary);print(json.dumps(summary,sort_keys=True))
