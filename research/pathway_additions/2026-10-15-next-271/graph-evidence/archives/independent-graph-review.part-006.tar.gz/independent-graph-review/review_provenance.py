from pathlib import Path
from collections import Counter
import hashlib,json,subprocess
from lxml import etree as ET
O=Path(__file__).resolve().parent;D=O/'inputs/frozen-design';S=D/'inputs/issuer/inputs/source/originals/native';BASE=Path('/private/tmp/pathwaymech-next-271-20261015')
checks=[]
def ck(n,a,b=True):
 checks.append({'check':n,'pass':a==b,'actual':a,'expected':b})
 if a!=b:raise AssertionError(n+': '+repr(a)+' != '+repr(b))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=Path('/private/tmp/pathwaymech-next-271-source-preparation')
claimpath='results/claim-ledger.json';manifest=json.loads((source/'artifact-manifest.json').read_text());bound=next(x for x in manifest['files'] if x['path']==claimpath)
ck('accepted source manifest',sha(source/'artifact-manifest.json'),'06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5')
ck('accepted source claim hash',sha(source/claimpath),bound['sha256']);ck('copied source claim hash',sha(D/'inputs/issuer/inputs/source'/claimpath),bound['sha256'])
original={x['id']:x for x in json.loads((source/claimpath).read_text())};claims=json.loads((D/'results/all32-claim-to-design-dispositions.json').read_text())
ck('32 exact claim IDs',sorted(x['id'] for x in claims),sorted(original))
for x in claims:
 for key,val in original[x['id']].items():ck('accepted claim '+x['id']+' '+key,x[key],val)
# Existing baseline files are pinned actual Git blobs, not merely author claims.
result=subprocess.run(['git','-C',str(BASE),'ls-tree','-r','--full-tree','63ebb3b3e29ca1ed6472597104347d9fbc98f4a5'],capture_output=True,text=True,check=True)
blobs={line.split('\t',1)[1]:line.split()[2] for line in result.stdout.splitlines()};bindings=[]
for p in sorted((D/'inputs/baseline').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(D/'inputs/baseline').as_posix();raw=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
 ck('actual merged baseline Git blob '+rel,blob,blobs.get(rel));bindings.append({'path':rel,'git_blob':blob,'sha256':sha(p)})
# Recompute full native closure context dispositions from all originals.
own={}
for p in S.glob('META-*.xml'):
 top=ET.parse(str(p)).getroot();obj=next(x for x in top if x.tag!='metadata');own[obj.get('frameid')]=obj
components=[]
for f,obj in own.items():
 if obj.tag!='Protein':continue
 for n,slot in enumerate(obj.findall('component'),1):components.append((f,slot[0].get('frameid'),slot.findtext('coefficient'),n))
comp_ledger=json.loads((D/'results/all18-component-dispositions.json').read_text())
ck('all context component identities',sorted((x['complex'],x['component'],x['coefficient_literal']) for x in comp_ledger),sorted((a,b,c) for a,b,c,n in components));ck('18 component contexts',len(components),18)
regs={f:obj for f,obj in own.items() if obj.tag=='Regulation'};reg_ledger=json.loads((D/'results/all27-regulation-dispositions.json').read_text())
ck('all regulation contexts',sorted(x['frame'] for x in reg_ledger),sorted(regs));ck('27 regulation contexts',len(regs),27)
for x in reg_ledger:
 obj=regs[x['frame']]
 ck('regulator identity '+x['frame'],x['regulator'],[v.get('frameid') for v in obj.findall('regulator/*')]);ck('regulated entity identity '+x['frame'],x['regulated_entity'],[v.get('frameid') for v in obj.findall('regulated-entity/*')]);ck('mode identity '+x['frame'],x['mode'],obj.findtext('mode'));ck('physiology identity '+x['frame'],x['physiologically_relevant'],obj.findtext('physiologically-relevant'))
ledger=json.loads((D/'results/all269-node-and-context-dispositions.json').read_text())
for x in ledger:ck('269 object type '+x['frame'],x['type'],own[x['frame']].tag);ck('269 object class '+x['frame'],x['class'],own[x['frame']].get('class')=='true')
(O/'independent/provenance-checks.json').write_text(json.dumps(checks,indent=2)+'\n');(O/'independent/actual-baseline-git-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
summary={'checks':len(checks),'failures':sum(not x['pass'] for x in checks),'actual_baseline_files':len(bindings),'accepted_claims':len(claims),'context_component_occurrences':len(components),'context_regulations':len(regs),'source_manifest':sha(source/'artifact-manifest.json'),'source_claim_ledger_sha256':bound['sha256']}
(O/'independent/provenance-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
