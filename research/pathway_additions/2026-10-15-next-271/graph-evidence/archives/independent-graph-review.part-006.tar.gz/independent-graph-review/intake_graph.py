from pathlib import Path
import json,hashlib,os,shutil,stat,subprocess
OUT=Path(__file__).resolve().parent;AUTHOR=Path('/private/tmp/pathwaymech-next-271-graph-design');BASE=Path('/private/tmp/pathwaymech-next-271-20261015');CI=Path('/private/tmp/pathwaymech-next-271-ci')
for d in ['operations','temporary','independent','inputs/accepted-root','inputs/current-successor']: (OUT/d).mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'artifact-manifest.json':'c680126985a8447ac0ef5d9f3f6ea14512c55cb74e1a1cc3ca948c0dcf8e1882','HANDOFF.md':'505382b3d8fb837de6e644266fd0ea5fc3ac194ff9accb2173c9727f68634dc8','freeze-proof.json':'20d9e5413f12e6ce147897fa2534cec8bca8edf1f8f943893a21d59635ccc530'}
for f,h in expected.items():assert digest(AUTHOR/f)==h
manifest=json.loads((AUTHOR/'artifact-manifest.json').read_text());items=manifest['files'];actual=[]
for current,ds,fs in os.walk(AUTHOR):
 for d in ds:assert not (Path(current)/d).is_symlink()
 for f in fs:
  p=Path(current)/f;assert stat.S_ISREG(p.lstat().st_mode);actual.append(str(p.relative_to(AUTHOR)))
assert set(actual)=={i['path'] for i in items}|{'artifact-manifest.json','freeze-proof.json'}
for item in items:
 p=AUTHOR/item['path'];assert p.stat().st_size==item['bytes'];assert digest(p)==item['sha256']
shutil.copytree(AUTHOR,OUT/'inputs/frozen-design')
for rel in actual:assert digest(AUTHOR/rel)==digest(OUT/'inputs/frozen-design'/rel)
receipts=['root-intake-next271-independent-source-review.json','root-intake-next271-independent-issuer-review.json','root-intake-next271-merged-baseline-independent-rebind.json','root-intake-next271-activity-endpoint-implementation-review.json','root-intake-next271-graph-design.json']
rootbindings=[]
for name in receipts:
 p=CI/name;dest=OUT/'inputs/accepted-root'/name;shutil.copyfile(p,dest);rootbindings.append({'source':str(p),'copy':str(dest.relative_to(OUT)),'sha256':digest(p)})
successor=[]
for rel in ['src/pathwaymech/schema.py','docs/CAUSAL_GRAPHS.md','tests/test_graph_context.py']:
 p=BASE/rel;dest=OUT/'inputs/current-successor'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 copied=AUTHOR/'inputs/endpoint-successor'/rel
 successor.append({'path':rel,'current_sha256':digest(p),'design_successor_sha256':digest(copied),'same':digest(p)==digest(copied)})
assert successor[0]['current_sha256']=='b3f0c28ded2e0e665c15cf0a0e4a8e19ffc1d9bdfd397aa8383ad6a13baf4214';assert all(x['same'] for x in successor)
identity={}
for k,args in [('head',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),('status',['status','--porcelain=v1','--untracked-files=all'])]:
 p=subprocess.run(['git','-C',str(BASE),*args],text=True,capture_output=True);identity[k]={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
result={'source_owner':str(AUTHOR),'author_manifest_sha256':expected['artifact-manifest.json'],'listed_files':len(items),'physical_files':len(actual),'listed_bytes':sum(x['bytes'] for x in items),'complete_inventory_hidden_ignored_included':True,'every_original_and_copy_hash_verified':True,'successor':successor,'root_intake_bindings':rootbindings,'actual_git':identity,'limits':'Historical nested archive containers copied and hash-verified as opaque bytes; no new archive/source-exhaustion claim.'}
(OUT/'independent/intake.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'intake':'PASS','listed':len(items),'physical':len(actual),'copied':len(actual),'successor_matches':all(x['same'] for x in successor)}))
