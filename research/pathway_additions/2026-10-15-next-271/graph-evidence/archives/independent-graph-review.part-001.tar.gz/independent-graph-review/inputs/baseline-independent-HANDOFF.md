# Frozen next271 actual-merged-baseline rebind

**Qualified baseline readiness acceptance; no actionable finding or issue requested.** Complete report: `REVIEW.md`; result: `RESULT.json`. This clears only actual merged-corpus/contract/current-authority readiness, not source science, issuer acceptance, a fixed graph, authority implementation or final record.

Actual baseline: `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e`, direct parent `e8ae5e445d3288717c31d3012611e226fd5cca34`. All267 maintained records are byte-bound and physically enumerated including hidden/ignored YAML; all266 prior records remain exact. Candidate root/six-member declarations remain uncurated. Newly landed270, PWY0-1312 and WP5019 are distinct at their reviewed boundaries.

**Coverage changes:** fixed26 core is now11 existing/15 missing, from9/17. CoM and Me-CoM are the new core owners. Provisional91 issuer-native inventory is17 existing/74 missing, from10/81; seven owners arrived with270. NCBITaxon2208 is separately available. None of these denominators fixes the future graph or accepts new mappings. See exact labels, types, permitted sections/categories, source owners and native taxon pointers in the results.

15,035 successful checks (12,993 main +2,042 final). Frozen discovery/preflight/source complete inventories verified, source1706listed/1708physical/239,304,575listedbytes and manifest06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5 rechecked. One reviewer JSON serialization failure is retained with its successor; no product changes. All sessions terminal.

Fresh search:109 named patterns against complete corpus and hidden/ignored-inclusive ordinary worktree text;735 matched ordinary paths. Fresh19new270 tar.gz archives:7,138outer files/548,591,504decoded bytes,6,586text members searched with12candidate/member patterns,417nested containers opaque.297matched members/63distinct payloads, with8selected full decision texts read. Prior76archives and116gzip search conclusions reused only after unchanged physical/Git digest checks and only for named12patterns. No global novelty, historical absence or exhaustion claim.

Reviewer Codex `/root/next271_independent_preflight` did not author candidate source/issuer preparations or next270 product. Earlier independent reviews are explicitly reused at pinned scope. All writes stayed in this owner; no maintained/Git/GitHub/runtime/source-owner change, helper or duplicate full suite. Current271worktree remains clean. Root owns later gates and integration.

REVIEW SHA256 `6b3fd58e00f4655d6c6a97d5c23c7fd8322d0c7a4e9078558026e941dfb4ef4c`; RESULT SHA256 `faff2e068e421e7203718d3d51cb9afbcaf8ee2703841b4bb23ae0aac1ee469c`. `artifact-manifest.json` and `freeze-proof.json` define complete physical inventory, including hidden/ignored files, with only those two self-exclusions. Treat this owner as immutable.
