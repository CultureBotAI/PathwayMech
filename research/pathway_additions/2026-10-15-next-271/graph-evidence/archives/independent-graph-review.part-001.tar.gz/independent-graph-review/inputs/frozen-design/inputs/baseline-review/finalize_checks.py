from pathlib import Path
import json,hashlib,subprocess,datetime,html,re
from collections import Counter
R=Path('/private/tmp/pathwaymech-next-271-20261015');O=Path('/private/tmp/pathwaymech-next-271-merged-baseline-independent-rebind');S=Path('/private/tmp/pathwaymech-next-271-source-preparation');checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ok(v,n):checks.append({'check':n,'passed':bool(v)});assert v,n

def load(p):return json.loads(p.read_text())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
head=load(O/'results/actual-git-tree.json');corpus=load(O/'results/all267-records.json');physical={p.relative_to(R).as_posix() for p in (R/'data/pathways').rglob('*') if p.is_file() and p.suffix.lower() in {'.yaml','.yml'}}
ok(physical=={r['path'] for r in corpus},'physical hidden ignored YAML set equals267 Git corpus');ok(len({r['id'] for r in corpus})==267,'267 unique record identities')
for row in load(O/'results/contracts.json')+corpus:
 b=(R/row['path']).read_bytes();ok(sha(b)==row['sha256'],'final record/contract unchanged '+row['path'])
for p in ['data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json','src/pathwaymech/biocyc_methanogenesis.py','src/pathwaymech/biocyc_phenylacetate.py','src/pathwaymech/biocyc_glutaryl.py']:
 b=(R/p).read_bytes();ok(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==head[p]['oid'],'authority/role owner exact Git '+p)
 q=O/'inputs/current'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
rows=load(O/'results/provisional91-authority-coverage.json');native={r['frame']:r for r in load(S/'results/native-object-inventory.json')}
for row in rows:
 if not row['existing']:continue
 names=[html.unescape(re.sub('<[^>]+>','',s)) for s in row['native_direct_names']];ok(row['term']['label'] in names or any(s in row['term']['synonyms'] for s in names),'current source label accepted among native names '+row['id'])
 if row['typed_node_roles']:
  expected='protein' if row['native_type']=='Protein' else 'cellular_component' if row['native_type']=='cco' else 'small_molecule'
  ok(expected in row['typed_node_roles'][1],'native type compatible existing role '+row['id'])
core=load(O/'results/core26-authority-coverage.json');ok(sum(r['existing'] for r in core)==11 and sum(not r['existing'] for r in core)==15,'final11/15 core coverage');ok(sum(r['existing'] for r in rows)==17 and sum(not r['existing'] for r in rows)==74,'final17/74 provisional native coverage');ok(sum(r['existed_at_old_preflight'] for r in rows)==10,'provisional91 had10 preexisting native terms')
root=(S/'originals/native/META-METH-ACETATE-PWY.xml').read_bytes();ok(sha(root)=='c07ebef86298854af9494a5309ee9453fb9a014b4d1dd5c016278648cb90b5ec','candidate root exact previously accepted native original')
eq=load(S/'results/member-equations.json');mtr=next(r for r in eq if r['frame']=='MTRMBARK-RXN');ok(sum(len(e['left'])+len(e['right']) for e in eq)==29,'29 native acetate equation occurrences');ok(all(not z['compartment'] for e in eq for s in ['left','right'] for z in e[s]),'all29 acetate locations unspecified');ok(len(mtr['left'])+len(mtr['right'])==4 and mtr['selected_direction']=='R2L','acetate Mtr exact4 unlocated occurrences and reverse selection')
a=load(R/'data/identifier_authorities/sources.json');newmtr=a['sources'][a['terms']['MetaCyc:2.1.1.86-RXN']['source']]['native_methanogenesis']['projection'];ok(sum(len(v) for v in newmtr['sides'].values())==6,'actual270 Mtr6 located occurrences');save('results/mtr-boundary-comparison.json',{'acetate':mtr,'actual270':newmtr['sides'],'disposition':'Distinct native carrier/transport representations. No THMPT or Na transport imported into acetate sarcinapterin equation.'})
outer=load(O/'results/new270-outer-archive-search.json');unique={}
for row in outer['matches']:unique.setdefault(row['sha256'],row)
disp=[]
for row in unique.values():
 p=row['path'];a=row['archive'];key=a+'::'+p
 if p.endswith('.xml') or 'native-' in p and p.endswith(('.json','.txt')) or '/sources.json' in p or 'new-source-snapshot' in p:reason='Full source definition, biochemical backlink/context, or mechanically retained native projection; not a maintained candidate record or independent term owner.'
 elif 'kurth' in p.lower() or 'web-search' in p:reason='General aceticlastic background in retained H2/CO2 source reading; not a separate accepted acetate route or a rejection.'
 elif 'HANDOFF' in p or 'candidate-comparison' in p or 'unresolved-prerequisites' in p or 'interpretation.json' in p or p.endswith('REVIEW.md'):reason='Selected full decision text read: acetate is an alternative/distinct candidate with open preparation, not the maintained H2/CO2 route or a permanently rejected candidate.'
 else:reason='Recorded candidate comparison/search or acquisition/retention/code bookkeeping. Context hit retained; no maintained curation follows. Original source/decision documents separately inspected.'
 disp.append({'archive':a,'path':p,'sha256':row['sha256'],'literal_matches':row['literal_matches'],'disposition':reason})
save('results/new270-prior-mention-dispositions.json',disp)
# All selected full-text excerpts are verified back to the freshly decoded outer-member inventories.
known={(x['archive'].split('/')[-1],x['path']):x for x in outer['members']}
for p in (O/'inputs/new270-selected-text').rglob('*'):
 if p.is_file():
  rel=p.relative_to(O/'inputs/new270-selected-text');row=known[(rel.parts[0],'/'.join(rel.parts[1:]))];ok(sha(p.read_bytes())==row['sha256'],'selected full outer text exact '+str(rel))
source_manifest=S/'artifact-manifest.json';ok(sha(source_manifest.read_bytes())=='06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5','source manifest unchanged at finish')
for row in load(source_manifest)['files']:
 b=(S/row['path']).read_bytes();ok(len(b)==row['bytes'] and sha(b)==row['sha256'],'final immutable source '+row['path'])
ok(subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()=='63ebb3b3e29ca1ed6472597104347d9fbc98f4a5','actual merged HEAD unchanged');ok(not subprocess.check_output(['git','-C',str(R),'status','--porcelain=v1','--untracked-files=all']),'final clean tracked/nonignored worktree')
summary={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'all_passed':True,'new270_distinct_mention_payloads':len(disp),'selected_outer_texts':len([p for p in (O/'inputs/new270-selected-text').rglob('*') if p.is_file()]),'physical_corpus_ignores_independent':True}
save('results/final-checks.json',{'summary':summary,'checks':checks});print(json.dumps(summary,indent=2))
