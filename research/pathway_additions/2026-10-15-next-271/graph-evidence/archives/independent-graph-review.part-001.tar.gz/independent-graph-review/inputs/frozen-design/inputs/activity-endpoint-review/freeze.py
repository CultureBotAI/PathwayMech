from pathlib import Path
import datetime, hashlib, json, os, stat
root=Path(__file__).resolve().parent
excluded={'manifest.json','freeze.json'}
assert not any((root/n).exists() for n in excluded),'Refuse overwriting a frozen owner'
files=[];dirs=[]
for current,dirnames,filenames in os.walk(root,followlinks=False):
 for dirname in dirnames:
  p=Path(current)/dirname
  assert not p.is_symlink(),str(p)
  dirs.append(p.relative_to(root).as_posix())
 for name in filenames:
  p=Path(current)/name
  assert stat.S_ISREG(p.lstat().st_mode),str(p)
  rel=p.relative_to(root).as_posix()
  if rel not in excluded:
   raw=p.read_bytes();files.append({'path':rel,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
files.sort(key=lambda x:x['path'])
manifest={'owner':str(root),'inventory_method':'os.walk, no ignore filtering; all hidden/ignored files included; regular files only; no symlinks','excluded_self_metadata':sorted(excluded),'listed_files':len(files),'listed_bytes':sum(f['bytes'] for f in files),'directories':sorted(dirs),'files':files}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
def digest(name):return hashlib.sha256((root/name).read_bytes()).hexdigest()
freeze={'owner':str(root),'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':digest('manifest.json'),'handoff_sha256':digest('HANDOFF.md'),'review_sha256':digest('REVIEW.md'),'result_sha256':digest('RESULT.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(f['bytes'] for f in files),'physical_file_paths':sorted([f['path'] for f in files]+list(excluded)),'metadata_self_exclusion':'manifest lists all substantive files; freeze binds manifest; manifest and freeze are the two additional physical files. Freeze cannot hash itself.','nested_container_limit':'No archive containers or symlinks in owner; external authority originals are hash-bound, not copied in full.'}
(root/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
actual=sorted(str(p.relative_to(root)) for p in root.rglob('*') if p.is_file())
assert actual==freeze['physical_file_paths']
for f in files:
 p=root/f['path'];assert p.stat().st_size==f['bytes'];assert digest(f['path'])==f['sha256']
assert digest('manifest.json')==freeze['manifest_sha256']
print(json.dumps({k:freeze[k] for k in ['listed_files','physical_files','listed_bytes','manifest_sha256','handoff_sha256','review_sha256','result_sha256']} | {'freeze_sha256':digest('freeze.json'),'fresh_complete_verification':'PASS'},indent=2))
