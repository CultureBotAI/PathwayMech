"""Independent, scratch-only endpoint contract probe. No biological claims from synthetic fixtures."""
from pathlib import Path
from copy import deepcopy
from dataclasses import asdict
import hashlib, importlib.util, json, os, sys
import xml.etree.ElementTree as ET
import yaml
from lxml import html
ROOT=Path('/private/tmp/pathwaymech-next-271-20261015')
OUT=Path(__file__).resolve().parent
import pathwaymech.schema as baseline
import pathwaymech.identifiers as identifiers
from pathwaymech.strict import validator, TARGET_CLASS
from pathwaymech.kgx import kgx_nodes, kgx_edges, write_kgx
from pathwaymech.cli import _record_page
checks=[]
def check(name, actual, expected=True):
    okay=actual==expected
    checks.append({'name':name,'pass':okay,'actual':actual,'expected':expected})
    if not okay: raise AssertionError(name+': '+repr(actual)+' != '+repr(expected))
def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def validation(module,record):
    try: module.validate_record(record);return []
    except baseline.ValidationError as error:return error.errors
    except module.ValidationError as error:return error.errors

def id_errors(record):
    # Only input enumeration/YAML load are injected. Policy, source ownership,
    # authority originals, and the entire identifier consumer are unchanged.
    old_paths,old_load=identifiers.pathway_files,identifiers.load_yaml_file
    path=ROOT/'data/pathways/methanogenesis-from-h2-and-co2.yaml'
    identifiers.pathway_files=lambda _: [path]
    identifiers.load_yaml_file=lambda _:deepcopy(record)
    try:return identifiers.identifier_errors(ROOT)
    finally:identifiers.pathway_files,identifiers.load_yaml_file=old_paths,old_load

original=yaml.safe_load((ROOT/'data/pathways/methanogenesis-from-h2-and-co2.yaml').read_text())
activity=next(deepcopy(n) for n in original['participants'] if n['id']=='MetaCyc:ENZRXN-702')
chemical=next(deepcopy(n) for n in original['participants'] if n['category']=='small_molecule')
reaction=deepcopy(original['reactions'][0])
record={
'id':original['id'],'label':original['label'],
'description':'Synthetic validator fixture using existing authority identities; not a biological assertion about these endpoints.',
'pathway_type':original['pathway_type'],'taxa':[],
'participants':[activity,chemical],'reactions':[reaction],
'mechanistic_edges':[{'id':'probe','subject':reaction['id'],'predicate':'has_input','object':chemical['id'],
'description':'Synthetic direction-only test; no experimental or substrate claim.',
'evidence':[{'reference_id':'gomodel:test','source_assertion':'Synthetic validator fixture, not biological evidence.','source_locator':'reproduce.py / record'}]}],
'references':[{'id':'gomodel:test','title':'Synthetic endpoint validation fixture; not a biological source'}]}
checker=validator()
check('baseline control Python',validation(baseline,record),[])
check('baseline control closed LinkML',len(checker.validate(record,TARGET_CLASS).results),0)
check('baseline control production identifier gate',id_errors(record),[])
save('fixtures/current-authority-control.json',record)
blocked=deepcopy(record);blocked['mechanistic_edges'][0]['subject']=activity['id']
check('activity fixture closed LinkML',len(checker.validate(blocked,TARGET_CLASS).results),0)
check('activity fixture production identifier gate',id_errors(blocked),[])
errors=validation(baseline,blocked)
check('activity has_input rejected exactly once',len(errors),1)
check('activity rejection is endpoint rule','has_input must point from an activity or pathway to a participant' in errors[0])
save('fixtures/current-authority-blocked-input.json',blocked)
output=deepcopy(blocked);output['mechanistic_edges'][0]['predicate']='has_output'
check('activity has_output rejected exactly once',len(validation(baseline,output)),1)
check('has_output closed LinkML',len(checker.validate(output,TARGET_CLASS).results),0)
save('fixtures/current-authority-blocked-output.json',output)
moved=deepcopy(blocked);moved['participants']=[n for n in moved['participants'] if n['id']!=activity['id']];moved['reactions'].append(activity)
check('misplacement superficially passes Python',validation(baseline,moved),[])
move_errors=id_errors(moved)
check('misplacement rejected by native identifier role',len(move_errors)==1 and 'ENTITY_TYPE_MISMATCH' in move_errors[0] and 'requires participants' in move_errors[0])
save('results/baseline-reproduction.json',{'input_errors':errors,'output_errors':validation(baseline,output),'moved_activity_identifier_errors':move_errors,'node':activity,'chemical':chemical,'reaction':reaction})

# Counterexample to category-map-only admission: conflicting declarations are
# not rejected by either shape validator and category map is last-write-wins.
contradiction=deepcopy(blocked)
contradiction['participants'].insert(0,{**activity,'category':'small_molecule'})
check('contradictory declaration shape is accepted by closed LinkML',len(checker.validate(contradiction,TARGET_CLASS).results),0)
categories={n['id']:n.get('category') for field in ['participants','reactions'] for n in contradiction[field]}
check('naive last-write category map admits contradictory activity',categories[activity['id']]=='molecular_activity')

# Experimental proof only: source copy with a narrow, ambiguity-resistant set.
# Does not touch maintained schema.py, authority policy, enums, or shared processes.
code=(ROOT/'src/pathwaymech/schema.py').read_text()
needle='        qualified_participants={\n'
assert code.count(needle)==1
code=code.replace(needle,'''        activity_participants={
            identifier
            for identifier in participants - reactions - taxa - {record.get("id")}
            if all(
                node.get("category") == "molecular_activity"
                for node in record["participants"]
                if isinstance(node, dict) and node.get("id") == identifier
            )
        },
'''+needle)
needle='    qualified_participants: set[str] | None = None,\n'
assert code.count(needle)==1
code=code.replace(needle,needle+'    activity_participants: set[str] | None = None,\n')
needle='                categories=categories or {},\n'
assert code.count(needle)==1
code=code.replace(needle,needle+'                activity_participants=activity_participants or set(),\n')
needle='    categories: dict[str, str | None],\n'
assert code.count(needle)==1
code=code.replace(needle,needle+'    activity_participants: set[str] | None = None,\n')
needle='''    if predicate in {"has_input", "has_output"} and (
        subject not in processes or obj not in participant_ids
    ):'''
assert code.count(needle)==1
code=code.replace(needle,'''    if predicate in {"has_input", "has_output"} and (
        subject not in processes | (activity_participants or set()) or obj not in participant_ids
    ):''')
candidate_path=OUT/'candidate/schema.py';candidate_path.write_text(code)
spec=importlib.util.spec_from_file_location('activity_endpoint_candidate',candidate_path)
candidate=importlib.util.module_from_spec(spec);sys.modules[spec.name]=candidate;spec.loader.exec_module(candidate)
cases=[]
def case(name,record,accept):
    errs=validation(candidate,record)
    case_result={'name':name,'expected_accept':accept,'actual_accept':not errs,'errors':errs}
    cases.append(case_result);check(name,not errs,accept)
for predicate in ['has_input','has_output']:
    fixture=deepcopy(blocked);fixture['mechanistic_edges'][0]['predicate']=predicate
    case(predicate+' explicit participant activity',fixture,True)
    check(predicate+' candidate still identifier-valid',id_errors(fixture),[])
    for category in [None,'small_molecule','chemical_entity','cofactor','protein','complex','gene','dna','rna','polymer','lipid','cellular_component','biological_process','pathway']:
        changed=deepcopy(fixture)
        if category is None:changed['participants'][0].pop('category')
        else:changed['participants'][0]['category']=category
        case(predicate+' rejects nonactivity '+str(category),changed,False)
    for kind in [None,'small_molecule','protein','complex','gene','biological_process']:
        for order in ['before','after']:
            changed=deepcopy(fixture);duplicate=deepcopy(activity)
            if kind is None:duplicate.pop('category')
            else:duplicate['category']=kind
            changed['participants'].insert(0 if order=='before' else len(changed['participants']),duplicate)
            case(predicate+' rejects contradictory duplicate '+str(kind)+' '+order,changed,False)
    duplicate=deepcopy(fixture);duplicate['participants'].append(deepcopy(activity))
    case(predicate+' consistent activity duplicate allowed',duplicate,True)
    taxon_collision=deepcopy(fixture);taxon_collision['taxa'].append(deepcopy(activity))
    case(predicate+' rejects newly admitted participant/taxon collision',taxon_collision,False)
    for section in ['reactions','record']:
        collision=deepcopy(fixture)
        if section=='record':collision['id']=activity['id']
        else:collision['reactions'].append(deepcopy(activity))
        case(predicate+' preexisting '+section+' process behavior unchanged',collision,True)
        check(predicate+' '+section+' collision accepted before patch',validation(baseline,collision),[])
    for subject in ['root','reaction']:
        changed=deepcopy(fixture);changed['mechanistic_edges'][0]['subject']=changed['id'] if subject=='root' else reaction['id']
        case(predicate+' retains '+subject,changed,True)
    for target in ['root','reaction','taxon','missing']:
        changed=deepcopy(fixture)
        if target=='taxon':changed['taxa']=[{'id':'NCBITaxon:2','label':'Bacteria'}]
        changed['mechanistic_edges'][0]['object']={'root':changed['id'],'reaction':reaction['id'],'taxon':'NCBITaxon:2','missing':'MetaCyc:missing'}[target]
        case(predicate+' rejects nonparticipant object '+target,changed,False)
    missing=deepcopy(fixture);missing['mechanistic_edges'][0]['subject']='MetaCyc:missing'
    case(predicate+' missing subject',missing,False)
for predicate in ['consumes','produces','occurs_in','located_in','causally_upstream_of','provides_input_for']:
    changed=deepcopy(blocked);edge=changed['mechanistic_edges'][0];edge['predicate']=predicate
    if predicate=='consumes':edge['subject'],edge['object']=chemical['id'],activity['id']
    if predicate in ['occurs_in','located_in']:
        changed['participants'].append({'id':'GO:0005737','label':'cytoplasm','category':'cellular_component'});edge['object']='GO:0005737'
    if predicate in ['causally_upstream_of','provides_input_for']:edge['object']=reaction['id']
    case('unchanged rejection '+predicate,changed,False)
    check('same errors '+predicate,validation(candidate,changed),validation(baseline,changed))
save('results/candidate-cases.json',cases)

# Source-scoped fixture for all six exact Ack alternatives, kept distinct from
# the canonical reaction equation. This is not a complete pathway draft or an
# approved new identifier authority record.
SRC=OUT/'inputs/source'
def xml(frame):return ET.parse(SRC/('META-'+frame+'.xml')).getroot()
def direct(frame,tag):return xml(frame).find(tag)
ack=direct('ENZRXN-481','Enzymatic-Reaction');rxn=direct('ACETATEKIN-RXN','Reaction')
pairs=[(x.find('substrate/Compound').get('frameid'),x.find('alternate/Compound').get('frameid')) for x in ack.findall('alternative-substrate')]
check('six exact Ack alternatives',pairs,[('ATP','TTP'),('ATP','ITP'),('ATP','UTP'),('ATP','GTP'),('ATP','CTP'),('ACET','PROPIONATE')])
left=[x[0].get('frameid') for x in rxn.findall('left')];right=[x[0].get('frameid') for x in rxn.findall('right')]
check('canonical source left',left,['ATP','ACET']);check('canonical source right',right,['ADP','ACETYL-P'])
materials=sorted(set(left+right+[pair[1] for pair in pairs]))
source_record={'id':'MetaCyc:METH-ACETATE-PWY','label':'methanogenesis from acetate','description':'Source-scoped endpoint fixture for Ack alternatives only, not a curated pathway draft. No new authority acceptance is claimed.','pathway_type':'methanogenesis','taxa':[],
'participants':[{'id':'MetaCyc:'+x,'label':''.join(direct(x,'Compound').find('common-name').itertext()),'category':'small_molecule'} for x in materials]+[{'id':'MetaCyc:ENZRXN-481','label':ack.findtext('common-name'),'category':'molecular_activity'}],
'reactions':[{'id':'MetaCyc:ACETATEKIN-RXN','label':rxn.findtext('common-name') or 'ACETATEKIN-RXN','category':'molecular_activity','direction':'reversible'}],
'mechanistic_edges':[],'references':[]}
for frame in ['ENZRXN-481','ACETATEKIN-RXN']:
    source_record['references'].append({'id':'MetaCyc:'+frame,'title':'MetaCyc native '+frame,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+frame,'source_version':'27.0','source_sha256':hashlib.sha256((SRC/('META-'+frame+'.xml')).read_bytes()).hexdigest()})
for n,(base,alt) in enumerate(pairs,1):
    desc=f'Source-qualified alternative substrate: {alt} can replace {base} for native acetate-kinase activity ENZRXN-481 (enzyme CPLX-441). Alternatives are not joint requirements; this does not change the canonical ACETATEKIN-RXN equation or establish broad in vivo specificity. Native EV-EXP is source metadata, not independent primary verification.'
    source_record['mechanistic_edges'].append({'id':'alternative-'+str(n),'subject':'MetaCyc:ENZRXN-481','predicate':'has_input','object':'MetaCyc:'+alt,'description':desc,'evidence':[{'reference_id':'MetaCyc:ENZRXN-481','source_assertion':f'Native ENZRXN-481 lists {alt} as an alternative substrate for {base}; its enzyme is CPLX-441. These are source-qualified alternatives, not simultaneous substrates or a replacement of the canonical reaction equation.','source_locator':f"/ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-481']/alternative-substrate[{n}]"}]})
for side,frames in [('left',left),('right',right)]:
    for n,frame in enumerate(frames,1):
        source_record['mechanistic_edges'].append({'id':side+'-'+str(n),'subject':'MetaCyc:'+frame if side=='left' else 'MetaCyc:ACETATEKIN-RXN','predicate':'consumes' if side=='left' else 'produces','object':'MetaCyc:ACETATEKIN-RXN' if side=='left' else 'MetaCyc:'+frame,'description':'Canonical source equation as written; source direction REVERSIBLE. Alternative activity substrates are separate claims.','evidence':[{'reference_id':'MetaCyc:ACETATEKIN-RXN','source_assertion':f'Native ACETATEKIN-RXN lists {frame} on its {side} side; reaction-direction is REVERSIBLE.','source_locator':f"/ptools-xml/Reaction[@frameid='ACETATEKIN-RXN']/{side}[{n}]"}]})
check('source fixture closed LinkML',len(checker.validate(source_record,TARGET_CLASS).results),0)
source_errors=validation(baseline,source_record)
check('source fixture fails only six alternatives',len(source_errors)==6 and all('has_input must point' in e for e in source_errors))
check('source fixture proposed narrow validator',validation(candidate,source_record),[])
save('fixtures/source-ack-six-alternatives.json',source_record)
save('results/source-ack-scope.json',{'pairs':pairs,'canonical_left':left,'canonical_right':right,'current_python_errors':source_errors,'authority_scope':'Pending native Ack and compound issuer additions not evaluated; no identifier-gate pass claimed for this fixture.'})

# Check literal endpoints, type, descriptions and all evidence in actual KGX and
# rendered HTML. Uses accepted candidate PathwayRecord, no renderer modifications.
for name,fixture in [('synthetic-input',blocked),('synthetic-output',output),('source-ack-six',source_record)]:
    checked=candidate.validate_record(fixture)
    nodes={node.id:node for node in kgx_nodes([checked])}
    activity_id=fixture['mechanistic_edges'][0]['subject']
    check(name+' KGX activity type',nodes[activity_id].category,'biolink:MolecularActivity')
    edges=kgx_edges([checked])
    check(name+' KGX edge count',len(edges),len(fixture['mechanistic_edges']))
    for current,expected in zip(edges,fixture['mechanistic_edges']):
        check(name+' '+expected['id']+' KGX subject',current.subject,expected['subject'])
        check(name+' '+expected['id']+' KGX object',current.object,expected['object'])
        check(name+' '+expected['id']+' KGX evidence',json.loads(current.evidence),expected['evidence'])
        check(name+' '+expected['id']+' KGX description',current.description,expected['description'])
        expectedrefs=[r for r in fixture['references'] if r['id'] in {e['reference_id'] for e in expected['evidence']}]
        check(name+' '+expected['id']+' KGX reference metadata',json.loads(current.reference_metadata),expectedrefs)
        if expected['predicate'] in ['has_input','has_output']:
            check(name+' '+expected['id']+' RO predicate',current.predicate,'RO:0002233' if expected['predicate']=='has_input' else 'RO:0002234')
    page=_record_page(checked);(OUT/'results'/f'{name}.html').write_text(page)
    document=html.fromstring(page)
    graphics=document.xpath('//a[@data-node-id=$identifier]',identifier=activity_id)
    check(name+' activity rendered once',len(graphics),1)
    check(name+' renderer explicit activity label','Declared type: molecular_activity' in graphics[0].get('aria-label',''))
    check(name+' renderer fallback shape remains participant',graphics[0].get('data-kind'),'participant')
    for edge in fixture['mechanistic_edges']:
        check(name+' '+edge['id']+' description in page',edge['description'] in document.text_content())
    write_kgx([checked],OUT/'results'/name)

save('results/checks.json',checks)
save('results/probe-summary.json',{'checks':len(checks),'failed':sum(not x['pass'] for x in checks),'candidate_cases':len(cases),'finding':'Current Python rejects participant molecular_activity subjects for has_input/has_output despite authority requiring that placement and closed LinkML accepting it.','candidate_is_experimental':True})
print(json.dumps({'checks':len(checks),'failures':sum(not x['pass'] for x in checks),'candidate_cases':len(cases),'status':'PASS'},sort_keys=True))
