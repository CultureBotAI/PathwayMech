# Reproduce the frozen design projection

No acquisition, installation, cache download or maintained checkout is needed. Use the existing verified runtime. From this packet's root:

```bash
PYTHONDONTWRITEBYTECODE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/design.py
PYTHONDONTWRITEBYTECODE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/probe.py
PYTHONDONTWRITEBYTECODE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/coverage.py
PYTHONDONTWRITEBYTECODE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/page-coverage.py
```

Run those commands only in a new copied owner, never in this frozen original. Scripts derive the prospective YAML, node/edge/authority/claim/slot/reference ledgers and static page/KGX projections from copied originals. `design.py` uses the exact historical baseline authority snapshots for existing-owner coverage; `probe.py` uses the distinct released endpoint successor contract. Baseline copies remain unchanged.

`initialize.py` and `intake-successors.py` document the original intake and actual Git/source bindings. They depend on the historical scratch paths and are not necessary to reproduce the design after its inputs are copied. Do not rerun them into an existing owner. Their retained receipts supply the acquisition/copy scope; the root endpoint and issuer-review receipts are external acceptance evidence, not self-authored acceptance.

The complete taxonomy SQLite file is deliberately external. The design uses retained complete selected issuing statements and does not query or rehash the 14 GB cache. Existing upstream archive files inside copied predecessor inputs remain opaque for this graph task. No runtime is installed or repaired.
