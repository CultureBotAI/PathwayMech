# Activity endpoint review handoff

Independent reviewer `/root/next271_independent_preflight` confirms one P2 functional finding, AE-1 (parent issue #630): correctly placed native molecular activities cannot be subjects of `has_input`/`has_output` under current Python validation, despite closed LinkML, authority placement and documented semantics.

Bound baseline: HEAD `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e` in `/private/tmp/pathwaymech-next-271-20261015`. No maintained files, Git, GitHub or runtime changed by reviewer.

Read `REVIEW.md`, `RESULT.json`, `results/baseline-reproduction.json`, then compare `candidate/experimental.patch` or `candidate/schema.py` with the parent's implementation. Experimental candidate only admits participant-only IDs whose every same-ID declaration explicitly says molecular_activity, solely for has_input/has_output; legacy process behavior remains unchanged. It is not an independently approved product patch.

Fresh verification: 208 passed assertions / 82 candidate cases; full valid synthetic fixture passes strict LinkML and actual current native-identifier consumer before failing the Python endpoint rule. All six source-qualified Ack alternatives succeed under the candidate while canonical ATP + ACET ⇄ ADP + ACETYL-P is retained. Actual HTML/KGX outputs retain evidence and type. No full suite or final graph/science/issuer approval is claimed. Source-scoped Ack fixture has pending authorities explicitly outside this check.

Commands, receipts, inputs, failures and outputs are preserved. Complete physical inventory including hidden/ignored files is `manifest.json`; `freeze.json` binds it and reports the two deliberately self-excluded metadata files. This owner is frozen; parent owns implementation, issue disposition, integration tests and final acceptance.
