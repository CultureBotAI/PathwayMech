# Native graph design for methanogenesis from acetate

This is a complete, bounded source graph proposal for **MetaCyc:METH-ACETATE-PWY**, ready for independent graph review. It is not a maintained record, an authority implementation, an exact-alias decision or a new whole-route experimental claim. The prospective schema-shaped YAML is a projection fixture for review and reproduction.

The proposal has **69 native graphical nodes, six issuing NCBI taxon declarations and 89 edges**. It preserves all six source members, five predecessor links, 29 material occurrences and 19 equation material identities. All six reaction-own directions remain reversible; the root separately selects four left-to-right and two right-to-left orientations. All 29 material occurrences remain unlocated. The boundary ends at methyl-CoM, with no seventh Acs member, methane-completion step, borrowed sodium transport or borrowed membrane side.

## Inputs, provenance and independence

The exact actual merged baseline is `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e`, containing 267 records. The independent merged-baseline review is accepted at its finite novelty/contract/authority-coverage scope. All 133 baseline files copied here matched their actual Git blobs. Its complete 362-file review packet and the complete 881-file issuer preparation were freshly inventoried, hashed and copied. No live worktree is needed to reproduce the design.

The accepted native/source preparation has manifest `06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5`; its independent review has manifest `d18d6d594d87721ff4e4e53b69a1fecf166b645357d5c571c2604e95e2f9cd2d`. This design reuses that accepted full native closure and the 32 bounded source/primary claims; it does not claim a new complete reading of every paper or a fresh hash of every original source-rendering file. The issuer packet contains the 269 full native originals, required acquisition/reuse receipts, primary claim-bound originals/projections and source-review reports used here.

Issuer preparation manifest `7a3d6b3991b7ca720ae7ff79620e5a25f107127bc84bc5b58785510df397a950` is independently accepted by review manifest `7b29470655c06c86c98f4d20cdb93d153a5bf32f7639f54c1d86727b5dbe47bb`. All 968 physical peer-review files were freshly verified; selected complete reports/results and the original manifest/freeze are copied. Root's completed acceptance is retained. Exact aliases, authority code and this graph are outside that issuer acceptance.

I authored the source and issuer preparations and this design. Their independent acceptance is supplied by separate reviewers. The current graph is not independently self-accepted. No maintained record, authority snapshot, governed file, Git/GitHub state, runtime or frozen predecessor was changed. No helper, new network/source hunt or installation was used. Licensing remains deferred as instructed.

## Node selection and names

The 69 native nodes comprise one pathway, six issued reactions, 41 material identities, 13 nonclass proteins/complexes, seven exact enzyme-specific activities and one membrane class. The material set includes 35 concrete molecules and six generic classes. Four of those classes are native Protein objects and remain `protein`, even where their parent context mentions protein complexes. They are generic corrinoid/ferredoxin material states, not a species-specific polypeptide or exact reactive part. CPD-7 and Corrinoids remain generic cofactor classes.

All seven activities are `participants/category: molecular_activity`; the six issued reactions are `reactions/category: molecular_activity`. They are not equivalent identities. The physical complexes and monomers keep their distinct categories. Complete node, class, source-original, name-policy, issuer-disposition and incident-edge records are in `results/proposed-native-node-inventory.json`.

The existing 17 native authority owners retain their exact canonical labels and permitted categories. New names use normalized direct own common-name text. The six reactions, CPLX-322, CPLX-481 and PTAMSARC-MONOMER have no own common-name; their proposed labels are the literal frame tokens. PTAMSARC-MONOMER's own synonym Pta remains source context. No nested activity label becomes a reaction or physical-complex canonical name. A later bounded adapter must independently support these frame-token fallbacks; this design does not alter a prior profile or grant a general naming waiver.

The research-selected 91 objects are not a required node count. Seven gene objects, seven regulation objects and eight native organism/range objects remain reference/context records. The full 269-object disposition table retains the other 178 excluded contexts, including the 38 unrelated member-reaction activity contexts. It does not infer pathway support from an activity backlink or `physiologically-relevant=true` alone.

## Edge projection

| Source role | Edges | Representation |
|---|---:|---|
| Explicit root membership | 6 | Pathway `has_part` issued reaction |
| Native predecessor links | 5 | Exact source predecessor `precedes` successor |
| Canonical material occurrences | 29 | Selected-direction `consumes` / `produces` |
| Enzyme-specific activity association | 7 | Physical enzyme/complex `enables` native activity |
| Qualified enzyme/reaction association | 7 | Physical enzyme/complex `enables` issued reaction |
| Native complex composition | 8 | Complex `has_part` source component, coefficient retained |
| Direct cofactor occurrences | 7 | Physical enzyme/complex `has_cofactor` material |
| Alternative cofactor occurrences | 4 | Scoped `has_cofactor`, replacement explicitly stated |
| Alternative substrate occurrences | 6 | Exact Ack activity `has_input` alternate material |
| Source membrane placements | 3 | Physical source object `located_in` membrane |
| Source negative regulations | 7 | Chemical `inhibits` exact activity |

Every edge has an exact source assertion and locator. Integer coefficients, implicit-one status, source side and unlocated scope are preserved in the occurrence ledger and on the material/composition edge descriptions and evidence. The current edge schema has no dedicated top-level stoichiometry field. The KGX projection keeps the complete descriptions and evidence; consumers must not treat a bare triple as the full scoped assertion.

Two enzyme association layers deliberately preserve the source's physical enzyme, enzyme-specific activity and issued reaction separately. `enables` records the source association, not a new catalysis experiment. The presumed thermophila Mtr and incompletely characterized barkeri Mtr are conspicuously qualified on both incident association edges. No component becomes a catalyst merely because it belongs to an assembly.

Whole ACDS CPLX-461 is retained through all three assembly occurrences, with coefficients four CPLX-443, eight CPLX-442 and eight beta. CPLX-443 retains alpha2/epsilon2; CPLX-442 retains delta1/gamma1; Ack retains monomer2. RXN-12908's explicit `enzymes-not-used` exclusion is preserved. The graph never links whole CPLX-461 as enabling that isolated methyltransferase reaction. Its other native catalytic backlink remains outside the selected six-reaction activity set.

## Activity-input contract correction

The unchanged baseline rejected `has_input` from correctly typed activity participants, although documentation and native authority roles required that placement. The retained 83-edge iteration reproduces this defect rather than hiding it. Independent contract review `bd4a9af6ce303c9d8af920bd4e6ce223ae989f9c16c0d3dc2264de3659908dc8` supports issue 630. Root's released schema SHA is `b3f0c28ded2e0e665c15cf0a0e4a8e19ffc1d9bdfd397aa8383ad6a13baf4214`; the exact successor schema, docs, tests and root receipts are copied separately from baseline inputs.

The successor admits only unambiguous, explicitly typed participant activities as additional input/output subjects. It does not broaden consumes, produces, occurs_in or other predicates, and does not move activities into reactions. Root reports 96 targeted tests and exact source probes passed; those are attributed root results, not this author's check count. Final independent product review and full project gates remain separate.

The final six edges all originate at ENZRXN-481. TTP, ITP, UTP, GTP and CTP replace ATP; propionate replaces acetate. Each edge states the replaced substrate, thermophila/CPLX-441 activity scope, alternative rather than simultaneous use, and the native EV-EXP evidence level. None changes ATP + acetate ⇄ ADP + acetyl phosphate or any other canonical material occurrence. The six endpoints are connected without inventing a predicate or an additional reaction.

## Genes and taxa

All seven native gene/product relationships are retained with exact original locators. Gene evidence is attached to incident edges of the corresponding protein, and `results/gene-dispositions.json` provides the inverse coverage. No isolated gene node is warranted merely to duplicate identity context without a supported mechanism relation. The current schema lacks `encodes`; no gene-to-protein `part_of` or `enables` is fabricated. This is a finite representation limit, not evidence that a gene/product relationship is absent. Five pointed protein/ENA comparisons accompany the relevant protein edges. The partial 16-residue CdhD feature, precursor/processing, TM-1/collection-reference and unpointed Ack/Pta/Mtr limits remain explicit.

Six public taxa are declared: NCBITaxon 2207 and 2222 at genus rank, and 2208, 2210, 2214 and 2224 at species rank, using exact pinned issuing labels. The seventh direct native association, ORG-5913 (Methanosarcina TM-1, native species rank), is preserved visibly on membership incident context and in the complete taxon ledger. It has no own NCBI pointer; a matching strain string does not supply one. TAX-28890 is range only, with native Euryarchaeota versus pinned Methanobacteriota language retained. Neither native organism frame needs an invented authority term.

NCBI reference digests intentionally identify the previously verified full 14,115,225,600-byte pinned SQLite source. The full database is not copied here, and no individual taxonomy URL response is claimed. Complete selected issuing statement sets, exact query locators and the prior full-cache identity/size/mtime proof are retained. Other source references distinguish native response bodies, issuing originals, published text projections, thesis manuscript and abstract-only material.

## Scientific conflicts carried on incident context

- CPD-8 and CPD-9 retain their distinct full sarcinapterin skeletons and charge -4. Their identical short SMILES is incomplete. Neither methanopterin nor a neutral KEGG form is substituted. CPD-7's inconsistent InChI/CML/short-SMILES representations do not fix biological oxidation state, ligation or binding site. Corrinoid and ferredoxin classes remain generic.
- The source reactions remain unnamed at their own level. Ack retains literal EC-2.7.2.15 while its valid propionate-kinase definition and acetate overlap are described separately. Mtr's partial EC remains partial. Rhea 17829's obsolete status and literal replacement comment do not create a native alias to the narrower Rhea 21040 family. A KEGG request 404 is not historical absence.
- Whole-complex CO oxidation/metal/KCN measurements do not prove isolated alpha/epsilon catalysis, essential metal sites or neutral HCN activity. Chemical inhibitions target exact native activities; absent physiological-relevance slots remain absent. Other inhibitor-specific papers are source citations where unread.
- CdhD factor-III prose, CdhE Fe-S prose and complex CdhE corrinoid prose remain inconsistent. Low-occupancy E. coli BL21(DE3) reconstitution with hydroxocobalamin is not a firm native factor-III assignment. Modern issuing annotations do not settle that question. Historical alpha clusters, unread beta mechanism main and the barkeri crystal/ligand/FAD proposal retain their different scopes.
- Artificial methyl-iodide/CO synthesis, isotope EPR, partial proteolysis, partial purification and abstract-only component reports remain qualified context. None adds an exact native cleavage intermediate or a new topological step. Methanothrix Acs evidence remains condition-specific alongside the native Ack/Pta members and associations.
- All three membrane placements are source assertions. Presumed thermophila Mtr, limited barkeri characterization and Pta localization do not assign compartments to the 29 equation occurrences or supply sodium coupling. General one-quarter/three-quarter methyl-CoM, methane reduction and methanophenazine prose stays outside this pathway's graph.

The 32-claim ledger retains every accepted source statement, original evidence locator and reading/access limit, with its graph disposition. Primary context is paraphrased as source assertions; database prose is never presented as a quotation from a cited paper. The phase-specific U30484/U66032 source-reading limitation is distinguished from the subsequent issuing-sequence comparison.

## Authority demand, verification and next steps

The graph requires **52 new native terms**, preserving all 17 existing native owners, plus **five missing direct NCBI terms**, preserving existing NCBITaxon 2208. Reference-only genes, regulations, native organisms, EC/Rhea/ChEBI/UniProt evidence IDs do not become named-node authority additions. `results/native-authority-demand.json` includes exact labels, roles, types/classes, original hashes and existing owners. No snapshot is authored here.

Author checks use copied actual contracts, a separately captured root endpoint successor and the existing verified runtime. They verify semantic and closed LinkML shape, all source equation occurrences, typed roles, native XPath locators, all 69 SVG native nodes and 89 directed evidence links, 75 KGX declarations, complete edge descriptions/evidence and six alternate-input conditions. Static no-JavaScript projection was checked; there is no browser-interaction or pixel visual QA claim. No full corpus suite or identifier implementation acceptance is claimed.

A separate reviewer must assess this graph. Additive authority implementation then requires reviewed original profiles, deterministic snapshots and independent acceptance. Root remains responsible for final maintained curation, further claim placement, actual page QA, canonical record review and full gates. The prepared YAML is not a substitute for those steps. There is no new broad source-exhaustion or global novelty claim; prior bounded hidden/ignored and archive searches remain attributed to the accepted baseline review.
