from pathlib import Path
import os,json,hashlib,shutil,subprocess,datetime,re,tarfile,gzip,base64,html
from collections import Counter
from xml.etree import ElementTree as ET
import yaml
R=Path('/private/tmp/pathwaymech-next-271-20261015');O=Path('/private/tmp/pathwaymech-next-271-merged-baseline-independent-rebind');D=Path('/private/tmp/pathwaymech-next-271-discovery');S=Path('/private/tmp/pathwaymech-next-271-source-preparation');P=Path('/private/tmp/pathwaymech-next-271-independent-preflight-review');I=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');H='63ebb3b3e29ca1ed6472597104347d9fbc98f4a5';B='e8ae5e445d3288717c31d3012611e226fd5cca34';T='5448122efcfbd8ae2ac90ad42e70557b03d9b78e';checks=[];commands=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ok(v,n):checks.append({'check':n,'passed':bool(v)});assert v,n

def save(n,v):
 p=O/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def load(p):return json.loads(p.read_text())
def copy(p,d):
 q=O/d;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return q

def run(args,cwd=R):
 p=subprocess.run(args,cwd=cwd,capture_output=True);commands.append({'argv':args,'cwd':str(cwd),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode(errors='replace')});ok(p.returncode==0,'command '+str(args[:4]));return p.stdout

def tree(h):
 result={}
 for x in run(['git','ls-tree','-rz',h]).split(b'\0'):
  if x:
   a,p=x.split(b'\t',1);mode,typ,oid=a.decode().split();result[p.decode()]={'mode':mode,'type':typ,'oid':oid}
 return result

def owner(root,expected,label):
 mpath=root/'artifact-manifest.json';m=load(mpath);ok(sha(mpath.read_bytes())==expected,label+' pinned manifest')
 rows=m['files'];paths={r['path'] for r in rows};ex=m.get('exclusions',m.get('self_exclusions',m.get('self_excluded',[])));ex=set(ex)
 actual=set()
 for base,dirs,names in os.walk(root):
  for n in names:
   p=Path(base)/n;ok(p.is_file() and not p.is_symlink(),label+' regular '+p.relative_to(root).as_posix());actual.add(p.relative_to(root).as_posix())
 ok(actual==paths|ex,label+' physical complete incl hidden ignored')
 for row in rows:
  b=(root/row['path']).read_bytes();ok(len(b)==row['bytes'] and sha(b)==row['sha256'],label+' hash '+row['path'])
 for n in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md']:
  copy(root/n,'inputs/'+label+'/'+n)
 return {'owner':str(root),'manifest_sha256':expected,'listed_files':len(rows),'physical_files':len(actual),'listed_bytes':sum(r['bytes'] for r in rows),'physical_paths':sorted(actual)}
info={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':H,'tree':T,'base':B}
info['owners']=[owner(D,'c602b4d2e491b1efd99769a988b34930f096d78049ac1fa9874fe1de379aa97b','discovery'),owner(P,'493020bca61eaaea938a0c3730ebf6fabc5fc036698776fc963fbbccce44bf23','preflight'),owner(S,'06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5','source')]
copy(D/'ASSESSMENT.md','inputs/discovery/ASSESSMENT.md');copy(P/'REVIEW.md','inputs/preflight/REVIEW.md');copy(S/'ASSESSMENT.md','inputs/source/ASSESSMENT.md')
for root,names,label in [(D,['candidate-native-boundary.json','landed-authority-coverage.json','search-patterns.txt','followup-search-patterns.txt','new-landed269-archive-outer-search.json','selected-compressed-reuse-and-additional-search.json'],'discovery'),(P,['archive-and-search-audit.json','boundary-comparison-completion.json'],'preflight'),(S,['member-equations.json','native-object-inventory.json','all-native-object-dispositions.json','taxon-ledger.json'],'source')]:
 for n in names:copy(root/'results'/n,'inputs/'+label+'/'+n)
for n in ['initial-identity-scope.json','all-269-identity-scope-dispositions.json']:copy(I/'results'/n,'inputs/provisional-issuer/'+n)
for n in ['merge-integrity.json','root-actual-merge-acceptance.json']:copy(Path('/private/tmp/pathwaymech-next-270-ci')/n,'inputs/merge/'+n)
copy(Path('/private/tmp/pathwaymech-next-271-ci/actual270-merged-baseline.json'),'inputs/merge/actual270-merged-baseline.json')
ok(run(['git','rev-parse','HEAD']).decode().strip()==H,'actual current HEAD');ok(run(['git','rev-parse',H+'^{tree}']).decode().strip()==T,'actual merged tree');ok(run(['git','rev-parse',H+'^']).decode().strip()==B,'actual direct parent');ok(not run(['git','status','--porcelain=v1','--untracked-files=all']),'clean tracked/nonignored worktree')
raw=run(['git','cat-file','commit',H]);ok(hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==H,'actual commit content hash');(O/'inputs/merge/actual-commit.txt').write_bytes(raw)
head=tree(H);old=tree(B);save('results/actual-git-tree.json',head)
contracts=['.claude/skills/add-pathway/SKILL.md','CLAUDE.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','templates/pathway_mechanism_research.md','conf/sources.yaml','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','conf/identifier_policy.yaml','docs/IDENTIFIERS.md','src/pathwaymech/identifiers.py','scripts/build_source_identifier_snapshot.py']
contractrows=[]
for p in contracts:
 b=(R/p).read_bytes();ok(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==head[p]['oid'],'current contract Git '+p);contractrows.append({'path':p,'bytes':len(b),'sha256':sha(b),'unchanged_from_old_preflight':head[p]==old[p]});copy(R/p,'inputs/current/'+p)
save('results/contracts.json',contractrows)
patterns=list(dict.fromkeys((D/'results/search-patterns.txt').read_text().splitlines()+(D/'results/followup-search-patterns.txt').read_text().splitlines()));(O/'inputs/search-patterns.txt').write_text('\n'.join(patterns)+'\n');narrow=patterns[:12]
candidate=load(D/'results/candidate-native-boundary.json');members={'MetaCyc:'+x for x in candidate['members']};core=sorted({candidate['id']}|members|{'MetaCyc:'+x for x in candidate['equation_material_ids']});ok(len(core)==26,'fixed preliminary26 core')
corpus=[];records={};declared=set()
for p in sorted(head):
 if not(p.startswith('data/pathways/') and p.endswith('.yaml')):continue
 b=(R/p).read_bytes();ok(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==head[p]['oid'],'record Git '+p);x=yaml.safe_load(b);records[x['id']]=x;ids={x['id']}|{n['id'] for section in ['participants','reactions','taxa','gene_clusters'] for n in x.get(section,[])};declared|=ids
 hits=[pat for pat in patterns if pat.lower() in b.decode().lower()];exact=[pat for pat in patterns if re.search(r'(?<![A-Za-z0-9_.:+-])'+re.escape(pat)+r'(?![A-Za-z0-9_.:+-])',b.decode(),re.I)]
 corpus.append({'path':p,'id':x['id'],'label':x['label'],'bytes':len(b),'sha256':sha(b),'oid':head[p]['oid'],'same_as_old':p in old and head[p]==old[p],'literal_hits':hits,'exact_token_hits':exact,'candidate_native_member_declarations':sorted(ids&members),'source_alias_context':'Hits are leads; exact equivalence not inferred.'});copy(R/p,'inputs/current/'+p)
ok(len(corpus)==267,'complete267 corpus');ok(sum(r['same_as_old'] for r in corpus)==266,'all266 prior records unchanged');ok(candidate['id'] not in records,'candidate root not declared');ok(not(members&declared),'six candidate native reactions not declared');ok(not any(any(s.lower() in r['label'].lower() for s in [candidate['label'],*candidate['source_synonyms']]) for r in corpus),'candidate exact labels not record labels');save('results/all267-records.json',corpus)
source=load(R/'data/identifier_authorities/sources.json');ontology=load(R/'data/identifier_authorities/ontology.json');oldsource=json.loads(run(['git','show',B+':data/identifier_authorities/sources.json']));oldont=json.loads(run(['git','show',B+':data/identifier_authorities/ontology.json']));allterms=source['terms']|ontology['terms'];oldterms=oldsource['terms']|oldont['terms']
for n in ['sources.json','ontology.json']:copy(R/'data/identifier_authorities'/n,'inputs/current/data/identifier_authorities/'+n)
from pathwaymech.biocyc_methanogenesis import NODE_ROLES
from pathwaymech.biocyc_carrier import name
native={x['frame']:x for x in load(S/'results/native-object-inventory.json')}
def coverage(ident):
 frame=ident.split(':',1)[1];t=allterms.get(ident);nt=native.get(frame);sourceentry=source['sources'].get(t['source']) if t and t['source'] in source['sources'] else ontology['sources'].get(t['source']) if t else None
 return {'id':ident,'existing':t is not None,'existed_at_old_preflight':ident in oldterms,'newly_landed270':t is not None and ident not in oldterms,'term':t,'source_kind':sourceentry.get('kind') if sourceentry else None,'source_sha256':sourceentry.get('sha256') if sourceentry else None,'native_type':nt['type'] if nt else None,'native_class':nt['class'] if nt else None,'native_direct_names':nt['all_common_names'] if nt else None,'typed_node_roles':list(NODE_ROLES[t['entity_type']]) if t and t.get('entity_type') in NODE_ROLES else None}
corecov=[coverage(i) for i in core];ok(sum(x['existed_at_old_preflight'] for x in corecov)==9,'old core9 authority owners reproduced');save('results/core26-authority-coverage.json',corecov)
issuer=load(O/'inputs/provisional-issuer/initial-identity-scope.json');issuerids=sorted({'MetaCyc:'+x for v in issuer['selected_ids_by_type'].values() for x in v});ok(len(issuerids)==91,'91 provisional issuer IDs');issuercov=[coverage(i) for i in issuerids];save('results/provisional91-authority-coverage.json',issuercov)
info['core26']={'existing':sum(x['existing'] for x in corecov),'missing':sum(not x['existing'] for x in corecov),'newly_landed270':[x['id'] for x in corecov if x['newly_landed270']]};info['provisional91']={'existing':sum(x['existing'] for x in issuercov),'missing':sum(not x['existing'] for x in issuercov),'newly_landed270':[x['id'] for x in issuercov if x['newly_landed270']],'limitation':'Point-in-time issuer preparation inventory, not frozen issuer acceptance or prospective graph selection; no new term approval.'}
# Current direct native taxon pointers are distinguished from native Organism authority IDs.
tax=[]
for frame in issuer['selected_ids_by_type']['Organism']:
 e=ET.fromstring((S/native[frame]['path']).read_bytes())[1];pointers=[n.findtext('dblink-oid') for n in e.findall('dblink') if n.findtext('dblink-db')=='NCBI-TAXONOMY-DB'];tax.append({'native':frame,'label':native[frame]['label'],'native_class':native[frame]['class'],'pointers':[{'id':'NCBITaxon:'+i,'existing_term':allterms.get('NCBITaxon:'+i),'old_existing':'NCBITaxon:'+i in oldterms} for i in pointers],'limit':'Direct pointer existence only; issuer identity/rank acceptance belongs to separate review.'})
save('results/native-taxon-pointer-authority-coverage.json',tax)
# Exact source boundary against actual maintained270 and the two previous compared owners.
comparisons={}
for ident in ['MetaCyc:METHANOGENESIS-PWY','MetaCyc:PWY0-1312','WikiPathways:WP5019']:
 x=records[ident];comparisons[ident]={'label':x['label'],'description':x['description'],'reactions':x.get('reactions',[]),'participants':x.get('participants',[]),'candidate_native_member_overlap':sorted(members&{z['id'] for z in x.get('reactions',[])}),'mechanistic_edges':x['mechanistic_edges']}
save('results/three-boundary-comparisons.json',comparisons)
actual270=records['MetaCyc:METHANOGENESIS-PWY'];ok(len(actual270['reactions'])==6 and not(members&{x['id'] for x in actual270['reactions']}),'actual270 six distinct native members');ok('MetaCyc:CPD-8' not in {x['id'] for x in actual270['participants']} and 'MetaCyc:CPD-9' not in {x['id'] for x in actual270['participants']},'actual270 no sarcinapterin alias substitution')
# Pinned historical archive conclusions reused only after current physical digest equality.
oldarch=load(D/'results/new-landed269-archive-outer-search.json')['archive_bindings'];oldgzip=load(D/'results/selected-compressed-reuse-and-additional-search.json')['files'];reused=[]
for row in oldarch:
 p=row['path'];b=(R/p).read_bytes();ok(head[p]==old[p] and sha(b)==row['sha256'] and len(b)==row['bytes'],'old76 archive unchanged '+p);reused.append({'path':p,'sha256':sha(b),'bytes':len(b),'reused_search_patterns':narrow,'scope':'Prior independent 5084 outer members/4706 texts; no fresh decode.'})
for row in oldgzip:
 p=row['path'];b=(R/p).read_bytes();ok(head[p]==old[p] and sha(b)==row['compressed_sha256'],'old116 gzip unchanged '+p);reused.append({'path':p,'sha256':sha(b),'bytes':len(b),'reused_search_patterns':narrow,'scope':'Prior independent exact decoded bytes/12-pattern search; no fresh decode.'})
save('results/reused-compressed-bindings.json',reused)
changed=sorted(p for p in head if p not in old or head[p]!=old[p]);save('results/changed270-paths.json',changed)
# Whole working-tree text search explicitly includes hidden and ignored paths. Containers/binary interiors excluded.
argv=['rg','--no-ignore','--hidden','-l','-i','-F','-f',str(O/'inputs/search-patterns.txt'),'.','-g','!.git','-g','!.venv','-g','!*.gz','-g','!*.zip','-g','!*.pdf','-g','!*.sqlite','-g','!*.db','-g','!*.png','-g','!*.jpg','-g','!*.docx','-g','!*.xlsx']
p=subprocess.run(argv,cwd=R,capture_output=True);ok(p.returncode in [0,1],'hidden ignored whole-repo text search');(O/'results/whole-repo-search.stdout').write_bytes(p.stdout);(O/'results/whole-repo-search.stderr').write_bytes(p.stderr);save('results/whole-repo-search-receipt.json',{'argv':argv,'cwd':str(R),'exit_code':p.returncode,'pattern_count':len(patterns),'matched_paths':p.stdout.decode().splitlines(),'scope':'Working tree hidden+ignored included, .git/.venv excluded. Binary and listed container types excluded; no global absence inference.'})
newplain=[]
for p in changed:
 b=(R/p).read_bytes()
 if b'\0' in b[:8192]:continue
 try:txt=b.decode('utf-8')
 except UnicodeDecodeError:continue
 hits=[pat for pat in patterns if pat.lower() in txt.lower()]
 if hits:
  contexts=[]
  for pat in narrow:
   at=txt.lower().find(pat.lower())
   if at>=0:contexts.append({'pattern':pat,'context':txt[max(0,at-150):at+len(pat)+200]})
  newplain.append({'path':p,'sha256':sha(b),'bytes':len(b),'literal_matches':hits,'candidate_contexts':contexts})
save('results/new270-plain-mentions.json',newplain)
# Fresh outer text scan of every added/changed tar.gz. Only the twelve exact candidate/root/member patterns.
archive_rows=[];outer=[];hits=[];totals=Counter()
for p in changed:
 if not p.endswith('.tar.gz'):continue
 path=R/p;raw=path.read_bytes();archive_rows.append({'path':p,'bytes':len(raw),'sha256':sha(raw)});seen=set()
 with tarfile.open(path,'r:gz') as t:
  for m in t:
   ok(m.isfile() and m.name not in seen and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,'safe unique regular outer '+p+'::'+m.name);seen.add(m.name);b=t.extractfile(m).read();totals['members']+=1;totals['decoded_bytes']+=len(b);nested=m.name.endswith(('.tar.gz','.tgz','.zip','.gz','.xz','.bz2','.docx','.xlsx'));text=False;found=[];contexts=[]
   if nested:totals['nested_opaque']+=1
   elif b'\0' not in b[:8192]:
    try:txt=b.decode('utf-8');text=True
    except UnicodeDecodeError:pass
    if text:
     totals['text_members']+=1
     for pat in narrow:
      at=txt.lower().find(pat.lower())
      if at>=0:found.append(pat);contexts.append({'pattern':pat,'context':txt[max(0,at-150):at+len(pat)+200]})
   row={'archive':p,'path':m.name,'bytes':len(b),'sha256':sha(b),'text_searched':text,'nested_opaque':nested,'literal_matches':found};outer.append(row)
   if found:hits.append({**row,'contexts':contexts})
save('results/new270-outer-archive-search.json',{'archive_bindings':archive_rows,'totals':dict(totals),'patterns':narrow,'members':outer,'matches':hits,'limits':'Only these outer text members and 12 candidate/root/member patterns searched. Nested archives/other binary containers opaque; all other historical interiors and later aliases remain outside this scope.'})
info['new270_archives']={'archives':len(archive_rows),'compressed_bytes':sum(x['bytes'] for x in archive_rows),**dict(totals),'matching_members':len(hits),'distinct_matching_payloads':len({x['sha256'] for x in hits})};info['corpus_records']=len(corpus);info['whole_repo_matching_paths']=len(p.stdout.decode().splitlines()) if False else len((O/'results/whole-repo-search.stdout').read_text().splitlines());info['new270_plain_matching_paths']=len(newplain);info['checks']=len(checks);info['all_passed']=True
save('results/rebind-checks.json',{'info':info,'checks':checks,'commands':commands});print(json.dumps({k:v for k,v in info.items() if k!='owners'},indent=2))
