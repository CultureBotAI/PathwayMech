from pathlib import Path
import hashlib,json,os,stat,datetime
O=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-271-graph-design');D=O/'inputs/frozen-design'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((A/'artifact-manifest.json').read_text());expected={x['path'] for x in a['files']}|{'artifact-manifest.json','freeze-proof.json'}
actual={str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()};assert actual==expected
for x in a['files']:
 assert sha(A/x['path'])==x['sha256'];assert sha(D/x['path'])==x['sha256']
for name in ['artifact-manifest.json','freeze-proof.json']:assert sha(A/name)==sha(D/name)
(O/'independent/final-input-reverification.json').write_text(json.dumps({'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_owner':str(A),'author_manifest_sha256':sha(A/'artifact-manifest.json'),'author_listed_files':len(a['files']),'author_physical_files':len(actual),'all_original_and_copy_hashes_reverified':True,'inventory_hidden_ignored_included':True},indent=2)+'\n')
excluded={'artifact-manifest.json','freeze-proof.json'};assert not any((O/n).exists() for n in excluded)
files=[];directories=[]
for current,dirs,names in os.walk(O,followlinks=False):
 for d in dirs:
  p=Path(current)/d;assert not p.is_symlink();directories.append(str(p.relative_to(O)))
 for name in names:
  p=Path(current)/name;assert stat.S_ISREG(p.lstat().st_mode);rel=str(p.relative_to(O))
  if rel not in excluded:files.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
files.sort(key=lambda x:x['path']);listedbytes=sum(x['bytes'] for x in files)
manifest={'version':1,'owner':str(O),'scope':'Complete physical inventory including hidden/ignored files; no ignore filtering; historical nested archive containers opaque. Only this manifest/freeze self-excluded.','files':files,'directories':sorted(directories),'listed_files':len(files),'listed_bytes':listedbytes,'excluded_self_metadata':sorted(excluded)}
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze={'status':'frozen','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'review_sha256':sha(O/'REVIEW.md'),'result_sha256':sha(O/'RESULT.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':listedbytes,'physical_file_paths':sorted([x['path'] for x in files]+list(excluded)),'all_owned_jobs_terminal':True,'maintained_writes':False,'independent_graph_acceptance':'qualified at explicit design/source/issuer limits','actionable_findings':0,'fresh_independent_checks':9751}
(O/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n')
actual=sorted(str(p.relative_to(O)) for p in O.rglob('*') if p.is_file());assert actual==freeze['physical_file_paths']
for x in files:assert (O/x['path']).stat().st_size==x['bytes'];assert sha(O/x['path'])==x['sha256']
assert sha(O/'artifact-manifest.json')==freeze['manifest_sha256']
print(json.dumps({k:freeze[k] for k in ['listed_files','physical_files','listed_bytes','manifest_sha256','handoff_sha256','review_sha256','result_sha256']}|{'freeze_sha256':sha(O/'freeze-proof.json'),'fresh_inventory_verification':'PASS'},indent=2))
