from pathlib import Path
import hashlib,json,datetime
O=Path(__file__).resolve().parents[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'freeze-proof.json').exists()
assert not any(p.is_symlink() for p in O.rglob('*'))
excluded={'artifact-manifest.json','freeze-proof.json'}
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':h(p)} for p in sorted(O.rglob('*')) if p.is_file() and str(p.relative_to(O)) not in excluded]
manifest={'version':1,'scope':'Complete physical inventory including hidden/ignored files; nested historical containers opaque; only manifest/freeze self-excluded.','files':files}
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
proof={'status':'frozen','finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':h(O/'artifact-manifest.json'),'handoff_sha256':h(O/'HANDOFF.md'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'all_owned_jobs_terminal':True,'maintained_writes':False,'independent_graph_acceptance':False,'native_nodes':69,'taxa':6,'edges':89,'final_author_checks':4509}
(O/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert len([p for p in O.rglob('*') if p.is_file()])==len(files)+2
assert all(h(O/x['path'])==x['sha256'] for x in files)
print(json.dumps({**proof,'freeze_sha256':h(O/'freeze-proof.json'),'yaml_sha256':h(O/'design/prospective-record.yaml'),'design_sha256':h(O/'DESIGN.md')},indent=2))
