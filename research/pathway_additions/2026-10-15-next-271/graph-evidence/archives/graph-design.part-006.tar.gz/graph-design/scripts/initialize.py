from pathlib import Path
import json, hashlib, shutil, subprocess
O=Path(__file__).resolve().parents[1]
B=Path('/private/tmp/pathwaymech-next-271-20261015')
for d in ['inputs','results','reading','receipts','probes','design']: (O/d).mkdir(exist_ok=True)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
receipts=[]
for name,path in [('issuer','/private/tmp/pathwaymech-next-271-issuer-preparation'),('baseline-review','/private/tmp/pathwaymech-next-271-merged-baseline-independent-rebind')]:
 p=Path(path);m=p/'artifact-manifest.json';d=json.loads(m.read_text());entries=d if isinstance(d,list) else d.get('files',d.get('artifacts'))
 assert isinstance(entries,list),d.keys()
 for x in entries:
  q=p/x['path'];assert q.is_file() and h(q)==x['sha256'],q
 physical=[q for q in p.rglob('*') if q.is_file()]
 assert len(physical)==len(entries)+2,(name,len(physical),len(entries))
 assert not any(q.is_symlink() for q in p.rglob('*'))
 shutil.copytree(p,O/'inputs'/name)
 assert all(h(O/'inputs'/name/q.relative_to(p))==h(q) for q in physical)
 receipts.append({'source':str(p),'copy':'inputs/'+name,'manifest_sha256':h(m),'listed':len(entries),'physical':len(physical),'scope':'Complete physical file copy including hidden/ignored files; ordinary file bytes rehashed; nested containers opaque.'})
contract=[]
paths=['CLAUDE.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','docs/IDENTIFIERS.md','templates/pathway_mechanism_research.md','conf/sources.yaml','conf/identifier_sources.json','.claude/skills/add-pathway/SKILL.md','pyproject.toml','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json','data/pathways/methanogenesis-from-h2-and-co2.yaml']
paths += [str(p.relative_to(B)) for folder in ['src','scripts'] for p in (B/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
for rel in sorted(set(paths)):
 p=B/rel;q=O/'inputs/baseline'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
 git=subprocess.run(['git','show','HEAD:'+rel],cwd=B,check=True,capture_output=True).stdout
 assert hashlib.sha256(git).hexdigest()==h(p)==h(q),rel
 contract.append({'path':rel,'sha256':h(p),'bytes':p.stat().st_size})
head=subprocess.run(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=B,check=True,capture_output=True,text=True).stdout.splitlines()
assert head==['63ebb3b3e29ca1ed6472597104347d9fbc98f4a5','5448122efcfbd8ae2ac90ad42e70557b03d9b78e']
for rel in ['actual270-merged-baseline.json','root-intake-next271-issuer-preparation.json','root-intake-next271-merged-baseline-independent-rebind.json','authority-implementation-preflight.json']:
 shutil.copy2(Path('/private/tmp/pathwaymech-next-271-ci')/rel,O/'inputs'/rel)
save(O/'receipts/initial-input-verification.json',{'packets':receipts,'baseline_head':head[0],'baseline_tree':head[1],'baseline_owners':contract,'maintained_writes':False,'runtime_changes':False})
print('Verified and copied',len(contract),'baseline files and',sum(r['physical'] for r in receipts),'frozen packet files')
