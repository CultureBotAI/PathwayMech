from pathlib import Path
import json,re
from lxml import html as H
import yaml
O=Path(__file__).resolve().parents[1];raw=(O/'probes/prospective-page.html').read_text();page=H.fromstring(raw);record=yaml.safe_load((O/'design/prospective-record.yaml').read_text());checks=[]
def ck(k,v):checks.append({'name':k,'passed':bool(v)});assert v,k
svgs=page.xpath('//*[local-name()="svg" and @class="pathway-network-svg"]');ck('one actual source graph (six other SVGs are legend icons)',len(svgs)==1);svg=svgs[0]
nodes=svg.xpath('.//*[@data-node-id]');links=svg.xpath('.//a[@data-subject and @data-object and @data-predicate]')
expected={record['id']}|{n['id'] for f in ['participants','reactions'] for n in record[f]}
ck('all69 native graphical nodes',len(nodes)==69 and {n.get('data-node-id') for n in nodes}==expected);ck('all89 graphical edges',len(links)==89)
for j,edge in enumerate(record['mechanistic_edges'],1):
 link=links[j-1];ck('edge topology '+edge['id'],[link.get('data-subject'),link.get('data-predicate'),link.get('data-object')]==[edge['subject'],edge['predicate'],edge['object']]);ck('arrowhead '+edge['id'],bool(link.xpath('.//*[@marker-end]')))
 row=page.get_element_by_id(link.get('href')[1:]);visible=' '.join(row.text_content().split());ck('description no JS '+edge['id'],' '.join(edge['description'].split()) in visible)
 for ev in edge['evidence']:
  ck('assertion no JS '+edge['id'],' '.join(ev['source_assertion'].split()) in visible);ck('locator no JS '+edge['id'],' '.join(ev['source_locator'].split()) in visible)
for f in ['TTP','ITP','UTP','GTP','CTP','PROPIONATE']:
 ms=[e for e in record['mechanistic_edges'] if e['subject']=='MetaCyc:ENZRXN-481' and e['object']=='MetaCyc:'+f]
 ck('one exact alternate-input '+f,len(ms)==1 and ms[0]['predicate']=='has_input' and 'alternative' in ms[0]['description'])
 ck('no canonical alternate equation '+f,not any(e['predicate'] in ['consumes','produces'] and 'MetaCyc:'+f in [e['subject'],e['object']] for e in record['mechanistic_edges']))
match=re.search(r'<svg xmlns="http://www.w3.org/2000/svg" class="pathway-network-svg"[\s\S]*?</svg>',raw);ck('exact rendered SVG extraction',bool(match));(O/'probes/source-network.svg').write_text(match.group()+'\n')
(O/'receipts/page-coverage-final.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'scope':'Static no-JavaScript source graph and evidence-table projection; no browser/interactive or pixel visual QA claim.'},indent=2)+'\n')
print(len(checks),'static page assertions passed')
