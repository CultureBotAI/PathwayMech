from pathlib import Path
import json,hashlib,sys
from collections import Counter
from lxml import etree as E
import yaml
O=Path(__file__).resolve().parents[1];I=O/'inputs/issuer';S=I/'inputs/source';B=O/'inputs/baseline';sys.path.insert(0,str(B/'src'))
from pathwaymech.biocyc_phenylacetate import NODE_ROLES as P
from pathwaymech.biocyc_glutaryl import NODE_ROLES as G
from pathwaymech.biocyc_methanogenesis import NODE_ROLES as M

def load(p):return json.loads(p.read_text())
def write(rel,d):(O/rel).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
r=yaml.safe_load((O/'design/prospective-record.yaml').read_text());nodes=load(O/'results/proposed-native-node-inventory.json');edges=load(O/'results/proposed-native-edge-inventory.json');selected=load(I/'results/all-91-issuer-dispositions.json');inv={x['frame']:x for x in load(S/'results/native-object-inventory.json')};checks=[]
def ck(k,v):checks.append({'name':k,'passed':bool(v)});assert v,k
cur=lambda f:'MetaCyc:'+f
ck('native selection69',len(nodes)==69);ck('six taxon declarations',len(r['taxa'])==6)
allids={x['declaration']['id'] for x in nodes};ck('unique native identifiers',len(allids)==69)
slotrows=[]
for row in selected:
 f=row['frame'];file=S/inv[f]['path'];doc=E.parse(str(file));e=doc.getroot().find(inv[f]['type']);counts=Counter();base=f"/ptools-xml/{e.tag}[@frameid='{f}']"
 for j,slot in enumerate(e,1):
  counts[slot.tag]+=1;loc=base+f'/{slot.tag}[{counts[slot.tag]}]';direct=[]
  for ed in edges:
   if any(x['reference_id']==cur(f) and (x['source_locator']==loc or x['source_locator'].startswith(loc+'/')) for x in ed['edge']['evidence']):direct.append(ed['id'])
  if direct:disposition='Exact source slot directly cited by graph assertion or qualification.'
  elif slot.tag in ['common-name','synonym','parent']:
   disposition='Identity/class/name context; exact existing labels retained, new common-name or frame-token policy proposed. No hierarchical edge or exact alias inferred.'
  elif slot.tag in ['dblink','goid','has-go-term','ec-number']:
   disposition='Bounded public-pointer/annotation context in issuer dispositions. No automatic exact alias or extra graph node; explicit membrane and EC context handled on incident edges.'
  elif row['type']=='Organism':disposition='Complete native taxon own context; six issuing NCBI declarations only, seventh native association and range explicitly separate.'
  elif slot.tag in ['comment','citation','evidence']:
   disposition='Narrative/citation/inference context retained in original and accepted claim ledger; only bounded supported statements are attached on incident edges. A cited publication is not automatically a read primary source.'
  elif slot.tag in ['gene','product']:
   disposition='Gene/product identity context is preserved on product-incident edge evidence and seven-gene ledger. No encodes or false part_of/enables edge.'
  elif slot.tag=='catalyzes' and f=='CPLX-461':
   disposition='Whole-complex ENZRXN-30278 context is outside the six member-reaction activity set. Retained as context, not a new member/catalytic edge; RXN-12908 explicitly excludes whole CPLX-461.'
  elif slot.tag in ['catalyzes','component-of','regulated-by']:
   disposition='Reciprocal context is represented through the qualified full activity, component or regulation original; no duplicate or unrelated backlink is promoted.'
  elif row['type'] in ['Compound','Protein']:
   disposition='Identity/property/context slot retained in full original and 41-material/13-nonclass-protein dispositions; no extra mechanistic edge from this property alone.'
  else:disposition='Complete own-slot context retained. Not an independently supported additional graph relation; finite selected roles and exclusions are explicit.'
  slotrows.append({'frame':f,'type':row['type'],'slot':slot.tag,'own_slot_position':j,'tag_occurrence':counts[slot.tag],'locator':loc,'xml':E.tostring(slot,encoding='unicode'),'direct_graph_edges':direct,'disposition':disposition})
  ck('own slot exact '+f+' '+str(j),len(doc.xpath(loc))==1)
# Independent original equations, coefficient occurrences and order.
rootdoc=E.parse(str(S/'originals/native/META-METH-ACETATE-PWY.xml'));root=rootdoc.getroot().find('Pathway');members=[x.get('frameid') for x in root.find('reaction-list')]
ck('six exact members',len(members)==6 and {cur(x) for x in members}=={x['id'] for x in r['reactions']})
material=[]
for rx in members:
 e=E.parse(str(S/'originals/native'/('META-'+rx+'.xml'))).getroot().find('Reaction');direction=next(x.findtext('direction') for x in root.findall('reaction-layout') if x.find('Reaction').get('frameid')==rx)
 ck('source direction '+rx,e.findtext('reaction-direction')=='REVERSIBLE')
 ck('no invented reaction common-name '+rx,e.find('common-name') is None and next(x for x in r['reactions'] if x['id']==cur(rx))['label']==rx)
 for side in ['left','right']:
  for j,slot in enumerate(e.findall(side),1):
   mat=next(x for x in slot if x.get('frameid')).get('frameid');coef=int(slot.findtext('coefficient') or 1);inp=(side=='left')==(direction=='L2R')
   ms=[m for m in edges if m['kind']=='material' and m['source_scopes']['reaction']==rx and m['source_scopes']['side']==side and m['source_scopes']['index']==j]
   ck('exact material occurrence '+rx+side+str(j),len(ms)==1)
   m=ms[0];ck('correct coefficient '+m['id'],m['source_scopes']['coefficient']==coef);ck('no compartment '+m['id'],not slot.findall('compartment') and m['source_scopes']['compartments']==[])
   ck('selected direction '+m['id'],m['edge']['subject']==cur(mat if inp else rx) and m['edge']['object']==cur(rx if inp else mat) and m['edge']['predicate']==('consumes' if inp else 'produces'))
   material.append({'edge':m['id'],'reaction':rx,'side':side,'occurrence':j,'material':mat,'coefficient':coef,'compartments':[]})
ck('29 material occurrences',len(material)==29);ck('19 distinct materials',len({x['material'] for x in material})==19)
for j,s in enumerate(root.findall('reaction-ordering'),1):
 subject=s.find('predecessor-reactions/Reaction').get('frameid');obj=s.find('Reaction').get('frameid')
 ck('native order '+str(j),sum(m['kind']=='order' and m['edge']['subject']==cur(subject) and m['edge']['object']==cur(obj) for m in edges)==1)
# Class, naming and existing owner roles are checked without modifying/synthesizing an authority snapshot.
roles=P|G|M
for n in nodes:
 t=n['existing_authority'];d=n['declaration']
 if t:
  ck('old canonical owner label '+d['id'],d['label']==t['label'])
  if t.get('entity_type') in roles:
   section,cats=roles[t['entity_type']];ck('old category role '+d['id'],n['section']==section and d['category'] in cats)
  elif t.get('entity_type')=='protein_class':ck('old protein class '+d['id'],n['section']=='participants' and d['category']=='protein')
  elif t.get('entity_type')=='native_chemical_class':ck('old chemical class '+d['id'],d['category'] in t['allowed_categories'])
 if n['native_class'] and n['native_type']=='Protein':ck('generic protein material '+d['id'],d['category']=='protein')
 if n['name_policy'].startswith('exact frame'):ck('literal fallback '+d['id'],d['label']==n['frame'])
ck('seven activity participants',sum(n['native_type']=='Enzymatic-Reaction' and n['section']=='participants' for n in nodes)==7)
ck('all 41 materials preserved',sum(n['native_type']=='Compound' or (n['native_type']=='Protein' and n['native_class']) for n in nodes)==41)
ck('all 13 nonclass proteins preserved',sum(n['native_type']=='Protein' and not n['native_class'] for n in nodes)==13)
ck('no whole ACDS reaction capability',not any(e['subject']=='MetaCyc:CPLX-461' and e['object']=='MetaCyc:RXN-12908' for e in r['mechanistic_edges']))
ck('zero gene nodes',not any(n['native_type']=='Gene' for n in nodes));ck('seven gene contexts',len(load(O/'results/gene-dispositions.json'))==7)
ck('no invented transport',not any(e['predicate'] in ['consumes','produces','has_input','has_output'] and 'MetaCyc:NA+' in [e['subject'],e['object']] for e in r['mechanistic_edges']))
ck('all32 claims dispositioned',{x['id'] for x in load(O/'results/all32-claim-to-design-dispositions.json')}=={x['id'] for x in load(S/'results/claim-ledger.json')})
ck('all269 source objects dispositioned',len(load(O/'results/all269-node-and-context-dispositions.json'))==269)
ck('all118 references bound',len(r['references'])==len(load(O/'results/reference-original-bindings.json')))
write('results/all-selected-own-slot-design-dispositions.json',slotrows)
write('results/independent-original-material-projection.json',material)
write('receipts/coverage-probe.json',{'checks':checks,'passed':len(checks),'own_slots':len(slotrows),'scope':'Author independent XML projection and copied role checks, not independent scientific or authority acceptance.'})
print(len(checks),'checks;',len(slotrows),'selected own slots')
