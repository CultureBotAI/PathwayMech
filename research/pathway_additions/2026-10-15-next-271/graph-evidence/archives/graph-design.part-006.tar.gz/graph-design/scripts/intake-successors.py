from pathlib import Path
import json,hashlib,shutil
O=Path(__file__).resolve().parents[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
receipts=[]
for label,src,expected,full in [('issuer-review','/private/tmp/pathwaymech-next-271-independent-issuer-review','7b29470655c06c86c98f4d20cdb93d153a5bf32f7639f54c1d86727b5dbe47bb',False),('activity-endpoint-review','/private/tmp/pathwaymech-next-271-activity-endpoint-review','bd4a9af6ce303c9d8af920bd4e6ce223ae989f9c16c0d3dc2264de3659908dc8',True)]:
 p=Path(src);m=p/('manifest.json' if label=='activity-endpoint-review' else 'artifact-manifest.json');assert h(m)==expected;d=load(m);rows=d if isinstance(d,list) else d['files'];physical=[x for x in p.rglob('*') if x.is_file()];assert len(physical)==len(rows)+2
 for x in rows:assert h(p/x['path'])==x['sha256'],x['path']
 assert not any(x.is_symlink() for x in p.rglob('*'))
 selected=physical if full else [x for x in physical if len(x.relative_to(p).parts)==1 and x.suffix in ['.md','.json'] or x.parent==p/'results']
 copied=[]
 for x in selected:
  q=O/'inputs'/label/x.relative_to(p);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(x,q);assert h(q)==h(x);copied.append({'path':str(q.relative_to(O)),'sha256':h(q),'source_relative':str(x.relative_to(p))})
 receipts.append({'source':src,'manifest_sha256':expected,'all_listed_verified':len(rows),'physical_count':len(physical),'copies':copied,'scope':'Complete physical byte verification, selected report/result copy' if not full else 'Complete byte verification and copy'})
ci=Path('/private/tmp/pathwaymech-next-271-ci');root=Path('/private/tmp/pathwaymech-next-271-20261015');release=load(ci/'activity-endpoint-product-changes.json');dest=O/'inputs/endpoint-successor';shutil.copytree(O/'inputs/baseline',dest)
for x in release['files']:
 p=root/x['path'];assert h(p)==x['sha256'];q=dest/x['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert h(q)==x['sha256']
for name in ['activity-endpoint-product-changes.json','root-intake-next271-activity-endpoint-review.json']:
 shutil.copy2(ci/name,O/'inputs'/name)
(O/'receipts/successor-input-verification.json').write_text(json.dumps({'packets':receipts,'endpoint_successor_release':release,'base_preserved':True,'maintained_writes':False},indent=2)+'\n')
print('Successor contracts and peer acceptances verified/copied')
