from pathlib import Path
import json,hashlib,subprocess,os,shutil,datetime
O=Path(__file__).resolve().parents[1]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
inputs={str(p.relative_to(O)):h(p) for p in (O/'inputs').rglob('*') if p.is_file()}
outputs=[p for d in ['results','design','probes'] for p in (O/d).rglob('*') if p.is_file()]
before={str(p.relative_to(O)):h(p) for p in outputs};before_receipts={rel:h(O/rel) for rel in ['receipts/design-probe-final.json','receipts/coverage-probe.json','receipts/page-coverage-final.json']}
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');runs=[]
for script in ['design.py','probe.py','coverage.py','page-coverage.py']:
 cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B',str(O/'scripts'/script)]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,cwd=O,env=env,capture_output=True);name='replay-'+script[:-3]
 (O/'receipts'/f'{name}.stdout').write_bytes(r.stdout);(O/'receipts'/f'{name}.stderr').write_bytes(r.stderr)
 runs.append({'command':cmd,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'returncode':r.returncode,'stdout':f'receipts/{name}.stdout','stderr':f'receipts/{name}.stderr'});assert r.returncode==0,(script,r.stderr)
assert all(h(O/p)==v for p,v in before.items()),'output non-determinism'
assert all(h(O/p)==v for p,v in before_receipts.items()),'check receipt non-determinism'
assert all(h(O/p)==v for p,v in inputs.items()),'copied input changed'
# Rehash both the complete original issuer/baseline review owners and their exact copies; reports/results copied from other peers retain exact bindings.
intake=load(O/'receipts/initial-input-verification.json');verifications=[]
for pkt in intake['packets']:
 source=Path(pkt['source']);copied=O/pkt['copy'];m=load(source/'artifact-manifest.json');rows=m if isinstance(m,list) else m['files'];files=[p for p in source.rglob('*') if p.is_file()]
 assert len(files)==pkt['physical'];assert h(source/'artifact-manifest.json')==pkt['manifest_sha256']
 for row in rows:assert h(source/row['path'])==row['sha256']==h(copied/row['path'])
 assert all(h(p)==h(copied/p.relative_to(source)) for p in files)
 verifications.append({'source':str(source),'listed':len(rows),'physical':len(files),'unchanged':True})
for pkt in load(O/'receipts/successor-input-verification.json')['packets']:
 for row in pkt['copies']:assert h(O/row['path'])==row['sha256']==h(Path(pkt['source'])/row['source_relative'])
release=load(O/'inputs/activity-endpoint-product-changes.json')
for row in release['files']:assert h(O/'inputs/endpoint-successor'/row['path'])==row['sha256']
counts={k:load(O/'receipts'/k)['passed'] for k in ['design-probe-final.json','coverage-probe.json','page-coverage-final.json']}
receipt={'runs':runs,'deterministic_outputs':[{'path':p,'sha256':v} for p,v in sorted(before.items())],'deterministic_check_receipts':before_receipts,'copied_inputs_unchanged':len(inputs),'frozen_source_reverification':verifications,'author_checks':counts,'total_final_checks':sum(counts.values()),'separate_root_endpoint_tests':96,'independent_acceptance_claimed':False,'maintained_mutations':False,'network_calls':0,'scope':'Before freeze: four source-derived projection scripts replayed; exact output and receipt bytes reproduced. No full corpus suite or independent authority gate.'}
(O/'receipts/final-reproduction-and-integrity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'final_author_checks':sum(counts.values()),'by_script':counts,'outputs':len(before),'copied_inputs':len(inputs),'all_terminal':True}))
