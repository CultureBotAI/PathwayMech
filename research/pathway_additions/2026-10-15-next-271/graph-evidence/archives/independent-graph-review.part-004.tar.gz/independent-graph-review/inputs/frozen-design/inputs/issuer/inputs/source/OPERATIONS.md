# Operational scope and retained diagnostics

All network operations were finite source acquisitions for the selected pathway and exact primary leads. New native batches direct/closure1/closure2/closure3/closure4/closure6 completed successfully; closure5 and closure7 had no new network targets. Native requests used the exact bare META query with the source's literal plus handling. Earlier failed discovery/preflight attempts remain preserved inside the unchanged predecessor packet. New primary acquisition batches and all raw bodies are indexed in `results/primary-access-ledger.json`; successful metadata and failed HTML are not full-paper originals.

The final primary attempts were the exact Gong supplement index, cdhDE metadata, and the publisher PDF request. The SI and PDF requests returned 403; metadata succeeded. No further retrieval is pending. One earlier guessed IUCR file path failed and is explicitly not identity or scientific evidence. No access control was bypassed.

Retained local corrections:

- `iterations/first-ledger-nested-context-overcount`: an initial mechanical ledger counted embedded low-detail parents as forward endpoints. Corrected to direct own-slot endpoints; all nested references remain in the occurrence inventory.
- `iterations/pre-alternative-wrapper-closure`: initial direct-child traversal did not expand the substrate/cofactor/alternate wrappers. Ten additional full compound objects were acquired; final selected forward count 338, no unresolved target.
- `iterations/pre-ec-and-multiple-name-projection`: EC strings are scalar slots. The earlier convenience equation projection omitted them while originals and full slot ledger retained them. Final equations preserve all literal EC annotations. Multiple direct names are checked; none occur in the final 269 full objects. Embedded names are not mistaken for own names.
- `iterations/claim-builder-missing-receipt-name`: the first claim builder exited 1 for a nonexistent local `web-primary-open-04.json` filename. No claim ledger was saved by that run. The corrected retained receipt binding and final successful output are explicit.

Harmless missing local-file probes are retained in `results/initial-operations.json`; later read probes of nonexistent receipt aliases or an `efetch*` glob were operational lookup errors, not absence claims. Every final scientific evidence path resolves and is hashed. A network approval description called closure4's G-12700 object an organism; the request/body is a Gene and all inventories correctly preserve its actual type.

Existing runtime: `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`. Existing PDFKit binary/source are bound in `receipts/pdf-reader-binding.json`; they were used unchanged, not rebuilt. Shell startup emitted a harmless pyenv rehash warning on the initial inventory call; subsequent commands used `login:false`. No remediation was performed.

Recorded terminal success handles include 67488(native closure6),39782(Gong PDF read),98301/58834/39416/8698(native ledger iterations),46511/17083(integrity audits),21524(last institutional PDF batch). Initial claim handle 39643 terminated 1 and is retained as above. Final reproduction and pre-freeze process evidence are recorded in `results/final-operation-receipt.json`; the freeze proof binds the completed inventory. The freezer terminal result is reported separately on release. No live owned process is left at release. No claim is made about unrelated parent/peer processes.

The physical inventory uses filesystem traversal independent of gitignore. Compressed containers retained from predecessors remain opaque in this task; their earlier exact bounded replay proofs remain available. No new global absence, complete-history decode or recursively reviewed binary-content claim is made.

The final primary-receipt content audit corrected three claim entries that referenced adjacent unrelated/failed web receipts. Exact publisher DOI presence is now checked in every substantive publisher-reading receipt. The earlier claim/proof bytes are preserved in `iterations/primary-receipt-binding-audit/`; the scientific interpretation did not change. Final reproducibility:22 outputs byte-identical; final integrity audit:5401 assertions passed.

The first freezer attempt stopped before writing any manifest because sandboxed `ps` was denied (PermissionError, exit1). It is retained in `iterations/freeze-process-list-sandbox-denial/`. The same bounded read-only process check was retried with execution permission; no runtime change or unrelated process data retention was involved.
