# Operations and attempts

Only `/private/tmp/pathwaymech-next-271-issuer-preparation` was written. Frozen predecessors, maintained worktrees, Git/GitHub and runtime installations were untouched. The parent prohibited helper agents for this task; none was launched.

The first 99 approved direct requests encountered sandbox DNS resolution failures and produced no bodies. Their original job list, full receipts and logs remain unchanged. The same finite requests were retried with authorized public network access into a separately named receipt/log; 98 returned200 and KEGG:R00296 returned404 with an empty body. Four concrete follow-up requests returned200. No unsuccessful body was treated as an issuing original or primary full text. ExPASy web-tool reading is retained separately as a tool projection.

Twenty-five historical original files were copied only after exact manifest/hash checks. Rhea142 and taxonomy are pinned historical evidence, not fresh-current downloads. Native response provenance includes all269 acquisition/reuse receipts and the sodium ancestry. Rhea ancestry records carry prior cache URLs/hash/version; release-properties lacks an original HTTP receipt and is described accordingly. No original timestamp or status was invented.

Exploratory displays that truncated large XML/claim projections were followed by bounded own-slot/statement reads. An early ad hoc UniProt display used `type` instead of the actual `database` field and raised KeyError after printing one record; it made no persistent data change. The correct full field projection and scientific reads followed. A probe for a nonexistent `full-native-objects.json` used no absence inference; the actual source ledger names were inspected. A guessed provenance-container filename was corrected by listing and reading the existing chain. These were tool navigation misses, not biological failures.

The Rhea parser first inspected the three direct seeds; subsequent scripts separately inspected the literal obsolete replacement and the two specific protein-annotation reaction IDs. Earlier outputs are preserved. No prior projection was silently broadened or claimed to cover the final set. No public aliases were promoted.

The existing Python runtime and the exact 77-file RDKit runtime binding were used. RDKit warnings and six ChEBI SMILES import failures are retained; successful InChI comparisons do not erase those failures. No module, package, database or environment was installed/repaired. Taxonomy was queried with `mode=ro&immutable=1`; no14GB rehash is claimed.

`scripts/reproduce_offline.py` retains pre-replay outputs under `iterations/offline-before`, runs deterministic local analyses and records real exit statuses and matching hashes. Taxonomy's UTC receipt is inherently new; its original receipt remains preserved and selected statement/lineage outputs are compared byte-for-byte. The final author audit and freeze run only after all acquisition/analysis processes are terminal.

A final optional `ps` inventory was denied by the sandbox. No process absence claim is based on that command. Completion is established by the authoritative terminal exit results of every owned execution handle and the replay subprocess receipts.
