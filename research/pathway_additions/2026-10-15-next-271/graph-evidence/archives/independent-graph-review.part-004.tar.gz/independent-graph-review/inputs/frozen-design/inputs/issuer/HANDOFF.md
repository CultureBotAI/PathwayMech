# Frozen issuer-preparation handoff: next271

**Ready for independent bounded issuer review. No authority, alias, graph or maintained-record acceptance is claimed.** Read `ASSESSMENT.md`, `READING-SCOPES.md`, then the 91-object and 474-pointer disposition ledgers.

Owner: `/private/tmp/pathwaymech-next-271-issuer-preparation`.

The finite scope is 91 selected native objects and 178 excluded contexts from 269 retained full native originals. It includes 41 material identities (35 concrete, 6 generic), six reactions / 29 unlocated occurrences / 19 equation IDs, 13 nonclass proteins or complexes, seven qualified activities, seven genes, seven regulations, one membrane class, seven direct organisms plus one range, and the pathway root. All 38 other-organism activities remain explicitly excluded. Ten non-dblink public-ID slots and all 474 selected own dblink occurrences are accounted for.

Direct issuing evidence: 39 ChEBI, 36 KEGG compound texts / 33 MOLs, four KEGG reaction responses, five UniProt records, two complete ENA records and two ENZYME pages; exact endpoint/location follow-ups add two KEGG texts / one MOL and one GO term. Twenty-five historical originals are reused, including complete pinned Rhea142. The 202 direct attempts distinguish 99 DNS failures from 103 actual HTTP responses (102 success / one 404). Every body/reuse hash and request context is retained. No PubChem expansion or new primary-paper hunt was required.

Key dispositions:

- All35 concrete native InChIs agree with their direct ChEBI representation at the compared standardized scope; this does not promote aliases. Sarcinapterin complete structures, neutral KEGG forms and incomplete shared source SMILES remain distinct. Generic CPD-7 has conflicting CML/SMILES/InChI representations; generic corrinoid/Fd classes are preserved.
- Rhea17829 is explicitly obsolete with a literal replacement comment naming21040. That replacement narrows generic ferredoxin to2Fe2S reactive parts. KEGG R00296 returned404 for the attempted request only. EC2.7.2.15 remains a valid propionate-kinase class with acetate substrate overlap, not a silently corrected source annotation.
- Five full ENA CDS translations match the five current pointed UniProt proteins exactly. Q50538's separate U66032 partial CDS matches only its16-aa prefix. ENA strainTM-1 and issuer collection-reference synonyms do not close ORG-5913's missing native taxonomy pointer. No absent native sequence or unpointed Ack/Pta/Mtr accession is invented.
- Whole ACDS exclusion, exact component coefficients, presumed thermophila Mtr, limited barkeri context, CdhD/E factor-III uncertainty, historical cofactor annotations, native membrane assertions, alternative cofactors/substrates and chemical-inhibition scope all remain explicit. No2Na transport, membrane side, seventhAcs or methane completion is borrowed.

Frozen source manifest `06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5`; independently accepted source review manifest `d18d6d594d87721ff4e4e53b69a1fecf166b645357d5c571c2604e95e2f9cd2d`. All 1,013 review files were verified and its full reports read. All 32 accepted source claims and bound evidence remain intact. I authored the source/issuer work; the source acceptance is by a distinct peer. This issuer packet awaits a different independent review.

Actual270 merge is root-reported/receipt-bound at `63ebb3b3e29ca1ed6472597104347d9fbc98f4a5`, tree `5448122efcfbd8ae2ac90ad42e70557b03d9b78e`,267 records. Candidate-specific baseline/novelty/authority rebinding is separately owned and not claimed here.

Author verification is in `results/author-integrity-checks.json` and `receipts/author-audit-final.stdout`; all recorded checks passed. `results/deterministic-reproduction.json` records seven terminal offline commands and 13 byte-identical analysis outputs. The taxonomy UTC receipt is new by design; original receipt and all selected statement comparisons are preserved. The 14GB cache was not rehashed. Existing 77-file RDKit/runtime bindings and all frozen-source/copy hashes were checked unchanged.

Every owned acquisition/analysis/replay/audit handle is terminal before freeze. No helper, install/repair, maintained/Git/GitHub/schema/authority mutation occurred. The top-level manifest and freeze proof enumerate every physical file, including hidden/ignored files, with only their declared self-reference exclusions. All earlier failures remain visible. Licensing stays deferred. Parent owns retention, independent review, graph design and any later curation.
