# Bounded reproduction

Use a new scratch owner; do not run scripts in this frozen owner. Copy the required inputs and scripts, changing only the scratch `O` constant. The copied `inputs/frozen-issuer` is byte-exact and complete. General scripts use `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`; chemistry scripts use `/private/tmp/npmech-rdkit-2026.03.5/bin/python3.13 -B` and `RDBASE=/private/tmp/npmech-rdkit-2026.03.5/share/RDKit`. Set `PYTHONDONTWRITEBYTECODE=1` and `PYTHONNOUSERSITE=1`. No installation is required or authorized.

The independently authored scripts are `independent_chemistry.py`, `independent_representation_limits.py`, `independent_rhea.py`, `independent_sequences_taxa.py` and `independent_bindings.py`. They write only their new scratch results. Sequence/taxonomy checks use the existing read-only pinned cache and preserve the full-cache-proof reuse distinction. Runtime/intake/final-integrity scripts are provenance checks, not additional scientific review. Old failed script attempts are evidence and must not replace final scripts.

All five final scientific/binding commands exited0, as did runtime/intake/final-integrity commands. Logs and structured checks are retained. No need to repeat a full maintained suite, a14GB cache hash, or source acquisition to assess this bounded review.
