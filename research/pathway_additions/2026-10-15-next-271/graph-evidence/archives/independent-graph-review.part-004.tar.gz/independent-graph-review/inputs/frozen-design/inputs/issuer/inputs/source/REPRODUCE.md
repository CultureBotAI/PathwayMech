# Reproduction and reading guide

Do not run writers inside this frozen owner. Copy the complete packet into a new scratch directory, then replace the hard-coded `R`/owner path in copied scripts only. The immutable originals and receipts permit offline reproduction; network responses are not expected to be byte-stable.

Use the existing `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`. No installation or runtime repair is required or authorized here.

1. Verify every manifest entry's length/hash and the complete physical file set, including hidden and ignored files. The manifest and freeze proof are the only deliberate manifest exclusions.
2. `build_native_ledgers.py` reproduces complete own slots, nested frame occurrences, full objects, selected forward closure, member equations and biological inventories from the retained native XML.
3. `assess_native_scope.py` applies explicit author scope dispositions to all 269 objects, 45 activities, 27 regulations and 18 component occurrences.
4. `build_claims.py` reproduces 32 claim entries from exact source files and retained reading receipts. This is an author assessment, not an independent validator of scientific truth.
5. `audit_packet.py` verifies input/copy equality, selected reuse chains, raw/promoted response equality, source envelopes, slot locators, finite closure, claim bindings and primary response classifications. Source paths refer to immutable predecessor owners; if those are unavailable, verify the retained copies/manifests and disclose the narrower replay scope instead of pretending to rehash unavailable live ancestors.

The native traversal plan is in `plan_native.py`; successive occurrence/job/reuse files show every expansion. `acquire_native.py` preserves attempts before accepting exact full responses. It must not be rerun into this packet. `acquire_primary.py` similarly preserves raw bodies and discriminates PDF magic from HTML; the final access ledger does not mistake HTTP200 for full-text success.

The PDFKit binary and Swift source used unchanged are copied and bound under `inputs/runtime-provenance/` and `receipts/pdf-reader-binding.json`. Its command is `read_pdf INPUT OUTPUT_DIRECTORY`; local execution generated complete text and page PNGs. The copied binary is retained provenance, not a request to install or compile a new runtime.

Native provenance: `results/native-provenance-index.json`, `receipts/*-reuses.json`, `receipts/discovery-native-reuse.json`, `receipts/NA-reuse-chain.json`, `results/reuse-manifest-membership.json`.

Scientific reading: `results/claim-ledger.json`, `ASSESSMENT.md`, `results/native-comments.json`, `results/native-citation-leads.json`, native full originals, retained publisher-tool text receipts, and the two primary PDF bodies. Metadata JSON/NCBI front-matter XML is not full article text. `reading/native-noneditorial-own-slots.txt` is a convenience projection; exact originals govern.

Earlier diagnostic iterations are preserved: nested-parent overcount, alternative-wrapper omission, scalar-EC projection correction, and a missing local receipt filename in the first claim-builder run. They document corrected author tooling, not source disappearance. The final ledgers and final audit receipts supersede those provisional projections without altering source bytes.
