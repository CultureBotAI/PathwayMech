# METH-ACETATE-PWY bounded source preparation

Ready for independent source-preparation review, with the limits below. This is an author handoff, not independent acceptance, a graph design, an authority implementation, or approval to add a maintained record.

The accepted discovery and independent preflight are preserved completely in `inputs/accepted-preflight/` (499 physical files, including the discovery). Their exact bindings are in `inputs/predecessor-bindings.json`. Discovery manifest: `c602b4d2e491b1efd99769a988b34930f096d78049ac1fa9874fe1de379aa97b`; preflight manifest: `493020bca61eaaea938a0c3730ebf6fabc5fc036698776fc963fbbccce44bf23`. The preflight's full REVIEW and HANDOFF were read. Its acceptance covers this preparation step only.

The retained baseline is the 266-record landing `e8ae5e445d3288717c31d3012611e226fd5cca34`, tree `1c03509290f5c76048cb293bdd19c1f57143059c`. Pending270 is not treated as landed. Actual270 merged-baseline rebinding remains required before authority implementation or maintained curation. No fresh novelty or global historical absence claim is made here. Prior hidden/ignored-inclusive and finite decoded-archive searches are reused only at their recorded exact-byte scope; this task did not repeat or broaden them.

## Native closure

There are **269 full native objects**: 6 reactions, 52 compounds, 65 proteins/classes, 45 activities, 34 genes, 32 organisms, 27 regulations, 3 locations and 5 root/boundary pathways. Every original retains the full source response, metadata and identity envelope. New acquisition accounts for 241 objects; 9 originals are reused from accepted discovery and 19 from frozen270, with the sodium original's ancestry through frozen269 explicitly retained. All original hashes, successful requests and reuse chains are indexed in `results/native-provenance-index.json` and the associated receipts. No fresh retrieval is claimed for reused bodies. Native source version is META27; acquisition times can differ.

The selected route remains **6 members, 5 ordering links, 29 material occurrences / 19 material IDs, and 7 direct native taxa**. No additional Acs, methane-reductase, respiratory or transport member is added. Exact full-reaction sides, coefficients, root-selected direction and source reversible direction are separate in the member ledgers. None of the 29 material occurrences carries an explicit compartment. Methyl-CoM is the endpoint; METHFORM, cofactor pathways and the superpathway remain boundary context.

The finite traversal covers all selected own enzyme, component, cofactor, alternative-cofactor/substrate, regulation, location, gene/product and species endpoints. **338 selected forward reference occurrences resolve to full originals**. It does not recurse through class membership, parent hierarchies, reaction backlinks, citation/editorial objects or arbitrary links in comments. **3,628 own slots and 61,473 nested frame-reference occurrences** are retained with exact source locators and role dispositions. This larger occurrence count includes repeated embedded context, not 61,473 biological assertions. The final no-new-target traversal is `closure7-jobs.json`.

All **45 activity occurrences** are individually disposed: 7 qualified methanogenic native contexts and 38 other-organism contexts. A source's `physiologically-relevant=true` is not sufficient to transfer a shared-reaction activity into this pathway. The seven qualified contexts retain uncertainty, particularly the presumed thermophila Mtr. All 27 regulation objects remain visible; 7 concern the qualified activity set, 20 remain other-context annotations. Chemical inhibition does not automatically imply physiological regulation. All 18 component occurrences are preserved; 8 belong to the qualified source hierarchy, including the whole ACDS assembly explicitly excluded as the isolated RXN-12908 enzyme.

## Scientific prerequisites retained

The claim ledger has **20 native/source-comparison and 12 primary-reading entries** with exact files, hashes and locators. It is the detailed claim authority for this handoff. Source statements and primary interpretations are kept distinct.

- Keep Methanothrix associations and the Ack/Pta root members visible together; do not silently remove taxa or insert a seventh activation reaction.
- ORG-5913 remains a native species-rank class with no own NCBI pointer. Historical TM-1 naming does not itself close an external strain identity.
- Keep the absent direct Reaction names, ACETATEKIN's EC-2.7.2.15 anomaly and MTR's partial EC-2.1.1 annotation. Nested activity names are not direct Reaction labels.
- Keep the sarcinapterin CML/formula/InChI/short-SMILES discrepancy. Other illustrative `[R]`, nucleobase and carrier strings also prevent automatic chemical equivalence. Generic corrinoid and ferredoxin Protein classes remain generic.
- Preserve CPLX-461's exclusion for RXN-12908, while retaining its component hierarchy and CPLX-442/ENZRXN-19881 identity. Native source component coefficients are not interchangeable with every historical preparation's mass estimate.
- Preserve the unlocated equations and the exact native membrane locations; no sodium transport coefficient, membrane side, or methanopterin-specific scope is borrowed from270.
- Keep the CdhD/CdhE cofactor uncertainty, historical alpha versus beta mechanistic assignments, and exact whole-complex versus component evidence scope explicit. Native assertions do not become primary experimental results merely because a paper is cited nearby.
- Keep all alternative substrates/cofactors, source gene/protein xrefs and the seven source chemical inhibition assertions available for later qualified representation. Exact issuing sequence/strain identities and unread native primary citations remain separate prerequisites.
- The root's generic methyl-CoM disproportionation and methanophenazine background is not accepted as the net equation or universal mechanism of this acetate boundary.

## Primary access and reading

There were **40 bounded HTTP primary/metadata access attempts** in this owner. All response bodies, including failed and misleading HTTP200 HTML responses, and exact receipts are preserved. `results/primary-access-ledger.json` classifies them. Two genuine PDF bodies were retained: Terlesky's institutional dissertation and Gong2008's institutional main-paper reprint. Neither is mislabelled as a newly obtained publisher download.

Primary full-text reading supports seven paper-level scopes: Terlesky1986 through the publisher extraction; Terlesky1987 through the dissertation's Section IV manuscript; Abbanat1990 and Jetten1989 through publisher extractions; selected cdhABC and cdhDE primary sections through publisher extractions; and Gong2008 through its retained main PDF. The exact read sections and distinctions are in P01–P09. The web-tool text receipts are retained projections of publisher content, **not hashes of original journal PDF bytes**. Table and figure interpretations are limited to readable extraction or the specifically inspected local page images.

Allen/Zinder CALS-1, Grahame/DeMoll1996, Abbanat1991 and Balbo2003 remain **abstract-only** (P06/P10–P12); their inaccessible mains were not read. The separate root-cited Deppenmeier review remains an indexed review lead, not a primary experiment. Later native citations, including Gencic2010 and inhibitor-specific papers, were not all acquired or independently read. Their database annotations are preserved at source-only scope.

Gong's main explicitly points to supporting information; the exact linked SI index returned403 and was inaccessible through the web tool. No SI content is claimed read. For the older papers, the bounded accessible views did not supply retained SI originals; this is not a global claim that no supplement exists. No authentication bypass or paid access was used.

The existing PDFKit reader rendered all149 dissertation pages and all6 Gong pages. Reading was selective for the dissertation: front matter and Section IV body, with relevant table/method/discussion context. Local visual inspection covered dissertation PDF pages64,69,73 and Gong pages1,2,5. Rendering all pages does not mean all pages were read. Web screenshot requests produced no inspectable image in this tool channel (one explicitly failed); they are not counted as visual verification.

## Boundaries and release

All scientific source material remains provisional for peer review. No final pathway YAML, authority term, graph, schema or governed file was authored. No maintained/Git/GitHub mutation, environment installation/repair or helper agent was used for this task. Only existing verified runtimes were used. Licensing review remains deferred under the user's instruction.

Next stages are independent source review; bounded issuer identity/chemistry/strain review; actual merged270 baseline rebind; complete graph design; authority implementation/review; and eventual maintained record review with corpus gates. This source preparation does not pre-accept any of those stages.
