# Reproduction

Do not run hardcoded-output scripts in this frozen owner. Copy the packet to a new scratch directory and replace the `R`/`O` owner literals in the copied scripts with that new location before running analyses. Existing frozen source packets are read-only provenance; no network refresh is required for the comparisons.

General runtime: `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`.

Chemistry runtime: `/private/tmp/npmech-rdkit-2026.03.5/bin/python3.13 -B`, with `RDBASE=/private/tmp/npmech-rdkit-2026.03.5/share/RDKit`, `PYTHONDONTWRITEBYTECODE=1` and `PYTHONNOUSERSITE=1`. Verify `results/runtime-verification.json` before using it; do not substitute or install an environment.

Offline analysis scripts, in order:

1. `scripts/chemistry.py`: all41 selected native material representations and direct ChEBI/KEGG candidates.
2. `scripts/followup_chemistry.py`: sarcinapterin/methanopterin distinctions, exact phosphate follow-up and bounded native equation balances.
3. `scripts/proteins.py`: complete ENA feature/translation replay, five protein comparisons and native own biological slots.
4. `scripts/rhea_all_bounded.py`: complete pinned RDF parse, five families, obsolete seed and selected statements. The two earlier parsers intentionally have narrower scope.
5. `scripts/taxonomy.py`: read-only pinned cache statements/lineages, prior-row controls and actual query receipt. Requires the same verified local cache; do not download a substitute. The new query UTC differs by design.
6. `scripts/dispositions.py` and `scripts/access_index.py`: complete finite object/pointer dispositions and acquisition/reuse index.

`results/deterministic-reproduction.json` records the author replay commands, exit codes and exact output hashes. `scripts/audit.py` checks source/copy bindings, all original response hashes, exact identity/type/chemical/sequence/reaction invariants, exclusions and runtime/cache stability. It is an author integrity check, not independent scientific acceptance or repository CI.

Acquisition scripts and every failed/successful request are preserved for provenance; replaying the scientific comparisons does not require repeating them. Initialization/intake scripts assert that their targets do not already exist and should not be rerun over a populated packet. The manifest/freeze proof inventories every physical file, including hidden/ignored files, except the two top-level self-referential proof files as explicitly declared.
