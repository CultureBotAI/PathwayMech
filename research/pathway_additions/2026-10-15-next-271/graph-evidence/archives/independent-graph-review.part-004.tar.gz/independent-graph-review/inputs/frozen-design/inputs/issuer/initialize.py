from pathlib import Path
import collections,hashlib,json,shutil,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-271-issuer-preparation');S=Path('/private/tmp/pathwaymech-next-271-source-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(R/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
for n in ['inputs/source','originals','receipts','results','scripts','reading','iterations']:(R/n).mkdir(parents=True,exist_ok=True)
m=json.loads((S/'artifact-manifest.json').read_text());assert sha(S/'artifact-manifest.json')=='06444fda09c36096c256160ac155fa074b66655e95f42377b891fa7d6c5129e5'
for x in m['files']:assert sha(S/x['path'])==x['sha256'] and (S/x['path']).stat().st_size==x['bytes']
assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
chosen=['artifact-manifest.json','freeze-proof.json','HANDOFF.md','ASSESSMENT.md','OPERATIONS.md','REPRODUCE.md','results/claim-ledger.json','results/native-object-inventory.json','results/native-forward-closure.json','results/native-closure-summary.json','results/all-45-activity-dispositions.json','results/all-27-regulation-dispositions.json','results/all-component-dispositions.json','results/all-native-object-dispositions.json','results/native-provenance-index.json','results/member-equations.json','results/member-material-occurrences.json','results/native-comments.json','results/gene-ledger.json','results/taxon-ledger.json','results/material-identity-ledger.json']
chosen += [str(p.relative_to(S)) for p in (S/'originals/native').glob('*.xml')]
bindings=[]
for n in chosen:
 p=S/n;dst=R/'inputs/source'/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst);bindings.append({'source':str(p),'copy':str(dst.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
put('inputs/source-bindings.json',bindings);put('results/source-manifest-verification.json',{'manifest_sha256':sha(S/'artifact-manifest.json'),'verified_listed':len(m['files']),'physical_files':len(m['files'])+2,'copied_files':len(bindings),'scope':'Full physical source packet verified; selected source bodies/ledgers copied. Other source evidence remains exact frozen reuse, not omitted or freshly acquired. Source scientific independent review pending.'})
objects={x.get('frameid'):x for p in (R/'inputs/source/originals/native').glob('*.xml') for x in E.parse(p).getroot() if x.tag!='metadata'}
forward=json.loads((S/'results/native-forward-closure.json').read_text());adj=collections.defaultdict(set)
for x in forward:adj[x['owner']].add(x['target'])
activities={'ENZRXN-481','ENZRXN-482','ENZRXN-541','ENZRXN-362','ENZRXN-18980','ENZRXN-19881','ENZRXN-24491'}
q=activities|{'CPLX-461'};todo=list(q)
while todo:
 f=todo.pop()
 for t in adj[f]:
  if t not in q:q.add(t);todo.append(t)
root=objects['METH-ACETATE-PWY'];members={x.get('frameid') for x in root.findall('reaction-list/Reaction')};materials={x['frame'] for x in json.loads((S/'results/member-material-occurrences.json').read_text())};taxa={x.get('frameid') for x in root.findall('species/Organism')};ranges={x.get('frameid') for x in root.findall('taxonomic-range/Organism')}
selected=q|members|materials|taxa|ranges|{'METH-ACETATE-PWY'};rows=[];pointers=[]
for f,o in sorted(objects.items()):
 roles=[]
 if f in materials:roles.append('member material')
 if f in members:roles.append('member reaction')
 if f in activities:roles.append('qualified activity, preserving source/primary limits')
 if f in q:roles.append('qualified forward hierarchy/context, not an automatically accepted graph assertion')
 if f in taxa:roles.append('direct native organism association')
 if f in ranges:roles.append('range context only')
 if f=='METH-ACETATE-PWY':roles.append('source root boundary')
 rows.append({'frame':f,'type':o.tag,'class':o.get('class')=='true','label':o.findtext('common-name'),'selected':f in selected,'roles':roles or ['excluded other-activity/boundary context; native original retained, no broad issuer expansion']})
 for i,s in enumerate(o.findall('dblink'),1):
  p={'owner':f,'type':o.tag,'selected_owner':f in selected,'db':s.findtext('dblink-db'),'id':s.findtext('dblink-oid'),'relationship':s.findtext('dblink-relationship'),'native_url':s.findtext('dblink-URL'),'locator':f"/ptools-xml/{o.tag}[@frameid='{f}']/dblink[{i}]"}
  p['disposition']='identity candidate; issuer verification required' if f in selected and p['relationship'] in ('unification','PART-OF') else 'family/related/context pointer, not exact identity; no broad resolution'
  pointers.append(p)
put('results/all-269-identity-scope-dispositions.json',rows);put('results/direct-public-pointer-inventory.json',pointers)
cats={}
for typ in sorted({x['type'] for x in rows}):cats[typ]=[x['frame'] for x in rows if x['selected'] and x['type']==typ]
summary={'source_objects':269,'selected_native_objects':len(selected),'selected_by_type':{t:len(fs) for t,fs in cats.items()},'selected_ids_by_type':cats,'member_materials':len(materials),'member_reactions':len(members),'qualified_activities':len(activities),'direct_root_taxa':len(taxa),'range_taxa':len(ranges),'excluded_activity_count':38,'selected_public_pointer_occurrences':sum(x['selected_owner'] for x in pointers),'selected_candidate_pointer_by_db':dict(collections.Counter(x['db'] for x in pointers if x['selected_owner'] and x['relationship'] in ('unification','PART-OF'))),'all_other_native_objects_retained_with_exclusion':len(objects)-len(selected),'scope':'Finite provisional issuer inventory from frozen source; graph/authority selection and independent source acceptance pending.'}
put('results/initial-identity-scope.json',summary);print(json.dumps(summary,indent=2))
