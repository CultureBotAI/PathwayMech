from pathlib import Path
import json,hashlib,html,re,sys
from collections import Counter
from lxml import etree as ET
import yaml
O=Path(__file__).resolve().parents[1]; I=O/'inputs/issuer'; S=I/'inputs/source'; B=O/'inputs/baseline'
sys.path.insert(0,str(B/'src'))
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(rel,d):p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def cur(f):return 'MetaCyc:'+f
def text(s):return ' '.join(html.unescape(re.sub('<[^>]+>','',s or '')).split())
inv={x['frame']:x for x in load(S/'results/native-object-inventory.json')}
disps={x['frame']:x for x in load(I/'results/all-91-issuer-dispositions.json')}
all269=load(I/'results/all-269-identity-scope-dispositions.json')
objs={f:ET.parse(str(S/inv[f]['path'])).getroot().find(inv[f]['type']) for f in disps}
assert all(e is not None for e in objs.values())
base=lambda f:f"/ptools-xml/{inv[f]['type']}[@frameid='{f}']"
root='METH-ACETATE-PWY';r=objs[root]
terms=load(B/'data/identifier_authorities/sources.json')['terms']; ont=load(B/'data/identifier_authorities/ontology.json')['terms']
provenance={x['frame']:x for x in load(S/'results/native-provenance-index.json')}
references={};refproof=[]
for f,e in objs.items():
 p=provenance[f];receipts=p.get('original_receipts',[p['receipt']]); receipt=None
 for rel in receipts:
  d=load(S/rel)
  if isinstance(d,dict) and d.get('status')==200 and d.get('sha256')==inv[f]['sha256']:receipt=(rel,d);break
  if isinstance(d,dict) and d.get('row',{}).get('sha256')==inv[f]['sha256'] and d.get('original_url'):receipt=(rel,{**d,'url':d['original_url']});break
 assert receipt,f
 rel,d=receipt;url=d['url'];assert url.startswith('https://') and 'getxml?META:' in url
 references[cur(f)]={'id':cur(f),'title':f'MetaCyc 27.0 native {inv[f]["type"]} {f}','url':url,'source_version':'MetaCyc PGDB 27.0; exact retained full-object response; acquisition/reuse chain in source ledger','source_sha256':inv[f]['sha256']}
 refproof.append({'id':cur(f),'body':str((S/inv[f]['path']).relative_to(O)),'sha256':inv[f]['sha256'],'request_receipt':str((S/rel).relative_to(O)),'receipt_sha256':sha(S/rel),'request_url':url,'self_reported_xml_base':inv[f]['envelope_attributes'].get('{http://www.w3.org/XML/1998/namespace}base'),'provenance':p,'scope':'Original/reuse; no fresh network call in graph design.'})
# Primary claims retain original selected/full/abstract reading levels; references bind the retained original or tool projection, never a claimed inaccessible PDF.
claims=load(S/'results/claim-ledger.json');primary={x['id']:x for x in claims if x['id'].startswith('P')}
for c in primary.values():
 pid='PMID:'+c['pmid'];proof=c['evidence'][0];q=S/proof['path'];assert q.is_file() and sha(q)==proof['sha256']
 if pid not in references:
  references[pid]={'id':pid,'title':'Primary publication '+c['pmid']+'; '+c['evidence_level'],'url':'https://pubmed.ncbi.nlm.nih.gov/'+c['pmid']+'/','source_version':c['evidence_level']+'; source_sha256 covers retained '+proof['path']+', not necessarily journal PDF','source_sha256':proof['sha256']}
  refproof.append({'id':pid,'body':str(q.relative_to(O)),'sha256':proof['sha256'],'scope':c['evidence_level']})
# Issuer originals are comparison evidence only, no mappings.
for acc in ['Q08368','P72020','P72021','Q50538','Q50539']:
 q=I/'originals'/('UniProt-'+acc+'.json');d=load(q)
 references['UniProtKB:'+acc]={'id':'UniProtKB:'+acc,'title':'UniProtKB '+acc+' issuing protein record','url':'https://rest.uniprot.org/uniprotkb/'+acc+'.json','source_version':'Exact retained JSON; issuing annotation/sequence comparison, not an alias or independent new assay','source_sha256':sha(q)}
 refproof.append({'id':'UniProtKB:'+acc,'body':str(q.relative_to(O)),'sha256':sha(q),'scope':'Direct pointed issuing original; native sequence absent; annotations retain their own inference/evidence.'})
for id in ['59924','64267']:
 q=I/'originals'/('ChEBI-'+id+'.json')
 references['CHEBI:'+id]={'id':'CHEBI:'+id,'title':'ChEBI '+id+' structure comparison','url':'https://www.ebi.ac.uk/chebi/backend/api/public/compound/'+id+'/','source_version':'Retained issuing original; compared structure only, no exact alias promotion','source_sha256':sha(q)}
 refproof.append({'id':'CHEBI:'+id,'body':str(q.relative_to(O)),'sha256':sha(q),'scope':'Issuer formula/charge/InChI comparison.'})
for id in ['17829','21040']:
 q=I/'originals/rhea.rdf.gz'
 references['RHEA:'+id]={'id':'RHEA:'+id,'title':'Rhea '+id+' retained release 142 statements','url':'https://rdf.rhea-db.org/'+id,'source_version':'Pinned release 142; source_sha256 covers complete compressed RDF, not a live response','source_sha256':sha(q)}
 refproof.append({'id':'RHEA:'+id,'body':str(q.relative_to(O)),'sha256':sha(q),'scope':'Selected statements independently replayed in issuer packet; whole compressed input retained, no fresh network receipt.'})
q=I/'originals/EC-2.7.2.15.html'
references['EC:2.7.2.15']={'id':'EC:2.7.2.15','title':'ExPASy enzyme nomenclature EC 2.7.2.15','url':'https://enzyme.expasy.org/EC/2.7.2.15','source_version':'Exact retained issuing HTML; definition is distinct from native annotation','source_sha256':sha(q)}
refproof.append({'id':'EC:2.7.2.15','body':str(q.relative_to(O)),'sha256':sha(q),'scope':'Valid propionate-kinase definition includes acetate substrate scope; no native correction inferred.'})
# Six direct NCBI taxa, no guessed public ORG-5913 equivalence or range expansion.
taxrows=load(I/'results/taxonomy-complete-selected-statements.json');taxa=[];taxledger=[]
for j,slot in enumerate(r.findall('species'),1):
 f=slot[0].get('frameid');e=objs[f];dbl=e.find("dblink[dblink-db='NCBI-TAXONOMY-DB']")
 row={'native':cur(f),'native_label':text(e.findtext('common-name')),'native_rank':e.findtext('rank'),'root_locator':base(root)+f'/species[{j}]','public_id':None,'declared':False}
 if dbl is not None:
  id='NCBITaxon:'+dbl.findtext('dblink-oid');rows=taxrows[id];label=next(x['value'] for x in rows if x['predicate']=='rdfs:label');rank=next(x['object'] for x in rows if x['predicate']=='obo:ncbitaxon#has_rank')
  row.update(public_id=id,issuing_label=label,issuing_rank=rank,declared=True,existing_authority=id in ont,statement_source='inputs/issuer/results/taxonomy-complete-selected-statements.json',statement_locator=f"$['{id}']")
  taxa.append({'id':id,'label':label})
  references[id]={'id':id,'title':'Pinned NCBI Taxonomy '+label,'url':'https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id='+id.split(':')[1],'source_version':'ncbitaxon 2026-07-12 pinned SQLite; source_sha256 is the documented complete database hash; selected issuing rows retained, no individual URL response claimed','source_sha256':'89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d'}
 else:row['disposition']='Exact seventh native species-rank association preserved on membership incident edges; no guessed NCBI equivalent or native Organism authority.'
 taxledger.append(row)
taxledger.append({'native':'MetaCyc:TAX-28890','native_label':'Euryarchaeota','native_rank':'phylum','public_id':'NCBITaxon:28890','issuing_label':'Methanobacteriota','declared':False,'root_locator':base(root)+'/taxonomic-range[1]','disposition':'Range only, not a direct association; label difference retained.'})
# Native graph node selection follows biochemical roles, not all 91 research objects.
cofactor_ids={x.get('frameid') for f,e in objs.items() if inv[f]['type']=='Enzymatic-Reaction' for x in e.xpath('./cofactor/*[@frameid] | ./alternative-cofactor/alternate/*[@frameid]')}
graphframes=[f for f in disps if inv[f]['type'] not in ['Gene','Organism','Regulation']]
nodes=[]
for f in graphframes:
 e=objs[f];typ=inv[f]['type'];term=terms.get(cur(f));label=term['label'] if term else text(e.findtext('common-name')) or f
 cat={'Pathway':'pathway','Reaction':'molecular_activity','Enzymatic-Reaction':'molecular_activity','cco':'cellular_component'}.get(typ)
 if typ=='Compound':cat='cofactor' if f in cofactor_ids else ('chemical_entity' if inv[f]['class'] else 'small_molecule')
 if typ=='Protein':cat='complex' if any(x.get('frameid')=='Protein-Complexes' for x in e.xpath('./parent/*')) else 'protein'
 section='root' if typ=='Pathway' else 'reactions' if typ=='Reaction' else 'participants'
 node={'id':cur(f),'label':label,'category':cat}
 if typ=='Reaction':node['direction']='reversible'
 nodes.append({'frame':f,'declaration':node,'section':section,'native_type':typ,'native_class':inv[f]['class'],'native_body':str((S/inv[f]['path']).relative_to(O)),'native_sha256':inv[f]['sha256'],'native_identity_locator':base(f),'name_policy':'existing exact authority owner' if term else 'direct own common-name' if e.find('common-name') is not None else 'exact frame token; no nested label promotion','existing_authority':term,'issuer_disposition':disps[f]['disposition']})
assert len(nodes)==69 and sum(x['existing_authority'] is not None for x in nodes)==17
# Every graph assertion cites an exact own slot. Supplementary source qualification rides on incident descriptions/evidence.
edges=[];edgemeta=[]
def ev(f,slot,assertion):
 assert len(assertion)<=400,(f,len(assertion),assertion)
 loc=base(f)+(('/'+slot) if slot else '')
 assert ET.ElementTree(objs[f]).getroot() is not None
 tree=ET.parse(str(S/inv[f]['path']));assert tree.xpath(loc),(f,loc)
 return {'reference_id':cur(f),'source_assertion':assertion,'source_locator':loc}
def add(kind,s,p,o,desc,evidence,**meta):
 id=f'native-{len(edges)+1:03d}'
 edge={'id':id,'subject':cur(s),'predicate':p,'object':cur(o),'description':desc,'evidence':evidence}
 edges.append(edge);edgemeta.append({'id':id,'kind':kind,'source_scopes':meta,'edge':edge});return edge
root_scope='This is a source-selected route ending at methyl-CoM, not completed methane production. The native direct associations include two genera and four publicly pointed species plus species-rank ORG-5913 (Methanosarcina TM-1), whose own object has no NCBI pointer. TAX-28890 is range only. Methanothrix associations are retained although condition-specific Opfikon/CALS-1 evidence supports Acs activation; no seventh Acs reaction or universal Ack/Pta operation is inferred.'
root_evidence=[ev(root,'species[7]','The seventh direct native association is ORG-5913, labelled Methanosarcina TM-1 with species rank; its full own object has no dblink.'),ev('ORG-5913','rank[1]','ORG-5913 has native rank species; a strain-like label does not establish an external equivalent.'),ev(root,'taxonomic-range[1]','TAX-28890 is the root taxonomic range, separate from seven direct species-slot associations.')]
for j,slot in enumerate(r.findall('species'),1):root_evidence.append(ev(root,f'species[{j}]',f'Native direct organism association {slot[0].get("frameid")} is preserved at its supplied rank; association alone is not universal route flux.'))
equations={x['frame']:x for x in load(S/'results/member-equations.json')}
rxscope={
 'ACETATEKIN-RXN':'Native EC-2.7.2.15 is retained. It is a valid propionate-kinase definition with acetate substrate scope, while the native reaction is labelled only by its frame. Do not silently rename or replace it. Thermophila Ack and Methanothrix Acs evidence remain distinct.',
 'PHOSACETYLTRANS-RXN':'The root selects acetate activation, opposite the source left/right equation. Thermophila Pta source membrane placement does not locate the equation materials or establish that all associated genera use Ack/Pta.',
 'ACETYLSYNCLTH-RXN':'Generic corrinoid Protein classes retain their Co(I)/methylated states; no exact polypeptide alias. Native beta activity has no own direction. Artificial-donor whole-complex synthesis and spectroscopic evidence are not isolated physiological cleavage proof.',
 '1.2.7.4-RXN':'The two ferredoxin states remain generic Protein classes. Rhea:17829 is obsolete with literal replacement comment naming Rhea:21040; the named family uses narrower [2Fe-2S] reactive parts. Neither replacement nor KEGG request failure establishes exact native identity.',
 'RXN-12908':'CPD-8 and CPD-9 are distinct full sarcinapterins despite identical incomplete short SMILES; no methanopterin substitution. Whole CPLX-461 is explicitly enzymes-not-used. CPLX-442/ENZRXN-19881 remains the source component association; native subunit cofactor assignments conflict.',
 'MTRMBARK-RXN':'Native partial EC-2.1.1 remains partial. The sarcinapterin equation ends at methyl-CoM; no 2 Na transport, membrane side, methane completion or eight-subunit expansion is borrowed from H2/CO2 methanogenesis. Thermophila activity remains presumed, barkeri activity incompletely characterized.'}
for j,m in enumerate(r.find('reaction-list'),1):
 f=m.get('frameid');eq=equations[f]
 add('membership',root,'has_part',f,'Native reaction membership. '+root_scope+' '+rxscope[f], [ev(root,f'reaction-list[1]/Reaction[{j}]',f'{f} is one of six explicit root members; no neighboring pathway or Acs member is added.')]+root_evidence,member_index=j)
for j,order in enumerate(r.findall('reaction-ordering'),1):
 dest=order.find('Reaction').get('frameid');src=order.find('predecessor-reactions/Reaction').get('frameid')
 add('order',src,'precedes',dest,'Native predecessor link, not a flux measurement or a statement that graphical layout establishes channeling. '+rxscope[src]+' '+rxscope[dest],[ev(root,f'reaction-ordering[{j}]',f'{src} is a direct predecessor of {dest} in the native root ordering.')],ordering_index=j)
layouts={x.find('Reaction').get('frameid'):(j,x.findtext('direction')) for j,x in enumerate(r.findall('reaction-layout'),1)}
for f,eq in equations.items():
 layoutidx,direction=layouts[f]
 for side in ['left','right']:
  for j,m in enumerate(eq[side],1):
   inp=(side=='left')==(direction=='L2R');mat=m['frame'];s,o=(mat,f) if inp else (f,mat);pred='consumes' if inp else 'produces'
   directionnote=f'Own reaction direction REVERSIBLE; root selects {direction}. This occurrence has coefficient {m["coefficient"]}'+(' explicitly supplied' if m['coefficient_explicit'] else ' (implicit default 1)')+' and no supplied compartment.'
   evidence=[ev(f,f'{side}[{j}]',f'Native {side} occurrence {j} is {mat}, coefficient {m["coefficient"]}; no compartment is supplied.'),ev(f,'reaction-direction[1]','The own reaction direction is REVERSIBLE.'),ev(root,f'reaction-layout[{layoutidx}]',f'Root layout selects {direction} for {f}; this does not assert irreversible chemistry.')]
   add('material',s,pred,o,directionnote+' '+rxscope[f],evidence,reaction=f,material=mat,side=side,index=j,coefficient=m['coefficient'],coefficient_explicit=m['coefficient_explicit'],compartments=[],selected_direction=direction)
activity_scope={
 'ENZRXN-18980':'Native thermophila alpha2 epsilon2 component association. Activity direction is absent. EV-EXP-IDA cites PMID3023296, whose acetate-grown whole-complex CO/methyl-viologen assay at 23°C and measured metals are not isolated-component catalytic or essential-cofactor proof.',
 'ENZRXN-19881':'Native thermophila gamma/delta component association, reversible. CPLX-461 is explicitly excluded from RXN-12908. Delta factor-III prose, gamma Fe-S prose and complex CdhE corrinoid prose conflict; low-occupancy heterologous reconstitution does not settle native assignment.',
 'ENZRXN-24491':'Native thermophila beta association; own activity direction absent. The source cites Gencic2010 mechanism prose, whose main was not read. Do not transfer artificial CH3I/CO whole-complex synthesis, partial-proteolysis barkeri results or inferred UniProt annotation into an isolated native cleavage assay.',
 'ENZRXN-362':'Source-only barkeri association, reversible and incompletely characterized. Native commentary discusses methanol oxidation and a possible two-step process. This is not a newly identified sarcinapterin-specific enzyme, universal acetate-route flux, sodium transport or an eight-subunit determination.',
 'ENZRXN-481':'Native thermophila acetate kinase association, reversible, EV-EXP source annotation. ATP may be replaced by TTP, ITP, UTP, GTP or CTP, and acetate by propionate in native alternative-substrate slots. These source alternatives do not alter ACETATEKIN-RXN or assert pathway use of every donor. Mg2+ alternatives are Mn2+, Co2+ and Ca2+.',
 'ENZRXN-482':'Native thermophila Pta association, reversible, EV-EXP source annotation. K+ cofactor, ammonium alternative and membrane placement remain source assertions; equation materials remain unlocated. Do not generalize condition-specific Ack/Pta activities to every Methanothrix association.',
 'ENZRXN-541':'PRESUMED native thermophila association only: the source explicitly says a tetrahydrosarcinapterin-specific enzyme has not been identified and is presumed to exist. Reversible/physiologically-relevant=true flags do not remove this caveat. No sequence, proven catalytic capability or eight-subunit assembly is inferred.'}
activityedges={};alts=[]
activities=[x for x in load(S/'results/all-45-activity-dispositions.json') if x['activity'] in objs]
assert len(activities)==7
for a in activities:
 f=a['activity'];enz=a['enzyme'][0];rx=a['reaction'];e=objs[f]
 common=[ev(f,'enzyme[1]',f'Native activity {f} names {enz} as its enzyme; this is a source association with the stated characterization limits.'),ev(f,'reaction[1]',f'Native activity {f} points to issued reaction {rx}; activity identity remains separate from that reaction.'),ev(enz,'species[1]',f'The own enzyme object assigns {enz} to {a["enzyme_species"][0]["taxa"][0]}; exact strain and preparation are not inferred from species alone.')]
 if e.find('comment') is not None:common.append(ev(f,'comment[1]',activity_scope[f][:400]))
 if e.find('reaction-direction') is not None:common.append(ev(f,'reaction-direction[1]',f'The native activity direction is {a["direction"]}; the record separately preserves the root-selected equation direction.'))
 if e.find('evidence') is not None:
  codes=[x.get('frameid') for x in e.xpath('./evidence/Evidence-Code')]
  common.append(ev(f,'evidence[1]','Native evidence code(s): '+', '.join(codes)+'. Database citation and inference codes do not certify a new reading or an isolated-component assay.'))
 for j,sl in enumerate(e.findall('alternative-substrate'),1):
  standard=sl.find('substrate')[0].get('frameid');alternate=sl.find('alternate')[0].get('frameid')
  evidence=ev(f,f'alternative-substrate[{j}]',f'Native activity lists {alternate} as an alternative to {standard}; this does not change the issued reaction equation or establish physiological use.')
  common.append(evidence)
  alts.append({'activity':f,'standard':standard,'alternate':alternate,'slot_index':j,'evidence':evidence,'proposed_predicate':'has_input','status':'conditional on separately reviewed precise activity-input endpoint-contract correction; not attached to the issued reaction'})
 en=add('enzyme_activity',enz,'enables',f,activity_scope[f],common.copy(),activity=f,enzyme=enz,reaction=rx,scope='Exact source activity association; no experimental promotion.')
 er=add('enzyme_reaction',enz,'enables',rx,activity_scope[f]+' '+rxscope[rx],common.copy(),activity=f,enzyme=enz,reaction=rx,scope='Separate source-qualified enzyme/reaction association, not equivalence of activity and reaction.')
 activityedges[f]=[en,er]
 for tag,path in [('cofactor','./cofactor'),('alternative-cofactor','./alternative-cofactor')]:
  for j,sl in enumerate(e.findall(tag),1):
   alt=tag=='alternative-cofactor';co=sl.find('alternate')[0].get('frameid') if alt else sl[0].get('frameid');std=sl.find('cofactor')[0].get('frameid') if alt else None
   note=f'Native {f} '+(f'lists {co} as an alternative to {std}, not an additional simultaneous requirement.' if alt else f'lists {co} as a cofactor.')
   extra=' CPD-7 and Corrinoids remain generic classes; no precise oxidation/ligation state or subunit site is assigned.' if co in ['CPD-7','Corrinoids'] else ''
   add('alternative_cofactor' if alt else 'cofactor',enz,'has_cofactor',co,note+' '+activity_scope[f]+extra,[ev(f,f'{tag}[{j}]',note)]+common[:3],activity=f,slot_index=j,standard_cofactor=std,alternative=alt)
for c in load(S/'results/all-component-dispositions.json'):
 if c['complex'] not in objs or c['component'] not in objs:continue
 f=c['complex'];co=c['component'];count=c['coefficient_literal'];idx=int(re.search(r'component\[(\d+)\]',c['source_locator']).group(1))
 note=f'Native assembly lists coefficient {count} of {co} in {f}; these are source assembly coefficients, not independent verification in every primary preparation.'
 scope=' Whole ACDS is assembly context and is explicitly enzymes-not-used for RXN-12908; no whole-complex methyltransferase edge is inferred.' if f=='CPLX-461' else ''
 add('composition',f,'has_part',co,note+scope,[ev(f,f'component[{idx}]',note),ev(f,'species[1]','This source assembly is assigned to Methanosarcina thermophila; a barkeri structure or heterologous reconstitution does not establish identical preparation.')],coefficient=int(count),component_index=idx)
for f,e in objs.items():
 for j,sl in enumerate(e.findall('location'),1):
  target=sl[0].get('frameid')
  if target not in objs:continue
  note=f'Native protein {f} has membrane location. This does not assign membrane side, material compartments or transport stoichiometry.'
  scope=activity_scope['ENZRXN-541'] if f=='CPLX-481' else activity_scope['ENZRXN-362'] if f=='CPLX-322' else activity_scope['ENZRXN-482']
  add('location',f,'located_in',target,note+' '+scope,[ev(f,f'location[{j}]',note),ev(f,'has-go-term[1]','The source also points to GO:0016020 (membrane); term identity does not itself demonstrate localization or side.')],location_index=j)
for rg in load(S/'results/all-27-regulation-dispositions.json'):
 if not rg['qualified_context']:continue
 f=rg['frame'];mat=rg['regulator'][0];act=rg['regulated_entity'][0]
 note=f'Native negative regulation {f}: {mat} inhibits exact activity {act}. Its physiological-relevance slot is absent; this is not new physiological regulation evidence.'
 scope=' The cited KCN experiment used whole thermophila complex; verified neutral HCN identity does not supply isolated alpha/epsilon HCN assay support.' if f=='REG-13366' else ' The cited primary experiment is not newly read here; annotation stays native-source-only.'
 add('regulation',mat,'inhibits',act,note+scope+' '+activity_scope[act],[ev(f,'mode[1]','Native regulation mode is negative (-).'),ev(f,'regulator[1]',f'Native regulator is {mat}.'),ev(f,'regulated-entity[1]',f'Native regulated entity is exact activity {act}, not the generic reaction or every catalyst.')],regulation=f,physiologically_relevant=None)
assert len(edges)==83,len(edges)
# Gene/product evidence is context on incident protein edges. No unsupported encodes, gene part_of, or disconnected gene declaration.
geneledger=[]
seqmap={'CDHAMSARC-MONOMER':'Q08368','CDHBMSARC-MONOMER':'P72020','CDHCMSARC-MONOMER':'P72021','CDHDMSARC-MONOMER':'Q50538','CDHEMSARC-MONOMER':'Q50539'}
for f,e in objs.items():
 if inv[f]['type']!='Gene':continue
 prod=e.find('product')[0].get('frameid');targets=[x for x in edges if cur(prod) in [x['subject'],x['object']]]
 note=f'Native gene {f} ({text(e.findtext("common-name"))}) names product {prod}; the source product backlink is preserved as identity context. No gene-to-protein predicate is asserted.'
 evidence=ev(f,'product[1]',note)
 for x in targets:
  x['description']+=' '+note;x['evidence'].append(evidence)
  if prod in seqmap:
   acc=seqmap[prod]
   seqnote=f'The own pointed UniProtKB:{acc} sequence is thermophila taxon 2210 and agrees with the corresponding full ENA CDS translation; native full protein sequence is absent. ENA TM-1 and UniProt reference strain synonyms are issuer-reported, not a new culture-collection equivalence.'
   if prod=='CDHDMSARC-MONOMER':seqnote+=' The U66032 16-residue partial CdhD fragment matches only the prefix; complete CdhD is supported separately by U30484.'
   x['description']+=' '+seqnote
   x['evidence'].append({'reference_id':'UniProtKB:'+acc,'source_assertion':f'Pointed UniProtKB:{acc} reports organism taxon 2210 and a complete sequence; annotation evidence and precursor/processing states remain separate from native protein identity.','source_locator':'$.primaryAccession; $.organism; $.sequence; $.references; $.features'})
 geneledger.append({'gene':cur(f),'product':cur(prod),'label':text(e.findtext('common-name')),'node':False,'predicate':None,'reason':'Gene/product relation is genuine but current schema has no encodes; isolated gene identity does not add a supported mechanistic claim. Retain complete relationship and issuing matches in incident evidence and this ledger.','incident_edges':[x['id'] for x in targets],'evidence':evidence,'issuer_comparison':seqmap.get(prod),'issuer_limit':disps[f]['disposition']})
# Broad source comments are carried as qualified, faithful incident context, never paper quotations.
comment_targets={
 'CDHDMSARC-MONOMER':'Source delta comment assigns factor III. Gamma own comment instead assigns a 4Fe-4S cluster, while complex prose calls CdhE corrinoid/Fe-S. Low-occupancy hydroxocobalamin reconstitution cannot establish a firm native factor-III assignment.',
 'CDHEMSARC-MONOMER':'Source gamma comment assigns a 4Fe-4S cluster. Delta own comment assigns factor III, while complex prose calls CdhE corrinoid/Fe-S; this disagreement is retained, not repaired by issuer annotation or reconstitution.',
 'CDHAMSARC-MONOMER':'Historical native alpha prose assigns centers A/B/C. Later barkeri structure and current issuer annotations have different species/component and nomenclature scopes; no exact metal-site equivalence or universal cluster count is inferred.',
 'CDHCMSARC-MONOMER':'Native beta comment describes a Ni-Ni/[Fe4S4] A cluster, acetyl-enzyme intermediate and two one-electron activation steps citing PMID20202935. That primary main was not read; these remain database prose rather than newly proven mechanism.'}
for f,note in comment_targets.items():
 for x in edges:
  if cur(f) in [x['subject'],x['object']]:x['description']+=' '+note;x['evidence'].append(ev(f,'comment[1]',note))
# Explicit enzymes-not-used and chemistry anomalies are preserved on all relevant edges.
for x in edges:
 if cur('RXN-12908') in [x['subject'],x['object']] or cur('CPLX-461') in [x['subject'],x['object']]:
  x['evidence'].append(ev('RXN-12908','enzymes-not-used[1]','Whole CPLX-461 is explicitly listed as enzymes-not-used for RXN-12908; the component-specific activity remains distinct.'))
 if cur('ACETATEKIN-RXN') in [x['subject'],x['object']]:
  x['evidence'].append(ev('ACETATEKIN-RXN','ec-number[1]','The native reaction retains literal EC-2.7.2.15; no silent replacement by EC-2.7.2.1 is made.'))
  x['evidence'].append({'reference_id':'EC:2.7.2.15','source_assertion':'The issuing entry defines propionate kinase and includes acetate in its substrate scope; validity of the class does not erase the native annotation discrepancy.','source_locator':'Accepted name; Reaction; Comments'})
 if cur('1.2.7.4-RXN') in [x['subject'],x['object']]:
  x['evidence'].append({'reference_id':'RHEA:17829','source_assertion':'Retained release 142 marks Rhea:17829 obsolete and comments that it has been replaced by Rhea:21040. This literal comment is not a structured replacedBy relation or native equation equivalence.','source_locator':"rdf:RDF/rdf:Description[@rdf:about='http://rdf.rhea-db.org/17829']/rh:status; rdfs:comment"})
 for f,ch in [('CPD-8','59924'),('CPD-9','64267')]:
  if cur(f) in [x['subject'],x['object']]:
   note='The full sarcinapterin structure and native charge -4 remain distinct from methanopterin states; identical short native SMILES does not identify the full molecule. Compared ChEBI agreement is not an alias promotion.'
   x['description']+=' '+note
   x['evidence'].append(ev(f,'inchi[1]',f'{f} has its own complete InChI; incomplete short SMILES is not used as complete molecular identity.'))
   x['evidence'].append({'reference_id':'CHEBI:'+ch,'source_assertion':note,'source_locator':'$.default_structure; $.chemical_data'})
# Bind all accepted primary claims to the narrowly relevant incident edges; no new topology from experimental context.
primary_map={
 'P01':lambda m:m['kind'] in ['cofactor','regulation'] and (m['source_scopes'].get('activity')=='ENZRXN-18980' or m['source_scopes'].get('regulation')=='REG-13366'),
 'P02':lambda m:m['kind']=='enzyme_reaction' and m['source_scopes'].get('activity')=='ENZRXN-24491',
 'P03':lambda m:m['kind']=='enzyme_activity' and m['source_scopes'].get('activity') in ['ENZRXN-481','ENZRXN-482'],
 'P04':lambda m:m['kind']=='enzyme_reaction' and m['source_scopes'].get('activity') in ['ENZRXN-24491','ENZRXN-18980'],
 'P05':lambda m:m['kind']=='membership' and m['edge']['object'] in [cur('ACETATEKIN-RXN'),cur('PHOSACETYLTRANS-RXN')],
 'P06':lambda m:m['kind']=='membership' and m['edge']['object']==cur('ACETATEKIN-RXN'),
 'P07':lambda m:m['kind']=='composition' and m['edge']['subject']==cur('CPLX-442'),
 'P08':lambda m:m['kind']=='composition' and m['edge']['object'] in [cur('CDHAMSARC-MONOMER'),cur('CDHBMSARC-MONOMER'),cur('CDHCMSARC-MONOMER')],
 'P09':lambda m:m['kind']=='enzyme_activity' and m['source_scopes'].get('activity')=='ENZRXN-18980',
 'P10':lambda m:m['kind']=='enzyme_activity' and m['source_scopes'].get('activity')=='ENZRXN-24491',
 'P11':lambda m:m['kind']=='composition' and m['edge']['subject']==cur('CPLX-461'),
 'P12':lambda m:m['kind']=='composition' and m['edge']['subject']==cur('CPLX-443')}
claimcoverage=[]
for c in primary.values():
 targets=[m for m in edgemeta if primary_map[c['id']](m)];assert targets,c['id']
 for m in targets:
  x=m['edge'];x['description']+=' Primary scope ('+c['id']+'): '+c['evidence_level']+'. '+c['statement']+' '+c['disposition']
  assert len(c['statement'])<=400
  x['evidence'].append({'reference_id':'PMID:'+c['pmid'],'source_assertion':c['statement'],'source_locator':c['evidence'][0]['locator']})
 claimcoverage.append({**c,'design_edges':[m['id'] for m in targets],'mode':'Qualified primary context on existing native assertion; no new topology or exact aliases.'})
# Contextual native claims: exact full ledgers retain all source scope and frozen peer acceptance.
native_map={'N01':['membership','order','material'],'N02':['material'],'N03':['membership'],'N04':['membership'],'N05':['membership'],'N06':['membership','material'],'N07':['material'],'N08':['material'],'N09':['composition','enzyme_activity','enzyme_reaction'],'N10':['composition'],'N11':['enzyme_activity','enzyme_reaction','location'],'N12':['enzyme_activity','enzyme_reaction','location'],'N13':['cofactor','alternative_cofactor','enzyme_activity','location'],'N14':['cofactor','enzyme_activity'],'N15':['composition','cofactor','enzyme_activity'],'N16':['composition','enzyme_activity'],'N17':['regulation'],'N18':['enzyme_activity','enzyme_reaction'],'N19':['membership'],'N20':['enzyme_activity','enzyme_reaction']}
for c in claims:
 if c['id'].startswith('N'):claimcoverage.append({**c,'design_edges':[m['id'] for m in edgemeta if m['kind'] in native_map[c['id']]],'mode':'Exact source-to-graph family coverage; bounded assertion and exclusion are retained in ledger and relevant incident context.'})
# Final design products. Contract correction remains an explicit conditional dependency.
record={'id':cur(root),'label':next(n['declaration']['label'] for n in nodes if n['frame']==root),'description':'PROSPECTIVE NATIVE GRAPH DESIGN, not maintained curation. '+root_scope+' All six reactions retain reversible source direction and separately selected root orientation. Full chemistry, taxon, activity, construct and source conflicts are carried on incident edge descriptions/evidence. No exact aliases are promoted.','pathway_type':'methanogenesis','taxa':taxa,'participants':[n['declaration'] for n in nodes if n['section']=='participants'],'reactions':[n['declaration'] for n in nodes if n['section']=='reactions'],'mechanistic_edges':edges,'references':list(references.values())}
(O/'design/prospective-record.yaml').write_text(yaml.safe_dump(record,sort_keys=False,allow_unicode=True,width=110))
for n in nodes:n['incident_edges']=[x['id'] for x in edges if n['declaration']['id'] in [x['subject'],x['object']]]
node_dispositions=[]
for x in all269:
 f=x['frame'];node=next((n for n in nodes if n['frame']==f),None)
 decision='graph node' if node else 'reference-only gene/product context' if x['type']=='Gene' and f in disps else 'reference-only regulation source; negative edge represented' if x['type']=='Regulation' and f in disps else 'native taxon association/range context; six verified NCBI declarations separate' if x['type']=='Organism' and f in disps else 'excluded unrelated native context; no biological transfer'
 node_dispositions.append({**x,'graph_disposition':decision,'graph_node':node['declaration'] if node else None,'issuer_disposition':disps[f]['disposition'] if f in disps else None})
coverage=[]
for m in edgemeta:
 for e in m['edge']['evidence']:
  ref=e['reference_id'];p=next((p for p in refproof if p['id']==ref),None)
  coverage.append({'edge_id':m['id'],'kind':m['kind'],'reference_id':ref,'locator':e['source_locator'],'source_assertion':e['source_assertion'],'proof':p})
demand=[{'id':n['declaration']['id'],'label':n['declaration']['label'],'section':n['section'],'category':n['declaration']['category'],'native_type':n['native_type'],'native_class':n['native_class'],'name_policy':n['name_policy'],'existing':n['existing_authority'] is not None,'existing_owner':n['existing_authority'],'original':n['native_body'],'sha256':n['native_sha256']} for n in nodes]
for row in taxledger:
 if row['declared']:demand.append({'id':row['public_id'],'label':row['issuing_label'],'section':'taxa','existing':row['existing_authority'],'rank':row['issuing_rank'],'original':'Pinned taxonomy selected statement rows and previously verified complete cache identity; no fresh URL response.'})
for rel,d in [('results/proposed-native-node-inventory.json',nodes),('results/proposed-native-edge-inventory.json',edgemeta),('results/all269-node-and-context-dispositions.json',node_dispositions),('results/all32-claim-to-design-dispositions.json',sorted(claimcoverage,key=lambda x:x['id'])),('results/all45-activity-dispositions.json',load(S/'results/all-45-activity-dispositions.json')),('results/all27-regulation-dispositions.json',load(S/'results/all-27-regulation-dispositions.json')),('results/all18-component-dispositions.json',load(S/'results/all-component-dispositions.json')),('results/source-to-graph-evidence-occurrences.json',coverage),('results/reference-original-bindings.json',refproof),('results/taxon-dispositions.json',taxledger),('results/gene-dispositions.json',geneledger),('results/native-authority-demand.json',demand),('results/conditional-alternative-substrate-edges.json',alts)]:save(rel,d)
save('results/design-summary.json',{'native_nodes':len(nodes),'taxa':len(taxa),'edges':len(edges),'edges_by_kind':dict(Counter(m['kind'] for m in edgemeta)),'native_existing':17,'native_missing':52,'taxa_existing':sum(x.get('existing',False) for x in demand if x['section']=='taxa'),'taxa_missing':sum(not x.get('existing',False) for x in demand if x['section']=='taxa'),'six_alternative_inputs':'pending precise separately reviewed endpoint-contract correction','authority_acceptance':False,'issuer_independent_acceptance':'pending receipt','maintained_curation':False,'graph_review':'pending independent review','reference_count':len(references),'gene_nodes':0,'exact_aliases':0})
print('Design prepared',len(nodes),'native nodes',len(edges),'edges;',len(alts),'conditional alternative inputs')
