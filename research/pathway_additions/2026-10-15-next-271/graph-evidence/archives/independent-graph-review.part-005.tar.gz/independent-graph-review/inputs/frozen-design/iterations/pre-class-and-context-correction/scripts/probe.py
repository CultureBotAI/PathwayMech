from pathlib import Path
import sys,json,hashlib,copy,dataclasses
from lxml import etree as ET,html as LH
import yaml
O=Path(__file__).resolve().parents[1]; B=O/'inputs/baseline';sys.path.insert(0,str(B/'src'))
from pathwaymech.schema import validate_record,ValidationError
from pathwaymech.strict import strict_errors
from pathwaymech.cli import _record_page
from pathwaymech.kgx import kgx_nodes,kgx_edges
r=yaml.safe_load((O/'design/prospective-record.yaml').read_text());checks=[]
def ck(name,v):checks.append({'name':name,'passed':bool(v)});assert v,name
record=validate_record(r);ck('Python semantic shape',True)
errs=strict_errors([O/'design/prospective-record.yaml'],B);ck('Closed LinkML contract',not errs)
html=_record_page(record,source_path='design/prospective-record.yaml');(O/'probes/prospective-page.html').write_text(html)
kgxn=[dataclasses.asdict(n) for n in kgx_nodes([record])];kgxe=[dataclasses.asdict(e) for e in kgx_edges([record])]
(O/'probes/kgx-nodes.json').write_text(json.dumps(kgxn,indent=2,ensure_ascii=False)+'\n');(O/'probes/kgx-edges.json').write_text(json.dumps(kgxe,indent=2,ensure_ascii=False)+'\n')
ck('75 KGX declarations including six taxa',len(kgxn)==75);ck('83 current edges',len(kgxe)==83)
nodeids={n['id'] for n in kgxn};meta=json.loads((O/'results/proposed-native-node-inventory.json').read_text())
for n in meta:
 ck('native node exported '+n['frame'],n['declaration']['id'] in nodeids)
 e=next(x for x in kgxn if x['id']==n['declaration']['id']);cat=n['declaration']['category']
 if n['native_class'] and n['native_type']=='Protein':ck('protein class preserved '+n['frame'],e['category']=='biolink:Protein')
 if n['native_type']=='Enzymatic-Reaction':ck('activity distinct '+n['frame'],e['category']=='biolink:MolecularActivity' and e['source_category']=='molecular_activity')
for edge in r['mechanistic_edges']:
 candidates=[x for x in kgxe if x['subject']==edge['subject'] and x['object']==edge['object'] and x['description']==edge['description']]
 ck('edge full context '+edge['id'],len(candidates)==1)
 ck('edge full evidence '+edge['id'],json.loads(candidates[0]['evidence'])==edge['evidence'])
 for ev in edge['evidence']:ck('evidence length '+edge['id'],len(ev['source_assertion'])<=400)
page=LH.fromstring(html);ids=page.xpath('//@id');ck('page unique ids',len(ids)==len(set(ids)))
for a in page.xpath('//a[starts-with(@href,"#")]'):ck('page fragment '+a.get('href'),a.get('href')[1:] in ids)
# Current baseline demonstrates the actual typed-activity input barrier; future correction owned separately.
alt=json.loads((O/'results/conditional-alternative-substrate-edges.json').read_text())[0]
test=copy.deepcopy(r);test['mechanistic_edges'].append({'id':'contract-probe-alternative-input','subject':'MetaCyc:'+alt['activity'],'predicate':'has_input','object':'MetaCyc:'+alt['alternate'],'description':'Native alternative input to exact activity, not a canonical reaction-equation change.','evidence':[alt['evidence']]})
try:validate_record(test);error=None
except ValidationError as e:error=str(e)
ck('baseline activity input restriction reproduced',error is not None and 'has_input' in error)
(O/'probes/activity-input-contract-error.txt').write_text(error+'\n')
# Source-native evidence locators all resolve against actual copied own-original bytes.
root=O/'inputs/issuer/inputs/source'
for edge in r['mechanistic_edges']:
 for ev in edge['evidence']:
  if ev['reference_id'].startswith('MetaCyc:'):
   f=ev['reference_id'].split(':',1)[1];doc=ET.parse(str(root/'originals/native'/('META-'+f+'.xml')))
   ck('native XPath '+edge['id']+' '+ev['source_locator'],bool(doc.xpath(ev['source_locator'])))
(O/'receipts/design-probe-v1.json').write_text(json.dumps({'checks':checks,'passed':sum(x['passed'] for x in checks),'scope':'Copied actual merged baseline; no authority gate or final record approval. Six alternate inputs conditional on separately reviewed contract correction.','contract_error':error},indent=2)+'\n')
print(len(checks),'checks passed')
