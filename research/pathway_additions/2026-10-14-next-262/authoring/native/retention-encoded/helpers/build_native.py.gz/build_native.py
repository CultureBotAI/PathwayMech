from pathlib import Path
import json,hashlib,sys,collections,copy,xml.etree.ElementTree as ET
import yaml,html
sys.dont_write_bytecode=True
B=Path('/private/tmp/pathwaymech-next-262-native-author');N=Path('/private/tmp/pathwaymech-next-262-native');C=Path('/private/tmp/pathwaymech-next-262-chemistry');I=Path('/private/tmp/pathwaymech-next-262-biological-identity');R=Path('/private/tmp/pathwaymech-next-262-20261014');P=Path('/private/tmp/pathwaymech-next-262-primary')
sys.path[:0]=[str(R/'src'),str(R/'scripts')]
from pathwaymech.schema import validate_record
from build_source_identifier_snapshot import source_terms
rd=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,v):(B/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
full={x['frame']:x for x in rd(N/'native-full-object-projection.json')};bindings={x['frame']:x for x in rd(N/'compact-original-source-bindings.json')}
for f,o in full.items():assert sha(o['file'])==o['sha256']==bindings[f]['sha256']
def slots(f,n):return [s for s in full[f]['slots']if s['slot']==n]
def direct(f,n):return [c['frameid']for s in slots(f,n)for c in s['direct_children']if c.get('frameid')]
def texts(f,n):return [s['plain_text']for s in slots(f,n)]
source_snapshot=rd(B/'originals/baseline-authorities/sources.json');ontology=rd(B/'originals/baseline-authorities/ontology.json');authority={**ontology['terms'],**source_snapshot['terms']};new_authorities=[]
for a in rd(B/'receipts/acquisition-native-identities-complete.json'):
 p=Path(a['path']);assert sha(p)==a['sha256'];terms=list(source_terms('metacyc-html',p,url=a['url'],version='27.0'));assert len(terms)==1 and terms[0][0]=='MetaCyc:'+a['key'];t=terms[0];entry={'key':'meta262-native-'+a['key'],'kind':'metacyc-html','path':'meta262-native/'+p.name,'url':a['url'],'version':'27.0','license':'BioCyc source terms; redistribution not assessed','sha256':a['sha256']};new_authorities.append({'identifier':t[0],'canonical_label':t[1],'synonyms':t[2],'entry':entry,'source_original':a,'native_typed_original':bindings[a['key']]});authority[t[0]]={'label':t[1],'synonyms':t[2],'source':entry['key']}
for a in rd(B/'activity-authority-exact-reuse-plan.json'):
 o=a['source_original'];assert sha(o['path'])==o['sha256'];f=a['identifier'].split(':',1)[1];assert a['native_typed_object']['sha256']==full[f]['sha256'];t=list(source_terms('metacyc-html',Path(o['path']),url=o['url'],version='27.0'));assert len(t)==1 and t[0][0]==a['identifier'];new_authorities.append(a);authority[a['identifier']]={'label':t[0][1],'synonyms':t[0][2],'source':a['entry']['key']}
write('native-activity-pathway-authority-proposals.json',new_authorities)
bio={x['native_identifier'].split(':',1)[1]:x for x in rd(I/'complete-biological-object-identity-ledger.json')};chemical=rd(C/'chemical-structure-closure.json');chemproof=rd(C/'formal-chemistry-proof.json');rheas=rd(C/'rhea-complete-source-projection.json');acts=rd(N/'formal-activity-closure.json');scopes=rd(N/'curated-catalyst-scope-decisions.json');scopes=copy.deepcopy(scopes);scopes['MONOMER-12780']=scopes['MONOMER-12780'].replace('measured aldehyde alternatives and pH optimum8.5','measured aldehyde alternatives and native pH-opt annotation8.5, distinct from the primary tested6.5–8.5 range');selected=[x for x in acts if x['enzyme']!='ADHE-CPLX'];selected_activity={x['activity']:x for x in selected};proteins={x['enzyme']for x in selected}
while True:
 prior=set(proteins)
 for f in list(proteins):proteins.update(direct(f,'component'));proteins.update(direct(f,'component-of'))
 if prior==proteins:break
assert 'ADHE-CPLX'not in proteins and 'ADHE-MONOMER'not in proteins
chems={}
for a in chemproof['steps']:
 for m in a['inputs']+a['outputs']:
  ident=m['id'];chems[m['native_compound']]={'id':ident,'label':authority.get(ident,{}).get('label')or chemical['issuing_chebi_compounds'][ident]['issuing_name'],'category':'small_molecule'}
for a in rd('/private/tmp/pathwaymech-next-261-participant-authorities/retained/native-chemical-dispositions.json')['endpoints']:
 if a['native_frame']not in full:continue
 assert full[a['native_frame']]['sha256']==a['source_sha256'];chems.setdefault(a['native_frame'],{'id':a['selected_id'],'label':a['selected_label'],'category':a['category']})
root_selection=B/'root-additional-chemical-selections.json'
if root_selection.exists():
 for a in rd(root_selection):
  assert a['native_sha256']==full[a['native_frame']]['sha256'];chems[a['native_frame']]={'id':a['selected_id'],'label':a['selected_label'],'category':a.get('category','small_molecule')}
formal_ids=['RHEA:17338','RHEA:34220','RHEA:33432','MetaCyc:4.1.1.77-RXN','RHEA:22582','RHEA:22625','RHEA:23289'];formal={a['native_reaction']:formal_ids[i]for i,a in enumerate(chemproof['steps'])};byindex={a['step']:a for a in chemproof['steps']};directions={'PHYSIOL-LEFT-TO-RIGHT':'left_to_right','LEFT-TO-RIGHT':'left_to_right','PHYSIOL-RIGHT-TO-LEFT':'right_to_left','RIGHT-TO-LEFT':'right_to_left','REVERSIBLE':'reversible'}
nodes={};reactions={};references={};edges=[];coverage=[];dispositions=[];unresolved=[]
def ref(f):
 o=full[f];ident='MetaCyc:'+f;references.setdefault(ident,{'id':ident,'title':'MetaCyc '+o['type']+' '+f+' complete original','url':bindings[f]['issuing_url'],'source_version':'27.0','source_sha256':o['sha256']});return ident
def ev(f,text,loc):
 assert 0<len(text)<=400,(f,text);assert '/comment'not in loc,'Prose is not a structured assertion';return {'reference_id':ref(f),'source_assertion':text,'source_locator':loc}
def relation_ev(f,n,text):return ev(f,text,'; '.join(s['locator']for s in slots(f,n)))
def edge(sub,pred,obj,desc,evidence,sourcekeys,qual=None):
 ident='n'+str(len(edges)+1).zfill(3);row={'id':ident,'subject':sub,'predicate':pred,'object':obj,'description':desc,'evidence':evidence}
 if qual:row['endpoint_qualifiers']=qual
 edges.append(row);coverage.append({'edge_id':ident,'subject':sub,'predicate':pred,'object':obj,'source_keys':sourcekeys});return ident

def chemical_node(f,cofactor=False):
 if f not in chems:unresolved.append({'native_frame':f,'reason':'Await root exact chemical authority selection'});return None
 r=copy.deepcopy(chems[f]);ident=r['id']
 if cofactor:r['category']='cofactor'
 if ident not in nodes:nodes[ident]=r
 elif cofactor:nodes[ident]['category']='cofactor'
 return ident
for f in sorted(proteins):
 r=bio[f];iscomplex='Protein-Complexes'in direct(f,'parent');nodes['MetaCyc:'+f]={'id':'MetaCyc:'+f,'label':r['canonical_label'],'category':'complex'if iscomplex else'protein'};ref(f)
genes={g for f in proteins for g in direct(f,'gene')}
for f in sorted(genes):nodes['MetaCyc:'+f]={'id':'MetaCyc:'+f,'label':bio[f]['canonical_label'],'category':'gene'};ref(f)
for s in chemproof['steps']:
 ident=formal[s['native_reaction']]
 if ident.startswith('RHEA:'):
  label=authority[ident]['label'];direction='right_to_left'if ident=='RHEA:22582'else'left_to_right';rr=rheas['nodes']['http://rdf.rhea-db.org/'+ident.split(':')[1]];assert rr['label'][0]==label
  reactions[ident]={'id':ident,'label':label,'category':'molecular_activity','direction':direction}
  rdf=rheas['original_inputs'][0];references[ident]={'id':ident,'title':'Rhea '+ident+' issuing reaction in release142','url':'https://www.rhea-db.org/rhea/'+ident.split(':')[1],'source_version':'Rhea142; digest identifies the complete official gzip RDF, with selected subject retained in source dossier','source_sha256':rdf['sha256']}
 else:reactions[ident]={'id':ident,'label':'2-oxo-3-hexenedioate decarboxylation to the formal (2Z)-2-hydroxypenta-2,4-dienoate','category':'molecular_activity','direction':directions[s['native_direction']]}
for a in selected:
 ident='MetaCyc:'+a['activity'];row={'id':ident,'label':authority[ident]['label'],'category':'molecular_activity'}
 ds=texts(a['activity'],'reaction-direction');assert len(ds)<=1
 if ds:row['direction']=directions[ds[0]]
 reactions[ident]=row
for f in ['PWY-5419','PWY-5162']:reactions['MetaCyc:'+f]={'id':'MetaCyc:'+f,'label':authority['MetaCyc:'+f]['label'],'category':'pathway'}
# Twenty-eight material facts retain complete native orientation separately from selected traversal.
for s in chemproof['steps']:
 f=s['native_reaction'];target=formal[f]
 for side,pred in [('inputs','consumes'),('outputs','produces')]:
  for m in s[side]:
   c=chemical_node(m['native_compound']);sub,obj=(c,target)if pred=='consumes'else(target,c);loc=m['locator'];role='input'if pred=='consumes'else'output';assertion=f+' lists '+m['native_compound']+' on its '+('left'if '/left['in loc else'right')+' side'+(' with coefficient '+str(m['coefficient'])if m['coefficient_explicit']else' without an explicit coefficient (one stoichiometric occurrence)')+'.'
   evidence=[ev(f,assertion,loc),relation_ev(f,'reaction-direction','Native reaction-direction is '+s['native_direction']+'. The pathway traversal is separately assigned.')]
   if target.startswith('RHEA:'):evidence.append({'reference_id':target,'source_assertion':'The issuing directional equation is '+rheas['nodes']['http://rdf.rhea-db.org/'+target.split(':')[1]]['equation'][0]+'.','source_locator':'RDF subject http://rdf.rhea-db.org/'+target.split(':')[1]+'; rh:equation'})
   edge(sub,pred,obj,f"Coefficient {m['coefficient']} along selected native traversal {s['native_traversal']}; native reaction direction {s['native_direction']}. The displayed formal reaction node retains its own issuing direction. Exact modern formal structure does not establish historical assay stereochemistry.",evidence,['material:'+f+':'+loc])
for module in ['PWY-5419','PWY-5162']:
 s=next(s for s in slots('PWY-5420','reaction-list')if any(x.get('frameid')==module for x in s['direct_children']));edge('MetaCyc:PWY-5420','has_part','MetaCyc:'+module,'This complete native child module is inside the seven-step oxidative route, not a separate pathway candidate.',[ev('PWY-5420','The parent reaction-list includes child pathway '+module+'.',s['locator'])],['module:PWY-5420:'+module])
 for s in slots(module,'reaction-list'):
  for child in s['direct_children']:
   f=child.get('frameid')
   if f in formal:edge('MetaCyc:'+module,'has_part',formal[f],'Native module membership, mapped to the exact selected formal chemistry; source reversibility and traversal remain separate.',[ev(module,'The module reaction-list includes '+f+'.',s['locator'])],['module:'+module+':'+f])
for j in chemproof['joins']:
 u=byindex[j['upstream_step']];d=byindex[j['downstream_step']];desc='The exact intermediate '+j['chebi']+' connects these selected steps; coefficient '+str(j['coefficient'])+'. Pyruvate branches at the aldolase step; acetaldehyde alone continues to the acylating step.'if j['upstream_step']==6 else'The same exact intermediate '+j['chebi']+' is produced upstream and consumed downstream, coefficient '+str(j['coefficient'])+'. This is direct material transfer, not inferred thermodynamic irreversibility.'
 edge(formal[u['native_reaction']],'provides_input_for',formal[d['native_reaction']],desc,[ev(u['native_reaction'],'The upstream reaction side lists '+j['native_compound']+'.',j['upstream_locator']),ev(d['native_reaction'],'The downstream reaction side lists the same '+j['native_compound']+'.',j['downstream_locator'])],['join:'+str(j['upstream_step'])+'-'+str(j['downstream_step'])])
for module in ['PWY-5420','PWY-5419','PWY-5162']:
 for s in slots(module,'reaction-ordering'):
  e=ET.fromstring(s['xml']);to=e.find('Reaction');prev=e.find('predecessor-reactions/Reaction')
  if to is None or prev is None:continue
  t,p=to.get('frameid'),prev.get('frameid');ti=formal.get(t,'MetaCyc:'+t);pi=formal.get(p,'MetaCyc:'+p)
  if ti in reactions and pi in reactions:edge(pi,'precedes',ti,'Explicit native predecessor order; module order does not imply irreversibility of each reaction.',[ev(module,p+' is listed as predecessor of '+t+'.',s['locator'])],['ordering:'+module+':'+s['locator']])
# Exact native source activity assignments; unsupported promotion is separately excluded.
blocked_formal={'MONOMER-13363','MONOMER-14737','MONOMER-14738'}
for a in selected:
 f=a['activity'];p=a['enzyme'];codes=sorted({c for x in a['activity_evidence']for c in x['codes']});enloc=slots(f,'enzyme')[0]['locator'];rxloc=slots(f,'reaction')[0]['locator'];evidence=[ev(f,f+' explicitly links enzyme '+p+' and reaction '+a['reaction']+'.',enloc+'; '+rxloc)]
 if codes:evidence.append(ev(f,'Native evidence codes: '+', '.join(codes)+'. These are database annotations, not independent primary readings.','; '.join(x['locator']for x in a['activity_evidence'])))
 qualifier=[]
 if any('HH'in c for c in codes):qualifier=[{'endpoint':'subject','kind':'experimental_construct','description':'Native activity evidence is annotated for a heterologous-host preparation. The source-specific host, construct boundaries, purification and substrate limitations remain distinct from native enzyme identity; isolated native-protein testing is not inferred.','evidence':[ev(f,'The native activity evidence includes '+', '.join(c for c in codes if'HH'in c)+'.','; '.join(x['locator']for x in a['activity_evidence']))]}]
 if not qualifier and direct(p,'component-of'):
  complexes=direct(p,'component-of');qualifier=[{'endpoint':'subject','kind':'molecular_state','description':'This native protein/subassembly is explicitly a component of '+', '.join(complexes)+'. The source activity is retained with its assembly context; overall isolated-subunit activity and unspecified stoichiometry are not inferred.','evidence':[relation_ev(p,'component-of',p+' explicitly belongs to '+', '.join(complexes)+'.')]}]
 pred='enables'if p in blocked_formal or any(c.startswith(('EV-COMP','EV-EXP-IEP','EV-EXP-IMP'))for c in codes)else'catalyzes'
 desc=scopes[p]+' Native activity '+f+' is retained at its stated inference level.'
 if p in blocked_formal:desc+=' No exact unchlorinated formal catalytic promotion is made from this source assignment.'
 # Preserve exact native structured preparation/direction/kinetic facts locally;
 # they are database assertions, not an independent reading of cited papers.
 context=[]
 for ns in full[f]['slots']:
  name=ns['slot']
  if name not in ['reaction-direction','physiologically-relevant','ph-opt','temperature-opt','km','kcat','specific-activity','alternative-substrate']:continue
  el=ET.fromstring(ns['xml']);detail=None
  if name=='alternative-substrate':
   ss=el.find('substrate/Compound');aa=el.find('alternate/Compound')
   if ss is not None and aa is not None:
    detail='alternative-substrate slot '+ss.get('frameid')+' → '+aa.get('frameid')
    if f=='ENZRXN-3582':detail+=' (rejected as a product-replacement equation; original slot conflict retained)'
    else:detail+=' (assay context only; no additional balanced reaction inferred)'
  elif name in ['km','kcat','specific-activity']:
   v=el.find('value');sub=el.find('substrate/Compound')
   detail=name+' '+str(v.text)+' '+html.unescape(html.unescape(v.get('units','')))+(' for '+sub.get('frameid')if sub is not None else'')
  else:detail=name+' '+str(el.text).strip()+(' '+html.unescape(html.unescape(el.get('units','')))if el.get('units')else'')
  if detail:
   direction=el.findtext('direction')
   if direction:detail+=' (native direction '+direction+')'
   context.append(detail);evidence.append(ev(f,'Native structured '+detail+'.',ns['locator']))
 if context:desc+=' Structured database context: '+ '; '.join(context)+'. These are source annotations, not universal optima, kinetic constants or primary-confirmed substrate equivalences.'
 e1=edge('MetaCyc:'+p,pred,'MetaCyc:'+f,desc,evidence,['activity:'+f],qualifier)
 e2=None
 if p not in blocked_formal:e2=edge('MetaCyc:'+p,pred,formal[a['reaction']],'Curated native assignment through '+f+'. '+scopes[p]+' Modern formal stereochemistry and complete-route occurrence are not independently established by the historical assay.',[ev(f,'The native enzyme/reaction assignment is '+p+' / '+a['reaction']+' through '+f+'.',enloc+'; '+rxloc)],['formal-assignment:'+f],qualifier)
 dispositions.append({'activity':f,'protein':p,'native_reaction':a['reaction'],'selected_formal_id':formal[a['reaction']],'native_evidence_codes':codes,'activity_edge':e1,'formal_edge':e2,'disposition':'source-qualified native activity only; formal promotion excluded'if p in blocked_formal else'source-qualified native activity and formal assignment','scope':scopes[p]})
for a in acts:
 if a['enzyme']=='ADHE-CPLX':dispositions.append({'activity':a['activity'],'protein':a['enzyme'],'disposition':'excluded exact E.coli ADHE-CPLX instance by PWY5162 enzymes-not-used; unrelated AdhE proteins unaffected','evidence_source':bindings['PWY-5162'],'source_locators':[s['locator']for s in slots('PWY-5162','enzymes-not-used')]})
for p in sorted(proteins):
 for s in slots(p,'component'):
  e=ET.fromstring(s['xml']);child=e.find('Protein');assert child is not None and child.get('frameid')in proteins;f=child.get('frameid');co=e.findtext('coefficient');detail='Explicit native component coefficient '+co+'.'if co else'No native component coefficient is supplied; total subunit number is not inferred.'
  if p=='CPLX-7250':detail+=' Two DmpF and two DmpG form the native biological complex; pair wording does not change its complete stoichiometry.'
  if p=='CPLX-7822':detail+=' The historical AmnF partner remains an unlinked prose identity; modern engineered8IH6 is a separate preparation.'
  edge('MetaCyc:'+p,'has_part','MetaCyc:'+f,detail+' Membership does not grant each isolated component the overall catalytic activity.',[ev(p,p+' explicitly lists '+f+' as a component'+(' with coefficient '+co if co else' without coefficient')+'.',s['locator'])],['component:'+p+':'+s['locator']])
for a in selected:
 for s in slots(a['activity'],'cofactor'):
  for x in s['direct_children']:
   f=x.get('frameid')
   if not f:continue
   cid=chemical_node(f,True)
   if cid:edge('MetaCyc:'+a['enzyme'],'has_cofactor',cid,'Native cofactor annotation for '+a['activity']+'. '+scopes[a['enzyme']]+' No requirement is transferred across homologs or inferred from an unrelated assay additive.',[ev(a['activity'],a['activity']+' explicitly lists '+f+' as a cofactor of '+a['enzyme']+'.',s['locator'])],['cofactor:'+a['activity']+':'+s['locator']])
regdis=[]
for a in rd(N/'regulation-assertions.json'):
 f=a['original']['frame'];targets=a['regulated_activities'];retained=[];reason='adjacent or explicitly excluded AdhE context'
 if f=='REG-5876':reason='native negative NADH sign conflicts with independently inspected primary stimulation; rejected as inhibition; primary author owns positive successor'
 elif any(t in selected_activity for t in targets):
  reason='native regulation assertion qualified to exact activity/preparation'
  for t in targets:
   if t not in selected_activity:continue
   for c in a['regulators']:
    cid=chemical_node(c)
    if not cid:reason='pending exact root chemical participant selection';continue
    mode=a['native_modes'];assert mode in [['-'],['+']];desc='Native regulation '+f+' targets '+t+' ('+selected_activity[t]['enzyme']+'). Effects remain specific to that activity/preparation; no universal metal or whole-pathway regulation is inferred.'
    if f in ['REG-5875','REG-5877']:desc+=' Native ALLOSTERIC annotation is not an established binding mechanism.'
    if f=='REG-12603':desc+=' This structured Cu2+ annotation conflicts with Hg2+ in native protein prose; historical primary main text remains unavailable, so the conflict is unresolved.'
    if f=='REG0-13116':desc+=' Native competitive mode and Ki265000µM remain database context, not independently primary-verified values.'
    retained.append(edge(cid,'inhibits'if mode==['-']else'activates','MetaCyc:'+t,desc,[ev(f,f+' explicitly lists regulator '+c+', mode '+mode[0]+' and regulated activity '+t+'.','; '.join(s['locator']for s in full[f]['slots']if s['slot']in['regulator','mode','regulated-entity']))],['regulation:'+f]))
 regdis.append({'frame':f,'regulators':a['regulators'],'targets':targets,'native_modes':a['native_modes'],'edges':retained,'disposition':reason,'source':a['original']})
for p in sorted(proteins):
 for s in slots(p,'location'):
  for x in s['direct_children']:
   f=x.get('frameid');mapping={'CCO-CYTOSOL':'GO:0005829','CCO-CHLOROPLAST':'GO:0009507','CCO-MEMBRANE':'GO:0016020'}
   if f not in mapping:continue
   ident=mapping[f];nodes[ident]={'id':ident,'label':authority[ident]['label'],'category':'cellular_component'};edge('MetaCyc:'+p,'located_in',ident,'Exact native physical protein localization; this does not localize the complete pathway or assign exclusive localization.',[ev(p,p+' lists location '+f+'.',s['locator'])],['location:'+p+':'+s['locator']])
taxa=[]
for s in slots('PWY-5420','species'):
 for x in s['direct_children']:
  f=x.get('frameid')
  if f=='ORG-5948':continue
  ts=[d['dblink-oid']for d in bio[f]['direct_crossreferences']if d['dblink-db']=='NCBI-TAXONOMY-DB'];assert len(ts)==1;ident='NCBITaxon:'+ts[0];t=next(x['term']for x in rd(I/'projections/taxon-authority-candidates.json')['candidates']if x['identifier']==ident);taxa.append({'id':ident,'label':t['label']});ref(f)
assert len(taxa)==4
narrative=('The complete seven-step oxidative catechol meta-cleavage route consists of the four reactions of PWY-5419 followed by the three reactions of PWY-5162. Ring cleavage, NAD-dependent semialdehyde oxidation, tautomerization and enol-producing decarboxylation feed the shared hydration/aldolase/acylating-dehydrogenase tail. Pyruvate branches at aldol cleavage; acetaldehyde continues to acetyl-CoA. The complete formal net transformation consumes catechol, oxygen, two waters, CoA(4−) and two NAD(1−), producing carbon dioxide, pyruvate, acetyl-CoA(4−), two NADH(2−) and three hydrons.\n\n'
 'Native formal reaction orientation is kept independently from route traversal and from the six selected directional Rhea equations. Native RXN-8529 is reversible and matches the 28080-to-64908 tautomerization, not its wrong-stereoisomer Rhea32214 cross-reference. Native4.1.1.77-RXN yields the 2Z dienol; linked ketoRhea24261 is not an exact substitute. The hydratase is traversed native right-to-left. Native parent2E prose and historical substrate preparations do not independently establish modern2Z/S stereochemistry.\n\n'
 'The four listed taxa are exact native parent species annotations, not four independently demonstrated complete routes. Historical Pseudomonas putida mt-2 remains the source-specific ORG-5948 context without a guessed taxonomy alias. Component donors, broader taxonomic ranges and heterologous expression hosts do not become whole-route taxa. All native activity assignments preserve their evidence classes and preparation limits. Gene nodes retain exact identity context and reciprocal product pointers in the accompanying ledger; no unsupported encodes predicate is invented.\n\n'
 'NbaG remains a predicted component; CnbE/F unchlorinated formal promotion is excluded because the described coupled assay is chlorinated. CnbG unchlorinated extract activity is distinct. AP3 decarboxylase gene spelling conflicts across native/UniProt, exact ENA accession/CDS and papers; accession-grounded identity does not resolve the historical AmnF partner or absolute assembly count. Modern engineered8IH6 tagged5+5 is a separate preparation. The native Cu/Hg regulator conflict is explicit. Native XylH six-subunit annotation, historical mass interpretation and modified crystal preparations remain separate. DmpFG is2+2; its native negative NADH sign is excluded in favor of primary-author adjudication. E.coli ADHE-CPLX is explicitly excluded by PWY5162, without excluding unrelated AdhE proteins.\n\n'
 'Source-specific enzyme scope follows. These native database descriptions preserve source inference and preparation limits; cited papers are not thereby claimed independently read.\n\n'+'\n\n'.join(scopes[p]+' [MetaCyc:'+p+']'for p in sorted({a['enzyme']for a in selected})))
record={'id':'MetaCyc:PWY-5420','label':authority['MetaCyc:PWY-5420']['label'],'description':narrative,'pathway_type':'aromatic-compound-degradation','taxa':taxa,'participants':list(nodes.values()),'reactions':list(reactions.values()),'mechanistic_edges':edges,'references':list(references.values())};validate_record(record)
(B/'native-draft.yaml').write_text(yaml.safe_dump(record,sort_keys=False,allow_unicode=True,width=110));write('edge-source-coverage.json',coverage);write('formal-activity-dispositions.json',dispositions);write('regulation-dispositions.json',regdis);write('unresolved-chemical-endpoints.json',unresolved)
write('selected-identifiers.json',[{'section':'record','id':record['id'],'label':record['label']}]+[{'section':s,**x}for s in ['taxa','participants','reactions']for x in record[s]])
write('node-reference-map.json',{'formal_reactions':formal,'protein_nodes':sorted(proteins),'gene_nodes':sorted(genes),'activity_nodes':sorted(selected_activity),'node_ids':[record['id']]+list(nodes)+list(reactions)+[x['id']for x in taxa],'references':list(references.values()),'native_edge_prefix':'n','primary_reserved_prefix':'p'})
write('native-formal-direction-correspondence.json',[{'native_reaction':s['native_reaction'],'native_original':s['native_original'],'native_direction':s['native_direction'],'pathway_traversal':s['native_traversal'],'selected_route_identifier':formal[s['native_reaction']],'selected_node_direction':reactions[formal[s['native_reaction']]]['direction'],'exact_route_chemistry':s['equation_CHEBI'],'disposition':'Exact participant/coefficient route-oriented chemistry correspondence, not a skos:exactMatch between reversible native and directional Rhea entities.'}for s in chemproof['steps']])
print(json.dumps({'participants':len(nodes),'genes':len(genes),'proteins':len(proteins),'reactions':len(reactions),'edges':len(edges),'references':len(references),'all_activity_dispositions':len(dispositions),'regulation_dispositions':len(regdis),'pending_chemical_uses':len(unresolved),'shape_validation':'passed'},indent=2))
