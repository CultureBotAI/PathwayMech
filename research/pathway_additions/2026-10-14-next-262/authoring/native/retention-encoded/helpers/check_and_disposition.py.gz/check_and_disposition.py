"""Replay the external native draft against its finite, source-bound inputs.

This is an author check and completeness/disposition ledger, not an independent
scientific review or the repository's integration gate suite.
"""
from pathlib import Path
import collections, datetime, hashlib, json, sys, sqlite3, xml.etree.ElementTree as ET
import yaml

sys.dont_write_bytecode = True
B = Path('/private/tmp/pathwaymech-next-262-native-author')
N = Path('/private/tmp/pathwaymech-next-262-native')
C = Path('/private/tmp/pathwaymech-next-262-chemistry')
I = Path('/private/tmp/pathwaymech-next-262-biological-identity')
P = Path('/private/tmp/pathwaymech-next-262-primary')
R = Path('/private/tmp/pathwaymech-next-262-20261014')
sys.path[:0] = [str(R/'src'), str(R/'scripts')]
from pathwaymech.schema import validate_record
from pathwaymech.strict import strict_errors
from build_source_identifier_snapshot import source_terms

def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):
    p = Path(p)
    return {'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size}
def write(n, x): (B/n).write_text(json.dumps(x, indent=2, ensure_ascii=False)+'\n')

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
record = yaml.safe_load((B/'native-draft.yaml').read_text())
full = {o['frame']: o for o in read(N/'native-full-object-projection.json')}
bindings = {o['frame']: o for o in read(N/'compact-original-source-bindings.json')}
locators = {}
for frame, obj in full.items():
    assert sha(obj['file']) == obj['sha256'] == bindings[frame]['sha256']
    root = ET.parse(obj['file']).getroot()
    native = next(e for e in list(root) if e.get('frameid') == frame)
    assert native.tag == obj['type']
    for slot in obj['slots']:
        actual = native.findall(slot['slot'])[slot['ordinal']-1]
        assert ET.tostring(actual).strip() == ET.tostring(ET.fromstring(slot['xml'])).strip(), (frame,slot['locator'])
        locators[slot['locator']] = (frame, slot)
assert len(locators) == 5148
validate_record(record)
strict = strict_errors([B/'native-draft.yaml'], R)
assert not strict, strict
refs = {r['id']: r for r in record['references']}
edges = {e['id']: e for e in record['mechanistic_edges']}
nodes = {record['id']: record} | {n['id']: n for s in ['taxa','participants','reactions'] for n in record[s]}
assert len(edges) == len(record['mechanistic_edges'])
assert len(refs) == len(record['references'])
assert len(nodes) == 1+sum(len(record[s]) for s in ['taxa','participants','reactions'])
graphcov = read(B/'edge-source-coverage.json')
assert {e['edge_id'] for e in graphcov} == set(edges)
used = collections.defaultdict(list)
evidence_replay = []
rhea = read(C/'rhea-complete-source-projection.json')
rdf = rhea['original_inputs'][0]
assert sha(rdf['path']) == rdf['sha256']
for edge in edges.values():
    items = [('edge', x) for x in edge['evidence']]
    items += [('endpoint_qualifier:'+str(qi), x) for qi,q in enumerate(edge.get('endpoint_qualifiers',[])) for x in q['evidence']]
    for ei,(place, item) in enumerate(items):
        reference = refs[item['reference_id']]
        assert 'source_assertion' in item and 'evidence' not in item
        rid = item['reference_id']
        if rid.startswith('MetaCyc:'):
            frame = rid.split(':',1)[1]
            assert reference['source_sha256'] == full[frame]['sha256']
            ll = item['source_locator'].split('; ')
            for loc in ll:
                assert loc in locators, (edge['id'],loc)
                assert locators[loc][0] == frame
                assert locators[loc][1]['slot'] != 'comment'
                used[loc].append({'edge':edge['id'],'place':place,'item':ei})
            mode = 'Exact original native direct slots replayed; structured database evidence'
        elif rid.startswith('RHEA:'):
            uri = 'http://rdf.rhea-db.org/'+rid.split(':')[1]
            assert reference['source_sha256'] == rdf['sha256']
            assert item['source_locator'] == 'RDF subject '+uri+'; rh:equation'
            assert item['source_assertion'] == 'The issuing directional equation is '+rhea['nodes'][uri]['equation'][0]+'.'
            mode = 'Issuing directional RDF equation, complete original gzip hash verified'
        else: raise AssertionError(rid)
        evidence_replay.append({'edge':edge['id'],'place':place,'item':ei,'reference_id':rid,'locator':item['source_locator'],'result':mode})
write('evidence-original-replay.json', evidence_replay)

activities = {a['activity']: a for a in read(B/'formal-activity-dispositions.json')}
regulations = {a['frame']: a for a in read(B/'regulation-dispositions.json')}
identity = {o['native_identifier'].split(':',1)[1]: o for o in read(I/'complete-biological-object-identity-ledger.json')}
correspondence = {o['native_reaction']:o for o in read(B/'native-formal-direction-correspondence.json')}
chemical = {o['native_frame']:o for o in read(B/'root-additional-chemical-selections.json')}
chemproof = read(C/'formal-chemistry-proof.json')
for step in chemproof['steps']:
    for c in step['inputs']+step['outputs']: chemical.setdefault(c['native_compound'],{'selected_id':c['id']})
formal = set(correspondence)
scopes = read(N/'curated-catalyst-scope-decisions.json')
oldslots = {r['locator']:r for r in read(N/'slot-disposition-ledger.json')}
node_map = read(B/'node-reference-map.json')
selected_protein = set(node_map['protein_nodes'])
selected_gene = set(node_map['gene_nodes'])

def object_disposition(frame, typ):
    if frame in activities: return activities[frame]['disposition']
    if frame in regulations: return regulations[frame]['disposition']
    if frame in formal: return 'Selected full-route formal reaction, with exact direction/participant correspondence and explicit native-versus-Rhea boundary.'
    if typ == 'Pathway':
        return ('Selected parent or one of its two complete child modules.' if frame in ['PWY-5420','PWY-5419','PWY-5162'] else 'Adjacent alternative catechol pathway; complete discovery comparison retained, not added to this oxidative record.')
    if typ == 'Protein':
        if frame in selected_protein: return 'Exact source instance retained as activity catalyst or explicitly linked assembly/component; historical reference/preparation limits remain in identity and primary dossiers.'
        if frame in ['ADHE-CPLX','ADHE-MONOMER']: return 'Exact E.coli AdhE exclusion by native PWY-5162 enzymes-not-used; preserve source context without graph catalytic promotion.'
        assert frame == 'MONOMER-12763',frame
        return 'XylF hydrolytic branch alternative; source-bounded contrast with the oxidative route, not a seven-step route catalyst.'
    if typ == 'Gene':
        return ('Exact gene identity retained; reciprocal product binding is source context. Closed graph predicates have no encodes relation, so no invented gene causal edge.' if frame in selected_gene else 'Gene belongs to exact excluded AdhE or adjacent hydrolytic XylF; no route gene node.')
    if typ == 'Organism':
        return ('Historical mt-2 source instance retained without guessed NCBI identity; no alias-based whole-route taxon promotion.' if frame=='ORG-5948' else 'Exact source organism identity and donor/host/component/parent roles retained; only four explicit parent species are selected as taxa.')
    if typ == 'Compound':
        return ('Exact structure selected for a route/cofactor/regulator participant; use-specific biological scope remains separately qualified.' if frame in chemical else 'Alternate substrate, comparator, branch, generic class or excluded-activity chemical context; no extra equation or regulator inferred from name/cross-reference.')
    if typ == 'cco': return 'Native physical localization context; exact selected protein location edges only, never a whole-route compartment.'
    if typ == 'Reaction': return 'Adjacent alternative chemistry or contextual reaction; full original retained, not a selected seven-step transformation.'
    if typ == 'Enzymatic-Reaction': return 'Adjacent substrate/route or explicitly excluded AdhE activity; not a selected full-route formal activity.'
    raise AssertionError((frame,typ))

slot_rows=[]
for frame,obj in full.items():
    scope=object_disposition(frame,obj['type'])
    for slot in obj['slots']:
        name=slot['slot'];loc=slot['locator'];why=scope
        if used.get(loc): kind='graph_evidence';why='Actual native structured fact cited by the listed graph edge/qualifier; source-specific scope follows that edge.'
        elif name in ['common-name','synonym','dblink','parent','accession-1','accession-2','rank','strain-name','subspecies-name','n-name','definition','abbrev-name','sensu','goid']:
            kind='identity_context';why+=' Native names/crossreferences/classes are not automatic exact mappings; issuing/current-owner decisions are in identity/chemistry dossiers.'
        elif name in ['gene','product','species','component-of','catalyzes','regulated-by','regulates','cofactors-of','instance','in-pathway','enzymatic-reaction','super-pathways','sub-pathways','pathway-link','taxonomic-range','appears-in-left-side-of','appears-in-right-side-of']:
            kind='relationship_context';why+=' Reciprocal/source-bound relation is preserved; no unsupported causal predicate, additional whole-route taxon, or homolog transfer.'
        elif name in ['cml','inchi','inchi-key','molecular-weight','monoisotopic-mw','gibbs-0','pka1','pka2']:
            kind='chemical_identity_or_physical_context';why+=' Complete native structure/property and issuing comparison remain available; physical-property annotations do not create mechanistic edges.'
        elif name=='comment':
            kind='narrative_context';why+=' Complete prose paragraphs are individually crosswalked below; no prose paraphrase is used as source_assertion. Primary-author integration owns independently read experimental claims.'
        elif name=='has-feature':
            kind='feature_context';why+=' Native mutation/model feature and its embedded evidence remain source context; no engineered/model-derived feature is assigned to a native activity by analogy.'
        elif name in ['km','kcat','ki','specific-activity','alternative-substrate','ph-opt','temperature-opt','mechanism','molecular-weight-seq','molecular-weight-exp','pi','cofactor-binding-comment']:
            kind='assay_or_preparation_context';why+=' Exact value, units, direction, substrate and citation remain in the bound slot. Uncited measurements/alternatives are not silently promoted into formal route chemistry or universal conditions.'
        elif name in ['citation','credits','ec-number','orphan','has-go-term','subclass','systematic-name','surrounded-by','surrounds','left-end-position','right-end-position','transcription-direction']:
            kind='annotation_or_provenance_context';why+=' Citation/annotation/coordinate metadata is not itself an independent experimental claim.'
        elif name in ['left','right','reaction-direction','physiologically-relevant','reaction-layout','reaction-list','reaction-ordering','evidence','enzyme','reaction','mode','regulator','regulated-entity','component','location','cofactor','enzymes-not-used','spontaneous']:
            kind='bounded_or_rejected_mechanistic_context';why+=' Explicit source field retained in finite closure; applicable selected facts are mapped above and adjacent/conflicting claims remain qualified, excluded or delegated as stated.'
        else: raise AssertionError((frame,name))
        slot_rows.append({'frame':frame,'type':obj['type'],'slot':name,'ordinal':slot['ordinal'],'locator':loc,'source_sha256':obj['sha256'],'disposition_kind':kind,'disposition':why,'graph_uses':used.get(loc,[]),'native_ledger_disposition':oldslots[loc]['disposition'],'source_value_projection':{'plain_text':slot['plain_text'],'direct_children':slot['direct_children']}})
assert len(slot_rows)==5148
write('complete-slot-to-graph-dispositions.json',slot_rows)
objects=[]
for frame,obj in full.items():
    relevant=[r for r in slot_rows if r['frame']==frame]
    objects.append({'frame':frame,'type':obj['type'],'original':bindings[frame],'slot_count':len(relevant),'disposition':object_disposition(frame,obj['type']),'selected_node':('MetaCyc:'+frame if 'MetaCyc:'+frame in nodes else correspondence.get(frame,{}).get('selected_route_identifier') or chemical.get(frame,{}).get('selected_id')),'graph_edges':sorted({u['edge']for r in relevant for u in r['graph_uses']}),'slot_disposition_counts':dict(collections.Counter(r['disposition_kind']for r in relevant))})
write('complete-object-to-graph-dispositions.json',objects)

prose=[]
for p in read(N/'prose-claim-context-ledger.json'):
    f=p['frame'];obj=full[f];assert p['source_sha256']==obj['sha256']
    context=scopes.get(f) or object_disposition(f,obj['type'])
    prose.append({'id':p['id'],'frame':f,'locator':p['locator'],'source_sha256':p['source_sha256'],'source_paragraph':p['text'],'native_scope':p['scope'],'native_disposition':p['disposition'],'draft_description_context':context,'related_edges':next(o['graph_edges']for o in objects if o['frame']==f),'representation':'Narrative/source-limited context, never evidence.source_assertion. Independently supported primary claims and stronger construct qualifications are a separate primary-author integration.'})
assert len(prose)==218
write('complete-prose-to-record-dispositions.json',prose)
features=[]
for f in read(N/'protein-feature-context.json'):
    assert f['source_sha256']==full[f['protein']]['sha256']
    features.append({'protein':f['protein'],'feature':f['feature'],'locator':f['source_locator'],'source_sha256':f['source_sha256'],'disposition':object_disposition(f['protein'],'Protein')+' Full embedded feature is retained in the frozen native dossier; mutation/model/ligand annotations do not by themselves define a qualified experimental endpoint or native causal edge.','complete_source_ledger':str(N/'protein-feature-context.json')})
write('complete-feature-dispositions.json',features)
bibliography=read(N/'native-bibliographic-metadata.json')
write('bibliographic-access-boundary.json',{'native_metadata':bind(N/'native-bibliographic-metadata.json'),'native_metadata_records':len(bibliography),'primary_evidence_owner':bind(P/'HANDOFF.md'),'primary_source_boundary':'Primary author has independently scoped full texts, abstracts, unread erratum and transformations. Native embedded citations alone are not claimed read here. This draft uses native and issuing structural evidence; primary-reference graph additions remain pending integration.','native_prose_links':bind(N/'native-prose-link-dispositions.json'),'explicit_prose_boundary':bind(N/'explicit-prose-boundary-decisions.json')})

# Complete 28-fact/six-join crosswalk is checked independently of edge numbering.
chem_rows=[]
for step in chemproof['steps']:
    rid=correspondence[step['native_reaction']]['selected_route_identifier']
    for side,predicate in [('inputs','consumes'),('outputs','produces')]:
        for fact in step[side]:
            sub,obj=(fact['id'],rid) if side=='inputs' else (rid,fact['id'])
            matches=[e for e in edges.values()if(e['subject'],e['predicate'],e['object'])==(sub,predicate,obj)]
            assert len(matches)==1
            e=matches[0];assert any(fact['locator']==x['source_locator']for x in e['evidence'])
            chem_rows.append({'step':step['step'],'kind':'material','edge':e['id'],'coefficient':fact['coefficient'],'fact':fact})
for join in chemproof['joins']:
    r1=correspondence[chemproof['steps'][join['upstream_step']-1]['native_reaction']]['selected_route_identifier'];r2=correspondence[chemproof['steps'][join['downstream_step']-1]['native_reaction']]['selected_route_identifier']
    matches=[e for e in edges.values()if(e['subject'],e['predicate'],e['object'])==(r1,'provides_input_for',r2)];assert len(matches)==1
    chem_rows.append({'kind':'join','edge':matches[0]['id'],'join':join})
assert collections.Counter(r['kind']for r in chem_rows)=={'material':28,'join':6}
write('formal-material-and-join-graph-crosswalk.json',chem_rows)

overrides=[]
for o in read(B/'originals/primary-overrides.captured.json'):
    selector=o['selector']
    matched=[e for e in edges.values() if all(e.get(k)==v for k,v in selector.items()if k!='subjects') and ('subjects'not in selector or e['subject']in selector['subjects'])]
    if o['native_object'].startswith('REG'):
        selected=regulations[o['native_object']]['edges'];matched=[edges[e]for e in selected]
    limits='Native/source-specific description and structured evidence retained; primary author owns exact primary-backed additions/qualifiers and root must apply the complete integration map.'
    if o['id']=='override-nadH-sign':
        assert not matched;limits='Native negative edge is suppressed. Primary preparation-specific positive stimulation is required from primary integration; no native allosteric mechanism is asserted.'
    elif o['id']in['override-nbaG-prediction','override-cnbF-substrate','override-cnbE-substrate']:
        assert len(matched)==1 and matched[0]['predicate']=='enables';limits='Native assignment uses enables only; the exact formal catalytic promotion is excluded. Primary evidence/construct details must qualify this retained association.'
    elif o['id']=='override-xylG-alternate-slot':limits='Original alternative-substrate slot is explicitly reported as a rejected product-replacement equation; no alternate formal reaction is created. Primary author supplies corrected substrate narrative.'
    elif o['id']=='override-whole-route-scope':limits='Four taxa remain exact native parent annotations only; no seven-step primary demonstration is claimed. Primary narrative must distinguish six-step historical endpoint from separate CoA step.'
    overrides.append({**o,'matched_edges':[{'id':e['id'],'subject':e['subject'],'predicate':e['predicate'],'object':e['object']}for e in matched],'native_author_disposition':limits,'primary_integration_status':'Required separate primary-author integration; this native draft does not claim it complete.'})
assert len(overrides)==15
write('primary-override-native-dispositions.json',overrides)

# Existing owners win; only absent exact candidates can be selected by root.
current=read(B/'originals/baseline-authorities/ontology.json')['terms']|read(B/'originals/baseline-authorities/sources.json')['terms']
candidates={p['identifier']:p for p in read(I/'complete-source-config-proposals.json')}
for a in read(B/'native-activity-pathway-authority-proposals.json'):candidates[a['identifier']]=a
taxon_source=read(I/'projections/taxon-authority-candidates.json');taxon_candidates={c['identifier']:c for c in taxon_source['candidates']}
needs=[]
for n in read(B/'selected-identifiers.json'):
    ident=n['id']
    if ident in current:
        existing=current[ident];label=existing['label']
        contextual=(ident=='MetaCyc:4.1.1.77-RXN')
        assert n['label']==label or contextual,(ident,n['label'],label)
        needs.append({'identifier':ident,'label':n['label'],'current_owner':existing,'disposition':'Preserve existing owner; contextual native reaction label explicitly qualified.'if contextual else'Exact existing owner and label preserved.'})
    elif ident in candidates:
        candidate=candidates[ident];entry=candidate['entry'];original=candidate.get('original')or candidate.get('source_original');assert sha(original['path'])==entry['sha256']
        terms=list(source_terms(entry['kind'],Path(original['path']),url=entry['url'],version=entry['version']));term=next(t for t in terms if t[0]==ident)
        assert term[1]==n['label'],(ident,term,n['label'])
        needs.append({'identifier':ident,'label':n['label'],'candidate':candidate,'disposition':'Absent merged-baseline owner; exact issuing parser replay passed. Root selects/rebinds source config and preserves all existing owners.'})
    elif ident in taxon_candidates:
        proposal=taxon_candidates[ident];assert proposal['term']['label']==n['label']
        with sqlite3.connect('file:'+taxon_source['database']['path']+'?mode=ro&immutable=1',uri=True) as con:
            actual=[dict(zip(['subject','predicate','object','value','datatype','language'],v))for v in con.execute('select subject,predicate,object,value,datatype,language from statements where subject=? order by predicate,object,value',(ident,))]
        assert actual==proposal['statements']
        needs.append({'identifier':ident,'label':n['label'],'candidate':proposal,'source_owner':taxon_source['source_owner'],'issuing_database':taxon_source['database'],'disposition':'Absent merged-baseline owner; exact issuing taxonomy statements replayed. Root selects scoped term with pinned owner; historical strain identity is not inferred.'})
    else:
        proposal=next((c for c in chemical.values()if c['selected_id']==ident),None)
        assert proposal is not None,(ident,'no owner/proposal')
        needs.append({'identifier':ident,'label':n['label'],'candidate':proposal,'disposition':'Absent merged-baseline owner; exact root chemical issuing selection required. Root owns authority selection/integration.'})
write('selected-authority-integration-needs.json',needs)
contracts=[R/'CLAUDE.md',R/'.claude/skills/add-pathway/SKILL.md',R/'docs/CAUSAL_GRAPHS.md',R/'docs/CURATION.md',R/'docs/IDENTIFIERS.md',R/'docs/HARMONIZATION.md',R/'src/pathwaymech/schema/pathwaymech.yaml',R/'src/pathwaymech/schema.py',R/'src/pathwaymech/strict.py',R/'scripts/build_source_identifier_snapshot.py']
write('contract-and-input-bindings.json',{'read_contracts_and_replayed_modules':[bind(p)for p in contracts],'merged_baseline':'fbccbdc027f2a86ad4919e9dbbb16a736cc0746a','native_manifest':bind(N/'artifact-manifest.json'),'chemistry_manifest':bind(C/'artifact-manifest.json'),'identity_manifest':bind(I/'artifact-manifest.json'),'primary_manifest':bind(P/'artifact-manifest.json'),'additional_chemistry':bind('/private/tmp/pathwaymech-next-262-additional-chemistry/verification.json'),'current_authorities':[bind(B/'originals/baseline-authorities'/n)for n in ['ontology.json','sources.json']]})
write('verification.json',{'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'External native author checks; not an independent review or full maintained integration gate','record':bind(B/'native-draft.yaml'),'closed_strict_errors':strict,'shape_validation':'passed','full_original_objects_replayed':len(full),'complete_direct_slots_replayed':len(locators),'evidence_occurrences_replayed':len(evidence_replay),'material_facts':28,'exact_joins':6,'all_activity_dispositions':len(activities),'all_regulation_dispositions':len(regulations),'prose_paragraph_dispositions':len(prose),'feature_dispositions':len(features),'bibliographic_metadata_records':len(bibliography),'primary_override_dispositions':len(overrides),'selected_identifiers':len(needs),'pending_chemical_uses':read(B/'unresolved-chemical-endpoints.json'),'graph_edges':len(edges),'participants':len(record['participants']),'reactions':len(record['reactions']),'references':len(refs),'limitations':['Primary author additions/overrides remain separate and must be integrated before final review.','Full repository source/identifier/history/render/KGX/review/test gates and independent scientific/technical review are root-owned future work.','No paid access, author contact, or additional inferred identity; original user checkout and maintained worktree were not modified.','Finite source closure is exact bound original cohort; no claim of exhaustive literature or globally absent sequence identity.']})
print(json.dumps(read(B/'verification.json'),indent=2))
