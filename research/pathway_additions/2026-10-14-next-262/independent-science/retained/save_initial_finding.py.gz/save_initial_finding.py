from pathlib import Path
import json, hashlib, datetime, yaml
b=Path('/private/tmp/pathwaymech-next-262-independent-science'); p=b/'initial-maintained-record.yaml'; raw=p.read_bytes(); d=yaml.safe_load(raw)
s=Path('/private/tmp/pathwaymech-next-262-primary/derived/PMID7868591-merged-publisher-transformation.txt')
replacements={
'p1198 Table 1':'p1199 Table 1',
'p1195 Methods L49–54; cultural conditions L63; Results p1197 L180–189':'p1196 Methods L49–54; cultural conditions L63; Results pp1198–1199 L180–189',
'p1199 Discussion L326–328':'p1200 Discussion L326–328'}
occ=[]
def walk(o,path):
 if isinstance(o,dict):
  if o.get('reference_id')=='PMID:7868591' and 'source_locator' in o:
   old=o['source_locator']; new=old
   for x,y in replacements.items(): new=new.replace(x,y)
   if new!=old: occ.append({'field_path':path+'.source_locator','old':old,'replacement':new})
  for k,v in o.items():walk(v,f'{path}.{k}' if path else k)
 elif isinstance(o,list):
  for i,v in enumerate(o):walk(v,f'{path}[{i}]')
walk(d,'')
assert len(occ)==10,occ
finding={'finding_id':'SCI-F01','issue_key':'pathwaymech:PWY-5420:PMID7868591-page-locators','severity':'minor','status':'open','created_at':datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),'target_id':d['id'],'target_path':'data/pathways/catechol-degradation-ii.yaml','target_sha256':hashlib.sha256(raw).hexdigest(),'title':'Correct one-page offsets in the PMID7868591 printed-page locators','observation':'Ten source_locator occurrences on n060, n061, p014 and p015 assign printed pages one lower than the retained publisher transformation. Claims and exact line anchors remain supported; this is an actionable provenance defect, not a biological claim reversal.','source':{'path':str(s),'sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'kind':'retained publisher full-text transformation; no independently available visual PDF','source_identity':'PMID:7868591','printed_article_pages':'1196–1201','page_boundary_evidence':['L0@P0: JOURNAL OF BACTERIOLOGY, Mar. 1995, p. 1196–1201','L76@P0-1: 1196','L171@P1-2: 1197','L184@P2-3: 1198','L284@P3-4: 1199','L370@P4-5: 1200','L441@P5: 1201'],'claim_locations':{'Methods L49–54, culture L63':'p1196','Results L180–189':'pp1198–1199 (boundary at L184)','Table1 L235–261 and adjacent comparison L190–205':'p1199','Discussion L326–328':'p1200'}},'occurrences':occ,'requested_change':'Apply these exact printed-page substitutions only to the maintained record; retain original frozen author artifacts and this finding. Append a successor correction receipt bound to the changed YAML.','limitations':'The source is a publisher transformation with explicit page markers. No repair of unresolved numeric/µM/± OCR or biological scope is requested.'}
q=b/'SCI-F01-initial-locator-finding.json'; assert not q.exists(); q.write_text(json.dumps(finding,indent=2,ensure_ascii=False)+'\n'); print(json.dumps({'path':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'occurrences':len(occ),'source_sha256':finding['source']['sha256']}))
