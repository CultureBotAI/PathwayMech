from pathlib import Path
import hashlib,json,sqlite3,xml.etree.ElementTree as E,collections,re
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
O=Path('/private/tmp/pathwaymech-next-262-independent-science'); N=Path('/private/tmp/pathwaymech-next-262-native/originals'); C=Path('/private/tmp/pathwaymech-next-262-chemistry/originals')
steps=[('CATECHOL-23-DIOXYGENASE-RXN','RHEA:17338',False),('RXN-8527','RHEA:34220',False),('RXN-8529','RHEA:33432',False),('4.1.1.77-RXN','MetaCyc:4.1.1.77-RXN',False),('2-OXOPENT-4-ENOATE-HYDRATASE-RXN','RHEA:22582',True),('MHPELY-RXN','RHEA:22625',False),('ACETALD-DEHYDROG-RXN','RHEA:23289',False)]
# Source-native compound -> direct issuing crossreference, verified full structure.
sql=sqlite3.connect('file:/private/tmp/pathwaymech-curation-authorities/chebi.db?mode=ro',uri=True)
chem={}; evidence=[]
def load(f):
 p=N/('META-'+f+'.xml'); b=p.read_bytes();root=E.fromstring(b);o=next(x for x in root if x.attrib.get('frameid')==f);return p,b,o
for f,selected,reverse in steps:
 p,b,o=load(f);eq={}
 for role,side in [('input','right' if reverse else 'left'),('output','left' if reverse else 'right')]:
  vals=[]
  for s in o.findall(side):
   obj=s.find('Compound');cf=obj.get('frameid');coeff=int(s.findtext('coefficient') or 1)
   if cf not in chem:
    cp,cb,co=load(cf);links=[x.findtext('dblink-oid') for x in co.findall('dblink') if x.findtext('dblink-db')=='CHEBI'];assert len(links)==1,(cf,links);cid='CHEBI:'+links[0]
    rows=sql.execute('select predicate,object,value from statements where subject=?',(cid,)).fetchall();props=collections.defaultdict(list)
    for pred,ob,v in rows:props[pred].append(v if v is not None else ob)
    inchi=co.findtext('inchi');ikey=co.findtext('inchi-key').removeprefix('InChIKey=');assert props['chemrof:inchi_string']==[inchi] and props['chemrof:inchi_key_string']==[ikey],cf
    m=Chem.MolFromInchi(inchi);assert m is not None
    frm=rdMolDescriptors.CalcMolFormula(m);charge=Chem.GetFormalCharge(m)
    # CalcMolFormula includes charge suffix; use explicit atomic counts including implicit H.
    atoms=collections.Counter(a.GetSymbol() for a in m.GetAtoms());atoms['H']+=sum(a.GetTotalNumHs() for a in m.GetAtoms())
    if atoms['H']==0:del atoms['H']
    cml=co.find('./cml/molecule');ctoks=cml.find('formula').attrib['concise'].split();cmla={ctoks[i].title():int(ctoks[i+1]) for i in range(0,len(ctoks),2)}
    assert dict(atoms)==cmla,(cf,dict(atoms),cmla);assert charge==int(cml.attrib.get('formalCharge','0'))==int(props['chemrof:charge'][0])
    original_api=json.loads((C/('ChEBI-'+links[0]+'.json')).read_text());st=original_api['default_structure'];assert st['standard_inchi']==inchi and st['standard_inchi_key']==ikey
    chem[cf]={'selected_id':cid,'formula_atoms':dict(atoms),'charge':charge,'full_inchi':inchi,'inchi_key':ikey,'isomeric_smiles':Chem.MolToSmiles(m,isomericSmiles=True),'native_path':str(cp),'native_sha256':hashlib.sha256(cb).hexdigest(),'issuing_api':str(C/('ChEBI-'+links[0]+'.json')),'stereo_centers':Chem.FindMolChiralCenters(m,includeUnassigned=True),'bond_stereo':[(b.GetBeginAtomIdx(),b.GetEndAtomIdx(),str(b.GetStereo())) for b in m.GetBonds() if b.GetBondType()==Chem.BondType.DOUBLE]}
   vals.append({'native':cf,'id':chem[cf]['selected_id'],'coefficient':coeff})
  eq[role]=vals
 sides=[]
 for role in ['input','output']:
  a=collections.Counter();charge=0
  for v in eq[role]:
   co=chem[v['native']];a.update({x:n*v['coefficient'] for x,n in co['formula_atoms'].items()});charge+=co['charge']*v['coefficient']
  sides.append((dict(a),charge))
 assert sides[0]==sides[1],(f,sides)
 evidence.append({'native':f,'selected':selected,'native_direction':o.findtext('reaction-direction'),'reverse_native_traversal':reverse,'equation':eq,'balanced_atoms_and_charge':sides[0]})
net=collections.Counter()
for row in evidence:
 for role,sign in [('input',-1),('output',1)]:
  for x in row['equation'][role]:net[x['id']]+=sign*x['coefficient']
net={k:v for k,v in net.items() if v}
# Actual structure comparators, including wrong Rhea-linked keto / stereo states.
comparators={}
for cid in ['CHEBI:28080','CHEBI:64908','CHEBI:16967','CHEBI:64016','CHEBI:67152','CHEBI:60886','CHEBI:11641']:
 rows=sql.execute("select value from statements where subject=? and predicate='chemrof:inchi_string'",(cid,)).fetchall();assert len(rows)==1
 m=Chem.MolFromInchi(rows[0][0]);comparators[cid]={'inchi':rows[0][0],'smiles':Chem.MolToSmiles(m,isomericSmiles=True),'bond_stereo':[(b.GetBeginAtomIdx(),b.GetEndAtomIdx(),str(b.GetStereo())) for b in m.GetBonds() if b.GetBondType()==Chem.BondType.DOUBLE]}
assert comparators['CHEBI:28080']!=comparators['CHEBI:16967'];assert comparators['CHEBI:64908']!=comparators['CHEBI:64016'];assert comparators['CHEBI:67152']!=comparators['CHEBI:11641']
out={'method':'Independent direct XML side/stoichiometry and issuing ChEBI SQL/API full structure comparison, independent RDKit InChI structure/atom-charge computation. No author balance/helper reused.','native_species':chem,'steps':evidence,'net_signed_output_minus_input':net,'structural_comparators':comparators,'limitations':['Native CML formula and charge independently checked; native CML coordinates were not used to independently assign stereochemistry. Full native InChI was compared to complete issuing ChEBI InChI and interpreted independently by RDKit.','Pinned SQL full artifact hash is supplied by previously inspected intake; this reviewer read full selected rows but did not repeat the 4.1GB hash.','Chemical agreement does not establish organism-specific experimental function.']}
(O/'independent-chemistry.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'steps':len(evidence),'species':len(chem),'material_facts':sum(len(x['equation']['input'])+len(x['equation']['output']) for x in evidence),'net':net,'result':'all equations atom/charge balanced; exact native and issuing full structures agree'},indent=2))
