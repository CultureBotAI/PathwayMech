from pathlib import Path
import json, hashlib, re, collections, xml.etree.ElementTree as E
import yaml
P=Path('/private/tmp/pathwaymech-next-262-independent-science')
sha=lambda b:hashlib.sha256(b).hexdigest()
y=yaml.safe_load((P/'initial-maintained-record.yaml').read_text())
chem=json.loads((P/'independent-chemistry.json').read_text())
bindings=json.loads((P/'original-native-inventory.json').read_text())['objects']
objs={r['frame']:next(x for x in E.parse(r['path']).getroot() if x.get('frameid')==r['frame']) for r in bindings}
rxmap={r['native']:r['selected'] for r in chem['steps']}
cpmap={n:r['selected_id'] for n,r in chem['native_species'].items()}
cpmap.update({'FE+2':'CHEBI:29033','MG+2':'CHEBI:18420','MN+2':'CHEBI:29035','CU+2':'CHEBI:29036','AG+':'CHEBI:49468','FE+3':'CHEBI:29034','N-ETHYLMALEIMIDE':'CHEBI:44485','IODOACETATE':'CHEBI:747879','ZN+2':'CHEBI:29105','HG+2':'CHEBI:16793','K+':'CHEBI:29103','CA+2':'CHEBI:29108','TIRON':'CHEBI:9607','OXOPENTENOATE':'CHEBI:11641','CPD-3618':'CHEBI:28644','OXALACETIC_ACID':'CHEBI:16452','CPD-10145':'CHEBI:5020','CO+2':'CHEBI:48828','OXALATE':'CHEBI:30623','CCO-CYTOSOL':'GO:0005829','CCO-CHLOROPLAST':'GO:0009507'})
mapped=lambda n:rxmap.get(n,cpmap.get(n,'MetaCyc:'+n))
frames=lambda o,p:[x.get('frameid') for x in o.findall(p) if x.get('frameid')]
edges={e['id']:e for e in y['mechanistic_edges']}
def triple(e):return (e['subject'],e['predicate'],e['object'])
def exact(e,t):assert triple(e)==t,(e['id'],triple(e),t)
results=[]
for eid,e in edges.items():
 if not eid.startswith('n'):continue
 n=int(eid[1:]);support=[]
 if n<=28:
  found=[]
  for s in chem['steps']:
   for side,pred in [('input','consumes'),('output','produces')]:
    for c in s['equation'][side]:
     t=(c['id'],pred,s['selected']) if side=='input' else (s['selected'],pred,c['id'])
     if t==triple(e):found.append({'native_reaction':s['native'],'native_species':c['native'],'coefficient':c['coefficient'],'side':side})
  assert len(found)==1;support=found
 elif n<=37:
  o=objs[e['subject'].split(':',1)[1]];children=frames(o,'reaction-list/*');assert e['object'] in [mapped(x) for x in children];support=[{'slot':'reaction-list','native_members':children}]
 elif n<=43:
  a=next(s for s in chem['steps'] if s['selected']==e['subject']);b=next(s for s in chem['steps'] if s['selected']==e['object']);same=set(c['id'] for c in a['equation']['output'])&set(c['id'] for c in b['equation']['input']);assert len(same)==1;support=[{'exact_shared_intermediate':list(same)}]
 elif n<=49:
  a=e['evidence'][0];m=re.search(r'frameid="([^"]+)".*reaction-ordering\[(\d+)\]',a['source_locator']);o=objs[m[1]].findall('reaction-ordering')[int(m[2])-1];pred=frames(o,'predecessor-reactions/*');current=frames(o,'Reaction');assert [mapped(x) for x in pred]==[e['subject']] and [mapped(x) for x in current]==[e['object']];support=[{'native_xml':E.tostring(o,encoding='unicode')}]
 elif n<=126:
  a=next(a for a in e['evidence'] if '/enzyme[' in a.get('source_locator',''));f=re.search('frameid="([^"]+)"',a['source_locator'])[1];o=objs[f];enzyme=frames(o,'enzyme/*');reaction=frames(o,'reaction/*');assert len(enzyme)==len(reaction)==1 and e['subject']=='MetaCyc:'+enzyme[0];assert e['object'] in ['MetaCyc:'+f,mapped(reaction[0])];ecodes=frames(o,'evidence/Evidence-Code');support=[{'native_activity':f,'enzyme':enzyme[0],'reaction':reaction[0],'evidence_classes':ecodes,'graph_predicate':e['predicate'],'primary_scope_override':f in ['ENZRXN-14218','ENZRXN-16328','ENZRXN-16329'],'endpoint_qualifiers':e.get('endpoint_qualifiers',[])}]
  weak={'ENZRXN-11713','ENZRXN-11706','ENZRXN-11711','ENZRXN-3584','ENZRXN-26159','ENZRXN-21046','MHPF-ENZRXN','ENZRXN-14218','ENZRXN-16328','ENZRXN-16329'}
  assert e['predicate']==('enables' if f in weak else 'catalyzes')
 elif n<=140:
  o=objs[e['subject'].split(':',1)[1]];c=[a for a in o.findall('component') if 'MetaCyc:'+frames(a,'Protein')[0]==e['object']];assert len(c)==1;support=[{'component_xml':E.tostring(c[0],encoding='unicode'),'coefficient':c[0].findtext('coefficient')}]
 elif n<=146:
  f=re.search('frameid="([^"]+)"',e['evidence'][0]['source_locator'])[1];o=objs[f];assert [mapped(x) for x in frames(o,'enzyme/*')]==[e['subject']] and e['object'] in [mapped(x) for x in frames(o,'cofactor/*')];support=[{'native_activity':f,'cofactors':frames(o,'cofactor/*')}]
 elif n<=180:
  f=re.search('frameid="([^"]+)"',e['evidence'][0]['source_locator'])[1];o=objs[f];a=frames(o,'regulator/*');b=frames(o,'regulated-entity/*');mode=o.findtext('mode');assert len(a)==len(b)==1;exact(e,(mapped(a[0]),{'-':'inhibits','+':'activates'}[mode],mapped(b[0])));support=[{'native_regulation':f,'regulator':a[0],'entity':b[0],'mode':mode}]
 else:
  o=objs[e['subject'].split(':',1)[1]];loc=frames(o,'location/*');assert e['object'] in [mapped(x) for x in loc];support=[{'native_locations':loc,'scope':'physical protein location; no whole-pathway occurrence inferred'}]
 results.append({'edge':eid,'triple':triple(e),'direct_source_support':support,'verdict':'supported within stated native/primary scope'})
assert len(results)==185
# Independently enumerate the source-forward denominator rather than import author dispositions.
activities=[];regs=[]
for f,o in objs.items():
 if o.tag=='Enzymatic-Reaction':
  r=frames(o,'reaction/*');enzyme=frames(o,'enzyme/*');formal=any(x in rxmap for x in r);matches=[e['id'] for e in edges.values() if e['object']=='MetaCyc:'+f]
  disposition='represented native activity' if matches else 'exact E. coli AdhE instance explicitly excluded by PWY-5162' if formal and enzyme==['ADHE-CPLX'] else 'adjacent reaction outside the seven-step oxidative route'
  assert matches or not formal or enzyme==['ADHE-CPLX']
  activities.append({'frame':f,'reaction':r,'enzyme':enzyme,'formal':formal,'edges':matches,'disposition':disposition})
 if o.tag=='Regulation':
  b=frames(o,'regulated-entity/*');a=frames(o,'regulator/*');matches=[r['edge'] for r in results if any(z.get('native_regulation')==f for z in r['direct_source_support'])]
  disposition='represented exact native sign' if matches else 'rejected native NADH inhibition; independently read PMID8419288 delayed-reporter experiments establish positive stimulation' if b==['ENZRXN-13575'] and a==['NADH'] else 'excluded exact AdhE/adjacent activity regulator'
  assert matches or (b==['ENZRXN-13575'] and a==['NADH']) or all(not any(e['object']=='MetaCyc:'+z for e in edges.values()) for z in b)
  regs.append({'frame':f,'entity':b,'regulator':a,'mode':o.findtext('mode'),'edges':matches,'disposition':disposition})
assert len(activities)==56 and sum(a['formal'] for a in activities)==41
assert len(regs)==52 and sum(bool(a['edges']) for a in regs)==34
native_taxa=frames(objs['PWY-5420'],'species/Organism');assert [t['id'] for t in y['taxa']]==['NCBITaxon:'+x[4:] for x in native_taxa if x.startswith('TAX-')]
assert 'ORG-5948' in native_taxa
biological_nodes=[]
for n in y['participants']:
 if n['category'] not in ['protein','complex','gene']:continue
 f=n['id'].split(':',1)[1];o=objs[f];biological_nodes.append({'id':n['id'],'kind':o.tag,'gene':frames(o,'gene/*'),'species':frames(o,'species/*'),'components':frames(o,'component/Protein'),'product':frames(o,'product/*')})
assert len(biological_nodes)==84
out={'initial_target_sha256':sha((P/'initial-maintained-record.yaml').read_bytes()),'method':'Independent typed replay from the 343 original XML objects; no author coverage verifier reused. Chemistry independently computed in independent-chemistry.json. Native narrative material independently read in full 72-object prose projection. Primary override judgments are separate human-level scientific assessments, not inferred from this program.','native_edges':results,'source_forward_activities':activities,'source_forward_regulators':regs,'biological_nodes':biological_nodes,'parent_taxa':native_taxa,'uncovered_formal_activities':[],'errors':[]}
(P/'independent-native-semantic-replay.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'native_edges':len(results),'activities':len(activities),'formal':sum(a['formal'] for a in activities),'regulators':len(regs),'represented_regulators':sum(bool(a['edges']) for a in regs),'biological_nodes':len(biological_nodes)}))
