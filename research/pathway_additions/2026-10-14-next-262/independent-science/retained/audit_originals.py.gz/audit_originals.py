from pathlib import Path
import json, hashlib, xml.etree.ElementTree as ET, collections, re, datetime
import yaml
OUT=Path('/private/tmp/pathwaymech-next-262-independent-science')
BASE=Path('/private/tmp/pathwaymech-next-262-20261014')
PREVIEW=Path('/private/tmp/pathwaymech-next-262-primary-author/combined-author-preview.yaml')
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(n,x): (OUT/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
packages=[]
for name in ['native-author','primary-author','native','chemistry','primary','biological-identity','discovery']:
 p=Path('/private/tmp/pathwaymech-next-262-'+name); mf=p/'artifact-manifest.json'; m=json.loads(mf.read_text()); rows=m['files']; actual={str(q.relative_to(p)) for q in p.rglob('*') if q.is_file() and q!=mf}; expected={r['path'] for r in rows}
 assert actual==expected,(name,actual-expected,expected-actual)
 for r in rows:
  b=(p/r['path']).read_bytes(); assert len(b)==r['bytes'] and sha(b)==r['sha256'],r
 packages.append({'package':name,'manifest_sha256':sha(mf.read_bytes()),'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'exact_hidden_inclusive_inventory':True})
dump('independent-package-intake.json',{'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packages':packages})
rows=json.loads(Path('/private/tmp/pathwaymech-next-262-native/compact-original-source-bindings.json').read_text()); xmls={}; directcounts=collections.Counter(); original_bindings=[]
for r in rows:
 p=Path(r['path']);b=p.read_bytes();assert sha(b)==r['sha256']; root=ET.fromstring(b); obj=[e for e in root if e.get('frameid')==r['frame']];assert len(obj)==1 and obj[0].get('detail')=='full';o=obj[0];xmls[r['frame']]=o
 for slot in o: directcounts[slot.tag]+=1
 original_bindings.append({'frame':r['frame'],'path':str(p),'sha256':sha(b),'kind':o.tag,'slots':len(o)})
dump('original-native-inventory.json',{'objects':original_bindings,'count':len(xmls),'slots':sum(directcounts.values()),'slot_counts':dict(directcounts)})
y=yaml.safe_load(PREVIEW.read_text()); refs={r['id']:r for r in y['references']}; nodes={n['id']:n for k in ['participants','reactions','taxa'] for n in y[k]};nodes[y['id']]=y
matched=[]; errors=[]
for e in y['mechanistic_edges']:
 assert e['subject'] in nodes and e['object'] in nodes
 for place,items in [('edge',e['evidence'])]+[(q['endpoint']+' qualifier',q['evidence']) for q in e.get('endpoint_qualifiers',[])]:
  for index,a in enumerate(items):
   assert a['reference_id'] in refs
   assert len(a.get('quote',a.get('source_assertion','')))<=400
   loc=a.get('source_locator','')
   if loc.startswith('/ptools-xml/'):
    evidence_slots=[]
    for locpart in loc.split('; '):
     m=re.fullmatch(r'/ptools-xml/([^\[]+)\[@frameid="([^"]+)"\]/([^\[]+)\[(\d+)\]',locpart)
     if not m:errors.append({'edge':e['id'],'place':place,'locator':locpart,'error':'unsupported locator syntax'});continue
     kind,frame,slot,ordinal=m.groups();o=xmls.get(frame)
     if o is None:errors.append({'edge':e['id'],'frame':frame,'error':'source original not in finite native cohort'});continue
     assert o.tag==kind; found=o.findall(slot)
     assert 1<=int(ordinal)<=len(found),(e['id'],locpart)
     x=found[int(ordinal)-1];evidence_slots.append({'locator':locpart,'xml':ET.tostring(x,encoding='unicode')})
    matched.append({'edge':e['id'],'place':place,'evidence_index':index,'assertion':a.get('source_assertion'),'original_slots':evidence_slots})
dump('independent-native-evidence-slots.json',{'preview_sha256':sha(PREVIEW.read_bytes()),'evidence_occurrences':matched,'errors':errors})
# Independent complete material/biology reading projections from direct native objects.
read=[]
for frame,o in xmls.items():
 if o.tag not in ['Pathway','Enzymatic-Reaction','Regulation','Protein','Gene','Organism']:continue
 row={'frame':frame,'kind':o.tag,'slots':[]}
 for slot in o:
  if slot.tag in ['comment','reaction-list','predecessors','reaction-layout','species','taxonomic-range','enzymatic-reaction','enzyme','reaction','reaction-direction','physiologically-relevant','cofactors','cofactor','regulators','regulated-by','regulator','regulated-entity','mode','mechanism','evidence','catalyzes','component-of','component','components','gene','product','location','common-name','synonym','molecular-weight-exp','ph-opt','temperature-opt','alternative-substrate','alternative-cofactor','km','kcat','vmax','kinetic','pI','dblink']:
   row['slots'].append({'slot':slot.tag,'text':' '.join(slot.itertext()).strip(),'children':[(a.tag,a.attrib) for a in slot]})
 read.append(row)
dump('independent-direct-biological-reading.json',read)
print(json.dumps({'packages':packages,'native_originals':len(xmls),'native_direct_slots':sum(directcounts.values()),'original_evidence_occurrences':len(matched),'errors':errors},indent=2))
