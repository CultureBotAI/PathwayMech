from pathlib import Path
import gzip,hashlib,json,collections,xml.etree.ElementTree as E
P=Path('/private/tmp/pathwaymech-next-262-independent-science')
path=Path('/private/tmp/pathwaymech-curation-authorities/rhea.rdf.gz')
R='{http://www.w3.org/1999/02/22-rdf-syntax-ns#}'
D=collections.defaultdict(lambda:collections.defaultdict(list)); fragments=0
for _,o in E.iterparse(gzip.open(path,'rb'),events=['end']):
 key=o.get(R+'about')
 if not key:continue
 fragments+=1
 for c in o:
  k=c.tag.split('}',1)[-1];v=c.get(R+'resource',c.text or '')
  if v not in D[key][k]:D[key][k].append(v)
 o.clear()
rh=lambda x:'http://rdf.rhea-db.org/'+x
chem=json.loads((P/'independent-chemistry.json').read_text())
sources=[];selected=[];closure={}
def visit(k):
 if k in closure:return
 closure[k]=dict(D[k])
 for name,vs in D[k].items():
  if name in ['substrates','products','compound','chebi','contains'] or name.startswith('contains'):
   for v in vs:
    if v in D:visit(v)
def side(k):
 out=collections.Counter()
 for name,vs in D[k].items():
  if not name.startswith('contains') or not name[8:].isdigit():continue
  coeff=int(name[8:])
  for part in vs:
   comp=D[part]['compound'];assert len(comp)==1,(part,D[part])
   cb=D[comp[0]]['chebi'];assert len(cb)==1,(comp,D[comp[0]])
   cb=cb[0].split('/')[-1].replace('CHEBI_','CHEBI:');out[cb]+=coeff
 return dict(out)
for s in chem['steps']:
 if not s['selected'].startswith('RHEA:'):continue
 k=rh(s['selected'].split(':')[1]);visit(k)
 a=side(D[k]['substrates'][0]);b=side(D[k]['products'][0]);ea={r['id']:r['coefficient'] for r in s['equation']['input']};eb={r['id']:r['coefficient'] for r in s['equation']['output']};assert a==ea and b==eb,(s['selected'],a,b,ea,eb)
 selected.append({'id':s['selected'],'substrates':a,'products':b,'native_reaction':s['native'],'original_rhea_equation':D[k]['equation'],'approved':rh('Approved') in D[k]['status']})
# The two tempting native xrefs refer to a different state/stereochemistry.
for id in ['32214','24261']:
 k=rh(id);visit(k);selected.append({'rejected_native_xref':'RHEA:'+id,'equation':D[k]['equation'],'all_original_properties':dict(D[k])})
extra=Path('/private/tmp/pathwaymech-next-262-primary-extra-chemistry/ChEBI-58349.json');n=json.loads(extra.read_text());assert n['chebi_accession']=='CHEBI:58349' and n['chemical_data']['charge']==-3 and n['chemical_data']['formula']=='C21H25N7O17P3';assert any(x['init_id']==18009 and x['relation_type']=='is conjugate acid of' and x['final_id']==58349 for x in n['ontology_relations']['incoming_relations'])
out={'method':'Independent whole original RDF streaming parse, merge all subject fragments, then direct selected reaction-side/contains-coefficient/participant/compound/ChEBI traversal; compare to independently computed native chemistry, not author Rhea projection.','original':{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()},'fragments':fragments,'subjects':len(D),'selected_equations':selected,'selected_original_closure':closure,'nadp':{'original':str(extra),'sha256':hashlib.sha256(extra.read_bytes()).hexdigest(),'chemical_data':n['chemical_data'],'incoming_relations':n['ontology_relations']['incoming_relations'],'interpretation':'CHEBI58349 is the conjugate-base normalization of assay NADP+, not experimental determination of assay protonation.'},'errors':[]}
(P/'independent-rhea-and-nadp.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'fragments':fragments,'subjects':len(D),'selected_equations':len(selected),'closure':len(closure),'errors':[]}))
