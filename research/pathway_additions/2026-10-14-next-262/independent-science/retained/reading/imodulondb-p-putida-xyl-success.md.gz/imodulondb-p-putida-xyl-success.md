# iModulonDB search: `xyl`

- dataset: `p_putida/precise321`
- genes: 10
- iModulons: 1

## iModulons

| key | name | regulators | category | function | match |
|---|---|---|---|---|---|
| `p_putida/precise321/56` | PP_5350 | PP_5350 | Carbon | Glyoxylate and dicarboxylate metabolism | function=Glyoxylate and dicarboxylate metabolism |

## Genes

| key | name | product | match |
|---|---|---|---|
| `p_putida/precise321/PP_0437` | birA | bifunctional biotin-[acetyl-CoA-carboxylase] ligase/biotin operon repressor BirA | gene_product=bifunctional biotin-[acetyl-CoA-carboxylase] ligase/biotin operon repressor BirA |
| `p_putida/precise321/PP_0558` | accC | acetyl-CoA carboxylase - biotin carboxylase subunit | gene_product=acetyl-CoA carboxylase - biotin carboxylase subunit |
| `p_putida/precise321/PP_0567` | speA | Biosynthetic arginine decarboxylase | gene_product=Biosynthetic arginine decarboxylase |
| `p_putida/precise321/PP_0787` | nadC | quinolinate phosphoribosyltransferase (decarboxylating) monomer | gene_product=quinolinate phosphoribosyltransferase (decarboxylating) monomer |
| `p_putida/precise321/PP_0864` | speC | ornithine decarboxylase | gene_product=ornithine decarboxylase |
| `p_putida/precise321/PP_0862` | PP_0862 | PKHD-type hydroxylase PP_0862 | gene_product=PKHD-type hydroxylase PP_0862 |
| `p_putida/precise321/PP_1066` | dctD-II | C4-dicarboxylate transport transcriptional regulatory protein | gene_product=C4-dicarboxylate transport transcriptional regulatory protein |
| `p_putida/precise321/PP_1127` | estC | Carboxylesterase | gene_product=Carboxylesterase |
| `p_putida/precise321/PP_1168` | PP_1168 | putative TRAP dicarboxylate transporter, DctQ subunit | gene_product=putative TRAP dicarboxylate transporter, DctQ subunit |
| `p_putida/precise321/PP_0263` | dctD-I | C4-dicarboxylate transport transcriptional regulatory protein | gene_product=C4-dicarboxylate transport transcriptional regulatory protein |
