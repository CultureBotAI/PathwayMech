# iModulonDB search: `mhp`

- dataset: `e_coli/precise_mg1655`
- genes: 8
- iModulons: 0

## iModulons

| key | name | regulators | category | function | match |
|---|---|---|---|---|---|

## Genes

| key | name | product | match |
|---|---|---|---|
| `e_coli/precise_mg1655/b0349` | mhpC | 2-hydroxy-6-ketonona-2,4-dienedioate hydrolase | gene_name=mhpC |
| `e_coli/precise_mg1655/b0350` | mhpD | 2-hydroxypentadienoate hydratase | gene_name=mhpD |
| `e_coli/precise_mg1655/b0351` | mhpF | acetaldehyde dehydrogenase (acetylating) MhpF | gene_name=mhpF |
| `e_coli/precise_mg1655/b0353` | mhpT | 3-hydroxyphenylpropionate\/3-hydroxycinnamate:H(+) symporter | gene_name=mhpT |
| `e_coli/precise_mg1655/b0352` | mhpE | 4-hydroxy-2-oxovalerate aldolase | gene_name=mhpE |
| `e_coli/precise_mg1655/b0347` | mhpA | 3-(3-hydroxyphenyl)propanoate hydroxylase | gene_name=mhpA |
| `e_coli/precise_mg1655/b0346` | mhpR | DNA-binding transcriptional activator MhpR | gene_name=mhpR |
| `e_coli/precise_mg1655/b0348` | mhpB | 3-carboxyethylcatechol 2,3-dioxygenase | gene_name=mhpB |
