# iModulonDB search: `catechol`

- dataset: `p_putida/precise321`
- genes: 2
- iModulons: 0

## iModulons

| key | name | regulators | category | function | match |
|---|---|---|---|---|---|

## Genes

| key | name | product | match |
|---|---|---|---|
| `p_putida/precise321/PP_3166` | catA-II | catechol 1,2-dioxygenase | gene_product=catechol 1,2-dioxygenase |
| `p_putida/precise321/PP_3713` | catA-I | catechol 1,2-dioxygenase | gene_product=catechol 1,2-dioxygenase |
