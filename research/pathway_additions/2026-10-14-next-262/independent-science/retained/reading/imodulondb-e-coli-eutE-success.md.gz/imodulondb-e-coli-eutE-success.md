# iModulonDB search: `eutE`

- dataset: `e_coli/precise_mg1655`
- genes: 1
- iModulons: 0

## iModulons

| key | name | regulators | category | function | match |
|---|---|---|---|---|---|

## Genes

| key | name | product | match |
|---|---|---|---|
| `e_coli/precise_mg1655/b2455` | eutE | acetaldehyde dehydrogenase (acetylating) EutE | gene_name=eutE |
