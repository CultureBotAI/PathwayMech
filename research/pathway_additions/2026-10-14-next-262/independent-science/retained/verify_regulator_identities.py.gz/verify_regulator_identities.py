import sqlite3,xml.etree.ElementTree as E,json,hashlib,ast
from pathlib import Path
P=Path('/private/tmp/pathwaymech-next-262-independent-science')
tree=ast.parse((P/'replay_native_semantics.py').read_text())
m=next(ast.literal_eval(n.value.args[0]) for n in tree.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='update')
s=sqlite3.connect('file:/private/tmp/pathwaymech-curation-authorities/chebi.db?mode=ro',uri=True);out=[]
for f,id in m.items():
 p=Path('/private/tmp/pathwaymech-next-262-native/originals')/('META-'+f+'.xml');o=next(x for x in E.parse(p).getroot() if x.get('frameid')==f)
 if id.startswith('GO:'):
  assert o.findtext('goid')==id;out.append({'native':f,'id':id,'native_goid':o.findtext('goid'),'definition':o.findtext('definition')});continue
 ids=[d.findtext('dblink-oid') for d in o.findall('dblink') if d.findtext('dblink-db')=='CHEBI'];assert len(ids)==1
 r=s.execute('select predicate,object,value from statements where subject=?',(id,)).fetchall();native_inchi=o.findtext('inchi');props={pred:v if v is not None else ob for pred,ob,v in r};basis={}
 if native_inchi:assert props['chemrof:inchi_string']==native_inchi;basis={'exact_full_inchi':native_inchi}
 else:
  assert f=='TIRON' and ids==['9607'];syn=[x.text for x in o.findall('synonym')];assert 'disodium 4,5-dihydroxybenzene-1,3-disulfonate' in syn;assert props['chemrof:generalized_empirical_formula']=='C6H4O8S2.2Na';assert abs(float(o.findtext('molecular-weight'))-float(props['chemrof:mass']))<0.1
  basis={'native_structure_limitation':'No native InChI or CML; exact native ChEBI xref, disodium 4,5-dihydroxybenzene-1,3-disulfonate synonym and molecular mass agree with issuing structure/formula. No independent native atom-level structure comparison is claimed.','native_mass':o.findtext('molecular-weight'),'issuing_formula':props['chemrof:generalized_empirical_formula'],'issuing_inchi':props['chemrof:inchi_string']}
 old='CHEBI:'+ids[0];conflict=[]
 if old!=id:
  rr=s.execute('select predicate,object,value from statements where subject=?',(old,)).fetchall();pr={pred:v if v is not None else ob for pred,ob,v in rr};assert f=='IODOACETATE' and old=='CHEBI:74571' and id=='CHEBI:747879' and props['chemrof:charge']=='-1' and pr['chemrof:charge']=='0'
  conflict={'native_xref_wrong_neutral_form':old,'native_full_inchi_matches_selected_anion':True,'wrong_xref_label':pr['rdfs:label'],'wrong_xref_inchi':pr['chemrof:inchi_string']}
 out.append({'native':f,'selected_id':id,'native_xref':old,**basis,'authority_label':props['rdfs:label'],'charge':props['chemrof:charge'],'xref_conflict':conflict,'native_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(P/'independent-regulator-identities.json').write_text(json.dumps({'method':'Independent full native versus issuing pinned ChEBI InChI comparison for additional mapped native regulator/cofactor compounds where native structure exists; exact named-disodium-salt/identifier/formula/mass comparison for TIRON; direct native goid for both physical locations.','helper_attempt_notes':['Initial inline helper assumed an obsolete redirect for IODOACETATE and failed: actual source is a neutral/anion xref conflict, resolved by complete structure and charge, not by obsolete-ID replacement.','Second inline helper assumed every native compound had InChI and failed for TIRON; the final explicit TIRON rule preserves this source limitation.'],'identities':out},indent=2)+'\n')
print(json.dumps({'independently_compared':len(out),'exact_full_inchi':sum('exact_full_inchi' in r for r in out),'named_salt_without_native_inchi':sum('native_structure_limitation' in r for r in out),'native_GO_ids':sum('native_goid' in r for r in out),'native_xref_conflicts':sum(bool(r.get('xref_conflict')) for r in out)}))
