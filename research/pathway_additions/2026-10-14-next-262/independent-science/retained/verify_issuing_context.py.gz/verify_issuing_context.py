from pathlib import Path
import json,hashlib,re,xml.etree.ElementTree as E
B=Path('/private/tmp/pathwaymech-next-262-biological-identity'); P=Path('/private/tmp/pathwaymech-next-262-primary'); O=Path('/private/tmp/pathwaymech-next-262-independent-science')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads(Path('/private/tmp/pathwaymech-next-262-20261014/research/pathway_additions/2026-10-14-next-262/integration/issuing-structure-context.json').read_text())
for r in manifest['sources']: assert sha(Path(r['path']))==r['sha256'] and Path(r['path']).stat().st_size==r['bytes']
seqs={}
for p in (B/'originals').rglob('*.json'):
 try:j=json.loads(p.read_text())
 except:continue
 if isinstance(j,dict) and 'primaryAccession' in j and 'sequence' in j:seqs[j['primaryAccession']]={'sequence':j['sequence']['value'],'path':str(p),'sha256':sha(p),'gene_names':j.get('genes'),'entry_type':j.get('entryType'),'organism':j.get('organism')}
cds=[]
for p in sorted((B/'originals/exact-follow').glob('*.xml')):
 root=E.parse(p); a=root.find('.//GBSeq_accession-version').text;s=root.find('.//GBSeq_sequence').text.upper();qual={}
 for q in root.findall('.//GBQualifier'):qual.setdefault(q.findtext('GBQualifier_name'),[]).append(q.findtext('GBQualifier_value'))
 matches=[k for k,v in seqs.items() if v['sequence']==s]
 cds.append({'accession':a,'path':str(p),'sha256':sha(p),'length':len(s),'definition':root.findtext('.//GBSeq_definition'),'qualifiers':qual,'identical_complete_UniProt':matches})
embl=P/'originals/AP3-AB020521.embl';t=embl.read_text();dna=re.sub('[^acgt]','',t.split('SQ   Sequence ')[1].split('\n',1)[1].lower());blocks=re.split(r'^FT   CDS\s+',t,flags=re.M)[1:]; ap3=[]
# Standard bacterial translation table11: codon identity equals standard code; all chosen CDS begin ATG.
bases='TCAG';aa='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG';codes={a+b+c:aa[i] for i,(a,b,c) in enumerate((a,b,c) for a in bases for b in bases for c in bases)}
for block in blocks:
 m=re.match(r'(\d+)\.\.(\d+)',block)
 if not m:continue
 q=re.split(r'\nFT   [A-Za-z]',block,1)[0];acc=re.search(r'/protein_id="([^"]+)"',q)
 if not acc or acc[1] not in ['BAB03534.1','BAB03535.1','BAB03536.1']:continue
 start,end=map(int,m.groups());sub=dna[start-1:end].upper(); translated=''.join(codes[sub[i:i+3]] for i in range(0,len(sub),3));declared=re.search(r'/translation="([^"]+)"',q,re.S)[1];declared=re.sub(r'\s','',re.sub(r'^FT\s+','',declared,flags=re.M))
 assert translated[:-1]==declared and translated[-1]=='*'; direct=E.parse(B/'originals/exact-follow'/f'{acc[1]}.xml').findtext('.//GBSeq_sequence').upper();assert direct==declared
 ap3.append({'accession':acc[1],'coordinates':[start,end],'gene':re.search(r'/gene="([^"]+)"',q)[1],'function':re.search(r'/function="([^"]+)"',q)[1],'translated_length':len(declared),'translation_matches_NCBI_protein':True,'UniProt_exact_matches':[k for k,v in seqs.items() if v['sequence']==declared]})
structures=[]
for entry in ['8IH6','1BJP']:
 if entry=='8IH6':ep=B/'originals/structure-lead/RCSB-8IH6-entry.json';pol=[B/'originals/exact-follow'/f'8IH6-polymer{i}.json' for i in [1,2]];aps=[B/'originals/exact-follow/8IH6-assembly1.json']
 else:ep=P/'originals/RCSB-1BJP-entry.json';pol=[P/'originals/RCSB-1BJP-polymer1.json'];aps=[P/'originals'/f'RCSB-1BJP-assembly{i}.json' for i in [1,2,3]]
 ej=json.loads(ep.read_text());row={'entry':entry,'entry_sha256':sha(ep),'DOI':ej['database_2'],'citation':ej.get('citation'),'polymers':[],'assemblies':[]}
 for pp in pol:
  pj=json.loads(pp.read_text());si=pj['entity_poly']['pdbx_seq_one_letter_code_can'];u=pj['rcsb_polymer_entity_container_identifiers']['uniprot_ids'][0]
  if u=='Q01468':up=Path('/private/tmp/pathwaymech-next-261-biological-identities/originals/initial/uniprot-Q01468.json');uj=json.loads(up.read_text()); us=uj['sequence']['value'];assert us[1:]==si;relation='removal of initial M'
  else:us=seqs[u]['sequence'];prefix={'Q9KWS4':'ADLNW','Q9KWS3':'AA'}[u];assert si==prefix+us;relation='N-terminal '+prefix+' addition'
  row['polymers'].append({'path':str(pp),'sha256':sha(pp),'canonical_sequence':si,'UniProt':u,'source_sequence_length':len(us),'relation':relation,'asym_ids':pj['rcsb_polymer_entity_container_identifiers']['asym_ids'],'source_gen':pj['entity_src_gen']})
 for ap in aps:
  j=json.loads(ap.read_text());a=j['pdbx_struct_assembly'];info=j['rcsb_assembly_info'];row['assemblies'].append({'path':str(ap),'sha256':sha(ap),'assembly':a,'protein_instance_count':info['polymer_entity_instance_count_protein'],'generators':j['pdbx_struct_assembly_gen'],'global_symmetry':[x for x in j.get('rcsb_struct_symmetry',[]) if x['kind']=='Global Symmetry']});assert a['oligomeric_count']==(10 if entry=='8IH6' else 6)
 structures.append(row)
result={'bound_record_sha256':sha(O/'initial-maintained-record.yaml'),'manifest_all_15_original_hashes_independently_checked':True,'native_CDS_protein_pairs':cds,'ENA_AB020521_1':{'path':str(embl),'sha256':sha(embl),'sequence_length':len(dna),'CDS':ap3},'structures':structures,'limitations':['Complete sequence equality does not establish the historical assay preparation or biological oligomerization.','1BJP chemical modification is checked separately against mmCIF and indexed experimental abstract.']}
assert len(cds)==9 and len(ap3)==3
(O/'independent-issuing-context.json').write_text(json.dumps(result,indent=2)+'\n');print({'cds':len(cds),'matching_CDS':[(x['accession'],x['identical_complete_UniProt']) for x in cds],'ENA':ap3,'structures':[(x['entry'],[(p['UniProt'],p['relation']) for p in x['polymers']]) for x in structures]})
