from pathlib import Path
import json,hashlib,collections,xml.etree.ElementTree as E,datetime,yaml
P=Path('/private/tmp/pathwaymech-next-262-independent-science')
sha=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((P/'original-native-inventory.json').read_text())['objects']; slots=[]; direct=[];nested=[]
for r in inv:
 root=E.fromstring(Path(r['path']).read_bytes());o=next(x for x in root if x.get('frameid')==r['frame']);counts=collections.Counter()
 for s in o:
  counts[s.tag]+=1;loc=f'/ptools-xml/{o.tag}[@frameid="{r["frame"]}"]/{s.tag}[{counts[s.tag]}]'
  slots.append({'frame':r['frame'],'slot':s.tag,'ordinal':counts[s.tag],'locator':loc,'original_sha256':r['sha256'],'direct_xml_sha256':sha(E.tostring(s))})
  for c in s:
   if c.get('frameid'):direct.append((r['frame'],s.tag,counts[s.tag],c.tag,c.get('frameid')))
  for c in s.iter():
   if c.get('frameid'):nested.append((r['frame'],s.tag,counts[s.tag],c.tag,c.get('frameid')))
ledger=json.loads(Path('/private/tmp/pathwaymech-next-262-native/slot-disposition-ledger.json').read_text());look={(r['frame'],r['slot'],r['ordinal']):r for r in ledger};assert len(look)==len(ledger)==len(slots)==5148
for s in slots:
 a=look[(s['frame'],s['slot'],s['ordinal'])];assert a['locator']==s['locator'] and a['source_sha256']==s['original_sha256'];s['observed_author_scope']=a['scope'];s['observed_author_disposition']=a['disposition']
# Every referenced original hash is discoverable in the frozen seven-package byte inventory,
# except the explicitly bound whole Rhea original and new issuing additions.
hashidx=collections.defaultdict(list)
for suffix in ['native-author','primary-author','native','chemistry','primary','biological-identity','discovery']:
 b=Path('/private/tmp/pathwaymech-next-262-'+suffix);m=json.loads((b/'artifact-manifest.json').read_text())
 for r in m['files']:hashidx[r['sha256']].append(str(b/r['path']))
for q in [Path('/private/tmp/pathwaymech-curation-authorities/rhea.rdf.gz'),Path('/private/tmp/pathwaymech-next-261-biological-identities/originals/initial/uniprot-Q01468.json'),Path('/private/tmp/pathwaymech-next-262-primary-extra-chemistry/ChEBI-58349.json')]:hashidx[sha(q.read_bytes())].append(str(q))
y=yaml.safe_load((P/'successor-maintained-record.yaml').read_text());refs=[]
for r in y['references']:
 h=r.get('source_sha256');assert h and h in hashidx,(r['id'],h)
 paths=hashidx[h];assert any(sha(Path(p).read_bytes())==h for p in paths)
 refs.append({'id':r['id'],'url':r['url'],'source_sha256':h,'matching_original_or_source_artifact_paths':paths,'citation_scope':r.get('citation',r.get('source_version'))})
assert len(refs)==210
(P/'independent-source-crosswalk.json').write_text(json.dumps({'method':'Direct original XML enumeration versus finite slot index, plus all maintained reference hashes replayed against frozen source bytes. The slot index is checked for exact denominator/locator/hash completeness; semantic judgments are separately captured by all-native-edge replay, full native material prose reading and primary-claim assessments. Global chemical incidence, bibliography, credit/admin and adjacent-reference links are not automatically pathway claims.','original_count':len(inv),'direct_slots':len(slots),'direct_frame_references':len(direct),'nested_frame_references':len(nested),'slot_index':slots,'references':refs,'errors':[]},indent=2)+'\n')
exe=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/culturebotai-claw/.venv/bin/kg-microbe-sources');module=exe.parents[2]/'src/kg_microbe_sources/imodulondb.py'
cmds=[('datasets','datasets'),('p-putida-catechol','search --organism p_putida --dataset precise321 --query catechol'),('p-putida-xyl','search --organism p_putida --dataset precise321 --query xyl'),('e-coli-mhp','search --organism e_coli --dataset precise_mg1655 --query mhp'),('e-coli-eutE','search --organism e_coli --dataset precise_mg1655 --query eutE')]
receipts=[]
for n,args in cmds:
 p=P/'reading'/f'imodulondb-{n}-success.md';err=P/'reading'/f'imodulondb-{n}-success.stderr';assert p.stat().st_size and not err.stat().st_size
 receipts.append({'command':str(exe)+' imodulondb --timeout 30 '+args,'exit_code':0,'output':str(p),'sha256':sha(p.read_bytes())})
(P/'imodulondb-assessment.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'adapter_path':str(module),'adapter_sha256':sha(module.read_bytes()),'commands':receipts,'initial_attempts':'Default sandbox could not resolve public host; these failed stderr files are preserved. Read-only public-source calls succeeded using approved network access. Web fallback also reported API unavailable.','assessment':'p_putida/precise321 catechol search returns PP_3166 catA-II and PP_3713 catA-I catechol 1,2-dioxygenases (ortho cleavage), not exact historical meta-cleavage catalysts. Broad xyl search yields substring hits and module56 PP_5350 glyoxylate/dicarboxylate function, irrelevant to exact xyl catalysts; no module-based mechanistic assertion accepted. E. coli precise_mg1655 returns mhpD b0350, mhpF b0351, mhpE b0352 and eutE b2455 as gene annotation context, with zero module hits in these queries. Search hits do not establish module membership, whole-route occurrence, physical state, chemistry or catalysis. No additional graph assertion or absence claim follows.','summarize':'Not applicable: no exact relevant iModulon hit that informs the verdict; broad xyl substring module56 is unrelated.','limits':'Bounded named-dataset queries, not exhaustive expression-module or species coverage.'},indent=2)+'\n')
print(json.dumps({'slots':len(slots),'references':len(refs),'direct_refs':len(direct),'nested_refs':len(nested),'imodulondb_commands':len(receipts)}))
