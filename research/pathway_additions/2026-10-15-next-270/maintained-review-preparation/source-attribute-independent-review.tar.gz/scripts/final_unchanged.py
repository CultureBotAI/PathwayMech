"""Recheck the fixed review scope without requiring unrelated root work to stop."""
import hashlib,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1]
W=Path('/private/tmp/pathwaymech-next-270-20261015')
C=Path('/private/tmp/pathwaymech-next-270-ci')
A=Path('/private/tmp/pathwaymech-next-270-native-authority-implementation/candidate')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((R/'results/owner-before.json').read_text())
for row in rows:
 p=W/row['path']; assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],row['path']
inputs=[]
for p in sorted((R/'inputs').iterdir()):
 source=W/'research/pathway_additions/2026-10-15-next-270/authority-source-originals/.gitattributes' if p.name=='applied.gitattributes' else C/p.name
 assert p.read_bytes()==source.read_bytes(),str(source)
 inputs.append({'copy':str(p.relative_to(R)),'source':str(source),'bytes':p.stat().st_size,'sha256':sha(p)})
xmls=json.loads((R/'results/unchanged-source-index.json').read_text())
raw=subprocess.run(['git','--no-optional-locks','ls-files','--stage','-z'],cwd=W,check=True,stdout=subprocess.PIPE).stdout
index={}
for item in raw.split(b'\0'):
 if item:
  meta,path=item.split(b'\t',1); mode,blob,stage=meta.decode().split();index[path.decode()]=(mode,blob,stage)
for row in xmls:
 assert index[row['path']][1:]==(row['index_blob'],'0')
 assert (A/row['path']).read_bytes()==(W/row['path']).read_bytes()
result={'status':'passed','scoped_maintained_owners':len(rows),'all_unchanged':True,'copied_inputs':inputs,'xml_index_and_accepted_body_rechecks':len(xmls),'global_tree_quiescence_required':False,'hidden_ignored_files_included':True,'scope':'Only the 704 fixed owners and 12 retained author inputs, plus 223 accepted source bodies; unrelated new root retention/gate outputs excluded.'}
p=R/'results/final-unchanged.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='copied_inputs'}))
