# Bounded reproduction

Use the existing verified interpreter with `PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`. No installation is required.

Do not rerun scripts into this frozen owner. Copy `scripts/` and `inputs/` into a new absent scratch owner, create `results/`, then run `scripts/review_attributes.py` followed by `scripts/final_unchanged.py`. The scripts use read-only Git operations against the worktree and compare fixed index trees plus the accepted authority candidate. They intentionally fail if required current scoped owners differ or the worktree is no longer available. They do not require unrelated tree quiescence. The `-c core.ignorecase=false` check is a per-command override, not a Git configuration write.

The preserved initial `attempts/review_attributes-uppercase-negative.py` is a failed historical harness; it is not the current producer. Its assumption about case-sensitive pattern matching is intentionally not repaired in place.

Review evidence is in `results/review-result.json`, `results/attribute-probes.json`, `results/unchanged-source-index.json`, `results/commands.json`, and `results/final-unchanged.json`. Original root failure and applied receipts are in `inputs/`. The actual 223 source bodies are not redundantly copied; their exact hashes/index object IDs and frozen authority locations are bound in the receipts. Initial and applied Git trees remain explicit. The manifest inventories every regular physical artifact except itself and `freeze-proof.json`; the proof binds that manifest and substantive reports.
