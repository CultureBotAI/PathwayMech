"""Read-only scoped acceptance of N270-R02; never normalizes source bytes."""
import hashlib,json,re,subprocess
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=Path('/private/tmp/pathwaymech-next-270-20261015')
A=Path('/private/tmp/pathwaymech-next-270-native-authority-implementation/candidate')
owner='research/pathway_additions/2026-10-15-next-270/authority-source-originals'
attr=owner+'/.gitattributes'
before_tree='547a82389109bb355a5a7e9a2fc83f8402f8aed6'
after_tree='2e3307207f1423634c18f7e0ee6c6903e56f7fe1'
checks=[];commands=[]
def check(ok,label):checks.append(label);assert ok,label
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(n,x):p=R/n;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(json.dumps(x,indent=2)+'\n')
def git(*args,input=None,expected=0):
 command=['git','--no-optional-locks',*args]
 run=subprocess.run(command,cwd=W,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 commands.append({'command':command,'exit_code':run.returncode,'stdout_bytes':len(run.stdout),'stderr':run.stderr.decode(errors='replace')})
 check(run.returncode==expected,'command exit '+str(args))
 return run.stdout
def tree_rows(tree):
 rows={}
 for value in git('ls-tree','-rz',tree).split(b'\0'):
  if not value:continue
  meta,path=value.split(b'\t',1);mode,kind,blob=meta.decode().split();rows[path.decode()]={'mode':mode,'kind':kind,'blob':blob}
 return rows
before=tree_rows(before_tree);after=tree_rows(after_tree)
check(set(after)-set(before)=={attr} and not set(before)-set(after),'only one added tree path')
check(all(after[p]==v for p,v in before.items()),'every preexisting staged tree entry exact')
body=(W/attr).read_bytes()
check(hashlib.sha256(body).hexdigest()=='7f12bedf58cfc88064420816fc4bd0a5c23f50b089c7afc312dbe0e8ba238d9f','exact released attributes')
check(body==b'# Preserve exact issuing-source XML bytes, including original end-of-line spaces.\n/originals/*.xml -text whitespace=-blank-at-eol\n/all-reference-originals/*.xml -text whitespace=-blank-at-eol\n','exact comment and two immediate-directory rules')
check(git('show',after_tree+':'+attr)==body,'applied tree attributes exact')
(R/'inputs/applied.gitattributes').write_bytes(body)
index={}
for value in git('ls-files','--stage','-z').split(b'\0'):
 if not value:continue
 meta,path=value.split(b'\t',1);mode,blob,stage=meta.decode().split();index[path.decode()]={'mode':mode,'blob':blob,'stage':stage}
snapshot=read(R/'inputs/candidate-owner-snapshot-during-gates.json')
check(len(snapshot['files'])==703,'703 prior proposed owners')
bindings=[]
for row in snapshot['files']:
 p=W/row['path'];check(p.is_file() and not p.is_symlink(),'regular prior owner '+row['path'])
 check(sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'unchanged prior owner '+row['path'])
 check(before[row['path']]==after[row['path']],'same old/new staged object '+row['path'])
 check(index[row['path']]['blob']==after[row['path']]['blob'] and index[row['path']]['stage']=='0','current index exact prior owner '+row['path'])
 bindings.append(row)
check(index[attr]['blob']==after[attr]['blob'] and index[attr]['stage']=='0','current index exact new attributes')
xmls=sorted(str(p.relative_to(W)) for folder in ['originals','all-reference-originals'] for p in (W/owner/folder).glob('*.xml'))
check(len(xmls)==223,'92 authoritative plus131 reference originals')
blob_request=''.join(index[p]['blob']+'\n' for p in xmls).encode();stream=git('cat-file','--batch',input=blob_request);offset=0
source_rows=[];trailing=[]
for path in xmls:
 end=stream.index(b'\n',offset);head=stream[offset:end].split();size=int(head[2]);raw=stream[end+1:end+1+size];offset=end+size+2
 check(head[0].decode()==index[path]['blob'],'exact index blob response '+path)
 check(raw==(W/path).read_bytes()==(A/path).read_bytes(),'index working accepted source bytes equal '+path)
 source_rows.append({'path':path,'bytes':size,'sha256':hashlib.sha256(raw).hexdigest(),'index_blob':index[path]['blob']})
 for line_number,line in enumerate(raw.splitlines(),1):
  if line.endswith((b' ',b'\t')):trailing.append({'path':path,'line':line_number})
check(offset==len(stream),'all index bytes consumed')
initial=(R/'inputs/initial-staged-diff-check.stdout').read_text()
reported=[{'path':p,'line':int(n)} for p,n in re.findall(r'^(.+):(\d+): trailing whitespace\.$',initial,re.M)]
check(reported==trailing,'137 exact native trailing-whitespace locations independently replayed')
check(len(trailing)==137 and len({r['path'] for r in trailing})==72,'137 diagnostics over72 files')
check(read(R/'inputs/initial-staged-diff-check.json')['exit_code']==2,'initial failure retained as failure')
root_after=read(R/'inputs/source-preserving-staged-diff-check.json')
actual_negative=sorted({r['path'] for r in root_after['attributes'] if r['value']=='unspecified'})
check(len(actual_negative)==6,'six retained actual negative controls')
synthetic=[owner+'/originals/nested/probe.xml',owner+'/all-reference-originals/nested/probe.xml',owner+'/originals/probe.xml.gz',owner+'/all-reference-originals/probe.xml.json',owner+'/originals/probe.XML',owner+'/all-reference-originals/probe.json',owner+'/other/probe.xml',owner+'/probe.xml','research/pathway_additions/2026-10-15-next-270/originals/probe.xml','tests/fixtures/methanogenesis_authority/probe.xml','src/pathwaymech/probe.xml','docs/probe.xml']
all_paths=xmls+actual_negative+synthetic
def attributes(args,paths):
 raw=git('check-attr',*args,'-z','text','whitespace','--stdin',input=b'\0'.join(p.encode() for p in paths)+b'\0')
 parts=raw.split(b'\0');check(parts[-1]==b'' and (len(parts)-1)%3==0,'well-formed attribute response')
 return [{'path':parts[i].decode(),'attribute':parts[i+1].decode(),'value':parts[i+2].decode()} for i in range(0,len(parts)-1,3)]
current=attributes(['--cached'],all_paths);pinned=attributes(['--source='+after_tree],all_paths)
check(current==pinned,'current cached attributes equal applied tree attributes')
for row in current:
 expected={'text':'unset','whitespace':'-blank-at-eol'}[row['attribute']] if row['path'] in xmls else 'unspecified'
 check(row['value']==expected,'exact attribute boundary '+row['path']+' '+row['attribute'])
prior=attributes(['--source='+before_tree],all_paths)
check(all(r['value']=='unspecified' for r in prior),'all probe attributes unspecified in pre-fix tree')
stdout=git('diff','--cached','--check');(R/'results/independent-staged-diff-check.stdout').write_bytes(stdout)
check(stdout==b'','current full staged whitespace check clean')
check(read(R/'inputs/source-preserving-staged-diff-check.json')['exit_code']==0,'author applied result retained')
save('results/commands.json',commands)
save('results/owner-before.json',bindings+[{'path':attr,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}])
save('results/attribute-probes.json',{'current_cached':current,'applied_tree':pinned,'before_tree':prior,'actual_positive_files':223,'actual_negative_files':6,'synthetic_boundary_negatives':12})
save('results/unchanged-source-index.json',source_rows)
save('results/review-result.json',{'status':'accepted_bounded_source_preserving_attribute_fix','issue':628,'finding_key':'N270-R02','checks':len(checks),'check_labels':checks,'before_tree':before_tree,'applied_tree':after_tree,'tree_delta':'Only the exact owner-local .gitattributes added; every prior staged tree entry identical.','prior_proposed_owners_exact':703,'xml_working_index_accepted_bytes_exact':223,'original_diagnostics':137,'original_affected_files':72,'initial_failure_exit_code':2,'independent_applied_staged_check_exit_code':0,'attribute_controls':{'positive_actual':223,'negative_actual':6,'negative_hypothetical':12},'scientific_data_code_changes':False,'all_jobs_terminal':True,'scope':'No source normalization, no scientific re-review, no full tests and no maintained/Git/GH/runtime mutation.'})
print(json.dumps({'checks':len(checks),'status':'passed','prior_owners':703,'xmls':223,'negative_controls':18,'staged_check_exit':0}))
