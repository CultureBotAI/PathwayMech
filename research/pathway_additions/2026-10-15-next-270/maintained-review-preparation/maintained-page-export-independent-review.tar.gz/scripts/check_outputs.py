"""Final generated-output fidelity, with fixed prior-record/page invariants."""
import copy,csv,hashlib,io,json,re,shutil,subprocess
from pathlib import Path
from lxml import html as lh,etree
import yaml
from pathwaymech.cli import render_site
from pathwaymech.schema import validate_record
from pathwaymech.site_display import load_site_history
R=Path(__file__).resolve().parents[1]
W=Path('/private/tmp/pathwaymech-next-270-20261015')
A=Path('/private/tmp/pathwaymech-next-270-record-preparation')
BASE='e8ae5e445d3288717c31d3012611e226fd5cca34'
ID='MetaCyc:METHANOGENESIS-PWY'
record_path='data/pathways/methanogenesis-from-h2-and-co2.yaml'
page_path='pages/records/MetaCyc_METHANOGENESIS-PWY.html'
checks=[];bindings={}
def check(ok,label):checks.append(label);assert ok,label
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bind(rel):
 p=W/rel;bindings[rel]={'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)}
def save(name,obj):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p
 p.write_text(json.dumps(obj,indent=2)+'\n')
def tsv(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def visible(el):
 return not any(n.tag in {'script','style','template','title'} or 'hidden' in n.attrib or n.get('aria-hidden')=='true' or 'display:none' in n.get('style','').replace(' ','') or 'visibility:hidden' in n.get('style','').replace(' ','') for n in [el,*el.iterancestors()])
check(sha(W/record_path)=='553922ede0ecdb12ebe569dbb9d8af1c70d4aa190e4fd60e69a9bc7ea0cf8e1e','exact accepted maintained record')
raw=yaml.safe_load((W/record_path).read_text());bind(record_path)
record=validate_record(raw)
preview=A/'preview/records/MetaCyc_METHANOGENESIS-PWY.html';actual=W/page_path
check(sha(preview)=='f5b5e83b48f28a16ac115582309c80e792409962b2c027a9e7ae19b74d31009d','accepted frozen preview')
pt=lh.fromstring(preview.read_text());at=lh.fromstring(actual.read_text());bind(page_path)
page_text=actual.read_text()
source_xpath='//main/p[a[normalize-space(.)="Read the source YAML"]]'
history_xpath='//main/section[h2[normalize-space(.)="Curation history"]]'
source_nodes=at.xpath(source_xpath);preview_sources=pt.xpath(source_xpath)
check(len(source_nodes)==1 and not preview_sources,'single maintained source-YAML provenance addition')
check(source_nodes[0].xpath('./a/@href')==['https://github.com/CultureBotAI/PathwayMech/blob/main/'+record_path],'exact maintained YAML source link')
ah=at.xpath(history_xpath);ph=pt.xpath(history_xpath)
check(len(ah)==len(ph)==1,'one current and preview curation history section')
save('results/preview-differences.json',{'preview_sha256':sha(preview),'actual_sha256':sha(actual),'actual_source_provenance_html':etree.tostring(source_nodes[0],encoding='unicode'),'preview_history_html':etree.tostring(ph[0],encoding='unicode'),'actual_history_html':etree.tostring(ah[0],encoding='unicode'),'allowed_difference':'Only maintained YAML provenance link and actual append-only curation history; scientific/graph content checked identical after these removals.'})
for tree in [pt,at]:
 for n in tree.xpath(source_xpath+' | '+history_xpath):n.getparent().remove(n)
check(etree.tostring(pt)==etree.tostring(at),'exact preview DOM after solely provenance/history removal')
# A fresh in-memory rendering verifies exact final history and source paths as
# well as the six changed indexes/downloads; no maintained output is written.
paths=sorted((W/'data/pathways').rglob('*.yaml'))
records=[];source_paths={}
for path in paths:
 value=yaml.safe_load(path.read_text());records.append(validate_record(value));source_paths[value['id']]=str(path.relative_to(W))
check(len(records)==267,'267 current records for render consistency')
expected=render_site(records,source_paths,load_site_history(W))
for rel,text in expected.items():
 check((W/'pages'/rel).read_bytes()==text.encode(),'actual renderer output '+rel)
 bind('pages/'+rel)
check(expected['records/MetaCyc_METHANOGENESIS-PWY.html'].encode()==actual.read_bytes(),'exact actual page with current history')
at=lh.fromstring(page_text)
check(len(at.xpath('//*[@data-node-id]'))==101,'101 biochemical SVG nodes')
graph_edges=at.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," graph-edge ")]')
check(len(graph_edges)==125,'125 SVG edges')
nodes=tsv(W/'pages/downloads/nodes.tsv');edges=tsv(W/'pages/downloads/edges.tsv')
preview_nodes=tsv(A/'preview/downloads/nodes.tsv');preview_edges=tsv(A/'preview/downloads/edges.tsv')
node_by_id={n['id']:n for n in nodes};edge_by_id={e['id']:e for e in edges}
check(len(node_by_id)==len(nodes) and len(edge_by_id)==len(edges),'unique global KGX IDs')
current_context_nodes={n['id'] for n in nodes if any(c.get('record_id')==ID for c in json.loads(n['source_contexts']))}
check(current_context_nodes=={n['id'] for n in preview_nodes} and len(current_context_nodes)==104,'104 exact current KGX context nodes')
for n in preview_nodes:
 check(n['id'] in node_by_id,'current KGX node '+n['id'])
 context=[c for c in json.loads(node_by_id[n['id']]['source_contexts']) if c.get('record_id')==ID]
 check(context==json.loads(n['source_contexts']),'complete record-local KGX node context '+n['id'])
check(len(preview_edges)==len(raw['mechanistic_edges'])==125,'125 edge payloads')
for number,(source,exported) in enumerate(zip(raw['mechanistic_edges'],preview_edges),1):
 check(edge_by_id.get(exported['id'])==exported,'full final KGX row '+source['id'])
 check(json.loads(exported['evidence'])==source['evidence'],'full KGX evidence '+source['id'])
 check(exported['description']==source['description'],'full KGX description '+source['id'])
 row=at.xpath('//*[@id="mechanism-edge-'+str(number)+'"]');check(len(row)==1,'single ordinary edge row '+source['id'])
 check(visible(row[0]) and source['description'] in row[0].text_content(),'visible complete description '+source['id'])
 for evidence in source['evidence']:
  text=evidence.get('source_assertion',evidence.get('quote',''))
  check(bool(text) and text in row[0].text_content(),'visible complete assertion '+source['id'])
  if evidence.get('source_locator'):check(evidence['source_locator'] in row[0].text_content(),'visible exact source locator '+source['id'])
claims=read(A/'claim-placement-ledger.json');by_edge={e['id']:e for e in raw['mechanistic_edges']}
check(len(claims)==20,'20 accepted scope placements')
main_paragraphs=at.xpath('//main/p');graph=at.xpath('//*[@id="pathway-network"]')[0];main=list(graph.getparent());graph_position=main.index(graph)
for claim in claims:
 matching=[p for p in main_paragraphs if p.text_content()==claim['root_paragraph']]
 check(len(matching)==1 and visible(matching[0]) and main.index(matching[0])<graph_position,'complete visible pregraph scope '+claim['claim_id'])
 for eid in claim['edge_ids']:
  check(claim['incident_addition'] in by_edge[eid]['description'],'complete incident scope '+claim['claim_id']+' '+eid)
for taxon in raw['taxa']:
 check(taxon['id'] in current_context_nodes,'KGX taxon '+taxon['id'])
 check(any(taxon['id'] in el.text_content() and taxon['label'] in el.text_content() and visible(el) for el in at.xpath('//main/dl')),'ordinary taxon metadata '+taxon['id'])
 check(not at.xpath('//*[@data-node-id="'+taxon['id']+'"]'),'unconnected taxon not fabricated into SVG '+taxon['id'])
check(len(raw['references'])==148,'148 accepted references')
hrefs=set(at.xpath('//a/@href'))
for ref in raw['references']:
 if ref.get('url'):check(ref['url'] in hrefs,'actual reference URL '+ref['id'])
# Exact old-owner hashes are from the preceding frozen integrated check, which
# compared each prior record/page directly to actual merged Git blobs.
old_bindings=read(R/'inputs/prior-integrated-owner-bindings.json')
old_pages={r['path']:r for r in old_bindings if r['path'].startswith('pages/')}
old_records={r['path']:r for r in old_bindings if r['path'].startswith('data/pathways/') and r['path'].endswith('.yaml')}
allowed={'pages/index.html','pages/browse.html','pages/pathway_index.json','pages/downloads/nodes.tsv','pages/downloads/edges.tsv','pages/downloads/manifest.json'}
changed=[]
for rel,row in old_pages.items():
 p=W/rel;check(p.is_file(),'prior page still present '+rel)
 if sha(p)!=row['sha256']:
  check(rel in allowed,'only justified index/export changes '+rel);changed.append(rel)
 else:check(p.stat().st_size==row['bytes'],'unchanged prior page size '+rel)
 bind(rel)
check(set(changed)==allowed,'exact six index/export changes')
for rel,row in old_records.items():
 p=W/rel;check(sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'prior record exact '+rel);bind(rel)
check(len(old_records)==266 and sum(r.startswith('pages/records/') for r in old_pages)==266,'266 old record/page invariants')
actual_pages={str(p.relative_to(W)) for p in (W/'pages').rglob('*') if p.is_file()}
check(actual_pages==set(old_pages)|{page_path},'complete hidden ignored page inventory; one addition')
check({str(p.relative_to(W)) for p in paths}==set(old_records)|{record_path},'complete record YAML inventory; one addition')
index=read(W/'pages/pathway_index.json');check(len(index['records'])==267,'267 pathway-index rows')
current=[r for r in index['records'] if r['id']==ID];check(len(current)==1 and current[0]['taxa']==raw['taxa'],'new index exact taxa')
manifest=read(W/'pages/downloads/manifest.json');check(manifest['pathway_records']==267,'267 download record count')
for name,row in manifest['files'].items():
 p=W/'pages/downloads'/name;check(sha(p)==row['sha256'],'download manifest digest '+name)
 check(len(p.read_text().splitlines())-1==row['rows'],'download manifest row count '+name)
# Review README scope/counts and local reference targets without widening source
# science or recursively re-reviewing retained archives.
readme_path='research/pathway_additions/2026-10-15-next-270/README.md';readme=(W/readme_path).read_text();bind(readme_path)
groups=[]
for group in ['accepted-preparation','integration-preparation','record-preparation']:
 inventory_path=Path(readme_path).parent/group/'inventory.json';inventory=read(W/inventory_path);bind(str(inventory_path))
 for packet in inventory['packets']:
  archive=inventory_path.parent/packet['archive'];p=W/archive;check(p.stat().st_size==packet['archive_bytes'] and sha(p)==packet['archive_sha256'],'README retained archive '+str(archive));bind(str(archive))
 groups.append({'group':group,'archives':len(inventory['packets']),'members':sum(len(p['files']) for p in inventory['packets']),'compressed_bytes':sum(p['archive_bytes'] for p in inventory['packets'])})
check(sum(g['archives'] for g in groups)==16 and sum(g['members'] for g in groups)==6883 and sum(g['compressed_bytes'] for g in groups)==174502467,'README exact 16/6883/174502467 totals')
for target in re.findall(r'\]\(([^)]+)\)',readme):
 if target.startswith(('https://','http://')):continue
 check(((W/readme_path).parent/target).resolve().is_file(),'README local link '+target)
for clause in ['six native reactions ending at methyl-CoM','104-node KGX','Full maintained rendering, corpus gates, canonical scientific review, PR review and merge verification are separate later events','closure requires verified merge','No global absence or source exhaustion is claimed','not a purified Mtr sodium-transport assay']:
 check(clause in readme,'README bounded scope '+clause)
shutil.copy2(actual,R/'results/actual-record-page.html');shutil.copy2(W/readme_path,R/'inputs/research-README.md')
save('results/owner-before.json',list(bindings.values()))
save('results/output-checks.json',{'status':'passed','checks':len(checks),'check_labels':checks,'record_sha256':sha(W/record_path),'actual_page_sha256':sha(actual),'preview_sha256':sha(preview),'kgx_record_nodes':104,'svg_nodes':101,'edges':125,'scope_claims':20,'taxa':3,'references':148,'prior_records_exact':266,'prior_record_pages_exact':266,'changed_indexes':sorted(changed),'new_page':page_path,'retention_groups':groups,'no_browser_or_pixel_level_QA_claimed':True,'all_jobs_terminal':True})
print(json.dumps({'checks':len(checks),'kgx_nodes':104,'svg_nodes':101,'edges':125,'prior_records_and_pages':266,'changed_indexes':sorted(changed),'status':'passed'}))
