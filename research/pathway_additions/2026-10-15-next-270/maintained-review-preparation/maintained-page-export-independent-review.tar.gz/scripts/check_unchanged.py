"""Rebind final reviewed outputs and accepted input packets after output checks."""
import csv,hashlib,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=Path('/private/tmp/pathwaymech-next-270-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(n,x):
 p=R/n;assert not p.exists(),p;p.write_text(json.dumps(x,indent=2)+'\n')
rows=read(R/'results/owner-before.json');assert len(rows)==len({r['path'] for r in rows})
for row in rows:
 p=W/row['path'];assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
sys.path.insert(0,'/private/tmp/pathwaymech-next-270-native-authority-independent-review/scripts')
from intake import check
before=read(R/'results/frozen-inputs-before.json')
after=[check(r['owner'],r['manifest_sha256'],r['physical']) for r in before]
assert after==before
prior=check('/private/tmp/pathwaymech-next-270-integrated-authority-independent-review','d8ceedb45dfec8e0e76ee05965da198d858b68b7ecded08f7fd7c677704780fc',24)
assert (Path(prior['owner'])/'results/owner-before.json').read_bytes()==(R/'inputs/prior-integrated-owner-bindings.json').read_bytes()
save('results/frozen-inputs-after.json',after)
save('results/prior-invariant-review-final-intake.json',prior)
with (W/'pages/downloads/nodes.tsv').open() as f:nodes=list(csv.DictReader(f,delimiter='\t'))
nodes=[n for n in nodes if any(c.get('record_id')=='MetaCyc:METHANOGENESIS-PWY' for c in json.loads(n['source_contexts']))]
preview=Path('/private/tmp/pathwaymech-next-270-record-preparation/preview/downloads/edges.tsv')
with preview.open() as f:ids={e['id'] for e in csv.DictReader(f,delimiter='\t')}
with (W/'pages/downloads/edges.tsv').open() as f:edges=[e for e in csv.DictReader(f,delimiter='\t') if e['id'] in ids]
assert len(nodes)==104 and len(edges)==125
save('results/actual-selected-104-nodes.json',nodes);save('results/actual-selected-125-edges.json',edges)
save('results/final-unchanged.json',{'all_exact':True,'fixed_maintained_output_inputs':len(rows),'record_and_peer_frozen_files_before_after':272,'prior_frozen_invariant_review_files_rechecked':24,'record_sha256':sha(W/'data/pathways/methanogenesis-from-h2-and-co2.yaml'),'page_sha256':sha(W/'pages/records/MetaCyc_METHANOGENESIS-PWY.html'),'readme_sha256':sha(W/'research/pathway_additions/2026-10-15-next-270/README.md'),'all_jobs_terminal':True,'scope':'Fixed output/record/README/archive snapshot; later canonical reviews, gate receipts and unrelated histories are excluded.'})
print(json.dumps({'all_exact':True,'fixed_owner_count':len(rows),'frozen_record_peer_files':272,'prior_review_files':24,'all_jobs_terminal':True}))
