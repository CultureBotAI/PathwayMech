# Output replay in a new scratch owner

Do not execute scripts inside this frozen owner. Copy `scripts/` and `inputs/` to a new empty scratch directory and create its `results/`. Copy `results/frozen-inputs-before.json` into that new results directory. Run with the existing verified interpreter, `-B`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONNOUSERSITE=1`, and `PYTHONPATH=/private/tmp/pathwaymech-next-270-20261015/src:/private/tmp/pathwaymech-next-270-20261015`.

Run `scripts/check_outputs.py`, then `scripts/check_unchanged.py`. The scripts explicitly reference the accepted frozen composition/review and actual maintained worktree. They write only their new scratch owner, render in memory, and do not run the full test or scientific-review suites. Later changes to the fixed reviewed paths require a successor binding. Existing output files are not silently overwritten.
