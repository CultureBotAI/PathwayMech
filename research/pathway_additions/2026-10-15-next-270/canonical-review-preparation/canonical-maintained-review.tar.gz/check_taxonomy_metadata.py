from pathlib import Path
import json, sqlite3, datetime
R=Path('/private/tmp/pathwaymech-next-270-20261015/research/pathway_additions/2026-10-15-next-270/authority-source-originals/taxonomy')
O=Path(__file__).parent
receipt=json.loads((R/'taxonomy-query-receipt.json').read_text());expected=json.loads((R/'three-direct-taxon-selected-statements.json').read_text());c=Path(receipt['cache']);before=c.stat()
assert before.st_size==receipt['size'] and before.st_mtime_ns==receipt['mtime_ns_after']
db=sqlite3.connect(c.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
rows={}
for tax,prior in expected.items():
 actual=[dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(tax,))]
 assert actual==prior,tax
 rows[tax]=actual
db.close();after=c.stat();assert after.st_size==before.st_size and after.st_mtime_ns==before.st_mtime_ns
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','scope':'Three exact current selected term-statement sets and before/after file size/mtime; reused accepted pinned full-cache SHA256; no new full-cache hash','mode':'ro&immutable=1','bytes':before.st_size,'mtime_ns':before.st_mtime_ns,'reused_sha256':receipt['prior_full_hash_evidence']['sha256'],'row_counts':{k:len(v) for k,v in rows.items()},'rows':rows}
(O/'current-selected-taxonomy-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
