# Independent maintained page and KGX review

**Accepted within the bounded output-review scope; no actionable finding.** The maintained record, actual page, aggregate exports and indexes faithfully retain the separately accepted composition. All 266 earlier YAML records and record pages are unchanged. This does not accept canonical scientific review, full maintained tests, PR review or merge.

The reviewed record is `data/pathways/methanogenesis-from-h2-and-co2.yaml`, SHA256 `553922ede0ecdb12ebe569dbb9d8af1c70d4aa190e4fd60e69a9bc7ea0cf8e1e`, in `/private/tmp/pathwaymech-next-270-20261015`. Actual output inspection began only after root declared rendering and the research README ready. The root-authored frozen composition and its separate peer acceptance were freshly read and verified: manifests `92357ea4f18409725bc8864f1ccd09648b1b6cd1cdfca1eeb15e371d7f90d64c` and `04198da4b79437a0fbbc29f3b5ed72768d8008e2942bb1feb1b484d89bb6f4e5`, 272 physical files exact before/after.

## Exact preview difference

The actual page SHA256 is `9e78b48afb06c2d2a5bbfb50e745eda6995b1857ce6c93d5d159a7bb9b02e30d`; the accepted preview SHA256 is `f5b5e83b48f28a16ac115582309c80e792409962b2c027a9e7ae19b74d31009d`. These are correctly different. The actual page adds the exact maintained source-YAML link and replaces the preview's empty-history notice with the recorded CREATE history. Removing only those provenance/history nodes makes the complete remaining DOM identical. Both historical sections and the exact added link are retained in `results/preview-differences.json`.

A fresh in-memory render using the actual maintained source paths and histories reproduces every renderer-owned file exactly, including the complete new page. It writes no maintained output. This accounts for the final page's actual source/history context rather than assuming byte equality with the context-free scratch preview.

## Visible claims and complete export

All 125 complete edge descriptions remain ordinary visible page-table text, outside script/style/template/title/hidden content. Every source assertion or quote and each exact source locator is present in its edge row. All 125 aggregate KGX edge rows exactly match the accepted record-local export, including full descriptions, evidence, reference metadata and endpoint qualifications. Selected actual rows are retained under `results/actual-selected-125-edges.json`.

All twenty accepted root paragraphs are present as ordinary text before the graph, and every required incident addition survives in the specified edge descriptions and exports. This includes generic carrier/stoichiometry limits, exact material-occurrence compartments, Mch direction and Mtr cofactor conflicts, source-only catalyst/strain qualifications and the corrected issue626 locator. This is preservation of the peer-accepted scope, not a new independent biochemical interpretation.

KGX retains exactly 104 record-local node contexts, including all three direct taxa. The SVG correctly contains 101 biochemical nodes and 125 links; the three unconnected taxa remain in ordinary organism metadata and KGX rather than receiving invented graph edges. All 148 accepted references remain, with every supplied reference URL present. Full record-local node contexts are preserved even where the global KGX export merges shared nodes.

These are exact payload and structural no-JS checks. No interactive-browser or pixel-level readability QA is claimed, and unchanged renderer implementation is not independently re-reviewed. The reviewer previously contributed renderer code, authored source/issuer preparations and performed the accepted authority/design reviews; separate peer source/issuer/composition acceptances supply their scientific scope. The reviewer did not author this complete record composition or final maintained rendering.

## Previous pages, indexes and research scope

All 266 previous records and their 266 record pages match the prior frozen invariant receipt, which compared them directly to actual merged Git blobs at `e8ae5e445d3288717c31d3012611e226fd5cca34`. That 24-file invariant review was freshly rechecked. The full hidden/ignored page inventory contains exactly the previous 276 files plus the one new record page.

Only six old page files changed: `index.html`, `browse.html`, `pathway_index.json`, and the downloaded `nodes.tsv`, `edges.tsv` and `manifest.json`. Each matches fresh in-memory output for the 267 maintained records. Download hashes/row counts and the new pathway-index taxon entries agree exactly. Existing style/graph assets and all other prior pages remain unchanged. No unrelated record or page deletion is hidden by ignored-file filtering.

The final proposed research README was read in full. Its six-member methyl-CoM boundary, Hmd distinction, generic/taxon/strain/mapping limits, Kurth assay qualifications, issue626 disposition and finite novelty scope agree with the accepted inputs. All local links resolve. The three group inventories and actual archive hashes substantiate exactly 16 archives, 6,883 outer file occurrences and 174,502,467 compressed bytes. This count check does not repeat scientific interpretation or recursive nested-container inspection. The integration-status paragraph is explicitly a preparation cutoff; it does not claim later full gates, canonical review or merge succeeded.

## Verification and remaining work

The output script passed **2,742 checks** and the final scoped rehash passed. Both executed reviewer scripts completed on their first runs. One exploratory search initially named a nonexistent `history.py`; the actual owner `site_display.py` was identified from the imports. It caused no product change, absence conclusion or failed verification. The existing runtime lacks the optional CairoSVG/Pillow modules; none was installed, and no raster/browser QA claim is made.

All jobs are terminal. No maintained, Git/GitHub, network, installed-runtime or frozen-input writes occurred. The review does not require a global tree lock: later canonical reviews and gate receipts are outside its fixed output snapshot. Root's later whitespace-policy finding N270-R02 concerns a separate prospective Git attribute change; it does not alter these reviewed scientific/product outputs and is not accepted by this packet.

Canonical scientific review, full maintained gates, issue626 and any subsequently filed implementation issue dispositions, PR review, verified merge and cleanup remain separate. This review creates or closes no issue.
