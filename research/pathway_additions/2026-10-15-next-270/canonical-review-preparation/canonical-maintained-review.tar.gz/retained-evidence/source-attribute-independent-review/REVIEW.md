# Independent acceptance of N270-R02 / issue 628

Accepted within the bounded integration scope, with no additional actionable finding. This correction adds one owner-local `.gitattributes` and preserves native source bytes. Issue 628 must remain open until the root verifies the later merged disposition.

## Exact correction and unchanged owners

The reviewed file is `research/pathway_additions/2026-10-15-next-270/authority-source-originals/.gitattributes`, SHA-256 `7f12bedf58cfc88064420816fc4bd0a5c23f50b089c7afc312dbe0e8ba238d9f`. Its two anchored rules apply `-text whitespace=-blank-at-eol` to immediate XML files in `originals/` and `all-reference-originals/`. The comment explains preservation of original end-of-line spaces. No source normalization or broader code/document waiver is introduced.

The exact tree delta from `547a82389109bb355a5a7e9a2fc83f8402f8aed6` to `2e3307207f1423634c18f7e0ee6c6903e56f7fe1` consists only of this added file. Every earlier staged tree entry is equal. All 703 prior proposed working owners and their index objects match the retained root snapshot. All 223 immediate raw XML files match their current Git index blobs, working bytes, and the separately accepted frozen authority candidate byte for byte. The final recheck verified all 704 scoped owners, all 12 copied author inputs, and all 223 source/index bindings unchanged.

## Failure and correction evidence

The initial root `git diff --cached --check` exit 2 is preserved with its original stdout/stderr and receipt. Independently scanning the unchanged XML bytes reproduces exactly 137 trailing-whitespace locations across 72 files, matching the original diagnostics in order. These lines remain present in the source. The root applied-check exit 0 and a fresh independent staged-check exit 0 are retained separately. The metadata change addresses staging behavior without changing scientific data or code.

The independent audit completed 3,776 assertions. Actual cached attributes equal attributes from the pinned applied tree. All 223 actual XML paths receive the intended two attributes. Six actual code, YAML, and documentation paths plus 11 hypothetical nested, sibling, other-directory, or non-XML paths remain unspecified. All tested paths were unspecified in the pre-fix tree.

## Case behavior and preserved reviewer failure

The first reviewer harness incorrectly treated a hypothetical uppercase `.XML` as a mandatory negative control. It failed at that assumption; `attempts/review_attributes-uppercase-negative.py`, `attempts/review-uppercase-negative.log`, and the original `results/review.log` preserve the failure. This checkout has `core.ignorecase=true`. Fresh controls confirm that both an uppercase `.XML` extension and uppercase `ORIGINALS` directory alias match the same rule, while nested directories remain outside it. A transient `git -c core.ignorecase=false check-attr` returns unspecified for both aliases; no persistent Git configuration was changed.

The parent explicitly confirmed that case-folded raw-XML matching is within intended scope. The corrected harness accounts for these two case aliases as informational positive controls. No actual directory or non-XML escape was found in the tested scope, and no product bytes changed in response to this reviewer failure.

## Independence and limits

The reviewer previously authored source/issuer preparation and renderer work. Their separate peer acceptances remain the scientific basis; this task independently evaluates the root-authored attribute correction. It does not re-review chemistry, primary papers, record composition, the full test suite, publication, or merge state. The initial/applied trees and 704 explicit owners define the scope; later unrelated root retention or gate outputs are not required to be quiescent. Inventories include hidden and ignored files, including the new hidden attribute file.

All tools used for product inspection were read-only; files were created only in this scratch review owner. No maintained, Git, GitHub, network, or runtime mutation, install, repair, or source normalization was performed. All jobs are terminal. The final unchanged-input check passed. Preserve this packet and the original failed root and reviewer attempts; do not reinterpret them as successful original runs.
