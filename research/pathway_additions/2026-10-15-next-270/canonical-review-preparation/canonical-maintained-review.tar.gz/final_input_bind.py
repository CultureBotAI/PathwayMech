from pathlib import Path
import json,hashlib,gzip,subprocess,os,datetime
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-270-20261015');F=R/'research/pathway_additions/2026-10-15-next-270/final-verification';h=lambda b:hashlib.sha256(b).hexdigest()
g=json.loads((F/'gates.json').read_text());checks=[]
def check(c,s):
 checks.append({'scope':s,'passed':bool(c)})
 if not c:raise AssertionError(s)
initial=json.loads((O/'initial-inspect.json').read_text())
for x in initial['source']['inputs']:check(h((R/x['path']).read_bytes())==x['sha256'],'initial scientific/governance input unchanged '+x['path'])
check(len(g['checks'])==7 and all(x['required'] and x['exit_code']==0 for x in g['checks']),'seven required actual terminal commands pass')
check(g['baseline_commit']==initial['source']['git_revision'],'same actual landed base')
check(g['test_summary']=='7149 passed, 3 skipped, 7 warnings in 1093.26s (0:18:13)','exact full test summary')
for x in g['integrated_owners']+g['supporting_receipts']:
 b=(R/x['path']).read_bytes();check(len(b)==x['bytes'] and h(b)==x['sha256'],'retained owner '+x['path'])
logs=[]
for c in g['checks']+g['resolved_attempts']:
 for role,x in c['logs'].items():
  b=(R/x['path']).read_bytes();raw=gzip.decompress(b);check(len(b)==x['bytes'] and h(b)==x['sha256'],'compressed log '+x['path']);check(len(raw)==x['decoded_bytes'] and h(raw)==x['decoded_sha256'],'decoded log '+x['path'])
  original=Path('/private/tmp/pathwaymech-next-270-ci')/Path(x['path']).name.removesuffix('.gz');check(raw==original.read_bytes(),'exact original log '+str(original))
  dest=O/'decoded-final-logs'/original.name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(raw);logs.append(x)
check('7149 passed, 3 skipped, 7 warnings in 1093.26s' in (O/'decoded-final-logs/full-test.stdout').read_text(),'test summary exists in authentic full log')
check(g['resolved_attempts'][0]['exit_code']==2 and g['resolved_attempts'][0]['finding_key']=='N270-R02','original staged failure retained honestly')
check(h((R/'research/pathway_additions/2026-10-15-next-270/authority-source-originals/.gitattributes').read_bytes())=='7f12bedf58cfc88064420816fc4bd0a5c23f50b089c7afc312dbe0e8ba238d9f','exact accepted attribute successor')
paths={x['path'] for x in g['integrated_owners']}|{x['path'] for x in initial['source']['inputs']}
paths|={p.relative_to(R).as_posix() for p in F.rglob('*') if p.is_file()}
M=R/'research/pathway_additions/2026-10-15-next-270/maintained-review-preparation';paths|={p.relative_to(R).as_posix() for p in M.rglob('*') if p.is_file()}
paths|={'src/pathwaymech/cli.py','pyproject.toml','src/pathwaymech/assets/pathway-network.css','src/pathwaymech/assets/pathway-network.js','conf/identifier_policy.yaml','src/pathwaymech/graph_view.py','src/pathwaymech/export.py','src/pathwaymech/site_display.py'}
# Export owner name is resolved from actual package filenames, never guessed into a source assertion.
if not (R/'src/pathwaymech/export.py').exists():
 paths.remove('src/pathwaymech/export.py');paths.add('src/pathwaymech/kgx.py')
indirect=sorted(p for p in paths if any(c in p for c in ':?#%'))
check(indirect==['research/pathway_additions/2026-10-15-next-270/authority-source-originals/acquisition/native-preparation/direct-NA%2B.json'],'one exact receipt path is indirect under governed source-input grammar')
paths-=set(indirect)
for p in paths:check((R/p).is_file(),'regular final inspection input '+p)
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(O/'targets.json')]
for p in sorted(paths):cmd+=['--input',p]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();q=subprocess.run(cmd,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'},capture_output=True)
(O/'final-inspect.stdout').write_bytes(q.stdout);(O/'final-inspect.stderr').write_bytes(q.stderr);check(q.returncode==0,'governed final inspect')
result=json.loads(q.stdout);check(result['source']['git_revision']==initial['source']['git_revision'],'governed final base exact')
lookup={x['path']:x['sha256'] for x in result['source']['inputs']}
for x in initial['source']['inputs']:check(lookup[x['path']]==x['sha256'],'no silent refresh '+x['path'])
previous=json.loads((O/'final-inspect.json.before-owner-context').read_text())
for x in previous['source']['inputs']:check(lookup[x['path']]==x['sha256'],'previous final input unchanged after additive renderer-owner context '+x['path'])
(O/'final-inspect.json').write_bytes(q.stdout)
(O/'final-bind-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(O/'final-gate-binding.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','checks':len(checks),'initial_inputs_preserved':len(initial['source']['inputs']),'integrated_owners':len(g['integrated_owners']),'supporting_receipts':len(g['supporting_receipts']),'exact_logs':len(logs),'inspection_inputs':len(paths),'indirect_inputs':[{'path':p,'sha256':h((R/p).read_bytes()),'binding':'gates.json integrated_owners plus accepted native-authority implementation archive; literal percent forbidden by governed input path grammar'} for p in indirect],'test_summary':g['test_summary'],'gate_scope':g['scope'],'prelaunch_attestation_claimed':False,'inspect_command':cmd,'inspect_started':started,'inspect_exit_code':q.returncode},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'inspection_inputs':len(paths),'logs':len(logs),'status':'passed'}))
