from pathlib import Path
import json,hashlib,tarfile,datetime,shutil
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-270-20261015/research/pathway_additions/2026-10-15-next-270/maintained-review-preparation')
h=lambda b:hashlib.sha256(b).hexdigest();inv=json.loads((R/'inventory.json').read_text());results=[]
for p in inv['packets']:
 src=Path(p['source_path']);mf=json.loads((src/'artifact-manifest.json').read_text());f=mf['files'];actual={x.relative_to(src).as_posix() for x in src.rglob('*') if x.is_file()};listed={x['path'] for x in f}
 exclusions=mf.get('self_excluded',mf.get('self_exclusions'));assert exclusions==['artifact-manifest.json','freeze-proof.json'];assert actual-listed==set(exclusions);assert h((src/'artifact-manifest.json').read_bytes())==p['source_manifest_sha256']
 for x in f:
  b=(src/x['path']).read_bytes();assert h(b)==x['sha256'] and len(b)==x['bytes']
 ap=R/p['archive'];ab=ap.read_bytes();assert h(ab)==p['archive_sha256'] and len(ab)==p['archive_bytes']
 index={x['path']:x for x in p['files']}
 with tarfile.open(ap) as tf:
  members=tf.getmembers();assert {x.name for x in members}==set(index)==actual
  for x in members:
   b=tf.extractfile(x).read();assert len(b)==index[x.name]['bytes'] and h(b)==index[x.name]['sha256'];assert b==(src/x.name).read_bytes()
 for n in ['HANDOFF.md','REVIEW.md','RESULT.json','artifact-manifest.json','freeze-proof.json']:
  d=O/'retained-evidence'/p['name']/n;d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/n,d)
 results.append({'archive':str(ap),'sha256':h(ab),'members':len(index),'frozen_source_manifest':p['source_manifest_sha256'],'all_members_byte_equal':True})
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','scope':'Two final peer review packets; full58 outer members decoded/hash-compared, nested contents not independently expanded','packets':results}
(O/'final-peer-retention-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
