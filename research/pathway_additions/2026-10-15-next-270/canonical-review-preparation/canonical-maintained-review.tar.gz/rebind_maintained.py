from pathlib import Path
import json, hashlib, tarfile, collections, datetime, shutil
import yaml
R=Path('/private/tmp/pathwaymech-next-270-20261015');O=Path('/private/tmp/pathwaymech-next-270-canonical-maintained-review');S=R/'research/pathway_additions/2026-10-15-next-270'
checks=[]
def h(b):return hashlib.sha256(b).hexdigest()
def check(condition,scope):
 checks.append({'scope':scope,'passed':bool(condition)})
 if not condition:raise AssertionError(scope)
def write(name,data):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
initial=json.loads((O/'initial-inspect.json').read_text())
for x in initial['source']['inputs']:check(h((R/x['path']).read_bytes())==x['sha256'],'initial input unchanged '+x['path'])
raw=(R/'data/pathways/methanogenesis-from-h2-and-co2.yaml').read_bytes();rec=yaml.safe_load(raw)
check(h(raw)=='553922ede0ecdb12ebe569dbb9d8af1c70d4aa190e4fd60e69a9bc7ea0cf8e1e','exact accepted full record bytes')
check(raw==(O/'maintained-record.yaml').read_bytes(),'reviewer complete target capture remains exact')
checks.append({'scope':'Entire 3360-line maintained document parsed/read and byte-equal to prior fully read accepted composition; scientific reading reused, not a newly claimed full literature reread','passed':True})
archives=[]
selected_suffixes={'HANDOFF.md','REVIEW.md','RESULT.json','ASSESSMENT.md','PRIMARY-READING.md','READING-SCOPES.md','artifact-manifest.json','freeze-proof.json','claim-placement-ledger.json','primary-claim-ledger.corrected.json','scientific-dispositions.json','reference-bindings.json','results/verification-receipts.json','results/owner-after.json'}
for group in ['accepted-preparation','integration-preparation','record-preparation']:
 inv=json.loads((S/group/'inventory.json').read_text())
 for p in inv['packets']:
  ap=S/group/p['archive'];b=ap.read_bytes()
  check(h(b)==p['archive_sha256'] and len(b)==p['archive_bytes'],'archive digest '+str(ap.relative_to(R)))
  index={x['path']:x for x in p['files']};picked=[]
  with tarfile.open(ap,'r:gz') as tf:
   members=tf.getmembers()
   check(len(members)==len(index),'outer inventory denominator '+p['name'])
   check({x.name for x in members}==set(index),'outer archive names exact '+p['name'])
   check(all(x.isfile() and x.size==index[x.name]['bytes'] for x in members),'outer archive types/sizes exact '+p['name'])
   for name in sorted(set(index)&selected_suffixes):
    v=tf.extractfile(name).read();check(h(v)==index[name]['sha256'],'selected retained member '+p['name']+'/'+name)
    dest=O/'retained-evidence'/p['name']/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(v);picked.append(name)
  archives.append({'path':str(ap.relative_to(R)),'sha256':h(b),'outer_members':len(index),'selected_members_read':picked,'scope':'Exact compressed bytes and full outer path/type/size inventory; only listed selected member bodies newly hashed here. Complete prior outer hashing reused; nested containers opaque.'})
write('retained-archive-bindings.json',archives)
refs={x['id']:x for x in rec['references']};check(len(refs)==148,'all148 unique references')
prior=json.loads((O/'retained-evidence/independent-record-composition-review/reference-bindings.json').read_text());check(len(prior)==148,'prior all148 reference bindings retained')
native=json.loads((S/'authority-source-originals/reference-original-bindings.json').read_text());ni={x['id']:x for x in native};check(len(ni)==131,'all131 maintained native originals indexed')
rb=[]
for x in prior:
 rid=x['id'];r=refs[rid];check(r['source_sha256']==x['sha256'],'reference artifact identity '+rid)
 if rid.startswith('MetaCyc:'):
  item=ni[rid];v=(S/'authority-source-originals'/item['path']).read_bytes()
  check(h(v)==item['sha256']==x['sha256'],'maintained native body '+rid)
  check(v==Path(x['body_path']).read_bytes(),'native original bytes prior frozen source '+rid)
  receipts=[]
  for a in item['receipt_bindings']:
   if 'status' in a:receipts.append(a)
   elif rid=='MetaCyc:METHANOGENESIS-PWY':
    receipt_bytes=(S/'authority-source-originals/acquisition/exact-reference-bindings'/a['path']).read_bytes()
    check(h(receipt_bytes)==a['sha256'],'root acquisition wrapper exact');receipts.append(json.loads(receipt_bytes))
   elif rid=='MetaCyc:NA+':
    reuse=a['receipt'];check(reuse['row']['sha256']==h(v) and reuse['original_url']==r['url'],'exact sodium reuse binding; no fresh request')
   else:raise AssertionError('unrecognized reference receipt shape '+rid)
  if rid!='MetaCyc:NA+':check(any(a['status']==200 and a['url']==r['url'] and a['sha256']==h(v) for a in receipts),'successful exact native acquisition binding '+rid)
  path=str((S/'authority-source-originals'/item['path']).relative_to(R))
 else:
  path=x['body_path'];check(Path(path).is_file(),'prior source body exists '+rid)
  if not rid.startswith('NCBITaxon:'):check(h(Path(path).read_bytes())==x['sha256'],'exact primary body '+rid)
  else:check(x['sha256']=='89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d','reused pinned taxonomy digest '+rid)
 rb.append({'id':rid,'source_sha256':x['sha256'],'body':path,'scope':x.get('scope','prior accepted reference binding')})
write('maintained-reference-bindings.json',rb)
pl=json.loads((O/'retained-evidence/complete-record-composition/claim-placement-ledger.json').read_text())
edges={e['id']:e for e in rec['mechanistic_edges']};check(len(edges)==125,'all125 edge IDs unique')
for c in pl:
 check(c['root_paragraph'] in rec['description'],'complete root placement '+c['claim_id'])
 for eid in c['edge_ids']:check(c['incident_addition'] in edges[eid]['description'],'incident placement '+c['claim_id']+' '+eid)
check(len(pl)==20,'all20 corrected claims')
check('Methods PDF pages6–7 (printed3554–3555), Figure4C/caption and Results PDF pages11–12 (printed3559–3560), with supplementary FigureS2B' in rec['description'],'issue626 exact corrected retained locator')
ids={rec['id']}|{n['id'] for f in ['taxa','participants','reactions'] for n in rec[f]};check(len(ids)==104,'all104 declarations unique')
for e in edges.values():
 check(e['subject'] in ids and e['object'] in ids,'endpoint closure '+e['id'])
 check(bool(e['evidence']),'nonempty evidence '+e['id'])
 for j,x in enumerate(e['evidence']):
  check(x['reference_id'] in refs,'reference closure '+e['id']+'/'+str(j))
  check(('quote' in x)!=('source_assertion' in x),'assertion/quote distinction '+e['id']+'/'+str(j))
  if 'source_assertion' in x:check(bool(x.get('source_locator')),'native source locator '+e['id']+'/'+str(j))
write('maintained-scientific-rebind.json',{'status':'bounded_rebind_pass','actual_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'record_sha256':h(raw),'native_declarations':101,'taxa':3,'edges':125,'evidence_items':sum(len(e['evidence']) for e in edges.values()),'references':len(refs),'claim_placements':len(pl),'archives':len(archives),'reused_reading':'Complete accepted composition, independent source/issuer/graph/novelty scopes; no new full literature read or taxonomy whole-cache hash','final_gates':'pending root receipts; not a final canonical review'})
write('scientific-rebind-checks.json',checks)
print(json.dumps({'passed':len(checks),'archives':len(archives),'record_sha256':h(raw)}))
