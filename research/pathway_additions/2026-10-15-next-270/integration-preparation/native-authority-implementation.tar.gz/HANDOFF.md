# Native methanogenesis authority implementation proposal

This is a concrete, scratch-only additive implementation for independent review. All jobs are terminal. No maintained worktree, governed file, schema/graph module, source record, Git/GitHub state or installed runtime was changed. The proposed maintained owner list is exact in `results/patch-owner-inventory.json`; this handoff does not accept its own implementation or authorize release.

The baseline is actual merged commit **e8ae5e445d3288717c31d3012611e226fd5cca34**, tree **1c03509290f5c76048cb293bdd19c1f57143059c**. All 732 selected copied files were directly rebound to that commit's Git blobs. They are byte-identical to the earlier published269 commit cf4dec8377669ec70e730428ba5aeb35e6ced1ca. Earlier read-only queries found the merge object unavailable locally; those attempts were not treated as a source discrepancy, and the direct successor rebind passed after root created270. No live worktree dependency remains. Full novelty/alias/history dedup remains parent-owned and is not claimed by this finite authority check.

## Exact proposed changes

The patch has five modified existing files: `src/pathwaymech/identifiers.py`, `scripts/build_source_identifier_snapshot.py`, `conf/identifier_sources.json`, and the source/ontology snapshots. It adds `src/pathwaymech/biocyc_methanogenesis.py`, `tests/test_methanogenesis_authority.py`, deterministic complete-original fixtures, and `research/pathway_additions/2026-10-15-next-270/authority-source-originals/`. The inventory contains 669 proposed paths (5 modified, 664 added); all 727 other selected baseline files remain byte-identical. Thirteen operational test/lint-cache files are retained in scratch but explicitly excluded from the proposed patch. `DOC-FRAGMENT.md` is a separate documentation fragment, not a modified governed owner.

The new `metacyc-methanogenesis-xml` kind supports exactly **92 new native graph identities**. All **9 existing graph terms** retain their prior owners and serialized content. New scope: 57 Protein instances including twelve complexes; sixteen Compound instances; four Compound classes; six Reactions; five exact Enzymatic-Reaction instances; two cco instances; one cco class; one Pathway. All **101 native graph declarations** are accounted for. Complete original XML, native full-detail type/class/envelope, every own slot and exact acquisition provenance are replayed at producer and consumer boundaries. Profiles encode source types and slot multiplicities, not curated label strings or public alias equivalence.

Six unnamed Reactions and the unnamed CPLX-381 heteromer retain exact frame-only source-context labels. Five unnamed homomers derive their label solely from their exact single native activity, guarded by one repeated component and the correct enzyme backlink. No broad contextual-label waiver or previous profile weakening is introduced. Actual record consumption enforces typed section/category and source labels. Generic chemical/protein classes, exact activities versus reactions, native equation coefficients/omissions and material-occurrence locations remain distinct in authority metadata. This does not add typed quantity/compartment fields to the graph schema.

All 131 native evidence-reference originals and their exact receipt bindings are retained. Thirty reference-only identities are not promoted; nine are already-owned graph identities. Forty-six additional contextual native objects remain in the separate complete accepted source packet. Sodium uses exact verified prior-original reuse, while its failed new requests remain failures. Literal charged request tokens and the issuer XML-base `%2b` spelling are preserved. Recognition of an encoded bare query for downgrade rejection does not allow normalized provenance for the new typed kind.

## Taxonomy and independent input acceptances

After the independent issuer review was released and hash-bound, exactly three absent direct taxa were projected using the unchanged ontology `extract_terms` function and complete accepted pinned statement sets: **NCBITaxon:2208** Methanosarcina barkeri (species), **NCBITaxon:145262** Methanothermobacter thermautotrophicus (species), and **NCBITaxon:2179** Methanothermus (genus). Historical range28890 and all catalyst-context taxa remain excluded. Projection uses an in-memory SQL view of those retained issuing rows. The unchanged source provenance hashes the full external 14,115,225,600-byte NCBI Taxonomy2026-07-12 database, not the selected-row JSON. No new full-cache hash, live cache query or acquisition is claimed here.

The complete independent issuer review (57 physical files; manifest `3d2baf4aa3bfbb0cf7278337e7796ea5c6c02c822ced83b7d4bfb6f611573a50`) and independent graph review (127 physical files; manifest `d945acd1f4e48e462e4db2bc3ed4f3db197bc421d8ed99ef3a40946fc613c19e`) are copied and hash-bound. They accept the finite source/design scopes with explicit limits and no actionable finding. The immutable author graph design (1,212 physical files; manifest `906563c7d8eaafe6c9198bbd7f9b0bea75bebffe634a07285410a98bebbc4e48`) remains unchanged. Its earlier pending-issuer wording correctly describes that design's freeze cutoff; the new reviews are separate inputs rather than edits to frozen history.

Retain all accepted generic/stereochemical/ionic/compartment, taxon/strain/sequence, GeneID/paralog, cofactor and activity-direction limits. In particular, no exact public FORMYL-THMPT substitution, generic F420 replacement, Mer strain/kinetic transfer, AF_RS10430/O28206 catalytic strengthening, Mch direction repair or Mtr cofactor reconciliation follows from authority support. The known direct-candidate versus all-original SMILES importer denominators change no term identity.

## Verification

All final checks are terminal and recorded with actual raw-log hashes in `results/test-receipts.json`:

- **1,645 targeted tests passed** in231.82s, covering the new profile plus existing glutaryl, phenylacetate, P321, typed-consumer and source-builder regressions.
- Final lint passed.
- All **266 copied baseline records** pass the real identifier consumer.
- All **101 native declarations plus three taxa** pass the complete-design consumer diagnostic, with canonical labels and no errors.
- The normal producer adds **92 source owners/terms** and the accepted taxonomy projection adds **3 terms**. Every prior serialized object and insertion order remains identical: 1,323 source owners/3,335 source terms and5 ontology owners/2,203 ontology terms are preserved. Final totals are1,415/3,427 and5/2,206 respectively.
- Fresh isolated reproduction re-created both final snapshots and three finite source/taxonomy projections **byte-for-byte**. This is additive reproduction, not a fresh rebuild of historical source caches.

Malformed-input tests cover wrong frame/source/version/query/full-detail/class/slot identities; missing or contradictory embedded identity attributes at both boundaries; label/role/owner tampering; unsupported or normalized charged requests; legacy untyped-owner downgrades including unselected sources; generic carrier class changes; wrong root membership; and incorrect unnamed-homomer enzyme backlinks. Earlier source/collection/lint attempts remain with truthful dispositions and preserved scripts/logs.

The identifier diagnostic is not full schema/scientific/page/KGX acceptance and does not validate a final maintained270 record. No full maintained `just test` or `just validate` run is claimed. Complete final record composition, primary/reference/incident-edge scope, actual full-corpus gates, canonical review and issue626 integration/verified merge remain separate.

## Integration and reproduction

Read `REPRODUCE.md`; in a fresh copy, the supported replay is `PYTHONPATH=candidate/src:candidate /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/reproduce_additions.py`. The final candidate files and exact patch-owner inventory are the proposed implementation. `prepare_authority.py` is preserved initial authoring history, not the final replay entry point.

Only after independent authority acceptance should root integrate the listed paths into the actual270 worktree and incorporate `DOC-FRAGMENT.md` through its documentation owner. The author also wrote the native graph design and earlier269 authority work; independent graph/issuer acceptance is attributed to peers, and this packet makes no self-acceptance claim. Public-release licensing review remains deferred as instructed.
