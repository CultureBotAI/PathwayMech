# Reproduce the prospective authority additions

Copy this immutable packet into a new owned scratch directory first. Run with the existing verified interpreter and explicit candidate import path; no network, package install, runtime repair or mutable worktree is needed.

```bash
PYTHONPATH=candidate/src:candidate PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/reproduce_additions.py
```

The normal source builder reads the 92 originals and selects their exact native IDs. The unchanged ontology `extract_terms` function reads an in-memory SQL projection of the complete accepted three selected statement sets. The pinned full-cache source metadata remains unchanged; this replay does not query or rehash the 14.1-GB external database. `project_taxa.py` checks that the issuer peer acceptance is bound before adding the three direct taxa.

Existing serialized source/term objects and insertion order are preserved. All resulting snapshots pass the real consumer. A separately owned replay already reproduced the two snapshots, new-source projection, three-term taxonomy projection and exact selected taxonomy rows byte-for-byte; see `results/fresh-reproduction-comparison.json`.

From `candidate/`, run the bounded adapter regressions:

```bash
PYTHONPATH=src:. PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m pytest -q tests/test_methanogenesis_authority.py tests/test_glutaryl_authority.py tests/test_phenylacetate_authority.py tests/test_p321_authority.py tests/test_typed_authority_consumer_integrity.py tests/test_source_identifier_snapshot.py
```

`results/test-receipts.json` records actual terminal results. `scripts/probe_consumers.py` separately checks all 266 copied baseline records and the 101-node plus three-taxon diagnostic. This is an identifier/label/type gate only, not schema, scientific, page or whole maintained test-suite acceptance.

`prepare_authority.py` is the preserved initial authoring helper and is not the final replay entry point. Its initial charged XML-base and import/dispatch corrections, the reserved pytest parameter failure and the initial lint results are retained. The final candidate files, not the prototype generator, define the patch. Use `results/patch-owner-inventory.json` to integrate only exact owned paths after independent authority acceptance and parent authorization.
