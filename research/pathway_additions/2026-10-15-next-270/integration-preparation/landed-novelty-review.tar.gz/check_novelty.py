from pathlib import Path
import subprocess, json, hashlib, re, os, collections, shutil
import yaml
O=Path(__file__).resolve().parent
REPO=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')
HEAD='cf4dec8377669ec70e730428ba5aeb35e6ced1ca'
TREE='1c03509290f5c76048cb293bdd19c1f57143059c'
ISS=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
DISC=Path('/private/tmp/pathwaymech-next-270-discovery')
ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,x):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,env=ENV)
def read(path):return git('cat-file','blob',HEAD+':'+path)
assert git('rev-parse',HEAD+'^{tree}').decode().strip()==TREE
entries={}
for line in git('ls-tree','-r','-l','-z',HEAD).split(b'\0'):
 if not line:continue
 meta,name=line.split(b'\t',1);mode,typ,oid,size=meta.decode().split()
 entries[name.decode()]={'mode':mode,'type':typ,'git_blob':oid,'bytes':int(size) if size!='-' else None}
identity={'head':HEAD,'tree':TREE,'commit':git('cat-file','-p',HEAD).decode(),'tracked_paths':len(entries),'scope':'Exact immutable published Git tree; complete tracked names including hidden and tracked gitignored paths, no working-tree filtering. Provisional until landed merge supplied.'}
dump('published-identity.json',identity)
input_bindings=[]
def bind(src,dest):
 b=src.read_bytes();p=O/'inputs'/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 input_bindings.append({'source':str(src),'copy':str(p.relative_to(O)),'sha256':sha(b),'bytes':len(b)})
 return b
rd=json.loads(bind(ISS/'results/reaction-dispositions.json','reaction-dispositions.json'))
rc=json.loads(bind(ISS/'results/reaction-issuer-comparisons.json','reaction-issuer-comparisons.json'))
root=bind(ISS/'inputs/native/META-METHANOGENESIS-PWY.xml','META-METHANOGENESIS-PWY.xml')
assert sha(root)=='35e06e69cc42fe911cee1f6e33ddd950628d24bcb45a2807878099dd8dae43c8'
for owner,files in [('/private/tmp/pathwaymech-next-270-independent-preflight-review',['HANDOFF.md','REVIEW.md','artifact-manifest.json','freeze-proof.json']),('/private/tmp/pathwaymech-next-270-independent-issuer-review',['HANDOFF.md','REVIEW.md','artifact-manifest.json','freeze-proof.json'])]:
 for f in files:bind(Path(owner)/f,Path(owner).name+'/'+f)
for f in ['ignored-DRAM-comparison.json','compressed-history-content-scan.json','exact-preflight-search-original-checkout.json','exact-preflight-search-merged265.json']:
 bind(DISC/'results'/f,'preflight/'+f)
# Identity candidates are comparison handles, NOT asserted equivalences.
roots=['METHANOGENESIS-PWY','METHFORM-PWY','PWY-5209','PWY-6830','METH-ACETATE-PWY','PWY-5198','P261-PWY','P241-PWY','PWY-5254','PWY-6148']
exact={x['native_id'] for x in rd}
rheafams=sorted({str(int(x['rhea_master'])+i) for x in rc for i in range(4)}|{x['native_rhea_alias'] for x in rd})
kegg=sorted({x['kegg_alias'] for x in rd}|{'R04456','R04540','R04541','R11928','R11931','R11943','R11944','R09096'})
patterns=roots+sorted(exact)+['M00567','M00357']+kegg+['RHEA:'+x for x in rheafams]+['rhea-db.org/'+x for x in rheafams]+['EC:1.12.98.2','EC:1.5.98.1','EC:1.5.98.2','EC:3.5.4.27','EC:2.3.1.101','EC:1.2.7.12','EC:7.2.1.4','methanogen','methanopter','methanofuran','methyl-coenzyme M','methyl coenzyme M','coenzyme M','hydrogenotroph','methylotroph','methane','Wood-Ljungdahl']
(O/'search-patterns.txt').write_text('\n'.join(patterns)+'\n')
dump('candidate-and-alias-scope.json',{'native_root':'MetaCyc:METHANOGENESIS-PWY','six_members':sorted(exact),'rhea_family_ids':rheafams,'kegg_reaction_leads':kegg,'related_pathways_not_equivalences':roots[1:],'broader_modules':['M00567','M00357'],'UM_BBD_native_dblink':'meth','limits':'Reaction aliases retain accepted ionic/stereo/generic/directional/transport caveats. No bare numeric Rhea search and no bare word meth equivalence. M00567/M00357 and linked pathways are broader or alternate routes, not exact synonyms.'})
regex=re.compile('|'.join(re.escape(x) for x in patterns),re.I)
def matches(text):
 hits=list(regex.finditer(text));cnt=collections.Counter(m.group().casefold() for m in hits)
 return {'total_matches':len(hits),'matched_terms':dict(sorted(cnt.items())),'contexts':[text[max(0,m.start()-100):min(len(text),m.end()+160)] for m in hits[:15]],'context_limit':15}
def ids(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if k=='id' and isinstance(v,str):yield v
   yield from ids(v)
 elif isinstance(x,list):
  for y in x:yield from ids(y)
records=[];hitrecords=[];candidate_declarations=[];summaries=[]
for path,ent in entries.items():
 if not path.startswith('data/pathways/') or not path.lower().endswith(('.yaml','.yml')):continue
 b=read(path);txt=b.decode();r=yaml.safe_load(txt);allids=list(ids(r));m=matches(txt)
 row={'path':path,**ent,'sha256':sha(b),'id':r['id'],'label':r['label'],'pathway_type':r.get('pathway_type'),'reaction_ids':[z['id'] for z in r.get('reactions',[])],'participant_count':len(r.get('participants',[])),'all_declaration_count':len(allids)}
 records.append(row)
 overlaps=sorted(set(allids)&({'MetaCyc:'+x for x in exact}|{'MetaCyc:METHANOGENESIS-PWY'}|{'RHEA:'+x for x in rheafams}|{'KEGG.REACTION:'+x for x in kegg}|{'KEGG:'+x for x in kegg}))
 if overlaps:candidate_declarations.append({'path':path,'overlaps':overlaps})
 if m['total_matches']:hitrecords.append({'path':path,'id':r['id'],'label':r['label'],**m})
 if re.search('methan|acetogen|formaldehyde|formate|carbon fixation|Wood.Ljungdahl',r['label']+' '+r.get('description',''),re.I):
  summaries.append({'path':path,'id':r['id'],'label':r['label'],'description':r.get('description'),'reactions':r.get('reactions',[]),'relevant_participants':[x for x in r.get('participants',[]) if re.search('methan|coenzyme M|ferredoxin|carbon dioxide|dihydrogen|tetrahydrofol|formate|carbon monoxide',str(x),re.I)]})
  p=O/'compared-records'/Path(path).name;p.parent.mkdir(exist_ok=True);p.write_bytes(b)
assert len(records)==266
assert len({r['id'] for r in records})==266
dump('corpus-inventory.json',records);dump('corpus-alias-hits.json',hitrecords);dump('declaration-overlaps.json',candidate_declarations);dump('route-comparisons.json',summaries)
# Relevant retained ordinary text: full source discovery/cross-Mech files plus every earlier matching tracked source and 269 metadata inventories.
previous=json.loads((DISC/'results/exact-preflight-search-merged265.json').read_text())
selected={x['path'] for x in previous['files'] if x['path'] in entries}
selected|={p for p in entries if p.startswith(('research/source_discovery/','research/cross_mech/')) and p.endswith(('.md','.json','.txt','.tsv','.yaml','.yml','.csv'))}
selected|={p for p in entries if p.startswith('research/pathway_additions/2026-10-15-next-269/') and p.endswith(('.md','.json')) and any(t in p for t in ['inventory','retention','README','identifier-increment'])}
inventories=[]
for p in sorted(selected):
 b=read(p)
 try:txt=b.decode('utf-8')
 except UnicodeDecodeError:inventories.append({'path':p,**entries[p],'sha256':sha(b),'scope':'not UTF-8; not text-searched'});continue
 inventories.append({'path':p,**entries[p],'sha256':sha(b),**matches(txt)})
dump('retained-inventory-search.json',inventories)
# Rebind earlier accepted compressed comparison; reuse contents result, do not decode again.
comp=json.loads((DISC/'results/compressed-history-content-scan.json').read_text())
reb=[]
for x in comp['files']:
 p=x['path'];b=read(p);assert sha(b)==x['compressed_sha256']
 reb.append({'path':p,'git_blob':entries[p]['git_blob'],'sha256':sha(b),'bytes':len(b),'reused_decoded_sha256':x['decoded_sha256'],'reused_decoded_bytes':x['decoded_bytes'],'reused_old_pattern_hits':x['hits']})
archives=[{'path':p,**e} for p,e in entries.items() if p.endswith(('.gz','.zip','.tar','.tgz','.xz','.bz2','.zst'))]
dump('compressed-scope.json',{'published_archives':len(archives),'published_compressed_bytes':sum(x['bytes'] for x in archives),'rebound_preflight_gzip':len(reb),'reused_decoded_bytes':sum(x['reused_decoded_bytes'] for x in reb),'freshly_decoded_interiors':0,'rebound_files':reb,'limit':'Old116-file/17-pattern decoded result reused only after exact compressed SHA rebind. Expanded current alias set was NOT searched inside archives. Other interiors not part of this review; no global historical absence claim.'})
# Current original checkout supplementary physical inventory: includes all hidden/ignored record files.
physical=[]
for p in sorted((REPO/'data/pathways').rglob('*')):
 if p.is_file():
  b=p.read_bytes();rel=str(p.relative_to(REPO));row={'path':rel,'bytes':len(b),'sha256':sha(b),'published_blob':entries.get(rel,{}).get('git_blob')}
  if p.suffix.lower() in {'.yaml','.yml'}:
   try:
    obj=yaml.safe_load(b);row.update({'id':obj.get('id'),'label':obj.get('label'),'alias_matches':matches(b.decode())})
   except Exception as e:row['error']=str(e)
  physical.append(row)
dump('original-checkout-physical-records.json',{'scope':'Supplementary current original checkout, recursively includes hidden/ignored; is NOT claimed identical to published tree. No .gitignore filtering, no symlinks followed for directories.','files':physical})
# Exact ignored DRAM comparison, from accepted receipt and current physical bytes.
dram=json.loads((DISC/'results/ignored-DRAM-comparison.json').read_text());dramp=Path(dram['source']);db=dramp.read_bytes();assert sha(db)==dram['sha256']
ignore=subprocess.run(['git','check-ignore','--no-index','-v',str(dramp.relative_to(REPO))],cwd=REPO,env=ENV,capture_output=True,text=True)
dump('ignored-dram-rebind.json',{'source':str(dramp),'bytes':len(db),'sha256':sha(db),'check_ignore_returncode':ignore.returncode,'check_ignore_stdout':ignore.stdout,'selected_rows_reused':len(dram['rows']),'module_row_counts':dict(collections.Counter(x['module'] for x in dram['rows'])),'disposition':dram['disposition']})
dump('input-bindings.json',input_bindings)
summary={'head':HEAD,'tree':TREE,'records':len(records),'candidate_declaration_overlaps':candidate_declarations,'record_alias_match_files':len(hitrecords),'route_comparison_records':len(summaries),'retained_ordinary_files_searched':len(inventories),'retained_ordinary_match_files':sum(bool(x.get('total_matches')) for x in inventories),'physical_original_record_files':len(physical),'physical_original_yaml_count':sum(x['path'].endswith(('.yaml','.yml')) for x in physical),'compressed_rebound':len(reb),'provisional_pending_landed_merge':True}
dump('results.json',summary);print(json.dumps(summary,indent=2))
