from pathlib import Path
import subprocess,hashlib,json,re,os
O=Path(__file__).resolve().parent
R=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')
roots=['data/pathways','research/source_discovery','research/cross_mech','reports/local_source_ingestion']
cmd=['rg','--no-ignore','--hidden','--files-with-matches','-i','-F','-f',str(O/'search-patterns.txt'),*roots]
r=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
(O/'physical-source-search.stdout').write_text(r.stdout);(O/'physical-source-search.stderr').write_text(r.stderr)
pat=re.compile('|'.join(re.escape(x) for x in (O/'search-patterns.txt').read_text().splitlines()),re.I)
hits=[]
for s in r.stdout.splitlines():
 p=R/s;b=p.read_bytes();t=b.decode(errors='replace');ms=list(pat.finditer(t));hits.append({'path':s,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'match_count':len(ms),'terms':sorted({m.group().casefold() for m in ms}),'contexts':[t[max(0,m.start()-80):m.end()+160] for m in ms[:8]],'context_limit':8})
files=[p for root in roots for p in (R/root).rglob('*') if p.is_file()]
result={'command':cmd,'cwd':str(R),'returncode':r.returncode,'roots':roots,'physical_file_denominator_including_hidden_ignored':len(files),'hits':hits,'scope':'Fresh ordinary-text search over these four original-checkout roots, including hidden and ignored. Not the published Git snapshot; compressed interiors/binary contents not searched and no global source absence claimed.'}
(O/'physical-source-search.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'returncode':r.returncode,'matched_files':len(hits),'physical_files':len(files)}))
