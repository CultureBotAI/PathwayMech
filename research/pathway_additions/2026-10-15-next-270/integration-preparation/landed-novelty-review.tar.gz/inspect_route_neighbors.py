from pathlib import Path
import json,subprocess,hashlib,yaml
O=Path(__file__).resolve().parent;R='/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech';H='cf4dec8377669ec70e730428ba5aeb35e6ced1ca'
rs=json.loads((O/'corpus-inventory.json').read_text())
sel={'MetaCyc:CALVIN-PWY','KEGG:M00374','KEGG:M00373','MetaCyc:PWY-5789','MetaCyc:PWY0-1312'}
out=[]
for row in rs:
 if row['id'] not in sel:continue
 b=subprocess.check_output(['git','cat-file','blob',H+':'+row['path']],cwd=R)
 assert hashlib.sha256(b).hexdigest()==row['sha256']
 d=yaml.load(b,Loader=yaml.CSafeLoader)
 (O/'compared-records'/Path(row['path']).name).write_bytes(b)
 out.append({'path':row['path'],'id':d['id'],'label':d['label'],'description':d['description'],'reactions':d.get('reactions',[]),'sha256':row['sha256']})
(O/'additional-route-neighbors.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
for x in out:print(x['id'],x['description'][:600], '\nREACTIONS',[(z['id'],z['label']) for z in x['reactions']])
