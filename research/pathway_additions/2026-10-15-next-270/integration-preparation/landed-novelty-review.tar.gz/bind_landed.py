from pathlib import Path
import subprocess,json,hashlib,os
O=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-270-20261015');C=Path('/private/tmp/pathwaymech-next-269-ci')
H='e8ae5e445d3288717c31d3012611e226fd5cca34';P='cf4dec8377669ec70e730428ba5aeb35e6ced1ca';T='1c03509290f5c76048cb293bdd19c1f57143059c';B='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse',H+'^{tree}').decode().strip()==T
raw=git('cat-file','commit',H);hdr=raw.split(b'\n\n')[0].decode();assert 'tree '+T in hdr;assert [l[7:] for l in hdr.splitlines() if l.startswith('parent ')]==[B]
assert hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==H
(O/'landed-commit.raw').write_bytes(raw)
rows={}
for x in git('ls-tree','-rz',H,'data/pathways').split(b'\0'):
 if x:
  m,n=x.split(b'\t');mode,typ,oid=m.decode().split();rows[n.decode()]={'mode':mode,'type':typ,'git_blob':oid}
prior=json.loads((O/'corpus-inventory.json').read_text());checks=[]
for r in prior:
 assert rows[r['path']]['git_blob']==r['git_blob'];assert rows[r['path']]['mode']==r['mode']
 checks.append({'path':r['path'],'git_blob':r['git_blob'],'sha256':r['sha256'],'same_landed_blob':True})
assert len(prior)==266==sum(p.endswith(('.yaml','.yml')) for p in rows)
bindings=[]
for f in ['merge-integrity.json','actual-merged-pr.json']:
 b=(C/f).read_bytes();(O/'inputs'/f).write_bytes(b);bindings.append({'source':str(C/f),'copy':'inputs/'+f,'sha256':sha(b),'bytes':len(b)})
receipt=json.loads((O/'inputs/merge-integrity.json').read_text());assert receipt['complete'] and receipt['exit_code']==0 and receipt['errors']==[]
row=receipt['commits'][0];assert row=={'commit':H,'parent':B,'pr_number':627,'head':P,'expected_tree':T,'actual_tree':T,'status':'verified'}
pr=json.loads((O/'inputs/actual-merged-pr.json').read_text())
result={'actual_landed_head':H,'parent':B,'tree':T,'published_reviewed_head':P,'root_governed_merge_receipt_verified':True,'raw_commit_sha256':sha(raw),'raw_commit_git_oid_recomputed':H,'corpus_count':266,'all_published_corpus_blob_ids_and_modes_match_landed':True,'complete_tree_identical':True,'chronology':'Initial published-identity/results retain provisional review context. Root later supplied actual landed commit and governed merge-integrity receipt. This independent direct Git-object check binds the same entire tree and all266 corpus blob IDs to landed main. No new science or archive search implied.','git_object_read_location':str(R),'dependency_limit':'Only exact Git objects read from new270 worktree; raw commit and receipts copied here. No269 worktree dependency, no live working-tree content used.','input_bindings':bindings,'record_bindings':checks}
(O/'landed-binding.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='record_bindings'},indent=2))
