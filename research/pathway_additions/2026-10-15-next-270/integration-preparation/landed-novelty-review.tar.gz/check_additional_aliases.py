from pathlib import Path
import json,subprocess,io,hashlib
O=Path(__file__).resolve().parent;R='/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech'
rows=json.loads((O/'corpus-inventory.json').read_text())
pats=['UM-BBD-PWY:meth','UM-BBD:meth','pathway_abbr=meth','eawag-bbd.ethz.ch/meth/','umbbd.msi.umn.edu/meth/','Me-CoM','METHYL-THMPT','FORMYL-THMPT','THMPT','METHENYLTETRAHYDROMETHANOPTERIN','METHYLENETETRAHYDROMETHANOPTERIN']+['CHEBI:'+x for x in ['58337','58116','57818','58286','58103','17114','58018','58319']]
(O/'additional-search-patterns.json').write_text(json.dumps(pats,indent=2)+'\n')
r=subprocess.run(['git','cat-file','--batch'],input=''.join(x['git_blob']+'\n' for x in rows).encode(),cwd=R,capture_output=True,check=True)
buf=io.BytesIO(r.stdout);hits=[]
for x in rows:
 header=buf.readline().decode().split();assert header[0]==x['git_blob'] and header[1]=='blob'
 b=buf.read(int(header[2]));assert buf.read(1)==b'\n';assert hashlib.sha256(b).hexdigest()==x['sha256'];t=b.decode().casefold()
 found=[p for p in pats if p.casefold() in t]
 if found:hits.append({'path':x['path'],'patterns':found})
assert not buf.read()
result={'corpus_count':len(rows),'exact_SHA256_rebound':len(rows),'matches':hits,'patterns':pats,'scope':'Supplementary literal source dblink/THMPT-specific identity handles, no chemical equivalence inferred. Complete published corpus blob bytes reused; landed tree is identical.'}
(O/'additional-alias-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
