from pathlib import Path
import json,hashlib,datetime
O=Path(__file__).resolve().parent
checks=[]
def ck(n,b):
 assert b,n
 checks.append(n)
def J(n):return json.loads((O/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
main=J('results.json');corpus=J('corpus-inventory.json');landed=J('landed-binding.json')
ck('266 distinct complete records',len(corpus)==266==len({r['id'] for r in corpus}))
ck('record byte denominator',sum(r['bytes'] for r in corpus)==13043584)
ck('main terminal stdout equals result',json.loads((O/'check.stdout').read_text())==main)
for n in ['check.stderr','physical-check.stderr','physical-source-search.stderr','landed.stderr','route-neighbors.stderr','additional-alias.stderr']:ck('empty terminal stderr '+n,(O/n).read_bytes()==b'')
ck('original main process absent',J('terminal-process-check.json')['returncode']==1)
ck('no native/issuer declaration overlaps',J('declaration-overlaps.json')==[])
ck('no supplementary dblink/THMPT handles',J('additional-alias-results.json')['matches']==[])
ck('landed exact record bindings',landed['all_published_corpus_blob_ids_and_modes_match_landed'] and len(landed['record_bindings'])==266)
ck('identical complete landed/published tree',landed['tree']==main['tree']=='1c03509290f5c76048cb293bdd19c1f57143059c')
ck('landed actual commit',landed['actual_landed_head']=='e8ae5e445d3288717c31d3012611e226fd5cca34')
by={x['path']:x for x in corpus};copied=[]
for p in (O/'compared-records').iterdir():
 r=by['data/pathways/'+p.name];ck('compared record exact '+p.name,sha(p.read_bytes())==r['sha256']);copied.append(p.name)
ck('21 compared committed records',len(copied)==21)
for x in J('input-bindings.json')+landed['input_bindings']:
 b=Path(x['source']).read_bytes();ck('read input unchanged '+x['source'],sha(b)==x['sha256'] and len(b)==x['bytes']);ck('input copy exact '+x['copy'],(O/x['copy']).read_bytes()==b)
# Bind selected scientific inputs to the already accepted author inventories.
for owner,want,selected in [
('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation','dfc7cef1e269d870034b347abb99af7dd473f434cd487a2083105bb7f439e851',['inputs/native/META-METHANOGENESIS-PWY.xml','results/reaction-dispositions.json','results/reaction-issuer-comparisons.json']),
('/private/tmp/pathwaymech-next-270-discovery','357c7c297bd3952e76ccd3386f4e518e98a83d0d7b989a7f3710ef54082e6621',['results/ignored-DRAM-comparison.json','results/compressed-history-content-scan.json','results/exact-preflight-search-original-checkout.json','results/exact-preflight-search-merged265.json'])]:
 p=Path(owner);b=(p/'artifact-manifest.json').read_bytes();ck('accepted owner manifest '+owner,sha(b)==want);m={x['path']:x for x in json.loads(b)['files']}
 for n in selected:ck('selected frozen input '+n,sha((p/n).read_bytes())==m[n]['sha256'])
for n,want in [('pathwaymech-next-270-independent-issuer-review','3d2baf4aa3bfbb0cf7278337e7796ea5c6c02c822ced83b7d4bfb6f611573a50'),('pathwaymech-next-270-independent-preflight-review','a7f6e03360e990a4b99e10702ffe3b7489cbfaef2464992263564bc0d50b1892')]:ck('peer accepted manifest '+n,sha((O/'inputs'/n/'artifact-manifest.json').read_bytes())==want)
physical=J('original-checkout-physical-records.json')['files'];py=[x for x in physical if x['path'].endswith(('.yaml','.yml'))]
ck('physical hidden ignored corpus scope',len(physical)==259 and len(py)==258)
for x in py:ck('original-checkout subset '+x['path'],x['path'] in by and x['sha256']==by[x['path']]['sha256'] and 'error' not in x)
R=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')
ck('no skipped symlink directories in physical record tree',not any(x.is_symlink() and x.is_dir() for x in (R/'data/pathways').rglob('*')))
ps=J('physical-source-search.json');ck('hidden ignored search explicitly selected',ps['returncode']==0 and '--no-ignore' in ps['command'] and '--hidden' in ps['command'])
ck('physical source denominator/hits',ps['physical_file_denominator_including_hidden_ignored']==401 and len(ps['hits'])==17)
for x in ps['hits']:ck('physical matched source unchanged '+x['path'],sha((R/x['path']).read_bytes())==x['sha256'])
r=J('retained-inventory-search.json');ck('144 retained inventories',len(r)==144 and sum(x['bytes'] for x in r)==105204804)
ck('21 retained matching inventories',sum(bool(x.get('total_matches')) for x in r)==21)
c=J('compressed-scope.json');ck('bounded compression denominator',c['published_archives']==16742 and c['published_compressed_bytes']==1340462030)
ck('reused compressed scope',c['rebound_preflight_gzip']==116 and c['reused_decoded_bytes']==24849128 and c['freshly_decoded_interiors']==0)
ck('ignored DRAM demonstrated',J('ignored-dram-rebind.json')['check_ignore_returncode']==0)
res={'status':'qualified_acceptance','finding_count':0,'checks_passed':len(checks),'checks':checks,'actual_landed_head':landed['actual_landed_head'],'tree':landed['tree'],'records':266,'all_active_jobs_terminal':True,'scope':'Final finite novelty/alias review with accepted earlier scientific and compressed-search scopes reused; no maintained or authority implementation acceptance.','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'final-verification.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='checks'},indent=2))
