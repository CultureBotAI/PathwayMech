# Independent review replay

Do not execute scripts inside this frozen review. Prepare a new owned empty scratch directory and copy only `scripts/`, `inputs/` and `input-owners.json` from this review into it; create an empty `results/`. The scripts derive their output owner from their own location and reject existing result artifacts. They read the immutable author packet at its recorded absolute path.

Use the existing interpreter with `PYTHONDONTWRITEBYTECODE=1`, `PYTHONNOUSERSITE=1`, and `-B`. Set `PYTHONPATH` to the frozen author's `candidate/src:candidate` absolute directories. Run `scripts/intake.py input-before.json`, `scripts/audit.py`, `scripts/adversarial.py`, and `scripts/intake.py input-after.json`. No network, installation, live worktree, or historical cache rebuild is needed.

The regression command is retained in `results/verification-receipts.json`. Give pytest a new scratch `--basetemp` and disable its cache provider. It reads frozen candidate tests and writes only its explicit temporary directory and redirected log. Preserve any actual failed attempt. These checks cover authority implementation, not final record/page/scientific acceptance.
