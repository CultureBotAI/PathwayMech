"""Independent semantic mutation probes, beyond fixture/manifest equality."""
import base64
import copy
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET
from pathwaymech import biocyc_methanogenesis as m
R=Path(__file__).resolve().parents[1]
A=Path('/private/tmp/pathwaymech-next-270-native-authority-implementation')
O=A/'candidate/research/pathway_additions/2026-10-15-next-270/authority-source-originals'
entries={e['url'].split('META:')[1]:e for e in json.loads((O/'manifest.json').read_text())}
results=[]
def source(frame):
    e=entries[frame]
    return {k:e[k] for k in ['license','url','version','sha256']}
def body(frame): return (O/'originals'/Path(entries[frame]['path']).name).read_bytes()
def record(label, fn, reject=True):
    try:fn()
    except (ValueError,ET.ParseError) as ex:
        assert reject,(label,str(ex))
        results.append({'case':label,'expected':'reject','actual':'rejected','error':str(ex)})
    else:
        assert not reject,label+' unexpectedly accepted'
        results.append({'case':label,'expected':'accept','actual':'accepted'})
def changed(frame,label, mutate):
    original=body(frame); tree=ET.fromstring(original);mutate(tree)
    raw=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
    s=source(frame);s['sha256']=hashlib.sha256(raw).hexdigest()
    record(label+' producer',lambda:m.document(raw,s,m.KIND))
    doc=m.document(original,source(frame),m.KIND)
    doc['original_base64']=base64.b64encode(raw).decode()
    doc['root_attributes']=dict(tree.attrib)
    doc['metadata_xml']=ET.tostring(tree.find('metadata'),encoding='unicode')
    doc['projection']['slots']=[{'ordinal':i,'name':n.tag,'xml':ET.tostring(n,encoding='unicode')} for i,n in enumerate(tree[1],1)]
    record(label+' consumer',lambda:m.validate_methanogenesis_metadata({**s,'kind':m.KIND,m.FIELD:doc}))

# Complete producer data, including empty CML/scalar nodes and PGDB orgid metadata,
# is a positive control: metadata is not misclassified as a native frame pointer.
for frame in entries:
    record('genuine '+frame,lambda f=frame:m.document(body(f),source(f),m.KIND),False)

for frame in m.UNNAMED_HOMOMERS:
    frame=frame.split(':')[1]
    changed(frame,frame+' cannot derive monomer name',lambda t:setattr(t[1].find('component/coefficient'),'text','1'))
    changed(frame,frame+' duplicate activity name',lambda t:t[1].find('catalyzes/Enzymatic-Reaction').append(copy.deepcopy(t[1].find('catalyzes/Enzymatic-Reaction/common-name'))))
    changed(frame,frame+' malformed activity backlink',lambda t:t[1].find('catalyzes/Enzymatic-Reaction/enzyme/Protein').set('ID','META:'+frame))
changed('CPLX-381','heteromer cannot gain guessed source label',lambda t:t[1].append(ET.fromstring('<common-name datatype="string">guessed heteromer</common-name>')))
for value in ['0','-2','2.0','02','+2']:
    changed('2.1.1.86-RXN','Na coefficient '+value,lambda t,v=value:setattr(t[1].find('left/coefficient'),'text',v))
changed('2.1.1.86-RXN','duplicate compartment wrapper',lambda t:t[1].find('left').append(copy.deepcopy(t[1].find('left/compartment'))))
changed('2.1.1.86-RXN','location class mismatch',lambda t:t[1].find('left/compartment/cco').set('class','true'))
changed('2.1.1.86-RXN','outside finite location set',lambda t:(t[1].find('left/compartment/cco').set('frameid','CCO-CYTOSOL'),t[1].find('left/compartment/cco').set('resource','getxml?META:CCO-CYTOSOL')))
for frame in ['Oxidized-Factor-F420','Reduced-Factor-F420','Formyl-methanofurans','Methanofurans','CCO-MEMBRANE']:
    changed(frame,'class downgrade '+frame,lambda t:t[1].attrib.pop('class'))

# Every genuine embedded object type is challenged at both boundaries; strip all
# identity attributes, introduce dual ID/resource, or keep an orphan attribute.
examples={}
for frame in entries:
    t=ET.fromstring(body(frame))
    for n in list(t[1].iter())[1:]:
        if {'frameid','orgid','ID','resource'} & n.attrib.keys():examples.setdefault(n.tag,frame)
for tag,frame in examples.items():
    for mutation in ['all_missing','dual','org_only']:
        def mutate(t,tag=tag,mutation=mutation):
            n=next(n for n in list(t[1].iter())[1:] if n.tag==tag)
            if mutation=='dual':
                native=n.get('orgid')+':'+n.get('frameid');n.set('ID',native);n.set('resource','getxml?'+native)
            else:
                for k in ['frameid','orgid','ID','resource']:n.attrib.pop(k,None)
                if mutation=='org_only':n.set('orgid','META')
        changed(frame,tag+' identity '+mutation,mutate)

base='https://bf2i-artsymbiocyc.insa-lyon.fr'
for url in [base+'/getxml?META:NA%2B',base+'/getxml?META:NA%2b',base+'/getxml?id=META%3ANA%2B',base+'/getxml?object=META%3AMG%2B2',base+'/getxml?META:METHANOGENESIS-PWY','http://biocyc.org/getxml?META:METHANOGENESIS-PWY']:
    record('untyped owner blocked '+url,lambda u=url:m.validate_methanogenesis_assertions({'x':{'url':u}},[]))
for url in [base+'/other?META:METHANOGENESIS-PWY',base+'/getxml?note=META:METHANOGENESIS-PWY',base+'/getxml?META:METHANOGENESIS-PWY-extra',base+'/getxml?META:METHANOGENESIS-PWY&extra=1','https://biocyc.org.evil.example/getxml?META:METHANOGENESIS-PWY','ftp://biocyc.org/getxml?META:METHANOGENESIS-PWY',base+'/getxml?ECOLI:METHANOGENESIS-PWY']:
    record('unrelated unselected URL remains outside guard '+url,lambda u=url:m.validate_methanogenesis_assertions({'x':{'url':u}},[]),False)
for frame in ['NA+','MG+2','MN+2']:
    for alteration in ['encoded','http','fragment','query_suffix','wrong_host','id_form']:
        s=source(frame)
        if alteration=='encoded':s['url']=s['url'].replace('+','%2B')
        elif alteration=='http':s['url']=s['url'].replace('https:','http:')
        elif alteration=='fragment':s['url']+='#native'
        elif alteration=='query_suffix':s['url']+='&detail=full'
        elif alteration=='wrong_host':s['url']=s['url'].replace('bf2i-artsymbiocyc.insa-lyon.fr','biocyc.org')
        else:s['url']=s['url'].replace('?META:','?id=META:')
        record('exact typed acquisition '+frame+' '+alteration,lambda s=s,f=frame:m.document(body(f),s,m.KIND))

for payload,label in [(b'<!DOCTYPE ptools-xml [<!ENTITY x "bad">]>','DOCTYPE'),(b'<?probe bad?>','processing instruction')]:
    raw=body('HYDROGEN-MOLECULE');pos=raw.index(b'?>')+2;raw=raw[:pos]+payload+raw[pos:]
    s=source('HYDROGEN-MOLECULE');s['sha256']=hashlib.sha256(raw).hexdigest()
    record(label,lambda raw=raw,s=s:m.document(raw,s,m.KIND))

out=R/'results/adversarial.json';assert not out.exists()
out.write_text(json.dumps({'status':'passed','cases':len(results),'embedded_types':sorted(examples),'results':results},indent=2)+'\n')
print(json.dumps({'status':'passed','cases':len(results),'embedded_types':len(examples)}))
