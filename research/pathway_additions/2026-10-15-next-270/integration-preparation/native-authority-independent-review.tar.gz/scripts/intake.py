"""Read-only exact inventories, including hidden/ignored paths and self exclusions."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as handle:
        while block := handle.read(1024*1024): h.update(block)
    return h.hexdigest()

def check(owner, expected, count):
    p=Path(owner); manifest=p/'artifact-manifest.json'
    assert sha(manifest)==expected, str(manifest)
    data=json.loads(manifest.read_text()); rows=data['files']
    assert len({r['path'] for r in rows})==len(rows)
    physical={str(q.relative_to(p)):q for q in p.rglob('*') if q.is_file()}
    assert not any(q.is_symlink() for q in p.rglob('*'))
    assert len(physical)==count, (p,len(physical),count)
    extra=set(physical)-{r['path'] for r in rows}
    assert extra=={'artifact-manifest.json','freeze-proof.json'}, (p,extra)
    bound=[]
    for row in rows:
        q=physical[row['path']]
        assert q.stat().st_size==row['bytes'] and sha(q)==row['sha256'],str(q)
        bound.append(row)
    for name in sorted(extra):
        q=physical[name];bound.append({'path':name,'bytes':q.stat().st_size,'sha256':sha(q)})
    return {'owner':str(p),'manifest_sha256':expected,'listed':len(rows),'physical':count,
            'all_exact':True,'ignored_hidden_included':True,'bindings':bound}

if __name__=='__main__':
    inputs=json.loads((ROOT/'input-owners.json').read_text())
    results=[check(**row) for row in inputs]
    output=ROOT/'results'/sys.argv[1]
    assert not output.exists(),str(output)
    output.write_text(json.dumps(results,indent=2)+'\n')
    print({'owners':len(results),'files_checked':sum(r['physical'] for r in results)})
