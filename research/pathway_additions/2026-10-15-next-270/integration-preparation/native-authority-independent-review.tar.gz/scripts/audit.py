"""Independent finite source, profile, patch and additive replay audit."""
import ast
import base64
import copy
import gzip
import hashlib
import json
import shutil
import sqlite3
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET
import yaml
from pathwaymech import biocyc_methanogenesis as m
from pathwaymech.identifiers import _load_authority, identifier_errors
from scripts.build_source_identifier_snapshot import build_snapshot
from scripts.build_ontology_identifier_snapshot import extract_terms

R = Path(__file__).resolve().parents[1]
A = Path('/private/tmp/pathwaymech-next-270-native-authority-implementation')
C, B, D = A/'candidate', A/'baseline', A/'inputs/frozen-design'
O = C/'research/pathway_additions/2026-10-15-next-270/authority-source-originals'
checks = []
def check(ok, label):
    checks.append(label)
    assert ok, label
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, obj, ascii=False):
    p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), p
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=ascii)+'\n')
E=read(R/'inputs/expected-authority-scope.json')
expected=set(E['native_new_ids'])
check(set(m.PROFILES)==expected, 'exact 92 profiles')
# No duplicate literal profile dictionary keys hidden by Python evaluation.
tree=ast.parse((C/'src/pathwaymech/biocyc_methanogenesis.py').read_text())
for n in ast.walk(tree):
    if isinstance(n,ast.Dict) and all(isinstance(k,ast.Constant) for k in n.keys):
        values=[k.value for k in n.keys]
        check(len(values)==len(set(values)), 'unique literal dict keys at '+str(n.lineno))
inventory=read(A/'results/patch-owner-inventory.json')
actual_base={str(p.relative_to(B)):p for p in B.rglob('*') if p.is_file()}
actual_candidate={str(p.relative_to(C)):p for p in C.rglob('*') if p.is_file()}
owned={r['path']:r for r in inventory['files']}
excluded={r['path'] for r in inventory['operational_exclusions']}
check(len(actual_base)==732, '732 selected baseline files')
check(set(actual_candidate)==set(actual_base)|set(owned)|excluded, 'complete hidden and ignored patch universe')
for path,p in actual_base.items():
    if path in owned:
        check(owned[path]['change']=='modified' and sha(p)==owned[path]['baseline_sha256'], 'modified baseline '+path)
    else: check(p.read_bytes()==actual_candidate[path].read_bytes(), 'unchanged owner '+path)
for path,row in owned.items():
    p=actual_candidate[path]
    check(p.stat().st_size==row['bytes'] and sha(p)==row['sha256'], 'exact proposed owner '+path)
    check((path not in actual_base)==(row['change']=='added'), 'patch action '+path)
check(Counter(r['change'] for r in owned.values())=={'modified':5,'added':664}, 'five modified and 664 added')
old=read(B/'data/identifier_authorities/sources.json'); new=read(C/'data/identifier_authorities/sources.json')
for section in ['sources','terms']:
    check(list(new[section])[:len(old[section])]==list(old[section]), 'old source order '+section)
    for k,v in old[section].items(): check(new[section][k]==v, 'old source value '+k)
check(set(new['terms'])-set(old['terms'])==expected, 'new native owners exactly graph scope')
check(len(new['sources'])-len(old['sources'])==92, '92 added source owners')
for ident in E['existing_native_ids']: check(new['terms'][ident]==old['terms'][ident], 'existing graph owner '+ident)
entries=read(O/'manifest.json')
manifest_old=read(B/'conf/identifier_sources.json'); manifest_new=read(C/'conf/identifier_sources.json')
check(manifest_new==manifest_old+entries, 'manifest additive and exact')
check({'MetaCyc:'+e['url'].split('META:')[1] for e in entries}==expected, 'manifest scope')
by_id={r['id']:r for r in E['native_terms']}
storage=read(C/'tests/fixtures/methanogenesis_authority/storage.json')
projection_rows=[]; equations=[]; components=[]; types=Counter()
cache=R/'replay/cache'
for entry in entries:
    ident='MetaCyc:'+entry['url'].split('META:')[1]
    p=O/'originals'/Path(entry['path']).name
    original=(D/by_id[ident]['source_path'])
    check(p.read_bytes()==original.read_bytes() and sha(p)==entry['sha256'], 'accepted original '+ident)
    root=ET.fromstring(p.read_bytes()); entity=root[1]
    profile={'tag':entity.tag,'is_class':entity.get('class')=='true','slots':dict(Counter(n.tag for n in entity))}
    check(profile==m.PROFILES[ident], 'full own slot profile '+ident)
    types[(entity.tag,entity.get('class')=='true')]+=1
    stage=cache/entry['path'];stage.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,stage)
    meta=m.methanogenesis_metadata(entry,cache); projected=meta[m.FIELD]['projection']
    check(base64.b64decode(meta[m.FIELD]['original_base64'])==p.read_bytes(), 'full original retained '+ident)
    check(projected['label']==by_id[ident]['proposed_label'], 'accepted design name '+ident)
    check(projected['slots']==[{'ordinal':i,'name':n.tag,'xml':ET.tostring(n,encoding='unicode')} for i,n in enumerate(entity,1)], 'every slot retained '+ident)
    check(new['sources'][entry['key']]==meta, 'full source snapshot '+ident)
    check(new['terms'][ident]==m.methanogenesis_term(meta,entry['key'])[1], 'typed term '+ident)
    f=storage[entry['path']];compressed=(C/'tests/fixtures/methanogenesis_authority'/f['path']).read_bytes()
    check(gzip.decompress(compressed)==p.read_bytes() and hashlib.sha256(compressed).hexdigest()==f['compressed_sha256'], 'fixture original '+ident)
    if entity.tag=='Reaction':
        check(projected['label']==entity.get('frameid'), 'reaction frame name '+ident)
        for side in ['left','right']:
            independent=[]
            for w in entity.findall(side):
                n=next(n for n in w if n.tag not in {'coefficient','compartment'})
                loc=w.find('compartment')
                independent.append({'material':'MetaCyc:'+n.get('frameid'),'native_type':n.tag,'is_class':n.get('class')=='true','coefficient':int(w.findtext('coefficient')) if w.find('coefficient') is not None else None,'compartment':'MetaCyc:'+loc[0].get('frameid') if loc is not None else None})
            check(projected['sides'][side]==independent, 'exact side quantities locations '+ident+' '+side)
            equations.extend([dict(reaction=ident,side=side,**row) for row in independent])
    if ident in m.COMPLEXES:
        independent=[{'id':'MetaCyc:'+w.find('Protein').get('frameid'),'coefficient':int(w.findtext('coefficient')) if w.find('coefficient') is not None else None} for w in entity.findall('component')]
        check(projected['components']==independent, 'exact complex multiplicities '+ident)
        components.extend([dict(complex=ident,**row) for row in independent])
    projection_rows.append({'id':ident,'profile':profile,'label':projected['label'],'label_origin':projected['label_origin'],'original_sha256':sha(p)})
check(len(equations)==30 and len(components)==43, 'complete equation and component occurrences')
check(sum(x['compartment'] is not None for x in equations)==6, 'six located Mtr occurrences only')
check(sum(x['coefficient'] is None for x in components)==16, '16 omitted component quantities retained')
refs=read(O/'reference-original-bindings.json');acq=read(O/'acquisition-bindings.json')
check(len(refs)==len(acq)==131,'131 references and acquisition bindings')
for row in refs:
    p=O/row['path']
    check(sha(p)==row['sha256'] and p.read_bytes()==(D/row['source']).read_bytes(), 'reference original '+row['id'])
    check(row['selected_term']==(row['id'] in expected), 'reference-only exclusion '+row['id'])
for row in acq:
    p=O/row['receipt_path']
    check(sha(p)==row['receipt_sha256'] and p.stat().st_size==row['bytes'], 'acquisition original '+row['id'])
    check(any(r['id']==row['id'] and r['sha256']==row['body_sha256'] for r in refs), 'acquisition body binding '+row['id'])
# Fresh normal producer, retaining independent source inputs in own cache.
selection=R/'replay/selection';selection.mkdir(parents=True)
(selection/'selection.yaml').write_text(yaml.safe_dump({'id':'MetaCyc:METHANOGENESIS-PWY','participants':[{'id':x} for x in sorted(expected) if x!='MetaCyc:METHANOGENESIS-PWY']}))
addition=build_snapshot(O/'manifest.json',selection,cache)
check(set(addition['terms'])==expected and len(addition['sources'])==92,'normal producer exact selection')
reproduced=copy.deepcopy(old)
for section in ['sources','terms']:reproduced[section].update(addition[section])
save(R/'replay/sources.json',reproduced)
check((R/'replay/sources.json').read_bytes()==(C/'data/identifier_authorities/sources.json').read_bytes(),'source snapshot byte reproduction')
save(R/'replay/new-source-snapshot.json',addition)
check((R/'replay/new-source-snapshot.json').read_bytes()==(A/'results/reproduction/new-source-snapshot.json').read_bytes(),'source projection byte reproduction')
old_tax=read(B/'data/identifier_authorities/ontology.json');new_tax=read(C/'data/identifier_authorities/ontology.json')
ids=['NCBITaxon:2208','NCBITaxon:145262','NCBITaxon:2179']
check(set(new_tax['terms'])-set(old_tax['terms'])==set(ids), 'exact three direct taxa additions')
check(new_tax['sources']==old_tax['sources'], 'taxonomy provenance preserved')
check(list(new_tax['terms'])[:len(old_tax['terms'])]==list(old_tax['terms']), 'taxonomy old ordering preserved')
for k,v in old_tax['terms'].items():check(new_tax['terms'][k]==v,'old taxonomy '+k)
rows=read(O/'taxonomy/taxonomy-complete-selected-statements.json')
accepted=read(Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation/results/taxonomy-complete-selected-statements.json'))
check(rows==accepted,'complete selected taxonomy statements exact accepted source')
selected={i:rows[i] for i in ids}
ranks={i:next(r['object'] for r in rows[i] if r['predicate']=='obo:ncbitaxon#has_rank') for i in ids}
check(ranks==dict(zip(ids,['NCBITaxon:species','NCBITaxon:species','NCBITaxon:genus'])),'two species and genus retained')
with sqlite3.connect(':memory:') as conn:
    conn.execute('CREATE TABLE statements(stanza,subject,predicate,object,value,datatype,language,graph)')
    for seq in selected.values():
        for row in seq:conn.execute('INSERT INTO statements VALUES(?,?,?,?,?,?,?,?)',[row[k] for k in ['stanza','subject','predicate','object','value','datatype','language','graph']])
    terms,missing=extract_terms(conn,ids,'ncbitaxon-2026-07-12')
check(not missing,'selected taxonomy extraction complete')
tax_reproduction=copy.deepcopy(old_tax);tax_reproduction['terms'].update(terms)
save(R/'replay/ontology.json',tax_reproduction,True)
check((R/'replay/ontology.json').read_bytes()==(C/'data/identifier_authorities/ontology.json').read_bytes(),'ontology byte reproduction')
for name,obj in [('three-additive-terms.json',terms),('three-direct-taxon-selected-statements.json',selected)]:
    save(R/'replay'/name,obj)
    check((R/'replay'/name).read_bytes()==(A/'results/taxonomy'/name).read_bytes(),'taxonomy projection byte reproduction '+name)
check(_load_authority(R/'replay/sources.json')==new['terms'],'real source snapshot consumer')
check(_load_authority(R/'replay/ontology.json')==new_tax['terms'],'real ontology snapshot consumer')
corpus=identifier_errors(C)
check(not corpus,'266 copied baseline identifier gate')
probe=R/'consumer';(probe/'data/pathways').mkdir(parents=True);(probe/'conf').mkdir()
record=yaml.safe_load((D/'results/native-biochemical-probe.yaml').read_text())
record['taxa']=[{'id':i,'label':t['label']} for i,t in terms.items()]
(probe/'data/pathways/diagnostic.yaml').write_text(yaml.safe_dump(record,sort_keys=False,allow_unicode=True))
shutil.copy2(C/'conf/identifier_policy.yaml',probe/'conf/identifier_policy.yaml')
shutil.copytree(C/'data/identifier_authorities',probe/'data/identifier_authorities')
check(not identifier_errors(probe),'101 native plus three direct taxon diagnostic consumer')
save(R/'results/independent-audit.json',{'status':'passed','checks':len(checks),'check_labels':checks,'types':{str(k):v for k,v in types.items()},'native_profiles':projection_rows,'equations':equations,'components':components,'ranks':ranks,'new_native_count':92,'existing_native_count':9,'taxon_additions':3,'patch_modified':5,'patch_added':664,'full_baseline_records':266,'reproduced_artifacts':5,'scope':'Finite implementation review; no full maintained corpus gate, final record, page or primary self-acceptance.'})
print(json.dumps({'checks':len(checks),'native':92,'taxa':3,'equations':len(equations),'components':len(components),'status':'passed'}))
