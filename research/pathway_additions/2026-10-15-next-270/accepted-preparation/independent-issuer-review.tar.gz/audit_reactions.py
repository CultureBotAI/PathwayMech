from pathlib import Path
import json,xml.etree.ElementTree as E,gzip,collections,re,hashlib
P=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation');NS='http://rdf.rhea-db.org/';RDF='http://www.w3.org/1999/02/22-rdf-syntax-ns#';checks=[]
def ck(x,why):
 checks.append(why)
 if not x:raise AssertionError(why)
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
def obj(f):return next(x for x in E.parse(R/'inputs/native'/('META-'+f+'.xml')).getroot() if x.tag!='metadata')
def refs(e,slot):return [x.get('frameid') for x in e.findall(slot+'/*') if x.get('frameid')]
def xrefs(e):return {x.findtext('dblink-db'):x.findtext('dblink-oid') for x in e.findall('dblink')}
root=obj('METHANOGENESIS-PWY');members=refs(root,'reaction-list');dirs={s.find('Reaction').get('frameid'):s.findtext('direction') for s in root.findall('reaction-layout')};ck(len(members)==6 and set(members)==set(dirs),'six members/layout directions')
# Full pinned RDF parsed independently; do not follow network references.
graph=collections.defaultdict(list);count=0
with gzip.open(R/'originals/rhea.rdf.gz','rb') as f:
 for event,e in E.iterparse(f,events=['end']):
  if e.tag=='{'+RDF+'}Description':
   count+=1;uri=e.get('{'+RDF+'}about');graph[uri].extend([{'predicate':c.tag[1:].replace('}',''),'resource':c.get('{'+RDF+'}resource'),'literal':c.text,'attributes':dict(c.attrib)} for c in e]);e.clear()
ck(count==326097,'complete pinned RDF description count');author=json.loads((R/'results/rhea-six-family-replay.json').read_text());ck(hashlib.sha256((R/'originals/rhea.rdf.gz').read_bytes()).hexdigest()==author['source_sha256'],'pinned Rhea bytes');ck('142' in (R/'originals/rhea-release.properties').read_text(),'Rhea release142')
for uri,statements in author['complete_selected_statements'].items():ck(graph[uri]==statements,'full selected Rhea statement record '+uri)
ck(len(author['complete_selected_statements'])==90,'90 selected statement records')
def vals(uri,pred):return [t['resource'] if t['resource'] is not None else t['literal'] for t in graph[uri] if t['predicate']==NS+pred]
def one(uri,pred):
 v=vals(uri,pred);ck(len(set(v))==1,'unique RDF '+uri+' '+pred);return v[0]
seeds={xrefs(obj(f))['RHEA'] for f in members};ck(seeds=={'20020','17585','21147','19056','18061','19844'},'exact six native Rhea aliases');fam=[]
for line in (R/'originals/rhea-directions.tsv').read_text().splitlines()[1:]:
 v=line.split('\t')
 if (seeds|{'53492'})&set(v):fam.append(dict(zip(['master','left_to_right','right_to_left','bidirectional'],v)))
ck(fam==author['direction_families'] and len(fam)==6,'six exact current families');ck('17585' not in {v for f in fam for v in f.values()},'obsolete alias not current directions row');old=graph[NS+'17585'];ck(any(t['predicate']==NS+'status' and t['resource']==NS+'Obsolete' for t in old),'old alias explicitly obsolete');comments=[t['literal'] for t in old if t['predicate'].endswith('comment')];ck(any('53492' in str(x) for x in comments),'replacement literal comment');ck(not vals(NS+'17585','replacedBy'),'no invented replacedBy relation in pinned object')
equations={}
for f in fam:
 for dr in ['left_to_right','right_to_left']:
  rid=f[dr];sides={}
  for role in ['substrates','products']:
   side=one(NS+rid,role);terms=[]
   for t in graph[side]:
    m=re.fullmatch(re.escape(NS)+r'contains(\d+)',t['predicate'])
    if not m:continue
    p=t['resource'];compound=one(p,'compound');terms.append({'coefficient':int(m[1]),'participant':p,'compound':compound,'accession':vals(compound,'accession'),'name':vals(compound,'name'),'formula':vals(compound,'formula'),'charge':vals(compound,'charge'),'chebi':vals(compound,'chebi'),'underlyingChebi':vals(compound,'underlyingChebi'),'reactivePart':vals(compound,'reactivePart'),'location':vals(p,'location')})
   sides[role]=terms
  row={'id':rid,'master':f['master'],'direction':dr,'equation':vals(NS+rid,'equation'),'status':vals(NS+f['master'],'status'),**sides};ck(row==next(x for x in author['equations'] if x['id']==rid),'directional equation exact '+rid);equations[rid]=row
ck(len(equations)==12,'twelve independently reconstructed directional equations')
# Native equations, generic-boundary balance and exact location-sensitive algebra.
rows=[];balance=[];net=collections.Counter();locnet=collections.Counter();occ=0
for f in members:
 e=obj(f);terms={}
 for side in ['left','right']:
  seq=[]
  for s in e.findall(side):
   ids=[x.get('frameid') for x in s if x.get('frameid')];ck(len(ids)==1,'one equation participant '+f);seq.append({'id':ids[0],'coefficient':int(s.findtext('coefficient') or 1),'location':next(iter(refs(s,'compartment')),None)})
  terms[side]=seq;occ+=len(seq)
 if dirs[f]=='R2L':terms={'left':terms['right'],'right':terms['left']}
 known=collections.Counter();unknown=[]
 for side,sign in [('left',-1),('right',1)]:
  for t in terms[side]:
   n=obj(t['id']);net[t['id']]+=sign*t['coefficient'];locnet[(t['id'],t['location'])]+=sign*t['coefficient'];c=n.find('cml/molecule');formula=c.find('formula') if c is not None else None
   if n.get('class')=='true' or formula is None:unknown.append(t);continue
   v=formula.get('concise').split()
   for element,co in zip(v[::2],v[1::2]):known[element.capitalize()]+=sign*t['coefficient']*int(co)
   known['charge']+=sign*t['coefficient']*int(c.get('formalCharge'))
  
 row={'native_id':f,'pathway_direction':dirs[f],'complete':not unknown,'known_term_products_minus_reactants':{k:v for k,v in sorted(known.items()) if v},'unknown_generic_terms':unknown};balance.append(row)
 r=next(x for x in json.loads((R/'results/reaction-issuer-comparisons.json').read_text()) if x['native_id']==f);ck(r['native_pathway_terms']==terms,'exact source sides coefficient location '+f)
 rr=equations[r['compared_directional_rhea']];ck(r['rhea_issuer_formula_terms']==rr,'original RDF equation attached '+f)
 # Derive candidate chemical IDs directly except stated narrower generic/reaction-linked identities.
 narrow={'FORMYL-THMPT':'58018','Formyl-methanofurans':'57727','Methanofurans':'58151','Oxidized-Factor-F420':'POLYMER:12939','Reduced-Factor-F420':'POLYMER:14378','Oxidized-ferredoxins':'GENERIC:10000','Reduced-ferredoxins':'GENERIC:10001'}
 def cid(t):return narrow.get(t['id'],xrefs(obj(t['id'])).get('CHEBI'))
 sig=lambda ts:dict(sorted(collections.Counter({key:sum(t['coefficient'] for t in ts if t['id']==key) for key in {t['id'] for t in ts}}).items()))
 rdfterms={s:[{'id':t['accession'][0].removeprefix('CHEBI:') if t['accession'] else t['compound'].removeprefix(NS),'coefficient':t['coefficient'],'location':t['location']} for t in rr[role]] for s,role in [('left','substrates'),('right','products')]};ck(rdfterms==r['rhea_pathway_terms'],'RDF participant projection '+f)
 difference={}
 for side in ['left','right']:
  a=collections.Counter();b=collections.Counter()
  for t in terms[side]:a[cid(t)]+=t['coefficient']
  for t in rdfterms[side]:b[t['id']]+=t['coefficient']
  difference[side]={k:b[k]-a[k] for k in sorted(a.keys()|b.keys()) if b[k]!=a[k]}
 ck(difference==r['rhea_minus_native_candidate_mapped_side_quantities'],'independent Rhea coefficient difference '+f)
 kid=xrefs(e)['LIGAND-RXN'];txt=(R/'originals'/('KEGG-'+kid+'.txt')).read_text();ck(re.search(r'^ENTRY\s+'+kid+r'\b',txt,re.M) is not None,'KEGG reaction issuer id '+kid);eq=re.search(r'^EQUATION\s+(.+)',txt,re.M)[1];parts=eq.split(' <=> ');kt={}
 for s,text in zip(['left','right'],parts):
  kt[s]=[]
  for term in text.split(' + '):
   m=re.fullmatch(r'(?:(\d+)\s+)?(C\d{5})(?:\s*\(([^)]+)\))?',term);ck(m is not None,'KEGG complete literal term '+kid+' '+term);kt[s].append({'id':m[2],'coefficient':int(m[1] or 1),'location':m[3]})
 if dirs[f]=='R2L' and f!='METHELENE-THMPT-OXI-RXN':kt={'left':kt['right'],'right':kt['left']}
 ck(kt==r['kegg_pathway_terms'],'KEGG orientation '+f);kd={}
 for s in ['left','right']:
  a=collections.Counter();b=collections.Counter()
  for t in terms[s]:a['C00876' if t['id']=='Oxidized-Factor-F420' else xrefs(obj(t['id']))['LIGAND-CPD']]+=t['coefficient']
  for t in kt[s]:b[t['id']]+=t['coefficient']
  kd[s]={k:b[k]-a[k] for k in sorted(a.keys()|b.keys()) if a[k]!=b[k]}
 ck(kd==r['kegg_minus_native_candidate_mapped_side_quantities'],'KEGG coefficient differences '+f);rows.append({'native_id':f,'native_direction':dirs[f],'native_terms':terms,'Rhea':r['compared_directional_rhea'],'Rhea_terms':rdfterms,'Rhea_candidate_coefficient_delta':difference,'KEGG':kid,'KEGG_equation':eq,'KEGG_terms':kt,'KEGG_candidate_coefficient_delta':kd})
ck(occ==30,'all30 native equation occurrences');recorded=json.loads((R/'results/native-formal-balance-and-net.json').read_text())
for b in balance:
 a=next(x for x in recorded['equations'] if x['native_id']==b['native_id']);ck(all(a[k]==v for k,v in b.items()),'independent formal balance '+b['native_id']);ck(bool(b['unknown_generic_terms']) or not b['known_term_products_minus_reactants'],'no fully specified native imbalance '+b['native_id'])
ck(sum(x['complete'] for x in balance)==3,'three complete and three undetermined balances');net={k:v for k,v in sorted(net.items()) if v};ln=[{'id':k[0],'location':k[1],'coefficient_products_minus_reactants':v} for k,v in sorted(locnet.items(),key=lambda z:(z[0][0],str(z[0][1]))) if v];ck(net==recorded['frame_only_formal_net_products_minus_reactants'] and ln==recorded['fully_location_sensitive_formal_net'],'two independent formal nets')
mtr=next(x for x in rows if x['native_id']=='2.1.1.86-RXN');ck([x for x in mtr['Rhea_terms']['left'] if x['id']=='29101']==[{'id':'29101','coefficient':2,'location':[NS+'In']}],'Rhea two inward Na');ck([x for x in mtr['Rhea_terms']['right'] if x['id']=='29101']==[{'id':'29101','coefficient':2,'location':[NS+'Out']}],'Rhea two outward Na');ck(all(not t['location'] for s in mtr['Rhea_terms'].values() for t in s if t['id']!='29101'),'Rhea four other locations unspecified');ck(all(t['location']=='CCO-IN' for s in mtr['native_terms'].values() for t in s if t['id']!='NA+'),'native four other carriers inside')
mer=next(x for x in rows if x['native_id']=='METHELENE-THMPT-OXI-RXN');ck(mer['Rhea_candidate_coefficient_delta']=={'left':{},'right':{'15378':1}},'Mer extra proton explicit')
save('reaction-independent-comparisons.json',{'RDF_descriptions':count,'selected_RDF_records':90,'families':fam,'equations':equations,'obsolete17585':old,'native_and_issuer_comparisons':rows,'native_formal_balance':balance,'frame_only_net':net,'location_sensitive_net':ln,'scope':'All comparisons are source-specific arithmetic, not automatic chemical/compartment equivalence or physiological flux.'});save('reaction-checks.json',checks);save('reaction-result.json',{'checks':len(checks),'RDF_descriptions':count,'selected_records':90,'families':6,'directional_equations':12,'native_members':6,'material_occurrences':30,'formally_balanced_complete':3,'generic_undetermined':3,'result':'equation, direction, transport, proton and class boundaries independently reproduced'});print(json.dumps(json.loads((P/'reaction-result.json').read_text()),indent=2))
