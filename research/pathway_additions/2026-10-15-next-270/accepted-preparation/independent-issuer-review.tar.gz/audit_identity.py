from pathlib import Path
import json,hashlib,re,sqlite3,xml.etree.ElementTree as E,datetime,collections
P=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation');checks=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ck(x,why):
 checks.append(why)
 if not x:raise AssertionError(why)
def js(p):return json.loads(p.read_text())
def save(n,j):(P/n).write_text(json.dumps(j,indent=2)+'\n')
def obj(path):return next(x for x in E.parse(path).getroot() if x.tag!='metadata')
def xrefs(e):return [{'db':z.findtext('dblink-db'),'id':z.findtext('dblink-oid'),'relationship':z.findtext('dblink-relationship')} for z in e.findall('dblink')]
def refs(e,tag):return [z.get('frameid') for z in e.findall(tag+'/*') if z.get('frameid')]
# Whole packet, accepted predecessor owners and issuer acquisitions.
packets=[(R,'dfc7cef1e269d870034b347abb99af7dd473f434cd487a2083105bb7f439e851')]
for owner,h in [('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation','2bd6c0bf3c957babb332519a8216a56840ae017914e09bc87ba1265673085c56'),('/private/tmp/pathwaymech-next-270-independent-source-closure-review','a64814d2b73ce4f5399704f087a816be51bae880fc448f13ec231a935d6812fe'),('/private/tmp/pathwaymech-next-270-source-locator-correction','d5f86a9308a10e1537f23a9bf0620445823bc2be05f53c85a0d71736c2b3f22b'),('/private/tmp/pathwaymech-next-270-source-locator-independent-acceptance','ef8ceb23771aae539748233f9f0099cfe14e363606d1bcfccacbe3c457597caf')]:packets.append((Path(owner),h))
packet_rows=[]
for owner,h in packets:
 ck(sha(owner/'artifact-manifest.json')==h,'manifest '+str(owner));m=js(owner/'artifact-manifest.json');actual={str(p.relative_to(owner)) for p in owner.rglob('*') if p.is_file()};ck(actual=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'},'physical inventory '+str(owner))
 for row in m['files']:ck(sha(owner/row['path'])==row['sha256'] and (owner/row['path']).stat().st_size==row['bytes'],'exact '+str(owner/row['path']))
 packet_rows.append({'owner':str(owner),'manifest_sha256':h,'physical_files':len(actual),'all_verified':True})
receipts=[]
for f in sorted((R/'receipts').glob('*.json')):
 j=js(f);receipts.extend(j if isinstance(j,list) else [j])
ck(len(receipts)==76,'76 fresh receipt entries')
for row in receipts:
 ck(row['status']==200,'fresh status '+row['path']);ck(sha(R/row['path'])==row['sha256'] and (R/row['path']).stat().st_size==row['bytes'],'fresh body '+row['path']);ck(row['url']==row['final_url'],'exact request URL '+row['path'])
reused=js(R/'inputs/reused-issuing-originals.json');ck(len(reused)==6,'6 reuse entries')
for row in reused:
 ck(sha(R/row['copy'])==row['sha256']==sha(Path(row['source'])),'reuse bytes '+row['copy']);parent=Path(row['source']).parent.parent;ck(sha(parent/'artifact-manifest.json')==row['manifest_sha256'],'reuse manifest '+row['copy'])
readings=js(R/'results/issuing-original-reading-bindings.json');ck(len(readings)==82,'82 issuer reading bindings');ck({x['path'] for x in readings}=={x['path'] for x in receipts}|{x['copy'] for x in reused},'readings cover exact fresh/reused set')
for row in readings:ck(sha(R/row['path'])==row['sha256'] and (R/row['path']).stat().st_size==row['bytes'],'reading original '+row['path'])
# Each copied native original is byte-identical to an accepted source original.
source=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation');source_manifest=js(source/'artifact-manifest.json');source_hashes={x['sha256'] for x in source_manifest['files']};native={}
for p in sorted((R/'inputs/native').glob('*.xml')):
 e=obj(p);ck(e.get('detail')=='full','full native '+p.name);ck(sha(p) in source_hashes,'native bytes accepted source '+p.name);ck(e.get('frameid') not in native,'native unique '+p.name);native[e.get('frameid')]=e
ck(len(native)==177,'177 native full objects')
# Typed object and exact own-slot coverage, avoiding generic reaction backlink IDs.
prows=js(R/'results/protein-gene-dispositions.json');pids={k for k,e in native.items() if e.tag=='Protein' and e.get('class')!='true'};ck({x['native_id'] for x in prows}==pids and len(pids)==57,'57 complete nonclass protein dispositions')
public=[];genediffs=[]
for row in prows:
 f=row['native_id'];e=native[f];ck(sha(R/row['native_path'])==row['native_sha256'],'protein hash '+f);ck(xrefs(e)==row['native_xrefs'],'protein xrefs '+f);ck(refs(e,'species')==row['native_species'],'protein taxa '+f);ck([''.join(z.itertext()) for z in e.findall('comment')]==row['native_comments'],'protein comments '+f);ck([E.tostring(z,encoding='unicode') for z in e.findall('component')]==row['native_components'],'protein components '+f)
 ck(refs(e,'gene')==[g['id'] for g in row['native_genes']],'protein genes '+f)
 for g in row['native_genes']:
  ge=native[g['id']];ck(xrefs(ge)==g['xrefs'],'gene xrefs '+g['id']);ck({k:[z.text for z in ge.findall(k)] for k in ['common-name','accession-1','accession-2','synonym']}==g['identity_slots'],'gene identity '+g['id']);ck(sha(R/g['path'])==g['sha256'],'gene hash '+g['id'])
 pointers=[x['id'] for x in xrefs(e) if x['db']=='UNIPROT'];ck(pointers==[x['accession'] for x in row['uniprot']],'exact direct uniprot set '+f)
 for u in row['uniprot']:
  j=js(R/u['path']);acc=j['primaryAccession'];ck(acc==u['accession'] and sha(R/u['path'])==u['sha256'],'issuer identity '+acc)
  for a,b in [('review_status','entryType'),('organism','organism'),('genes','genes')]:ck(u[a]==j.get(b),'issuer field '+acc+' '+a)
  loc=[l['value'] for gene in j.get('genes',[]) for l in gene.get('orderedLocusNames',[])];ck(loc==u['ordered_loci'],'loci '+acc)
  cross=[x for x in j['uniProtKBCrossReferences'] if x['database'] in ['EMBL','RefSeq','GeneID','KEGG','Proteomes']];ck(cross==u['sequence_crossrefs'],'issuer crossrefs '+acc);ck(len(j['sequence']['value'])==j['sequence']['length']==u['sequence_length'] and hashlib.sha256(j['sequence']['value'].encode()).hexdigest()==u['sequence_sha256'],'sequence integrity '+acc)
  ck([c for c in j.get('comments',[]) if c['commentType']=='SEQUENCE CAUTION']==u['sequence_cautions'],'sequence cautions '+acc);ck([c for c in j.get('features',[]) if c['type']=='Sequence conflict']==u['sequence_conflict_features'],'sequence conflicts '+acc)
  old=[x for g in row['native_genes'] for x in g['identity_slots']['accession-2']];nr=[x['id'] for x in xrefs(e) if x['db']=='NCBI-REFSEQ-PRO'];ng=[x['id'] for g in row['native_genes'] for x in g['xrefs'] if x['db']=='NCBI-GENE'];ig=[x['id'] for x in cross if x['database']=='GeneID'];ir=[x['id'] for x in cross if x['database']=='RefSeq']
  ck((bool(old) and set(old)<=set(loc))==u['native_old_locus_matches'],'locus comparison '+acc);ck((bool(nr) and set(nr)<=set(ir))==u['native_RefSeq_alias_matches_UniProt_report'],'refseq comparison '+acc);ck(ng==u['native_GeneID_pointers'] and ig==u['UniProt_GeneID_pointers'],'GeneID pointers '+acc)
  if ng and set(ng)!=set(ig):genediffs.append({'native':f,'accession':acc,'native_GeneIDs':ng,'issuer_GeneIDs':ig})
  public.append({'native':f,'accession':acc,'taxon':j['organism']['taxonId'],'status':j['entryType'],'name':j['proteinDescription'],'genes':j.get('genes',[]),'comments':j.get('comments',[]),'conflicts':[z for z in j.get('features',[]) if z['type']=='Sequence conflict'],'references':[{'citation':x['citation'],'positions':x.get('referencePositions',[]),'comments':x.get('referenceComments',[])} for x in j['references']]})
ck(len(public)==14,'14 direct protein accession pointers');ck(len(genediffs)==8,'eight GeneID discrepancies');ck(sum(x['taxon']==224325 for x in public)==9,'nine AF DSM4304 pointers');ck(sum(x['taxon']==187420 for x in public)==4,'four DeltaH pointers');ck(sum(x['taxon']==272630 for x in public)==1,'one AM1 pointer')
# Fifteen activity closures, own directions/cofactor/regulation slots and complete seven target contexts.
author_acts=js(R/'results/activity-identity-contexts.json');aids={k for k,e in native.items() if e.tag=='Enzymatic-Reaction'};ck({x['activity'] for x in author_acts}==aids and len(aids)==15,'all15 activity dispositions');actout=[]
for a in author_acts:
 e=native[a['activity']];ck(refs(e,'reaction')==[a['reaction']] and refs(e,'enzyme')==[a['enzyme']],'activity endpoints '+a['activity']);ck(e.findtext('reaction-direction')==a['native_activity_direction'],'activity direction '+a['activity']);todo=[a['enzyme']];seen=set()
 while todo:
  f=todo.pop()
  if f not in seen:seen.add(f);todo.extend(refs(native[f],'component'))
 ck(sorted(seen)==a['linked_protein_closure'],'activity protein closure '+a['activity']);ck(refs(native[a['enzyme']],'species')==a['native_species'],'activity enzyme taxa '+a['activity'])
 for slot,key in [('cofactor','cofactor_slots'),('regulated-by','regulations')]:ck([E.tostring(x,encoding='unicode') for x in e.findall(slot)]==[x['xml'] for x in a[key]],'exact activity '+slot+' '+a['activity'])
 actout.append({'activity':a['activity'],'reaction':a['reaction'],'enzyme':a['enzyme'],'direction':a['native_activity_direction'],'closure':sorted(seen),'cofactors':refs(e,'cofactor'),'regulations':refs(e,'regulated-by')})
ck(sum(len(a['regulations']) for a in actout)==7,'seven exact activity regulations')
# Literal historical accession/sequence comparison, from original ENA plus original UniProt.
ena=(R/'originals/ENA-X86477.embl').read_text();translation=re.search(r'/translation="([^"]+)"',ena).group(1);translation=re.sub(r'\s|FT','',translation)
q=js(R/'originals/UniProt-Q50744.json');d=js(R/'originals/UniProt-O27784.json');ck(len(translation)==321 and translation==q['sequence']['value'],'ENA translation exact Q50744');diff=[{'position':i+1,'ENA_Marburg':x,'UniProt_Delta_H':y} for i,(x,y) in enumerate(zip(translation,d['sequence']['value'])) if x!=y];mc=js(R/'results/mer-sequence-conflict.json');ck(diff==mc['same_position_differences'] and len(diff)==5,'literal five residue differences');ck(q['organism']['taxonId']==79929 and d['organism']['taxonId']==187420,'Mer distinct strain identities');ck('/strain="Marburg/DSM 2133"' in ena and '/db_xref="taxon:145262"' in ena and '/protein_id="CAA60203.1"' in ena,'ENA source historical qualifiers');ck(any(x['id']=='X86477' and x['relationship']=='PART-OF' for x in xrefs(native['G-356'])),'native Mer nucleotide pointer');ck(any(x['id']=='O27784' for x in xrefs(native['MERMAUTO-MONOMER'])),'native Mer different protein pointer')
# Fresh selected taxonomy statements and lineages, reusing full-cache hash only.
receipt=js(R/'results/taxonomy-query-receipt.json');cache=Path(receipt['cache']);before=cache.stat();ck(before.st_size==receipt['size']==14115225600 and before.st_mtime_ns==receipt['mtime_ns_after'],'taxonomy size mtime continuity');prior=R/'inputs/prior/taxon-review/review-results.json';ck(sha(prior)==receipt['prior_evidence_sha256'],'prior full-cache evidence binding');ck(js(prior)['summary']['taxonomy_cache']==receipt['prior_full_hash_evidence'],'prior full-cache assertion reused exactly');ck(receipt['new_full_rehash'] is False,'no false fresh fullhash claim')
db=sqlite3.connect(cache.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
query=lambda tax:[dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(tax,))]
old=js(R/'inputs/prior/taxon-review/independent-taxonomy-rows.json');selected=js(R/'results/taxonomy-complete-selected-statements.json');lines=js(R/'results/taxonomy-selected-lineages.json')
for tax,rows in old.items():ck(query(tax)==rows,'taxonomy accepted control '+tax)
for tax,rows in selected.items():
 ck(query(tax)==rows,'taxonomy selected full statements '+tax);chain=[];seen=set();cur=tax
 while cur not in seen:
  seen.add(cur);rs=query(cur);parent=[x['object'] for x in rs if x['predicate']=='rdfs:subClassOf'];chain.append({'id':cur,'label':[x['value'] for x in rs if x['predicate']=='rdfs:label'],'rank':[x['object'] for x in rs if x['predicate']=='obo:ncbitaxon#has_rank'],'parent':parent})
  if len(parent)!=1 or parent[0] in seen:break
  cur=parent[0]
 ck(chain==lines[tax],'taxonomy selected lineage '+tax)
db.close();after=cache.stat();ck((before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'cache stat unchanged by readonlyqueries')
taxrows=js(R/'results/taxon-dispositions.json')['native_objects'];ck(len(taxrows)==12 and {t['native_id'] for t in taxrows}=={k for k,e in native.items() if e.tag=='Organism'},'all12 native taxon dispositions')
for t in taxrows:
 e=native[t['native_id']];x=next(x for x in xrefs(e) if x['db']=='NCBI-TAXONOMY-DB');ck('NCBITaxon:'+x['id']==t['issuer_id'],'native taxon pointer '+t['native_id']);rs=selected[t['issuer_id']];ck([x['value'] for x in rs if x['predicate']=='rdfs:label']==[t['issuer_label']] and [x['object'] for x in rs if x['predicate']=='obo:ncbitaxon#has_rank']==[t['issuer_rank']],'issuer taxon label/rank '+t['native_id'])
root=native['METHANOGENESIS-PWY'];ck(set(refs(root,'species'))=={'TAX-2208','TAX-145262','TAX-2179'},'allthree direct taxon associations');ck(refs(root,'taxonomic-range')==['TAX-28890'],'native taxonomic range');ck(lines['NCBITaxon:79929'][0]['parent']==['NCBITaxon:145263'] and lines['NCBITaxon:187420'][0]['parent']==['NCBITaxon:145262'],'Marburg and DeltaH distinct parents')
save('protein-reading-original-projection.json',public);save('activity-independent-contexts.json',actout);save('GeneID-discrepancies.json',genediffs);save('source-and-issuer-binding.json',{'packets':packet_rows,'fresh_receipts':receipts,'reused':reused,'native_objects':177,'readings':readings});save('independent-taxonomy-binding.json',{'full_cache_hash_reused':receipt['prior_full_hash_evidence'],'fresh_full_hash':False,'control_sets':len(old),'selected_sets':len(selected),'selected_statements':selected,'lineages':lines,'size':after.st_size,'mtime_ns':after.st_mtime_ns});save('identity-checks.json',checks);save('identity-result.json',{'checks':len(checks),'packets_physical':sum(x['physical_files'] for x in packet_rows),'fresh_issuer_requests':76,'reused_issuer_originals':6,'proteins':57,'direct_uniprot_pointers':14,'activity_contexts':15,'native_taxa':12,'taxonomy_selected':15,'taxonomy_controls':9,'full_cache_rehashed':False,'result':'bounded original identity/context checks passed'});print(json.dumps(js(P/'identity-result.json'),indent=2))
