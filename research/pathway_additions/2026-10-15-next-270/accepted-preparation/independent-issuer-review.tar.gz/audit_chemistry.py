from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,collections
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors as D
P=Path(__file__).resolve().parent;R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation');checks=[]
def ck(ok,why):
 checks.append(why)
 if not ok:raise AssertionError(why)
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
def obj(f):return next(x for x in E.parse(R/'inputs/native'/('META-'+f+'.xml')).getroot() if x.tag!='metadata')
def props(m):return {'formula':D.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'inchi':Chem.MolToInchi(m),'key':Chem.MolToInchiKey(m),'smiles':Chem.MolToSmiles(m),'centres':Chem.FindMolChiralCenters(m,includeUnassigned=True)}
def equal(a,b,stereo=True):
 a,b=Chem.AddHs(a),Chem.AddHs(b)
 return a.GetNumAtoms()==b.GetNumAtoms() and a.GetNumBonds()==b.GetNumBonds() and a.HasSubstructMatch(b,useChirality=stereo) and b.HasSubstructMatch(a,useChirality=stereo)
root=obj('METHANOGENESIS-PWY');memberids=[x.get('frameid') for x in root.findall('reaction-list/*')];materialids={x.get('frameid') for f in memberids for side in ['left','right'] for s in obj(f).findall(side) for x in s if x.get('frameid')}
ck(len(materialids)==18,'18 native equation material IDs');disps={x['native_id']:x for x in json.loads((R/'results/material-dispositions.json').read_text())};ck(set(disps)==materialids,'exact18 disposition coverage')
rows=[];counts=collections.Counter();native_mols={}
for f in sorted(materialids):
 e=obj(f);generic=e.get('class')=='true';nchi=e.findtext('inchi');cm=e.find('cml/molecule');d={'native':f,'generic':generic,'native_sha256':hashlib.sha256((R/'inputs/native'/('META-'+f+'.xml')).read_bytes()).hexdigest()};ids={z.findtext('dblink-db'):z.findtext('dblink-oid') for z in e.findall('dblink')};ck(disps[f]['direct_chebi_candidates']==(['CHEBI:'+ids['CHEBI']] if 'CHEBI' in ids else []),'own ChEBI pointer '+f);counts['generic' if generic else 'concrete']+=1
 if not generic:
  n=Chem.MolFromInchi(nchi);ck(n is not None,'native InChI import '+f);native_mols[f]=n;d['native']=f;d['native_inchi_graph']=props(n);ck(Chem.MolToInchiKey(n)==e.findtext('inchi-key').removeprefix('InChIKey='),'native key '+f)
  rw=Chem.RWMol();am={}
  for atom in cm.findall('atomArray/atom'):
   a=Chem.Atom(atom.get('elementType').capitalize());a.SetFormalCharge(int(atom.get('formalCharge','0')));am[atom.get('id')]=rw.AddAtom(a)
  for bond in cm.findall('bondArray/bond'):
   u,v=(bond.get('atomRefs2') or bond.get('atomRefs')).split();rw.AddBond(am[u],am[v],{1:Chem.BondType.SINGLE,2:Chem.BondType.DOUBLE,3:Chem.BondType.TRIPLE}[int(bond.get('order'))])
  c=rw.GetMol();Chem.SanitizeMol(c);de=Chem.Mol(n);Chem.RemoveStereochemistry(de)
  parts=cm.find('formula').get('concise').split();expected={k.capitalize():int(v) for k,v in zip(parts[::2],parts[1::2])};got=collections.Counter(a.GetSymbol() for a in Chem.AddHs(c).GetAtoms());ck(dict(got)==expected,'CML declared atoms '+f);ck(Chem.GetFormalCharge(c)==int(cm.get('formalCharge'))==Chem.GetFormalCharge(n),'CML declared charge '+f);ck(D.CalcMolFormula(c)==D.CalcMolFormula(n) and Chem.MolToInchi(c)==Chem.MolToInchi(de),'CML versus native InChI stereo-stripped standard normalization '+f);d['cml_connectivity_only']=props(c)
  if 'CHEBI' in ids:
   j=json.loads((R/'originals'/('ChEBI-'+ids['CHEBI']+'.json')).read_text());u=Chem.MolFromInchi(j['default_structure']['standard_inchi']);ck(u is not None,'direct ChEBI import '+f);eq=equal(n,u);d['direct_chebi']={'accession':j['chebi_accession'],'graph':props(u),'expanded_graph_equal_chiral':eq};ck(eq==(f!='FORMYL-THMPT'),'expected direct ChEBI identity or formyl exception '+f);counts['direct_chebi_exact']+=int(eq)
   if eq:ck((D.CalcMolFormula(n),Chem.GetFormalCharge(n))==(D.CalcMolFormula(u),Chem.GetFormalCharge(u)),'exact ChEBI formula/charge '+f)
  kid=ids.get('LIGAND-CPD');molpath=R/'originals'/('KEGG-'+kid+'.mol');k=Chem.MolFromMolFile(str(molpath),sanitize=True,removeHs=False);ck(k is not None,'KEGG concrete mol import '+f);eq=equal(n,k);normeq=Chem.MolToInchi(n)==Chem.MolToInchi(k);ck(eq==normeq,'KEGG expanded graph versus standard InChI verdict '+f);d['kegg']={'id':kid,'graph':props(k),'expanded_graph_equal_chiral':eq};counts['kegg_exact' if eq else 'kegg_nonidentical']+=1
 else:ck('native generic identity retained' in disps[f]['disposition'],'generic scope not mapped '+f)
 rows.append(d)
ck(counts=={'concrete':12,'generic':6,'direct_chebi_exact':11,'kegg_exact':5,'kegg_nonidentical':7},'expected full material counts')
formyl=native_mols['FORMYL-THMPT'];j=json.loads((R/'originals/ChEBI-58018.json').read_text());f2=Chem.MolFromInchi(j['default_structure']['standard_inchi']);ck((D.CalcMolFormula(formyl),Chem.GetFormalCharge(formyl))==(D.CalcMolFormula(f2),Chem.GetFormalCharge(f2)),'formyl58018 same formula charge');ck(equal(formyl,f2,False) and not equal(formyl,f2,True),'formyl58018 constitution-only comparison');ck('22+' in Chem.MolToInchi(formyl) and '22?' in Chem.MolToInchi(f2),'formyl explicit stereo gap')
issuer=[];smfails=[]
for p in sorted((R/'originals').glob('ChEBI-*.json')):
 j=json.loads(p.read_text());ck(j['chebi_accession']=='CHEBI:'+p.stem.split('-')[1] and j['is_released'],'ChEBI issuing identity '+p.name);s=j.get('default_structure');z={k:j.get(k) for k in ['chebi_accession','name','definition','chemical_data','ontology_relations']}
 if s:
  n=Chem.MolFromInchi(s['standard_inchi']) if s.get('standard_inchi') else None;m=Chem.MolFromSmiles(s['smiles']) if s.get('smiles') else None;z['structure']=s;z['inchi_imported']=n is not None;z['smiles_imported']=m is not None
  if n:ck(Chem.MolToInchiKey(n)==s['standard_inchi_key'],'ChEBI key '+p.name)
  if s.get('smiles') and m is None:smfails.append(j['chebi_accession'])
 issuer.append(z)
direct_ids={x for d in disps.values() for x in d['direct_chebi_candidates']};ck(len(issuer)==23 and len(set(smfails)&direct_ids)==6 and set(smfails)-direct_ids=={'CHEBI:58018','CHEBI:139511'},'six direct-candidate and two additional retained-original SMILES failures')
allmols=[]
for p in sorted((R/'originals').glob('KEGG-*.mol')):
 m=Chem.MolFromMolFile(str(p),sanitize=True,removeHs=False);ck(m is not None,'all KEGG mol original imported '+p.name);allmols.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),**props(m)})
ck(len(allmols)==16,'16 complete KEGG MOL originals');ck(D.CalcMolFormula(Chem.MolFromSmiles(obj('HYDROGEN-MOLECULE').findtext('cml/molecule/string')))== 'H','literal source hydrogen SMILES is H, notH2')
save('chemical-independent-comparisons.json',{'runtime':rdBase.rdkitVersion,'counts':dict(counts),'rows':rows,'formyl58018':{'native':props(formyl),'issuer':props(f2),'interpretation':'Same formula/charge and nonstereo connectivity; exact stereochemical identity not established.'},'CML_scope':'Connectivity and standard normalization after stripping stereo only. No CML coordinate/wedge stereochemistry interpretation.'});save('chebi-original-reading-projection.json',issuer);save('kegg-mol-independent-graphs.json',allmols);save('chemistry-checks.json',checks);save('chemistry-result.json',{'checks':len(checks),'counts':dict(counts),'all_16_kegg_mols_import':True,'issuer_smiles_import_failures':smfails,'result':'bounded molecular/class conclusions supported, stated formyl/generic/ionic limitations required'});print(json.dumps(json.loads((P/'chemistry-result.json').read_text()),indent=2))
