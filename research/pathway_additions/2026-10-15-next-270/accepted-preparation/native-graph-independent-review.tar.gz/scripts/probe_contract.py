"""Synthetic closed-contract probes; these are not scientific source acceptance."""
import copy
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'contracts/src'))
from pathwaymech.schema import validate_record, ValidationError
from pathwaymech.strict import validator, TARGET_CLASS
from pathwaymech.kgx import kgx_nodes, kgx_edges
from pathwaymech.cli import _record_page

def node(local, category):
    return {'id': 'MetaCyc:' + local, 'label': local, 'category': category}

base = {
    'id': 'MetaCyc:SYNTHETIC-REVIEW-ONLY', 'label': 'Synthetic contract probe',
    'description': 'REVIEW_ROOT_SCOPE_SENTINEL', 'pathway_type': 'metabolic',
    'taxa': [], 'participants': [node('ACT', 'molecular_activity'),
        node('ENZ', 'protein'), node('NA', 'small_molecule'),
        node('IN', 'cellular_component'), node('OUT', 'cellular_component'),
        node('COF', 'cofactor')],
    'reactions': [node('RXN', 'molecular_activity')],
    'references': [{'id': 'MetaCyc:SYNTHETIC-SOURCE', 'title': 'Synthetic fixture only'}],
    'mechanistic_edges': [],
}

def edge(subject, predicate, obj):
    return {'id': 'edge', 'subject': 'MetaCyc:' + subject,
            'predicate': predicate, 'object': 'MetaCyc:' + obj,
            'description': 'REVIEW_EDGE_SCOPE_SENTINEL: coefficient 2, occurrence IN to OUT.',
            'evidence': [{'reference_id': 'MetaCyc:SYNTHETIC-SOURCE',
                          'source_assertion': 'Synthetic contract statement only.',
                          'source_locator': 'Synthetic fixture/slot'}]}

checker = validator()
results = []
cases = [
    ('protein enables exact activity participant', edge('ENZ', 'enables', 'ACT'), True),
    ('chemical inhibits exact activity participant', edge('NA', 'inhibits', 'ACT'), True),
    ('protein cofactor', edge('ENZ', 'has_cofactor', 'COF'), True),
    ('activity participant cofactor rejected', edge('ACT', 'has_cofactor', 'COF'), False),
    ('reaction occurs in', edge('RXN', 'occurs_in', 'IN'), True),
    ('activity participant occurs in unsupported', edge('ACT', 'occurs_in', 'IN'), False),
    ('physical global location syntactically valid only', edge('NA', 'located_in', 'IN'), True),
    ('chemical consumes reaction', edge('NA', 'consumes', 'RXN'), True),
    ('reaction produces chemical', edge('RXN', 'produces', 'NA'), True),
    ('chemical consumes participant activity unsupported', edge('NA', 'consumes', 'ACT'), False),
]
for label, e, expected in cases:
    record = copy.deepcopy(base); record['mechanistic_edges'] = [e]
    try:
        validate_record(record); py_errors = []
    except ValidationError as exc:
        py_errors = exc.errors
    closed_errors = [r.message for r in checker.validate(record, TARGET_CLASS).results]
    accepted = not py_errors and not closed_errors
    assert accepted == expected, (label, py_errors, closed_errors)
    results.append({'case': label, 'expected_accepted': expected, 'accepted': accepted,
                    'python_errors': py_errors, 'closed_errors': closed_errors})

record = copy.deepcopy(base)
record['mechanistic_edges'] = [edge('NA', 'consumes', 'RXN')]
for key, value in [('coefficient', 2), ('compartment', 'MetaCyc:IN')]:
    bad = copy.deepcopy(record); bad['mechanistic_edges'][0][key] = value
    errors = [r.message for r in checker.validate(bad, TARGET_CLASS).results]
    assert errors
    results.append({'case': 'top-level edge ' + key + ' field rejected', 'errors': errors})
bad = copy.deepcopy(record); bad['reactions'][0]['description'] = 'Not a NamedNode field'
errors = [r.message for r in checker.validate(bad, TARGET_CLASS).results]
assert errors
results.append({'case': 'NamedNode description rejected', 'errors': errors})
valid = validate_record(record)
nodes = kgx_nodes([valid]); edges = kgx_edges([valid]); page = _record_page(valid)
assert len(nodes) == 8 and len(edges) == 1
assert 'REVIEW_ROOT_SCOPE_SENTINEL' not in json.dumps([n.__dict__ for n in nodes])
assert 'REVIEW_EDGE_SCOPE_SENTINEL' in edges[0].description
assert page.index('REVIEW_ROOT_SCOPE_SENTINEL') < page.index('class="pathway-network')
assert 'REVIEW_EDGE_SCOPE_SENTINEL' in page and 'Synthetic fixture/slot' in page
results.append({'case': 'visible root description and exported incident-edge scope',
                'root_scope_in_KGX': False, 'edge_scope_in_KGX': True,
                'root_scope_before_graph': True, 'all_declared_nodes_exported': True})
(ROOT/'results/contract-probes.json').write_text(json.dumps(results, indent=2)+'\n')
(ROOT/'results/synthetic-contract-probe.html').write_text(page)
print(json.dumps({'cases':len(results), 'all_expected_results':True}))
