"""Independent source-to-design-to-consumer replay. No author script execution."""
import copy
import hashlib
import html
import json
import re
import sys
from collections import Counter
from pathlib import Path
from lxml import etree
from lxml import html as lhtml
import yaml

ROOT=Path(__file__).resolve().parents[1]
DESIGN=Path('/private/tmp/pathwaymech-next-270-native-graph-design')
NATIVE=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation/inputs/native')
sys.path.insert(0,str(ROOT/'contracts/src'))
from pathwaymech.schema import validate_record
from pathwaymech.strict import validator,TARGET_CLASS
from pathwaymech.kgx import kgx_nodes,kgx_edges,render_kgx
from pathwaymech.cli import _record_page

checks=[]
def ck(condition,name):
    assert condition,name
    checks.append(name)
def read(name):return json.loads((DESIGN/'results'/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def curie(frame):return 'MetaCyc:'+frame
def refs(slot):return [c.get('frameid') for c in slot if c.get('frameid')]
def normalized(value):return re.sub(r'<[^>]*>','',html.unescape(value)).strip()
objects={};trees={};paths={}
for path in NATIVE.glob('*.xml'):
    tree=etree.parse(str(path));own=[x for x in tree.getroot() if x.get('detail')=='full'][0]
    fid=own.get('frameid');objects[fid]=own;trees[fid]=tree;paths[fid]=path
root=objects['METHANOGENESIS-PWY']
projection=json.loads((ROOT/'results/independent-native-projection.json').read_text())
nodes=read('proposed-native-node-inventory.json');edges=read('proposed-native-edge-inventory.json')
by_node={x['node']['id']:x for x in nodes};by_edge={x['edge']['id']:x for x in edges}
ck(len(nodes)==len(by_node)==101,'101 unique nodes')
ck(len(edges)==len(by_edge)==125,'125 unique edges')
activity={x['id']:x for x in projection['activities']}
targets={t for r in projection['regulations'] for t in r['target']}
expected_ids={fid for fid,obj in objects.items() if obj.tag in {'Protein','Compound','cco'}}
expected_ids |= targets | set(projection['members']) | {'METHANOGENESIS-PWY'}
ck(set(by_node)=={curie(x) for x in expected_ids},'complete exact biochemical node union')
for row in nodes:
    n=row['node'];fid=n['id'].split(':',1)[1];obj=objects[fid]
    ck(sha(DESIGN/row['source_path'])==sha(paths[fid])==row['source_sha256'],fid+' node source')
    ck(row['native_type']==obj.tag and row['native_class']==(obj.get('class')=='true'),fid+' type/class')
    direct=[normalized(s.text or '') for s in obj.findall('common-name')]
    if direct:
        ck(n['label'] in direct,fid+' direct label')
    elif n['label']==fid:
        ck('frame token' in row['label_rule'],fid+' explicit frame fallback')
    else:
        enzymes=[a for a,v in activity.items() if fid in v['enzymes']]
        ck(len(enzymes)==1,fid+' sole activity naming')
        ck(n['label'] in [normalized(s.text or '') for s in objects[enzymes[0]].findall('common-name')],fid+' exact activity label')
        cs=obj.findall('component');ck(len(cs)==1 and len(refs(cs[0]))==1,fid+' homomer source')
    if obj.tag=='Reaction':
        direction={'REVERSIBLE':'reversible','PHYSIOL-LEFT-TO-RIGHT':'left_to_right'}[obj.findtext('reaction-direction')]
        ck(n['direction']==direction,fid+' reaction direction retained')
    elif row['collection']!='root':
        ck('direction' not in n,fid+' no unsupported node direction')

def bound_slot(binding):
    fid=binding['frame'];obj=objects[fid];slot=obj[binding['one_based_slot']-1]
    ck(sha(DESIGN/binding['path'])==sha(paths[fid])==binding['sha256'],fid+' exact binding')
    ck(slot.tag==binding['slot'],fid+' own slot tag')
    selected=trees[fid].xpath(binding['source_locator'])
    ck(len(selected)==1 and selected[0] is slot,fid+' exact XPath')
    # Parse both serializations: quote/empty-tag style is not source semantics.
    stored=etree.fromstring(binding['source_xml'].encode())
    ck(etree.tostring(stored,method='c14n')==etree.tostring(slot,method='c14n'),fid+' serialized own slot')
    return fid,slot

roles=Counter()
for row in edges:
    edge=row['edge'];eid=edge['id'];roles[row['role']]+=1
    ck(edge['subject'] in by_node and edge['object'] in by_node,eid+' local endpoints')
    ck(edge.get('description') and edge.get('evidence'),eid+' scope/evidence present')
    slots=[bound_slot(b) for b in row['source_slots']]
    bindings={(curie(b['frame']),b['source_locator']) for b in row['source_slots']}
    for e in edge['evidence']:
        ck((e['reference_id'],e['source_locator']) in bindings,eid+' evidence actual source slot')
        ck('source_assertion' in e and 'quote' not in e and len(e['source_assertion'])<=400,eid+' bounded structured assertion')
    role=row['role'];subject=edge['subject'].split(':',1)[1];obj=edge['object'].split(':',1)[1]
    if role=='membership':
        ck(subject=='METHANOGENESIS-PWY' and obj in projection['members'] and edge['predicate']=='has_part',eid+' membership')
    elif role=='ordering':
        ck({'predecessor':subject,'successor':obj} in projection['ordering'] and edge['predicate']=='precedes',eid+' order')
    elif role in {'native_catalyst_association','exact_activity_enable'}:
        aid=next(fid for fid,s in slots if objects[fid].tag=='Enzymatic-Reaction')
        ck(subject in activity[aid]['enzymes'],eid+' exact enzyme')
        ck(obj==(activity[aid]['reactions'][0] if role=='native_catalyst_association' else aid),eid+' exact reaction/activity')
        ck(edge['predicate']==('catalyzes' if role=='native_catalyst_association' else 'enables'),eid+' catalyst predicate')
    elif role=='component':
        matching=[s for fid,s in slots if fid==subject and s.tag=='component' and obj in refs(s)]
        ck(len(matching)==1 and edge['predicate']=='has_part',eid+' exact component')
        coefficient=matching[0].findtext('coefficient')
        if coefficient is None:
            ck('not supplied (not assumed to be 1)' in edge['description'],eid+' absent component coefficient')
            ck('coefficient unspecified' in edge['evidence'][0]['source_assertion'],eid+' absent component evidence')
        else:
            ck('coefficient '+coefficient+'.' in edge['description'],eid+' explicit component coefficient')
    elif role=='cofactor':
        matching=[(fid,s) for fid,s in slots if s.tag=='cofactor' and obj in refs(s)]
        ck(len(matching)==1 and subject in activity[matching[0][0]]['enzymes'],eid+' exact cofactor/enzyme projection')
        ck(edge['predicate']=='has_cofactor' and by_node[curie(obj)]['node']['category']=='cofactor',eid+' cofactor category')
    elif role=='physical_location':
        ck(any(fid==subject and s.tag=='location' and obj in refs(s) for fid,s in slots),eid+' exact physical location')
        ck(objects[subject].tag=='Protein' and edge['predicate']=='located_in',eid+' location is protein not material occurrence')
    elif role=='regulation':
        reg=next(fid for fid,s in slots if objects[fid].tag=='Regulation')
        r=next(r for r in projection['regulations'] if r['id']==reg)
        ck([subject]==r['regulator'] and [obj]==r['target'],eid+' exact regulator/activity')
        ck(edge['predicate']==('activates' if r['mode']==['+'] else 'inhibits'),eid+' exact regulatory sign')

ck(roles==Counter(membership=6,ordering=5,material=30,native_catalyst_association=13,
    exact_activity_enable=5,component=43,cofactor=6,physical_location=10,regulation=7),'all role arithmetic')
materials=read('all30-material-occurrence-design.json')
ck(len(materials)==30,'30 material rows')
seen=set()
for row in materials:
    key=(row['reaction'],row['slot_index']);ck(key not in seen,'unique occurrence '+str(key));seen.add(key)
    p=next(p for p in projection['materials'] if (p['owner'],p['own_slot_index'])==key)
    ck([row['frame']]==p['targets'] and row['source_side']==p['slot'],'material native side '+str(key))
    ck(row['selected_side']==p['pathway_side'],'material orientation '+str(key))
    ck(row['coefficient']==int(p['coefficient'] or 1) and row['coefficient_explicit']==(p['coefficient'] is not None),'material explicit/default coefficient '+str(key))
    ck(([row['compartment']] if row['compartment'] else [])==p['compartment'],'material occurrence compartment '+str(key))
    e=by_edge[row['edge_id']]['edge'];input_=p['pathway_side']=='input'
    ck((e['subject'],e['object'],e['predicate'])==
       ((curie(row['frame']),curie(row['reaction']),'consumes') if input_ else
        (curie(row['reaction']),curie(row['frame']),'produces')),'material edge endpoints '+str(key))
    ck('coefficient '+str(row['coefficient'])+';' in e['description'],'quantity retained in description '+str(key))
    compartment=row['compartment'] or 'unspecified (unlocated; not assumed cytosol or CCO-IN)'
    ck('compartment '+compartment+'.' in e['description'],'compartment retained in description '+str(key))
ck(Counter(x['compartment'] for x in materials)==Counter({None:24,'CCO-IN':5,'CCO-OUT':1}),'6 located/24 unlocated occurrences')
ck(not any(e['edge']['predicate']=='located_in' and e['edge']['subject']==curie('NA+') for e in edges),'no global sodium location')

allslots=read('all2061-own-slot-design-dispositions.json')
expected={(fid,i,s.tag) for fid,obj in objects.items() for i,s in enumerate(obj,1)}
ck(len(allslots)==len(expected)==2061,'2061 complete own slots')
ck({(r['frame'],r['one_based_slot'],r['tag']) for r in allslots}==expected,'all own slot identities')
for r in allslots:
    ck(bool(r['disposition']),'nonempty slot disposition')
    for eid in r['edge_ids']:
        ck(any(b['frame']==r['frame'] and b['one_based_slot']==r['one_based_slot'] for b in by_edge[eid]['source_slots']),'reverse own slot edge binding')
objectrows=read('all177-native-object-dispositions.json')
ck(len(objectrows)==177 and {r['frame'] for r in objectrows}==set(objects),'177 object coverage')
for r in objectrows:ck(r['proposed_graph_node']==(curie(r['frame']) in by_node) and bool(r['reason']),'object disposition '+r['frame'])

claims=read('all20-claim-design-dispositions.json')
accepted=json.loads(Path('/private/tmp/pathwaymech-next-270-source-locator-correction/after/claim-dispositions.json').read_text())
ck(len(claims)==len(accepted)==20,'20 claims')
for row,old in zip(claims,accepted):
    ck(all(row[k]==v for k,v in old.items()),row['id']+' entire accepted claim preserved')
    ck(row['root_description_required'] and bool(row['design_edge_ids']),row['id']+' explicit placement obligation')
    ck(all(eid in by_edge for eid in row['design_edge_ids']),row['id']+' incident edges resolve')
activities=read('all15-activity-design-dispositions.json')
ck(len(activities)==15 and {r['activity'] for r in activities}==set(activity),'15 activity coverage')
for a in activities:
    own=activity[a['activity']]
    ck(own['enzymes']==[a['enzyme']] and own['reactions']==[a['reaction']],'activity original relation '+a['activity'])
    ck(own['directions']==([a['native_direction']] if a['native_direction'] else []),'activity original direction '+a['activity'])
    ck(bool(a['proposed_edge_ids']) and all(e in by_edge for e in a['proposed_edge_ids']),'activity graph disposition '+a['activity'])
ck({a['activity'] for a in activities if not a['direct_selected_reaction_catalyst']}=={'ENZRXN-662','ENZRXN-4121'},'both opposing Mch activities retained contextually')

record=yaml.safe_load((DESIGN/'results/native-biochemical-probe.yaml').read_text())
valid=validate_record(record);closed=validator().validate(record,TARGET_CLASS)
ck(not closed.results,'copied current Python/closed consumer')
ck(record['taxa']==[],'probe explicitly remains taxon-incomplete')
ck(record['mechanistic_edges']==[r['edge'] for r in edges],'probe exact edge inventory')
kn=kgx_nodes([valid]);ke=kgx_edges([valid]);page=_record_page(valid)
ck(len(kn)==101 and len(ke)==125,'current KGX cardinality')
for raw,exported in zip(record['mechanistic_edges'],ke):
    ck(exported.description==raw['description'] and json.loads(exported.evidence)==raw['evidence'],'full KGX evidence '+raw['id'])
tree=lhtml.fromstring(page)
ck(len(tree.xpath('//*[@data-node-id]'))==101,'current graph every node')
ck(len(tree.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," graph-edge ")]'))==125,'current graph every directed edge')
for i,e in enumerate(record['mechanistic_edges'],1):
    elements=tree.xpath('//*[@id="mechanism-edge-'+str(i)+'"]')
    ck(len(elements)==1 and e['description'] in elements[0].text_content(),'no-JS complete edge description '+e['id'])
    for evidence in e['evidence']:ck(evidence['source_assertion'] in elements[0].text_content(),'no-JS evidence '+e['id'])
for name,content in render_kgx([valid]).items():(ROOT/'results'/('independent-'+name)).write_text(content)
(ROOT/'results/independent-design-page.html').write_text(page)
(ROOT/'results/design-replay.json').write_text(json.dumps({'checks':len(checks),'all_passed':True,'check_names':checks,'roles':roles},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':True,'roles':roles}))
