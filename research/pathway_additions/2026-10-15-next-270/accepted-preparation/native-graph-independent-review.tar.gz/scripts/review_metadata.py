"""Fresh metadata/authority/reference/issuer-scope and adversarial design checks."""
import copy
import hashlib
import json
from pathlib import Path
from lxml import etree

ROOT=Path(__file__).resolve().parents[1]
D=Path('/private/tmp/pathwaymech-next-270-native-graph-design')
def read(name):return json.loads((D/'results'/name).read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
checks=[]
def ck(test,label):
    assert test,label
    checks.append(label)

contracts=read('input-binding.json')['contracts']
for r in contracts:
    local=ROOT/'contracts'/r['path']
    if local.exists():ck(sha(local)==r['sha256'],'design/current published contract '+r['path'])
references=read('proposed-native-reference-inventory.json')
input_files=[p for p in (D/'inputs').rglob('*') if p.is_file()]
ck(len(references)==len({r['reference']['id'] for r in references})==131,'131 unique native references')
for row in references:
    ref=row['reference'];fid=ref['id'].split(':',1)[1]
    path=D/row['source_path'];tree=etree.parse(str(path))
    ck(sha(path)==ref['source_sha256'],'reference original '+fid)
    ck(tree.getroot().get('{http://www.w3.org/XML/1998/namespace}base')==row['literal_xml_base_preserved'],'literal XML base unchanged '+fid)
    ck(ref['url'].startswith('https://') and ':443' not in ref['url'],'HTTPS navigation '+fid)
    bindings=row['receipt_bindings'];ck(bool(bindings),'reference receipt present '+fid)
    found=False
    for receipt in bindings:
        if 'receipt' in receipt and isinstance(receipt['receipt'],dict):
            obj=receipt['receipt'];ck(sha(D/receipt['path'])==receipt['sha256'],'reuse receipt '+fid)
            found |= obj.get('original_url')==ref['url'] and obj['row']['sha256']==ref['source_sha256']
        elif 'receipt' not in receipt:
            ck(sha(D/receipt['path'])==receipt['sha256'],'preflight receipt '+fid)
            obj=json.loads((D/receipt['path']).read_text())
            found |= obj.get('status')==200 and obj['sha256']==ref['source_sha256'] and ref['url'] in {obj['url'],obj.get('final_url')}
        else:
            candidates=[p for p in input_files if str(p).endswith(receipt['receipt'])]
            matched=[p for p in candidates if sha(p)==receipt['receipt_sha256']]
            ck(bool(matched),'bound acquisition receipt '+fid)
            found |= receipt.get('status')==200 and not receipt.get('error') and receipt['sha256']==ref['source_sha256'] and ref['url'] in {receipt['url'],receipt.get('final_url')}
    ck(found,'actual successful acquisition or exact reused URL '+fid)

nodes=read('proposed-native-node-inventory.json');by_node={r['node']['id']:r for r in nodes}
authority=read('native-authority-requirements.json')
snapshot=json.loads((D/'inputs/contracts/data/identifier_authorities/sources.json').read_text())
terms=snapshot.get('terms',snapshot)
ck(len(authority)==101,'all graph authority requirements')
existing=0
for a in authority:
    n=by_node[a['id']]['node']
    category='pathway' if by_node[a['id']]['collection']=='root' else n.get('category')
    ck(a['proposed_label']==n['label'] and a['proposed_category']==category,'authority proposed label/category '+a['id'])
    if a['existing_snapshot_term'] is not None:
        existing+=1
        ck(terms[a['id']]==a['existing_snapshot_term'] and not a['needs_new_authority_support'],'existing exact authority owner '+a['id'])
        ck(a['proposed_label']==a['existing_snapshot_term']['label'],'existing canonical label preserved '+a['id'])
    else:ck(a['id'] not in terms and a['needs_new_authority_support'],'bounded missing term in exact snapshot '+a['id'])
ck(existing==9,'nine existing owners and92 additions')

impact=read('issuer-constraint-impact-ledger.json')
ck(len(impact['rows'])==108,'108 issuer impacts')
ledger_counts={}; seen=set()
for row in impact['rows']:
    p=D/row['issuer_ledger'];ck(sha(p)==row['issuer_ledger_sha256'],'issuer source ledger '+row['native_id'])
    parsed=json.loads(p.read_text());parsed=parsed if isinstance(parsed,list) else parsed['native_objects']
    ck(row['author_disposition'] in parsed,'unchanged complete issuer disposition '+row['native_id'])
    key=(str(p),row['native_id']);ck(key not in seen,'unique issuer impact '+str(key));seen.add(key)
    ledger_counts[p.name]=ledger_counts.get(p.name,0)+1
    if p.name=='taxon-dispositions.json':
        ck('Direct three source taxa remain obligatory' in row['design_decision'] and
           'Catalyst contexts do not enlarge pathway taxa' in row['design_decision'],
           'direct/context taxon boundary '+row['native_id'])
    else:ck('No public alias' in row['design_decision'],'native identity retained '+row['native_id'])
ck(sorted(ledger_counts.values())==[6,12,15,18,57],'all five issuer categories complete')

edges=read('proposed-native-edge-inventory.json');by_edge={r['edge']['id']:r for r in edges}
materials=read('all30-material-occurrence-design.json')
def exact_occurrences(rows):
    return sorted((r['reaction'],r['slot_index'],r['frame'],r['source_side'],r['selected_side'],r['coefficient'],r['coefficient_explicit'],r['compartment']) for r in rows)
expected=exact_occurrences(materials)
mutations=[]
for name,operation in [
    ('delete sodium output',lambda r:r.pop(next(i for i,x in enumerate(r) if x['frame']=='NA+' and x['selected_side']=='output'))),
    ('sodium coefficient2 to1',lambda r:next(x for x in r if x['frame']=='NA+').__setitem__('coefficient',1)),
    ('sodium outside to inside',lambda r:next(x for x in r if x['frame']=='NA+' and x['selected_side']=='output').__setitem__('compartment','CCO-IN')),
    ('unlocated carrier to inside',lambda r:next(x for x in r if x['frame']=='THMPT' and x['compartment'] is None).__setitem__('compartment','CCO-IN')),
    ('Mch direction repair',lambda r:next(x for x in r if x['reaction']=='3.5.4.27-RXN').__setitem__('selected_side','input')),
    ('generic ferredoxin substitution',lambda r:next(x for x in r if x['frame']=='Reduced-ferredoxins').__setitem__('frame','Reduced-Ferredoxin-2Fe2S')),
]:
    changed=copy.deepcopy(materials);operation(changed);rejected=exact_occurrences(changed)!=expected
    ck(rejected,'adversarial original replay rejects '+name);mutations.append({'case':name,'rejected_by_source_replay':rejected})
for r in edges:
    if r['role']=='regulation':
        ck(r['edge']['object'].startswith('MetaCyc:ENZRXN'),'no regulatory generic reaction flattening')
for eid in ['native-ne107','native-ne108']:
    e=by_edge[eid]['edge']
    ck('Unresolved native conflict' in e['description'] and {i['reference_id'] for i in e['evidence']}=={'MetaCyc:ENZRXN-702','MetaCyc:CPLX-643'},'Mtr opposing evidence on '+eid)
ck('O28206' in by_edge['native-ne058']['edge']['description'] and 'not independent confirmation' in by_edge['native-ne058']['edge']['description'],'formyltransferase-like limitation retained')
ck('five residue differences' in by_edge['native-ne051']['edge']['description'],'Mer mixed identity retained')

result={'checks':len(checks),'all_passed':True,'check_names':checks,'issuer_counts':ledger_counts,'adversarial_cases':mutations,
        'limits':'The existing-authority lookup is finite exact-snapshot scope; no global absence claim. Public terms and a final record were not approved.'}
(ROOT/'results/metadata-replay.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['check_names','adversarial_cases']}))
