"""Fresh native-original projection for design comparison, not primary reacceptance."""
import hashlib
import json
from pathlib import Path
from lxml import etree

ROOT=Path(__file__).resolve().parents[1]
NATIVE=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation/inputs/native')
objects={}
bindings=[]
for path in sorted(NATIVE.glob('*.xml')):
    tree=etree.parse(str(path)); full=[x for x in tree.getroot() if x.get('detail')=='full']
    assert len(full)==1,path
    node=full[0]; assert node.get('frameid') not in objects
    objects[node.get('frameid')]=node
    bindings.append({'frameid':node.get('frameid'),'kind':node.tag,'path':str(path),
                     'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert len(objects)==177
def refs(node): return [x.get('frameid') for x in node if x.get('frameid')]
def vals(node,tag): return [(x.text or '').strip() for x in node.findall(tag)]
def located(owner, slot, index):
    return {'owner':owner,'slot':slot.tag,'own_slot_index':index,
            'targets':refs(slot),'coefficient':slot.findtext('coefficient'),
            'compartment':slot.xpath('./compartment/*/@frameid'),
            'comment':vals(slot,'comment')}

root=objects['METHANOGENESIS-PWY']
members=[x.get('frameid') for s in root.findall('reaction-list') for x in s]
assert len(members)==len(set(members))==6
directions={s[0].get('frameid'):s.findtext('direction') for s in root.findall('reaction-layout')}
ordering=[{'predecessor':p.get('frameid'),'successor':s[0].get('frameid')}
          for s in root.findall('reaction-ordering') for p in s.findall('./predecessor-reactions/Reaction')]
materials=[]
for rid in members:
    for i,s in enumerate(objects[rid],1):
        if s.tag not in {'left','right'}:continue
        row=located(rid,s,i)
        assert len(row['targets'])==1
        row['pathway_side']='input' if (s.tag=='left')==(directions[rid]=='L2R') else 'output'
        row['pathway_direction']=directions[rid]
        materials.append(row)
components=[]; cofactors=[]; locations=[]; activities=[]; regulations=[]
for fid,obj in objects.items():
    for i,s in enumerate(obj,1):
        if obj.tag=='Protein' and s.tag=='component':components.append(located(fid,s,i))
        if s.tag=='cofactor':cofactors.append(located(fid,s,i))
        if s.tag=='location':locations.append(located(fid,s,i))
    if obj.tag=='Enzymatic-Reaction':
        activities.append({'id':fid,'enzymes':[v for s in obj.findall('enzyme') for v in refs(s)],
                           'reactions':[v for s in obj.findall('reaction') for v in refs(s)],
                           'directions':vals(obj,'reaction-direction'),
                           'own_evidence':vals(obj,'evidence')})
    if obj.tag=='Regulation' and obj.get('class')!='true':
        regulations.append({'id':fid,'regulator':[v for s in obj.findall('regulator') for v in refs(s)],
                            'target':[v for s in obj.findall('regulated-entity') for v in refs(s)],
                            'mode':vals(obj,'mode')})
result={'bindings':bindings,'members':members,'ordering':ordering,'materials':materials,
        'components':components,'cofactors':cofactors,'locations':locations,
        'activities':activities,'regulations':regulations,
        'direct_taxa':[v for s in root.findall('species') for v in refs(s)],
        'taxonomic_range':[v for s in root.findall('taxonomic-range') for v in refs(s)]}
assert len(materials)==30 and len(components)==43 and len(activities)==15 and len(regulations)==7
assert len(ordering)==5
(ROOT/'results/independent-native-projection.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:len(v) for k,v in result.items()})
