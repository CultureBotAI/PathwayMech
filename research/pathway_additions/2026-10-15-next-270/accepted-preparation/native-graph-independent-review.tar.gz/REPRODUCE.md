# Safe independent review reproduction

Copy this review to a new, absent scratch owner before running its scripts; never execute writers in this frozen owner. Keep the exact frozen input owners listed in `input-owners.json` available. No live269 worktree, network, new installation or runtime repair is needed.

Use `PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B` for each command:

1. `scripts/intake.py fresh-input-check.json` verifies all nine input owners and writes a new named receipt under the copied owner's results directory.
2. `scripts/source_projection.py` reconstructs the native original projection.
3. `scripts/probe_contract.py` exercises the fourteen synthetic contract cases.
4. `scripts/review_design.py` replays source completeness, all edge bindings, claims and actual current consumers.
5. `scripts/review_metadata.py` checks reference receipts, finite authority scope, all issuer dispositions and six adversarial occurrence controls.

All output roots derive from each script's own parent. Original packets are read-only. These independent scripts do not invoke the designer's builder or accept a maintained record. The retained earlier `.txt` script versions and failed logs document reviewer-harness mistakes and are not current reproduction commands.
