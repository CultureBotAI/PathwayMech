from pathlib import Path
from collections import Counter
import copy, csv, hashlib, html, io, json, sys, xml.etree.ElementTree as ET
import yaml
from html.parser import HTMLParser
from jsonschema import Draft7Validator
from linkml.generators.jsonschemagen import JsonSchemaGenerator

O=Path(__file__).resolve().parents[1];R=O/'results';S=O/'inputs/source-preparation'
sys.path.insert(0,str(O/'inputs/contracts/src'))
from pathwaymech.schema import validate_record
from pathwaymech.kgx import render_kgx
from pathwaymech.graph_view import graph_html
checks=[]
def check(value,label):
    checks.append({'check':label,'passed':bool(value)})
    if not value:raise AssertionError(label)
def read(p):return json.loads(p.read_text())
nodes=read(R/'proposed-native-node-inventory.json');edges=read(R/'proposed-native-edge-inventory.json')
objects={}
for row in read(S/'results/native-object-inventory.json'):
    raw=(S/row['path']).read_bytes();check(hashlib.sha256(raw).hexdigest()==row['sha256'],'original '+row['frame'])
    objects[row['frame']]=ET.fromstring(raw).find(row['type'])
for e in edges:
    for source in e['source_slots']:
        slot=list(objects[source['frame']])[source['one_based_slot']-1]
        check(slot.tag==source['slot'],'slot tag '+e['edge']['id'])
        check(ET.tostring(slot,encoding='unicode')==source['source_xml'],'slot XML '+e['edge']['id'])
    check(all(len(x['source_assertion'])<=400 and x['source_locator'] for x in e['edge']['evidence']),'bounded evidence '+e['edge']['id'])
material=[e for e in edges if e['role']=='material']
observed=[]
for e in material:
    src=e['source_slots'][0];slot=list(objects[src['frame']])[src['one_based_slot']-1]
    term=next(x for x in slot if x.tag in {'Compound','Protein'})
    cf=slot.findtext('coefficient');comp=slot.find('compartment');compid=next(iter(comp)).get('frameid') if comp is not None else None
    check(e['coefficient']==(int(cf) if cf is not None else 1),'coefficient '+e['edge']['id'])
    check(e['compartment']==compid,'compartment '+e['edge']['id'])
    lay=e['source_slots'][1];ls=list(objects[lay['frame']])[lay['one_based_slot']-1]
    orientation=ls.findtext('direction');incoming=(slot.tag=='left')==(orientation=='L2R')
    check(e['edge']['predicate']==('consumes' if incoming else 'produces'),'selected predicate '+e['edge']['id'])
    check(e['edge']['subject']=='MetaCyc:'+(term.get('frameid') if incoming else src['frame']),'selected subject '+e['edge']['id'])
    check(e['edge']['object']=='MetaCyc:'+(src['frame'] if incoming else term.get('frameid')),'selected object '+e['edge']['id'])
    check(f'coefficient {e["coefficient"]}' in e['edge']['description'],'visible coefficient '+e['edge']['id'])
    observed.append((src['frame'],src['one_based_slot']))
expected=[(f,i) for f in [x['node']['id'].split(':',1)[1] for x in nodes if x['collection']=='reactions'] for i,s in enumerate(objects[f],1) if s.tag in {'left','right'}]
check(Counter(expected)==Counter(observed) and len(observed)==30,'all30 source terms exactly once')
na=[e for e in material if 'MetaCyc:NA+' in {e['edge']['subject'],e['edge']['object']}]
check(sorted((e['coefficient'],e['compartment'],e['edge']['predicate']) for e in na)==[(2,'CCO-IN','consumes'),(2,'CCO-OUT','produces')],'exact 2 Na inside to outside')
check(sum(e['compartment'] is not None for e in material)==6,'six located material occurrences only')
check(not any(e['edge']['predicate']=='located_in' and e['edge']['subject']=='MetaCyc:NA+' for e in edges),'no global sodium location')
for e in [e for e in edges if e['role']=='component']:
    slot=list(objects[e['source_slots'][0]['frame']])[e['source_slots'][0]['one_based_slot']-1]
    check(slot.findtext('coefficient')==e['coefficient_literal'],'component literal coefficient '+e['edge']['id'])
    check('MetaCyc:'+slot.find('Protein').get('frameid')==e['edge']['object'],'component exact ID '+e['edge']['id'])
for e in [e for e in edges if e['role']=='regulation']:
    n=objects[e['regulation']]
    check(e['edge']['subject']=='MetaCyc:'+n.find('regulator')[0].get('frameid'),'regulator '+e['edge']['id'])
    check(e['edge']['object']=='MetaCyc:'+n.find('regulated-entity')[0].get('frameid'),'exact activity '+e['edge']['id'])
    check(e['edge']['predicate']=={'+':'activates','-':'inhibits'}[n.findtext('mode')],'regulatory mode '+e['edge']['id'])
act=read(R/'all15-activity-design-dispositions.json')
check(len(act)==15 and sum(a['direct_selected_reaction_catalyst'] for a in act)==13,'all15 activities /13 nonopposed catalyst assertions')
for a in act:
    check(a['proposed_edge_ids'],'every activity has concrete representation '+a['activity'])
    if a['activity'] in {'ENZRXN-4121','ENZRXN-662'}:
        check(not a['direct_selected_reaction_catalyst'] and a['proposed_activity_node'],'opposing hydrolysis separate '+a['activity'])
check(len(read(R/'all20-claim-design-dispositions.json'))==20,'all20 accepted corrected claims')
check(read(R/'all20-claim-design-dispositions.json')[14]['primary_scope'][0].startswith('Kurth2021 main Methods PDF pp.6–7'),'corrected S15 locator retained')
check(len(read(R/'all2061-own-slot-design-dispositions.json'))==2061,'complete own-slot disposition ledger')
check(len(read(R/'all177-native-object-dispositions.json'))==177,'complete object disposition ledger')
direct=[x for x in read(R/'all12-native-taxon-design-dispositions.json') if x['proposed_record_role'].startswith('direct taxon')]
check({(x['frame'],x['rank']) for x in direct}=={('TAX-2208','species'),('TAX-145262','species'),('TAX-2179','genus')},'all three direct ranks preserved')

root=next(n['node'] for n in nodes if n['collection']=='root')
prototype={**root,'description':'SCRATCH BIOCHEMICAL DESIGN PROBE ONLY. No maintained record or authority/taxon acceptance. Three native direct taxa await separate issuer closure. Six source members end at methyl-CoM; METHFORM is boundary-only. '+ ' '.join(x['text'] for x in read(R/'required-narrative-fragments.json')),
 'pathway_type':'methanogenesis','taxa':[],
 'participants':[n['node'] for n in nodes if n['collection']=='participants'],
 'reactions':[n['node'] for n in nodes if n['collection']=='reactions'],
 'mechanistic_edges':[e['edge'] for e in edges],
 'references':[r['reference'] for r in read(R/'proposed-native-reference-inventory.json')]}
record=validate_record(prototype);check(True,'actual copied Python schema accepts biochemical design projection')
generator=JsonSchemaGenerator(str(O/'inputs/contracts/src/pathwaymech/schema/pathwaymech.yaml'),top_class='PathwayRecord',not_closed=False,include_null=False)
schema=json.loads(generator.serialize());validator=Draft7Validator(schema)
errors=list(validator.iter_errors(prototype));check(not errors,'closed schema accepts design probe '+str([e.message for e in errors]))
negative=[]
for field,value in [('coefficient',2),('compartment','MetaCyc:CCO-IN')]:
    wrong=copy.deepcopy(prototype);wrong['mechanistic_edges'][11][field]=value
    errs=list(validator.iter_errors(wrong));check(bool(errs),'closed schema rejects top-level '+field)
    negative.append({'mutation':f'top-level edge {field}','errors':[e.message for e in errs]})
wrong=copy.deepcopy(prototype);wrong['participants'][0]['description']='extra scope'
errs=list(validator.iter_errors(wrong));check(bool(errs),'closed NamedNode rejects description')
negative.append({'mutation':'NamedNode description','errors':[e.message for e in errs]})
(R/'native-biochemical-probe.yaml').write_text(yaml.safe_dump(prototype,sort_keys=False,allow_unicode=True))
(R/'closed-schema-gap-probes.json').write_text(json.dumps(negative,indent=2)+'\n')
exports=render_kgx([record])
for name,body in exports.items():(R/name).write_text(body)
tsv=next(body for name,body in exports.items() if 'edge' in name)
rows=list(csv.DictReader(io.StringIO(tsv),delimiter='\t'));check(len(rows)==125,'125 KGX edges retained')
for edge,row in zip(prototype['mechanistic_edges'],rows):
    check(row['subject']==edge['subject'] and row['object']==edge['object'],'KGX endpoints '+edge['id'])
    check(row['description']==edge['description'],'KGX full description '+edge['id'])
    check(json.loads(row['evidence'])==edge['evidence'],'KGX exact evidence '+edge['id'])
node_tsv=next(body for name,body in exports.items() if 'node' in name)
node_rows=list(csv.DictReader(io.StringIO(node_tsv),delimiter='\t'));check(len(node_rows)==101,'101 KGX nodes retained including isolated compartments')
labels={n['node']['id']:n['node']['label'] for n in nodes};anchors={id:f'node-{i}' for i,id in enumerate(labels)}
graph=graph_html(record,labels,anchors)
class Tags(HTMLParser):
    def __init__(self):super().__init__();self.tags=[]
    def handle_starttag(self,tag,attrs):self.tags.append((tag,dict(attrs)))
parsed=Tags();parsed.feed(graph)
svg_edges=[a for tag,a in parsed.tags if 'graph-edge' in a.get('class','').split() and 'data-subject' in a]
svg_nodes=[a for tag,a in parsed.tags if 'graph-node' in a.get('class','').split() and 'data-node-id' in a]
check(len(svg_edges)==125,'125 rendered SVG edges')
check(len(svg_nodes)==101,'101 rendered native SVG nodes')
details=''.join(f'<section id="{anchors[n["node"]["id"]]}"><h3>{html.escape(n["node"]["label"])}</h3><p>{html.escape(n["node"]["id"])}</p></section>' for n in nodes)
details+=''.join(f'<section id="mechanism-edge-{i}"><h3>{html.escape(e["id"])}</h3><p>{html.escape(e["description"])}</p><pre>{html.escape(json.dumps(e["evidence"],ensure_ascii=False,indent=2))}</pre></section>' for i,e in enumerate(prototype['mechanistic_edges'],1))
all_tags=Tags();all_tags.feed(graph+details)
targets={a['id'] for _,a in all_tags.tags if 'id' in a}
check(all(a['href'][1:] in targets for _,a in all_tags.tags if a.get('href','').startswith('#')),'all scratch preview local links resolve')
(R/'native-design-preview.html').write_text('<!doctype html><html><head><meta charset="utf-8"><title>Native design probe, not a curated record</title></head><body><h1>Scratch native design probe</h1><p>'+html.escape(prototype['description'])+'</p>'+graph+details+'</body></html>')
(R/'design-checks.json').write_text(json.dumps({'passed':all(c['passed'] for c in checks),'checks':checks,'count':len(checks),'scope':'Author structural/source/projection checks only. Empty probe taxa do not accept omission: all three direct taxa remain pending issuing closure. No authority consumer, full corpus, independent science or pixel/browser acceptance.'},indent=2)+'\n')
print(json.dumps({'passed':True,'checks':len(checks),'native_nodes':101,'edges':125,'pending_direct_taxa':3}))
