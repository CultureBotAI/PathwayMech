from pathlib import Path
from collections import Counter, defaultdict
import datetime, hashlib, html, json, re, xml.etree.ElementTree as ET
import yaml

O = Path(__file__).resolve().parents[1]
S = O/'inputs/source-preparation'
R = O/'results'
def read(p): return json.loads(p.read_text())
def save(name, obj): (R/name).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n')
def sha(b): return hashlib.sha256(b).hexdigest()
def plain(s): return html.unescape(re.sub(r'<[^>]*>', '', s or '')).strip()
def curie(frame): return 'MetaCyc:'+frame
inventory = read(S/'results/native-object-inventory.json')
originals = {x['frame']:x for x in inventory}
objects = {}
for row in inventory:
    p = S/row['path']; raw = p.read_bytes()
    assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
    root = ET.fromstring(raw)
    candidates = [n for n in root if n.tag==row['type'] and n.get('frameid')==row['frame']]
    assert len(candidates)==1
    n = candidates[0]; assert n.get('detail')=='full' and n.get('orgid')=='META'
    assert n.get('ID')=='META:'+row['frame']
    objects[row['frame']] = n

def source(frame, index):
    row=originals[frame]; n=objects[frame]; c=list(n)[index-1]
    return {'frame':frame,'type':row['type'],'path':'inputs/source-preparation/'+row['path'],
            'sha256':row['sha256'],'one_based_slot':index,'slot':c.tag,
            'source_locator':f"/ptools-xml/{row['type']}[@frameid='{frame}']/*[{index}][self::{c.tag}]",
            'source_xml':ET.tostring(c,encoding='unicode')}
def slots(frame, tag): return [(i,c) for i,c in enumerate(objects[frame],1) if c.tag==tag]
def selected_sources(frame,tags): return [source(frame,i) for i,c in enumerate(objects[frame],1) if c.tag in tags]
def source_ev(s, assertion):
    assert len(assertion)<=400,assertion
    return {'reference_id':curie(s['frame']),'source_assertion':assertion,'source_locator':s['source_locator']}

root_frame='METHANOGENESIS-PWY'
order=['FORMYLMETHANOFURAN-DEHYDROGENASE-RXN','2.3.1.101-RXN','3.5.4.27-RXN','H2-METHYLENE-THMPT-DEHYDRO-RXN','METHELENE-THMPT-OXI-RXN','2.1.1.86-RXN']
equations={x['frame']:x for x in read(S/'results/member-equations.json')}
activities=read(S/'results/activity-dispositions.json')
activity_by_id={a['activity']:a for a in activities}
regulations=read(S/'results/regulation-ledger.json')
regulated={x['target_activity'] for x in regulations}
assert regulated=={'ENZRXN-422','ENZRXN-641','ENZRXN-4121','ENZRXN-662','ENZRXN-702'}
opposed={'ENZRXN-4121','ENZRXN-662'}
components=read(S/'results/complex-components.json')
cofactor_frames={c[0].get('frameid') for a in activities for _,c in slots(a['activity'],'cofactor')}
claims=read(O/'inputs/locator-successor/after/claim-dispositions.json')
assert sha((O/'inputs/locator-successor/after/claim-dispositions.json').read_bytes())=='08730dcd80abda474f8fa5dc3bdd3ad2d9edb21e79f94a7b278001ef183fac2b'

taxon_context='Direct source pathway associations are TAX-2208 (species), TAX-145262 (species) and TAX-2179 (genus); TAX-28890 is a separate phylum range. These are not all-member experiments. Current issuer reconciliation is pending.'
reaction_context={
 order[0]:'The selected R2L equation reduces CO2 using generic methanofuran and ferredoxin classes. No specific carrier sequence, complete molecular balance or observed carbamate intermediate is asserted.',
 order[1]:'Selected L2R formyl transfer. Material terms are unlocated; their shared carrier IDs do not silently equate them with Mtr CCO-IN occurrences.',
 order[2]:'Root layout selects R2L dehydration, but ENZRXN-662 and ENZRXN-4121 both state physiological L2R hydrolysis. The source reaction remains reversible; neither opposing activity is asserted as catalyzing the selected route direction.',
 order[3]:'The native fourth member is Hmd/H2, not the F420-dependent Mtd alternative. H2 native SMILES [H] conflicts with formula/InChI H2. Historical Hmd Ni/FeS/flavin statements do not establish absence of iron cofactor.',
 order[4]:'Selected R2L reduction uses generic F420 classes. Historical Marburg versus species/delta-H protein pointers remain unresolved; no exact strain or sequence substitution is made.',
 order[5]:'Native Mtr specifies two Na+ from CCO-IN to CCO-OUT; CoM, methyl-THMPT, Me-CoM and THMPT occurrences are CCO-IN. Other reactions have unlocated terms. This source stoichiometry is not a fresh purified Mtr assay. Me-CoM is the endpoint; METHFORM-PWY is downstream boundary only.'}
def activity_context(a):
    s=f"Native activity {a['activity']} refers to reaction {a['reaction']} and enzyme {a['enzyme']}; source organism(s) {', '.join(a['source_species'])}. Native activity direction: {a['native_direction'] or 'unspecified'}. {a['disposition']}. "
    if a['activity'] in opposed: s+='This L2R activity conflicts with root R2L dehydration; it is retained as an activity-specific source assertion, not a catalyst assertion for selected dehydration. '
    if a['activity'].startswith('ENZRXN26TB'): s+='Archaeoglobus fulgidus DSM 4304 shared C1 annotations do not establish methanogenesis or the six-member route. '
    if a['activity']=='ENZRXN26TB-75':s+='The frozen issuer preparation reports AF_RS10430/O28206 as formyltransferase-like with family/similarity support only, distinct from O28076; independent issuer acceptance is pending. This native catalog catalysis edge is not independent confirmation of catalytic function. '
    if a['activity']=='ENZRXN-4121':s+='Methylorubrum extorquens AM1 bacterial C1 metabolism is not methane formation. '
    if a['activity']=='ENZRXN2065-393':s+='EV-EXP-IPI remains native metadata. Kurth2021 studied Mto and expression, not a purified Mtr sodium-pumping assay; MtoA BP07_RS03240 differs from MtrH BP07_RS06315. '
    if 'TAX-145262' in a['source_species']:s+='Historical Marburg/species/delta-H pointers are not resolved to one exact strain or sequence. '
    if a['activity']=='ENZRXN-701':s+='Provisional frozen issuer analysis reports G-356/X86477/CAA60203.1 matching Q50744 Marburg while the native O27784 pointer is Delta H with five residue differences. Independent issuer acceptance is pending; neither accession is substituted. '
    return s+'Native evidence codes remain database assertions; cited papers are not automatically read assays.'

nodes=[]
node_dispositions=[]
included=set()
for row in inventory:
    f=row['frame'];typ=row['type'];n=objects[f]
    include=(typ in {'Reaction','Protein','Compound','cco'} or f==root_frame or f in regulated)
    category={'Reaction':'molecular_activity','Compound':'chemical_entity' if row['class'] else 'small_molecule','cco':'cellular_component','Pathway':'pathway','Enzymatic-Reaction':'molecular_activity'}.get(typ)
    if typ=='Protein': category='complex' if slots(f,'component') else 'protein'
    if f in cofactor_frames: category='cofactor'
    label_slots=slots(f,'common-name');label_sources=[]
    if label_slots:
        assert len(label_slots)==1
        label=plain(label_slots[0][1].text);assert label
        label_rule='direct native common-name, presentation markup decoded'
        label_sources=[source(f,label_slots[0][0])]
    elif typ=='Protein' and len(slots(f,'component'))==1 and len(slots(f,'catalyzes'))==1:
        component=slots(f,'component')[0][1];count=component.findtext('coefficient')
        a=slots(f,'catalyzes')[0][1][0].get('frameid')
        assert count and int(count)>=2 and a in objects
        assert objects[a].find('enzyme')[0].get('frameid')==f
        label=plain(objects[a].findtext('common-name'));assert label
        label_rule='bounded unnamed homomer / sole exact native activity name; authority producer still requires separate acceptance'
        label_sources=selected_sources(f,{'component','catalyzes'})+selected_sources(a,{'common-name','enzyme','reaction'})
    else:
        label=f;label_rule='exact native frame token only; source-context fallback requiring bounded authority support, not an invented canonical biological name'
    if include:
        included.add(f)
        node={'id':curie(f),'label':label}
        if f!=root_frame:node['category']=category
        if typ=='Reaction':node['direction']={'REVERSIBLE':'reversible','PHYSIOL-LEFT-TO-RIGHT':'left_to_right'}[equations[f]['source_direction']]
        nodes.append({'node':node,'collection':'root' if f==root_frame else ('reactions' if typ=='Reaction' else 'participants'),
                      'native_type':typ,'native_class':row['class'],'source_path':'inputs/source-preparation/'+row['path'],
                      'source_sha256':row['sha256'],'label_rule':label_rule,'label_sources':label_sources,
                      'scope':'Source-native class or instance only. No external identity, exact sequence or physiological-route inference.'})
    reason='included source-native graph declaration' if include else {
        'Gene':'Gene/product provenance context only; no supported encodes predicate exists in this profile, and gene presence is not an extra enzyme or measured route. Preserve all 45 exact originals and source gene/product ledger without inventing edges.',
        'Organism':'Native taxon association/context ledger retained; direct three taxa await issuing NCBITaxon closure. Do not use MetaCyc Organism IDs as a substitute public taxon or broaden from catalyst contexts.',
        'Regulation':'Exact real regulation is edge evidence rather than an invented activity; Regulation-of-Enzyme-Activity is a class, not an eighth regulation.',
        'Pathway':'METHFORM is a downstream boundary comparison, not a seventh member or additional chemical reaction.',
        'Enzymatic-Reaction':'Unregulated exact activity retained as reference/provenance of its direct native catalyst association; no unnecessary identity equivalence edge.'
    }[typ]
    node_dispositions.append({'frame':f,'native_type':typ,'native_class':row['class'],'proposed_graph_node':include,'reason':reason,'source_sha256':row['sha256'],'source_path':'inputs/source-preparation/'+row['path']})

edges=[]
def add(subject,predicate,obj,description,sources,assertions,role,**metadata):
    assert subject in included and obj in included
    assert len(sources)==len(assertions) and sources
    eid=f'native-ne{len(edges)+1:03d}'
    edge={'id':eid,'subject':curie(subject),'predicate':predicate,'object':curie(obj),'description':description,
          'evidence':[source_ev(s,a) for s,a in zip(sources,assertions)]}
    edges.append({'edge':edge,'role':role,'source_slots':sources,**metadata})
    return eid

root_members=slots(root_frame,'reaction-list');assert len(root_members)==1
for f in order:
    assert f in {n.get('frameid') for n in root_members[0][1]}
    ss=source(root_frame,root_members[0][0])
    add(root_frame,'has_part',f,f'One of six native members; source reaction direction {equations[f]["source_direction"]}, selected layout {equations[f]["pathway_direction"]}. '+reaction_context[f]+' '+taxon_context,[ss],[f'METHANOGENESIS-PWY reaction-list explicitly contains {f}.'],'membership',reaction=f)
for index,c in slots(root_frame,'reaction-ordering'):
    successor=c.find('Reaction').get('frameid');predecessor=c.find('predecessor-reactions/Reaction').get('frameid')
    add(predecessor,'precedes',successor,'Native pathway ordering only; not measured timing, channeling, transport between unlocated compartments or whole-route flux.',[source(root_frame,index)],[f'Native reaction-ordering names {predecessor} as predecessor of {successor}.'],'ordering')

material_plan=[]
for f in order:
    equation=equations[f]
    layout_i=next(i for i,c in slots(root_frame,'reaction-layout') if c.find('Reaction').get('frameid')==f)
    for side,terms in equation['terms'].items():
        for term in terms:
            incoming=(side=='left')==(equation['pathway_direction']=='L2R')
            ss=source(f,term['slot_index']);loc=term['compartment'] or 'unspecified (unlocated; not assumed cytosol or CCO-IN)'
            assertion=f'Native {side} occurrence: {term["frame"]}; coefficient {term["coefficient"]}; compartment {loc}.'
            desc=f'Selected pathway {equation["pathway_direction"]}: '+('input' if incoming else 'output')+f' coefficient {term["coefficient"]}; original {side} side; material occurrence compartment {loc}. '+reaction_context[f]
            if '[R]' in ''.join(objects[term['frame']].itertext()):desc+=' Native [R]-containing structural text does not establish a fixed exact molecule or public alias.'
            eid=add(term['frame'] if incoming else f,'consumes' if incoming else 'produces',f if incoming else term['frame'],desc,[ss,source(root_frame,layout_i)],[assertion,f'Root reaction-layout for {f} selects {equation["pathway_direction"]}; full material terms are taken from its own Reaction original.'],'material',reaction=f,source_side=side,coefficient=term['coefficient'],coefficient_explicit=term['coefficient_explicit'],compartment=term['compartment'],selected_side='input' if incoming else 'output')
            material_plan.append({**term,'reaction':f,'source_side':side,'selected_side':'input' if incoming else 'output','edge_id':eid})

activity_plan=[]
for a in activities:
    f=a['activity'];sources=selected_sources(f,{'enzyme','reaction'})
    assert len(sources)==2
    ids=[]
    if f not in opposed:
        ids.append(add(a['enzyme'],'catalyzes',a['reaction'],activity_context(a),sources,[f'Native {f} {s["slot"]} identifies '+(a['enzyme'] if s['slot']=='enzyme' else a['reaction'])+'.' for s in sources],'native_catalyst_association',activity=f))
    if f in regulated:
        es=selected_sources(f,{'enzyme'})[0]
        ids.append(add(a['enzyme'],'enables',f,activity_context(a),[es],[f'Native enzyme-specific activity {f} explicitly identifies {a["enzyme"]} as its enzyme.'],'exact_activity_enable',activity=f))
    activity_plan.append({**a,'proposed_edge_ids':ids,'proposed_activity_node':f in regulated,'direct_selected_reaction_catalyst':f not in opposed,'design_disposition':'Exact activity/enables and regulatory context only; source hydrolysis direction opposes selected route dehydration.' if f in opposed else 'Qualified native catalyst assertion; source evidence/direction/context retained without paper or route-wide promotion.'})

for row in components:
    ss=source(row['complex'],row['slot_index'])
    coef=row['coefficient_literal']
    desc=f'Native complex component occurrence; coefficient '+(coef if coef is not None else 'not supplied (not assumed to be 1)')+'. Complex membership does not assert independent subunit catalysis or a modern assembly/sequence mapping.'
    if row['complex'] in {'CPLX-622','CPLX-642','CPLX-643'}:desc+=' Historical native assembly scope is retained; do not combine quantities across preparations.'
    if row['complex']=='CPLX2065-6':desc+=' Source Mtr assembly annotation; Kurth2021 Mto assays and expression do not independently establish purified Mtr stoichiometry.'
    if row['complex']=='CPLX26TB-9':desc+=' Archaeoglobus annotation context is not proof of methanogenesis.'
    add(row['complex'],'has_part',row['component'],desc,[ss],[f'Native {row["complex"]} component slot identifies {row["component"]}; coefficient '+(coef if coef is not None else 'unspecified')+'.'],'component',coefficient_literal=coef)

for a in activities:
    for index,c in slots(a['activity'],'cofactor'):
        cf=c[0].get('frameid');desc=activity_context(a)+' Native activity cofactor assertion is projected onto its exact enzyme. '
        if a['activity'] in {'ENZRXN-422','ENZRXN-641','ENZRXN-642'}:desc+='Mo and W cofactors remain catalyst-specific; old single-MGD wording and the native bis-pterin compound are not automatically reconciled. Cyanide results must not transfer from Mo to W.'
        if a['activity']=='ENZRXN-702':desc+='Unresolved native conflict: CPLX-643 comment says only the cobamide prosthetic group, whereas ENZRXN-702 also lists FeS. Neither assertion is deleted or treated as independently measured stoichiometry.'
        ss=source(a['activity'],index)
        sources=[ss];assertions=[f'Native activity {a["activity"]}, whose enzyme is {a["enzyme"]}, lists cofactor {cf}.']
        if a['activity']=='ENZRXN-702':
            sources.append(selected_sources('CPLX-643',{'comment'})[0])
            assertions.append('CPLX-643 comment describes the cob(I)amide as the only prosthetic group. This conflicts with the linked activity FeS cofactor assertion; the source statements are retained without a reconciled cofactor inference.')
        add(a['enzyme'],'has_cofactor',cf,desc,sources,assertions,'cofactor',activity=a['activity'])

for f in sorted(included):
    if originals[f]['type']!='Protein':continue
    for index,c in slots(f,'location'):
        location=c[0].get('frameid');assert location in included
        add(f,'located_in',location,'Direct native physical-entity location only; it does not locate every reaction material or establish equivalent compartments. Membrane association does not establish an independently verified transport stoichiometry.',[source(f,index)],[f'Native Protein {f} has location {location}.'],'physical_location')

reg_plan=[]
for row in regulations:
    f=row['frame'];target=row['target_activity'];predicate={'+':'activates','-':'inhibits'}[row['mode']]
    sources=selected_sources(f,{'mode','regulator','regulated-entity'})
    assert len(sources)==3
    desc=f'Exact native regulation {f} targets activity {target}; it is not generalized to every enzyme of the generic reaction. '+activity_context(activity_by_id[target])
    if row['regulator']=='HCN':desc+=' Mo-specific native inhibition; no W activity inhibition is inferred.'
    if target in opposed:desc+=' Regulation belongs to the declared L2R hydrolytic activity, not selected root R2L dehydration.'
    eid=add(row['regulator'],predicate,target,desc,sources,[f'Native regulation {f}: mode {row["mode"]}; regulator {row["regulator"]}; regulated entity {target}.' for _ in sources],'regulation',regulation=f,activity=target)
    reg_plan.append({**row,'edge_id':eid})

assert len(nodes)==101 and len(edges)==125
assert len(material_plan)==30 and len({x['frame'] for x in material_plan})==18
assert Counter(x['role'] for x in edges)=={'membership':6,'ordering':5,'material':30,'native_catalyst_association':13,'exact_activity_enable':5,'component':43,'cofactor':6,'physical_location':10,'regulation':7}

claim_placements=[]
claim_roles={1:['membership','ordering'],2:['material'],3:['membership','material','native_catalyst_association'],4:['membership','material','exact_activity_enable','regulation'],5:['membership'],6:['material'],7:['material','cofactor'],8:['cofactor','regulation'],9:['component','native_catalyst_association'],10:['cofactor'],11:['component','native_catalyst_association'],12:['component','native_catalyst_association'],13:['exact_activity_enable','regulation'],14:['component','native_catalyst_association'],15:['native_catalyst_association'],16:['native_catalyst_association','material'],17:['membership'],18:['membership'],19:['material'],20:['regulation']}
for c in claims:
    num=int(c['id'][-2:]);roles=claim_roles[num]
    affected=set(x['frame'] for x in c['native_locators'])
    selected=[]
    for e in edges:
        frameids={s['frame'] for s in e['source_slots']}|{e['edge']['subject'].split(':',1)[1],e['edge']['object'].split(':',1)[1]}
        chosen=e['role'] in roles and (not affected or affected & frameids)
        if num==3:chosen=e.get('reaction')==order[3] or e.get('activity')=='ENZRXN-682'
        if num==4:chosen=e.get('reaction')==order[2] or e.get('activity') in opposed
        if num in {14,15}:chosen=e.get('activity')=='ENZRXN2065-393' or (num==14 and e['role']=='component' and e['edge']['subject']==curie('CPLX2065-6'))
        if num==16:chosen=e.get('reaction')==order[5] or e.get('activity')=='ENZRXN2065-393'
        if num==17:chosen=e['role']=='membership' and e.get('reaction')==order[0]
        if chosen:selected.append(e['edge']['id'])
    claim_placements.append({**c,'root_description_required':True,'design_edge_ids':selected,
        'placement_rule':'Carry the exact accepted claim and its limitation in the record narrative; required graph/export scope belongs in the selected incident-edge descriptions/evidence. Primary limitations do not become positive native experimental edges.',
        'source_evidence_policy':'Native slots are source_assertion evidence. Accepted primary summaries/locators are prose interpretation with their retained provenance, never fabricated paper quotations.'})

taxa=read(S/'results/taxon-ledger.json')
for row in taxa:
    row['proposed_record_role']='direct taxon declaration after separate issuer closure' if row['frame'] in {'TAX-2208','TAX-145262','TAX-2179'} else ('separate historical range, not a fourth direct taxon' if row['frame']=='TAX-28890' else 'catalyst/nested context only, not a pathway taxon declaration')
    row['public_curie_accepted_here']=False
    row['sources']=selected_sources(row['frame'],{'common-name','rank','strain-name','dblink','synonym'})

reference_frames=included|{a['activity'] for a in activities}|{x['frame'] for x in regulations}|{x['frame'] for x in taxa}|{'METHFORM-PWY'}
acquisitions=read(S/'results/acquisition-attempt-ledger.json')
references=[]
for f in sorted(reference_frames):
    row=originals[f]
    receipts=[x for x in acquisitions if x.get('sha256')==row['sha256'] and x.get('status')==200 and (x.get('url') or '').startswith('https://')]
    if f==root_frame:
        receipt=read(O/'inputs/discovery/results/acquisition-network-METHANOGENESIS-PWY.json')
        url='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:METHANOGENESIS-PWY'
        assert url in json.dumps(receipt)
        receipt_bindings=[{'path':'inputs/discovery/results/acquisition-network-METHANOGENESIS-PWY.json','sha256':sha((O/'inputs/discovery/results/acquisition-network-METHANOGENESIS-PWY.json').read_bytes())}]
    elif f=='NA+':
        receipt_path=S/'receipts/reuse-NA+.json'
        reuse=read(receipt_path)
        assert row['sha256'] in json.dumps(reuse)
        url=reuse['original_url']
        receipt_bindings=[{'path':'inputs/source-preparation/receipts/reuse-NA+.json','sha256':sha(receipt_path.read_bytes()),'scope':'Verified original reuse; no new successful270 sodium request is claimed.','receipt':reuse}]
    else:
        assert receipts,(f,'no exact successful acquisition receipt')
        url=receipts[0]['url'];receipt_bindings=receipts
    references.append({'reference':{'id':curie(f),'title':f'MetaCyc native {row["type"]} {f}','url':url,'source_version':'META 27.0; native original acquisition retained','source_sha256':row['sha256']},
        'source_path':'inputs/source-preparation/'+row['path'],'literal_xml_base_preserved':row['xml_base'],'receipt_bindings':receipt_bindings})

existing=read(O/'inputs/contracts/data/identifier_authorities/sources.json')['terms']
authority=[]
for node in nodes:
    id=node['node']['id'];old=existing.get(id)
    authority.append({'id':id,'proposed_label':node['node']['label'],'proposed_category':node['node'].get('category','pathway'),'native_type':node['native_type'],'native_class':node['native_class'],
       'existing_snapshot_term':old,'needs_new_authority_support':old is None,'label_rule':node['label_rule'],
       'source_path':node['source_path'],'source_sha256':node['source_sha256'],
       'scope':'Existence/type/label provenance only. Public aliases and identity mappings are excluded; no authority implementation or consumer pass claimed.'})

save('proposed-native-node-inventory.json',nodes)
save('all177-native-object-dispositions.json',node_dispositions)
save('proposed-native-edge-inventory.json',edges)
save('all30-material-occurrence-design.json',material_plan)
save('all15-activity-design-dispositions.json',activity_plan)
save('all7-regulation-design-dispositions.json',reg_plan)
save('all20-claim-design-dispositions.json',claim_placements)
save('all12-native-taxon-design-dispositions.json',taxa)
save('proposed-native-reference-inventory.json',references)
save('native-authority-requirements.json',authority)
slot_coverage=[]
for slot in read(S/'results/native-direct-slot-ledger.json'):
    f=slot['owner'];index=slot['index']
    exact_edges=[e['edge']['id'] for e in edges if any(s['frame']==f and s['one_based_slot']==index for s in e['source_slots'])]
    claim_ids=[c['id'] for c in claims if any(s['frame']==f and s['one_based_slot']==index for s in c['native_locators'])]
    disposition='explicit edge evidence' if exact_edges else ('retained accepted claim/context or conflict' if claim_ids else 'preserved original context/identity/backlink, not a new graph assertion')
    if f==root_frame and slot['tag']=='species':disposition='three direct taxon association obligations, pending separately accepted issuer/rank closure'
    if originals[f]['type']=='Gene':disposition='exact gene/product provenance retained; no invented encodes edge or extra biological-function inference'
    slot_coverage.append({'frame':f,'one_based_slot':index,'tag':slot['tag'],'edge_ids':exact_edges,'claim_ids':claim_ids,'disposition':disposition})
save('all2061-own-slot-design-dispositions.json',slot_coverage)
save('required-narrative-fragments.json',[{'claim_id':c['id'],'text':c['claim']+' '+c['limitations'],'source_disposition':c['disposition'],'native_locators':c['native_locators'],'primary_scope':c['primary_scope'],'scope':'Accepted predecessor interpretation reused at exact scope; not a fresh full primary reading or automatic paper quotation.'} for c in claims])
issuer=O/'inputs/issuer-preparation-unaccepted'
impacts=[]
for filename,key in [('material-dispositions.json','native_id'),('reaction-dispositions.json','native_id'),('protein-gene-dispositions.json','native_id'),('activity-identity-contexts.json','activity')]:
    rows=read(issuer/'results'/filename)
    for row in rows:
        f=row[key]
        related=[e['edge']['id'] for e in edges if f in {e['edge']['subject'].split(':',1)[1],e['edge']['object'].split(':',1)[1],e.get('activity')}]
        impacts.append({'native_id':f,'issuer_ledger':'inputs/issuer-preparation-unaccepted/results/'+filename,'issuer_ledger_sha256':sha((issuer/'results'/filename).read_bytes()),'author_disposition':row,'affected_design_edges':related,
            'design_decision':'Preserve native source identity and exact equation/quantity/location. No public alias, accession substitution, catalytic strengthening or whole-route scope is accepted from this author preparation. Reconcile the separately forthcoming independent issuer review before final record curation.'})
for row in read(issuer/'results/taxon-dispositions.json')['native_objects']:
    impacts.append({'native_id':row['native_id'],'issuer_ledger':'inputs/issuer-preparation-unaccepted/results/taxon-dispositions.json','issuer_ledger_sha256':sha((issuer/'results/taxon-dispositions.json').read_bytes()),'author_disposition':row,'design_decision':'Direct three source taxa remain obligatory; public IDs/ranks and historical range wording require separate independent issuer acceptance. Catalyst contexts do not enlarge pathway taxa.'})
save('issuer-constraint-impact-ledger.json',{'status':'Frozen author constraints only; independent issuer acceptance pending','source_manifest_sha256':'dfc7cef1e269d870034b347abb99af7dd473f434cd487a2083105bb7f439e851','rows':impacts})
save('design-summary.json',{'native_nodes':len(nodes),'native_edges':len(edges),'roles':dict(Counter(x['role'] for x in edges)),
 'source_objects':len(inventory),'source_references':len(references),'direct_taxa_pending_issuer':3,
 'existing_native_authority_terms':sum(x['existing_snapshot_term'] is not None for x in authority),
 'new_native_authority_terms':sum(x['needs_new_authority_support'] for x in authority),
 'not_a_maintained_record':True,'no_external_aliases_accepted':True,'actual_merged266_baseline_rebind_pending':True})
print(json.dumps(read(R/'design-summary.json'),indent=2))
