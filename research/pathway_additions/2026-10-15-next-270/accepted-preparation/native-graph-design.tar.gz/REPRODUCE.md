# Reproduce the bounded design

Use the existing verified runtime, with bytecode disabled. Copy this entire frozen packet to a new owned directory first. Neither script writes outside its own parent packet; do not execute it in this immutable owner.

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B /NEW/OWNER/scripts/design_native.py
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B /NEW/OWNER/scripts/check_design.py
```

The builder consumes copied accepted originals, corrected claims, frozen-but-not-yet-independently-accepted issuer constraints and copied contracts only. It produces source-to-design and design-to-source inventories, exact activity/regulation/taxon/claim dispositions, reference and authority requirements. The checker reparses source slots, exercises copied schema/export/graph modules, and creates the clearly labelled native-biochemical probe and preview. It does not run network requests, current authority validation, whole-corpus checks or a maintained saver.

The input taxonomy remains three explicit unresolved issuing obligations; `taxa: []` in the test fixture is deliberate partial-probe scope, not an approved final taxon omission. Native IDs and provisional labels do not by themselves establish authority-consumer acceptance. Do not use the schema probe to claim a curated record.

`results/attempt-dispositions.json` preserves the sodium reuse and cofactor-category author corrections, plus two temporary SVG-count assumptions. The final terminal log is `results/check-issuer-successor.stdout`; its matching stderr is empty. Earlier logs and scripts remain unchanged.

A fresh isolated replay in `/private/tmp/pathwaymech-next-270-native-design-reproduction` completed both scripts with exit 0. All 20 generated files were byte-identical, including the 1,369-check receipt, YAML probe, HTML preview and KGX tables. Exact commands and output hashes are in `results/reproduction.json`; raw logs use the `reproduction-` prefix. This replay makes no authority or whole-corpus acceptance claim.
