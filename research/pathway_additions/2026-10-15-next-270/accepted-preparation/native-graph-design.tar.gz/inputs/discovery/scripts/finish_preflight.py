from pathlib import Path
import json,hashlib,csv,re,shutil,xml.etree.ElementTree as ET
R=Path('/private/tmp/pathwaymech-next-270-discovery'); B=Path('/private/tmp/pathwaymech-next-269-20261015'); O=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/'results'/n).write_text(json.dumps(x,indent=2)+'\n')
src=O/'reports/local_source_ingestion/2026-10-08-dram-seed/dram/module_step_form.tsv'
dst=R/'inputs/ignored-DRAM-module_step_form.tsv';assert not dst.exists();shutil.copyfile(src,dst)
rows=list(csv.DictReader(src.read_text().splitlines(),delimiter='\t'))
selected=[dict(x,original_line_number=i+2) for i,x in enumerate(rows) if x['module'] in ('M00567','M00357')]
aliases=sorted(set(['M00567','M00357']+[y for x in selected for y in re.findall(r'R\d{5}',x['gene'])]))
records=json.loads((R/'results/current265-record-inventory.json').read_text())
overlaps=[]
for row in records:
 text=(B/row['path']).read_text()
 hits=[a for a in aliases if re.search(r'(?<![A-Za-z0-9])'+re.escape(a)+r'(?![0-9])',text)]
 if hits:overlaps.append({'path':row['path'],'id':row['id'],'exact_lexical_codes':hits})
save('ignored-DRAM-comparison.json',{'source':str(src),'copy':str(dst.relative_to(R)),'sha256':sha(src),'bytes':src.stat().st_size,'rows':selected,'candidate_codes_not_accepted_equivalences':aliases,'current265_lexical_code_overlaps':overlaps,'disposition':'DRAM derived KEGG module rows are comparison leads, not current issuing originals or complete native pathway equivalence. M00567 includes alternative Mtd/Hmd and downstream methane/heterodisulfide steps beyond the six-member native definition. M00357 includes acetate activation alternatives and a larger boundary.'})
terms=json.loads((B/'data/identifier_authorities/sources.json').read_text())['terms']
ids=['MetaCyc:METHANOGENESIS-PWY','MetaCyc:METH-ACETATE-PWY','MetaCyc:PWY-301']+[f"MetaCyc:{x['id']}" for row in json.loads((R/'results/candidate-comparison.json').read_text()) for x in row['directions']]
save('authority-exact-term-check.json',{'source':str(B/'data/identifier_authorities/sources.json'),'sha256':sha(B/'data/identifier_authorities/sources.json'),'checks':[{'id':x,'declared_term':x in terms} for x in sorted(set(ids))],'limit':'Term ownership only; native backlinks and embedded activity contexts are present and are not promoted into independent terms or curated pathway records.'})
for frame in ('METHANOGENESIS-PWY','METH-ACETATE-PWY'):
 p=R/'originals'/f'META-{frame}.xml';doc=ET.parse(p).getroot();pw=doc.find('Pathway')
 assert pw is not None and pw.get('frameid')==frame and pw.get('orgid')=='META' and pw.get('detail')=='full'
 assert doc.findtext('metadata/query')=='META:'+frame and doc.findtext('metadata/num_results')=='1'
 save(frame+'-boundary.json',{'sha256':sha(p),'members':[x.get('frameid') for x in pw.findall('reaction-list/Reaction')],'order':[{'before':p.get('frameid'),'after':x.find('Reaction').get('frameid')} for x in pw.findall('reaction-ordering') for p in x.findall('predecessor-reactions/Reaction')],'layout_material_occurrences':[{'reaction':x.find('Reaction').get('frameid'),'direction':x.findtext('direction'),'side':side,'id':p.get('frameid'),'native_class':p.get('class')=='true'} for x in pw.findall('reaction-layout') for side in ('left-primaries','right-primaries') for p in x.findall(side+'/*')],'linked_only':[x.get('frameid') for x in pw.findall('pathway-link/link-target/Pathway')],'limit':'Layout primaries are not complete equations; no exact net, mass balance, catalyst or elemental mechanism accepted.'})
print(json.dumps({'DRAM_rows':len(selected),'candidate_codes':aliases,'overlap':overlaps,'term_hits':[x for x in ids if x in terms]},indent=2))
