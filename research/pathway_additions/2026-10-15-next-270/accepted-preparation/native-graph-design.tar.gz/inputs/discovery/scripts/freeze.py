from pathlib import Path
import hashlib,json,subprocess,datetime
R=Path('/private/tmp/pathwaymech-next-270-discovery'); B=Path('/private/tmp/pathwaymech-next-269-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert not (R/'artifact-manifest.json').exists()
assert not (R/'freeze-proof.json').exists()
bindings=json.loads((R/'results/input-bindings.json').read_text())
checks=[{'source':x['source'],'copy':x['copy'],'source_unchanged':sha(Path(x['source']))==x['sha256'],'copy_unchanged':sha(R/x['copy'])==x['sha256']} for x in bindings]
assert all(x['source_unchanged'] and x['copy_unchanged'] for x in checks)
records=json.loads((R/'results/current265-record-inventory.json').read_text())
assert all(sha(B/x['path'])==x['sha256'] for x in records)
dram=json.loads((R/'results/ignored-DRAM-comparison.json').read_text())
assert sha(Path(dram['source']))==dram['sha256']==sha(R/dram['copy'])
native=[]
for frame,expected in [('METHANOGENESIS-PWY','35e06e69cc42fe911cee1f6e33ddd950628d24bcb45a2807878099dd8dae43c8'),('METH-ACETATE-PWY','c07ebef86298854af9494a5309ee9453fb9a014b4d1dd5c016278648cb90b5ec')]:
 p=R/'originals'/f'META-{frame}.xml';assert sha(p)==expected;native.append({'path':str(p.relative_to(R)),'sha256':sha(p),'unchanged':True})
write(R/'results/final-input-check.json',{'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'copied_inputs':checks,'DRAM_source_and_copy_unchanged':True,'native_originals':native,'records_unchanged':len(records),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=B,text=True).strip(),'scope':'All 265 record bytes, 13 governing/prior inputs, one ignored DRAM input and two newly acquired native originals checked. No blanket maintained-worktree quiescence claim; root independently owns pending269 integration.'})
files=[]
for p in sorted(R.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file():files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
write(R/'artifact-manifest.json',{'schema_version':1,'scope':'All physical files recursively including hidden/ignored; manifest and freeze proof are explicitly self-excluded. No symlinks.','files':files,'listed_files':len(files),'listed_bytes':sum(x['bytes'] for x in files)})
proof={'owner':str(R),'listed_files':len(files),'physical_files':len(files)+2,'manifest_sha256':sha(R/'artifact-manifest.json'),'HANDOFF_sha256':sha(R/'HANDOFF.md'),'PRIMARY_READING_sha256':sha(R/'PRIMARY-READING.md'),'self_excluded':['artifact-manifest.json','freeze-proof.json'],'claim':'Frozen bounded author preflight only; no independent acceptance or maintained curation.'}
write(R/'freeze-proof.json',proof)
assert len([p for p in R.rglob('*') if p.is_file()])==len(files)+2
assert all(sha(R/x['path'])==x['sha256'] for x in files)
print(json.dumps(dict(proof,freeze_sha256=sha(R/'freeze-proof.json')),indent=2))
