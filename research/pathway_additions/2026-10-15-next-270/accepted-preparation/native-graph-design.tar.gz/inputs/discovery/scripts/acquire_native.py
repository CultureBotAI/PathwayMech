from pathlib import Path
import urllib.request, hashlib, json, datetime, concurrent.futures
O=Path('/private/tmp/pathwaymech-next-270-discovery')
def fetch(frame):
    url='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+frame
    row={'id':frame,'url':url,'attempted_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':'network-enabled retry after retained sandbox DNS failure'}
    try:
        with urllib.request.urlopen(url,timeout=40) as resp:
            b=resp.read();row.update(status=resp.status,final_url=resp.url,headers=dict(resp.headers),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
            p=O/'originals'/('META-'+frame+'.xml');assert not p.exists();p.write_bytes(b);row['path']=str(p.relative_to(O))
    except Exception as e:row['error']=repr(e)
    p=O/'results'/('acquisition-network-'+frame+'.json');assert not p.exists();p.write_text(json.dumps(row,indent=2)+'\n')
    return {k:v for k,v in row.items() if k!='headers'}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for r in pool.map(fetch,['METHANOGENESIS-PWY','METH-ACETATE-PWY']):print(json.dumps(r,indent=2))
