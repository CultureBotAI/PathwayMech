from pathlib import Path
import urllib.request, urllib.error, hashlib, json, datetime, concurrent.futures
O=Path('/private/tmp/pathwaymech-next-270-discovery')
jobs=[('PMC3041090.html','https://pmc.ncbi.nlm.nih.gov/articles/PMC3041090/'),('PMID9342247.html','https://pubmed.ncbi.nlm.nih.gov/9342247/'),('PMID15882413.html','https://pubmed.ncbi.nlm.nih.gov/15882413/'),('Vorholt1997.pdf','https://febs.onlinelibrary.wiley.com/doi/pdf/10.1111/j.1432-1033.1997.00919.x')]
def fetch(job):
    name,url=job;row={'url':url,'attempted_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(url,timeout=40) as response:
            body=response.read();row.update(status=response.status,final_url=response.url,headers=dict(response.headers))
    except urllib.error.HTTPError as error:
        body=error.read();row.update(status=error.code,error=str(error),headers=dict(error.headers))
    except Exception as error:
        body=None;row['error']=repr(error)
    if body is not None:
        path=O/'originals'/name;assert not path.exists();path.write_bytes(body);row.update(path=str(path.relative_to(O)),bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),pdf_magic=body.startswith(b'%PDF-'))
    path=O/'results'/('acquisition-'+name+'.json');assert not path.exists();path.write_text(json.dumps(row,indent=2)+'\n')
    return {k:v for k,v in row.items() if k!='headers'}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for row in pool.map(fetch,jobs):print(json.dumps(row,indent=2))
