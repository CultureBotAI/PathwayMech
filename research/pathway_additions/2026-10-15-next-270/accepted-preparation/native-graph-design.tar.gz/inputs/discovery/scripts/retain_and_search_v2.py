from pathlib import Path
import hashlib,json,shutil,subprocess,re
ROOT=Path('/private/tmp/pathwaymech-next-270-discovery')
BASE=Path('/private/tmp/pathwaymech-next-269-20261015')
ORIG=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/Mechs/PathwayMech')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value): (ROOT/'results'/name).write_text(json.dumps(value,indent=2)+'\n')
sources=[
(BASE/'.claude/skills/add-pathway/SKILL.md','governance/add-pathway-SKILL.md'),
(Path('/Users/marcin/.codex/skills/pathwaymech-discover-sources/SKILL.md'),'governance/discover-sources-SKILL.md'),
*[(BASE/p,'baseline/'+p) for p in ['CLAUDE.md','docs/HARMONIZATION.md','docs/CURATION.md','docs/CAUSAL_GRAPHS.md','src/pathwaymech/schema/pathwaymech.yaml','conf/sources.yaml','research/source_discovery/current_open_source_ingest_triage.md','research/source_discovery/2026-10-03-additional-sources-and-updates.md','research/cross_mech/2026-10-05-uniprot-protein-links.md']],
(Path('/private/tmp/pathwaymech-next-269-candidate-handoff/HANDOFF.md'),'prior-next269/HANDOFF.md'),
(Path('/private/tmp/pathwaymech-next-269-candidate-handoff/inputs/META-PWY-301.xml'),'prior-next269/META-PWY-301.xml')]
bindings=[]
for src,rel in sources:
 dst=ROOT/'inputs'/rel
 if dst.exists():
  assert sha(src)==sha(dst),dst
 else:
  dst.parent.mkdir(parents=True,exist_ok=True)
  shutil.copyfile(src,dst)
 bindings.append({'source':str(src),'copy':str(dst.relative_to(ROOT)),'bytes':src.stat().st_size,'sha256':sha(src)})
write('input-bindings.json',bindings)
patterns=['METHANOGENESIS-PWY','METH-ACETATE-PWY','methanogenesis','methanogenic','H2-METHYLENE-THMPT-DEHYDRO-RXN','2.1.1.86-RXN','METHELENE-THMPT-OXI-RXN','3.5.4.27-RXN','2.3.1.101-RXN','FORMYLMETHANOFURAN-DEHYDROGENASE-RXN','9342247','21262829','15882413','10.1073/pnas.1016761108','PWY-301','R281-RXN','R282-RXN']
patfile=ROOT/'results'/'exact-preflight-search-patterns.txt'; patfile.write_text('\n'.join(patterns)+'\n')
rx=re.compile('|'.join(re.escape(s) for s in patterns),re.I)
for tag,base in [('merged265',BASE),('original-checkout',ORIG)]:
 cmd=['rg','--no-ignore','--hidden','--files-with-matches','-i','-F','-f',str(patfile),'-g','!.git/**','-g','!.venv/**','.']
 result=subprocess.run(cmd,cwd=base,capture_output=True,text=True)
 assert result.returncode in (0,1),(result.returncode,result.stderr)
 files=[]
 for line in result.stdout.splitlines():
  p=base/line; raw=p.read_bytes(); txt=raw.decode('utf-8',errors='replace')
  matches=list(rx.finditer(txt))
  files.append({'path':str(p.relative_to(base)),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'match_count':len(matches),'contexts':[txt[max(0,m.start()-120):min(len(txt),m.end()+180)] for m in matches[:12]],'context_limit':12})
 write('exact-preflight-search-'+tag+'.json',{'root':str(base),'command':cmd,'returncode':result.returncode,'stderr':result.stderr,'scope':'All ordinary text including hidden and ignored files; root .git and .venv excluded; binary and compressed interiors require separate accounting. Every matching file retained by path/hash; contexts capped at 12, not asserted complete readings.','files':files})
records=json.loads((ROOT/'results/current265-record-inventory.json').read_text())
write('baseline-after-check.json',{'records':[{'path':r['path'],'sha256_before':r['sha256'],'sha256_after':sha(BASE/r['path']),'unchanged':sha(BASE/r['path'])==r['sha256']} for r in records],'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=BASE,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=BASE,text=True).strip(),'input_copies_unchanged':all(sha(Path(r['source']))==r['sha256']==sha(ROOT/r['copy']) for r in bindings)})
print(json.dumps({'copied_inputs':len(bindings),'record_count':len(records),'searches':['merged265','original-checkout']}))
