# Retained failures and scope corrections

- Initial scratch-owner creation succeeded. An overbroad temporary-directory enumeration hit PermissionError on an unrelated daemon directory; the later enumeration filtered candidate basenames before stat. No further access was attempted.
- A prior `ASSESSMENT.md` probe found no file in the next269 candidate-handoff owner. Its complete HANDOFF was read instead; no missing-file content was inferred.
- Initial native network calls failed DNS inside the sandbox. Bounded read-only escalated acquisition succeeded, and both receipt series remain present.
- A SolCyc page request returned 502. Speculative candidate-ID search terms were discarded when the actual source identities were found; no guessed PWY number is represented as an alias.
- Initial broad text output was truncated by embedded JSON lines. Complete matching file identities and bounded contexts were retained in later machine-readable searches. Search contexts are not full-document reading claims.
- `scripts/retain_and_search.py` stopped at a mistaken `schema/pathwaymech.yaml` path after copying six preceding inputs. The corrected `retain_and_search_v2.py` uses `src/pathwaymech/schema/pathwaymech.yaml`, checks already copied bytes, and completed both searches and baseline checks. The failed script is preserved, not represented as successful.
- Direct primary acquisition responses were challenges or HTML rather than the requested papers; see PRIMARY-READING.md and unchanged acquisition receipts. A later web reopen of a formerly readable PMC view also returned a challenge. No whole-paper or original-byte acceptance was inferred.
- No runtime package was installed or repaired. No frozen source packet was overwritten. The historical search does not imply universal archive coverage.
