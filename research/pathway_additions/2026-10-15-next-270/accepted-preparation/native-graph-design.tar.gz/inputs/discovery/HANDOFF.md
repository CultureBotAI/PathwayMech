# Next270 bounded candidate handoff

**Recommend MetaCyc:METHANOGENESIS-PWY, methanogenesis from H₂ and CO₂, for the next source-preparation task.** This is a supported discovery lead with an exact native boundary, not a curation-ready record. It adds distinct archaeal carbon-reduction coverage. Its native six-member route ends at methyl-coenzyme M; methane formation is a linked pathway, **METHFORM-PWY**, and is not silently added.

The baseline is the actual merged commit `7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105`, tree `1a0560c741c07fcb7878b1e93d8d38da67b1287c`: all **265 maintained records**, including PWY0-321. Pending PWY-5177 is separately excluded. All 265 record hashes remained unchanged at final comparison. The existing methanogenesis lead in the 2026-10-05 cross-Mech report was inspected; its McrA demand is useful context but does not place methyl-CoM reductase inside this native definition.

| Rank | Exact candidate | Disposition |
|---|---|---|
| 1 | MetaCyc:METHANOGENESIS-PWY | Prepare the complete six-member native source closure and primary evidence with the boundary and commentary limitations below. |
| 2 | MetaCyc:METH-ACETATE-PWY | Keep as an alternative: a distinct aceticlastic definition, also six members, with more overlap in acetate activation and CODH/ACS context. Exact catalyst/cofactor and genus-versus-species coverage remain unprepared. |
| 3 | MetaCyc:PWY-301 | Keep deferred. Prior AliA/AliB evidence distinctions remain: the cited AliB expression/purification/activity is attributed to unpublished work, not the demonstrated BadH experiments. |

## Exact first-candidate source and boundary

The complete Pathway Tools 27.0 `META` original, exact frame and `detail=full`, was acquired from [the native getxml endpoint](https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:METHANOGENESIS-PWY): `originals/META-METHANOGENESIS-PWY.xml`, 28,899 bytes, SHA256 `35e06e69cc42fe911cee1f6e33ddd950628d24bcb45a2807878099dd8dae43c8`. Its literal XML base is retained as evidence; use the actual HTTPS acquisition URL for navigation. Successful and failed acquisition receipts are separate.

Source order and layout directions:

1. `FORMYLMETHANOFURAN-DEHYDROGENASE-RXN` — R2L.
2. `2.3.1.101-RXN` — L2R.
3. `3.5.4.27-RXN` — R2L.
4. `H2-METHYLENE-THMPT-DEHYDRO-RXN` — L2R.
5. `METHELENE-THMPT-OXI-RXN` — R2L; preserve this exact native spelling.
6. `2.1.1.86-RXN` — L2R.

All six memberships and five order edges are explicit. Layout primaries are not complete equations. The selected Hmd reaction must not be replaced by the F₄₂₀-dependent Mtd alternative. Methanofuran and F₄₂₀ families remain generic where declared. The three direct taxon associations are TAX-2208 M. barkeri, TAX-145262 M. thermautotrophicus and TAX-2179 Methanothermus (a genus). The broader native range is not experimental proof, and current taxonomy/strain reconciliation remains necessary. Preserve every direct taxon disposition rather than treating them as catalyst backlinks.

`METHFORM-PWY`, `PWY-5209`, cofactor synthesis/regeneration links and superpathway PWY-6830 are contextual boundaries, not member reactions. The UM-BBD-PWY `meth` unification cross-reference remains a source assertion pending issuer comparison. The source's experimental evidence code and PMID:9342247 identify a first-enzyme paper, not six-step or all-taxon experimental closure.

The native commentary contains a material scope hazard: it imports generalized methyl-CoM disproportionation and energy-conservation language into the H₂/CO₂ definition. The targeted primary check and exact access/reading limits are in `PRIMARY-READING.md`. Do not assert universal 1:3 disproportionation, a universal membrane methanophenazine system, or whole-route flux on the basis of this comment. The six-member boundary itself remains usable for faithful source preparation.

## Duplicate and prior-disposition scope

All 265 current records were parsed and hash-bound. Neither methanogenesis candidate is a maintained pathway ID/label, and none of the twelve native member IDs is a declared reaction ID. This is exact declaration accounting, not proof that every underlying reaction chemistry is new. Acetate activation and shared cofactors overlap existing biology. Issuing Rhea/KEGG mappings have not yet been accepted and must trigger another alias/equation duplicate check.

`rg --no-ignore --hidden` searched ordinary text in both the merged worktree and original checkout, excluding root Git administration and runtime only. Results matched 52 and 21 files. Authority backlinks were inspected; they are contextual original slots, not declared pathway/reaction owners. The ignored DRAM table supplies derived M00567/M00357 comparison rows. M00567 has an alternative dehydrogenase branch and downstream methane/heterodisulfide steps, so it is not an exact alias for the native six-member route. The selected rows and current-record lexical code overlaps are retained. SEED selector labels are discovery leads only. Prior incomplete YeastPathways GO-CAM projections remain distinct from complete native definitions.

Compressed history is explicit and finite: 16,576 archive files (1,273,224,545 compressed bytes) were inventoried; 116 discovery/candidate/preflight/queue/triage text gzip files were fully decoded and searched (24,849,128 decoded bytes), with no selected-pattern hits. The other 16,460 archive interiors were not globally decoded. No universal synonym, historical rejection or source-exhaustion claim follows. Relevant uncompressed prior reports and the PWY-301 handoff were read.

## Concrete next task

In a separate scratch owner, acquire the **six exact member Reaction originals**, then close their complete material occurrences, activities, enzymes/complexes, cofactors, regulators and organisms through direct native references. Obtain METHFORM-PWY only as a boundary comparison. Preserve complete equations and source directions before net cancellation; no generic carrier should become a specific molecule by convenience. Reconcile native aliases against issuing originals or already verified pins, then repeat duplicate checks.

Primary priorities are the full Vorholt/Thauer 1997 article (PMID:9342247; DOI:10.1111/j.1432-1033.1997.00919.x), exact Hmd/Mer/Mtr catalyst studies discovered from those originals, and complete Kaster 2011 main/SI for energy-coupling context if a claim needs it. Pritchett 2005 is a methanol-context comparison, not H₂/CO₂-route validation. Preserve unavailable primary claims as explicitly source-only; do not invent a complete physiological route. Rebind the actual merged corpus after pending269 lands before any maintained addition.

No maintained record, source inventory, authority, Git/GitHub state, runtime or frozen269 packet was changed. No page/browser QA or complete mechanistic curation is claimed. This packet is ready for bounded independent preflight review and source-preparation scheduling.
