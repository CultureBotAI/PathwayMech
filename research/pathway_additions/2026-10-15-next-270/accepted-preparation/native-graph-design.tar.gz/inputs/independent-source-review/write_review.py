from pathlib import Path
import hashlib,json,shutil
A=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation');O=Path(__file__).resolve().parent
comments={
1:'Root membership/order and methyl-CoM endpoint independently reconstructed; linked METHFORM retained outside membership.',
2:'Exact Reaction left/right slots carry coefficient2 and CCO-IN/CCO-OUT. This accepts the native assertion, not primary measured stoichiometry.',
3:'Native H2 member and Hmd complex commentary differ from Mtd/F420 in Kurth Fig2/Fig5 and TableS1 row39.',
4:'Both own Mch activity directions are PHYSIOL-LEFT-TO-RIGHT, root layout R2L. Explicit source conflict correctly retained.',
5:'Direct pathway species slots include two species and one genus; phylum range distinct. No current taxonomy equivalence accepted.',
6:'Generic source carriers remain classes; ferredoxin comments explicitly call their structures illustrative.',
7:'Eight literal [R] SMILES and H2 [H] verified directly; four R entries are nonclass. No CML or InChI chemistry certification.',
8:'Exact Mo/W activity cofactor targets and PMID8125106 abstract preserve differential cyanide response; no cross-catalyst transfer.',
9:'PMID1521540 absence-of-Ni/FeS/flavin wording is narrower than absence of iron; PMID20221540 is other-species abstract context.',
10:'CPLX643 only-cobamide prose, ENZRXN702 FeS/cobamide fields and historical seven/eight polypeptide abstracts remain separately scoped.',
11:'HMDMAUTO own comment explicitly combines Marburg and DeltaH labels; Mer abstracts distinguish preparations. No strain or sequence mapping accepted.',
12:'Five Archaeoglobus own activity originals lack evidence and direction fields; protein annotations explicitly invoke automated homology.',
13:'PMID10215859 describes separate purified H4MPT/H4F cyclohydrolases and suggests a catabolic role; no whole methanogenesis claim.',
14:'Complete Kurth Methods/Results and figures show native MtoA/B plus heterologous MtoC/D experiments, and Mtr expression context. Native Mtr IPI tag is not an isolated pumping assay.',
15:'H4F-surrogate and CoM-negative assay scientifically supported by Fig4C/caption, Results PDF11–12 and SI S2B. Required locator correction N270-R01.',
16:'Kurth Fig5 explicitly hypothetical; SI S4/S7 and results model oscillation, and main isotope experiment expressly qualitative. No measured route-wide flux or universalratio accepted.',
17:'All PMID9342247 abstract paragraphs support CO2 rather than bicarbonate and consistency with proposed N-carboxymethanofuran. Full original remains unavailable.',
18:'All PMID21262829 abstract paragraphs concern MvhADG/HdrABC; preflight partial scope reused only. No fresh full main/SI or membrane universal claim.',
19:'Independently recomputed one-pass signed nets; compartment-specific sodium and located/unlocated carrier residuals remain. No atom/charge/energy/flux conclusion.',
20:'Seven regulation objects independently rebound to exact targets/modes, excluding Regulation class. Abstracts corroborate only selected scoped effects.'}
claims=json.loads((A/'results/claim-dispositions.json').read_text());rows=[{'claim_id':r['id'],'status':'scientific qualification accepted; locator correction required' if i==15 else 'accepted at stated bounded source/primary scope','independent_assessment':comments[i],'original_claim_ledger_sha256':hashlib.sha256((A/'results/claim-dispositions.json').read_bytes()).hexdigest()} for i,r in enumerate(claims,1)]
(O/'claim-review-dispositions.json').write_text(json.dumps(rows,indent=2)+'\n')
acts=json.loads((A/'results/activity-dispositions.json').read_text());ar=[]
for r in acts:
 f=r['activity'];status='native association; abstract-only experimental corroboration, preparation identities unresolved'
 if f.startswith('ENZRXN26TB-'):status='native homology/annotation context only; no own activity evidence/direction or whole pathway claim'
 elif f=='ENZRXN2065-393':status='native activity assertion retained; independent full Kurth study supports expression/context and hypothetical Mtr role, not isolatedMtr pumping experiment'
 elif f=='ENZRXN-4121':status='native bacterial C1 activity and abstract corroboration; root direction conflict and no methane-route transfer'
 elif f=='ENZRXN-662':status='native Mch activity plus abstract corroboration; exact regulator scope and root direction conflict retained'
 ar.append({'activity':f,'reaction':r['reaction'],'enzyme':r['enzyme'],'reviewed_disposition':status,'scope':'No exact current strain/sequence/public-issuer equivalence accepted.'})
(O/'activity-review-dispositions.json').write_text(json.dumps(ar,indent=2)+'\n')
for n in ['claim-dispositions.json','activity-dispositions.json','primary-reading-scopes.json','unresolved-prerequisites.json']:
 shutil.copyfile(A/'results'/n,O/('author-'+n))
