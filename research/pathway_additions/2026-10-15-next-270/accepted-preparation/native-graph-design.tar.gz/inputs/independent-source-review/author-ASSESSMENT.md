# Bounded native and primary source preparation

This packet supports independent review of the exact MetaCyc METHANOGENESIS-PWY definition. It is source preparation, not a maintained record, authority adapter, or blanket scientific approval. The previously frozen discovery packet is unchanged. Its 265-record duplicate scope and pending PWY-5177 exclusion remain the baseline; this packet does not extend the absence claim to every chemical synonym or every compressed historical interior.

## Native closure and boundary

The root defines six reactions in this order: FORMYLMETHANOFURAN-DEHYDROGENASE-RXN (R2L), 2.3.1.101-RXN (L2R), 3.5.4.27-RXN (R2L), H2-METHYLENE-THMPT-DEHYDRO-RXN (L2R), METHELENE-THMPT-OXI-RXN (R2L), and 2.1.1.86-RXN (L2R). Exact native spelling is retained. Five ordering relations connect them. The definition ends at methyl-CoM. METHFORM-PWY was acquired and read as a downstream boundary only; its methyl-CoM reductase reaction was not imported into the six-member definition. Other pathway links and the superpathway remain context.

There are 177 full native objects including the copied root: 175 fresh successful acquisitions, one verified sodium-original reuse, and that root. The 176 closure objects contain six reactions, 59 proteins (including two generic ferredoxin classes), 45 genes, 26 compounds, four cellular-component objects, 15 enzyme activities, the boundary pathway, eight Regulation objects (seven actual instances and one class), and 12 organism objects. Counts including the root are in native-closure-summary.json.

All 30 direct material occurrences (18 distinct material IDs), 15 activity associations, 15 direct catalysts, six equation-compartment occurrences, three direct pathway taxon associations, and one taxonomic range resolve to owned originals. Following the declared biological slots reaches 334 reference occurrences with no missing target. These slots cover complex components, gene/product, catalyst species/location, activity cofactors and regulation, and modified/unmodified forms. All 43 component occurrences preserve literal coefficients, including absence of an explicit coefficient. All 2,061 own-object direct slots and 34,996 nested frame-reference occurrences are retained in exact XML ledgers.

This closure is finite. Class members, unrelated reaction backlinks, protein-feature metadata, every citation object, every taxonomy ancestor, and every HTML commentary hyperlink are not recursively expanded. Their source slots and references remain visible. METHFORM's own species and downstream reaction remain boundary context, not missing members. The comment-only methylated cobamide intermediate CPD-7163 is a specific future prerequisite if an elementary Mtr mechanism is proposed.

## Direction, transport and identity

The native Mtr equation contains two Na+ on each side, explicitly CCO-IN to CCO-OUT. This is retained as a source assertion. The other reactions generally lack explicit compartments. A compartment-preserving one-pass sum therefore retains both sodium transport and located/unlocated carrier residuals. Collapsing compartments is a separate lossy diagnostic, not proof of physiological transport or flux. Generic methanofuran, F420 and ferredoxin carriers prevent a complete molecular atom/charge proof here.

The native fourth member is Hmd using H2, not the distinct F420-dependent Mtd reaction. The Kurth study discusses Mtd in another metabolic context; it does not replace this native member. The two experimentally annotated Mch activities, ENZRXN-662 and ENZRXN-4121, declare physiological L2R despite the root's R2L layout. Both statements are preserved as a conflict.

Eight material SMILES contain literal [R]: CPD-7162, CoM, Formyl-methanofurans, METHYL-THMPT, Me-CoM, Methanofurans, Oxidized-Factor-F420 and Reduced-Factor-F420. Four are nonclass entries with concrete formula/InChI. H2 has literal SMILES [H] alongside an H2 formula/InChI. Generic ferredoxin structures are explicitly illustrative, not fixed protein molecules. No SMILES equality, CML stereochemical validation, issuing ChEBI/Rhea/KEGG identity, or exact gene/protein accession equivalence is accepted in this packet. Native xrefs remain candidates.

## Taxa, activities and regulation

Each direct pathway association is explicit: TAX-2208 is native M. barkeri at species rank; TAX-145262 is native M. thermautotrophicus at species rank; TAX-2179 is Methanothermus at genus rank, despite its placement in a species slot. TAX-28890 is a separate historical Euryarchaeota phylum range. None implies that every member has been measured in every listed organism. Current issuing taxonomy remains unchecked.

All 15 activity dispositions are in activity-dispositions.json. Five Archaeoglobus fulgidus DSM 4304 activities have no activity evidence code or direction in their own records; their shared C1 reactions and homology context do not establish methanogenesis. The AM1 bacterial Mch activity belongs to C1 metabolism, not a whole methane route. Historical Marburg prose and species/delta-H accession pointers need exact reconciliation before a public strain or sequence mapping.

All seven regulations retain their exact activity targets: HCN inhibits ENZRXN-422 and -641; Na+ activates -4121; 10-formyl-THMPT inhibits -662; Mg2+ activates -662; Mn2+ inhibits -662; and oxygen inhibits -702. The extra Regulation class is not an eighth instance. Abstracts corroborate only selected effects; other details remain native-source assertions. They must not be broadened to every generic reaction or organism.

Native cofactor conflicts remain explicit. Mo/W Fmd activities have separate cofactors; the Mo cyanide result must not transfer to W. Old single-MGD wording is not automatically reconciled with the native bis-pterin compound. Mtr complex prose names only a cobamide prosthetic group while its activity also asserts FeS. Hmd historical absence of Ni/FeS/flavins is not evidence of absent iron cofactor. Its native four-subunit assertion is retained, not silently replaced by a newer assembly from a different organism.

## Primary reading and supported limits

Kurth et al. 2021 (PMID 34145392; DOI 10.1038/s41396-021-01025-6) is the freshly acquired full primary study. All 17 main-text PDF pages were read; all five figures were visually inspected. The complete supplementary DOCX body and seven embedded figures were read/inspected. Table S3 was read in full; S1 and S2 were read only at the exact rows recorded in PRIMARY-READING.md. All spreadsheet cells were extracted, which is not the same as reading every row.

The study experimentally supports an Mto demethylation system and expression context in Methermicoccus shengliensis. It does not provide a purified eight-subunit Mtr sodium-pumping experiment. Its MtoA acceptor assay uses H4F as a surrogate and a CoM negative control; H4MPT is the physiological interpretation. MtoA and MtrH are different gene products. The Mtr-centered energy model is explicitly hypothetical. These qualifications constrain the native ENZRXN2065-393 experimental tag; the tag remains source metadata.

Fourteen complete PubMed abstracts were freshly read and bound to the NCBI XML original. They offer narrower support for Fmd substrate/cofactor behavior, Hmd, Ftr, Mch, Mer and Mtr properties, but do not replace full methods, figures or assays. Vorholt/Thauer 1997 and Kaster 2011 full originals remain access gaps. Kaster's previously recorded partial main-text reading is reused only at that exact scope; no complete main/SI reading is asserted. PMID 20221540 is a modern iron-site lead in M. jannaschii, not an exact native-catalyst mapping.

The root commentary's general methyl-CoM disproportionation and membrane methanophenazine narrative must not become universal H2/CO2-route assertions. The six native members, source association evidence, and context-specific primary experiments are different scopes. A native pathway-level experimental tag citing the Fmd substrate study does not establish a whole-route experiment.

Twenty claim dispositions, 15 activity dispositions, all seven regulation rows, 23 reading scopes, and 11 unresolved prerequisites provide the review handoff. Open prerequisites are not automatically defects in a qualified source-only representation. They do limit stronger chemistry, physiological, taxonomic and mechanistic claims.
