# Primary reading receipt

The authoritative per-source hashes and exact scopes are results/primary-reading-scopes.json. Fresh abstract extraction is reading/selected-pubmed-abstracts.json. Failed accesses are retained with status/body hashes in results/acquisition-attempt-ledger.json and receipts/.

## Fresh full study

Kurth2021 original PDF: originals/primary/kurth2021.pdf, SHA256 f15d78d1ccca763d30f0ba74eb5f1867688623a4e6833c05373ff056811d008b, 2,955,798 bytes, retrieved from https://www.nature.com/articles/s41396-021-01025-6.pdf. Complete text reading includes all 17 pages, methods, results, discussion and references. All pages were rendered with the existing PDFKit reader. Visual figure inspection used pages 8 (Figure 1), 10 (Figures 2–3), 11 (Figure 4) and 13 (Figure 5). This is not a claim that every nonfigure page was separately inspected visually.

All four publisher supplements were acquired from links in the original publisher HTML. The DOCX body text, supplementary results, seven captions and references were read fully, and all seven original embedded images were visually inspected. No DOCX page-layout rendering is claimed. Spreadsheet original cell extraction used the already installed openpyxl runtime:

- Table S1: 195 rows × 33 columns extracted. Deliberately read rows 1–5, 25–32 and 38–47 (23 rows), including headers, exact eight Mtr subunits and the relevant C1 enzyme entries. A later broad footer probe printed rows 48–96 with truncation; it is not a complete-sheet reading receipt. No inferred meaning for p* versus p** beyond the paper's methods is used here.
- Table S2: 1,643 rows × 23 columns extracted. Read rows 1–5, 25 and 57–65 (15 rows), including MtoA, eight Mtr subunits and the adjacent row returned by the selection. Other protein rows are retained but not scientifically reviewed.
- Table S3: all 40 rows × 8 columns read, including blank rows. Authors' thermodynamic assumptions are not independently validated.

The principal experimental context is methanol versus aromatic methoxy compounds in AmaM and ZC-1. Native MtoA/MtoB purification and heterologous MtoC/MtoD are distinct roles. MtoA uses an H4F surrogate in the assay; no exact H4MPT rate should be invented. Native Mtr annotations and expression rows do not turn the theoretical energy model into isolated Mtr activity or sodium-stoichiometry measurements. All claims are paraphrased and bounded in the claim ledger rather than reproduced as article passages.

## Fresh abstract-only readings

The NCBI original selected-pubmed.xml is 153,223 bytes, SHA256 a7594bb3cea7d15bf6afaa53a756016b6e592daaa297410a7faff97871c1c260. All returned abstract paragraphs and identities were read for PMIDs 9342247, 21262829, 1521540, 8522533, 10215859, 8477726, 3782039, 3097011, 2253782, 8125106, 7737157, 7649177, 34145392 and 20221540. Exact titles and DOIs are retained. Apart from Kurth2021, no full article reading is implied by these rows.

Vorholt/Thauer1997: native pathway evidence cites PMID9342247, DOI10.1111/j.1432-1033.1997.00919.x. The abstract supports CO2 rather than bicarbonate as the enzyme substrate and a proposed N-carboxymethanofuran intermediate in M. barkeri. Authentic full main/figures were not acquired; the Wiley failure is retained.

Kaster2011: PMID21262829, PMC3041090, DOI10.1073/pnas.1016761108. Fresh NCBI abstract and institutional metadata were read. The PMC efetch response explicitly excludes full XML; public publisher/repository attempts failed or presented challenges. No authentic new full main or supplementary file was acquired. Earlier preflight partial main reading is reused only as specified in inputs/preflight/PRIMARY-READING.md. It concerns MvhADG/HdrABC electron bifurcation in M. marburgensis, outside the six source members. An abstract-level ATP consistency argument is not a measured six-member energy yield.

Other attempted historical full originals—Hmd1992, Mer1995, Mch1986, Ftr1986 and Pomper1999—remain unsuccessful/limited accesses. A .pdf suffix on a saved HTTP403 body does not make it a PDF. The Mer PMC200 body is a challenge; its efetch XML is metadata/abstract only. Exact full-paper leads remain in the unresolved ledger rather than being declared exhausted.

## Native reading versus machine coverage

The complete six reaction definitions and 15 own activity records were read, including their evidence, directions, assays and cofactors. Selected own biological fields/comments for all catalyst/component proteins, genes, real regulations, organisms and material identity records were inspected using the retained cards and exact ledgers. All direct slots and nested references were mechanically retained. That does not assert a human literal reading of every large unrelated backlink, every embedded annotation, or all 34,996 reference occurrences. Broad truncated tool outputs were followed by targeted bounded reads; truncation is not a completion receipt.
