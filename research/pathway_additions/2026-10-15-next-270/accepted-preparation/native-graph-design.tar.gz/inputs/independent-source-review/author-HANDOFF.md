# Frozen source preparation: next270 METHANOGENESIS-PWY

Owner: /private/tmp/pathwaymech-next-270-methanogenesis-source-preparation

Disposition: ready for bounded independent source/evidence review. This is not independent acceptance, a maintained record, an authority implementation, or approval of complete methane flux. No maintained/Git/GitHub/runtime edits were made. All acquisition/render/verification jobs are terminal. Do not modify this packet; any correction belongs in a new successor owner.

## Inputs and exact scope

The unchanged discovery predecessor is /private/tmp/pathwaymech-next-270-discovery, manifest SHA256 357c7c297bd3952e76ccd3386f4e518e98a83d0d7b989a7f3710ef54082e6621; HANDOFF dad3d91880e37e9065599c9c2253230530ae21a3e0d3bb308c719888821a8c1e; freeze ba5efefad2956510d025e8cdc54b621470a089684411a29f83a9c077a3b41044. All 63 physical predecessor files and all 22 selected source/copy bindings passed final unchanged-input checks.

The copied root original is SHA256 35e06e69cc42fe911cee1f6e33ddd950628d24bcb45a2807878099dd8dae43c8, 28,899 bytes. Its actual acquisition URL is https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:METHANOGENESIS-PWY. Literal XML base metadata is preserved and is not the correct clickable acquisition URL.

The baseline remains the actual merged 265-record state 7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105, tree 1a0560c741c07fcb7878b1e93d8d38da67b1287c, with pending PWY-5177 excluded. A later actual merged-baseline rebind is still required before maintained work. Prior hidden/ignored duplicate and finite compressed-history search limits remain as stated in the discovery packet; no fresh global absence or exhaustion claim is made here.

## Delivered evidence

- 177 full native objects including the root, or 176 closure objects excluding it: 175 fresh successful originals plus one verified prior sodium reuse. All six member reactions, 30 material occurrences/18 material IDs, 15 activities/15 direct catalysts, 43 component occurrences, 45 genes, seven real regulations and 12 organism contexts are retained. Three taxa are direct pathway associations; the phylum range is separate. METHFORM is boundary-only.
- 70 initial direct occurrences and 334 selected biological forward-reference occurrences all resolve. The entire 2,061 own-slot and 34,996 frame-reference inventories are retained, with finite closure exclusions explicit. There is no claim to expand every backlink, class member, feature, publication, taxonomic ancestor or commentary hyperlink.
- Complete Kurth2021 main text and all five figures, complete supplementary DOCX text and all seven embedded figures, full Table S3, selected S1/S2 rows; 14 complete PubMed abstracts. Exact reading scopes and source hashes are retained. Extraction of all spreadsheet cells does not mean all rows were read.
- Twenty bounded claim dispositions, 15 activity dispositions, all exact regulation targets, material warnings, source-specific taxon roles and 11 open prerequisites. All are author preparation for independent review.
- Two hundred network attempts plus one reuse receipt, returned failure bodies, selected web discovery outputs, exact plans/scripts and operations limitations. Source requests use HTTPS; XML metadata remains unchanged.
- 1,126 author verification checks passed, including full predecessor/input integrity, exact native envelopes, direct/forward closure, hand-enumerated member/order/Na/direction/taxon/regulation controls, signed-net replay and deterministic ledger reproduction.

## Required scientific qualifications

1. This six-member source definition stops at methyl-CoM. Methane formation and electron-carrier regeneration are outside membership. The source's generalized disproportionation and membrane electron-transport commentary is not accepted as universal physiological behavior.
2. Mtr explicitly transports 2 Na+ from inside to outside. Unlocated carrier terms cannot silently be assigned to the same compartment. The retained net is formal arithmetic, not full atom/charge balance, energy yield or flux.
3. Hmd/H2 is the native fourth reaction. Mtd/F420 in the Kurth context is a different alternative. Both Mch activity directions conflict with the root layout and remain visible.
4. Native generic methanofuran/F420/ferredoxin classes, eight [R]-containing SMILES, and the H2 [H] string prevent automatic identity mapping. No issuing ChEBI/Rhea/KEGG, CML stereochemistry, current taxonomy, protein accession or strain equivalence is approved here.
5. Historical Marburg/delta-H context, Hmd cofactor/assembly language, and Mtr FeS versus only-cobamide prose remain unresolved. All three direct pathway taxa are explicitly distinguished from shared-catalyst context and the separate phylum range.
6. Kurth2021 assays Mto, with an H4F surrogate for MtoA, and provides expression context; its Mtr energy scheme is hypothetical. It does not establish a purified native Mtr sodium-stoichiometry assay. Native EV-EXP-IPI remains source metadata rather than a broader experimental claim.
7. Authentic Vorholt1997 full main and Kaster2011 full main/SI were not acquired. Fresh abstracts and inherited partial Kaster reading are labeled at their actual depth. Other historical primary gaps remain explicit. No inaccessible source was bypassed or invented.

## Review entry points

Read ASSESSMENT.md, PRIMARY-READING.md and OPERATIONS.md, then results/claim-dispositions.json and results/activity-dispositions.json. Exact source/equation coverage is in native-object-inventory.json, native-direct-slot-ledger.json, member-equations.json, member-material-occurrences.json, complex-components.json, regulation-ledger.json and taxon-ledger.json under results/. Primary scopes, unresolved prerequisites, access attempts and verification each have separate JSON ledgers. REPRODUCE.md explains safe replay in a new owner.

The final artifact-manifest.json recursively inventories every physical file except itself and freeze-proof.json, including hidden/ignored content. freeze-proof.json binds the manifest, this HANDOFF and final counts. No unmanifested extra file or running job is part of the handoff. Reported hashes/counts are emitted only after final freeze verification.
