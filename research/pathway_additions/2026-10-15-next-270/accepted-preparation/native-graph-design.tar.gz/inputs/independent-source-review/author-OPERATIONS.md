# Operations and limits

Owner was created only after an actual existence check including hidden/ignored entries. All writes are inside this new scratch owner. No maintained worktree, Git/GitHub, runtime installation/repair, source packet or authority cache was changed. Existing Python263 runtime was run with -B and user-site/bytecode disabled. The previously compiled PDFKit reader was copied and hash-bound; no compiler or PDF package was installed.

Two hundred network request receipts plus one verified reuse receipt are preserved. They include 177 native requests (175 successful; encoded-sodium404 and literal-sodium connection reset), 23 primary access attempts, and the sodium reuse. Every returned body is retained at its exact hash, including unsuccessful HTML bodies. The timeout attempt for an institutional Kurth PDF produced no file; a later distinct publisher request successfully wrote the planned output. The failed sodium request similarly produced no bytes before verified reuse. Those later files are not attributed to the failed attempts.

The sodium original was copied from the frozen next269 source-completion packet after verifying its manifest row and bytes. Its provenance and actual HTTPS URL are in receipts/reuse-NA+.json. No fresh sodium retrieval is claimed. The root definition is copied from the frozen next270 discovery packet. All other successful native requests are fresh. Literal XML base URLs are retained as source metadata; future clickable references must use the actual successful HTTPS acquisition URLs, not the broken http:443 metadata form.

Bounded web search/open outputs are preserved separately in receipts/web-search-and-open-results.json. They contain discovery snippets and incidental unrelated results, none of which establishes full-primary reading. One search return was accidentally stored as boolean true (priority_fulltext_search_last270); that raw return is not retained and no complete web-transcript preservation is claimed. All scripted network attempts have their receipts.

Preserved failures/limitations:

- Initial ledger derivation assumed one Reaction per reaction-list slot, but the root has six siblings. It failed before writing ledgers; results/ledger-first-attempt.json retains the failure. Corrected replay passes.
- Initial regex HTML stripping mangled nested hyperlink attributes. The original version is retained as scripts/catalog-initial-regex.py; the current catalog uses HTMLParser. Exact original XML was never edited.
- One initial governance-path read used an incorrect path; the actual copied add-pathway skill was subsequently read in full. No nonexistent-skill assertion was made.
- Multiple broad read outputs were truncated. Final reading claims are confined to complete targeted outputs or the exact full-paper scope, not those truncated outputs.
- PDFKit emitted a CoreGraphics diagnostic while rendering. All 17 page images and text completed; relevant figure images were inspected. This is retained as a warning, not silently treated as a failed whole render or as perfect visual QA.
- No full primary was inferred from HTTP200 alone, a filename suffix, abstract, search snippet or native experimental tag.

Observed execution handles 83129,59126,95433,93862,80100,84933,73484,8422,36269 and12394 all reached terminal output in the session. Later final primary probes, assessment construction and verification also exited normally. No acquisition or rendering job remains running at release. This statement concerns this owner's jobs, not unrelated agents' work.

All 22 copied input bindings and every one of the 63 physical files of the frozen discovery packet were checked again at completion. The selected original/source and receipt checks pass. The 1,126 verification checks are author checks, not independent scientific acceptance. Replaying the same extraction implementation demonstrates reproducibility, not independent proof of biology.
