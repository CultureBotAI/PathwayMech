import collections,hashlib,json,re
from pathlib import Path
from xml.etree import ElementTree as E
A=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation');O=Path(__file__).resolve().parent;checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((A/'results'/f'{n}.json').read_text())
def ck(v,s):assert v,s;checks.append(s)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
inv=load('native-object-inventory');obj={r['frame']:E.parse(A/r['path']).getroot()[1] for r in inv};paths={r['path'] for r in inv};root=obj['METHANOGENESIS-PWY'];direct=[]
for rxn in root.findall('reaction-list/Reaction'):
 f=rxn.get('frameid');n=obj[f]
 for side in ['left','right']:
  for i,s in enumerate(n.findall(side),1):
   x=s[0];comp=s.find('compartment/cco');direct.append({'owner':f,'slot':f'{side}[{i}]','type':x.tag,'frame':x.get('frameid'),'role':'equation-material','coefficient':s.findtext('coefficient','1'),'compartment':comp.get('frameid') if comp is not None else None})
   if comp is not None:direct.append({'owner':f,'slot':f'{side}[{i}]/compartment','type':comp.tag,'frame':comp.get('frameid'),'role':'equation-location'})
 for x in n.findall('enzymatic-reaction/Enzymatic-Reaction'):
  a=x.get('frameid');direct.append({'owner':f,'slot':'enzymatic-reaction','type':x.tag,'frame':a,'role':'member-linked-activity'});en=obj[a].find('enzyme')[0];direct.append({'owner':a,'slot':'enzyme','type':en.tag,'frame':en.get('frameid'),'role':'member-linked-catalyst'})
for side,role in [('species','direct-pathway-species'),('taxonomic-range','pathway-taxonomic-range')]:
 for s in root.findall(side):
  x=s[0];direct.append({'owner':'METHANOGENESIS-PWY','slot':side,'type':x.tag,'frame':x.get('frameid'),'role':role})
expected=load('direct-occurrences');# Exact role strings are author provenance labels; compare source-bearing fields independently.
def semantic(r):return tuple((k,r.get(k)) for k in ['owner','slot','type','frame','coefficient','compartment'])
ck(collections.Counter(map(semantic,direct))==collections.Counter(map(semantic,expected)) and len(direct)==70,'70 direct source occurrences exact')
ck(all(r['frame'] in obj and obj[r['frame']].tag==r['type'] for r in direct),'all70 direct target types resolved')
# Every receipt is internally bound; successful native receipts exactly cover175 originals.
attempts=load('acquisition-attempt-ledger');ck(len(attempts)==201,'200network+1reuse receipts');success=[]
for a in attempts:
 p=A/a['receipt'];ck(sha(p)==a['receipt_sha256'],'receipt bytes '+a['receipt'])
 if a['bytes'] is not None and a['sha256'] is not None:
  p=A/a['output'];ck(p.exists() and p.stat().st_size==a['bytes'] and sha(p)==a['sha256'],'returned body preserved '+a['receipt'])
 if a['kind']=='native request' and a['status']==200 and a['error'] is None:
  success.append(a);f=E.parse(A/a['output']).getroot()[1].get('frameid');ck(a['url']==a['final_url']=='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+f,'successful actual native query '+f)
ck(len(success)==175 and {a['output'] for a in success}==paths-{'inputs/preflight/originals/META-METHANOGENESIS-PWY.xml','originals/native/META-NA+.xml'},'175 fresh native source originals exactly')
physical={str(p.relative_to(A)) for p in (A/'originals/native').glob('*.xml')};extra=physical-paths;ck(extra=={'originals/native/META-NA%2B.xml'},'only extra native suffix file is retained failed encoded sodium body');bad=next(a for a in attempts if a['output']=='originals/native/META-NA%2B.xml');ck(bad['status']==404 and 'Not found' in (A/bad['output']).read_text(),'failed encoded sodium response not promoted')
# Read exact native chemical strings without asserting chemistry equivalence.
materials=load('material-identity-source-ledger');warn=[]
for r in materials:
 n=obj[r['frame']];m=n.find('cml/molecule');sm=m.findtext("string[@title='smiles']") if m is not None else None;fo=m.find('formula') if m is not None else None
 ck(r['smiles']==sm and r['inchi']==n.findtext('inchi') and r['inchi_key']==n.findtext('inchi-key') and r['formula_concise']==(fo.get('concise') if fo is not None else None) and r['cml_formal_charge']==(m.get('formalCharge') if m is not None else None),'chemical source strings '+r['frame'])
 if sm and '[R]' in sm:warn.append(r['frame'])
ck(set(warn)=={'CPD-7162','CoM','Formyl-methanofurans','METHYL-THMPT','Me-CoM','Methanofurans','Oxidized-Factor-F420','Reduced-Factor-F420'},'eight literal R-SMILES warnings')
ck(len([f for f in warn if obj[f].get('class')!='true'])==4,'four nonclass R warnings')
ck(obj['HYDROGEN-MOLECULE'].findtext("cml/molecule/string[@title='smiles']")=='[H]' and obj['HYDROGEN-MOLECULE'].find('cml/molecule/formula').get('concise')=='H 2','H2 source discrepancy exact')
# Bind exact experimental figure/method locators and record the required correction, not change author data.
t=(O/'kurth-replay/complete-text.txt').read_text();pages={int(k):s for k,s in re.findall(r'\[PDF PAGE (\d+)\]\n(.*?)(?=\n\[PDF PAGE |\Z)',t,flags=re.S)}
ck('Enzyme activity assays' in pages[6] and 'MtoA activity was determined' in pages[6] and 'H4F (Schircks' in pages[7] and '1.7 mM CoM' in pages[7],'MtoA Methods atPDF6–7')
ck('Fig. 3 Demethylation and demethoxylation pathways' in pages[10] and 'Fig. 4 O-demethylation and methyl transfer conducted by Mto' in pages[11],'Fig3schematic Fig4experiment exact')
ck('H4MPT structural analog H4F' in pages[11] and 'no speci c activity value for MtoA' in pages[12],'assay qualification atPDF11–12')
claim=next(r for r in load('claim-dispositions') if r['id']=='N270-S15');ck(claim['primary_scope']==['Kurth2021 main Methods pp.4–5 and Results pp.9–11, Fig.3; supplement Fig.S2'],'exact oldS15locator reproduced')
find={'id':'N270-R01','severity':'minor','status':'requires separate locator successor','owner':'results/claim-dispositions.json','selector':'N270-S15.primary_scope[0]','before':claim['primary_scope'][0],'recommended_after':'Kurth2021 main Enzyme activity assays, PDF pp.6–7 (printed3554–3555); Results and Fig.4 reactionC/caption, PDF pp.11–12 (printed3559–3560); supplementary Fig.S2B and caption.','reason':'Current Methods page range excludes the methyl-acceptor assay and Fig.3 is a tentative pathway schematic. Fig.4 and S2B contain the experiment. Scientific claim and limitations are supported and need not change.','primary_original':'originals/primary/kurth2021.pdf','primary_sha256':sha(A/'originals/primary/kurth2021.pdf'),'claim_ledger_sha256':sha(A/'results/claim-dispositions.json'),'acceptance':'Successor changes only the inaccurate locator scalar and reproducible generator if retained as current; keep all20 claim bodies, other fields, original/source hashes, native ledgers and prior packet immutable.'}
save('findings.json',[find]);save('supplemental-check-list.json',checks);save('supplemental-results.json',{'status':'pass','checks':len(checks),'direct_occurrences':len(direct),'fresh_native_sources':len(success),'attempts':len(attempts),'extra_failed_native_bodies':sorted(extra),'material_warnings':warn,'findings':1});print(json.dumps({'status':'pass','checks':len(checks),'findings':1}))
