import collections,hashlib,json,re,zipfile
from pathlib import Path
from xml.etree import ElementTree as E
from openpyxl import load_workbook
A=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation');O=Path(__file__).resolve().parent;checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((A/'results'/f'{n}.json').read_text())
def ck(v,s):assert v,s;checks.append(s)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sig(x):return (x.tag,tuple(sorted(x.attrib.items())),x.text if x.text and x.text.strip() else None,tuple(sig(y) for y in x))
# Independently parse every physical original and literal own-slot projection.
inventory=read('native-object-inventory');paths=sorted([A/r['path'] for r in inventory if r['frame']!='METHANOGENESIS-PWY'])+[A/'inputs/preflight/originals/META-METHANOGENESIS-PWY.xml'];objects={};roots={};byid={r['frame']:r for r in inventory};slots=read('native-direct-slot-ledger');slotmap={(r['owner'],r['index']):r for r in slots};refs=[];counts=collections.Counter();sourcebindings=[]
for p in paths:
 root=E.parse(p).getroot();entities=[n for n in root if n.tag!='metadata'];ck(len(entities)==1,'one full object '+p.name);n=entities[0];f=n.get('frameid');ck(f not in objects,'unique native frame '+f);objects[f]=n;roots[f]=root;counts[n.tag]+=1
 ck(root.tag=='ptools-xml' and root.get('ptools-version')=='27.0' and root.findtext('metadata/query')=='META:'+f and root.findtext('metadata/num_results')=='1' and n.get('detail')=='full' and n.get('orgid')=='META' and n.get('ID')=='META:'+f,'exact native envelope '+f)
 r=byid[f];ck(r['path']==str(p.relative_to(A)) and r['sha256']==sha(p) and r['bytes']==p.stat().st_size and r['direct_slot_count']==len(n) and r['type']==n.tag and r['class']==(n.get('class')=='true'),'inventory literal '+f);sourcebindings.append(r)
 for i,s in enumerate(n,1):
  r=slotmap[(f,i)];ck(r['tag']==s.tag and sig(E.fromstring(r['xml']))==sig(s),'own slot exact '+f+':'+str(i))
  ns=[x for x in s.iter() if x.get('frameid')];ck(r['reference_count']==len(ns),'slot reference count '+f+':'+str(i))
  for j,x in enumerate(ns,1):refs.append((f,i,s.tag,j,x.tag,x.get('frameid'),tuple(sorted(x.attrib.items())),x.get('frameid') in byid))
ck(len(objects)==177 and dict(counts)=={'Reaction':6,'Protein':59,'Gene':45,'Compound':26,'cco':4,'Enzymatic-Reaction':15,'Pathway':2,'Regulation':8,'Organism':12},'177 exact object types')
reported=read('native-reference-occurrences');rs=[(r['owner'],r['slot_index'],r['slot'],r['ordinal'],r['type'],r['frame'],tuple(sorted(r['attributes'].items())),r['resolved_in_finite_packet']) for r in reported];ck(collections.Counter(refs)==collections.Counter(rs) and len(refs)==34996,'all34996 reference occurrences exact');ck(len(slots)==2061,'all2061 own slots')
# Reconstruct selected forward closure independently from actual field ownership.
follow={'Protein':{'component','gene','species','locations','location','cofactor','prosthetic-group','modified-form','unmodified-form'},'Enzymatic-Reaction':{'cofactor','regulated-by','enzyme'},'Regulation':{'regulator','regulated-entity'},'Gene':{'product','species'}}
forward=[]
for f,n in objects.items():
 if n.get('class')=='true':continue
 for i,s in enumerate(n,1):
  if s.tag not in follow.get(n.tag,set()):continue
  for x in s.iter():
   if x.get('frameid') and x.tag not in {'Publication','Evidence-Code','Person','Organization'}:forward.append((f,s.tag,i,x.get('frameid'),x.tag,x.get('frameid') in objects))
r=read('biological-forward-closure');ck(collections.Counter(forward)==collections.Counter((r['owner'],r['slot'],r['slot_index'],r['target'],r['target_type'],r['resolved']) for r in r) and len(forward)==334 and all(v[-1] for v in forward),'334 selected forward references all resolved')
root=objects['METHANOGENESIS-PWY'];members=[x.get('frameid') for x in root.findall('reaction-list/Reaction')];direction={x.find('Reaction').get('frameid'):x.findtext('direction') for x in root.findall('reaction-layout')};seq=['FORMYLMETHANOFURAN-DEHYDROGENASE-RXN','2.3.1.101-RXN','3.5.4.27-RXN','H2-METHYLENE-THMPT-DEHYDRO-RXN','METHELENE-THMPT-OXI-RXN','2.1.1.86-RXN'];ck(set(members)==set(seq) and len(members)==6,'six exact members');ck([direction[f] for f in seq]==['R2L','L2R','R2L','L2R','R2L','L2R'],'six route directions');order=[(p.get('frameid'),x.find('Reaction').get('frameid')) for x in root.findall('reaction-ordering') for p in x.findall('predecessor-reactions/Reaction')];ck(set(order)==set(zip(seq,seq[1:])) and len(order)==5,'five exact order links')
mat=[];acts=[];net=collections.Counter();located=collections.Counter();equations=[]
for f in members:
 n=objects[f];r=next(x for x in read('member-equations') if x['frame']==f);ck(r['source_direction']==n.findtext('reaction-direction') and r['pathway_direction']==direction[f],'equation directions '+f);eq={'reaction':f,'route':direction[f],'source':n.findtext('reaction-direction'),'left':[],'right':[]}
 for side in ['left','right']:
  terms=[]
  for i,s in enumerate(n,1):
   if s.tag!=side:continue
   x=s[0];c=s.find('compartment/cco');v={'frame':x.get('frameid'),'native_type':x.tag,'coefficient':int(s.findtext('coefficient','1')),'coefficient_explicit':s.find('coefficient') is not None,'compartment':c.get('frameid') if c is not None else None,'slot_index':i,'source_xml':E.tostring(s,encoding='unicode')};terms.append(v);mat.append(dict(v,reaction=f,side=side));eq[side].append({k:v[k] for k in ['frame','coefficient','compartment']});sgn=(-1 if side=='left' else 1)*(-1 if direction[f]=='R2L' else 1);net[v['frame']]+=sgn*v['coefficient'];located[(v['frame'],v['compartment'])]+=sgn*v['coefficient']
  ck(terms==r['terms'][side],'exact equation terms '+f+' '+side)
 aa=[x.get('frameid') for x in n.findall('enzymatic-reaction/Enzymatic-Reaction')];ck(aa==r['activity_ids'],'all native activity links '+f);acts.extend(aa);equations.append(eq)
ck(mat==read('member-material-occurrences') and len(mat)==30 and len({r['frame'] for r in mat})==18,'30 exact material occurrences18 IDs')
summary=read('native-closure-summary');ck({f:c for f,c in sorted(net.items()) if c}==summary['formal_compartment_collapsed_net'],'lossy formal net exact');ck([{'frame':f,'compartment':c,'coefficient':v} for (f,c),v in sorted(located.items(),key=str) if v]==summary['formal_compartment_retained_net'],'located formal net exact');ck(located[('NA+','CCO-IN')]==-2 and located[('NA+','CCO-OUT')]==2,'2Na transport not cancelled');ck(located[('METHYL-THMPT',None)]==1 and located[('METHYL-THMPT','CCO-IN')]==-1 and located[('THMPT',None)]==-1 and located[('THMPT','CCO-IN')]==1,'unknown compartments not unified')
dispositions=read('activity-dispositions');ck(len(acts)==len(set(acts))==len(dispositions)==15 and set(acts)=={r['activity'] for r in dispositions},'all15 activity dispositions');actinfo=[]
for f in acts:
 n=objects[f];r=next(x for x in dispositions if x['activity']==f);enzyme=n.find('enzyme/Protein').get('frameid');taxa=[s[0].get('frameid') for s in objects[enzyme].findall('species')];ck(r['reaction']==n.find('reaction/Reaction').get('frameid') and r['enzyme']==enzyme and r['native_direction']==n.findtext('reaction-direction') and r['source_species']==taxa,'native activity disposition '+f);actinfo.append({'activity':f,'enzyme':enzyme,'taxa':taxa,'direction':n.findtext('reaction-direction'),'cofactors':[s[0].get('frameid') for s in n.findall('cofactor')],'evidence':[s[0].get('frameid') for s in n.findall('evidence')],'comment':[s.text for s in n.findall('comment')]})
ck(all(objects[f].find('evidence') is None and objects[f].find('reaction-direction') is None for f in acts if f.startswith('ENZRXN26TB-')),'five Archaeoglobus activities no own evidence/direction');ck(objects['ENZRXN-662'].findtext('reaction-direction')==objects['ENZRXN-4121'].findtext('reaction-direction')=='PHYSIOL-LEFT-TO-RIGHT' and direction['3.5.4.27-RXN']=='R2L','Mch source directions conflict preserved')
components=[]
for f,n in objects.items():
 if n.tag=='Protein':
  for i,s in enumerate(n,1):
   if s.tag=='component':components.append({'complex':f,'component':s[0].get('frameid'),'coefficient_literal':s.findtext('coefficient'),'slot_index':i,'source_xml':E.tostring(s,encoding='unicode')})
ck(components==read('complex-components') and len(components)==43,'43 literal component occurrences')
reg=[]
for f,n in objects.items():
 if n.tag=='Regulation' and n.get('class')!='true':reg.append((f,n.findtext('mode'),n.find('regulator')[0].get('frameid'),n.find('regulated-entity')[0].get('frameid'),n.findtext('physiologically-relevant'),n.findtext('mechanism')))
ck(set(reg)=={(r['frame'],r['mode'],r['regulator'],r['target_activity'],r['physiologically_relevant'],r['mechanism']) for r in read('regulation-ledger')} and len(reg)==7,'seven real regulations exact')
ck({(x[1],x[2],x[3]) for x in reg}=={('-','HCN','ENZRXN-422'),('-','HCN','ENZRXN-641'),('+','NA+','ENZRXN-4121'),('-','CPD-19570','ENZRXN-662'),('+','MG+2','ENZRXN-662'),('-','MN+2','ENZRXN-662'),('-','OXYGEN-MOLECULE','ENZRXN-702')},'seven hand-enumerated scoped effects')
for r in read('taxon-ledger'):
 n=objects[r['frame']];ck((r['name'],r['rank'],r['strain_name'])==(n.findtext('common-name'),n.findtext('rank'),n.findtext('strain-name')),'taxon literal rank '+r['frame'])
ck([x[0].get('frameid') for x in root.findall('species')]==['TAX-2208','TAX-145262','TAX-2179'] and objects['TAX-2179'].findtext('rank')=='genus','three direct associations incl genus')
# Every claim-native locator uses exact own-object, not embedded-only or guessed positions.
for r in read('claim-dispositions')+dispositions:
 for loc in r.get('native_locators',r.get('native_source',[])):
  n=objects[loc['frame']];ck(sha(A/loc['path'])==loc['sha256'] and list(n)[loc['one_based_slot']-1].tag==loc['slot'],'native claim locator '+r.get('id',r.get('activity'))+':'+loc['frame']+':'+str(loc['one_based_slot']))
# Rebind machine-retained biological abstracts to full authoritative XML text.
xml=E.parse(A/'originals/primary/selected-pubmed.xml').getroot();abstracts=json.loads((A/'reading/selected-pubmed-abstracts.json').read_text());ck(len(abstracts)==14,'14 complete abstract entries')
for r in abstracts:
 n=next(n for n in xml.findall('PubmedArticle') if n.findtext('MedlineCitation/PMID')==r['pmid']);texts=[{'label':x.get('Label'),'text':''.join(x.itertext())} for x in n.findall('MedlineCitation/Article/Abstract/AbstractText')];ck(texts==r['abstract'],'original complete abstract '+r['pmid']);ck(''.join(n.find('MedlineCitation/Article/ArticleTitle').itertext())==r['title'],'original title '+r['pmid'])
# DOCX is read directly as OOXML and every viewed figure is rebound to an original ZIP member.
z=zipfile.ZipFile(A/'originals/primary/kurth2021-supp1.docx');ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'};d=E.fromstring(z.read('word/document.xml'));paras=[''.join(x.itertext()) for x in d.findall('.//w:t',ns)];ret=(A/'reading/kurth-supplements/supp1-text.txt').read_text();norm=lambda s:re.sub(r'\s+','',s);ck(norm(''.join(paras))==norm(ret),'full DOCX body text original')
media=[]
for n in z.namelist():
 if n.startswith('word/media/') and not n.endswith('/'):
  p=A/'reading/kurth-supplements'/Path(n).name;ck(z.read(n)==p.read_bytes(),'original supplementary figure '+n);media.append({'member':n,'sha256':sha(p)})
ck(len(media)==7,'seven original supplement figures')
# Only bounded rows are scientifically read; all-sheet extraction equivalence is mechanical.
sheets=[]
for num,table in [(2,'TableS1'),(3,'TableS2'),(4,'TableS3')]:
 p=A/'originals/primary'/f'kurth2021-supp{num}.xlsx';w=load_workbook(p,read_only=True,data_only=True);s=w.worksheets[0];chosen=json.loads((A/'reading/kurth-supplements'/f'supp{num}-selected-reading.json').read_text());rows={i:{str(j):v for j,v in enumerate(row,1) if v is not None} for i,row in enumerate(s.iter_rows(values_only=True),1)}
 for r in chosen:ck(rows[r['xlsx_row']]==r['cells'],'selected original '+table+' row'+str(r['xlsx_row']))
 sheets.append({'source':str(p.relative_to(A)),'sha256':sha(p),'table':table,'rows':s.max_row,'columns':s.max_column,'reviewed_rows':[r['xlsx_row'] for r in chosen]});w.close()
ck([len(s['reviewed_rows']) for s in sheets]==[23,15,40],'bounded spreadsheet reading denominator')
# Successful PDF replay is byte-identical for complete text and all17 original render outputs.
ck((O/'kurth-replay/complete-text.txt').read_bytes()==(A/'reading/kurth2021/complete-text.txt').read_bytes(),'independent PDF extraction complete17pages exact')
for i in range(1,18):ck(sha(O/'kurth-replay'/f'page-{i:03}.png')==sha(A/'reading/kurth2021'/f'page-{i:03}.png'),'fresh PDF page render exact '+str(i))
save('native-equation-projection.json',equations);save('activity-independent-projection.json',actinfo);save('native-original-bindings.json',sourcebindings);save('spreadsheet-reading-scope.json',sheets);save('supplement-figure-bindings.json',media);save('check-list.json',checks);save('check-results.json',{'status':'pass','checks':len(checks),'objects':len(objects),'slots':len(slots),'frame_references':len(refs),'selected_forward_occurrences':len(forward),'material_occurrences':len(mat),'activities':len(acts),'components':len(components),'real_regulations':len(reg),'primary_abstracts':len(abstracts),'pdf_pages':17,'supplement_figures':7,'scientific_findings_separate':True});print(json.dumps({'status':'pass','checks':len(checks)}))
