from pathlib import Path
import hashlib,json,shutil
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sets=[('/private/tmp/pathwaymech-next-270-independent-source-closure-review','a64814d2b73ce4f5399704f087a816be51bae880fc448f13ec231a935d6812fe','source-review',['HANDOFF.md','REVIEW.md','findings.json']),('/private/tmp/pathwaymech-next-270-source-locator-correction','d5f86a9308a10e1537f23a9bf0620445823bc2be05f53c85a0d71736c2b3f22b','locator-correction',['HANDOFF.md','after/claim-dispositions.json']),('/private/tmp/pathwaymech-next-270-source-locator-independent-acceptance','ef8ceb23771aae539748233f9f0099cfe14e363606d1bcfccacbe3c457597caf','locator-acceptance',['HANDOFF.md','RESULT.json'])]
rows=[];cp=[]
for path,h,name,select in sets:
 p=Path(path);assert sha(p/'artifact-manifest.json')==h;mf=json.loads((p/'artifact-manifest.json').read_text());expected={x['path'] for x in mf['files']}|{'artifact-manifest.json','freeze-proof.json'};actual={str(q.relative_to(p)) for q in p.rglob('*') if q.is_file()};assert expected==actual,(path,expected^actual)
 for x in mf['files']:assert sha(p/x['path'])==x['sha256'] and (p/x['path']).stat().st_size==x['bytes'],x
 inv=[{'path':str(q.relative_to(p)),'sha256':sha(q),'bytes':q.stat().st_size} for q in sorted(p.rglob('*')) if q.is_file()];rows.append({'root':path,'manifest_sha256':h,'physical':len(inv),'files':inv})
 d=R/'inputs'/name;d.mkdir(exist_ok=False)
 for rel in select+['artifact-manifest.json','freeze-proof.json']:
  src=p/rel;dst=d/Path(rel).name;shutil.copyfile(src,dst);cp.append({'source':str(src),'copy':str(dst.relative_to(R)),'sha256':sha(src),'bytes':src.stat().st_size})
(R/'inputs/review-packets-intake.json').write_text(json.dumps(rows,indent=2)+'\n');(R/'inputs/additional-copied-bindings.json').write_text(json.dumps(cp,indent=2)+'\n')
print([(x['root'],x['physical']) for x in rows],len(cp))
