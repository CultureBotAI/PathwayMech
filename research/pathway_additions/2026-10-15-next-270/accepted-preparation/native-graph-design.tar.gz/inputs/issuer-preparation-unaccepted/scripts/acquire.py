from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import sys
import urllib.request
import urllib.error
import time

O = Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
jobs = json.loads((O / sys.argv[1]).read_text())


def get(j):
    r = dict(j)
    r['started_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = O / 'originals' / j['file']
    assert not p.exists()
    if 'eutils.ncbi.nlm.nih.gov' in j['url']:
        time.sleep(0.4)
    try:
        with urllib.request.urlopen(urllib.request.Request(j['url'], headers={'User-Agent': 'PathwayMech bounded scientific source preparation'}), timeout=45) as response:
            b = response.read()
            r.update(status=response.status, final_url=response.url, headers=dict(response.headers))
    except urllib.error.HTTPError as e:
        b = e.read()
        r.update(status=e.code, final_url=e.url, headers=dict(e.headers), error=str(e))
    except Exception as e:
        b = None
        r['error'] = str(e)
    if b is not None:
        p.write_bytes(b)
        r.update(path=str(p.relative_to(O)), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
    r['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(j['file'], r.get('status'), r.get('bytes'), r.get('error', ''), flush=True)
    return r


with ThreadPoolExecutor(max_workers=int(sys.argv[2]) if len(sys.argv) > 2 else 4) as pool:
    results = list(pool.map(get, jobs))
p = O / 'receipts' / (Path(sys.argv[1]).stem + '.json')
assert not p.exists()
p.write_text(json.dumps(results, indent=2) + '\n')
