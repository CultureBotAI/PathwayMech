from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (R/'artifact-manifest.json').exists() and not (R/'freeze-proof.json').exists()
rows=[]
for p in sorted(R.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file():rows.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)})
m={'scope':'Frozen bounded author issuing-authority preparation for MetaCyc:METHANOGENESIS-PWY; no maintained curation or blanket identity acceptance.','files':rows,'listed_files':len(rows),'listed_bytes':sum(x['bytes'] for x in rows),'self_excluded':['artifact-manifest.json','freeze-proof.json']}
(R/'artifact-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
for x in rows:assert sha(R/x['path'])==x['sha256']
physical={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()};assert physical=={x['path'] for x in rows}|{'artifact-manifest.json'}
f={'frozen_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':sha(R/'artifact-manifest.json'),'HANDOFF_sha256':sha(R/'HANDOFF.md'),'listed_files':len(rows),'physical_files_including_self':len(rows)+2,'listed_bytes':sum(x['bytes'] for x in rows),'all_manifested_hashes_rechecked':True,'hidden_and_ignored_physical_inventory_included':True,'jobs_terminal':True,'self_excluded':['artifact-manifest.json','freeze-proof.json'],'source_unchanged_verification':'results/verification.json','verification_sha256':sha(R/'results/verification.json')}
(R/'freeze-proof.json').write_text(json.dumps(f,indent=2)+'\n');assert len([p for p in R.rglob('*') if p.is_file()])==len(rows)+2
print(json.dumps(dict(f,freeze_sha256=sha(R/'freeze-proof.json')),indent=2))
