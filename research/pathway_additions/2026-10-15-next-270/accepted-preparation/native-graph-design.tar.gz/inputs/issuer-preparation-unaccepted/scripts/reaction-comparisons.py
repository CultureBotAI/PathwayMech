from pathlib import Path
import collections,hashlib,json,re,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/'results'/n).write_text(json.dumps(x,indent=2)+'\n')
ns=json.loads((R/'inputs/source/results/member-equations.json').read_text());mats={x['frame']:x for x in json.loads((R/'inputs/material-candidates.json').read_text())}
rc=json.loads((R/'results/rhea-six-family-replay.json').read_text());RNS='http://rdf.rhea-db.org/'
rmap={'H2-METHYLENE-THMPT-DEHYDRO-RXN':'20018','2.1.1.86-RXN':'53493','METHELENE-THMPT-OXI-RXN':'21146','3.5.4.27-RXN':'19055','2.3.1.101-RXN':'18062','FORMYLMETHANOFURAN-DEHYDROGENASE-RXN':'19843'}
chemap={'FORMYL-THMPT':'58018','Formyl-methanofurans':'57727','Methanofurans':'58151','Oxidized-Factor-F420':'POLYMER:12939','Reduced-Factor-F420':'POLYMER:14378','Oxidized-ferredoxins':'GENERIC:10000','Reduced-ferredoxins':'GENERIC:10001'}
for f,m in mats.items():
 for x in m['xrefs']:
  if x['db']=='CHEBI' and f not in chemap:chemap[f]=x['id']
kmap={f:next((x['id'] for x in m['xrefs'] if x['db']=='LIGAND-CPD'),None) for f,m in mats.items()};kmap['Oxidized-Factor-F420']='C00876'
def native_terms(n,byframe=False):
 a={}
 for side in ['left','right']:
  a[side]=[{'id':t['frame'],'coefficient':t['coefficient'],'location':t['compartment']} for t in n['terms'][side]]
 if n['pathway_direction']=='R2L':a={'left':a['right'],'right':a['left']}
 return a
def signature(terms):
 c=collections.Counter()
 for t in terms:c[t['id']]+=t['coefficient']
 return dict(sorted(c.items()))
def parsed_kegg(p):
 s=p.read_text();eq=re.search(r'^EQUATION\s+(.*)$',s,re.M).group(1);a,b=eq.split(' <=> ');out={}
 for side,body in [('left',a),('right',b)]:
  out[side]=[]
  for z in body.split(' + '):
   m=re.fullmatch(r'(?:(\d+) )?(C\d+)(?:\s*\(([^)]+)\))?',z);assert m,z
   out[side].append({'id':m[2],'coefficient':int(m[1] or 1),'location':m[3]})
 return {'equation':eq,'terms':out,'enzyme':re.findall(r'^ENZYME\s+(.*)$',s,re.M)}
rows=[];net=collections.Counter();located=collections.Counter();balance=[]
for n in ns:
 nt=native_terms(n);f=n['frame'];q=R/'inputs/native'/('META-'+f+'.xml');e=next(x for x in E.parse(q).getroot() if x.tag!='metadata')
 # Replay the owned source equation against actual direct XML slots.
 for side in ['left','right']:
  actual=[]
  for z in e.findall(side):
   entity=next(t for t in z if t.get('frameid'));cc=z.find('coefficient');loc=z.find('compartment/*');actual.append((entity.get('frameid'),int(cc.text) if cc is not None else 1,loc.get('frameid') if loc is not None else None))
  assert actual==[(t['frame'],t['coefficient'],t['compartment']) for t in n['terms'][side]],f
 known=collections.Counter();unknown=[]
 for side,sign in [('left',-1),('right',1)]:
  for t in nt[side]:
   cf=t['coefficient'];net[t['id']]+=sign*cf;located[(t['id'],t['location'])]+=sign*cf;m=mats[t['id']]
   if m['class'] or not m['formula_concise']:unknown.append(t);continue
   atoms=m['formula_concise'].split()
   for element,num in zip(atoms[::2],atoms[1::2]):known[element.title()]+=sign*cf*int(num)
   known['charge']+=sign*cf*int(m['cml_formal_charge'])
 balance.append({'native_id':f,'pathway_direction':n['pathway_direction'],'complete':not unknown,'known_term_products_minus_reactants':{k:v for k,v in sorted(known.items()) if v},'unknown_generic_terms':unknown,'disposition':'formal balance for fully specified equation' if not unknown else 'Known-term residual is not a claim of imbalance; generic material formulas/redox states are unresolved.'})
 rr=next(x for x in rc['equations'] if x['id']==rmap[f]);rt={}
 for s,role in [('left','substrates'),('right','products')]:
  rt[s]=[{'id':(t['accession'][0].removeprefix('CHEBI:') if t['accession'] else t['compound'].removeprefix(RNS)),'coefficient':t['coefficient'],'location':t.get('location',[])} for t in rr[role]]
 mapped={s:[dict(t,id=chemap[t['id']]) for t in nt[s]] for s in nt}
 diff={s:{k:signature(rt[s]).get(k,0)-signature(mapped[s]).get(k,0) for k in sorted(set(signature(rt[s]))|set(signature(mapped[s]))) if signature(rt[s]).get(k,0)!=signature(mapped[s]).get(k,0)} for s in nt}
 kid=next(x['id'] for x in n['xrefs'] if x['db']=='LIGAND-RXN');kp=R/'originals'/('KEGG-'+kid+'.txt');kr=parsed_kegg(kp)
 # KEGG Mer equation is reversed relative to the native written equation; it is already in pathway direction.
 reverse=n['pathway_direction']=='R2L' and f!='METHELENE-THMPT-OXI-RXN'
 kt=kr['terms'];kt={'left':kt['right'],'right':kt['left']} if reverse else kt
 km={s:[dict(t,id=kmap[t['id']]) for t in nt[s]] for s in nt}
 kd={s:{k:signature(kt[s]).get(k,0)-signature(km[s]).get(k,0) for k in sorted(set(signature(kt[s]))|set(signature(km[s]))) if signature(kt[s]).get(k,0)!=signature(km[s]).get(k,0)} for s in nt}
 rows.append({'native_id':f,'native_original_sha256':sha(q),'pathway_direction':n['pathway_direction'],'native_pathway_terms':nt,'native_rhea_alias':next(x['id'] for x in n['xrefs'] if x['db']=='RHEA'),'compared_directional_rhea':rr['id'],'rhea_master':rr['master'],'rhea_pathway_terms':rt,'rhea_issuer_formula_terms':rr,'rhea_minus_native_candidate_mapped_side_quantities':diff,'rhea_mapping_limit':'Candidate crosswalk used for arithmetic only; generic/stereo/ionic and location differences remain in identity dispositions, even when no coefficient residual.','kegg_alias':kid,'kegg_original_sha256':sha(kp),'kegg_own_equation':kr,'kegg_pathway_terms':kt,'kegg_minus_native_candidate_mapped_side_quantities':kd,'kegg_mapping_limit':'Candidate crosswalk used for arithmetic only; ionic and generic scope differences prevent automatic equivalence.'})
save('reaction-issuer-comparisons.json',rows);save('native-formal-balance-and-net.json',{'equations':balance,'frame_only_formal_net_products_minus_reactants':{k:v for k,v in sorted(net.items()) if v},'fully_location_sensitive_formal_net':[{'id':k[0],'location':k[1],'coefficient_products_minus_reactants':v} for k,v in sorted(located.items(),key=lambda z:(z[0][0],str(z[0][1]))) if v],'net_limit':'Algebra only; six source members do not regenerate carriers or produce methane. Frame-only cancellation discards localization information; location-sensitive net retains unspecified versus inside terms. No physiological flux inference.'})
for x in rows:print(x['native_id'],x['compared_directional_rhea'],x['rhea_minus_native_candidate_mapped_side_quantities'],x['kegg_alias'],x['kegg_minus_native_candidate_mapped_side_quantities'])
print('BALANCE',balance);print('NET',{k:v for k,v in net.items() if v})
