from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,sqlite3
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation');checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,label):
 checks.append({'check':label,'pass':bool(ok)})
 assert ok,label
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
source=json.loads((R/'inputs/source-packet-integrity-before.json').read_text());root=Path(source['root']);check({str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}=={x['path'] for x in source['files']},'source521 physical inventory unchanged including hidden files')
for x in source['files']:check(sha(root/x['path'])==x['sha256'] and (root/x['path']).stat().st_size==x['bytes'],'source '+x['path'])
for b in json.loads((R/'inputs/review-packets-intake.json').read_text()):
 p=Path(b['root']);check({str(q.relative_to(p)) for q in p.rglob('*') if q.is_file()}=={x['path'] for x in b['files']},'review/correction physical inventory '+str(p))
 for x in b['files']:check(sha(p/x['path'])==x['sha256'] and (p/x['path']).stat().st_size==x['bytes'],str(p)+'/'+x['path'])
for file in ['inputs/copied-input-bindings.json','inputs/additional-copied-bindings.json','inputs/reused-issuing-originals.json','inputs/reused-acquisition-receipt-bindings.json']:
 for x in json.loads((R/file).read_text()):check(sha(Path(x['source']))==sha(R/x['copy'])==x['sha256'],'copy binding '+x['copy'])
# Taxonomy review copies were made by taxonomy.py after the initial copied-input ledger.
p=Path('/private/tmp/pathwaymech-next-269-direct-taxon-label-independent-acceptance');mf=json.loads((p/'artifact-manifest.json').read_text());taxcopies=[]
for q in sorted((R/'inputs/prior/taxon-review').glob('*')):
 x=next((z for z in mf['files'] if z['path']==q.name),None);expected=x['sha256'] if x else next(z['sha256'] for z in json.loads((R/'inputs/copied-input-bindings.json').read_text()) if z['copy']==str(q.relative_to(R)));check(sha(q)==sha(p/q.name)==expected,'taxon review copy '+q.name);taxcopies.append({'source':str(p/q.name),'copy':str(q.relative_to(R)),'sha256':sha(q)})
save('results/additional-taxon-review-bindings.json',taxcopies)
requests=[]
for p in sorted((R/'receipts').glob('*.json')):
 for x in json.loads(p.read_text()):
  check(x.get('status')==200,'issuer HTTP200 '+x['file']);check(sha(R/x['path'])==x['sha256'] and (R/x['path']).stat().st_size==x['bytes'],'issuer bytes '+x['path']);requests.append(x)
check(len(requests)==76,'76 successful fresh issuer originals')
rb=json.loads((R/'inputs/prior/rdkit-runtime-binding.json').read_text())['binding']['files']
for x in rb:check(sha(Path(x['path']))==x['sha256'],'runtime unchanged '+x['path'])
save('results/rdkit-runtime-after.json',{'verified_files':len(rb),'all_hashes_unchanged':True,'scope':'Same77runtimefilesasbefore; no installs or repairs.'})
t=json.loads((R/'results/taxonomy-query-receipt.json').read_text());cache=Path(t['cache']);check(cache.stat().st_size==t['size'] and cache.stat().st_mtime_ns==t['mtime_ns_before']==t['mtime_ns_after'],'taxonomy size/mtime remained unchanged; reused fullhash')
db=sqlite3.connect(cache.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
old=json.loads((R/'inputs/prior/taxon-review/independent-taxonomy-rows.json').read_text());selected=json.loads((R/'results/taxonomy-complete-selected-statements.json').read_text())
for name,sets in [('old controls',old),('selected',selected)]:
 for id,rows in sets.items():check([dict(z) for z in db.execute('select * from statements where subject=? order by predicate,object,value',(id,))]==rows,'taxonomy fresh final '+name+' '+id)
db.close();check(len(selected)==15,'15 taxonomy contexts');save('results/taxonomy-final-unchanged.json',{'new_full_rehash':False,'cache_size':cache.stat().st_size,'mtime_ns':cache.stat().st_mtime_ns,'selected_rows_requeried':15,'prior_controls_requeried':9,'all_exact':True})
chem=json.loads((R/'results/material-issuer-chemistry.json').read_text())['rows'];check(len(chem)==18,'all18materialidentities');con=[x for x in chem if not x['native_class']];check(len(con)==12,'12concretematerials')
for x in con:check(x['cml_vs_inchi_constitution_normalized'] and x['cml_vs_inchi_formula_charge'] and x['native_key_recomputed'],'native CML constitution/formula/key '+x['native_id'])
exact=[x for x in con if x['issuer_candidates'][0]['comparison']['stereospecific_graph_isomorphism']];check(len(exact)==11,'11directChEBImolecularmatches')
f=json.loads((R/'results/formyl-58018-comparison.json').read_text());check(f['comparison']['formula_charge_equal'] and f['comparison']['strict_graph_equal_without_chirality'] and not f['comparison']['strict_graph_equal_with_chirality'],'formyl stereo unresolved despite ionic match')
k=json.loads((R/'results/kegg-material-graphs.json').read_text())['rows'];check(len(k)==18,'18KEGGmaterialroles');check(sum(x.get('mol_parse_success',False) for x in k)==16,'16KEGGmolecularimports');check(sum(x.get('comparison',{}).get('normalized_inchi_equal',False) for x in k)==5,'5KEGGsmallmoleculematches');check(sum(bool(x.get('comparison')) and not x['comparison']['formula_charge_equal'] for x in k)==7,'7KEGGionicmismatches');check(next(x for x in k if x['native_id']=='HYDROGEN-MOLECULE')['comparison']['explicit_hydrogen_graph_equal_with_chirality'],'H2explicitgraphagreement')
rh=json.loads((R/'results/rhea-six-family-replay.json').read_text());check(len(rh['direction_families'])==6 and len(rh['equations'])==12 and rh['unresolved_direction_seeds']==['17585'],'six currentRheafamilies + obsolete17585');check(len(rh['complete_selected_statements'])==90,'90selectedRheastatementrecords')
r=json.loads((R/'results/reaction-issuer-comparisons.json').read_text());check(len(r)==6,'six equationcomparisons');check(next(x for x in r if x['native_id']=='METHELENE-THMPT-OXI-RXN')['rhea_minus_native_candidate_mapped_side_quantities']=={'left':{},'right':{'15378':1}},'Mer extraRheaproton retained');check(next(x for x in r if x['native_id']=='2.3.1.101-RXN')['kegg_minus_native_candidate_mapped_side_quantities']=={'left':{'C00080':-1},'right':{}},'Ftr KEGGprotondeficit');check(next(x for x in r if x['native_id']=='FORMYLMETHANOFURAN-DEHYDROGENASE-RXN')['kegg_minus_native_candidate_mapped_side_quantities']=={'left':{'C00080':1},'right':{}},'Fmd KEGGextraH')
bal=json.loads((R/'results/native-formal-balance-and-net.json').read_text())['equations'];check(sum(x['complete'] for x in bal)==3 and all(not x['known_term_products_minus_reactants'] for x in bal if x['complete']),'three fullyspecifiednativebalances')
p=json.loads((R/'results/protein-gene-dispositions.json').read_text());check(len(p)==57 and sum(len(x['uniprot']) for x in p)==14,'57nonclassproteins and14directUniProtaliases');check(sum(z['GeneID_equality'] is False for x in p for z in x['uniprot'])==8,'eightGeneIDdifferences retained');check(len(json.loads((R/'results/activity-identity-contexts.json').read_text()))==15,'all15activitycontextdispositions')
s=(R/'originals/ENA-X86477.embl').read_text();seq=''.join(re.findall(r'[A-Z]+',re.search(r'/translation="([^"]+)"',s,re.S)[1].replace('FT','')));a=json.loads((R/'originals/UniProt-O27784.json').read_text());b=json.loads((R/'originals/UniProt-Q50744.json').read_text());check(len(seq)==321 and seq==b['sequence']['value'],'ENA321aa equalsQ50744');check(a['sequence']['length']==321 and sum(v!=w for v,w in zip(seq,a['sequence']['value']))==5,'fiveDeltaHversusMarburgresiduedifferences');check(a['organism']['taxonId']==187420 and b['organism']['taxonId']==79929,'differentofficialstrainidentities')
save('results/final-check-list.json',checks);save('results/verification.json',{'utc':datetime.now(timezone.utc).isoformat(),'checks':len(checks),'passed':sum(x['pass'] for x in checks),'source_packet_physical':len(source['files']),'review_correction_packets_physical':100,'initial_copied_bindings':211,'additional_copied_bindings':13,'additional_taxon_review_copies':len(taxcopies),'fresh_requests':76,'fresh_HTTP200':76,'reused_issuing_originals':6,'runtime_files_rehashed':len(rb),'taxonomy_fullhash_reused':True,'new_taxonomy_full_rehash':False,'terminal_jobs':True,'maintained_edits':False,'frozen_input_changes':False,'limitations':'This is author scientific preparation; independent acceptance, transport-aware design, merged-baseline rebind and maintained curation remain separate.'});print('checks',len(checks),'allpass',all(x['pass'] for x in checks))
