from pathlib import Path
import hashlib,json,re,xml.etree.ElementTree as E
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors as D
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def details(m):
 return {'formula':D.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'atoms':m.GetNumAtoms(),'bonds':m.GetNumBonds(),'inchi':Chem.MolToInchi(m),'key':Chem.MolToInchiKey(m),'smiles':Chem.MolToSmiles(m,isomericSmiles=True),'tetrahedral_centres':Chem.FindMolChiralCenters(m,includeUnassigned=True)}
def iso(a,b,stereo=True):return a.GetNumAtoms()==b.GetNumAtoms() and a.GetNumBonds()==b.GetNumBonds() and a.HasSubstructMatch(b,useChirality=stereo) and b.HasSubstructMatch(a,useChirality=stereo)
rows=[]
for n in json.loads((R/'inputs/material-candidates.json').read_text()):
 f=n['frame'];p=R/'inputs/native'/('META-'+f+'.xml');o=next(x for x in E.parse(p).getroot() if x.tag!='metadata')
 ids=[x['id'] for x in n['xrefs'] if x['db']=='CHEBI'];issuer=[]
 nm=Chem.MolFromInchi(n['inchi']) if n['inchi'] else None
 row={'native_id':f,'native_path':str(p.relative_to(R)),'native_sha256':sha(p),'native_class':n['class'],'native_formula':n['formula_concise'],'native_charge':n['cml_formal_charge'],'native_literal_smiles':n['smiles'],'native_inchi':n['inchi'],'native_parsed':details(nm) if nm else None,'native_inchi_parse_success':nm is not None,'native_inchi_parse_limit':'Standard sanitized RDKit import failed; structure remains unresolved' if n['inchi'] and nm is None else None,'issuer_candidates':issuer}
 if nm:
  row['native_key_recomputed']=Chem.MolToInchiKey(nm)==n['inchi_key'].removeprefix('InChIKey=')
  cml=o.find('cml/molecule');rw=Chem.RWMol();index={}
  for a in cml.findall('atomArray/atom'):
   atom=Chem.Atom(a.get('elementType').title());atom.SetFormalCharge(int(a.get('formalCharge','0')));index[a.get('id')]=rw.AddAtom(atom)
  for b in cml.findall('bondArray/bond'):
   a,z=(b.get('atomRefs') or b.get('atomRefs2')).split();rw.AddBond(index[a],index[z],{'1':Chem.BondType.SINGLE,'2':Chem.BondType.DOUBLE,'3':Chem.BondType.TRIPLE}[b.get('order')])
  cm=rw.GetMol();Chem.SanitizeMol(cm);unst=Chem.Mol(nm);Chem.RemoveStereochemistry(unst)
  row['native_cml_without_stereo']=details(cm);row['cml_vs_inchi_constitution_normalized']=Chem.MolToInchi(cm)==Chem.MolToInchi(unst);row['cml_vs_inchi_formula_charge']=(D.CalcMolFormula(cm),Chem.GetFormalCharge(cm))==(D.CalcMolFormula(nm),Chem.GetFormalCharge(nm))
  row['cml_stereo_limit']='CML connectivity only; drawing coordinates/wedges not independently interpreted. Native InChI owns the compared stereochemistry.'
 for id in ids:
  q=R/'originals'/('ChEBI-'+id+'.json');x=json.loads(q.read_text());assert x['chebi_accession']=='CHEBI:'+id and x['is_released']
  st=x.get('default_structure');im=Chem.MolFromInchi(st['standard_inchi']) if st and st.get('standard_inchi') else None;sm=Chem.MolFromSmiles(st['smiles']) if st and st.get('smiles') else None
  z={'id':'CHEBI:'+id,'path':str(q.relative_to(R)),'sha256':sha(q),'name':x['name'],'definition':x.get('definition'),'chemical_data':x.get('chemical_data'),'structure':st,'issuer_inchi_parse_success':im is not None,'issuer_smiles_parse_success':sm is not None,'ontology_relations':x.get('ontology_relations'),'issuer_parsed':details(im) if im else None}
  if im:
   z['issuer_key_recomputed']=Chem.MolToInchiKey(im)==st['standard_inchi_key'];z['issuer_smiles_inchi_consistent']=Chem.MolToInchi(sm)==Chem.MolToInchi(im) if sm else False
  if nm and im:
   z['comparison']={'stereospecific_graph_isomorphism':iso(nm,im),'graph_isomorphism_without_stereo':iso(nm,im,False),'normalized_standard_inchi_equal':Chem.MolToInchi(nm)==Chem.MolToInchi(im),'formula_charge_equal':(D.CalcMolFormula(nm),Chem.GetFormalCharge(nm))==(D.CalcMolFormula(im),Chem.GetFormalCharge(im))}
  else:z['comparison']={'not_an_exact_structure_comparison':'Native generic class, absent issuing structure or failed sanitized molecular import; see exact parse fields. No molecular identity inferred from names/xrefs.'}
  issuer.append(z)
 rows.append(row)
(R/'results/material-issuer-chemistry.json').write_text(json.dumps({'rdkit':rdBase.rdkitVersion,'rows':rows},indent=2)+'\n')
for x in rows:print(x['native_id'],'generic' if x['native_class'] else 'concrete','CML',x.get('cml_vs_inchi_constitution_normalized'),[(z['id'],z['comparison']) for z in x['issuer_candidates']])
