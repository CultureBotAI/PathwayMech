from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/'results'/n).write_text(json.dumps(x,indent=2)+'\n')
def obj(f):return next(z for z in E.parse(R/'inputs/native'/('META-'+f+'.xml')).getroot() if z.tag!='metadata')
def xs(o):return [{'db':d.findtext('dblink-db'),'id':d.findtext('dblink-oid'),'relationship':d.findtext('dblink-relationship')} for d in o.findall('dblink')]
mat=json.loads((R/'results/material-issuer-chemistry.json').read_text())['rows'];kg={z['native_id']:z for z in json.loads((R/'results/kegg-material-graphs.json').read_text())['rows']}
rows=[]
for m in mat:
 f=m['native_id'];candidate=m['issuer_candidates'];k=kg[f];notes=[]
 if m['native_class']:
  state='native generic identity retained; no exact molecular equivalence'
  if 'ferredoxin' in f.lower():notes.append('Direct ChEBI reduced/oxidized ferredoxin supports a broad redox class only. Rhea GENERIC:10000/10001 explicitly models [2Fe-2S] reactive parts, narrower than native multiple-cluster-class narrative; no exact protein or universal electron capacity follows.')
  elif 'methanofuran' in f.lower():notes.append('Direct ChEBI and KEGG originals are individual methanofuran molecules/microstates, not the entire native side-chain-variable class.')
  else:notes.append('Native F420 class permits variable glutamate count/linkage. KEGG and direct reduced ChEBI15823 are concrete two-Glu molecules. Rhea gamma-Glu(n) polyanions and ChEBI133980/139511 specify narrower linkage/microstate scope; representative default structures do not resolve the whole class.')
 elif f=='FORMYL-THMPT':state='retain native exact molecule; no accepted exact ChEBI alias';notes.append('Direct ChEBI17114 is neutral and stereo-underdetermined. Rhea ChEBI58018 is 3− with matching stereo-stripped constitution but explicit InChI atom22? versus native22+. KEGG C01274 has matching stereochemical InChI outside its proton layer, but is neutral.')
 else:
  assert candidate[0]['comparison']['stereospecific_graph_isomorphism'] and candidate[0]['comparison']['formula_charge_equal']
  state='direct ChEBI molecular comparison supported at native InChI resolution; independent acceptance required before promotion'
  notes.append('Native CML constitution/formula/charge checked; CML drawing stereochemistry not independently interpreted. Issuer InChI graph, formal charge, formula and stereochemistry compared to native InChI, not label/string-only equality.')
 if f=='PROTON':notes.append('CHEBI15378 is hydron (isotope-unspecified), not the narrower isotope-specific proton CHEBI24636. Native H+ InChI is isotope-unspecified; do not claim nuclear-isotope resolution.')
 if m.get('native_literal_smiles') and '[R]' in m['native_literal_smiles']:notes.append('Native literal SMILES contains [R]; it is not used as exact molecular identity.')
 if f=='HYDROGEN-MOLECULE':notes.append('Native literal SMILES [H] conflicts with H2 CML/formula/InChI. KEGG explicit [H][H] versus RDKit InChI [HH] representation reconciles by hydrogen-expanded graph comparison and formula/charge; not a monatomic-hydrogen mapping.')
 if not m['native_class']:
  cmp=k['comparison'];notes.append('KEGG exact small-molecule representation supported.' if cmp['normalized_inchi_equal'] else 'KEGG is a different ionic representation; no automatic exact alias. Proton-layer-only diagnostic does not erase the microstate difference.')
 rows.append({'native_id':f,'disposition':state,'direct_chebi_candidates':[x['id'] for x in candidate],'kegg_candidate':k['candidate'],'kegg_direct_native_xref':k['native_direct_xref'],'notes':notes,'evidence':['results/material-issuer-chemistry.json','results/kegg-material-graphs.json']+(['results/formyl-58018-comparison.json'] if f=='FORMYL-THMPT' else [])})
save('material-dispositions.json',rows)
rxnotes={
'H2-METHYLENE-THMPT-DEHYDRO-RXN':('Rhea20018 matches exact compared material chemistry and coefficients in source L2R direction. Native20020 is bidirectional, not the directional identifier.','KEGG R04455 has same candidate side quantities, but pterins are different ionic species.'),
'2.1.1.86-RXN':('Native Rhea17585 is obsolete. Its literal comment names53492 because omitted sodium transport; there is no structured replacedBy link in this pinned original. Independently replayed53493 carries matching four molecules and2Na(in)→2Na(out). Native also locates all four carriers inside, while Rhea leaves their location unspecified; this is not full compartment-complete equation equality.','KEGG R04347 retains2Na(side1)→2Na(side2) and updated EC7.2.1.4, but carrier ionic forms differ and numbered sides alone do not prove membrane orientation.'),
'METHELENE-THMPT-OXI-RXN':('Native bidirectional21147 resolves to master21144 and pathway direction21146. Rhea has an extra H+ product in that direction, with gamma-Glu(n) F420 polyanions. Native generic F420 class is not that exact microstate/linkage specification. Do not silently add the proton to native source.','KEGG R04464 is already written in pathway direction, opposite native written sides; quantity pattern agrees but concrete neutral F420 and pterin microstates differ.'),
'3.5.4.27-RXN':('Native19056 is bidirectional; pathway R2L corresponds19055. Formyl ChEBI58018 remains stereo-underdetermined. Native Mch activities662/4121 are physiol-L2R, opposite pathway layout; reversibility/directional alias does not settle in vivo flux.','KEGG R03464 side quantities agree after reversal, but ionic forms differ.'),
'2.3.1.101-RXN':('Native18061 is a master identifier; pathwayL2R is18062. Generic methanofuran classes versus particular Rhea molecules and formyl stereo gap prevent exact equivalence.','KEGG R03390 omits one H+ reactant relative to native pathway equation, plus microstate/generic differences.'),
'FORMYLMETHANOFURAN-DEHYDROGENASE-RXN':('Native19844 is bidirectional; pathwayR2L is19843. Rhea narrows methanofuran molecules and ferredoxin to [2Fe-2S] reactive parts; broad native carriers prevent exact equivalence.','KEGG R03015 requires2H+ versus native1H+ in pathway direction; neither shared aliases nor coefficients establish exact generic carrier identity.')}
rr=json.loads((R/'results/reaction-issuer-comparisons.json').read_text());out=[]
for x in rr:out.append({'native_id':x['native_id'],'native_rhea_alias':x['native_rhea_alias'],'directional_rhea':x['compared_directional_rhea'],'rhea_scope':rxnotes[x['native_id']][0],'kegg_alias':x['kegg_alias'],'kegg_scope':rxnotes[x['native_id']][1],'source_retention':'Retain native member and exact native quantities/direction/location in source graph. Candidate aliases do not transfer catalysts or establish whole-route methane physiology.','evidence':'results/reaction-issuer-comparisons.json'})
save('reaction-dispositions.json',out)
# Native whole-object protein scope, with separately bounded direct UniProt pointers.
prows=[]
for n in json.loads((R/'inputs/protein-candidates.json').read_text()):
 f=n['frame'];o=obj(f);genes=[]
 for g in n['gene_ids']:
  z=obj(g);genes.append({'id':g,'path':'inputs/native/META-'+g+'.xml','sha256':sha(R/'inputs/native'/('META-'+g+'.xml')),'identity_slots':{k:[a.text for a in z.findall(k)] for k in ['common-name','accession-1','accession-2','synonym']},'xrefs':xs(z),'citations':[E.tostring(a,encoding='unicode') for a in z.findall('citation')]})
 u=[a['id'] for a in n['xrefs'] if a['db']=='UNIPROT'];row={'native_id':f,'native_path':n['source'],'native_sha256':sha(R/n['source']),'native_species':[a.get('frameid') for a in o.findall('species/*')],'native_comments':[''.join(a.itertext()) for a in o.findall('comment')],'native_components':[E.tostring(a,encoding='unicode') for a in o.findall('component')],'native_genes':genes,'native_xrefs':n['xrefs'],'uniprot':[],'disposition':'Source-native protein/complex retained. No direct UniProt unification candidate in its own slots; no accession invented from generic reaction RELATED-TO lists.'}
 for a in u:
  p=R/'originals'/('UniProt-'+a+'.json');x=json.loads(p.read_text());assert x['primaryAccession']==a;loc=[b['value'] for g in x.get('genes',[]) for b in g.get('orderedLocusNames',[])];ref=[z for z in x['uniProtKBCrossReferences'] if z['database'] in ['EMBL','RefSeq','GeneID','KEGG','Proteomes']]
  native_loci=[v for g in genes for v in g['identity_slots']['accession-2']];native_gids=[a['id'] for g in genes for a in g['xrefs'] if a['db']=='NCBI-GENE'];issuer_gids=[z['id'] for z in ref if z['database']=='GeneID'];native_refs=[z['id'] for z in n['xrefs'] if z['db']=='NCBI-REFSEQ-PRO'];issuer_refs=[z['id'] for z in ref if z['database']=='RefSeq']
  z={'accession':a,'path':str(p.relative_to(R)),'sha256':sha(p),'review_status':x['entryType'],'organism':x['organism'],'genes':x.get('genes'),'ordered_loci':loc,'native_old_locus_matches':bool(native_loci) and set(native_loci)<=set(loc),'native_RefSeq_alias_matches_UniProt_report':bool(native_refs) and set(native_refs)<=set(issuer_refs),'native_GeneID_pointers':native_gids,'UniProt_GeneID_pointers':issuer_gids,'GeneID_equality':set(native_gids)==set(issuer_gids) if native_gids else None,'sequence_crossrefs':ref,'sequence_length':x['sequence']['length'],'sequence_sha256':hashlib.sha256(x['sequence']['value'].encode()).hexdigest(),'sequence_cautions':[c for c in x.get('comments',[]) if c['commentType']=='SEQUENCE CAUTION'],'sequence_conflict_features':[v for v in x.get('features',[]) if v['type']=='Sequence conflict'],'annotation_limit':'Official accession resolves this record; no new full native-sequence equality or original-paper experimental reading. UniProt evidence codes and references remain source assertions.'}
  row['uniprot'].append(z)
  if a in ['O27002','O27211','O27227','O27784']:row['disposition']='Official accession is Delta H strain187420, not Marburg79929 (different species145263). Native species-level/mixed historical object cannot be replaced wholesale by this sequence. Retain native identity and source-scoped accession.'
  elif a=='O85014':row['disposition']='AM1 strain and native AF032114 reference agree with official record; whole native sequence not compared. Preserve oxidative C1-catabolism/Mch scope, not methane-production proof.'
  else:row['disposition']='DSM4304 strain, exact native old locus and native RefSeq pointer agree with UniProt report. Native full sequence not supplied; linked NCBI originals not independently retrieved. Eight divergent historical GeneID pointers remain unresolved, not inferred obsolete/equivalent.'
  if a=='O28206':row['disposition']+=' Issuer is formyltransferase-like protein with similarity-only annotation; does not independently establish native ENZRXN26TB-75 catalysis.'
  if a=='O27784':row['disposition']+=' Native G-356 cites Marburg mer paper7649177 and PART-OF X86477, while O27784 cites DeltaH sequence U31568/AE000666. Preserve specific sequence conflict and do not transfer Marburg kinetics.'
 prows.append(row)
save('protein-gene-dispositions.json',prows)
acts=[]
for a in json.loads((R/'inputs/source/results/activity-ledger.json').read_text()):
 seen=set();todo=[a['enzyme']]
 while todo:
  f=todo.pop()
  if f in seen:continue
  seen.add(f);o=obj(f);todo += [z.get('frameid') for z in o.findall('component/*') if z.get('frameid')]
 aliases=[{'native_protein':r['native_id'],'accessions':[z['accession'] for z in r['uniprot']],'disposition':r['disposition']} for r in prows if r['native_id'] in seen]
 acts.append({'activity':a['frame'],'reaction':a['reaction'],'enzyme':a['enzyme'],'native_species':a['enzyme_direct_species'],'native_activity_direction':a['direction'],'linked_protein_closure':sorted(seen),'bounded_accession_dispositions':aliases,'cofactor_slots':a['cofactors'],'regulations':a['regulations'],'limit':'Activity-specific source assertion retained; generic reaction alias and shared subunit identity do not turn every linked catalyst into methanogenic-route evidence. Primary reading limits remain those in accepted source packet.'})
save('activity-identity-contexts.json',acts)
# All twelve native taxon objects plus historical strain constraints.
tax=json.loads((R/'results/taxonomy-complete-selected-statements.json').read_text());tx=[]
for n in json.loads((R/'inputs/source/results/taxon-ledger.json').read_text()):
 i=next(x['id'] for x in n['xrefs'] if x['db']=='NCBI-TAXONOMY-DB');rs=tax['NCBITaxon:'+i];label=next(x['value'] for x in rs if x['predicate']=='rdfs:label');rank=next(x['object'] for x in rs if x['predicate']=='obo:ncbitaxon#has_rank')
 tx.append({'native_id':n['frame'],'native_label':n['name'],'native_rank':n['rank'],'native_strain':n['strain_name'],'source_role':n['role'],'issuer_id':'NCBITaxon:'+i,'issuer_label':label,'issuer_rank':rank,'disposition':('Historical native Euryarchaeota label differs from pinned issuer Methanobacteriota; preserve old source range wording and current authority label separately, no all-phylum physiological assertion.' if i=='28890' else 'Exact native pointer and issuer name/rank support taxonomic identity at stated rank. Source pathway association does not establish every strain or whole-route experiment.'),'evidence':'results/taxonomy-complete-selected-statements.json'})
save('taxon-dispositions.json',{'native_objects':tx,'historical_sequence_constraints':{'Delta_H':'NCBITaxon:187420 under145262','Marburg':'NCBITaxon:79929 under145263, not187420','Methermicoccus':'Native660064 is species; Kurth ZC-1 experimental context retained as source-native strain string, no exact genome/protein accession inferred.'},'cache_hash_scope':'Full-cache SHA reused from prior independent acceptance; fresh15taxon complete statement sets/lineages and9unchanged control sets, size+mtime checked. No new full14GB rehash.'})
print('materials',len(rows),'reactions',len(out),'proteins',len(prows),'UniProt',sum(len(x['uniprot']) for x in prows),'activities',len(acts),'native_taxa',len(tx))
