from pathlib import Path
import hashlib,json,re
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors as D
from rdkit.Chem.MolStandardize import rdMolStandardize
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def det(m):return {'formula':D.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'inchi':Chem.MolToInchi(m),'key':Chem.MolToInchiKey(m),'smiles':Chem.MolToSmiles(m),'chiral_centres':Chem.FindMolChiralCenters(m,includeUnassigned=True)}
def iso(a,b,chiral):return a.GetNumAtoms()==b.GetNumAtoms() and a.GetNumBonds()==b.GetNumBonds() and a.HasSubstructMatch(b,useChirality=chiral) and b.HasSubstructMatch(a,useChirality=chiral)
def compare(a,b):
 ua=Chem.Mol(a);ub=Chem.Mol(b);Chem.RemoveStereochemistry(ua);Chem.RemoveStereochemistry(ub)
 na=rdMolStandardize.Uncharger().uncharge(a);nb=rdMolStandardize.Uncharger().uncharge(b)
 return {'formula_charge_equal':(D.CalcMolFormula(a),Chem.GetFormalCharge(a))==(D.CalcMolFormula(b),Chem.GetFormalCharge(b)),'strict_graph_equal_with_chirality':iso(a,b,True),'strict_graph_equal_without_chirality':iso(a,b,False),'explicit_hydrogen_graph_equal_with_chirality':iso(Chem.AddHs(a),Chem.AddHs(b),True),'inchi_except_proton_layer_equal':[z for z in Chem.MolToInchi(a).split('/') if not z.startswith('p')]==[z for z in Chem.MolToInchi(b).split('/') if not z.startswith('p')],'normalized_inchi_equal':Chem.MolToInchi(a)==Chem.MolToInchi(b),'normalized_stereo_stripped_inchi_equal':Chem.MolToInchi(ua)==Chem.MolToInchi(ub),'diagnostic_uncharged_inchi_equal':Chem.MolToInchi(na)==Chem.MolToInchi(nb),'normalization_limit':'Uncharging is a diagnostic transformation, not exact identity or physiological proton balance.'}
native=json.loads((R/'inputs/material-candidates.json').read_text());rows=[]
for n in native:
 ids=[x['id'] for x in n['xrefs'] if x['db']=='LIGAND-CPD']
 if n['frame']=='Oxidized-Factor-F420':ids=['C00876']
 for i in ids:
  p=R/'originals'/('KEGG-'+i+'.txt');s=p.read_text();assert re.search(r'^ENTRY\s+'+i+r'\b',s)
  row={'native_id':n['frame'],'candidate':i,'native_direct_xref':n['frame']!='Oxidized-Factor-F420','text_path':str(p.relative_to(R)),'text_sha256':sha(p),'issuer_formula':re.findall(r'^FORMULA\s+(.*)$',s,re.M),'native_class':n['class']}
  q=p.with_suffix('.mol')
  if q.exists():
   m=Chem.MolFromMolFile(str(q),sanitize=True,removeHs=True);row.update(mol_path=str(q.relative_to(R)),mol_sha256=sha(q),mol_parse_success=m is not None)
   if m:
    row['issuer_graph']=det(m)
    if n['inchi']:
     a=Chem.MolFromInchi(n['inchi']);row['native_graph']=det(a);row['comparison']=compare(a,m)
    else:row['disposition']='Native generic class versus specific issuer molecular structure; no exact molecular equivalence.'
  else:row['disposition']='Generic ferredoxin record; no formula or molecular structure. No sequence/cluster-complete identity inferred.'
  rows.append(row)
f=next(n for n in native if n['frame']=='FORMYL-THMPT');a=Chem.MolFromInchi(f['inchi']);p=R/'originals/ChEBI-58018.json';x=json.loads(p.read_text());b=Chem.MolFromInchi(x['default_structure']['standard_inchi']);formyl={'native_id':f['frame'],'candidate':'CHEBI:58018','candidate_source_sha256':sha(p),'native':det(a),'issuer':det(b),'comparison':compare(a,b),'explicit_inchi_stereolayers':{'native':[z for z in f['inchi'].split('/') if z.startswith(('t','b','m','s'))],'issuer':[z for z in x['default_structure']['standard_inchi'].split('/') if z.startswith(('t','b','m','s'))]},'disposition':'Formula/charge and stereo-stripped constitution match, but issuer standard InChI leaves atom22 tetrahedral stereochemistry unspecified. Retain native identity; do not replace with this xref as exact.'}
(R/'results/kegg-material-graphs.json').write_text(json.dumps({'rdkit':rdBase.rdkitVersion,'rows':rows},indent=2)+'\n');(R/'results/formyl-58018-comparison.json').write_text(json.dumps(formyl,indent=2)+'\n')
for r in rows:print(r['native_id'],r['candidate'],r.get('issuer_graph',{}).get('formula'),r.get('issuer_graph',{}).get('charge'),r.get('comparison',r.get('disposition')))
print('FORMYL',formyl['comparison'],formyl['explicit_inchi_stereolayers'])
