from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,sqlite3,shutil
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation')
P=Path('/private/tmp/pathwaymech-next-269-direct-taxon-label-independent-acceptance')
C=Path('/private/tmp/pathwaymech-curation-authorities/ncbitaxon.db')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
assert sha(P/'artifact-manifest.json')=='bbf93a71845ebdd3b23eb238d2062b61347b0b7c09baabf449d264112fc0f797'
mf=json.loads((P/'artifact-manifest.json').read_text())
for name in ['review-results.json','independent-taxonomy-rows.json','REVIEW.md']:
 row=next(x for x in mf['files'] if x['path']==name);assert sha(P/name)==row['sha256']
 q=R/'inputs/prior/taxon-review'/name
 if q.exists():assert sha(q)==row['sha256']
 else:shutil.copyfile(P/name,q)
prior=json.loads((P/'review-results.json').read_text())['summary']['taxonomy_cache']
before=C.stat();assert before.st_size==prior['bytes']
db=sqlite3.connect(C.as_uri()+'?mode=ro&immutable=1',uri=True);db.row_factory=sqlite3.Row
old=json.loads((P/'independent-taxonomy-rows.json').read_text())
control={}
for tax,rows in old.items():
 now=[dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(tax,))]
 assert now==rows,tax
 control[tax]={'row_count':len(now),'exact_match_to_previously_accepted_rows':True}
ids={'2208','145262','2179','28890','79929','187420','145263'}
for n in json.loads((R/'inputs/source/results/taxon-ledger.json').read_text()):
 for x in n['xrefs']:
  if x['db']=='NCBI-TAXONOMY-DB':ids.add(x['id'])
for p in (R/'originals').glob('UniProt-*.json'):ids.add(str(json.loads(p.read_text())['organism']['taxonId']))
rows={};lineages={}
for id in sorted(ids):
 t='NCBITaxon:'+id;rows[t]=[dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(t,))]
 chain=[];seen=set();current=t
 while current not in seen:
  seen.add(current);rs=[dict(x) for x in db.execute('select * from statements where subject=? order by predicate,object,value',(current,))]
  label=[x['value'] for x in rs if x['predicate']=='rdfs:label'];parent=[x['object'] for x in rs if x['predicate']=='rdfs:subClassOf'];rank=[x['object'] for x in rs if x['predicate']=='obo:ncbitaxon#has_rank']
  chain.append({'id':current,'label':label,'rank':rank,'parent':parent})
  if len(parent)!=1 or parent[0] in seen:break
  current=parent[0]
 lineages[t]=chain
metadata=[dict(x) for x in db.execute("select * from statements where predicate in ('owl:versionIRI','owl:versionInfo','dcterms:license')")]
db.close();after=C.stat();assert before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns
save('results/taxonomy-complete-selected-statements.json',rows);save('results/taxonomy-selected-lineages.json',lineages)
save('results/taxonomy-query-receipt.json',{'cache':str(C),'mode':'ro&immutable=1','prior_full_hash_evidence':prior,'prior_evidence_sha256':sha(P/'review-results.json'),'new_full_rehash':False,'fresh_checks':'size, before/after mtime and nine accepted statement-set equality controls; newly selected query rows are hash-bound in this packet','size':before.st_size,'mtime_ns_before':before.st_mtime_ns,'mtime_ns_after':after.st_mtime_ns,'prior_row_controls':control,'metadata':metadata,'queried_ids':sorted(ids),'utc':datetime.now(timezone.utc).isoformat()})
for t,rs in rows.items():print(t,[(x['predicate'],x['object'],x['value']) for x in rs if x['predicate'] in ['rdfs:label','obo:ncbitaxon#has_rank','rdfs:subClassOf']])
