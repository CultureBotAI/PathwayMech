import collections,csv,gzip,hashlib,html,io,json,re,subprocess
from pathlib import Path
from xml.etree import ElementTree as E
import yaml
O=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-270-discovery');W=Path('/private/tmp/pathwaymech-next-269-20261015');B='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105';checks=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def out(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def ck(x,label):assert x,label;checks.append(label)
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=W)
manifest=load(A/'artifact-manifest.json');files={r['path']:r for r in manifest['files']};physical={str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()};ck(physical==set(files)|{'artifact-manifest.json','freeze-proof.json'},'exact physical inventory including hidden/ignored')
ck(sha(A/'artifact-manifest.json')=='357c7c297bd3952e76ccd3386f4e518e98a83d0d7b989a7f3710ef54082e6621','expected frozen manifest')
for p,r in files.items():ck(sha(A/p)==r['sha256'] and (A/p).stat().st_size==r['bytes'],p+' exact frozen bytes')
ck(len(files)==61 and len(physical)==63,'61 listed63physical')
for n in ['HANDOFF.md','PRIMARY-READING.md','OPERATIONS.md']:(O/('author-'+n)).write_bytes((A/n).read_bytes())
projections={};member_union=set()
for frame in ['METHANOGENESIS-PWY','METH-ACETATE-PWY']:
 p=A/'originals'/('META-'+frame+'.xml');root=E.fromstring(p.read_bytes());entity=root[1];receipt=load(A/'results'/('acquisition-network-'+frame+'.json'))
 ck(root.tag=='ptools-xml' and root.get('ptools-version')=='27.0','native27 '+frame);ck(entity.tag=='Pathway' and entity.get('frameid')==frame and entity.get('orgid')=='META' and entity.get('detail')=='full','full exact pathway '+frame)
 ck(root.findtext('metadata/query')=='META:'+frame and root.findtext('metadata/num_results')=='1','exact query '+frame)
 ck(receipt['sha256']==sha(p) and receipt['bytes']==p.stat().st_size and receipt['status']==200 and receipt['url']==receipt['final_url']=='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+frame,'authentic successful request '+frame)
 members=[n.get('frameid') for n in entity.findall('reaction-list/Reaction')];order=[{'before':n.get('frameid'),'after':x.find('Reaction').get('frameid')} for x in entity.findall('reaction-ordering') for n in x.findall('predecessor-reactions/Reaction')];layouts=[{'reaction':x.find('Reaction').get('frameid'),'direction':x.findtext('direction'),'side':side,'id':n.get('frameid'),'native_class':n.get('class')=='true'} for x in entity.findall('reaction-layout') for side in ['left-primaries','right-primaries'] for n in x.find(side)];linked=[n.get('frameid') for n in entity.findall('pathway-link/link-target/Pathway')]
 b=load(A/'results'/(frame+'-boundary.json'));ck(b['members']==members and b['order']==order and b['layout_material_occurrences']==layouts and b['linked_only']==linked,'independent literal boundary projection '+frame);ck(len(members)==6 and len(set(members))==6,'six unique members '+frame);member_union.update('MetaCyc:'+m for m in members)
 taxa=[{'frameid':n.get('frameid'),'name':n.findtext('common-name'),'rank':n.findtext('rank'),'native_taxonomy_id':n.findtext('dblink/dblink-oid')} for n in entity.findall('species/Organism')]
 projections[frame]={'sha256':sha(p),'direct_slots':dict(collections.Counter(n.tag for n in entity)),'members':members,'ordering':order,'layout_occurrences':layouts,'direct_taxa':taxa,'linked_only':linked,'common_name':html.unescape(re.sub('<[^>]*>','',entity.findtext('common-name')))}
 if frame=='METHANOGENESIS-PWY':
  seq=['FORMYLMETHANOFURAN-DEHYDROGENASE-RXN','2.3.1.101-RXN','3.5.4.27-RXN','H2-METHYLENE-THMPT-DEHYDRO-RXN','METHELENE-THMPT-OXI-RXN','2.1.1.86-RXN'];ck({(r['before'],r['after']) for r in order}==set(zip(seq,seq[1:])),'five exact linear order links')
  direction={x.find('Reaction').get('frameid'):x.findtext('direction') for x in entity.findall('reaction-layout')};ck([direction[i] for i in seq]==['R2L','L2R','R2L','L2R','R2L','L2R'],'six specified layout directions');ck(len(layouts)==15,'15 layout primary occurrences not complete equation count')
  ck([t['frameid'] for t in taxa]==['TAX-2208','TAX-145262','TAX-2179'] and [t['rank'] for t in taxa]==['species','species','genus'],'two direct species and one genus')
  ck('METHFORM-PWY' in linked and 'METHFORM-PWY' not in members and entity.find('super-pathways/Pathway').get('frameid')=='PWY-6830','downstream methane pathway outside membership')
  ck(any(x['reaction']=='2.1.1.86-RXN' and x['side']=='right-primaries' and x['id']=='Me-CoM' for x in layouts),'final native layout endpoint Me-CoM')
  comment=entity.findtext('comment');ck('One in four' in comment and 'which is then disproportionated' in comment and 'methanophenazine' in comment,'material native commentary hazards actually present')
  (O/'native-comment.txt').write_text(comment+'\n');ck(entity.findtext('evidence/Publication/pubmed-id')=='9342247' and 'formylmethanofuran dehydrogenase' in entity.findtext('evidence/Publication/title'),'attached evidence paper is exact first-enzyme publication')
# Independently replay exact declarations against fixed merged corpus, plus explicit pending269 exclusion.
inventory=load(A/'results/current265-record-inventory.json');paths={r['path'] for r in inventory};ck(len(paths)==265,'265 frozen maintained record identities')
basepaths={p for p in git('ls-tree','-r','--name-only',B,'data/pathways').decode().splitlines() if p.endswith('.yaml')};ck(paths==basepaths,'inventory is complete actual merged maintained YAML')
records=[]
for row in inventory:
 p=W/row['path'];raw=p.read_bytes();ck(sha(p)==row['sha256'],'current original record unchanged '+row['path']);r=yaml.load(raw,Loader=yaml.CSafeLoader);ck(r['id']==row['id'] and r['label']==row['label'] and [x['id'] for x in r.get('reactions',[])]==row['reactions'],'record declaration inventory '+row['path']);records.append(r)
ids={r['id'] for r in records};reactions={n['id'] for r in records for n in r.get('reactions',[])};ck(not member_union&reactions,'none of12native memberIDs declared');ck(not ids&{'MetaCyc:METHANOGENESIS-PWY','MetaCyc:METH-ACETATE-PWY'},'both candidate pathway IDs absent in265')
physical_yaml={str(p.relative_to(W)) for p in (W/'data/pathways').rglob('*.yaml')};extra=physical_yaml-paths;ck(extra=={'data/pathways/glutaryl-coa-degradation.yaml'},'hidden ignored YAML inventory only pending269 outside baseline');pending=yaml.load((W/next(iter(extra))).read_text(),Loader=yaml.CSafeLoader);ck(pending['id']=='MetaCyc:PWY-5177' and not member_union&{n['id'] for n in pending.get('reactions',[])},'pending269 explicitly excluded and exact member disjoint')
# Audit search scope without pretending to repeat all compressed history.
searches=[]
for name,n in [('merged265',52),('original-checkout',21)]:
 s=load(A/'results'/('exact-preflight-search-'+name+'.json'));ck('--no-ignore' in s['command'] and '--hidden' in s['command'] and s['returncode']==0 and s['stderr']=='','ignore-independent text search receipt '+name);ck(len(s['files'])==n,'matching file denominator '+name);searches.append({'scope':s['scope'],'matching_files':n,'root':s['root']})
arch=load(A/'results/compressed-history-inventory.json');scan=load(A/'results/compressed-history-content-scan.json');ck(len(arch['archives'])==16576 and sum(r['bytes'] for r in arch['archives'])==1273224545,'compressed archive inventory denominator');ck(len(scan['files'])==116 and sum(r['decoded_bytes'] for r in scan['files'])==24849128 and all(not r['hits'] for r in scan['files']),'reported116gzip subset and exact absence scope')
# Replay only the declared 116-file subset, preserving its exact finite scope.
patterns=[p for p in (A/'results/exact-preflight-search-patterns.txt').read_text().splitlines() if p];scan_checks=[]
for row in scan['files']:
 p=W/row['path'];raw=p.read_bytes();ck(hashlib.sha256(raw).hexdigest()==row['compressed_sha256'] and len(raw)==row['bytes'],'selected compressed original '+row['path']);body=gzip.decompress(raw);ck(hashlib.sha256(body).hexdigest()==row['decoded_sha256'] and len(body)==row['decoded_bytes'],'selected decoded body '+row['path']);text=body.decode('utf-8',errors='replace').lower();hits=[s for s in patterns if s.lower() in text];ck(not hits,'selected finite gzip pattern absence '+row['path']);scan_checks.append({'path':row['path'],'compressed_sha256':row['compressed_sha256'],'decoded_sha256':row['decoded_sha256']})
# DRAM is a retained derived comparison, not a current issuer or exact alias.
dram=load(A/'results/ignored-DRAM-comparison.json');raw=(A/dram['copy']).read_bytes();ck(hashlib.sha256(raw).hexdigest()==dram['sha256'],'ignored DRAM source copy exact');allrows=list(csv.DictReader(io.StringIO(raw.decode()),delimiter='\t'));selected=[dict(r,original_line_number=i+2) for i,r in enumerate(allrows) if r['module'] in ['M00567','M00357']];ck(selected==dram['rows'] and collections.Counter(r['module'] for r in selected)=={'M00567':40,'M00357':34},'74 exact selected DRAM rows')
# All four misleadingly named files are explicitly failed-response bodies; no primary original accepted.
failed=[]
for name in ['PMC3041090.html','PMID9342247.html','PMID15882413.html','Vorholt1997.pdf']:
 receipt=load(A/'results'/('acquisition-'+name+'.json'));p=A/'originals'/name;ck(sha(p)==receipt['sha256'] and p.stat().st_size==receipt['bytes'],'failed primary response bytes '+name);text=p.read_text(errors='replace').lower();markers=[s for s in ['recaptcha','checking your browser','cloudflare','enable cookies','enable javascript','challenge'] if s in text];ck(bool(markers) and not p.read_bytes().startswith(b'%PDF'),'failed challenge body not paper '+name);failed.append({'name':name,'sha256':sha(p),'status':receipt['status'],'content_type':receipt['headers'].get('content-type',receipt['headers'].get('Content-Type')),'challenge_markers':markers,'accepted_primary_original':False})
res={'status':'bounded preflight acceptance','checks':len(checks),'frozen_input':{'path':str(A),'manifest_sha256':sha(A/'artifact-manifest.json'),'handoff_sha256':sha(A/'HANDOFF.md'),'reading_sha256':sha(A/'PRIMARY-READING.md'),'freeze_sha256':sha(A/'freeze-proof.json'),'listed':len(files),'physical':len(physical),'bytes':sum(r['bytes'] for r in files.values())},'native_projections':projections,'baseline':B,'baseline_records':265,'pending269_exclusion':pending['id'],'candidate_exact_ID_absence_includes_hidden_ignored_YAML':True,'exact_memberIDs_absent':sorted(member_union),'search_receipts':searches,'compressed_scope':{'inventoried':16576,'compressed_bytes':1273224545,'freshly_replayed_subset':116,'decoded_bytes':24849128,'unread_other_archive_interiors':16460,'patterns':patterns,'subset':scan_checks},'failed_primary_responses':failed,'primary_acceptance':'No new full-paper, figures, Methods or SI acceptance; successful ephemeral web text not retained as complete original and not independently reverified here.','mutable_source_closure_read':False,'no_maintained_git_github_network_runtime_mutation':True}
out('review-results.json',res);out('check-list.json',checks);print(json.dumps({'status':res['status'],'checks':len(checks),'listed':len(files),'physical':len(physical),'source_members':6,'order_links':5,'layout_occurrences':15,'source_direct_taxa':3,'gzip_subset_replayed':116,'failed_primary_bodies':4}))
