# Independent next270 preflight review

**Qualified acceptance for bounded source preparation. No actionable defect found in the frozen preflight.** This is not acceptance of a maintained record, complete chemistry, primary experimental mechanism, or global discovery exhaustion. Reviewer: `/root/next268_reaction_review_completion`; author: `/root/next268_chemistry_acceptance`.

The exact input is `/private/tmp/pathwaymech-next-270-discovery`: 61 listed / 63 physical files, manifest SHA256 `357c7c297bd3952e76ccd3386f4e518e98a83d0d7b989a7f3710ef54082e6621`, HANDOFF `dad3d91880e37e9065599c9c2253230530ae21a3e0d3bb308c719888821a8c1e`, PRIMARY-READING `e8ad779bc2051f416fb708ab1f00fa3f8e96022663cc7eb718da638a230ac2b3`, freeze `ba5efefad2956510d025e8cdc54b621470a089684411a29f83a9c077a3b41044`. Every listed file and physical path was independently verified. `check-list.json` records 984 passing assertions; `review-results.json` retains exact projections and source bindings.

## Native candidate and boundary

The full Pathway Tools 27.0 META original for METHANOGENESIS-PWY is 28,899 bytes, SHA256 `35e06e69cc42fe911cee1f6e33ddd950628d24bcb45a2807878099dd8dae43c8`. The successful acquisition receipt binds the exact HTTPS bare native query, body and frame. Independent XML projection confirms six members, five ordering links and fifteen layout primary occurrences. Fifteen is not a complete-equation material count.

| Order | Exact native reaction | Layout direction |
|---|---|---|
| 1 | FORMYLMETHANOFURAN-DEHYDROGENASE-RXN | R2L |
| 2 | 2.3.1.101-RXN | L2R |
| 3 | 3.5.4.27-RXN | R2L |
| 4 | H2-METHYLENE-THMPT-DEHYDRO-RXN | L2R |
| 5 | METHELENE-THMPT-OXI-RXN | R2L |
| 6 | 2.1.1.86-RXN | L2R |

The final native layout product is Me-CoM. METHFORM-PWY is linked, not a member; methane formation must not silently extend the six-member boundary. PWY-5209, cofactor synthesis/regeneration links and superpathway PWY-6830 remain context. The selected Hmd/H2 reaction must not be replaced by the F420-dependent Mtd alternative. Generic methanofuran and F420 families cannot be normalized to a convenient specific molecule without support.

The three direct native associations are TAX-2208 Methanosarcina barkeri (species), TAX-145262 Methanothermobacter thermautotrophicus (species) and TAX-2179 Methanothermus (genus). The broader Euryarchaeota range is distinct from these associations and from assay evidence. All direct entries need explicit issuer/rank dispositions during curation.

The complete native comment was read and retained in `native-comment.txt`. It does contain the generalized methyl-CoM disproportionation and membrane methanophenazine statements identified by the author. The preflight explicitly excludes their universal use, so this is a preserved source hazard, not a new defect. Its broad CO2-to-methane narrative also requires the narrower source-member endpoint to remain visible. The attached EV-EXP publication PMID:9342247 names a first-enzyme formylmethanofuran dehydrogenase study; neither the attachment nor the code proves six steps or every taxon experimentally.

## Duplicate and search limits

All 265 maintained YAML record hashes and declarations were rebound to actual merged baseline `7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105`, tree `1a0560c741c07fcb7878b1e93d8d38da67b1287c`. Both candidate pathway IDs and their twelve member reaction IDs are absent as exact declarations. Recursive physical YAML accounting includes hidden and ignored files; the sole additional current record is pending PWY-5177, explicitly outside the merged denominator and disjoint in those exact member IDs. This establishes neither chemical novelty nor complete synonym deduplication; acetate activation and other biology may overlap.

The author's ordinary-text search receipts explicitly use `rg --no-ignore --hidden`, with Git administration and runtime exclusions, and retain 52 and 21 matching-file results in the two stated checkouts. Those searches and capped contexts are not a complete reading of every historical document. Independently replayed the declared 116 text-gzip subset: all compressed and decoded hashes match; 24,849,128 decoded bytes have no hits for the seventeen retained patterns. The full inventory is 16,576 archives / 1,273,224,545 compressed bytes; the other 16,460 interiors were not globally decoded by this review. No source-exhaustion or universal historical-absence claim follows.

The retained ignored DRAM table and all 74 selected rows (40 M00567, 34 M00357) were reproduced with original row positions. M00567's alternate dehydrogenase and downstream steps prevent treating it as an exact six-member alias. Native UM-BBD-PWY `meth` and any future Rhea/KEGG mappings remain issuer/equation comparison tasks. The inherited PWY-301 AliB unpublished-work limitation is preserved, not independently upgraded to primary evidence.

## Primary access and reading scope

All four retained apparent primary files are challenge-response HTML, including the file named Vorholt1997.pdf, which has no PDF magic. The PMC3041090 body is reCAPTCHA despite HTTP 200; the Vorholt body is a 403 challenge. Body hashes and markers are in `review-results.json`. These are failed acquisition evidence, never a primary-paper source hash.

The author's successful web reading reports include abstracts and a partial Kaster2011 main excerpt, but complete successful primary originals are not retained here. Consequently this review makes no independent full-paper, figures, Methods or supplementary-information acceptance. The reported reading can motivate leads and caution; it cannot bind complete experimental claims to the retained challenge bodies. Pritchett2005 is methanol context, and Vorholt1997 is a first-enzyme lead, not whole-route validation. Do not promote a carbamate proposal to an observed intermediate or import Mvh/Hdr, artificial ferredoxin or ion-coupling details into all six reactions based on these partial leads.

## Concrete remaining preparation

Obtain or explicitly dispose the six complete Reaction objects and their material, activity, enzyme/complex, cofactor, regulation and organism references; preserve full coefficients and directions before cancellation. Reconcile direct taxa, carrier classes and mappings, and rerun alias/equation duplicate checks once justified identities exist. Rebind the actual merged corpus after pending269 merges. The separate source-closure task addresses these finite requirements; its mutable files were not read here.

Unread or unavailable historical papers are not an automatic global proof gate. Authoritative structured-source statements may be curated with explicit source-only scope. Full original reading is necessary when adopting corresponding primary experimental claims or quotations. The preflight's primary-priority list should be applied at that claim-specific scope, without an endless access hunt.

No authority implementation, maintained curation, schema gates, rendered page, complete mechanistic graph, global literature review or public licensing decision is accepted here. No maintained files, Git/GitHub state, network or runtime were changed.

## Execution provenance

The successful bounded replay used the existing verified Python runtime, bytecode disabled, and terminated with exit 0. Two reviewer harness failures remain preserved: an ElementTree empty-element assertion error, then a missing standard-library io import. Both are documented in `attempt-disposition.json`; neither involved changing the source packet. The final full 984-assertion replay passed. Final input inventory verification is retained separately. This review is frozen independently of future closure or publication reviews.
