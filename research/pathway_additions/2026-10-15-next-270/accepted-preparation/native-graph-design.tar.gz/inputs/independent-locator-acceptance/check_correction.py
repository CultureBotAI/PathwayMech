import ast,copy,hashlib,json,re,shutil
from pathlib import Path
C=Path('/private/tmp/pathwaymech-next-270-source-locator-correction');S=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation');R=Path('/private/tmp/pathwaymech-next-270-independent-source-closure-review');O=Path(__file__).resolve().parent;checks=[];bindings=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(v,s):assert v,s;checks.append(s)
def load(p):return json.loads(p.read_text())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def packet(p,manifest,count):
 ck(sha(p/'artifact-manifest.json')==manifest,'expected manifest '+p.name);m=load(p/'artifact-manifest.json');fs={x['path']:x for x in m['files']};ph={str(x.relative_to(p)) for x in p.rglob('*') if x.is_file()};ck(ph==set(fs)|{'artifact-manifest.json','freeze-proof.json'} and len(ph)==count,'exact physical inventory '+p.name)
 for name,r in fs.items():ck(sha(p/name)==r['sha256'] and (p/name).stat().st_size==r['bytes'],'original exact '+p.name+'/'+name)
 bindings.extend({'owner':str(p),'path':name,'bytes':(p/name).stat().st_size,'sha256':sha(p/name)} for name in sorted(ph))
packet(C,'d5f86a9308a10e1537f23a9bf0620445823bc2be05f53c85a0d71736c2b3f22b',15)
packet(S,'2bd6c0bf3c957babb332519a8216a56840ae017914e09bc87ba1265673085c56',521)
packet(R,'a64814d2b73ce4f5399704f087a816be51bae880fc448f13ec231a935d6812fe',64)
ck((C/'before/claim-dispositions.json').read_bytes()==(S/'results/claim-dispositions.json').read_bytes(),'before ledger exact source')
ck((C/'before/finish_assessment.py').read_bytes()==(S/'scripts/finish_assessment.py').read_bytes(),'before producer exact source')
b=load(C/'before/claim-dispositions.json');a=load(C/'after/claim-dispositions.json');ck(len(a)==len(b)==20 and [x['id'] for x in a]==[f'N270-S{i:02}' for i in range(1,21)],'all20 ordered claims')
old='Kurth2021 main Methods pp.4–5 and Results pp.9–11, Fig.3; supplement Fig.S2'
new='Kurth2021 main Methods PDF pp.6–7 (printed3554–3555); Figure4C/caption and Results PDF pp.11–12 (printed3559–3560); supplementary Figure S2B'
ck(b[14]['primary_scope']==[old] and a[14]['primary_scope']==[new],'one exact corrected scalar')
expected=copy.deepcopy(b);expected[14]['primary_scope'][0]=new;ck(a==expected,'all other20claim fields unchanged')
ck((C/'after/claim-dispositions.json').read_bytes()==(json.dumps(expected,indent=2,ensure_ascii=True)+'\n').encode(),'ledger exact expected semantic replacement plus ASCII serialization')
pb=(C/'before/finish_assessment.py').read_text();pa=(C/'after/finish_assessment.py').read_text();ck(pb.count(old)==1 and pa==pb.replace(old,new),'whole producer exact one literal replacement')
tb=ast.parse(pb);ta=ast.parse(pa);cb=[n for n in ast.walk(tb) if isinstance(n,ast.Constant) and n.value==old];ca=[n for n in ast.walk(ta) if isinstance(n,ast.Constant) and n.value==new];ck(len(cb)==len(ca)==1,'one AST literal each');cb[0].value=new;ck(ast.dump(tb,include_attributes=False)==ast.dump(ta,include_attributes=False),'AST identical after exact correction')
# Independent safe complete claim construction: only loc/claim functions and20 claim calls.
inventory=load(S/'results/native-object-inventory.json');slots=load(S/'results/native-direct-slot-ledger.json');allow={'results/member-equations.json','results/regulation-ledger.json'}
def readonly_read(n):
 ck(n in allow,'safe producer read '+n);return load(S/n)
ns={'byid':{r['frame']:r for r in inventory},'slots':slots,'claims':[],'read':readonly_read};nodes=[n for n in ta.body if isinstance(n,ast.FunctionDef) and n.name in {'loc','claim'}];calls=[n for n in ta.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='claim'];ck(len(nodes)==2 and len(calls)==20,'safe producer20 calls two functions');module=ast.Module(body=nodes+calls,type_ignores=[]);exec(compile(module,'review-isolated-claim-construction','exec'),ns);ck(ns['claims']==a,'independent corrected20claim reproduction');repro=json.dumps(ns['claims'],indent=2,ensure_ascii=True)+'\n';ck(repro.encode()==(C/'after/claim-dispositions.json').read_bytes(),'complete reproduced ledger exact ASCII serialization');(O/'independent-reproduced-claims.json').write_text(repro);(O/'independent-producer-format-claims.json').write_text(json.dumps(ns['claims'],indent=2,ensure_ascii=False)+'\n')
# Verify source text locations against accepted original-bound extraction; no newfull reading claim.
t=(R/'kurth-replay/complete-text.txt').read_text();p={int(k):v for k,v in re.findall(r'\[PDF PAGE (\d+)\]\n(.*?)(?=\n\[PDF PAGE |\Z)',t,re.S)}
ck('Enzyme activity assays' in p[6] and 'MtoA activity was determined' in p[6] and '1.7 mM CoM' in p[7] and 'H4F (Schircks' in p[7],'Methods6–7 exact')
ck('Fig. 4 O-demethylation and methyl transfer conducted by Mto' in p[11] and 'Reaction C:' in p[11] and 'H4MPT structural analog H4F' in p[11],'Figure4C/caption exact')
ck('no speci c activity value for MtoA' in p[12],'Results continuation12 exact')
si=(S/'reading/kurth-supplements/supp1-text.txt').read_text();ck('Figure S2. Enzyme activity assay with MtoB and MtoA.' in si and 'B) Methyl transfer from methylated Co(III)-MtoC to H4F' in si and 'When CoM is used as methyl group acceptor' in si,'SI S2B/caption exact')
ck(sha(S/'originals/primary/kurth2021.pdf')=='f15d78d1ccca763d30f0ba74eb5f1867688623a4e6833c05373ff056811d008b','same acceptedprimaryPDF')
for n in ['HANDOFF.md','artifact-manifest.json','freeze-proof.json'] :shutil.copyfile(C/n,O/('author-'+n))
for n in ['claim-dispositions.json','finish_assessment.py']:shutil.copyfile(C/'after'/n,O/('accepted-'+n))
save('input-bindings.json',bindings);save('check-list.json',checks);save('RESULT.json',{'status':'accepted bounded correction','issue':626,'finding':'N270-R01','checks':len(checks),'source_physical':521,'prior_review_physical':64,'correction_physical':15,'changed_field':'/14/primary_scope/0','all20_claim_bodies_and_other_fields_unchanged':True,'single_current_producer_literal_only':True,'independent_complete_claim_generation_values_exact':True,'serialization_difference':'After ledger uses ASCII escapes, including unchangedS14 en dashes; current producer save uses literalUnicode. Both decode to identical expected20claims.','full_producer_executed':False,'prior_scientific_scope_reused':True,'issue_status':'open pending later integration/merge; no GitHub write','accepted_ledger_sha256':sha(C/'after/claim-dispositions.json'),'accepted_producer_sha256':sha(C/'after/finish_assessment.py')});print(json.dumps({'status':'accepted bounded correction','checks':len(checks)}))
