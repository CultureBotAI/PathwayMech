# Frozen N270-R01 / issue626 locator correction

This narrow successor changes only N270-S15.primary_scope[0] and the corresponding literal in its reproducible generator. The exact corrected locator is Methods PDF pages 6–7 (printed 3554–3555), Figure 4C/caption and Results PDF pages 11–12 (printed 3559–3560), and supplementary Figure S2B. Figure 3 was a pathway schematic, not the experiment. The underlying H4F-surrogate and CoM-negative claim is unchanged.

All 20 claim bodies and every other field are byte/value-preserved; the new entire 20-claim ledger is reproduced from the corrected claim-builder section. All 521 original source files and 64 independent-review files were freshly verified before and after. No original, native ledger, primary body, maintained code, authority, runtime, Git or GitHub was edited. Issue 626 stays open pending independent acceptance and later integration. This is author correction, not self-acceptance.

Read results/correction-verification.json, inputs/findings.json, before/ and after/ files, and results/generator.diff. The corrected generator retains its original historical absolute input/output root; do not execute it wholesale against the frozen predecessor. Safe reproduction must isolate the claim section and intercept writes as documented in verification. The original broad source packet remains immutable. All jobs are terminal.

The correction has no new primary acquisition or reading claim; locators are grounded to the accepted independent full reading. It makes no unrelated scientific change or new curation approval.
