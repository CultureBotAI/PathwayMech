from pathlib import Path
import xml.etree.ElementTree as ET,json,hashlib,html,re,collections,sys,urllib.parse
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
from html.parser import HTMLParser
class Plain(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.parts=[]
 def handle_data(self,data):self.parts.append(data)
def plain(t):
 parser=Plain();parser.feed(t or '');return ''.join(parser.parts)
catalog=[]; objects={}
for p in sorted((R/'originals/native').glob('*.xml')):
 try:
  d=ET.parse(p).getroot();o=[x for x in d if x.tag!='metadata'][0]
  if d.tag!='ptools-xml' or o.get('detail')!='full':continue
  objects[o.get('frameid')]=(p,o)
 except Exception:continue
for f,(p,o) in objects.items():
 slots=[]
 for i,s in enumerate(o,1):
  refs=[{'type':x.tag,'frame':x.get('frameid'),'attributes':dict(x.attrib)} for x in s.iter() if x.get('frameid')]
  slots.append({'index':i,'tag':s.tag,'xml':ET.tostring(s,encoding='unicode'),'text':plain(s.text),'references':refs})
 catalog.append({'frame':f,'type':o.tag,'attributes':dict(o.attrib),'path':str(p.relative_to(R)),'sha256':sha(p),'direct_slots':slots})
(R/'results/native-catalog-current.json').write_text(json.dumps(catalog,indent=2)+'\n')
if len(sys.argv)>1 and sys.argv[1]=='plan':
 follows={'Protein':{'component','gene','species','locations','location','cofactor','prosthetic-group','modified-form','unmodified-form'},'Enzymatic-Reaction':{'cofactor','regulated-by','enzyme'},'Regulation':{'regulator','regulated-entity'},'Gene':{'product','species'}}
 needed={}
 for f,(p,o) in objects.items():
  if o.get('class')=='true':continue
  for slot in follows.get(o.tag,set()):
   for s in o.findall(slot):
    for x in s.iter():
     if x.get('frameid') and x.tag not in ('Publication','Evidence-Code','Person','Organization'):
      target=x.get('frameid')
      if target!=f and target not in objects:needed.setdefault(target,[]).append({'owner':f,'slot':slot,'native_type':x.tag})
 plan=[{'name':urllib.parse.quote(f,safe='-._+'),'frame':f,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+urllib.parse.quote(f,safe='-._+'),'output':'originals/native/META-'+urllib.parse.quote(f,safe='-._+')+'.xml','reasons':v} for f,v in sorted(needed.items())]
 n=sys.argv[2];out=R/'results'/f'closure-{n}-plan.json';assert not out.exists();out.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'new':len(plan),'frames':[x['frame'] for x in plan]},indent=2))
else:
 types=sys.argv[1:] or ['Protein']
 for row in catalog:
  if row['type'] not in types or row['attributes'].get('class')=='true':continue
  print('\n###',row['frame'])
  for s in row['direct_slots']:
   if s['tag'] in ('credits','has-feature'):print(s['tag'], 'metadata retained:',[(r['type'],r['frame']) for r in s['references']]);continue
   if s['tag']=='comment':print('comment:',s['text']);continue
   print(s['tag'], s['text'], [(r['type'],r['frame']) for r in s['references']], re.sub('<[^>]+>',' ',s['xml']) if s['tag'] in ('component','species','dblink') else '')
