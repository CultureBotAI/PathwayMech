from pathlib import Path
import collections, hashlib, json, subprocess, sys, xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads((R/p).read_text())
def save(p,x): (R/p).write_text(json.dumps(x,indent=2)+'\n')
checks=[]
def check(name, condition, detail=None):
 checks.append({'name':name,'passed':bool(condition),'detail':detail})
 if not condition: raise AssertionError(name)
bindings=read('results/input-bindings-initial.json')
for row in bindings:
 for label,p in [('source',Path(row['source'])),('copy',R/row['copy'])]:
  check('input '+label+' '+str(p),p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
preflight=Path('/private/tmp/pathwaymech-next-270-discovery')
mf=json.loads((preflight/'artifact-manifest.json').read_text())
for row in mf['files']:
 p=preflight/row['path'];check('preflight '+row['path'],p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
physical={str(p.relative_to(preflight)) for p in preflight.rglob('*') if p.is_file()}
check('preflight full physical set including hidden/ignored',physical=={x['path'] for x in mf['files']}|{'artifact-manifest.json','freeze-proof.json'},len(physical))
for name,expected in [('artifact-manifest.json','357c7c297bd3952e76ccd3386f4e518e98a83d0d7b989a7f3710ef54082e6621'),('freeze-proof.json','ba5efefad2956510d025e8cdc54b621470a089684411a29f83a9c077a3b41044')]:check('preflight '+name+' exact',sha(preflight/name)==expected)
save('results/input-bindings-final.json',{'checks':checks.copy(),'result':'all copied inputs and entire original preflight unchanged'})

inv=read('results/native-object-inventory.json');objects={}
for row in inv:
 p=R/row['path'];check('native exact bytes '+row['frame'],p.stat().st_size==row['bytes'] and sha(p)==row['sha256'])
 root=E.parse(p).getroot();os=[x for x in root if x.tag!='metadata'];o=os[0];f=row['frame'];objects[f]=o
 check('native envelope '+f,root.tag=='ptools-xml' and len(os)==1 and o.get('detail')=='full' and o.get('frameid')==f and o.get('ID')=='META:'+f and o.get('orgid')=='META' and root.findtext('metadata/query')=='META:'+f and root.findtext('metadata/num_results')=='1')
check('all full native objects',len(objects)==177)
for x in read('results/direct-occurrences.json'):check('direct '+x['owner']+' '+x['slot']+' '+x['frame'],x['frame'] in objects)
for i,x in enumerate(read('results/biological-forward-closure.json'),1):check('closure occurrence '+str(i),x['target'] in objects and objects[x['target']].tag==x['target_type'])

ordered=['FORMYLMETHANOFURAN-DEHYDROGENASE-RXN','2.3.1.101-RXN','3.5.4.27-RXN','H2-METHYLENE-THMPT-DEHYDRO-RXN','METHELENE-THMPT-OXI-RXN','2.1.1.86-RXN']
root=objects['METHANOGENESIS-PWY']
check('six exact source members',set(ordered)=={x.get('frameid') for s in root.findall('reaction-list') for x in s})
orders={(s.find('predecessor-reactions/Reaction').get('frameid'),s.find('Reaction').get('frameid')) for s in root.findall('reaction-ordering')}
check('five exact source ordering edges',orders==set(zip(ordered,ordered[1:])))
check('boundary METHFORM not member','METHFORM-PWY' in objects and not any(x.get('frameid')=='METHFORM-PWY' for s in root.findall('reaction-list') for x in s))
expected={'FORMYLMETHANOFURAN-DEHYDROGENASE-RXN':'R2L','2.3.1.101-RXN':'L2R','3.5.4.27-RXN':'R2L','H2-METHYLENE-THMPT-DEHYDRO-RXN':'L2R','METHELENE-THMPT-OXI-RXN':'R2L','2.1.1.86-RXN':'L2R'}
check('six exact source layout directions',{s.find('Reaction').get('frameid'):s.findtext('direction') for s in root.findall('reaction-layout')}==expected)
material=[];net=collections.Counter();compnet=collections.Counter()
for f in ordered:
 for side in ('left','right'):
  for s in objects[f].findall(side):
   o=next(x for x in s if x.tag in ('Compound','Protein'));q=int(s.findtext('coefficient') or 1);c=s.find('compartment/cco');c=c.get('frameid') if c is not None else None
   material.append((f,side,o.get('frameid'),q,c));sign=(-1 if side=='left' else 1)*(-1 if expected[f]=='R2L' else 1)
   net[o.get('frameid')]+=q*sign;compnet[(o.get('frameid'),c)]+=q*sign
ledger=read('results/member-material-occurrences.json')
check('complete30 material occurrences',len(material)==30 and sorted(material,key=str)==sorted([(x['reaction'],x['side'],x['frame'],x['coefficient'],x['compartment']) for x in ledger],key=str))
check('18 material IDs',len({x[2] for x in material})==18)
check('Mtr sodium quantity and locations',[(side,q,c) for f,side,m,q,c in material if f=='2.1.1.86-RXN' and m=='NA+']==[('left',2,'CCO-IN'),('right',2,'CCO-OUT')])
summary=read('results/native-closure-summary.json')
check('net recomputation',dict((f,n) for f,n in net.items() if n)==summary['formal_compartment_collapsed_net'])
check('compartment net recomputation',{(x['frame'],x['compartment']):x['coefficient'] for x in summary['formal_compartment_retained_net']}=={k:v for k,v in compnet.items() if v})
for f in ('ENZRXN-662','ENZRXN-4121'):check('Mch opposite activity '+f,objects[f].findtext('reaction-direction')=='PHYSIOL-LEFT-TO-RIGHT')
check('direct taxa exact',{s[0].get('frameid') for s in root.findall('species')}=={'TAX-2208','TAX-145262','TAX-2179'})
check('Methanothermus is genus',objects['TAX-2179'].findtext('rank')=='genus')
check('native range separate',{s[0].get('frameid') for s in root.findall('taxonomic-range')}=={'TAX-28890'} and objects['TAX-28890'].findtext('rank')=='phylum')
check('15 exact activity dispositions',{x['activity'] for x in read('results/activity-dispositions.json')}=={x['frame'] for x in read('results/activity-ledger.json')} and len(read('results/activity-dispositions.json'))==15)
check('43 complex component occurrences',sum(len(o.findall('component')) for o in objects.values() if o.tag=='Protein')==43)
regs=read('results/regulation-ledger.json')
expectedreg={'REG-10183':('HCN','ENZRXN-422','-'),'REG-10357':('HCN','ENZRXN-641','-'),'REG-11191':('NA+','ENZRXN-4121','+'),'REG-15400':('CPD-19570','ENZRXN-662','-'),'REG-9176':('MG+2','ENZRXN-662','+'),'REG-9174':('MN+2','ENZRXN-662','-'),'REG-8185':('OXYGEN-MOLECULE','ENZRXN-702','-')}
check('7 exact regulation contexts',{x['frame']:(x['regulator'],x['target_activity'],x['mode']) for x in regs}==expectedreg)
check('all own direct slots preserved',len(read('results/native-direct-slot-ledger.json'))==sum(len(o) for o in objects.values())==2061)
check('all frame occurrences retained',len(read('results/native-reference-occurrences.json'))==sum(1 for o in objects.values() for s in o for x in s.iter() if x.get('frameid'))==34996)
check('no unauthorized bytecode in owned packet',not list(R.rglob('*.pyc')) and not list(R.rglob('__pycache__')))
reuse=read('receipts/reuse-NA+.json');check('sodium exact reuse',sha(R/reuse['copy'])==reuse['row']['sha256']==sha(Path(reuse['source'])))
for x in read('results/acquisition-attempt-ledger.json'):
 if x['sha256'] and x['output']:check('request body '+x['receipt'],sha(R/x['output'])==x['sha256'])
for x in read('results/primary-reading-scopes.json'):check('primary reading source '+x['source'],sha(R/x['source'])==x['sha256'])
check('all14 PMID abstracts',{x['pmid'] for x in read('reading/selected-pubmed-abstracts.json')}=={'9342247','21262829','1521540','8522533','10215859','8477726','3782039','3097011','2253782','8125106','7737157','7649177','34145392','20221540'})
check('complete17 main page renders',len(list((R/'reading/kurth2021').glob('page-*.png')))==17)

# Reproduce deterministic derived ledgers without changing originals. Same implementation,
# not independent science review; hand-enumerated boundary controls above are separate.
names=['native-object-inventory','native-direct-slot-ledger','native-reference-occurrences','biological-forward-closure','member-equations','member-material-occurrences','activity-ledger','complex-components','gene-ledger','regulation-ledger','taxon-ledger','material-identity-source-ledger','primary-citation-leads','native-closure-summary']
before={n:sha(R/'results'/f'{n}.json') for n in names}
run=subprocess.run([sys.executable,'-B',str(R/'scripts/build_ledgers.py')],capture_output=True,text=True)
save('results/ledger-reproduction-command.json',{'exit_code':run.returncode,'stdout':run.stdout,'stderr':run.stderr,'before':before})
check('ledger reproduction exit',run.returncode==0)
for n,h in before.items():check('deterministic ledger '+n,sha(R/'results'/f'{n}.json')==h)
save('results/verification.json',{'scope':'Author verification, not independent acceptance. Exact input/source bindings, selected closure, finite hand-enumerated boundary controls and deterministic replay. No chemistry solver or physiological flux validation.', 'passed':len(checks),'failed':0,'checks':checks})
print(json.dumps({'passed':len(checks),'failed':0},indent=2))
