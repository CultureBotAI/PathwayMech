from pathlib import Path
import xml.etree.ElementTree as ET,json,urllib.parse,hashlib
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
roots={}
for p in (R/'originals/native').glob('*.xml'):
 try:
  d=ET.parse(p).getroot();o=[x for x in d if x.tag!='metadata'][0]
  if o.get('detail')=='full':roots[o.get('frameid')]=(p,o)
 except Exception:pass
pw=ET.parse(R/'inputs/preflight/originals/META-METHANOGENESIS-PWY.xml').getroot().find('Pathway')
occ=[]
for frame in [x.get('frameid') for x in pw.findall('reaction-list/Reaction')]:
 p,o=roots[frame]
 for side in ('left','right'):
  for i,s in enumerate(o.findall(side),1):
   for x in s:
    if x.get('frameid'):occ.append({'owner':frame,'slot':f'{side}[{i}]','type':x.tag,'frame':x.get('frameid'),'role':'equation-material','coefficient':s.findtext('coefficient') or '1','compartment':s.find('compartment/*').get('frameid') if s.find('compartment/*') is not None else None})
   for x in s.findall('compartment/*'):occ.append({'owner':frame,'slot':f'{side}[{i}]/compartment','type':x.tag,'frame':x.get('frameid'),'role':'equation-location'})
 for x in o.findall('enzymatic-reaction/Enzymatic-Reaction'):
  occ.append({'owner':frame,'slot':'enzymatic-reaction','type':x.tag,'frame':x.get('frameid'),'role':'member-linked-activity'})
  for en in x.findall('enzyme/*'):occ.append({'owner':x.get('frameid'),'slot':'enzyme','type':en.tag,'frame':en.get('frameid'),'role':'member-linked-catalyst'})
for slot,role in [('species','direct-pathway-taxon'),('taxonomic-range','range-context')]:
 for x in pw.findall(slot+'/*'):occ.append({'owner':'METHANOGENESIS-PWY','slot':slot,'type':x.tag,'frame':x.get('frameid'),'role':role})
by={}
for x in occ:by.setdefault(x['frame'],[]).append(x)
plan=[{'name':urllib.parse.quote(f,safe='-._'),'frame':f,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+urllib.parse.quote(f,safe='-._'),'output':'originals/native/META-'+urllib.parse.quote(f,safe='-._')+'.xml','reasons':by[f]} for f in sorted(by) if f not in roots]
(R/'results/direct-occurrences.json').write_text(json.dumps(occ,indent=2)+'\n')
(R/'results/direct-originals-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'occurrences':len(occ),'equation_occurrences':sum(x['role']=='equation-material' for x in occ),'unique_materials':len(set(x['frame'] for x in occ if x['role']=='equation-material')),'new_originals':len(plan),'roles':{role:len(set(x['frame'] for x in occ if x['role']==role)) for role in sorted(set(x['role'] for x in occ))}},indent=2))
