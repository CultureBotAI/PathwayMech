from pathlib import Path
import json,sys,time,datetime,hashlib,urllib.request,urllib.error,urllib.parse,concurrent.futures,xml.etree.ElementTree as ET
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
plan=json.loads(Path(sys.argv[1]).read_text()); batch=sys.argv[2]
def one(task):
 name=task['name']; out=R/task['output']; rec=R/'receipts'/f'{batch}-{name}.json'; assert not rec.exists() and not out.exists(),name
 row=dict(task,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),batch=batch)
 try:
  req=urllib.request.Request(task['url'],headers={'User-Agent':'PathwayMech-research/1.0 (public source evidence inspection)'})
  try:
   with urllib.request.urlopen(req,timeout=35) as resp: data=resp.read();row.update(status=resp.status,final_url=resp.url,headers=dict(resp.headers))
  except urllib.error.HTTPError as exc:
   data=exc.read();row.update(status=exc.code,final_url=exc.url,headers=dict(exc.headers))
  out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  if task.get('frame'):
   try:
    doc=ET.fromstring(data); objects=[x for x in doc if x.tag!='metadata'];obj=objects[0] if len(objects)==1 else None
    row['native_validation']={'root':doc.tag,'ptools_version':doc.get('ptools-version'),'query':doc.findtext('metadata/query'),'num_results':doc.findtext('metadata/num_results'),'object_type':obj.tag if obj is not None else None,'object_attributes':dict(obj.attrib) if obj is not None else None,'accepted_exact_full':doc.tag=='ptools-xml' and len(objects)==1 and obj.get('orgid')=='META' and obj.get('frameid')==task['frame'] and obj.get('detail')=='full' and doc.findtext('metadata/query')=='META:'+task['frame'] and doc.findtext('metadata/num_results')=='1'}
   except Exception as exc:row['native_parse_error']=repr(exc)
 except Exception as exc:row['error']=repr(exc)
 row['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec.write_text(json.dumps(row,indent=2)+'\n')
 return {'name':name,'status':row.get('status'),'bytes':row.get('bytes'),'accepted':row.get('native_validation',{}).get('accepted_exact_full'),'error':row.get('error')}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for row in pool.map(one,plan):print(json.dumps(row),flush=True)
