from pathlib import Path
from html.parser import HTMLParser
import collections, hashlib, json, re, xml.etree.ElementTree as E
R=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,v): (R/'results'/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
class Text(HTMLParser):
 def __init__(self): super().__init__();self.parts=[];self.links=[]
 def handle_data(self,x):self.parts.append(x)
 def handle_starttag(self,t,a):
  if t=='a' and dict(a).get('href'):self.links.append(dict(a)['href'])
def plain(x):
 p=Text();p.feed(x or '');return ''.join(p.parts)
paths=sorted((R/'originals/native').glob('*.xml'))+[R/'inputs/preflight/originals/META-METHANOGENESIS-PWY.xml']
objects={}; inventory=[]
for p in paths:
 try:
  root=E.parse(p).getroot();os=[x for x in root if x.tag!='metadata'];o=os[0]
  if root.tag!='ptools-xml' or len(os)!=1 or o.get('detail')!='full':continue
 except Exception:continue
 f=o.get('frameid');assert f not in objects,f
 assert o.get('orgid')=='META' and o.get('ID')=='META:'+f
 assert root.findtext('metadata/query')=='META:'+f and root.findtext('metadata/num_results')=='1'
 objects[f]=(p,o)
 inventory.append({'frame':f,'type':o.tag,'class':o.get('class')=='true','path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p),'xml_base':root.get('{http://www.w3.org/XML/1998/namespace}base'),'ptools_version':root.get('ptools-version'),'direct_slot_count':len(o)})
root=objects['METHANOGENESIS-PWY'][1]
members=[x.get('frameid') for s in root.findall('reaction-list') for x in s if x.tag=='Reaction']
assert len(members)==6
directions={}
for layout in root.findall('reaction-layout'):
 rxn=layout.find('Reaction');direction=layout.findtext('direction')
 if rxn is not None:directions[rxn.get('frameid')]=direction
direct_taxa=[s[0].get('frameid') for s in root.findall('species')]
range_taxa=[s[0].get('frameid') for s in root.findall('taxonomic-range')]
def refs(s):return [{'type':x.tag,'frame':x.get('frameid'),'attributes':dict(x.attrib)} for x in s.iter() if x.get('frameid')]
def slots(o,t):return [{'slot_index':i,'xml':E.tostring(s,encoding='unicode'),'references':refs(s)} for i,s in enumerate(o,1) if s.tag==t]
equations=[];occ=[];net=collections.Counter();compnet=collections.Counter()
for f in members:
 o=objects[f][1];sides={}
 for side in ('left','right'):
  terms=[]
  for i,s in enumerate(o,1):
   if s.tag!=side:continue
   obj=next(x for x in s if x.tag in ('Compound','Protein'));term={'frame':obj.get('frameid'),'native_type':obj.tag,'coefficient':int(s.findtext('coefficient') or 1),'coefficient_explicit':s.find('coefficient') is not None,'compartment':s.find('compartment/cco').get('frameid') if s.find('compartment/cco') is not None else None,'slot_index':i,'source_xml':E.tostring(s,encoding='unicode')};terms.append(term);occ.append(dict(term,reaction=f,side=side))
  sides[side]=terms
 reverse=directions[f]=='R2L'
 for side,terms in sides.items():
  sign=(-1 if side=='left' else 1)*(-1 if reverse else 1)
  for t in terms:net[t['frame']]+=sign*t['coefficient'];compnet[(t['frame'],t['compartment'])]+=sign*t['coefficient']
 equations.append({'frame':f,'source_direction':o.findtext('reaction-direction'),'pathway_direction':directions[f],'label':plain(o.findtext('common-name')),'terms':sides,'activity_ids':[x.get('frameid') for s in o.findall('enzymatic-reaction') for x in s if x.tag=='Enzymatic-Reaction'],'xrefs':[{'db':s.findtext('dblink-db'),'id':s.findtext('dblink-oid'),'relationship':s.findtext('dblink-relationship'),'url':s.findtext('dblink-URL')} for s in o.findall('dblink')]})
activity_ids=sorted({a for e in equations for a in e['activity_ids']})
assert len(activity_ids)==15
activities=[]
for f in activity_ids:
 o=objects[f][1];c=o.find('enzyme/Protein').get('frameid');co=objects[c][1]
 activities.append({'frame':f,'reaction':o.find('reaction/Reaction').get('frameid'),'enzyme':c,'enzyme_direct_species':[s[0].get('frameid') for s in co.findall('species')],'direction':o.findtext('reaction-direction'),'physiologically_relevant':o.findtext('physiologically-relevant'),'cofactors':slots(o,'cofactor'),'regulations':slots(o,'regulated-by'),'evidence':slots(o,'evidence'),'citations':slots(o,'citation'),'comments':[plain(s.text) for s in o.findall('comment')],'assay_fields':{t:slots(o,t) for t in ('specific-activity','km','vmax','ph-opt','temperature-opt') if o.findall(t)}})
components=[];genes=[];regulations=[];taxa=[];materials=[];links=[];allslots=[];pubs=[]
backlinks={'appears-in-left-side-of','appears-in-right-side-of','cofactors-of','regulates','component-of','surrounds','surrounded-by','subclass','instance'}
follow={'Protein':{'component','gene','species','locations','location','cofactor','prosthetic-group','modified-form','unmodified-form'},'Enzymatic-Reaction':{'cofactor','regulated-by','enzyme'},'Regulation':{'regulator','regulated-entity'},'Gene':{'product','species'}}
closure=[]
for f,(p,o) in objects.items():
 for i,s in enumerate(o,1):
  rs=refs(s);disposition='retained scalar or contextual source slot'
  if s.tag in backlinks:disposition='retained backlink/class/context; no expansion outside selected pathway closure'
  if s.tag in ('credits','has-feature'):disposition='retained metadata; no mechanism claim'
  if o.get('class')!='true' and s.tag in follow.get(o.tag,set()):
   disposition='biological forward-closure slot'
   for x in rs:
    if x['type'] not in ('Publication','Evidence-Code','Person','Organization'):
     closure.append({'owner':f,'slot':s.tag,'slot_index':i,'target':x['frame'],'target_type':x['type'],'resolved':x['frame'] in objects})
  if f=='METHFORM-PWY':disposition='boundary-only linked pathway; not membership expansion'
  allslots.append({'owner':f,'index':i,'tag':s.tag,'disposition':disposition,'reference_count':len(rs),'xml':E.tostring(s,encoding='unicode')})
  for j,x in enumerate(rs,1):links.append(dict(x,owner=f,slot=s.tag,slot_index=i,ordinal=j,resolved_in_finite_packet=x['frame'] in objects,disposition=disposition))
  for x in rs:
   if x['type']=='Publication':pubs.append({'owner':f,'slot':s.tag,'slot_index':i,'native_publication':x['frame'],'reading_role':'citation pointer, not evidence that original paper was read'})
  if s.tag=='comment':
   parser=Text();parser.feed(s.text or '')
   for u in parser.links:
    if any(k in u for k in ('pubmed','PubMed','PUB-','list_uids')):pubs.append({'owner':f,'slot':'comment','slot_index':i,'url':u,'reading_role':'native commentary citation lead, not primary reading'})
 if o.tag=='Protein':
  for i,s in enumerate(o,1):
   if s.tag=='component':components.append({'complex':f,'component':s[0].get('frameid'),'coefficient_literal':s.findtext('coefficient'),'slot_index':i,'source_xml':E.tostring(s,encoding='unicode')})
 if o.tag=='Gene':genes.append({'frame':f,'name':o.findtext('common-name'),'products':[x.get('frameid') for s in o.findall('product') for x in s if x.tag=='Protein'],'slots':[a for a in allslots if a['owner']==f]})
 if o.tag=='Regulation' and o.get('class')!='true':regulations.append({'frame':f,'mode':o.findtext('mode'),'regulator':o.find('regulator')[0].get('frameid'),'target_activity':o.find('regulated-entity')[0].get('frameid'),'physiologically_relevant':o.findtext('physiologically-relevant'),'mechanism':o.findtext('mechanism'),'citations':slots(o,'citation')})
 if o.tag=='Organism':taxa.append({'frame':f,'name':o.findtext('common-name'),'rank':o.findtext('rank'),'strain_name':o.findtext('strain-name'),'role':'direct pathway species association' if f in direct_taxa else 'direct pathway taxonomic range' if f in range_taxa else 'catalyst species or nested taxonomy context','source_species_users':[a['frame'] for a in activities if f in a['enzyme_direct_species']],'issuer_equivalence':'not verified here; native NCBI pointer only','xrefs':[{'db':s.findtext('dblink-db'),'id':s.findtext('dblink-oid')} for s in o.findall('dblink')]})
 if o.tag=='Compound' or f in ('Oxidized-ferredoxins','Reduced-ferredoxins'):
  cm=o.find('cml/molecule');formula=cm.find('formula').get('concise') if cm is not None and cm.find('formula') is not None else None
  materials.append({'frame':f,'type':o.tag,'class':o.get('class')=='true','label':plain(o.findtext('common-name')),'in_member_equation':f in {x['frame'] for x in occ},'formula_concise':formula,'cml_formal_charge':cm.get('formalCharge') if cm is not None else None,'smiles':cm.findtext("string[@title='smiles']") if cm is not None else None,'inchi':o.findtext('inchi'),'inchi_key':o.findtext('inchi-key'),'comments':[plain(s.text) for s in o.findall('comment')],'xrefs':[{'db':s.findtext('dblink-db'),'id':s.findtext('dblink-oid'),'relationship':s.findtext('dblink-relationship')} for s in o.findall('dblink')],'identity_disposition':'native source retained; no external exact-equivalence or stereochemical validation in source preparation'})
save('native-object-inventory.json',inventory);save('native-direct-slot-ledger.json',allslots);save('native-reference-occurrences.json',links);save('biological-forward-closure.json',closure)
save('member-equations.json',equations);save('member-material-occurrences.json',occ);save('activity-ledger.json',activities);save('complex-components.json',components);save('gene-ledger.json',genes);save('regulation-ledger.json',regulations);save('taxon-ledger.json',taxa);save('material-identity-source-ledger.json',materials);save('primary-citation-leads.json',pubs)
summary={'objects':len(objects),'types':dict(collections.Counter(o.tag for _,o in objects.values())),'members':len(members),'material_occurrences':len(occ),'unique_equation_materials':len({x['frame'] for x in occ}),'activities':len(activities),'direct_catalysts':len({x['enzyme'] for x in activities}),'component_occurrences':len(components),'real_regulations':len(regulations),'direct_pathway_taxa':direct_taxa,'taxonomic_range':range_taxa,'closure_occurrences':len(closure),'closure_unresolved':[x for x in closure if not x['resolved']],'all_own_slots':len(allslots),'all_frame_reference_occurrences':len(links),'formal_compartment_collapsed_net':dict(sorted((f,c) for f,c in net.items() if c)),'formal_compartment_retained_net':[{'frame':f,'compartment':c,'coefficient':v} for (f,c),v in sorted(compnet.items(),key=str) if v],'net_limit':'Signed products minus reactants, one pass through each source layout. Collapsing compartments is an explicitly lossy diagnostic; unspecified locations are not automatically CCO-IN. Generic carriers prevent a complete atom/charge proof; neither net proves physiological flux or methane formation.'}
save('native-closure-summary.json',summary);print(json.dumps(summary,indent=2))
