import Foundation
import PDFKit
import AppKit

let args = CommandLine.arguments
guard args.count == 3 else { fatalError("usage: read_pdf INPUT.pdf OUTPUT_DIR") }
let input = URL(fileURLWithPath: args[1])
let output = URL(fileURLWithPath: args[2], isDirectory: true)
try FileManager.default.createDirectory(at: output, withIntermediateDirectories: true)
guard let document = PDFDocument(url: input) else { fatalError("PDFKit could not open input") }
var text = ""
for i in 0..<document.pageCount {
    guard let page = document.page(at: i) else { fatalError("missing page") }
    text += "\n[PDF PAGE \(i+1)]\n" + (page.string ?? "") + "\n"
    let bounds = page.bounds(for: .mediaBox)
    let width = 1600
    let height = Int(ceil(Double(width) * bounds.height / bounds.width))
    guard let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0), let context = NSGraphicsContext(bitmapImageRep: bitmap) else { fatalError("render allocation failed") }
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = context
    let cg = context.cgContext
    cg.setFillColor(NSColor.white.cgColor)
    cg.fill(CGRect(x: 0,y: 0,width: width,height: height))
    cg.scaleBy(x: Double(width)/bounds.width, y: Double(height)/bounds.height)
    page.draw(with: .mediaBox, to: cg)
    NSGraphicsContext.restoreGraphicsState()
    guard let data = bitmap.representation(using: .png, properties: [:]) else { fatalError("PNG encoding failed") }
    try data.write(to: output.appendingPathComponent(String(format:"page-%03d.png",i+1)))
}
try text.write(to: output.appendingPathComponent("complete-text.txt"), atomically: false, encoding: .utf8)
print("PDFKit read and rendered \(document.pageCount) pages; \(text.count) text characters")
