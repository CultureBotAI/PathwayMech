from pathlib import Path
import collections, hashlib, json, xml.etree.ElementTree as E

R = Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads((R / p).read_text())
def save(p, v): (R / p).write_text(json.dumps(v, indent=2, ensure_ascii=False) + '\n')
inventory = read('results/native-object-inventory.json')
byid = {x['frame']: x for x in inventory}
slots = read('results/native-direct-slot-ledger.json')
def loc(frame, tags):
    return [{'path': byid[frame]['path'], 'sha256': byid[frame]['sha256'],
             'frame': frame, 'slot': s['tag'], 'one_based_slot': s['index']}
            for s in slots if s['owner'] == frame and s['tag'] in tags]

attempts = []
for p in sorted((R / 'receipts').glob('*.json')):
    if p.name == 'web-search-and-open-results.json':
        continue
    x = json.loads(p.read_text())
    output = x.get('output')
    body = R / output if output else None
    produced = bool(x.get('sha256'))
    if produced and body and body.exists():
        assert sha(body) == x['sha256'], p
    kind = 'native request' if output and '/native/' in output else 'primary access attempt'
    if p.name == 'reuse-NA+.json': kind = 'verified reuse; no fresh acquisition'
    content = body.read_bytes() if produced and body and body.exists() else b''
    if content.startswith(b'%PDF-'): role = 'authentic PDF body'
    elif content.startswith(b'PK'): role = 'office archive body'
    elif output and '/native/' in output and x.get('status') == 200:
        role = 'native XML; exact-object validation separately retained'
    elif x.get('status') != 200: role = 'unsuccessful access; not full primary evidence'
    elif b'does not allow downloading of the full text' in content.lower() or b'not available' in content.lower() and b'<article' in content:
        role = 'availability-limited XML, not full article'
    elif b'checking your browser' in content.lower() or b'recaptcha' in content.lower() or b'pow-challenge' in content.lower():
        role = 'HTML challenge; not full article'
    else: role = 'retrieved body; specific reading role in primary-reading-scopes.json'
    attempts.append({'receipt': str(p.relative_to(R)), 'receipt_sha256': sha(p), 'kind': kind,
                     'url': x.get('url'), 'final_url': x.get('final_url'), 'status': x.get('status'),
                     'error': x.get('error'), 'output': output, 'bytes': x.get('bytes'),
                     'sha256': x.get('sha256'), 'body_role': role,
                     'later_file_at_unproduced_output_is_not_this_attempt': bool(not produced and body and body.exists())})
save('results/acquisition-attempt-ledger.json', attempts)

claims = []
def claim(n, text, status, native, primary=None, limit=''):
    claims.append({'id': f'N270-S{n:02}', 'claim': text, 'disposition': status,
                   'native_locators': sum([loc(f, tags) for f, tags in native], []),
                   'primary_scope': primary or [], 'limitations': limit})
claim(1, 'The exact native definition has six members and five ordering relations, ending at methyl-CoM.', 'source-supported',
      [('METHANOGENESIS-PWY', ['reaction-list', 'reaction-ordering', 'reaction-layout'])],
      limit='It is not a complete methane-forming or energy-conserving system; METHFORM-PWY is a linked boundary, not a seventh member.')
claim(2, 'Native Mtr transfers a methyl group and translocates two Na+ from CCO-IN to CCO-OUT.', 'source-supported, primary exact stoichiometry unresolved',
      [('2.1.1.86-RXN', ['left', 'right', 'reaction-direction'])], ['PMID:7737157 abstract; Kurth2021 full main Fig.5 is a model'],
      'Keep compartment-specific occurrences and coefficient 2. No measured sodium stoichiometry in the freshly read Kurth study; no general transport schema decision here.')
claim(3, 'The source uses Hmd/H2 for the fourth member, separately from the F420-dependent Mtd alternative.', 'source-supported with abstract corroboration',
      [('METHANOGENESIS-PWY', ['reaction-list']), ('H2-METHYLENE-THMPT-DEHYDRO-RXN', ['left', 'right']), ('CPLX-622', ['comment'])],
      ['PMID:1521540 complete abstract; Kurth2021 Fig.2/5 and TableS1 use Mtd'],
      'Do not substitute the Kurth Mtd/F420 route or double-count it as a native member.')
claim(4, 'Root Mch layout is R2L, while both experimentally annotated native Mch activities are PHYSIOL-LEFT-TO-RIGHT.', 'explicit source direction conflict',
      [('METHANOGENESIS-PWY', ['reaction-layout']), ('ENZRXN-662', ['reaction-direction']), ('ENZRXN-4121', ['reaction-direction'])],
      ['PMID:3782039 and PMID:10215859 abstracts'], 'No silent direction repair or universal physiological flux inference.')
claim(5, 'Root species associations are M. barkeri, M. thermautotrophicus and the genus Methanothermus; Euryarchaeota is a separate phylum range.', 'source-supported associations only',
      [('METHANOGENESIS-PWY', ['species', 'taxonomic-range'])], limit='Native source rank and historical label retained; external NCBI current taxonomy and complete-route experiments not verified here.')
claim(6, 'Fmd uses generic methanofuran and ferredoxin classes; Mer uses generic F420 classes.', 'source-supported generic scope',
      [('FORMYLMETHANOFURAN-DEHYDROGENASE-RXN', ['left', 'right']), ('METHELENE-THMPT-OXI-RXN', ['left', 'right'])],
      limit='No single molecular species, fixed ferredoxin sequence, full atom/charge balance, or ChEBI equivalence follows from class labels.')
claim(7, 'Native SMILES are insufficient for exact identity in eight R-containing material entries, plus the H2 [H] discrepancy.', 'source-internal representation warning',
      [(f, ['cml', 'inchi', 'inchi-key']) for f in ('CPD-7162','CoM','Formyl-methanofurans','METHYL-THMPT','Me-CoM','Methanofurans','Oxidized-Factor-F420','Reduced-Factor-F420','HYDROGEN-MOLECULE')],
      limit='Four nonclass compounds have [R] despite concrete formula/InChI. This is not a claim that their CML graphs or InChIs have been chemically validated.')
claim(8, 'Fmd molybdenum and tungsten cofactors and cyanide responses remain catalyst-specific.', 'source-supported; partial primary corroboration',
      [('ENZRXN-422', ['cofactor','regulated-by']), ('ENZRXN-641', ['cofactor','regulated-by']), ('ENZRXN-642', ['cofactor'])],
      ['PMID:2253782 and PMID:8125106 complete abstracts'],
      'Do not transfer Mo cyanide inhibition to the W isoenzyme; old one-MGD wording and modern bis-pterin source compound remain unreconciled.')
claim(9, 'Hmd historical absence of Ni/FeS/flavins does not establish absence of an iron cofactor.', 'historical-source limitation',
      [('CPLX-622', ['comment','component'])], ['PMID:1521540 abstract; PMID:20221540 abstract of M. jannaschii enzyme'],
      'Exact native Hmd FeGP identity and stoichiometry require primary/issuer work; the newer abstract is a different organism and is not a direct mapping.')
claim(10, 'Native Mtr complex prose says only cobamide prosthetic group while the linked activity also asserts FeS cofactor.', 'unresolved source cofactor conflict',
      [('CPLX-643', ['comment']), ('ENZRXN-702', ['cofactor'])], ['PMID:8477726 and PMID:7737157 abstracts'],
      '1993 measured iron/sulfur and seven polypeptides; 1995 reports eight. Do not combine per-complex quantities across preparations or silently delete either native assertion.')
claim(11, 'Historical Marburg catalyst prose and species/delta-H pointers are not automatically exact strain or protein identity.', 'unresolved identity conflict',
      [('HMDMAUTO-MONOMER', ['comment','species','dblink']), ('MERMAUTO-MONOMER', ['comment','species','dblink'])],
      ['PMID:7649177 Marburg abstract versus PMID:8522533 delta H abstract'],
      'Retain native IDs until current taxonomy and accession/sequence originals reconcile the particular claim.')
claim(12, 'Five Archaeoglobus fulgidus activities are native associations without activity evidence tags or declared directions.', 'source-only context',
      [(f, ['enzyme','reaction','physiologically-relevant']) for f in ('ENZRXN26TB-100','ENZRXN26TB-273','ENZRXN26TB-48','ENZRXN26TB-75','ENZRXN26TB-96')],
      limit='Homology/annotation and shared C1 reactions do not establish methanogenesis or the complete six-member route.')
claim(13, 'Methylorubrum extorquens AM1 Mch belongs to bacterial C1 metabolism; its native association is not evidence of methane formation.', 'source-supported, abstract corroboration',
      [('ENZRXN-4121', ['evidence','specific-activity','km','vmax']), ('CPLX-3321', ['species','comment'])],
      ['PMID:10215859 complete abstract'], 'Abstract supports substrate-specific purified enzymes and a suggested catabolic role; full assay conditions are not newly verified.')
claim(14, 'Kurth2021 experimentally studies methoxy-compound demethylation by Mto and expression of methanogenesis genes, not an isolated Mtr sodium-pumping assay.', 'full-primary-supported qualification',
      [('ENZRXN2065-393', ['evidence']), ('CPLX2065-6', ['component','species'])],
      ['Kurth2021 main Methods/Results, Figs.1–4, TableS1 rows25–32, TableS2 rows57–64'],
      'Preserve native EV-EXP-IPI as source metadata, not an independently accepted exact Mtr catalysis experiment.')
claim(15, 'The Kurth MtoA methyl-acceptor experiment uses tetrahydrofolate as a surrogate; CoM is a negative acceptor.', 'full-primary-supported', [],
      ['Kurth2021 main Methods pp.4–5 and Results pp.9–11, Fig.3; supplement Fig.S2'],
      'Native H4MPT acceptor assignment is inferred in that experiment. MtoA BP07_RS03240 differs from MtrH BP07_RS06315; do not transfer activity.')
claim(16, 'Kurth Mtr-centered energy model and oscillating flux scenarios are hypotheses, not measured pathway-wide flux.', 'full-primary-supported limitation', [],
      ['Kurth2021 main Discussion/Fig.5; supplementary results, Figs.S4/S7, TableS3'],
      'Resting-cell product ratios and qualitative 13C experiments do not validate the full model or universal 1:3 disproportionation.')
claim(17, 'Vorholt1997 directly concerns the Fmd CO2 versus bicarbonate substrate question and a proposed intermediate.', 'abstract-only corroboration',
      [('METHANOGENESIS-PWY', ['evidence'])], ['PMID:9342247 complete abstract'],
      'Full main, figures and assays remain unavailable. Pathway-level native experimental tag is not a whole-route primary experiment.')
claim(18, 'Kaster2011 concerns MvhADG/HdrABC electron bifurcation in M. marburgensis, outside the six native members.', 'abstract plus inherited partial-main reading only', [],
      ['PMID:21262829 complete abstract; preflight PRIMARY-READING exact partial scope'],
      'No fresh authentic full main/SI; do not infer a universal membrane methanophenazine mechanism or promote assay ferredoxin to native fixed identity.')
claim(19, 'Formal one-pass reaction net is distinct from a physiological methane balance.', 'derived diagnostic only',
      [(f,['left','right']) for f in [x['frame'] for x in read('results/member-equations.json')]],
      limit='Compartment-preserving net keeps Na+ transport and unresolved located/unlocated carrier residuals; generic carriers prohibit full molecular balancing.')
claim(20, 'All seven real native regulations have exact activity targets, distinct from the extra Regulation class object.', 'source-supported contextual regulations',
      [(x['frame'],['regulator','regulated-entity','mode','citation']) for x in read('results/regulation-ledger.json')],
      ['PMID:3782039 abstract supports Mg stimulation and 10-formyl inhibition; PMID:8125106 abstract supports Mo-specific cyanide effect'],
      'Other regulator details are source-only pending cited full papers. No flattening onto all generic reactions or taxon-wide regulation.')
save('results/claim-dispositions.json', claims)

abstracts = read('reading/selected-pubmed-abstracts.json')
scopes = [{'source': 'originals/primary/selected-pubmed.xml', 'sha256': sha(R/'originals/primary/selected-pubmed.xml'),
           'selector': 'PubmedArticle PMID='+a['pmid'], 'doi': a['ids'].get('doi'), 'title': a['title'],
           'read': 'All returned abstract paragraphs and bibliographic identity; no full article implied',
           'full_original_acquired_here': a['pmid']=='34145392'} for a in abstracts]
for p, scope in [
 ('kurth2021.pdf','Complete text of all 17 pages, including Methods, Results, Discussion and references; all five figures visually inspected on PDF pages 8,10,11,13. All pages rendered; no claim that every nonfigure page was visually read.'),
 ('kurth2021-supp1.docx','All document body text, supplementary results, seven captions and references read. All seven original embedded figure images visually inspected. DOCX page layout not rendered.'),
 ('kurth2021-supp2.xlsx','TableS1 rows1–5,25–32,38–47 read deliberately (23 rows). Additional rows48–96 were printed during a broad footer probe with truncated output: not accepted as full-sheet reading. All195 rows/33 columns extracted; no whole-sheet scientific review or visual layout claim.'),
 ('kurth2021-supp3.xlsx','TableS2 selected15 rows:1–5,25,57–65, including eight Mtr subunits. All1643 rows/23 columns extracted, not all read. No whole-sheet or visual layout claim.'),
 ('kurth2021-supp4.xlsx','All40 TableS3 rows/8 columns read, including blanks. Energy assumptions treated as authors model, not independent thermodynamic verification.'),
 ('kurth2021.html','Publisher landing/full text used for exact PDF/supplement links; full-paper reading is bound to the PDF.'),
 ('kaster-mpg-api.json','Complete institutional metadata JSON read; external DOI pointer, no retrieved PDF file.'),
 ('kaster-efetch.xml','Availability statement and abstract/metadata read; explicitly not full article.'),
 ('mer-efetch.xml','Availability-limited metadata/abstract XML; not full article.')]:
    scopes.append({'source':'originals/primary/'+p,'sha256':sha(R/'originals/primary'/p),'read':scope})
save('results/primary-reading-scopes.json', scopes)

activities = read('results/activity-ledger.json')
pmids = {'ENZRXN-4121':['10215859'], 'ENZRXN-422':['9342247','2253782','8125106'],
         'ENZRXN-641':['8125106'], 'ENZRXN-642':['8125106'], 'ENZRXN-661':['3097011'],
         'ENZRXN-662':['3782039'], 'ENZRXN-682':['1521540'], 'ENZRXN-701':['7649177','8522533'],
         'ENZRXN-702':['8477726','7737157'], 'ENZRXN2065-393':['34145392']}
dispositions=[]
for a in activities:
    f=a['frame']
    status='native association only; no activity evidence code or direction supplied' if f.startswith('ENZRXN26TB') else 'native association with bounded primary abstract corroboration; full historical assay unverified'
    if f=='ENZRXN2065-393': status='native association retained; fresh full primary supports gene/expression context and a hypothetical Mtr energy role, not purified Mtr assay'
    dispositions.append({'activity':f,'reaction':a['reaction'],'enzyme':a['enzyme'], 'native_direction':a['direction'],
                         'source_species':a['enzyme_direct_species'],'native_source':loc(f,['enzyme','reaction','evidence','cofactor','regulated-by','reaction-direction']),
                         'primary_pmids':pmids.get(f,[]),'disposition':status,
                         'scope':'No activity-to-route, taxon, strain, or molecular identity transfer; exact native association and assay slots remain in activity-ledger.json.'})
save('results/activity-dispositions.json',dispositions)

prereqs=[
 ('SP01','Independent review of this preparation and actual baseline rebind before any maintained integration.','All packet artifacts; baseline265 plus pendingPWY5177 exclusions remain finite.'),
 ('SP02','Acquire/read authentic Vorholt1997 main if legitimate access becomes available; otherwise keep abstract-only.','PMID9342247; DOI10.1111/j.1432-1033.1997.00919.x; Wiley403 retained.'),
 ('SP03','Acquire/read authentic Kaster2011 main/SI if available; otherwise retain exact inherited partial scope.','PMID21262829; PMC3041090; DOI10.1073/pnas.1016761108; publisher403, PMC challenge and availability-limited XML retained.'),
 ('SP04','Reconcile exact historical Marburg/delta-H taxa and gene/protein accession identities before public mapping.','HMDMAUTO-MONOMER, MERMAUTO-MONOMER and associated native species/dblinks; PMID7649177/8522533/8477726/7737157.'),
 ('SP05','Chemically assess issuing-authority candidates, CML/InChI/stereo/microstates and generic carrier scope.','Six Rhea and six KEGG candidates; all28 material identity rows; eight [R] entries and H2 literalSMILES warning. No external equivalence accepted.'),
 ('SP06','Choose a faithful transport-aware representation before any graph implementation.','Mtr exact2Na in/out; unrelated steps have unspecified compartments. No silently collapsed net or invented common location.'),
 ('SP07','Preserve or adjudicate Mch direction and Mtr cofactor conflicts explicitly.','ENZRXN662/4121 vs root R2L; ENZRXN702 FeS vs CPLX643 only-cobamide prose; PMID3782039/10215859/8477726/7737157 full originals not read.'),
 ('SP08','Retain regulator/source-only historical assertions with exact activity scope unless fuller primary reading supports promotion.','Seven regulation objects; HCN/Na/Mg/Mn/10-formylTHMPT/O2; citation leads in primary-citation-leads.json.'),
 ('SP09','Do not treat Hmd old metal language, source tetramer, or modern other-species FeGP paper as resolved native structure.','PMID1521540 full original; exact native Hmd follow-up; PMID20221540 is M.jannaschii abstract only.'),
 ('SP10','If expanding Mtr elementary mechanism, acquire the comment-only methylated cobamide intermediate and exact primary assays first.','CPLX643 comment references CPD7163 and PMIDs8001564,8223548,7813469,8898900,9461302; outside direct-slot closure.'),
 ('SP11','Curate source boundary and evidence levels visibly; source pathway commentary overgeneralizes disproportionation and membrane electron transport.','METHANOGENESIS-PWY comment; Kaster partial evidence and Kurth full evidence are context-specific, not one universal methane pathway.'),
]
save('results/unresolved-prerequisites.json',[{'id':i,'required_action':a,'exact_leads':b,'status':'open; not an automatic blocker to retaining qualified source-only assertions'} for i,a,b in prereqs])

warnings=[]
for m in read('results/material-identity-source-ledger.json'):
    if '[R]' in (m['smiles'] or ''): warnings.append({'frame':m['frame'],'kind':'literal SMILES generic substituent','class':m['class'],'formula':m['formula_concise'],'has_inchi':bool(m['inchi']),'locators':loc(m['frame'],['cml','inchi'])})
warnings.append({'frame':'HYDROGEN-MOLECULE','kind':'literal [H] SMILES versus H2 formula/InChI; no chemical parser equivalence accepted','locators':loc('HYDROGEN-MOLECULE',['cml','inchi'])})
save('results/material-representation-warnings.json',warnings)

print(json.dumps({'claims':len(claims),'primary_scopes':len(scopes),'activities':len(dispositions),'prerequisites':len(prereqs),'receipts':len(attempts),'material_warnings':len(warnings)},indent=2))
