# Native graph design: MetaCyc:METHANOGENESIS-PWY

This is a complete proposed representation of the accepted, finite native source scope. It is a scratch design, not a maintained record or independent acceptance. The six registry packets are copied and fully hash-verified: 707 physical files. The corrected twenty-claim ledger is SHA256 `08730dcd80abda474f8fa5dc3bdd3ad2d9edb21e79f94a7b278001ef183fac2b`. Mutable issuer work is excluded. The subsequently released 400-file issuer author packet is copied and fully hash-verified separately (manifest `dfc7cef1e269d870034b347abb99af7dd473f434cd487a2083105bb7f439e851`). Its dispositions constrain this design but are not independently accepted here; no new public alias or taxon is promoted. Together the seven input packets contain 1,107 physical files. The copied contracts come from the integrated next269 working tree at base `7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105`; they do not certify a later merged 266-record baseline.

## Exact source graph

The proposed biochemical graph has 101 native nodes and 125 edges. Three direct taxon declarations remain separate obligations until their issuing identities/ranks are independently accepted. They must not disappear merely because the biochemical probe has an empty taxon list.

| Relation role | Occurrences |
| --- | ---: |
| Source pathway membership | 6 |
| Source ordering | 5 |
| Full reaction material terms | 30, covering 18 material IDs |
| Qualified native catalyst associations | 13 |
| Exact enzyme-specific activity enables | 5 |
| Complex component assertions | 43 |
| Activity-sourced cofactor assertions | 6 |
| Explicit physical-entity locations | 10 |
| Exact native regulations | 7 |

The six members retain this order and selected layout: FORMYLMETHANOFURAN-DEHYDROGENASE-RXN R2L; 2.3.1.101-RXN L2R; 3.5.4.27-RXN R2L; H2-METHYLENE-THMPT-DEHYDRO-RXN L2R; METHELENE-THMPT-OXI-RXN R2L; 2.1.1.86-RXN L2R. Reaction nodes retain their own source direction: five reversible reactions and physiological L2R Mtr. All six lack a direct common-name; their exact native frame labels are retained rather than curated chemical titles.

The endpoint is methyl-CoM. METHFORM-PWY is retained as an original and a reference for the downstream boundary, but is not a seventh member or an extra graph reaction. No methane, heterodisulfide regeneration, Mvh/Hdr, membrane methanophenazine or universal 1:3 disproportionation is added. Other pathway links, superpathways and DRAM alternatives remain contextual source leads. Their existence does not establish an exact alias for this six-member definition.

The 101 graph IDs consist of the root, six Reactions, 59 Protein objects (including two generic ferredoxin classes), 26 Compounds, five exact Enzymatic-Reaction activities and four cellular-component objects. The two inside/outside compartments remain declared context even though no false global located_in relation is invented. The source still contains 177 fully acquired native objects. All have a disposition, including 45 gene/product originals retained as provenance, twelve taxon contexts, ten unregulated activity references, seven regulation reference objects plus their class, and the boundary pathway. The graph is not a projection of every source backlink or comment hyperlink.

## Directions and activity identity

All fifteen native activities have a concrete disposition. The two Mch activities ENZRXN-662 and ENZRXN-4121 declare physiological L2R hydrolysis while the root layout selects R2L dehydration. Their exact activity nodes, enzyme enables and regulations are preserved, with their reaction association and direction conflict on the incident edges. They are not emitted as catalysts of the selected dehydration. This does not deny their native association with the reversible generic Reaction.

The remaining thirteen enzyme-to-reaction edges are qualified native source assertions. Five Archaeoglobus fulgidus DSM 4304 associations lack an activity evidence tag and direction; their shared C1 annotations are explicitly not evidence of methanogenesis. Methylorubrum extorquens AM1 Mch remains bacterial C1 context. Historical Marburg, species and delta-H pointers remain distinct and unresolved. No modern protein, sequence, gene or strain accession is substituted.

The five activity participants are ENZRXN-422, ENZRXN-641, ENZRXN-4121, ENZRXN-662 and ENZRXN-702. HCN inhibits the first two Mo activities; Na+ activates ENZRXN-4121; 10-formyl-THMPT inhibits, Mg2+ activates and Mn2+ inhibits ENZRXN-662; oxygen inhibits ENZRXN-702. Regulation-of-Enzyme-Activity is a class, not an eighth instance. Targets remain activities rather than generic Reactions, all isoenzymes or whole organisms. Missing inverse links do not erase the independently acquired Regulation objects.

Every component occurrence remains separate, including absent coefficients. An omitted coefficient is never silently replaced by one. Native Hmd tetramer and Mtr fourfold octamer annotations are preserved as historical source assertions; component membership is not independent subunit catalysis. Ten direct location slots become physical located_in edges. Prose-only predicted membrane topology does not add more locations.

## Chemistry and transport

The native fourth member is Hmd using H2; it is not the Mtd/F420 alternative discussed in Kurth. Generic methanofuran, F420 and ferredoxin classes remain generic. Eight [R]-containing structural strings and native H2 `[H]` versus formula/InChI H2 remain explicit representation warnings. No CML stereochemical validation, exact ChEBI/Rhea/KEGG equivalence or complete elemental/charge balance is claimed.

Mtr preserves all six located occurrences: CoM, methyl-THMPT and two Na+ at CCO-IN on the left; Me-CoM and THMPT at CCO-IN and two Na+ at CCO-OUT on the right. The other 24 reaction material occurrences are unlocated. Their shared identifiers cannot cancel against the located Mtr carrier occurrences in a location-aware net. Sodium is not assigned one global location, and no ion-gradient, ATP yield or full methane balance follows from formal arithmetic.

Mo/W cofactors and cyanide effects stay catalyst-specific. Native bis-pterin identifiers do not silently reconcile historical single-MGD prose. The six cofactor assertions target five explicitly categorized cofactor nodes, matching the current schema. Mtr retains its source conflict: ENZRXN-702 lists FeS and cobamide, whereas CPLX-643 prose says only the cobamide prosthetic group. Neither statement is deleted or represented as a reconciled measured stoichiometry. Historical Hmd absence of Ni/FeS/flavins is not absence of an iron cofactor; a newer different-organism FeGP lead is not adopted.

## Frozen issuer qualifications

The complete 108-row issuer impact ledger retains all eighteen material, six reaction, fifty-seven protein, fifteen activity and twelve native taxon dispositions. These are author-prepared constraints pending separate peer acceptance, not a new independent chemistry or sequence review. The native IDs remain the graph identities.

FORMYL-THMPT remains distinct from neutral ChEBI:17114 and stereo-underdetermined ChEBI:58018; matching charge alone does not close the native stereocenter. Native hydron remains isotope-unspecified. The issuer author reports twelve concrete constitutions and six generic materials; no specific F420, methanofuran or ferredoxin example replaces a generic class. Rhea's Mer proton and narrower F420 scope, KEGG Ftr/Fmd proton differences, and Rhea Mtr's unspecified carrier compartments remain different from the native occurrences. A matching Hmd equation does not establish whole-pathway equivalence.

The AF_RS10430/O28206 source remains formyltransferase-like and similarity-only, separate from AF_RS11105/O28076 Ftr. Nine AF protein pointers retain strain/locus scope; eight divergent GeneID pointers are unresolved. O28076 also carries historical sequence conflicts at positions 32, 34 and 43. These annotations are not whole native sequence comparisons or independent assays.

The historical Mer G-356/X86477/CAA60203.1 translation matches Q50744 Marburg but differs from O27784 Delta H at five residues (191, 196, 197, 213, 247); the historical ENA taxon label and additional issuer sequence conflicts remain explicit. No Marburg kinetics are transferred to Delta H. O27211 has an erroneous-initiation caution, O27002 retains similarity-level function versus native unknown function, and O27227 cofactor/transport annotation does not establish a measured pump assay. O85014 retains AM1 oxidative C1 scope. The native species-level objects and components remain intact; none is silently replaced by an accession.

## Taxon obligations

The root's three direct associations must be retained at their actual source ranks: TAX-2208 Methanosarcina barkeri, species; TAX-145262 Methanothermobacter thermautotrophicus, species; TAX-2179 Methanothermus, genus. TAX-28890 Euryarchaeota is a separate historical range, not a fourth direct taxon. The other eight native organism objects support catalyst or nested taxonomy context only. All twelve dispositions and exact issuing-pointer source slots are retained. Public NCBITaxon terms are not accepted from these pointers alone. The later issuer review must reconcile rank/name/strain scope and repeated-baseline identity before the final taxa are written.

## Evidence and primary scope

Each of the 125 proposed graph edges has source_assertion evidence tied to exact original hash, object and one-based own-slot XPath. The full 2,061-own-slot inventory has a separate disposition ledger. Each original or slot not promoted to an edge remains a preserved context/identity/backlink, not a silently discarded source or a claim that every embedded annotation was human-read.

The accepted twenty claims are retained with explicit narrative and incident-edge placement obligations. Their original primary-reading scopes are reused from the separate independent closure review. This design is not a fresh independent full-paper review. No database comment is converted into a paper quotation, and no primary assay edge is manufactured from an experimental database tag.

Kurth2021 supports Mto demethylation experiments and expression context. Native MtoA/MtoB, heterologous MtoC/MtoD, the H4F surrogate and negative CoM acceptor remain distinct from MtrH or an isolated sodium-pumping assay. Corrected S15 cites Methods PDF6–7, Figure4C/caption and Results PDF11–12, and supplementary FigureS2B. Figure3 is not the experimental locator. The energy/oscillation schemes remain hypotheses; qualitative 13C and resting-cell product ratios are not full-route flux validation. The source EV-EXP-IPI remains metadata.

Fourteen inspected PubMed abstracts remain abstract-level evidence; except Kurth, full experimental originals are not newly accepted. Vorholt1997's first-enzyme substrate question and proposed intermediate do not establish the whole route. Kaster2011's electron-bifurcation system is outside membership, with only accepted abstract/partial-main scope. No new broad search or acquisition was performed.

The proposed 131 native reference entries use exact acquired HTTPS URLs. Sodium is explicitly a verified original reuse, not a successful new270 request. XML bases remain unchanged source metadata. Primary references/locators remain in the accepted claim/reading ledgers and must be carried into a final narrative; the biochemical probe's reference list contains native graph/context originals only.

## Contract limits and proposed solution

Closed NamedNode supports only id, label, category and direction, with direction on Reactions only. It has no description. Top-level MechanisticEdge has neither a structured coefficient nor per-material-occurrence compartment field. Three negative closed-schema probes confirm these boundaries. No extra fields are inserted.

The supported current representation keeps coefficients, explicit absence, source side, selected orientation, location and conflict in each incident edge's description and precise evidence. Actual KGX replay preserves the complete edge descriptions/evidence/reference metadata. The SVG preserves all 101 declarations and 125 directed links; accessible details carry scope. The four context nodes are not chemical reactants. The detailed-mechanism profile rejects transport/mixed locations and same-material boundary cancellation, so it is not used as a workaround for Mtr.

This is a real machine-readable compartment/stoichiometry limitation, not a claim that arbitrary consumers can reconstruct transport from bare endpoints. A future typed extension would need per-occurrence source/target compartment identity and positive integer coefficient, preserving unspecified location separately, plus parser/schema/renderer/KGX/mutation tests. It must not mint biological CURIEs for located copies, globally locate shared carriers or silently alter existing profile semantics. Such work is a separate proposal; no governed or schema edits were made here. The source-faithful prose/evidence graph remains reviewable under the present contract.

## Authority and integration prerequisites

Nine graph IDs already exist in the copied authority snapshot; their existing owners/labels/class scope must remain unchanged. Ninety-two native graph IDs require bounded source-original authority support. The 131-reference union is not an instruction to promote every contextual reference to a graph term. Five unnamed homomers use the documented exact sole-activity naming rule provisionally; the unnamed heteromer CPLX-381 uses only its frame token and requires a separately reviewed source-context authority rule. No curated label allowlist, broad label waiver or guessed canonical protein name is proposed.

Before maintained curation: accept this design independently; read the frozen issuer closure and its independent review; reconcile any material finding without rewriting this packet; rebind novelty and exact aliases against the actual merged266-record baseline, including hidden/ignored files and bounded compressed history; implement/review additive authorities; compose the complete record including all three direct taxa and primary limits; run actual identifier/schema/full corpus gates; inspect final no-JS page and export; save a canonical maintained scientific review. Current source preparation and design do not certify those later stages.

## Verification limits

The author check reads copied native XML and reproduces exact material orientation, coefficient, compartment, component and regulation facts; all 125 source edges have locators. It exercises copied Python/closed-schema, KGX and SVG code without changing maintained owners or installing anything. The preview is a scratch structural probe with no issuer-accepted taxa, not a draft ready to commit. No pixel-level or interactive-browser review is claimed. Failed author probes remain with their exact scripts/logs and corrections; no failure is relabelled as a pass. Independent design review remains required.
