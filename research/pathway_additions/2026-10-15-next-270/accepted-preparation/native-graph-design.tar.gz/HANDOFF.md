# Handoff: next270 native methanogenesis graph design

This frozen scratch packet proposes the complete finite native representation of MetaCyc:METHANOGENESIS-PWY. It is author work for independent review, not a maintained record or scientific acceptance. No maintained, governed, schema, Git/GitHub or runtime files were changed; no new source acquisition was performed. All jobs are terminal.

## Concrete result

The proposed biochemical graph contains **101 native nodes and 125 edges**: six memberships, five source-order links, thirty material occurrences covering eighteen material IDs, thirteen qualified native catalyst associations, five exact activity enables, forty-three component occurrences, six cofactor assertions, ten physical locations and seven exact regulations. The terminal member produces methyl-CoM; METHFORM remains downstream boundary context only.

All 177 acquired native objects and all 2,061 own slots have finite dispositions. All fifteen activities, seven regulations and twenty corrected claims are accounted for. Native carrier classes, historical strains, both Mch activity/root direction conflicts, Hmd versus Mtd, Mo/W specificity, AF and bacterial C1 contexts, and the Mtr cofactor conflict remain explicit. Both conflicting Mtr cofactor statements are supported on the affected edges. Mtr retains two Na+ inside-to-outside and the exact locations of all six material occurrences; the other twenty-four occurrences remain unlocated.

The graph has 131 proposed native references with exact acquired HTTPS navigation URLs and original digests. Sodium uses a verified earlier original reuse; failed new acquisition attempts remain failures. Native frame labels are retained for all six unnamed Reactions; the unnamed CPLX-381 heteromer requires a reviewed source-context authority rule rather than an invented canonical name.

## Inputs and scientific limits

The six accepted source/closure/locator registry packets contain 707 physical files. The subsequently frozen issuer author packet adds 400 physical files, for 1,107 total. Every member, external original and copy was rehashed unchanged at finish. The nineteen copied contract/module inputs are hash-bound and unchanged; no live next269 dependency remains. These contract copies do not certify the actual merged 266-record baseline.

The corrected twenty-claim ledger SHA256 is `08730dcd80abda474f8fa5dc3bdd3ad2d9edb21e79f94a7b278001ef183fac2b`. Accepted primary reading scopes are reused, including corrected S15 Methods/Figure4C/Results/Supplement FigureS2B locators. This author design did not independently reread every full paper and does not convert database comments into paper quotations or assay proof.

The issuer input manifest is `dfc7cef1e269d870034b347abb99af7dd473f434cd487a2083105bb7f439e851`; its separate independent acceptance is pending at freeze. Its complete 108-row impact ledger preserves eighteen material, six reaction, fifty-seven protein, fifteen activity and twelve native taxon dispositions. No public alias or sequence substitution is accepted here. Formyl-THMPT stereochemistry/microstate distinctions, Mer proton and historical X86477/Marburg versus O27784/Delta-H sequence differences, AF_RS10430/O28206 family-only scope, divergent GeneIDs and exact historical range/taxon ranks remain obligations.

## Current contract and verification

Current NamedNode fields cannot carry scope, and current top-level edges lack typed material coefficient/compartment fields. Three negative closed-schema probes confirm these real limits. The supported design retains the exact occurrence scope in incident descriptions and evidence, plus a separate occurrence ledger. Actual KGX replay preserves those fields. No globally located sodium or fictitious located-material identifiers are introduced. A future typed occurrence extension is explicitly proposed as separate work; no schema broadening was attempted.

Copied Python/closed-schema/KGX/SVG checks pass: **1,369 assertions**, 101 SVG nodes, 125 directed graph links and all local evidence links resolved. Fresh isolated reproduction reran both scripts with exit 0 and reproduced all **20 generated output files byte-for-byte**. Earlier failed author probes and their source versions remain untouched. This is static structural QA; no interactive or pixel-level browser review is claimed.

## Exact review entry points

- `DESIGN.md`: complete representation, conflicts, limitations and integration requirements.
- `results/proposed-native-node-inventory.json` and `proposed-native-edge-inventory.json`: all declarations and edge/source bindings.
- `results/all30-material-occurrence-design.json`, `all15-activity-design-dispositions.json`, `all7-regulation-design-dispositions.json`, `all20-claim-design-dispositions.json`, `all12-native-taxon-design-dispositions.json`: finite scientific coverage.
- `results/all177-native-object-dispositions.json` and `all2061-own-slot-design-dispositions.json`: exclusions/context and complete own-slot coverage.
- `results/issuer-constraint-impact-ledger.json`: complete frozen issuer author constraints and affected edges, explicitly pending acceptance.
- `results/native-authority-requirements.json`: nine existing graph authority terms preserved, ninety-two new graph terms needing additive original-based authority support. Context references are not automatically terms.
- `results/native-biochemical-probe.yaml`, `native-design-preview.html`, `nodes.tsv`, `edges.tsv`: executable partial probe and structural projections, not a final curation draft.
- `results/design-checks.json`, `check-issuer-successor.stdout/.stderr`, `reproduction.json`, `reproduction-*.stdout/.stderr`, `final-input-verification.json`: terminal verification receipts.

## Remaining obligations before maintained promotion

Independent design review; separate issuer acceptance and any necessary successor reconciliation; actual merged266 baseline novelty/alias rebind; additive authority implementation and independent acceptance; all three direct taxa (2208 species, 145262 species, 2179 genus) with exact issuing support; final native/primary narrative with accepted reference scopes; actual maintained schema/identifier/corpus gates, final no-JS page/export QA and canonical maintained scientific review. Historical Euryarchaeota range is separate and must not become a fourth direct association. `taxa: []` in the biochemical test probe is intentionally incomplete and cannot be copied as a final omission.

The author has prior next269 authority/review responsibilities. This next270 packet makes no independent acceptance claim for its own graph or the issuer author's scientific conclusions. Every source edge is a qualified native source assertion; none certifies whole-route physiological flux.
