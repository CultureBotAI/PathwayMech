from pathlib import Path
import json,hashlib,subprocess,io,yaml
from html.parser import HTMLParser
O=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-270-record-preparation');H='e8ae5e445d3288717c31d3012611e226fd5cca34';W='/private/tmp/pathwaymech-next-270-20261015'
def sha(b):return hashlib.sha256(b).hexdigest()
def J(p):return json.loads(p.read_text())
checks=[]
def ck(n,b):assert b,n;checks.append(n)
class P(HTMLParser):
 def __init__(self):super().__init__();self.stack=[];self.texts=[];self.tags=[]
 def handle_starttag(self,t,a):
  d=dict(a);self.tags.append((t,d,self.getpos()));
  if t not in {'meta','link','input','br','hr','img','path','circle','line','polygon','polyline','rect','use','stop'}:self.stack.append((t,d))
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i][0]==t:self.stack=self.stack[:i];break
 def handle_data(self,d):self.texts.append((d,list(self.stack),self.getpos()))
def visible(stack):return not any(t in {'script','style','template','title'} or 'hidden' in a or a.get('aria-hidden')=='true' or 'display:none' in a.get('style','').replace(' ','') or 'visibility:hidden' in a.get('style','').replace(' ','') for t,a in stack)
r=yaml.load((A/'methanogenesis-from-h2-and-co2.yaml').read_bytes(),Loader=yaml.CSafeLoader);p=P();p.feed((O/'replay/preview/records/MetaCyc_METHANOGENESIS-PWY.html').read_text());data=[]
for e in r['mechanistic_edges']:
 hits=[(s,pos) for text,s,pos in p.texts if e['description'] in text and visible(s) and any(t=='td' for t,a in s)]
 ck('complete no-JS table description '+e['id'],bool(hits));data.append({'edge':e['id'],'visible_table_matches':len(hits),'first_line':hits[0][1][0]})
for c in J(A/'claim-placement-ledger.json'):
 hits=[(s,pos) for text,s,pos in p.texts if c['root_paragraph'] in text and visible(s) and any(t=='p' for t,a in s)]
 ck('visible root paragraph '+c['claim_id'],bool(hits))
for t in r['taxa']:ck('visible taxon '+t['id'],any(t['label'] in text and visible(s) for text,s,pos in p.texts))
ck('exact biochemical SVG graph nodes',sum('graph-node' in a.get('class','').split() and 'data-node-id' in a for t,a,pos in p.tags)==101)
# Exact62 copied landed contracts; do not review separately authored authority implementation.
b=J(A/'inputs/contract-bindings.json');contracts=[]
for x in b['files']:
 raw=subprocess.check_output(['git','cat-file','blob',H+':'+x['path']],cwd=W);copy=(A/'inputs/contracts'/x['path']).read_bytes();ck('landed contract '+x['path'],raw==copy and sha(raw)==x['sha256']);contracts.append({'path':x['path'],'sha256':sha(raw)})
ck('62 bound contract files',len(contracts)==62)
# Reused independent review acceptances and exact source-ledger correction.
peers=[('/private/tmp/pathwaymech-next-270-independent-source-closure-review','a64814d2b73ce4f5399704f087a816be51bae880fc448f13ec231a935d6812fe'),('/private/tmp/pathwaymech-next-270-source-locator-independent-acceptance','ef8ceb23771aae539748233f9f0099cfe14e363606d1bcfccacbe3c457597caf'),('/private/tmp/pathwaymech-next-270-independent-issuer-review','3d2baf4aa3bfbb0cf7278337e7796ea5c6c02c822ced83b7d4bfb6f611573a50'),('/private/tmp/pathwaymech-next-270-published-tree-novelty-review','7bc78495e1a7d55c2a7a9ba5b412677570d34f54d9d9414620769547e7765645')]
for src,want in peers:
 q=Path(src);ck('peer manifest '+q.name,sha((q/'artifact-manifest.json').read_bytes())==want);dest=O/'reused-reviews'/q.name;dest.mkdir(parents=True,exist_ok=True)
 for f in ['HANDOFF.md','artifact-manifest.json','freeze-proof.json']:(dest/f).write_bytes((q/f).read_bytes())
 if (q/'REVIEW.md').exists():(dest/'REVIEW.md').write_bytes((q/'REVIEW.md').read_bytes())
for x in J(A/'inputs/input-bindings.json'):
 raw=Path(x['original']).read_bytes();ck('author selected input original still exact '+x['copy'],sha(raw)==x['sha256'] and raw==(A/'inputs'/x['copy']).read_bytes())
# Final immutable author physical inventory and all actual referenced native/primary originals.
m=J(A/'artifact-manifest.json');physical={str(x.relative_to(A)) for x in A.rglob('*') if x.is_file()};ck('author physical set unchanged',physical=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'})
for x in m['files']:ck('author byte exact '+x['path'],sha((A/x['path']).read_bytes())==x['sha256'])
for x in J(O/'reference-bindings.json'):
 if x['id'].startswith('NCBITaxon:'):continue
 ck('bound reference still exact '+x['id'],sha(Path(x['body_path']).read_bytes())==x['sha256'])
# No cache rehash: stat rebind plus existing accepted complete-hash/selected-query scope.
q=J(A/'inputs/taxonomy-query-receipt.json');s=Path(q['cache']).stat();ck('pinned taxonomy cache stat unchanged',s.st_size==q['size'] and s.st_mtime_ns==q['mtime_ns_after'])
result={'status':'passed','additional_checks':len(checks),'checks':checks,'no_JS_visible_edges':125,'visible_claim_paragraphs':20,'SVG_nodes':101,'KGX_nodes':104,'landed_contracts_exact':62,'author_packet_final_physical':110,'cache_full_hash':'Reused accepted hash; no new14GB read','contract_commit':H,'authority_implementation_review':'Explicitly excluded; separate reviewer owns it.'}
(O/'final-checks.json').write_text(json.dumps(result,indent=2)+'\n');(O/'visibility-detail.json').write_text(json.dumps(data,indent=2)+'\n');(O/'contract-rebind.json').write_text(json.dumps(contracts,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
