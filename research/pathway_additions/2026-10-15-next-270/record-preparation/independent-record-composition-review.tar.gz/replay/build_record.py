"""Compose a reviewable candidate from copied accepted source/design inputs.

This writes only this scratch owner. It does not integrate or accept a record.
"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET

import yaml

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"


def read_json(name):
    return json.loads((INPUTS / name).read_text())


paragraphs = {
    "N270-S01": "MetaCyc METHANOGENESIS-PWY defines six ordered reactions from CO2 to methyl-CoM, using methanofuran, tetrahydromethanopterin and coenzyme M carriers. The source label is retained, but methyl-CoM reduction to methane belongs to the linked METHFORM-PWY boundary and is not a seventh member. Carrier regeneration, methane formation and a complete energy-conserving system are outside this six-member record. Native pathway evidence tags are source metadata, not independent proof of the complete route.",
    "N270-S02": "The native Mtr equation specifies two Na+ on each side, from CCO-IN to CCO-OUT. CoM and methyl-THMPT inputs and Me-CoM and THMPT outputs are all explicitly inside; the other 24 material occurrences in the pathway have unspecified locations. Exact coefficients, source side, selected orientation and occurrence-specific locations are retained in incident descriptions/evidence and the research ledger. They do not establish newly measured sodium stoichiometry, a globally located sodium species, ATP yield or physiological flux. The Kurth2021 energy scheme is a model, not a purified Mtr transport assay.",
    "N270-S03": "The fourth native member is Hmd using H2, distinct from the F420-dependent Mtd alternative discussed in Kurth2021. Five generic reaction definitions are reversible; the root selects R2L Fmd, L2R Ftr, R2L Mch, L2R Hmd, R2L Mer and L2R Mtr. Exact native reaction frame labels are retained where their own records lack common names. The Hmd abstract (PMID:1521540) supplies bounded corroboration, not evidence for replacing Hmd with Mtd.",
    "N270-S04": "The root selects Mch dehydration, whereas native ENZRXN-662 and ENZRXN-4121 explicitly specify physiological L2R hydrolysis. Both activities remain exact molecular-activity nodes with their enzyme enables and regulation assertions; neither is assigned as a catalyst of the selected dehydration. The generic reaction remains reversible. PMID:3782039 and PMID:10215859 were read at abstract scope, without a new full-methods reconciliation of the opposing native directions.",
    "N270-S05": "The three direct pathway associations are NCBITaxon:2208 Methanosarcina barkeri (species), NCBITaxon:145262 Methanothermobacter thermautotrophicus (species), and NCBITaxon:2179 Methanothermus (genus). Exact native pointers and the pinned NCBI Taxonomy 2026-07-12 label/rank statements support these identities. A species-slot placement does not turn Methanothermus into a species. These are source pathway associations, not demonstrations of all six reactions or all strains. Historical Euryarchaeota TAX-28890 is a separate source range; the pinned issuer labels that identifier Methanobacteriota. Catalyst and nested taxon contexts do not enlarge the three direct associations.",
    "N270-S06": "Methanofuran, F420 and ferredoxin remain generic native classes. Specific methanofuran molecules, two-glutamate F420 examples, gamma-linked polymer polyanions and [2Fe-2S] reactive parts cannot substitute for those classes. No fixed ferredoxin sequence or universal electron capacity is assigned. Hmd, Mch and Mtr formally balance at the compared native representation; Fmd, Ftr and Mer remain undetermined because their generic terms lack complete molecular specifications.",
    "N270-S07": "Eight native SMILES contain [R], including four nonclass compounds with concrete formula/InChI; native H2 also has a literal [H] SMILES. Independent issuing review reproduced twelve concrete CML constitutions/formulas/charges and eleven direct ChEBI InChI-derived matches at the compared isotope-unspecified resolution, without establishing CML drawing stereochemistry. FORMYL-THMPT is not an exact substitute for either neutral CHEBI:17114 or stereo-underdetermined CHEBI:58018. Hydron remains isotope-unspecified. Seven concrete KEGG ionic forms differ; native graph IDs are retained. Matching selected equations or structures does not establish a whole-pathway alias.",
    "N270-S08": "Molybdenum and tungsten Fmd cofactors and cyanide responses remain catalyst-specific. The Mo inhibition is not transferred to the W isoenzyme or every Fmd reaction. Old single-MGD wording is not silently reconciled with native bis-pterin compounds. PMID:2253782 and PMID:8125106 supply abstract-level context; source cofactor and regulation assertions without fully read experimental originals remain source assertions.",
    "N270-S09": "Historical Hmd statements about absent Ni, FeS and flavins do not establish absence of an iron cofactor. PMID:20221540 concerns an M. jannaschii iron-site study at the abstract scope read here; it does not identify the exact historical native catalyst or authorize a FeGP cofactor edge. Native Hmd tetramer and component assertions retain their historical source scope. Its Marburg molecular-weight prose is distinct from the Delta H O27211 pointer and its initiation caution.",
    "N270-S10": "Mtr has an unresolved native cofactor conflict: ENZRXN-702 lists FeS and cobamide, while CPLX-643 prose names only a cobamide prosthetic group. Both statements remain on the affected cofactor edges with their separate native evidence. The 1993 abstract (PMID:8477726) and 1995 abstract (PMID:7737157) describe different preparations and seven versus eight polypeptides; their quantities are not merged into a single measured stoichiometry. Native fourfold-octamer composition and unspecified component coefficients remain source-scoped; component membership does not establish independent subunit catalysis.",
    "N270-S11": "Historical Marburg prose, species-level objects and Delta H accession pointers are not treated as one strain or protein. The exact ENA X86477/CDS CAA60203.1 translation is 321 amino acids and matches Q50744 Marburg, differing from O27784 Delta H at residues 191, 196, 197, 213 and 247. The historical ENA taxon pointer and the distinct Q50744 position15 and O27784 position313 sequence cautions remain visible. Marburg taxon79929 has species parent145263, whereas Delta H187420 has parent145262. Native protein identities and historical assay contexts are retained without accession substitution or transfer of Marburg kinetics. PMID:7649177 and PMID:8522533 were read as distinct Marburg and Delta H abstracts.",
    "N270-S12": "Five Archaeoglobus fulgidus DSM4304 activities are native associations without their own evidence tags or declared directions. Shared C1 functions, homology and annotation do not establish methanogenesis or the complete six-member route. AF_RS10430/O28206 is formyltransferase-like with family/similarity support, distinct from AF_RS11105/O28076. Nine AF locus/RefSeq aliases have issuing support, but eight divergent GeneID pointers remain unresolved. O28076 also carries sequence cautions at positions32,34,43. Issuing annotations do not establish whole native sequence identity or independently read catalytic experiments.",
    "N270-S13": "Methylorubrum extorquens AM1 Mch belongs to bacterial C1 metabolism. Its native association and O85014 annotation do not establish methane formation. PMID:10215859 provides abstract-level purified-enzyme and suggested catabolic-context evidence; full assay conditions were not newly verified. Its exact opposing physiological activity and sodium regulation retain their own native targets rather than being generalized to the route.",
    "N270-S14": "Kurth2021 (PMID:34145392; DOI:10.1038/s41396-021-01025-6) experimentally studies methoxy-compound demethylation by Mto and expression context in Methermicoccus shengliensis. Native MtoA/MtoB purification and heterologous MtoC/MtoD have distinct roles. The full main, all five figures, complete supplementary DOCX body/seven figures, selected S1/S2 rows and all S3 were accepted at their recorded reading scopes. This is not an isolated eight-subunit Mtr sodium-pumping experiment. Native ENZRXN2065-393 EV-EXP-IPI remains a database evidence tag, not independently demonstrated exact Mtr catalysis.",
    "N270-S15": "The Kurth MtoA acceptor assay uses tetrahydrofolate as a surrogate and CoM as a negative acceptor; physiological H4MPT acceptance is the interpretation, not a measured H4MPT rate. MtoA BP07_RS03240 and MtrH BP07_RS06315 are different gene products. The corrected experimental locator is Methods PDF pages6–7 (printed3554–3555), Figure4C/caption and Results PDF pages11–12 (printed3559–3560), with supplementary FigureS2B. Figure3 is not this assay locator, and no MtoA activity is transferred to native MtrH.",
    "N270-S16": "Kurth Figure5, the supplementary energy calculations and oscillating-flux scenarios are hypotheses. Resting-cell product ratios and qualitative 13C experiments do not measure full-route flux, establish universal 1:3 disproportionation or validate every energetic assumption. Mtr expression rows in TableS1 and S2 remain expression context; neither those rows nor O27227 rule-derived cofactor/transport annotations demonstrate a purified sodium pump.",
    "N270-S17": "The Vorholt1997 abstract (PMID:9342247) addresses CO2 rather than bicarbonate as Fmd substrate and evidence consistent with a proposed N-carboxymethanofuran intermediate. Its full main, figures and assays remain unacquired here. A native pathway-level experimental tag citing this study is not an experiment on the entire six-member route, and the proposed intermediate is not added as an observed elementary step.",
    "N270-S18": "Kaster2011 (PMID:21262829) concerns MvhADG/HdrABC electron bifurcation in M. marburgensis, outside the six native members. Evidence here is the complete abstract plus the exactly recorded inherited partial-main scope; no newly acquired authentic full main/SI is claimed. Its assay ferredoxin is not substituted for the native generic class, and no universal membrane methanophenazine mechanism or six-member ATP yield is inferred.",
    "N270-S19": "A formal one-pass net is a diagnostic rather than a physiological methane balance. Location-aware summation retains Na+ transport and located/unlocated carrier residuals. Rhea142 Mer has an additional H+ and narrower F420 scope, KEGG Ftr omits a native H+ and Fmd has an additional H+, and Rhea Mtr leaves four carrier locations unspecified where the native equation specifies inside. These are not silently normalized away. Bare graph endpoints do not encode typed occurrence coefficients or compartments; the exact source facts remain in the edge descriptions/evidence and retained occurrence ledger.",
    "N270-S20": "Seven native regulations retain exact activity targets: HCN inhibits ENZRXN-422 and ENZRXN-641; Na+ activates ENZRXN-4121; 10-formyl-THMPT inhibits, Mg2+ activates and Mn2+ inhibits ENZRXN-662; oxygen inhibits ENZRXN-702. The separately acquired Regulation class is not an eighth instance. PMID:3782039 supports selected Mg/formyl effects and PMID:8125106 the Mo-specific cyanide effect at abstract scope. Other details remain source-only. Regulation is not flattened onto generic reactions, every isoenzyme or whole taxa.",
}

# New primary/identity context needed on incident edges, because root descriptions
# are not part of the current KGX export. Every original native assertion remains.
incident_additions = {
    "N270-S01": "The six-member definition ends at methyl-CoM; METHFORM, methane production and carrier-regeneration systems are outside its membership.",
    "N270-S02": "PMID:7737157 is abstract-level context; Kurth2021 Figure5 is an energetic model, not a fresh measurement of this sodium stoichiometry.",
    "N270-S03": "PMID:1521540 is abstract-level Hmd context; Kurth2021 Figures2/5 and selected TableS1 rows discuss a separate Mtd route.",
    "N270-S04": "PMID:3782039 and PMID:10215859 were read at abstract scope; no full-methods reconciliation of the source direction conflict is asserted.",
    "N270-S05": paragraphs["N270-S05"],
    "N270-S06": "No specific methanofuran, F420 polymer length or ferredoxin sequence replaces a native class. Formal native Hmd/Mch/Mtr balancing does not close generic Fmd/Ftr/Mer chemistry.",
    "N270-S07": "Accepted issuer comparison preserves native IDs: FORMYL-THMPT is not exactly CHEBI:17114 or58018; native isotope-unspecified hydron and generic carriers remain distinct. CML constitution/formula/charge agreement does not establish drawing stereochemistry or every ionic representation.",
    "N270-S08": "PMID:2253782 and PMID:8125106 are abstract-level context only; Mo inhibition and historical MGD wording do not establish W inhibition or reconciled cofactor stoichiometry.",
    "N270-S09": "PMID:1521540 and PMID:20221540 were read at abstract scope. The latter concerns a different-organism iron-site study, not an exact native FeGP mapping. Marburg molecular-weight prose and Delta H O27211 initiation cautions remain distinct.",
    "N270-S10": "PMID:8477726 (1993) and PMID:7737157 (1995) were read as abstracts from different preparations; seven/eight-polypeptide and iron/sulfur quantities are not merged into a single measured assembly.",
    "N270-S11": paragraphs["N270-S11"],
    "N270-S12": paragraphs["N270-S12"],
    "N270-S13": "PMID:10215859 supports narrower bacterial C1 context at abstract scope. It does not establish methanogenesis or newly verified full assay conditions.",
    "N270-S14": "PMID:34145392 full-main/SI evidence concerns Mto demethylation and expression context; the native EV-EXP-IPI tag does not establish isolated Mtr catalysis or sodium pumping. S1 rows25–32 and S2 rows57–64 cover Mtr expression, not purified transport.",
    "N270-S15": paragraphs["N270-S15"],
    "N270-S16": "PMID:34145392 Discussion/Figure5, supplementary FiguresS4/S7 and TableS3 retain hypothetical energy/oscillation models. Qualitative13C and resting-cell ratios are not whole-route flux or universal1:3 proof.",
    "N270-S17": paragraphs["N270-S17"],
    "N270-S18": "PMID:21262829 is complete-abstract plus inherited partial-main context for MvhADG/HdrABC outside this membership, without a new full main/SI or universal membrane mechanism/ATP-yield claim.",
    "N270-S19": "Compartment-specific net residuals do not prove physiological methane flux. Rhea Mer proton/F420, KEGG Ftr/Fmd proton and Rhea Mtr carrier-location differences remain distinct from native occurrences.",
    "N270-S20": "PMID:3782039 and PMID:8125106 provide selected abstract-level corroboration only; all other regulation details remain exact native activity assertions rather than independently read assays.",
}


def main():
    inputs = read_json("input-bindings.json")
    for row in inputs:
        path = INPUTS / row["copy"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"], path
    original = yaml.safe_load((INPUTS / "native-biochemical-probe.yaml").read_text())
    candidate = deepcopy(original)
    claims = read_json("all20-claim-design-dispositions.json")
    assert set(paragraphs) == set(incident_additions) == {c["id"] for c in claims}
    candidate["description"] = "\n\n".join(paragraphs[c["id"]] for c in claims)
    taxa = read_json("taxon-dispositions.json")["native_objects"]
    statements = read_json("taxonomy-complete-selected-statements.json")
    direct = [next(t for t in taxa if t["native_id"] == "TAX-" + n) for n in ["2208", "145262", "2179"]]
    candidate["taxa"] = [{"id": t["issuer_id"], "label": t["issuer_label"]} for t in direct]
    query = read_json("taxonomy-query-receipt.json")
    for t in direct:
        rows = statements[t["issuer_id"]]
        assert any(r["predicate"] == "rdfs:label" and r["value"] == t["issuer_label"] for r in rows)
        assert any(r["predicate"] == "obo:ncbitaxon#has_rank" and r["object"] == t["issuer_rank"] for r in rows)
        candidate["references"].append({"id": t["issuer_id"], "title": t["issuer_label"] + " — NCBI Taxonomy", "url": "https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id=" + t["issuer_id"].split(":")[1], "source_version": "NCBI Taxonomy 2026-07-12; accepted pinned full-cache hash reused, selected statements freshly verified", "source_sha256": query["prior_full_hash_evidence"]["sha256"]})
    abstracts = read_json("selected-pubmed-abstracts.json")
    for abstract in abstracts:
        is_full = abstract["pmid"] == "34145392"
        candidate["references"].append({"id": "PMID:" + abstract["pmid"], "title": abstract["title"], "url": "https://www.nature.com/articles/s41396-021-01025-6.pdf" if is_full else "https://pubmed.ncbi.nlm.nih.gov/" + abstract["pmid"] + "/", "source_version": "2021 full main; associated SI reading scopes retained separately" if is_full else abstract["year"] + " complete PubMed abstract only; full experimental original not newly accepted", "source_sha256": "f15d78d1ccca763d30f0ba74eb5f1867688623a4e6833c05373ff056811d008b" if is_full else "a7594bb3cea7d15bf6afaa53a756016b6e592daaa297410a7faff97871c1c260"})
    root = ET.fromstring((INPUTS / "META-METHANOGENESIS-PWY.xml").read_bytes())
    pathway = next(x for x in root if x.attrib.get("frameid") == "METHANOGENESIS-PWY")
    associations = []
    for i, slot in enumerate(pathway, 1):
        if slot.tag == "species":
            native = slot[0].attrib["frameid"]
            t = next(t for t in direct if t["native_id"] == native)
            associations.append({"reference_id": original["id"], "source_assertion": "METHANOGENESIS-PWY directly lists " + native + " in species; issuing name/rank is " + t["issuer_label"] + " (" + t["issuer_rank"].split(":")[1] + "). This is a pathway association, not all-member experimental proof.", "source_locator": f"/ptools-xml/Pathway[@frameid='METHANOGENESIS-PWY']/*[{i}][self::species]/Organism[@frameid='{native}']"})
    assert len(associations) == 3
    edges = {e["id"]: e for e in candidate["mechanistic_edges"]}
    for edge in edges.values():
        edge["description"] = edge["description"].replace("Current issuer reconciliation is pending.", "Issuing names/ranks are accepted at the pinned 2026-07-12 taxonomy scope; the associations remain source-only.")
        edge["description"] = edge["description"].replace("Provisional frozen issuer analysis reports", "Accepted issuing-original comparison shows")
        edge["description"] = edge["description"].replace("Independent issuer acceptance is pending; neither accession is substituted.", "Neither accession is substituted, and strain/sequence/assay distinctions remain explicit.")
        edge["description"] = edge["description"].replace("The frozen issuer preparation reports", "Accepted issuing-original comparison identifies")
        edge["description"] = edge["description"].replace("; independent issuer acceptance is pending.", "; this remains family/similarity annotation rather than independent catalytic proof.")
    placements = []
    for claim in claims:
        for eid in claim["design_edge_ids"]:
            edges[eid]["description"] += " " + incident_additions[claim["id"]]
        placements.append({"claim_id": claim["id"], "root_paragraph": paragraphs[claim["id"]], "incident_addition": incident_additions[claim["id"]], "edge_ids": claim["design_edge_ids"], "accepted_primary_scope": claim["primary_scope"], "policy": "Primary qualifications are explicitly cited interpretation in descriptions; positive mechanistic evidence remains the exact native source assertion."})
    for edge in candidate["mechanistic_edges"][:6]:
        assert edge["subject"] == candidate["id"] and edge["predicate"] == "has_part"
        edge["evidence"].extend(deepcopy(associations))
        for t in direct:
            edge["evidence"].append({"reference_id": t["issuer_id"], "source_assertion": t["issuer_id"] + " has label " + t["issuer_label"] + " and rank " + t["issuer_rank"].split(":")[1] + " in pinned NCBI Taxonomy 2026-07-12. Identity/rank support does not establish all-member experiments.", "source_locator": "SQLite statements: subject='" + t["issuer_id"] + "', predicate in ('rdfs:label','obo:ncbitaxon#has_rank'); complete selected rows retained in taxonomy-complete-selected-statements.json"})
    assert candidate["participants"] == original["participants"] and candidate["reactions"] == original["reactions"]
    for before, after in zip(original["mechanistic_edges"], candidate["mechanistic_edges"], strict=True):
        assert all(before[k] == after[k] for k in ["id", "subject", "predicate", "object"])
        assert after["evidence"][:len(before["evidence"])] == before["evidence"]
    assert len(candidate["mechanistic_edges"]) == 125
    assert len(candidate["references"]) == 148
    assert len({r["id"] for r in candidate["references"]}) == 148
    for edge in candidate["mechanistic_edges"]:
        assert not re.search(r"issuer (?:reconciliation|acceptance) is pending", edge["description"], re.I)
        for evidence in edge["evidence"]:
            assert len(evidence.get("source_assertion", evidence.get("quote", ""))) <= 400
    class Dumper(yaml.SafeDumper):
        pass
    def represent_str(dumper, value):
        return dumper.represent_scalar("tag:yaml.org,2002:str", value, style="|" if "\n" in value else None)
    Dumper.add_representer(str, represent_str)
    (ROOT / "methanogenesis-from-h2-and-co2.yaml").write_text(yaml.dump(candidate, Dumper=Dumper, sort_keys=False, allow_unicode=True, width=100))
    (ROOT / "claim-placement-ledger.json").write_text(json.dumps(placements, indent=2, ensure_ascii=False) + "\n")
    (ROOT / "composition-result.json").write_text(json.dumps({"status": "scratch_candidate_not_integrated_or_accepted", "native_nodes": 101, "taxa": candidate["taxa"], "edges": 125, "references": 148, "claims_placed": 20, "native_nodes_edges_and_original_evidence_preserved": True, "new_evidence": "Three native direct associations and three pinned taxon identity/rank assertions on each of six membership edges.", "pending": ["actual merged-baseline novelty acceptance", "authority implementation and independent acceptance", "independent complete-record review", "maintained history, full corpus gates, page/export QA and canonical review"]}, indent=2) + "\n")
    print(json.dumps({"candidate": str(ROOT / "methanogenesis-from-h2-and-co2.yaml"), "taxa": 3, "edges": 125, "references": 148, "claims": 20}))


if __name__ == "__main__":
    main()
