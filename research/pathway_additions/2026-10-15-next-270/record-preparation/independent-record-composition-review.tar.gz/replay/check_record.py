"""Check the scratch candidate with copied landed consumers; no corpus claim."""
from pathlib import Path
import csv
import hashlib
import html
from html.parser import HTMLParser
import io
import json
import sys

import yaml
from jsonschema import Draft7Validator

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "inputs/contracts/src"))
from pathwaymech.cli import render_site
from pathwaymech.schema import validate_record
from pathwaymech.strict import json_schema


def main():
    bindings = json.loads((ROOT / "inputs/contract-bindings.json").read_text())
    for row in bindings["files"]:
        data = (ROOT / "inputs/contracts" / row["path"]).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
    raw = yaml.safe_load((ROOT / "methanogenesis-from-h2-and-co2.yaml").read_text())
    record = validate_record(raw)
    errors = list(Draft7Validator(json.loads(json_schema())).iter_errors(raw))
    assert not errors, [str(e) for e in errors]
    files = render_site([record])
    out = ROOT / "preview"
    for name, body in files.items():
        path = out / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body)
    rows = list(csv.DictReader(io.StringIO(files["downloads/edges.tsv"]), delimiter="\t"))
    nodes = list(csv.DictReader(io.StringIO(files["downloads/nodes.tsv"]), delimiter="\t"))
    assert len(rows) == 125 and len(nodes) == 104
    for edge, row in zip(raw["mechanistic_edges"], rows, strict=True):
        assert row["subject"] == edge["subject"] and row["object"] == edge["object"]
        assert row["description"] == edge["description"]
        assert json.loads(row["evidence"]) == edge["evidence"]
    page = files["records/MetaCyc_METHANOGENESIS-PWY.html"]
    class Tags(HTMLParser):
        def __init__(self):
            super().__init__()
            self.tags = []
            self.text = []
        def handle_starttag(self, tag, attrs):
            self.tags.append((tag, dict(attrs)))
        def handle_data(self, data):
            self.text.append(data)
    parser = Tags()
    parser.feed(page)
    targets = {a["id"] for _, a in parser.tags if "id" in a}
    assert all(a["href"][1:] in targets for _, a in parser.tags if a.get("href", "").startswith("#"))
    graph_nodes = [a for _, a in parser.tags if "graph-node" in a.get("class", "").split() and "data-node-id" in a]
    graph_edges = [a for _, a in parser.tags if "graph-edge" in a.get("class", "").split() and "data-subject" in a]
    # The current SVG omits unconnected taxa; KGX and the page's taxon list
    # retain all three direct declarations without inventing biological edges.
    assert len(graph_nodes) == 101 and len(graph_edges) == 125
    plain = " ".join(parser.text)
    for taxon in raw["taxa"]:
        assert taxon["id"] in plain and taxon["label"] in plain
    for edge in raw["mechanistic_edges"]:
        assert edge["description"] in plain, edge["id"]
        for evidence in edge["evidence"]:
            assert evidence.get("source_assertion", evidence.get("quote", "")) in plain
    placements = json.loads((ROOT / "claim-placement-ledger.json").read_text())
    edge_by_id = {e["id"]: e for e in raw["mechanistic_edges"]}
    for claim in placements:
        assert claim["root_paragraph"] in raw["description"]
        for eid in claim["edge_ids"]:
            assert claim["incident_addition"] in edge_by_id[eid]["description"]
    refs = {r["id"]: r for r in raw["references"]}
    assert len(refs) == 148
    assert refs["PMID:34145392"]["source_sha256"] == "f15d78d1ccca763d30f0ba74eb5f1867688623a4e6833c05373ff056811d008b"
    for ref in refs.values():
        assert ref["url"].startswith("https://")
        assert len(ref["source_sha256"]) == 64
    receipt = {
        "status": "passed_scratch_schema_export_and_static_page_checks",
        "landed_contract_commit": bindings["commit"],
        "landed_contract_tree": bindings["tree"],
        "python_schema": True,
        "closed_null_free_schema": True,
        "kgx_nodes": len(nodes),
        "kgx_edges": len(rows),
        "svg_nodes": len(graph_nodes),
        "svg_edges": len(graph_edges),
        "taxon_rendering": "Three unconnected direct taxa remain in KGX, the page taxon list and membership evidence; current SVG includes biochemical graph nodes only.",
        "all_descriptions_and_evidence_export_exact": True,
        "all_edge_scopes_visible_without_javascript": True,
        "local_page_links_resolve": True,
        "corrected_claims_placed": len(placements),
        "candidate_sha256": hashlib.sha256((ROOT / "methanogenesis-from-h2-and-co2.yaml").read_bytes()).hexdigest(),
        "page_sha256": hashlib.sha256(page.encode()).hexdigest(),
        "scope_limits": ["No authority consumer or maintained corpus gate in this check.", "No pixel-level or interactive-browser QA.", "Accepted source/issuer/graph reviews are reused at their stated scope, not independently reread here.", "Full reference-original retention is in the separately frozen source/issuer owners, not these selected copied inputs."]
    }
    (ROOT / "record-checks.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
