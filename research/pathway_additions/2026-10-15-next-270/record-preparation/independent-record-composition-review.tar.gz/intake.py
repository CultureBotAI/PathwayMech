from pathlib import Path
import hashlib,json,shutil
O=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-270-record-preparation')
def sha(b):return hashlib.sha256(b).hexdigest()
m=(A/'artifact-manifest.json').read_bytes();assert sha(m)=='92357ea4f18409725bc8864f1ccd09648b1b6cd1cdfca1eeb15e371d7f90d64c';j=json.loads(m)
physical={str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()};listed={x['path'] for x in j['files']};assert physical==listed|{'artifact-manifest.json','freeze-proof.json'}
for x in j['files']:
 b=(A/x['path']).read_bytes();assert sha(b)==x['sha256'] and len(b)==x['bytes']
assert len(physical)==110 and len(listed)==108
assert sha((A/'methanogenesis-from-h2-and-co2.yaml').read_bytes())=='553922ede0ecdb12ebe569dbb9d8af1c70d4aa190e4fd60e69a9bc7ea0cf8e1e'
shutil.copytree(A,O/'replay')
(O/'intake.json').write_text(json.dumps({'owner':str(A),'manifest_sha256':sha(m),'listed':108,'physical':110,'all_hashes_exact':True,'review_input_copy':'replay','write_scope':'Reproduction writes only new owned replay directory; original author packet immutable.'},indent=2)+'\n')
print('All110 physical files exact; isolated copy ready')
