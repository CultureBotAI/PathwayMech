from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E,yaml,subprocess,io,csv,sys,html,collections
O=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-270-record-preparation');S=Path('/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation');I=Path('/private/tmp/pathwaymech-next-270-methanogenesis-issuer-preparation');G=Path('/private/tmp/pathwaymech-next-270-native-graph-independent-review')
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(n,b):
 assert b,n
 checks.append(n)
def J(p):return json.loads(p.read_text())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
d=yaml.load((A/'methanogenesis-from-h2-and-co2.yaml').read_bytes(),Loader=yaml.CSafeLoader);n=yaml.load((A/'inputs/native-biochemical-probe.yaml').read_bytes(),Loader=yaml.CSafeLoader)
ck('candidate identity',sha((A/'methanogenesis-from-h2-and-co2.yaml').read_bytes())=='553922ede0ecdb12ebe569dbb9d8af1c70d4aa190e4fd60e69a9bc7ea0cf8e1e')
ck('participants exact independently accepted native design',d['participants']==n['participants']);ck('six reactions exact independently accepted native design',d['reactions']==n['reactions'] and len(d['reactions'])==6)
ck('101 native nodes',len(d['participants'])+len(d['reactions'])+1==101)
ck('graph peer acceptance',sha((G/'artifact-manifest.json').read_bytes())=='d945acd1f4e48e462e4db2bc3ed4f3db197bc421d8ed99ef3a40946fc613c19e')
# Preserve peer reports and bind their unchanged source graph scope.
for f in ['HANDOFF.md','REVIEW.md','RESULT.json','READING-SCOPES.json','artifact-manifest.json','freeze-proof.json']:
 p=O/'peer-graph';p.mkdir(exist_ok=True);(p/f).write_bytes((G/f).read_bytes())
new=[];edgechange=[]
for a,b in zip(n['mechanistic_edges'],d['mechanistic_edges'],strict=True):
 ck('edge identity '+a['id'],{k:a[k] for k in ('id','subject','predicate','object')}=={k:b[k] for k in ('id','subject','predicate','object')})
 ck('native evidence prefix '+a['id'],b['evidence'][:len(a['evidence'])]==a['evidence'])
 more=b['evidence'][len(a['evidence']):];new.extend([{'edge':b['id'],**x} for x in more]);edgechange.append({'id':a['id'],'before_description_sha256':sha(a.get('description','').encode()),'after_description_sha256':sha(b.get('description','').encode()),'new_evidence_count':len(more),'native_evidence_count':len(a['evidence'])})
ck('125 edges',len(edgechange)==125);ck('36 added taxon assertions across only memberships',len(new)==36 and set(x['edge'] for x in new)=={e['id'] for e in d['mechanistic_edges'][:6]})
ck('131 native references unchanged',d['references'][:len(n['references'])]==n['references'] and len(n['references'])==131)
ck('148 exact distinct refs',len(d['references'])==148==len({x['id'] for x in d['references']}))
# Every native reference binds to a body in the accepted source owner manifest.
sm=J(S/'artifact-manifest.json');source_by_hash=collections.defaultdict(list)
for r in sm['files']:source_by_hash[r['sha256']].append(r)
refs=[]
for r in d['references'][:131]:
 candidates=[x for x in source_by_hash[r['source_sha256']] if x['path'].endswith('.xml')]
 ck('retained native reference body '+r['id'],bool(candidates))
 item=candidates[0];p=S/item['path'];b=p.read_bytes();ck('native reference body SHA '+r['id'],sha(b)==r['source_sha256'])
 root=E.fromstring(b);own=next(x for x in root if x.tag!='metadata');ck('reference native own frame '+r['id'],own.get('frameid')==r['id'].split(':',1)[1] and own.get('orgid')=='META')
 refs.append({'id':r['id'],'sha256':sha(b),'body_path':str(p),'native_tag':own.tag,'url':r['url'],'scope':'Exact unchanged native reference; accepted graph reviewer checked successful acquisition URL/reuse bindings. No new network acquisition.'})
# Read the primary bodies, not copied title summaries, for all fourteen PMID identities.
xml=S/'originals/primary/selected-pubmed.xml';xb=xml.read_bytes();ck('complete PubMed batch original',sha(xb)=='a7594bb3cea7d15bf6afaa53a756016b6e592daaa297410a7faff97871c1c260');arts={x.findtext('MedlineCitation/PMID'):x for x in E.fromstring(xb).findall('PubmedArticle')}
for r in d['references'][134:]:
 pmid=r['id'].split(':')[1];art=arts[pmid];title=''.join(art.find('MedlineCitation/Article/ArticleTitle').itertext());ck('PMID title original '+pmid,title==r['title']);ck('PMID nonempty abstract '+pmid,bool(art.findall('MedlineCitation/Article/Abstract/AbstractText')))
 if pmid=='34145392':
  p=S/'originals/primary/kurth2021.pdf';b=p.read_bytes();ck('Kurth full original body',b.startswith(b'%PDF-') and sha(b)==r['source_sha256']=='f15d78d1ccca763d30f0ba74eb5f1867688623a4e6833c05373ff056811d008b');scope='Authentic full main hash; accepted main/SI reading scopes reused, with targeted Mto/locator checks in this review.'
 else:
  ck('abstract batch hash '+pmid,r['source_sha256']==sha(xb));ck('abstract-only reference scope '+pmid,'abstract only' in r['source_version']);p=xml;scope='Complete PubMed abstract original checked; no full paper acquisition or reading claimed.'
 refs.append({'id':r['id'],'body_path':str(p),'sha256':r['source_sha256'],'title_matches_original':True,'scope':scope})
# Three taxon identities and all36 new evidence assertions independently located.
root=E.fromstring((A/'inputs/META-METHANOGENESIS-PWY.xml').read_bytes());pw=next(x for x in root if x.get('frameid')=='METHANOGENESIS-PWY');species={s[0].get('frameid'):(i,s[0]) for i,s in enumerate(pw,1) if s.tag=='species'}
st=J(A/'inputs/taxonomy-complete-selected-statements.json');q=J(A/'inputs/taxonomy-query-receipt.json');tax=[]
for r,t in zip(d['references'][131:134],d['taxa'],strict=True):
 ident=t['id'];frame='TAX-'+ident.split(':')[1];index,e=species[frame];rank=e.findtext('rank');label=e.findtext('common-name')
 ck('taxon direct pointer '+ident,e.findtext('dblink/dblink-oid')==ident.split(':')[1]);ck('taxon label '+ident,t['label']==label and any(x['predicate']=='rdfs:label' and x['value']==label for x in st[ident]));ck('taxon rank '+ident,any(x['predicate']=='obo:ncbitaxon#has_rank' and x['object']=='NCBITaxon:'+rank for x in st[ident]));ck('taxon hash is full accepted pin '+ident,r['source_sha256']==q['prior_full_hash_evidence']['sha256']=='89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d')
 for edge in d['mechanistic_edges'][:6]:
  es=edge['evidence'][-6:];native=next(z for z in es if z['reference_id']==d['id'] and frame in z['source_locator']);issuer=next(z for z in es if z['reference_id']==ident)
  ck('exact new species own-slot '+edge['id']+ident,native['source_locator']==f"/ptools-xml/Pathway[@frameid='METHANOGENESIS-PWY']/*[{index}][self::species]/Organism[@frameid='{frame}']")
  ck('new taxonomy qualifier '+edge['id']+ident,'not all-member experimental proof' in native['source_assertion'] and 'does not establish all-member experiments' in issuer['source_assertion'])
 tax.append({'id':ident,'label':label,'rank':rank,'native_own_slot':index,'native_sha256':sha((A/'inputs/META-METHANOGENESIS-PWY.xml').read_bytes()),'pinned_cache_sha256_reused':r['source_sha256']})
 refs.append({'id':ident,'body_path':q.get('cache_path',str(I/'results/taxonomy-query-receipt.json')),'sha256':r['source_sha256'],'scope':'Accepted full14.1GB cache hash reused; exact selected issuer statements and prior independent acceptance rebound. No fresh whole-cache hash claimed.'})
ck('three direct taxa exact ranks',[(x['id'],x['rank']) for x in tax]==[('NCBITaxon:2208','species'),('NCBITaxon:145262','species'),('NCBITaxon:2179','genus')])
# Every accepted source claim and its exact primary scope placed without creating positive primary graph evidence.
cl=J(A/'claim-placement-ledger.json');design={x['id']:x for x in J(A/'inputs/all20-claim-design-dispositions.json')};eb={x['id']:x for x in d['mechanistic_edges']};placement=[]
for x in cl:
 c=design[x['claim_id']];ck('exact accepted primary scope '+c['id'],x['accepted_primary_scope']==c['primary_scope']);ck('claim root placement '+c['id'],x['root_paragraph'] in d['description']);ck('claim all planned incident edges '+c['id'],x['edge_ids']==c['design_edge_ids'])
 for eid in x['edge_ids']:ck('claim incident '+c['id']+eid,x['incident_addition'] in eb[eid]['description'])
 placement.append({'claim_id':c['id'],'edge_count':len(x['edge_ids']),'primary_scope':x['accepted_primary_scope'],'status':'Root and all specified incident additions exact; semantic qualifications reviewed separately.'})
ck('all20 claims',len(placement)==20);s15=next(x for x in cl if x['claim_id']=='N270-S15');ck('corrected626 locator',all(s in s15['root_paragraph'] for s in ['pages6–7','Figure4C','pages11–12','FigureS2B','CoM as a negative acceptor','BP07_RS03240','BP07_RS06315']))
ck('no new primary positive evidence',all(x['reference_id'].startswith(('MetaCyc:','NCBITaxon:')) for x in new))
# Independent export inspection including root-only qualifications on incident rows.
P=O/'replay/preview';rows=list(csv.DictReader((P/'downloads/edges.tsv').open(),delimiter='\t'));nodes=list(csv.DictReader((P/'downloads/nodes.tsv').open(),delimiter='\t'));ck('KGX104nodes125edges',len(rows)==125 and len(nodes)==104)
for b,r in zip(d['mechanistic_edges'],rows,strict=True):ck('lossless context export '+b['id'],r['description']==b['description'] and json.loads(r['evidence'])==b['evidence'])
for t in d['taxa']:ck('taxon KGX '+t['id'],any(r['id']==t['id'] for r in nodes))
# Reproduction compares exact generated bytes, separately from historical attempts/logs.
outputs=['methanogenesis-from-h2-and-co2.yaml','claim-placement-ledger.json','composition-result.json','record-checks.json']+[str(p.relative_to(A)) for p in sorted((A/'preview').rglob('*')) if p.is_file()]
for p in outputs:ck('independent replay exact '+p,(O/'replay'/p).read_bytes()==(A/p).read_bytes())
ck('13 generated outputs',len(outputs)==13)
for p in ['build.stderr','check.stderr']:ck('terminal empty stderr '+p,(O/p).read_bytes()==b'')
save('reference-bindings.json',refs);save('taxon-evidence-review.json',tax);save('claim-placement-review.json',placement);save('graph-delta-review.json',edgechange);save('checks.json',checks);save('result.json',{'checks_passed':len(checks),'references':len(refs),'native_nodes':101,'taxa':3,'edges':125,'claims':20,'generated_outputs_reproduced':13,'native_graph_evidence_unchanged':True,'new_evidence_count':len(new),'scope':'Independent composition/reference/placement/export verification; earlier peer scientific and native graph reviews reused at their exact scopes.'});print((O/'result.json').read_text())
