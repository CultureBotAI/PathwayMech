# Frozen independent next270 source-closure review

Qualified scientific/source-preparation acceptance with **one minor required locator correction N270-R01**; no other actionable defect established. Exact input: `/private/tmp/pathwaymech-next-270-methanogenesis-source-preparation`, manifest `2bd6c0bf3c957babb332519a8216a56840ae017914e09bc87ba1265673085c56`, 519 listed / 521 physical files, unchanged.

Read `REVIEW.md` and `findings.json`. N270-S15 must cite the MtoA acceptor assay Methods at PDF6–7 (printed3554–3555), Fig4C/caption and Results PDF11–12 (printed3559–3560), and SI FigS2B. Current pp4–5/Fig3 locator is inaccurate; the qualified H4F-surrogate/CoM-negative claim is supported. Correct in a separate successor, retaining all20 claim bodies and immutable source packet.

5,898 independent assertions pass, plus manifest integrity. Native177 full objects, six member reactions/30 materials/15 activities/43 components/seven real regulations and all334 selected forward occurrences reproduced. Sodium compartment terms, Mch direction conflicts, generic chemistry, exact regulation targets and taxon roles retained.

Complete Kurth main text/allfive figures, complete DOCX body/allseven figures, exact23/15 selectedS1/S2 rows and all40S3 rows independently reviewed and original-bound; all14 abstracts checked. Full historical originals remain unavailable/qualified. No whole-route flux, chemistry equivalence, current taxonomy, sequence mapping or maintained acceptance follows. Qualified structured-source assertions remain usable without endless historical full-text hunting.

All review jobs terminal. Two reviewer harness failures and PDFKit warning preserved; final complete replays passed. No maintained/Git/GitHub/network/runtime writes. Later issuer, record, merged-baseline and publication acceptance remain separate.
