"""Rehash only the scoped owners and frozen evidence; no whole-tree lock."""
import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
W=Path('/private/tmp/pathwaymech-next-270-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
rows=read(R/'results/owner-before.json')
assert len(rows)==len({r['path'] for r in rows})
for row in rows:
 p=W/row['path'];assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
evidence=read(R/'results/integration-check.json')['frozen_inputs']
for item in evidence:
 owner=Path(item['owner']);assert sha(owner/'artifact-manifest.json')==item['manifest']
 manifest=read(owner/'artifact-manifest.json')['files']
 physical={str(p.relative_to(owner)) for p in owner.rglob('*') if p.is_file()}
 assert len(physical)==item['physical'] and physical=={r['path'] for r in manifest}|{'artifact-manifest.json','freeze-proof.json'}
 for row in manifest:
  p=owner/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],str(p)
receipt=Path('/private/tmp/pathwaymech-next-270-ci/initial-authority-retention-integration.json')
assert receipt.read_bytes()==(R/'inputs/integration-receipt.json').read_bytes()
result={'all_exact':True,'scoped_current_owner_count':len(rows),'frozen_evidence_owners':len(evidence),'frozen_evidence_physical_files':sum(r['physical'] for r in evidence),'integration_receipt_sha256':sha(receipt),'scope':'Only fixed approved owners and prior committed records/pages; later histories, new record and retention groups are not locked or accepted.','all_jobs_terminal':True}
p=R/'results/owner-after.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
