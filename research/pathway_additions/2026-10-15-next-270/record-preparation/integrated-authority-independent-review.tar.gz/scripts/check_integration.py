"""Bounded current owner integration audit; unrelated mutable work is excluded."""
import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path,PurePosixPath
import yaml
from pathwaymech.identifiers import _load_authority,identifier_errors
R=Path(__file__).resolve().parents[1]
W=Path('/private/tmp/pathwaymech-next-270-20261015')
A=Path('/private/tmp/pathwaymech-next-270-native-authority-implementation')
T=Path('/private/tmp/pathwaymech-next-270-retention-preparation')
V=Path('/private/tmp/pathwaymech-next-270-native-authority-independent-review')
BASE='e8ae5e445d3288717c31d3012611e226fd5cca34'
checks=[]
def check(ok,label):checks.append(label);assert ok,label
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(name,value):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p
 p.write_text(json.dumps(value,indent=2)+'\n')
def git(*args,input=None):return subprocess.run(['git',*args],cwd=W,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
def verify_frozen(owner,expected,count):
 check(sha(owner/'artifact-manifest.json')==expected,'frozen manifest '+str(owner))
 rows=read(owner/'artifact-manifest.json')['files'];physical={str(p.relative_to(owner)):p for p in owner.rglob('*') if p.is_file()}
 check(len(physical)==count and set(physical)=={r['path'] for r in rows}|{'artifact-manifest.json','freeze-proof.json'},'exact hidden ignored inventory '+str(owner))
 for row in rows:check(sha(owner/row['path'])==row['sha256'] and (owner/row['path']).stat().st_size==row['bytes'],'frozen file '+str(owner/row['path']))
 return {'owner':str(owner),'manifest':expected,'physical':count,'all_exact':True}
frozen=[verify_frozen(A,'ee709a62cd177e962f5d0d6dc5a4e14fcc1b86397e3d3ed6861cf17259dfa967',3794),verify_frozen(V,'ea73c682f4d7f9921c5d664d2e795ad2c809303a13b04c57cbce2d353b0d6591',207),verify_frozen(T,'e51444da796f17c684e7bc5e8ad3455ca49f3912942bde0b62e09883468b38f6',35)]
receipt=read(R/'inputs/integration-receipt.json')
check(receipt['baseline_commit']==BASE,'integration baseline commit')
check(git('rev-parse',BASE+'^{tree}').decode().strip()=='1c03509290f5c76048cb293bdd19c1f57143059c','actual baseline tree')
authority=read(A/'results/patch-owner-inventory.json')['files']
retention=read(T/'results/prospective-owner-inventory.json')
if isinstance(retention,dict):retention=retention['files']
check(len(authority)==669 and len(retention)==12,'669 plus 12 approved inventory')
expected={r['path']:r for r in authority+retention}
check(set(expected)=={r['path'] for r in receipt['files']} and len(receipt['files'])==681,'exact integration receipt ownership')
bindings=[]
for row in receipt['files']:
 p=W/row['path'];reference=expected[row['path']]
 check(p.is_file() and not p.is_symlink(),'integrated regular owner '+row['path'])
 check(sha(p)==row['sha256']==reference['sha256'] and p.stat().st_size==row['bytes']==reference['bytes'],'exact integrated owner '+row['path'])
 check(p.read_bytes()==Path(row['source']).read_bytes(),'source copy '+row['path'])
 bindings.append({'path':row['path'],'bytes':p.stat().st_size,'sha256':sha(p)})
old_doc=git('show',BASE+':docs/IDENTIFIERS.md')
fragment=(A/'DOC-FRAGMENT.md').read_bytes()
old_heading=b'### Bounded native methanogenesis originals'
new_heading=b'## Complete native methanogenesis authority originals'
check(fragment.startswith(old_heading+b'\n'),'exact accepted fragment heading')
changed_fragment=fragment.replace(old_heading,new_heading,1)
new_doc=(W/'docs/IDENTIFIERS.md').read_bytes()
check(new_doc==old_doc.rstrip(b'\n')+b'\n\n'+changed_fragment,'only approved heading replacement and append')
check(sha(W/'docs/IDENTIFIERS.md')==receipt['documentation']['after_sha256'],'docs receipt after')
check(hashlib.sha256(old_doc).hexdigest()==receipt['documentation']['before_sha256'],'docs receipt before')
(R/'inputs/IDENTIFIERS-before.md').write_bytes(old_doc);(R/'inputs/IDENTIFIERS-after.md').write_bytes(new_doc);shutil.copy2(A/'DOC-FRAGMENT.md',R/'inputs/DOC-FRAGMENT.md')
bindings.append({'path':'docs/IDENTIFIERS.md','bytes':len(new_doc),'sha256':sha(W/'docs/IDENTIFIERS.md')})
# Compare every prior record and page to actual committed blobs, not working-tree
# diff output. This includes all prior tracked pages, assets and hidden entries.
tree=git('ls-tree','-rz',BASE,'--','data/pathways','pages').split(b'\x00')
members=[]
for raw in tree:
 if not raw:continue
 header,path=raw.split(b'\t',1);mode,kind,blob=header.split();check(kind==b'blob','record/page tree blob')
 members.append((path.decode(),blob.decode()))
request=''.join(blob+'\n' for _,blob in members).encode();stream=git('cat-file','--batch',input=request);offset=0
record_count=page_count=0
for path,blob in members:
 end=stream.index(b'\n',offset);head=stream[offset:end].split();size=int(head[2]);content=stream[end+1:end+1+size];offset=end+size+2
 check(head[0].decode()==blob,'committed blob header '+path)
 p=W/path;check(p.is_file() and p.read_bytes()==content,'unchanged prior record/page '+path)
 record_count+=int(path.startswith('data/pathways/') and path.endswith('.yaml'))
 page_count+=int(path.startswith('pages/records/') and path.endswith('.html'))
 bindings.append({'path':path,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'baseline_git_blob':blob})
check(offset==len(stream),'all batch blobs consumed')
check(record_count==page_count==266,'266 old records and record pages unchanged')
# Other copied code/contract owners stay exact; histories and later unrelated
# files are intentionally outside this fixed owner snapshot.
for p in (A/'baseline').rglob('*'):
 if not p.is_file():continue
 rel=str(p.relative_to(A/'baseline'))
 if rel in expected or rel=='docs/IDENTIFIERS.md' or rel.startswith('data/pathways/'):continue
 q=W/rel;check(q.read_bytes()==p.read_bytes(),'unchanged prior selected owner '+rel)
 bindings.append({'path':rel,'bytes':q.stat().st_size,'sha256':sha(q)})
# Exact preservation and additive ordering from the actual merged baseline.
counts={}
for snapshot in ['sources','ontology']:
 old=json.loads(git('show',BASE+':data/identifier_authorities/'+snapshot+'.json'))
 new=read(W/'data/identifier_authorities'/f'{snapshot}.json')
 for section in ['sources','terms']:
  check(list(new[section])[:len(old[section])]==list(old[section]),'old order '+snapshot+' '+section)
  for key,value in old[section].items():check(new[section][key]==value,'prior owner/value '+snapshot+' '+key)
 counts[snapshot]={'old_sources':len(old['sources']),'old_terms':len(old['terms']),'added_sources':len(new['sources'])-len(old['sources']),'added_terms':len(new['terms'])-len(old['terms'])}
 check(_load_authority(W/'data/identifier_authorities'/f'{snapshot}.json')==new['terms'],'integrated real authority load '+snapshot)
check(counts['sources']['added_terms']==counts['sources']['added_sources']==92,'92 native additions')
check(counts['ontology']['added_terms']==3 and counts['ontology']['added_sources']==0,'three taxonomy terms unchanged owner')
# Outer retained archive members only; nested containers remain opaque payloads.
retained=W/'research/pathway_additions/2026-10-15-next-270/accepted-preparation'
archive_inventory=read(retained/'inventory.json');archive_results=[]
for packet in archive_inventory['packets']:
 p=retained/packet['archive'];check(sha(p)==packet['archive_sha256'],'archive hash '+packet['name'])
 rows={row['path']:row for row in packet['files']}
 with tarfile.open(p,'r:gz') as tar:
  items=tar.getmembers();check(len(items)==len(rows) and {m.name for m in items}==set(rows),'archive exact member set '+packet['name'])
  for member in items:
   q=PurePosixPath(member.name);check(member.isfile() and not q.is_absolute() and '..' not in q.parts,'safe regular archive member '+member.name)
   payload=tar.extractfile(member).read();row=rows[member.name]
   check(len(payload)==row['bytes'] and hashlib.sha256(payload).hexdigest()==row['sha256'],'exact decoded archive member '+packet['name']+'/'+member.name)
  manifest=tar.extractfile('artifact-manifest.json').read();check(hashlib.sha256(manifest).hexdigest()==packet['source_manifest_sha256'],'retained source manifest '+packet['name'])
 archive_results.append({'name':packet['name'],'members':len(rows),'archive_sha256':sha(p),'decoded_members_exact':True})
check(len(archive_results)==10 and sum(x['members'] for x in archive_results)==2503,'ten archives 2503 members')
# One new-declaration diagnostic only: no full-corpus test rerun.
probe=R/'consumer';(probe/'data/pathways').mkdir(parents=True);(probe/'conf').mkdir()
record=yaml.safe_load((A/'inputs/frozen-design/results/native-biochemical-probe.yaml').read_text())
terms=read(A/'results/taxonomy/three-additive-terms.json')
record['taxa']=[{'id':ident,'label':term['label']} for ident,term in terms.items()]
(probe/'data/pathways/diagnostic.yaml').write_text(yaml.safe_dump(record,sort_keys=False,allow_unicode=True))
shutil.copy2(W/'conf/identifier_policy.yaml',probe/'conf/identifier_policy.yaml');shutil.copytree(W/'data/identifier_authorities',probe/'data/identifier_authorities')
errors=identifier_errors(probe);check(not errors,'integrated 101 native and three taxon declaration consumer')
save('results/owner-before.json',bindings)
save('results/integration-check.json',{'status':'passed','checks':len(checks),'check_labels':checks,'frozen_inputs':frozen,'scoped_integrated_files':len(bindings),'approved_copied_files':681,'doc_heading_from':old_heading.decode(),'doc_heading_to':new_heading.decode(),'documentation_body_unchanged':True,'prior_records_unchanged':record_count,'prior_record_pages_unchanged':page_count,'all_baseline_pages_files':sum(path.startswith('pages/') for path,_ in members),'authority_counts':counts,'archives':archive_results,'consumer_errors':errors,'diagnostic_native_nodes':101,'diagnostic_taxa':3,'all_jobs_terminal':True,'global_tree_quiescence_claimed':False})
print(json.dumps({'checks':len(checks),'approved_copies':681,'prior_records':record_count,'prior_record_pages':page_count,'archive_members':2503,'consumer_errors':errors}))
