# Replay in a new scratch owner

Do not execute the scripts in this frozen directory. Copy `scripts/` and `inputs/integration-receipt.json` into a new empty scratch owner and create its `results/` directory. The scripts derive output locations from their own file paths and refuse existing result files.

Use the existing `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B` with `PYTHONDONTWRITEBYTECODE=1` and `PYTHONNOUSERSITE=1`. Set `PYTHONPATH` to `/private/tmp/pathwaymech-next-270-20261015/src:/private/tmp/pathwaymech-next-270-20261015`, then run `scripts/check_integration.py` and `scripts/check_unchanged.py`. They read the fixed approved worktree owners and frozen input packets, perform read-only Git blob queries, and write only the new scratch owner.

The worktree and frozen evidence paths are explicitly recorded in the scripts. Later changes to those fixed owners require a successor binding. Unrelated histories, record additions and new retention groups are intentionally outside this snapshot; there is no whole-tree lock or full test-suite execution.
