--- tested README
+++ current README
@@ -101,14 +101,16 @@
 It contains nine taxa, 83 participants, 30 reaction nodes, 117 edges and 211
 references. The 259 pre-existing pathway records remain byte-identical.
 Root's native validation and separate closed JSON-schema validation passed on
-the initial integration; the complete gates are being run on the successor.
+the initial integration. Full successor validation and the recovered full test
+suite passed; the [verification report](verification.md) preserves the initial
+environment failure and exact successful command receipts.
 The [author validation wording correction](record-author-validation-wording/correction.json)
 preserves the distinction between those two checks without rewriting the frozen
 author receipts. The selected authority snapshots are promoted and the actual
 260-record identifier consumer passed after the reference correction; subsequent
-changes preserve every named identifier and label. Generated outputs, full
-repository gates, independent final review and protected publication are still
-being completed.
+changes preserve every named identifier and label. Generated graph and KGX
+checks passed. Independent assessments found no remaining supported defect;
+canonical review saves and protected publication remain separately gated.
 
 ## Retained artifacts
 
@@ -124,3 +126,9 @@
 Large originals excluded by the finite retention contracts remain external and
 hash-bound. Stored projections do not claim to replace those originals. Public
 release licensing remains deferred as instructed.
+
+The [independent review retention receipt](root-verification/independent-review-retention-promotion.json)
+binds the preserved scientific and technical proofs. The [ADIPATE storage successor](root-verification/context-adipate-storage-successor.json)
+records its exact lossless gzip path without altering source bytes or frozen
+manifest meanings. See the [completed verification report](verification.md) for
+command results and post-gate documentation boundaries.
