import hashlib,html,json,re
from pathlib import Path
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015');P=W/'research/pathway_additions/2026-10-15-next-269'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
page=W/'pages/records/MetaCyc_PWY-5177.html';raw=page.read_text();start=raw.index('<section aria-labelledby="history-title">');fragment=raw[start:raw.index('</section>',start)+len('</section>')];text=' '.join(html.unescape(re.sub('<[^>]+>',' ',fragment)).split())
results=json.loads((O/'results.json').read_text());rows=[r for r in results['new_histories'] if r['target']['kind']=='record'];assert len(rows)==2
for r in rows:
 assert ' '.join(r['event']['summary'].split()) in text and ' '.join(r['event']['details'].split()) in text
 assert f'https://github.com/CultureBotAI/PathwayMech/blob/main/{r["path"]}' in fragment
 assert r['session']['timestamp'] in text and r['session']['actors'][0]['name'] in text
(O/'history-section.html').write_text(fragment+'\n')
bindings=[]
for family in ['accepted-preparation','integration-preparation','review-preparation','integration-review']:
 inv=json.loads((P/family/'inventory.json').read_text())
 for pack in inv['packets']:
  src=Path(pack['source_path']);assert sha(src/'artifact-manifest.json')==pack['source_manifest_sha256']
  bindings.append({'source':str(src),'manifest_sha256':sha(src/'artifact-manifest.json'),'freeze_sha256':sha(src/'freeze-proof.json')})
(O/'history-visibility-and-frozen-inputs.json').write_text(json.dumps({'status':'pass','scope':'Only appended record history visibility, not full scientific/page review','record_page_sha256':sha(page),'history_entries_visible':2,'actor_correction_fully_visible':True,'original_and_correction_links_present':True,'frozen_source_packets':bindings},indent=2)+'\n')
print(json.dumps({'status':'pass','visible_history_entries':2,'bound_frozen_manifests':len(bindings)}))
