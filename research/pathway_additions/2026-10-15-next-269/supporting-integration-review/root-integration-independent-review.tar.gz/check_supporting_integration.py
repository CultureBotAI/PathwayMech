import collections,csv,hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
import yaml
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015');CI=Path('/private/tmp/pathwaymech-next-269-ci');BASE='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105';RESEARCH='research/pathway_additions/2026-10-15-next-269';P=W/RESEARCH
checks=[];inputs={}
def hashraw(raw):return hashlib.sha256(raw).hexdigest()
def sha(p):return hashraw(p.read_bytes())
def record_input(p):inputs[str(p)]=sha(p)
def load(p):record_input(p);return json.loads(p.read_text())
def emit(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=W)
def base(p):return git('show',BASE+':'+p)
def ck(ok,label):assert ok,label;checks.append(label)
ck(git('rev-parse','HEAD').decode().strip()==BASE,'actual merged baseline unchanged')
(O/'status-before.txt').write_bytes(git('status','--porcelain=v1','--untracked-files=all'))
record_path=W/'data/pathways/glutaryl-coa-degradation.yaml';record_input(record_path);record=yaml.load(record_path.read_text(), Loader=yaml.CSafeLoader);recid=record['id'];assert recid=='MetaCyc:PWY-5177'
retain=load(P/'reference-original-retention.json');increment=load(P/'record-identifier-increment.json');ck(retain['record_sha256']==increment['record_sha256']==sha(record_path),'both metadata ledgers bind actual URL successor bytes')
references={r['id']:r for r in record['references']};ck(len(references)==59 and {r['reference_id'] for r in retain['references']}==set(references),'all59 references exactly accounted')
# Bounded archive check: compressed bytes and complete frozen file inventories are re-bound.
# Previously executed whole-member decode receipts are reused; only cited artifacts are freshly decoded below.
archives={};packet_summary=[]
for family in ['accepted-preparation','integration-preparation','review-preparation','integration-review']:
 inv=load(P/family/'inventory.json');rows=inv['packets'];ck(len(rows)=={'accepted-preparation':16,'integration-preparation':3,'review-preparation':4,'integration-review':1}[family],family+' packet count')
 for pack in rows:
  arch=P/family/pack['archive'];record_input(arch);ck(sha(arch)==pack['archive_sha256'] and arch.stat().st_size==pack['archive_bytes'],str(arch.relative_to(P))+' compressed identity')
  src=Path(pack['source_path']);manifest=json.loads((src/'artifact-manifest.json').read_text());ck(sha(src/'artifact-manifest.json')==pack['source_manifest_sha256'],pack['name']+' original frozen manifest')
  expected={r['path']:r for r in manifest['files']}; expected['artifact-manifest.json']={'path':'artifact-manifest.json','bytes':(src/'artifact-manifest.json').stat().st_size,'sha256':sha(src/'artifact-manifest.json')};expected['freeze-proof.json']={'path':'freeze-proof.json','bytes':(src/'freeze-proof.json').stat().st_size,'sha256':sha(src/'freeze-proof.json')}
  actual={r['path']:r for r in pack['files']};ck(actual==expected,pack['name']+' complete frozen file inventory')
  ck(set(actual)=={str(p.relative_to(src)) for p in src.rglob('*') if p.is_file()},pack['name']+' original physical inventory including hidden/ignored')
  ck(all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in actual),pack['name']+' safe archive member paths')
  archives[str(arch.relative_to(W))]={'path':arch,'files':actual,'source':src};packet_summary.append({'family':family,'name':pack['name'],'archive_sha256':sha(arch),'files':len(actual),'source_manifest_sha256':pack['source_manifest_sha256'],'verification':'compressed hash and full frozen inventory rebound; existing full-decode receipt reused'})
ck(len(archives)==24,'24 retained packets before later canonical review')
# Map every listed original, including all alternatives, not merely first convenient match.
wanted=collections.defaultdict(set);ledger_rows=[]
for row in retain['references']:
 ident=row['reference_id'];ck(row['source_sha256']==references[ident]['source_sha256'],ident+' record/retention source hash')
 if row['retention_kind']=='complete referenced artifact bytes':
  ck(bool(row['retained_matches']),ident+' has retained matches')
  for match in row['retained_matches']:
   a=archives[match['archive']];m=a['files'][match['member']];ck(m['sha256']==row['source_sha256'],ident+' exact retained body inventory');wanted[match['archive']].add(match['member'])
 else:
  ck(ident.startswith('NCBITaxon:') and row['source_sha256']=='89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d',ident+' correct external batch hash')
  ck(row['external_original_bytes']==14115225600 and row['full_database_committed'] is False,ident+' explicit external complete database scope')
  selected=row['selected_statement_set'];ck(archives[selected['archive']]['files'][selected['member']]['sha256']==selected['member_sha256'],ident+' selected statement body identity');wanted[selected['archive']].add(selected['member'])
  binding=row['independent_source_binding'];wanted[binding['archive']].update(binding['members'])
 ledger_rows.append({'reference_id':ident,'source_sha256':row['source_sha256'],'kind':row['retention_kind']})
# Freshly decode targeted retained bodies and bounded review/row proofs; no recursive historical archive decoding.
decoded={};decoded_rows=[]
for name,names in wanted.items():
 a=archives[name]
 with tarfile.open(a['path'],'r:gz') as tar:
  for m in tar:
   if m.name in names:
    ck(m.isfile(),name+':'+m.name+' regular file');raw=tar.extractfile(m).read();expected=a['files'][m.name];ck(len(raw)==expected['bytes'] and hashraw(raw)==expected['sha256'],name+':'+m.name+' decoded hash');decoded[(name,m.name)]=raw;decoded_rows.append({'archive':name,'member':m.name,'sha256':hashraw(raw),'bytes':len(raw)})
  ck(all((name,n) in decoded for n in names),name+' all targeted members decoded')
external=[r for r in retain['references'] if r['reference_id'].startswith('NCBITaxon:')]
for row in external:
 selected=row['selected_statement_set'];d=json.loads(decoded[(selected['archive'],selected['member'])]);ck(selected['json_key']==row['reference_id'] and selected['json_key'] in d,row['reference_id']+' selected issuing row set present')
ck(len(external)==8 and len(retain['references'])-len(external)==51,'51 bodies plus8external batch references')
# Corpus identity accounting and unchanged maintained records/pages/history.
tree={}
for entry in git('ls-tree','-r','-z',BASE).split(b'\0'):
 if entry:
  meta,p=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[p.decode()]={'mode':mode,'kind':kind,'oid':oid}
def oid(raw):return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
baserecords=[];old_ids=set();all_taxa=set();all_refs=set();edges_count=0
for path,t in tree.items():
 if path.startswith('data/pathways/') and path.endswith('.yaml'):
  raw=(W/path).read_bytes();ck(oid(raw)==t['oid'],path+' existing record unchanged');r=yaml.load(raw, Loader=yaml.CSafeLoader);baserecords.append(r);old_ids.add(r['id'])
  for key in ['taxa','participants','reactions','gene_clusters']:old_ids.update(n['id'] for n in r.get(key,[]))
  all_taxa.update(n['id'] for n in r.get('taxa',[]));all_refs.update(n['id'] for n in r.get('references',[]));edges_count+=len(r.get('mechanistic_edges',[]))
ck(len(baserecords)==265,'265 original records unchanged')
recordfiles={str(p.relative_to(W)) for p in (W/'data/pathways').rglob('*.yaml')};ck(recordfiles=={p for p in tree if p.startswith('data/pathways/') and p.endswith('.yaml')}|{'data/pathways/glutaryl-coa-degradation.yaml'},'exactly one new YAML including ignored/hidden')
declared={recid}|{n['id'] for key in ['taxa','participants','reactions'] for n in record[key]};ck(len(declared)==68 and sorted(declared)==increment['declared_ids'],'68 declared IDs exact');ck(sorted(declared-old_ids)==increment['new_to_maintained_corpus'],'new IDs computed against actual maintained baseline');ck(len(declared-old_ids)==52,'52 new to corpus')
page_rows=[];history_old=[]
for path,t in tree.items():
 if (path.startswith('pages/records/') and path.endswith('.html')) or path.startswith('history/'):
  ck(oid((W/path).read_bytes())==t['oid'],path+' baseline bytes unchanged')
  (page_rows if path.startswith('pages/') else history_old).append(path)
ck(len(page_rows)==265,'all265 existing record pages byte-identical')
# Cross-record aggregate exports: no prior edge or context lost; no old global field overwritten.
def csvrows(raw):
 rows=list(csv.DictReader(io.StringIO(raw.decode()),delimiter='\t'));ck(len(rows)==len({r['id'] for r in rows}),'TSV IDs unique');return {r['id']:r for r in rows}
oldnodes=csvrows(base('pages/downloads/nodes.tsv'));nodes=csvrows((W/'pages/downloads/nodes.tsv').read_bytes());oldedges=csvrows(base('pages/downloads/edges.tsv'));edges=csvrows((W/'pages/downloads/edges.tsv').read_bytes())
ck(set(oldnodes)<=set(nodes) and set(nodes)-set(oldnodes)==declared-old_ids,'exact52new KGX node IDs');ck(set(oldedges)<=set(edges) and all(v==edges[k] for k,v in oldedges.items()),'all13869 original KGX edge rows exact');ck(len(edges)-len(oldedges)==80,'80 appended KGX rows')
changed=[]
for ident,old in oldnodes.items():
 new=nodes[ident]
 if old==new:continue
 fields=[k for k in old if old[k]!=new[k]];ck(fields==['source_contexts'],ident+' only source context extended');a=json.loads(old['source_contexts']);b=json.loads(new['source_contexts']);added=[x for x in b if x not in a];ck(all(x in b for x in a) and len(added)==1 and added[0]['record_id']==recid,ident+' preserves every old context with one new context');changed.append({'id':ident,'changed_fields':fields,'added_context':added[0]})
ck(len(changed)==16 and {r['id'] for r in changed}==declared&old_ids,'only16shared declarations changed context')
for ident in declared-old_ids:ck(len(json.loads(nodes[ident]['source_contexts']))==1 and json.loads(nodes[ident]['source_contexts'])[0]['record_id']==recid,ident+' new node context scoped')
# Manifest and aggregate displays derive from actual corpus, not manually substituted counts.
manifest=load(W/'pages/downloads/manifest.json')
for n in ['nodes.tsv','edges.tsv']:
 p=W/'pages/downloads'/n;record_input(p);ck(sha(p)==manifest['files'][n]['sha256'],'download '+n+' digest');ck(manifest['files'][n]['rows']==len(nodes if n=='nodes.tsv' else edges),'download '+n+' row count')
ck(manifest['pathway_records']==266,'download266record count');ck(manifest['version']=='sha256:'+hashraw((W/'pages/downloads/nodes.tsv').read_bytes()+(W/'pages/downloads/edges.tsv').read_bytes()),'manifest fingerprint equals actual concatenated exports')
index=load(W/'pages/pathway_index.json');oldindex=json.loads(base('pages/pathway_index.json'))
# Current index uses a top-level records list, inspect that contract without assumptions about extra metadata.
key='records' if 'records' in index else 'pathways';ck(key in index,key+' index list');oldmap={r['id']:r for r in oldindex[key]};newmap={r['id']:r for r in index[key]};ck(set(newmap)-set(oldmap)=={recid} and all(v==newmap[k] for k,v in oldmap.items()),'existing index entries exact plus one')
all_taxa.update(n['id'] for n in record['taxa']);all_refs.update(n['id'] for n in record['references']);edges_count+=len(record['mechanistic_edges']);counts={'records':266,'taxa':len(all_taxa),'edges':edges_count,'references':len(all_refs)}
ck(counts=={'records':266,'taxa':96,'edges':13949,'references':5396},'home counts independently computed')
home=(W/'pages/index.html').read_text();record_input(W/'pages/index.html')
for label,n in [('Pathway records',counts['records']),('Taxa represented',counts['taxa']),('Mechanistic edges',counts['edges']),('Distinct references',counts['references'])]:ck(f'<dt>{label}</dt><dd>{n:,}</dd>' in home,label+' home statistic')
ck(manifest['version'].removeprefix('sha256:') in home,'home manifest version agrees')
oldbrowse=base('pages/browse.html').decode();browse=(W/'pages/browse.html').read_text();record_input(W/'pages/browse.html');line=next(l for l in browse.splitlines(keepends=True) if 'data-search="glutaryl-CoA degradation MetaCyc:PWY-5177"' in l);ck(browse.replace(line,'',1)==oldbrowse and '80 mechanistic edges' in line,'browse exact one new entry')
# Four new histories, default actor attribution followed by explicit immutable correction.
newhistory=sorted(p for p in (W/'history').rglob('*.yaml') if str(p.relative_to(W)) not in tree);ck(len(newhistory)==4,'exact four new histories, ignored/hidden included')
scaffold=load(CI/'history-direct-scaffold-actions.json');corrections=load(CI/'history-attribution-correction-actions.json');failed=load(CI/'history-scaffold-actions.json');ck(len(failed)==1 and failed[0]['returncode']==127,'failed initial scaffold preserved')
for n in ['history-direct-scaffold-actions.json','history-attribution-correction-actions.json','history-scaffold-actions.json']:(O/n).write_bytes((CI/n).read_bytes())
historyrows=[]
for action in scaffold+corrections:
 ck(action['returncode']==0,'history scaffold terminal success');p=W/action['stdout'].strip();record_input(p);d=yaml.load(p.read_text(), Loader=yaml.CSafeLoader);cmd=action['command'];arg=lambda n:cmd[cmd.index(n)+1]
 ck(d['events'][0]['summary']==arg('--summary') and d['events'][0]['details']==arg('--details'),'history exact requested content');ck(d['session']['actors'][0]['name']==('codex' if '--actor-name' in cmd else 'claude-code'),'history actor/default accurately retained');ck((W/d['target']['path']).exists(),'history target exists')
 if action in corrections:
  earlier=next(x for x in scaffold if x['command'][x['command'].index('--kind')+1]==arg('--kind'))['stdout'].strip();ck(earlier in d['events'][0]['details'] and d['events'][0]['outcome']=='no_change' and d['events'][0]['type']=='GENERAL','append-only correction names exact earlier owner')
 (O/p.name).write_bytes(p.read_bytes());historyrows.append({'path':str(p.relative_to(W)),'sha256':sha(p),'session':d['session'],'target':d['target'],'event':d['events'][0]})
# Local research markdown links resolve; external issue/primary URLs are retained without new network checks.
links=[]
for p in [P/'README.md',*[P/f/'README.md' for f in ['accepted-preparation','integration-preparation','review-preparation','integration-review']]]:
 record_input(p);(O/(p.parent.name+'-README.md')).write_bytes(p.read_bytes())
 for label,url in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',p.read_text()):
  if '://' in url:continue
  target=(p.parent/url.split('#',1)[0]).resolve();ck(target.exists(),str(p.relative_to(W))+' local link '+url);links.append({'from':str(p.relative_to(W)),'url':url,'target':str(target)})
# Current scoped changed-path frontier; canonical review additions may appear later and are outside this snapshot.
modified=git('diff',BASE,'--name-only','--diff-filter=MD').decode().splitlines();expected={'conf/identifier_sources.json','data/identifier_authorities/ontology.json','data/identifier_authorities/sources.json','docs/IDENTIFIERS.md','scripts/build_source_identifier_snapshot.py','src/pathwaymech/identifiers.py','pages/browse.html','pages/downloads/edges.tsv','pages/downloads/manifest.json','pages/downloads/nodes.tsv','pages/index.html','pages/pathway_index.json'};ck(set(modified)==expected,'no unintended tracked baseline modifications')
for p in [P/'README.md',P/'reference-original-retention.json',P/'record-identifier-increment.json',W/'pages/pathway_index.json',W/'pages/downloads/manifest.json']:
 record_input(p)
(O/'reference-original-retention.json').write_bytes((P/'reference-original-retention.json').read_bytes());(O/'record-identifier-increment.json').write_bytes((P/'record-identifier-increment.json').read_bytes())
emit('results.json',{'status':'pass','checks':len(checks),'baseline':BASE,'record_sha256':sha(record_path),'scope':'Supporting integration only; exact80-edge scientific/page assessment remains separate','archive_packets':packet_summary,'archive_compressed_bytes':sum(a['path'].stat().st_size for a in archives.values()),'archive_file_inventory_total':sum(len(a['files']) for a in archives.values()),'fresh_decoded_reference_members':decoded_rows,'references':ledger_rows,'external_taxonomy_count':8,'new_declared_ids':sorted(declared-old_ids),'existing_records_unchanged':265,'existing_record_pages_unchanged':len(page_rows),'existing_history_files_unchanged':len(history_old),'new_histories':historyrows,'kgx':{'old_nodes':len(oldnodes),'new_nodes':len(nodes),'old_edges':len(oldedges),'new_edges':len(edges),'shared_context_changes':changed,'all_old_edge_rows_exact':True,'all_prior_node_contexts_preserved':True},'home_counts':counts,'local_research_links':links,'modified_paths':modified,'full_gates':'Root-owned live run; not rerun or accepted here','source_archive_scope':'Compressed hashes and every frozen file inventory rebound; original full-member decode receipts reused; all cited artifact matches and selected taxonomy proof members freshly decoded and hashed; nested execution archives not recursively decoded.'})
emit('inputs-before.json',inputs);emit('check-list.json',checks);print(json.dumps({'status':'pass','checks':len(checks),'packets':len(archives),'archive_files':sum(len(a['files']) for a in archives.values()),'fresh_decoded_members':len(decoded_rows),'shared_node_contexts':len(changed),'existing_records':265,'existing_pages':len(page_rows),'history_existing':len(history_old),'history_new':len(newhistory),'home_counts':counts}))
