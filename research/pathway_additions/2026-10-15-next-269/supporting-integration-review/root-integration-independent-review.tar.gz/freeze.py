import datetime,hashlib,json,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
inputs=json.loads((O/'inputs-before.json').read_text());assert json.loads((O/'check.stdout').read_text())['status']=='pass';assert (O/'check.stderr').read_bytes()==b'';assert json.loads((O/'history-visibility.stdout').read_text())['status']=='pass';assert (O/'history-visibility.stderr').read_bytes()==b''
for p,h in inputs.items():assert sha(Path(p))==h,p
view=json.loads((O/'history-visibility-and-frozen-inputs.json').read_text());assert sha(W/'pages/records/MetaCyc_PWY-5177.html')==view['record_page_sha256']
for row in view['frozen_source_packets']:
 p=Path(row['source']);assert sha(p/'artifact-manifest.json')==row['manifest_sha256'] and sha(p/'freeze-proof.json')==row['freeze_sha256']
prior=Path('/private/tmp/pathwaymech-next-269-authority-integration-independent-review');accepted=json.loads((prior/'integration-check.json').read_text())
for row in accepted['exact_reviewed_owners']:assert sha(W/row['path'])==row['sha256']
assert sha(W/'docs/IDENTIFIERS.md')==accepted['documentation']['after_sha256'] and sha(W/'research/pathway_additions/2026-10-15-next-269/authority-source-originals/.gitattributes')==accepted['attributes_sha256']
status=subprocess.check_output(['git','--no-optional-locks','status','--porcelain=v1','--untracked-files=all'],cwd=W);(O/'status-after.txt').write_bytes(status)
write('terminal-receipts.json',{'all_jobs_terminal':True,'first_attempt_exit_code':1,'first_attempt_disposition':'Reviewer staging-sensitive frontier assertion; full evidence preserved; corrected fixed-baseline replay passes','successful_supporting_audit_exit_code':0,'successful_checks':1831,'history_visibility_exit_code':0,'before_after_input_hashes_exact':len(inputs),'original_frozen_packets_exact':24,'prior_152_authority_owners_plus_docs_rule_unchanged':True,'record_page_sha256':view['record_page_sha256'],'full_gates':'Parent-owned run, excluded from this acceptance','no_maintained_or_git_github_writes':True,'logs':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.iterdir()) if p.is_file() and any(s in p.name for s in ['.stdout','.stderr'])}})
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['artifact-manifest.json','freeze-proof.json']]
write('artifact-manifest.json',{'scope':'Every regular physical file except artifact-manifest.json and freeze-proof.json; hidden/ignored included; failed reviewer attempt and historical root scaffold receipts retained','files':files,'listed_files':len(files),'listed_bytes':sum(x['bytes'] for x in files)})
write('freeze-proof.json',{'status':'frozen; all review jobs terminal','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'review_sha256':sha(O/'REVIEW.md'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'disposition':'bounded supporting integration acceptance without findings; canonical record/gates/publication/merge remain separate'})
print(json.dumps({'owner':str(O),'manifest':sha(O/'artifact-manifest.json'),'handoff':sha(O/'HANDOFF.md'),'review':sha(O/'REVIEW.md'),'freeze':sha(O/'freeze-proof.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files)}))
