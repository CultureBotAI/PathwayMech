from pathlib import Path
import datetime,hashlib,json,shutil
import yaml
O=Path('/private/tmp/pathwaymech-next-269-canonical-maintained-review')
R=Path('/private/tmp/pathwaymech-next-269-20261015')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
for phase in ['validate-successor','save','check']:
    receipt=json.loads((O/'results'/f'canonical-{phase}.json').read_text())
    assert receipt['exit_code']==0,phase
saved=json.loads((O/'results/canonical-save.stdout').read_text())
bundle=Path(saved['review']);md=Path(saved['markdown'])
assert bundle.is_relative_to(R/'reviews/structured')
review=yaml.safe_load(bundle.read_text())
assert review['completion']=='completed' and review['verdict']=='pass_with_limitations'
assert not review['findings']
bindings=[]
for row in review['source']['inputs']:
    data=(R/row['path']).read_bytes();assert sha(data)==row['sha256'],row['path']
    bindings.append({'path':row['path'],'sha256':row['sha256'],'bytes':len(data)})
write('results/final-input-recheck.json',{'observed_at':now,'all_unchanged':True,'inputs':bindings})
shutil.copyfile(bundle,O/'inputs/saved-review.yaml');shutil.copyfile(md,O/'inputs/saved-review.md')
write('results/saved-bundle-binding.json',{'review_id':review['review_id'],'review':str(bundle.relative_to(R)),'review_sha256':sha(bundle.read_bytes()),'markdown':str(md.relative_to(R)),'markdown_sha256':sha(md.read_bytes()),'observed_at':now})
(O/'HANDOFF.md').write_text(f'''# Frozen canonical maintained record review

The immutable canonical review is saved and the prescribed repository-wide review check passed.

- Review: `{bundle.relative_to(R)}`
- Markdown: `{md.relative_to(R)}`
- Verdict: pass_with_limitations; completion: completed; scientific_review: true.
- Findings: zero within the full selected-record scope.
- Actual target: MetaCyc:PWY-5177, data/pathways/glutaryl-coa-degradation.yaml, SHA 3c2ac2ae8443a7bdac87bd8ca9e612eee869fb479f3625231fadf84658e16317.
- Actual Git base: 7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105.
- All {len(bindings)} final canonical inputs rehashed unchanged after save/check.

Read the saved review for complete source, assay, taxon, identity, regulation, graph, metadata and independence qualifications. Prior scientific/projection evidence was retained before canonical inspection; terminal root full-gate receipts were inspected and bound without duplicating the expensive suite. This reviewer authored the authority adapter and reused separate peer acceptance; no independent self-acceptance is claimed. Legacy623/624/625 corrections are assessed without fabricated structured predecessors or GitHub closure.

The preceding scientific/projection packet remains immutable and separate. All initial pending drafts and failed reviewer draft attempts are retained here with successful successors. The only maintained writes by this final stage are the two prescribed canonical saver outputs. No scientific YAML, history, code, Git/GitHub or runtime changes were made.

All local review jobs are terminal. The complete physical scratch inventory is in artifact-manifest.json, excluding only itself and freeze-proof.json. Do not rerun these hardcoded-output helpers in this frozen owner; use a new successor owner if required. Root owns final retention, staging, publication, merge and branch/issue cleanup.
''')
assert not (O/'artifact-manifest.json').exists()
files=[]
for p in sorted(O.rglob('*')):
    if p.is_file():
        assert not p.is_symlink();data=p.read_bytes();files.append({'path':str(p.relative_to(O)),'bytes':len(data),'sha256':sha(data)})
write('artifact-manifest.json',{'created_at':now,'inventory_scope':'All physical regular files including hidden/ignored; excludes manifest and freeze proof.','files':files})
proof={'frozen_at':now,'immutable':True,'manifest':'artifact-manifest.json','manifest_sha256':sha((O/'artifact-manifest.json').read_bytes()),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'all_local_jobs_terminal':True,'canonical_review':str(bundle.relative_to(R))}
write('freeze-proof.json',proof)
print(json.dumps({**proof,'freeze_sha256':sha((O/'freeze-proof.json').read_bytes()),'handoff_sha256':sha((O/'HANDOFF.md').read_bytes()),'review_sha256':sha(bundle.read_bytes()),'markdown_sha256':sha(md.read_bytes())},indent=2))
