from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path('/private/tmp/pathwaymech-next-269-canonical-maintained-review')
R=Path('/private/tmp/pathwaymech-next-269-20261015')
phase=sys.argv[1]
assert phase in {'validate','validate-successor','save','check'}
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py']
if phase in {'validate','validate-successor'}:cmd += ['validate',str(O/'completed-review.yaml')]
elif phase=='save':cmd += ['save','--content',str(O/'completed-review.yaml')]
else:cmd += ['check','--require-reviews']
base=O/'results'/('canonical-'+phase)
assert not base.with_suffix('.stdout').exists(),'Preserve completed attempt and use a new named successor before retrying.'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
start=utc()
env={**os.environ,'PYTHONPATH':str(R/'src'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
with base.with_suffix('.stdout').open('xb') as out,base.with_suffix('.stderr').open('xb') as err:
    result=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=err)
logs={}
for suffix in ['stdout','stderr']:
    p=base.with_suffix('.'+suffix);b=p.read_bytes();logs[suffix]={'path':str(p.relative_to(O)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
receipt={'phase':phase,'command':cmd,'cwd':str(R),'started_at':start,'finished_at':utc(),'exit_code':result.returncode,'logs':logs}
base.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
