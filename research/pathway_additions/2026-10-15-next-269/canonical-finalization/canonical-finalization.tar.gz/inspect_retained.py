from pathlib import Path
import datetime,hashlib,json,os,subprocess,tarfile
O=Path('/private/tmp/pathwaymech-next-269-canonical-maintained-review')
R=Path('/private/tmp/pathwaymech-next-269-20261015')
F=Path('/private/tmp/pathwaymech-next-269-maintained-record-review')
D=Path('research/pathway_additions/2026-10-15-next-269/maintained-record-review')
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
paths=json.loads((F/'inputs/owner-complete-input-paths.json').read_text())
paths.extend(str(x.relative_to(R)) for x in (R/D).rglob('*') if x.is_file())
paths=sorted(set(paths))
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for x in paths:cmd.extend(['--input',x])
env={**os.environ,'PYTHONPATH':str(R/'src'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
start=utc();p=subprocess.run(cmd,cwd=R,env=env,capture_output=True)
(O/'results/initial-inspect.stdout').write_bytes(p.stdout);(O/'results/initial-inspect.stderr').write_bytes(p.stderr)
save('results/initial-inspect-command.json',{'command':cmd,'cwd':str(R),'started_at':start,'finished_at':utc(),'exit_code':p.returncode})
assert p.returncode==0,p.stderr
save('inputs/initial-input-paths.json',paths)
prior=json.loads((F/'results/owner-complete-inspect.stdout').read_text())
for row in prior['source']['inputs']:assert sha((R/row['path']).read_bytes())==row['sha256']
inventory=json.loads((R/D/'inventory.json').read_text())
packet=inventory['packets'][0]
expected={x['path']:x for x in packet['files']}
arc=R/D/packet['archive']; assert sha(arc.read_bytes())==packet['archive_sha256']
with tarfile.open(arc,'r:gz') as tf:
    observed={}
    for member in tf.getmembers():
        assert member.isfile() and member.name in expected and member.name not in observed
        raw=tf.extractfile(member).read();assert sha(raw)==expected[member.name]['sha256']
        assert len(raw)==expected[member.name]['bytes'];observed[member.name]=sha(raw)
        assert raw==(F/member.name).read_bytes()
    assert set(observed)==set(expected)
assert observed['artifact-manifest.json']=='9aac639b0ca2a2371b01129ada1f1109456e0faa0990ae7ce05fd72a52d35c6b'
record=(R/'data/pathways/glutaryl-coa-degradation.yaml').read_bytes()
assert record==(F/'inputs/maintained-target.yaml').read_bytes()
(O/'inputs/maintained-target.yaml').write_bytes(record)
save('results/frozen-scientific-evidence-rebind.json',{'archive':str(arc.relative_to(R)),'archive_sha256':packet['archive_sha256'],'physical_members':len(observed),'all_members_equal_frozen_owner':True,'prior213_inspected_inputs_unchanged':True,'target_byte_identical':True,'target_sha256':sha(record),'scope':'Exact maintained full-text/scientific/projection review carried from the retained bounded packet, without repeating full source/scientific or repository gates.','observed_at':utc()})
id='20261016T011225Z-glutaryl-coa-maintained-record-review';assert not (R/'reviews/structured'/id).exists()
save('results/review-identity.json',{'review_id':id,'saved_path':f'reviews/structured/{id}/review.yaml','started_at':json.loads((O/'results/start.json').read_text())['started_at'],'path_unused_at':utc()})
print(json.dumps({'inputs':len(paths)+1,'replayed_members':len(observed),'review_id':id}))
