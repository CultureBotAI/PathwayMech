from pathlib import Path
import datetime, difflib, hashlib, json, os, shutil, subprocess

O = Path('/private/tmp/pathwaymech-next-269-canonical-maintained-review')
R = Path('/private/tmp/pathwaymech-next-269-20261015')
P = Path('research/pathway_additions/2026-10-15-next-269')
D = P / 'final-verification'
T = 'MetaCyc:PWY-5177'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def write(n, value):
    p = O / n
    assert not p.exists(), p
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z')

# Capture inputs before assessing the final released metadata and terminal gates.
prior = read(O / 'results/supporting-inspect.stdout')
for row in prior['source']['inputs']:
    assert sha((R / row['path']).read_bytes()) == row['sha256'], row['path']
g = read(R / D / 'gates.json')
paths = set(read(O / 'inputs/supporting-input-paths.json'))
paths.update(str(p.relative_to(R)) for p in (R / D).rglob('*') if p.is_file())
paths.update(row['path'] for row in g['integrated_owners'])
paths.add(str(P / 'README.md'))
paths = sorted(paths)
cmd = ['/private/tmp/pathwaymech-next-263-verified-venv/bin/python', '-B',
       'scripts/record_review.py', 'inspect', '--targets', str(O / 'targets.yaml')]
for path in paths: cmd.extend(['--input', path])
env = {**os.environ, 'PYTHONPATH':str(R / 'src'), 'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONNOUSERSITE':'1'}
receipt = read(O / 'results/final-inspect-command.json')
assert receipt['command'] == cmd and receipt['exit_code'] == 0
inspection = read(O / 'results/final-inspect.stdout')
for row in inspection['source']['inputs']:
    assert sha((R / row['path']).read_bytes()) == row['sha256'], row['path']
assert inspection['source']['git_revision'] == '7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105'
write('inputs/final-input-paths.json', paths)

assert g['baseline_commit'] == inspection['source']['git_revision']
assert g['all_required_checks_passed'] is True and len(g['checks']) == 7
log_rows = []
for check in g['checks']:
    assert check['required'] is True and check['exit_code'] == 0
    for stream, row in check['logs'].items():
        raw = (R / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
        log_rows.append({'command':check['command'], 'stream':stream, **row})
assert g['test_summary'] in (R / D / 'full-test.stdout').read_text()
for phrase in ['validated 266 pathway records', 'checked 21035 evidence blocks', '510 record(s), 0 invalid', 'pages/ is current with 266 pathway records']:
    assert phrase in (R / D / 'full-validate.stdout').read_text(), phrase
assert '22 governed artifacts' in (R / D / 'vendored-check.stdout').read_text()

metadata = read(R / D / 'readme-metadata-update.json')
current = (R / metadata['path']).read_text()
assert sha(current.encode()) == metadata['after_sha256'] == '77ad69238d07a78a6edc12a0f9fa5301aea6b49daea53a48f16979d6dbaacb7a'
old = current.split('## Maintained review and checks\n')[0] + 'Full repository gates and canonical maintained review follow integration;\npreparation checks alone do not establish their completion.\n'
assert sha(old.encode()) == metadata['before_sha256'] == '11ac378a7aec2b9013bf3338a03419b05f1a4629dedd07aa679ba8922be35460'
assert ''.join(difflib.unified_diff(old.splitlines(True), current.splitlines(True), fromfile='README.before', tofile='README.after')) == metadata['diff']
for link in metadata['local_links']:
    assert link['exists'] is True and (R / P / link['target']).exists(), link
changed = []
for row in g['integrated_owners']:
    raw = (R / row['path']).read_bytes()
    if sha(raw) != row['sha256']:
        assert row['path'] == metadata['path'] and row['sha256'] == metadata['before_sha256']
        assert sha(raw) == metadata['after_sha256']
        changed.append(row['path'])
    else:
        assert len(raw) == row['bytes']
assert changed == [metadata['path']]
copy_dir = O / 'inputs/root-final-verification'
copy_dir.mkdir()
for source in sorted((R / D).rglob('*')):
    if source.is_file():
        dest = copy_dir / source.relative_to(R / D)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
(O / 'inputs/final-research-README.md').write_text(current)
(O / 'inputs/pre-metadata-research-README.md').write_text(old)
write('results/final-gate-metadata-rebind.json', {
    'observed_at':utc(), 'previous_inputs_unchanged':len(prior['source']['inputs']),
    'final_inputs':len(inspection['source']['inputs']), 'terminal_required_checks':7,
    'verified_log_occurrences':log_rows, 'gate_integrated_owners':len(g['integrated_owners']),
    'unchanged_gate_owners':len(g['integrated_owners'])-1,
    'explicit_post_gate_metadata_delta':metadata,
    'all_12_readme_links_resolve':True,
    'scope':'Root terminal commands/logs inspected and hashed; expensive suite not repeated. Owner receipt is post-run, not a pre-launch immutable attestation. Exactly one later metadata-only README change reconstructed against its old digest; scientific prefix unchanged. Current README was independently assessed after final inspect, not falsely claimed as tested by the earlier suite.'})

accessed = utc()
evidence = []
def ev(eid, path, summary, locator=None):
    row = {'evidence_id':eid, 'kind':'validation', 'reference':str(path),
           'accessed_at':accessed, 'support':'supports', 'summary':summary,
           'snapshot_sha256':sha((R / path).read_bytes())}
    if locator: row['locator'] = locator
    evidence.append(row)
ev('gate-terminal-receipt', D / 'gates.json', 'Authoritative root terminal results for all seven required commands, exact log hashes and post-run integrated-owner inventory; no invented pre-launch attestation.')
checks = []
names = ['render','validate','lint','test','diff','vendored','staged-diff']
for name, check in zip(names, g['checks']):
    eid = 'gate-' + name + '-stdout'
    summary = g['test_summary'] if name == 'test' else 'Root command completed with exit 0; exact retained stdout and stderr match the terminal receipt.'
    ev(eid, Path(check['logs']['stdout']['path']), summary)
    checks.append({'check_id':'gate-' + name, 'name':'Terminal repository ' + check['command'],
                   'status':'passed', 'required':True, 'command':check['command'],
                   'exit_code':0, 'expected_exit_code':0, 'summary':summary,
                   'target_ids':[T], 'evidence_ids':['gate-terminal-receipt', eid],
                   'scope_note':'Root executed this full integration check; reviewer inspected terminal receipt and hashed both raw logs without rerunning. Final canonical save and metadata-only README update are separately assessed.'})
ev('gate-readme-delta', D / 'readme-metadata-update.json', 'Exactly one post-suite README metadata change independently reconstructed against both hashes and the exact unified diff; 12 local links resolve. Previous scientific prose remains unchanged.')
ev('gate-final-readme', P / 'README.md', 'Full final research README read: accurate terminal results and retained evidence links, with unchanged scientific limits and clear distinction between preparation, canonical and merged-tree evidence.')
write('inputs/gate-integration.json', {
    'all_required_passed':True, 'checks':checks, 'evidence':evidence,
    'assessment_summary':'All seven root integration commands terminated with exit 0. Full test: 6,827 passed, 3 skipped, 7 warnings; validation covers 266 records, 21,035 evidence blocks and 510 histories. Lint, rendering, 22-artifact vendored integrity and both diff checks pass.',
    'evidence_ids':['gate-terminal-receipt'] + ['gate-' + n + '-stdout' for n in names],
    'metadata_evidence_ids':['gate-readme-delta', 'gate-final-readme']})
print(json.dumps({'final_inputs':len(inspection['source']['inputs']), 'gate_owners':len(g['integrated_owners']), 'unchanged_gate_owners':len(g['integrated_owners'])-1, 'documented_metadata_changes':changed, 'checks':7}))
