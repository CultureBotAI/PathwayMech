from pathlib import Path
import datetime, hashlib, json
import yaml

O=Path('/private/tmp/pathwaymech-next-269-canonical-maintained-review')
R=Path('/private/tmp/pathwaymech-next-269-20261015')
P=Path('research/pathway_additions/2026-10-15-next-269')
T='MetaCyc:PWY-5177'
def read(p): return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00','Z')
identity=read(O/'results/review-identity.json')
inspection_path=next(O/'results'/n for n in ['final-inspect.stdout','supporting-inspect.stdout','initial-inspect.stdout'] if (O/'results'/n).exists())
inspection=read(inspection_path)
evidence=[]
packets={}
for directory in ['accepted-preparation','integration-preparation','review-preparation','integration-review','maintained-record-review','supporting-integration-review']:
    inv=read(R/P/directory/'inventory.json')
    for p in inv['packets']:packets[p['name']]={**p,'relative_archive':str(P/directory/p['archive'])}
def member(eid,packet,name,kind,summary,support='supports',locator=None):
    p=packets[packet]; f=next(x for x in p['files'] if x['path']==name)
    evidence.append({'evidence_id':eid,'kind':kind,'reference':p['relative_archive'],
      'locator':name+(('; '+locator) if locator else ''),'accessed_at':now,'support':support,
      'summary':summary,'snapshot_sha256':f['sha256']})
def local(eid,path,kind,summary,locator=None):
    e={'evidence_id':eid,'kind':kind,'reference':path,'accessed_at':now,'support':'supports','summary':summary,'snapshot_sha256':sha(R/path)}
    if locator:e['locator']=locator
    evidence.append(e)

local('record','data/pathways/glutaryl-coa-degradation.yaml','record_content',
      'Full actual maintained record read before assessment; exact accepted corrected YAML, 60 native declarations, eight taxa, 80 edges, 88 structured assertions and 59 references.')
member('maintained-science','maintained-record-review','REVIEW.md','prior_review',
       'Complete bounded maintained scientific and projection assessment, with authorship disclosures, unchanged-byte carryover, primary limits and exact current target. Full repository gates and canonical save were expressly excluded.')
member('maintained-projection','maintained-record-review','results/projection-review.json','validation',
       'Fresh actual maintained imports: 1,185 final schema/HTML/SVG/KGX checks pass. Exact generated page, no-JS qualifications, every arrow/evidence target and all export descriptions/references retained.')
member('maintained-retention','maintained-record-review','results/retained-archive-replay.json','validation',
       'All 24 named retained archives and 4,781 outer member occurrences decoded/rehashed. Nested archives are exact opaque bytes here, not a new recursive-interior replay.')
member('reference-replay','maintained-record-review','results/59-reference-retention-replay.json','validation',
       'All declared matches for 51 reference bodies rehashed; eight taxonomy references explicitly bind the external pinned batch source and retained selected statements.')
member('probe-correction','maintained-record-review','results/probe-correction.json','validation',
       'Retained initial reviewer-probe mismatch concerned entity decoding of literal source units, not an owner defect; corrected final probe passes.')
member('original-science','record-independent-original-review','REVIEW.md','prior_review',
       'Independent complete scratch-record science review: 2,095 final bounded assertions, all 80 edges and 59 references; identified legacy R01 navigation defect. Exact scientific content carried through URL-only successor.')
member('native-replay','record-independent-original-review','results/all80-edge-source-replay.json','database',
       'Every native edge and all 88 source assertions compared with selected full original XML slots; exact object ownership, coefficient, direction, activity and component scope.',
       locator='native-ne001 through native-ne080; exact per-edge original slot selections')
member('native-context','record-independent-original-review','results/all29-activities-and10-regulations.json','database',
       'All native activity/regulatory contexts accounted for, including opposed microbial condensation activities and excluded human/plant contexts.')
member('primary-locators','record-independent-original-review','results/primary-original-extracts.json','primary_source',
       'Inspected original HTML source elements and exact retained source hashes for the 2009 and 2018 claims; supporting extracts are carried at the previously read scope.')
member('primary2018-placement','record-independent-original-review','results/all16-primary-claim-placement.json','prior_review',
       'Each of 16 accepted corrected 2018 primary claims mapped to actual narrative or retained unasserted context; no additional positive native graph claim inferred.')
member('pwy-original','glutaryl-preparation','originals/META-PWY-5177.xml','database',
       'Exact full native Pathway original; five members, ordering/layout and nine direct organism associations. Source assertions are not paper quotations.',
       locator="/ptools-xml/Pathway[@frameid='PWY-5177']/reaction-list; reaction-ordering; reaction-layout; species")
member('paper2009','glutaryl-preparation','originals/PMC2698508.html','primary_source',
       '2009 full main supports distinct native/recombinant organisms and constructs, ferrocenium assays, reported GDHDes kinetics and membrane-extract conversion scope.',
       locator='PMID:19395484; Abstract, Materials and Methods enzyme preparations/activity assay, Results product analysis and Table 1; exact element locators in primary-locators')
member('paper2018','glutaryl-source-completion','originals/PMC5974017.html','primary_source',
       '2018 main with retained supplement/peer-review evidence supports bounded deletion/growth and separate CsiD/LhgO route context, not every native member or physiological ETF.',
       locator='PMID:29844506; Figure 4c, Figure 7, associated Results/Methods; 16 corrected claim placements and retained supplementary insert/plate evidence')
member('paper1993','glutaryl-source-completion','originals/BF00250279.pdf','primary_source',
       'Authentic publisher HTML abstract/preview despite its .pdf filename. Supports historical K172/KB740 FAD-containing homotetramers; full methods and exact modern sequence remain unacquired.',support='partial',locator='PMID:8439237; publisher abstract/preview')
member('paper2010-si','ip08-2010-primary-completion','originals/Figshare-bi100317m_si_001.pdf','primary_source',
       'Authentic four-page 2010 supplement, DOI10.1021/bi100317m.s001, inspected fully; primer/sequence material contains no kinetic reconciliation. Full main was not acquired.',support='partial',locator='All four SI pages; exact citation PMID:20486657 / DOI:10.1021/bi100317m')
member('uniprot-kinetics','glutaryl-issuer-preparation','originals/UniProt-C3UVB0.json','authority',
       'Exact retained issuer annotation has 25 µM and 11 mmol/min/mg without per-value evidence, conflicting with the reported 2009 preparation values. Does not establish the origin of those numbers.',support='partial',locator='C3UVB0 kinetic annotation and publication list')
member('issuer-scope','independent-glutaryl-issuer-review','REVIEW.md','prior_review',
       'Previously authored independent issuer review retained at its bounded chemistry, taxon/protein/gene/sequence and five-reaction disposition scope; not represented as a new independent self-review.')
member('taxon-label-fix','direct-taxon-label-independent-acceptance','REVIEW.md','prior_review',
       'Separate peer accepted all eight microbial associations, exact issuing ranks/type-material scope and canonical reaction labels; source anomalies remain in visible chemistry prose.')
member('taxon-statements','direct-taxon-completion','results/nine-taxonomy-statement-sets.json','authority',
       'Complete selected issuing statement sets for nine native direct associations, including excluded human. Full source database identity/rank/lineage scope is distinct from browser responses.',locator='NCBITaxon:303,1076,316277,43774,43775,59405,44139,59406,9606')
member('url-acceptance','reference-url-independent-acceptance','REVIEW.md','prior_review',
       'Independent 461-check acceptance of exactly 46 native reference URL scalar corrections. All scientific semantics, original XML/xml:base, locators and digests unchanged; 13 other references unchanged.')
member('url-diffs','reference-url-independent-acceptance','results/exact-record-scalar-diffs.json','validation',
       'Exact 46 acquired-HTTPS navigation replacements, supported by retained HTTP200 acquisition receipts and matching original bodies. Only one representative old/new URL pair was freshly network-tested in the predecessor.')
member('authority-peer','native-authority-independent-review','REVIEW.md','prior_review',
       'Separate peer accepted the 152-owner bounded implementation with 386 fresh tests, coherent semantic mutation checks, exact original acquisitions, additive snapshot reproduction and complete pinned-cache verification. This reviewer authored the implementation and relies on this independent acceptance.')
member('authority-integration-peer','authority-integration-independent-review','REVIEW.md','prior_review',
       'Separate peer verified exact maintained authority integration, documentation append and XML preservation rule; current consumer imports pass. Excludes this scientific record and full repository gates.')
member('supporting-integration','root-integration-independent-review','REVIEW.md','prior_review',
       'Separate peer verified supporting retention/ledgers/history and aggregate integration with 1,831 checks: all 265 prior records/pages and 13,869 old KGX edges remain exact; 52 nodes / 80 edges added and 16 shared nodes only gain new source context. Earlier README version accepted; later gate/canonical metadata excluded.')
member('authority-rebind','maintained-record-review','results/accepted-authority-owner-rebind.json','validation',
       'All 152 maintained owners freshly match the independent integration acceptance. Byte rebind is not independent scientific or implementation self-acceptance.')
member('baseline','actual-merged-baseline-rebind','REVIEW.md','prior_review',
       'Actual merged baseline7dcc has 265 records; complete candidate source was already retained in next266; incomplete YeastPathways lead remains distinct. Bounded hidden/ignored and compressed-text duplicate/provenance search retains all exclusions.')
member('lineage','maintained-record-review','results/canonical-lineage-search.json','search',
       'Current hidden/ignored-inclusive structured-review text search found no target/slug/N269-D01/D02/R01 match; legacy issues are not fabricated canonical predecessors.')
evidence[-1]['search_scope']='rg --no-ignore --hidden -n against current reviews/structured for PWY-5177, glutaryl-coa-degradation and N269-D01/D02/R01. No binary, compressed or global absence claim.'
member('imodulon','maintained-record-review','results/imodulondb-search-receipts.json','database',
       'Six actual existing-adapter searches succeeded for applicable P. putida/E. coli context. Dataset-local gene annotations are context only; no component hit was returned by these bounded searches.',support='context_only')
member('imodulon-applicability','maintained-record-review','results/imodulondb-applicability.json','validation',
       'Existing local console available; initial sandbox DNS failure retained, network-enabled datasets retry succeeded without installation. No returned component hit requiring summarize; no absent-membership inference.')
local('reference-retention',str(P/'reference-original-retention.json'),'record_content',
      'Maintained reference retention map binds all 59 source hashes: 51 complete referenced bodies and eight explicit external pinned taxonomy batch references.')
local('page','pages/records/MetaCyc_PWY-5177.html','record_content',
      'Actual generated maintained page, source-YAML link and both append-only record histories; all source-only/primary boundaries remain visible without JavaScript.')
histories=sorted((R/'history/records/glutaryl-coa-degradation').glob('*.yaml'))
for i,h in enumerate(histories,1):local(f'history{i}',str(h.relative_to(R)),'record_content',
      'Read exact append-only record integration history and actor-attribution successor; statements preserve integration-time pending gates and do not claim a merged scientific pass.')

assessments=[]
def assess(aid,area,topic,summary,ev,details=None,outcome='supported',dimensions=None):
    a={'assessment_id':aid,'area':area,'topic':topic,'outcome':outcome,'summary':summary,'target_ids':[T],'evidence_ids':ev}
    if details:a['details']=details
    if dimensions:a['dimensions']=dimensions
    assessments.append(a)
def dimension(name,value,definition,ev):return {'name':name,'value':value,'definition':definition,'evidence_ids':ev}
assess('identity','identity','Exact native pathway and prior source reuse',
       'The record denotes the five-member MetaCyc PWY-5177 glutaryl-CoA degradation route; adjacent activation/hydroxylation routes and downstream metabolism remain outside its boundary.',
       ['record','pwy-original','baseline','maintained-science'],
       'The complete native original already existed in next266 retained research and is reused with exact identity. The incomplete source-specific YeastPathways lead is not equivalent evidence. A generic shared thiolase and upstream routes ending at glutaryl-CoA are not duplicate complete routes. The baseline search includes ignored/hidden files but expressly excludes unread binary/nested interiors; no global discovery absence is claimed.')
assess('native-equations','graph','Five members, source direction and composite separation',
       'All five native memberships, four ordering links, 20 member material occurrences and six composite occurrences retain exact objects and coefficients. Selected hydration/thiolysis do not overwrite source reversibility.',
       ['native-replay','pwy-original','record','maintained-projection'],
       'The composite has two input protons and two constituent reactions and remains outside the five-member set. K172 and KT2440 catalysts attach only to that composite, never the isolated halves. Source ordering does not establish channeling or measured flux.',
       dimensions=[dimension('source_object','PWY-5177 and six exact native Reaction originals','Five members plus one separate composite context',['native-replay']),dimension('evidence_tier','Structured source assertion','Every one of 88 graph evidence items is a native assertion, not a purported primary quotation',['native-replay'])])
assess('reaction-label','nomenclature','Legacy issue 624 canonical-label and hydration conflict',
       'All six Reaction labels remain canonical. RXN-11667 retains its source dehydrogenase label while the accurate hydration equation and naming conflict are conspicuous before the graph and in exported incident-edge context.',
       ['record','taxon-label-fix','page','maintained-projection','authority-peer'],
       'This is evidence of the applied legacy issue 624 correction, not a fabricated structured resolved finding. No broad label-policy waiver, silent source rename or unsupported NamedNode description field was introduced.')
assess('chemical-scope','grounding','Encoded structures, ETF, FAD and sodium transport',
       'Native identifiers preserve chemistry scope: generic oxidized/reduced ETF Protein classes remain distinct from exact carrier sequences and FAD; the Rhea sodium-transport equation is not adopted.',
       ['record','issuer-scope','native-replay','maintained-science'],
       'Twelve accepted ChEBI comparisons concern normalized encoded ionic structures; nine KEGG microstates differ. CML stereo/tautomer detail is not blanket equivalence. Generic ETF lacks complete formula/charge, so complete first-reaction or route elemental balance and physiological ETF coupling remain unproven. No sodium pumping stoichiometry is added.')
assess('catalysts','scope','Native catalyst and component roles',
       'Twenty-one source-only catalyst assertions preserve organism, direction and native evidence code; nine complex-component edges retain explicit or unspecified stoichiometry without independent subunit-catalysis claims.',
       ['native-replay','native-context','record'],
       'All 29 native activities are accounted for. Four microbial activities with opposing physiological condensation directions do not become route-thiolysis catalysts; four human/plant activities remain excluded. THLCLOS retains its regulated exact activity, enzyme and assembly context. Missing direction is not physiological flux.',
       dimensions=[dimension('component_role','Complex membership versus catalyst','A component relation alone does not establish that the individual subunit catalyzes the generic reaction',['native-replay'])])
assess('regulation','evidence','Exact enzyme-specific targets and source units',
       'Eight microbial inhibition assertions target four exact activity participants, linked by four enables edges. They do not inhibit every enzyme of a generic Reaction.',
       ['native-replay','native-context','record','maintained-projection','probe-correction'],
       'Two human ion-regulation contexts remain excluded. REG-14465 Ki 120 retains literal &micro;mole without micromolar conversion. The selenium-source conflict is retained without a selenium cofactor edge. Native source evidence is not relabelled as an independently read historical assay.')
assess('taxa','scope','Legacy issue 623 direct-taxon completion and issuing rank',
       'All eight direct microbial pathway associations are present with exact issuing scope; the ninth human association is explicitly excluded.',
       ['taxon-statements','taxon-label-fix','pwy-original','record','maintained-projection'],
       'NCBITaxon:303, 1076, 316277, 43774, 43775, 59405, 44139 and 59406 are preserved. Historical K172 binds the issuing strain 44139 separately from species 59405; KB740 binds Aromatoleum evansii species/type material, not an invented strain/modern sequence. Other enzyme organism contexts do not broaden whole-route taxa. These accepted legacy issue 623 changes are assessed without inventing canonical finding lineage.',
       dimensions=[dimension('taxon_condition','Native pathway association only','A direct source association is not independent proof of all five members, flux or ETF coupling in the taxon',['pwy-original','record']),dimension('taxon_rank','K172 strain; KB740 species/type material','Native historical naming is reconciled only to accepted issuing rank and type-material evidence',['taxon-statements','taxon-label-fix'])])
assess('primary2009','evidence','2009 organism, construct and assay scope',
       'The narrative keeps native GS15, tagged recombinant GS15 and tagged DSM2059 preparations separate and confines their results to the artificial-ferrocenium assays.',
       ['paper2009','primary-locators','original-science','record'],
       'GS15 oxidative decarboxylation and DSM2059 dehydrogenation without detected crotonyl-CoA are preparation-specific. Membrane extract plus 20 mM NaCl is not a purified sodium pump or physiological ETF experiment. The 52±5 µM / 11±1 µmol min−1 mg−1 values refer to the reported DSM2059 preparation at 30°C/pH 7.8. No engineered construct is silently represented as an unqualified native enzyme endpoint.')
assess('primary2018','evidence','2018 growth, complements and alternative route',
       'KT2440 deletion/growth, substrate-consumption and expression context is qualified by exact experimental scope; the separate CsiD/LhgO route is not promoted to the native graph.',
       ['paper2018','primary2018-placement','primary-locators','original-science','record'],
       'Complement inserts include gdh+pp0159 and csiD+lhgO. Sampling occurred after glutarate contact; plate observations distinguish 36 h Figure 4c from 12 h Supplementary Figure 9. Figure 7 is a network interpretation without 13C tracing. Proposed CsiR/glutarate control is not a demonstrated edge. All 16 corrected accepted claims have record/context dispositions.')
assess('historical-identities','consistency','Historical protein, gene and sequence conflicts',
       'The record preserves the 1993 abstract-only scope and unresolved historical/modern sequence and strain bindings, without substituting convenient accessions.',
       ['paper1993','issuer-scope','original-science','record'],
       'K172/AE016774 conflicts with the issuing KT2440 record; KB740/MAY27 and the current KT2440 gene identity remain unresolved. Sequence length, residue numbering and accession/version coordinates remain explicit retained limitations. The 1993 abstract supports FAD homotetramers but not unacquired methods or a physiological ETF partner.')
assess('ip08','quantity','Unresolved 2009/issuer/2010 kinetic discrepancy',
       'The kinetic discrepancy remains evidence-limited and explicitly disclosed; the record makes no global numerical correction or attribution of the database values to the inaccessible 2010 main.',
       ['paper2009','uniprot-kinetics','paper2010-si','record'],
       'The verified 2010 citation and four-page supplement contain no kinetic reconciliation or exact 2010 assay-preparation result. This uncertainty does not invalidate the correctly scoped native source graph, but prevents an unqualified pass on those kinetic values.',outcome='unknown')
assess('references','provenance','Legacy issue 625 navigation correction and original-byte retention',
       'All 46 native navigation URLs now use their exact acquired HTTPS bare-query URLs. All original XML, embedded source bases, assertions, source versions and digests remain unchanged.',
       ['url-acceptance','url-diffs','reference-replay','reference-retention','record'],
       'Thirteen other references are unchanged. Existing successful acquisition receipts bind all 46 replacements; only one representative pair was freshly live-tested in the predecessor. This is applied legacy issue 625 fix evidence, not a fabricated structured predecessor or GitHub closure. All 59 hashes are accounted for: 51 full referenced artifacts retained and eight external pinned taxonomy batch references.')
assess('taxonomy-hash','provenance','External batch digest semantics',
       'Eight NCBITaxon source_sha256 values correctly identify the entire external pinned 2026-07-12 SQLite source, not individual browser responses or selected-row JSON.',
       ['taxon-statements','reference-retention','reference-replay','authority-peer'],
       'The database is 14,115,225,600 bytes with SHA 89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d. Complete selected statement sets and independently accepted cache/hash/query receipts are retained. This canonical stage does not repeat the 14 GB hash or claim that 59 complete source bodies were committed.')
assess('authority-independence','ownership','Separate authority acceptance and exact maintained owners',
       'The 49 new native terms and three additive pinned taxa are supported by separate peer implementation and maintained integration acceptances; all 152 actual owners match those accepted bytes.',
       ['authority-peer','authority-integration-peer','authority-rebind'],
       'This reviewer authored the adapter and does not self-accept it. Peer verification preserves all prior owners/terms and ordering, genuine full source identity and exact labels, four activity roles and 26 reference-only exclusions. The separate profiles are unchanged. Authority identity alone is not experimental biological support.')
assess('page-export','representation','No-JS reading and graph/export fidelity',
       'The actual page and corrected KGX reproduce exactly with maintained modules: all 60 native SVG nodes, 80 directed evidence-linked edges and 68 KGX declarations remain faithful.',
       ['maintained-projection','page','record'],
       'Every root paragraph and the taxon/hydration qualifications remain ordinary visible HTML before the graph. All local fragments resolve and IDs are unique. KGX omits root description by contract; relevant incident-edge context, exact evidence and reference metadata remain intact. Static review is bounded; no new interactive browser or complete pixel-level label audit is claimed.')
assess('history','provenance','Append-only integration and actor correction',
       'The only maintained-page additions over the accepted corrected preview are the source-YAML link and two transparent record history events.',
       ['page','history1','history2','maintained-projection'],
       'The initial integration event inherited actor name claude-code while agent_tool/model already identified Codex/GPT-6. The visible append-only successor corrects attribution to codex without rewriting the original or biological owners. The corresponding infrastructure histories are also input-bound. Events truthfully preserve their integration-time pending-gate statements.')
assess('supporting-integration','consistency','Preservation of prior records and aggregate outputs',
       'Separate independent integration evidence supports the candidate increment without changing existing biological owners or prior graph assertions.',
       ['supporting-integration','reference-retention','authority-rebind'],
       'The peer verified all 265 prior records and pages, all 13,869 old KGX edge rows, 52 added node IDs and 80 edges. Sixteen shared nodes only gain new PWY-5177 source context; all prior attributes/contexts remain. This is bounded integration acceptance, not a scientific review of those 265 records or acceptance of the later final-gate README edits.')
assess('structured-context','scope','iModulonDB applicability and bounded context',
       'The existing structured adapter was available and its applicable P. putida/E. coli queries succeeded. Returned gene annotations are contextual leads and add no biochemical or regulatory assertion.',
       ['imodulon','imodulon-applicability','record'],
       'Queries gdh/glutaryl/CsiR/csiD/lhgO in p_putida/precise321 and acetyl-CoA acetyltransferase in e_coli/precise_mg1655 returned gene keys including PP_0158 (gcdH), PP_2908, PP_2909, PP_2910 and b2224 (atoB). gdh alone returned glutamate-dehydrogenase near misses. No component hit was returned, so no summarize k applied; no absence of membership is inferred. These dataset-local keys do not resolve the issuing gene/sequence conflicts or prove CsiR control.',dimensions=[dimension('evidence_tier','Structured expression-database context','Annotation/module context is not direct catalysis, pathway membership, flux or demonstrated regulation',['imodulon'])])

checks=[{'check_id':'retained-evidence','name':'Maintained evidence and source retention replay','status':'passed','required':True,'summary':'All 24 retained archives / 4,781 outer member occurrences and 59 reference bindings verified; exact frozen maintained review of 117 members rebound in the canonical stage.','target_ids':[T],'evidence_ids':['maintained-retention','reference-replay','maintained-science'],'scope_note':'Nested archives not newly recursively replayed; full external taxonomy cache not rehashed at this stage.'},
 {'check_id':'science','name':'Complete scoped scientific record assessment','status':'passed','required':True,'summary':'Full actual YAML read; all 80 edges/88 source assertions/59 references assessed by exact-byte carryover of complete independent science and URL successor evidence, with limitations preserved.','target_ids':[T],'evidence_ids':['record','original-science','native-replay','url-acceptance','maintained-science']},
 {'check_id':'projection','name':'Fresh maintained schema, page and KGX reproduction','status':'passed','required':True,'summary':'1,185 final bounded checks pass; exact current page and corrected KGX reproduce.','target_ids':[T],'command':'/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B /private/tmp/pathwaymech-next-269-maintained-record-review/review_maintained_projection.py','exit_code':0,'expected_exit_code':0,'evidence_ids':['maintained-projection','probe-correction'],'scope_note':'Fresh bounded import/reproduction checks, not a replacement for root-owned full corpus gates. Initial reviewer unit-entity assumption failure preserved separately.'},
 {'check_id':'structured-adapter','name':'Applicable existing iModulonDB adapter context check','status':'passed','required':True,'summary':'Datasets query and six bounded applicable searches succeeded; no component hit requiring summarize.','target_ids':[T],'command':'Existing CLAW kg-microbe-sources imodulondb datasets; six search invocations recorded in imodulondb-search-receipts.json','exit_code':0,'expected_exit_code':0,'evidence_ids':['imodulon','imodulon-applicability'],'scope_note':'Initial sandbox DNS failure retained; successful existing-runner retry required no installation. No broad search or absent-module claim.'}]
gatefile=O/'inputs/gate-integration.json'
complete=gatefile.exists()
if complete:
    gates=read(gatefile);assert gates['all_required_passed']
    checks.extend(gates['checks']);evidence.extend(gates['evidence'])
    assess('full-gates','schema','Terminal whole-repository checks',
           gates['assessment_summary'],gates['evidence_ids'],
           'Root executed the documented full gates against the unchanged integrated owners. This reviewer inspected terminal receipts and log hashes without duplicating the expensive suite. Deterministic gates do not replace the scientific assessment.')
    assess('final-metadata','provenance','Post-suite documentation metadata successor',
           'The final research README accurately reports terminal gates and links the retained independent evidence and stable structured-review directory.',
           gates['metadata_evidence_ids'],
           'The gate receipt inventories 201 owners after the run; it is not an immutable pre-launch attestation. Exactly 200 remain byte-identical. The README alone has a documented later metadata update: both old/new hashes and the precise diff were independently reconstructed, all preceding scientific text is unchanged, and all 12 local links resolve. The full suite preceded this metadata-only change; this assessment does not falsely claim that the earlier suite tested the later README or this new canonical bundle.')
else:
    for name in ['validate','test','lint','diff-check']:
        checks.append({'check_id':'pending-'+name,'name':'Required repository '+name,'status':'unavailable','required':True,'summary':'Terminal complete root gate bundle not released to this canonical owner yet; no completed result inferred.','target_ids':[T]})
if complete:
    finished = datetime.datetime.now(datetime.timezone.utc)
    identity['finished_at'] = finished.isoformat().replace('+00:00','Z')
    identity['final_review_id'] = finished.strftime('%Y%m%dT%H%M%SZ')+'-glutaryl-coa-maintained-record-review'
    identity['saved_path'] = f"reviews/structured/{identity['final_review_id']}/review.yaml"
    assert not (R/'reviews/structured'/identity['final_review_id']).exists()
    (O/'results/review-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
content={'schema_version':'1.0.0','review_id':identity.get('final_review_id') if complete else datetime.datetime.fromisoformat(now.replace('Z','+00:00')).strftime('%Y%m%dT%H%M%SZ')+'-glutaryl-coa-maintained-record-review','kind':'record','repository':'CultureBotAI/PathwayMech',
 'title':'Glutaryl-CoA degradation: maintained scientific, provenance and graph review',
 'started_at':identity['started_at'],'finished_at':identity.get('finished_at',now),
 'reviewer':{'identity':'Codex /root/next268_current_bigg_completion','kind':'agent','model':'gpt-6','independence':'independent',
   'independence_basis':'Independent of the peer-authored scientific record, native graph design, taxon/label successor and root URL correction. This reviewer authored the prospective authority adapter, earlier issuer review and IP08 source completion; their authorship is disclosed, and authority acceptance relies on a separate peer implementation/integration review. This is not independent self-acceptance of that adapter.'},
 'skill':'.claude/skills/review-yaml-record/SKILL.md; docs/record-reviews.md; docs/record-review-profile.md',
 'completion':'completed' if complete else 'partial','verdict':'pass_with_limitations' if complete else 'blocked',
 'native_verdict':'Supported native source graph with explicit primary/issuer limits', 'scientific_review':True,
 'summary':('The complete maintained PWY-5177 record is supported within its declared source and primary scope. Five native members, eight microbial taxa,60 native declarations,80 edges,88 source assertions and 59 references retain exact identity and limitations. Legacy taxon/label/navigation corrections are verified; no new actionable finding. Maintained page/KGX reproduction and all required terminal repository gates pass.' if complete else 'Scientific and projection assessment is supported, but canonical completion awaits the terminal root full-gate bundle. Do not publish this draft as a completed review.'),
 'source':inspection['source'],'scope':{'description':'Complete review of one actual maintained glutaryl-CoA degradation record, its native graph/evidence, primary-context limits, exact source retention, generated page/export and accepted authority integration.','selection':'Exact requested new maintained target MetaCyc:PWY-5177; full selected-record coverage, no sampling.','coverage':'full','population_size':1,'reviewed_target_ids':[T],
   'exclusions':[{'target':'Other 265 maintained records','reason':'Covered by deterministic whole-corpus gates only; no new scientific review of those records.'},{'target':'Unacquired 1993/2010 full mains and unread historical native-cited papers','reason':'Do not manufacture primary results; source-only annotations and explicit limitations remain.'},{'target':'Global resource exhaustion, complete nested archive content and physiological route flux','reason':'Not established by bounded retained searches or native source assertions.'},{'target':'Authority adapter independent self-review','reason':'This reviewer authored it; separate peer acceptance is required and bound.'},{'target':'Publication/merge and GitHub issue closure','reason':'Not performed or certified by this record-review save.'}]},
 'targets':inspection['targets'],'checks':checks,'evidence':evidence,'assessments':assessments,'findings':[],'actions':[],
 'limitations':['IP08 remains evidence-limited: the authentic 2010 supplement does not reconcile UniProt C3UVB0 kinetics against the 2009 preparation; full main was not acquired.',
   'Generic ETF lacks exact physiological carrier identity and complete formula/charge; no complete route elemental balance, physiological ETF coupling, sodium pump or whole-route flux claim.',
   'Historical strain/protein/gene/sequence and selenium-source conflicts remain explicitly unresolved at their retained source scope; native annotations are not independently read primary assays.',
   'Eight taxonomy reference hashes bind one external full pinned SQLite database, not eight browser responses. Fifty-one other referenced body artifacts are retained; no claim that 59 complete originals were committed.',
   'This stage replays outer retained members and carries exact prior accepted evidence; it does not rehash the 14 GB taxonomy database, re-read every historical paper or perform global discovery.',
   'Current KGX does not export root description; verified incident-edge qualifications preserve required taxon/hydration scope. Broader primary narrative is not claimed as experimental graph evidence.',
   'Static no-JS/HTML/SVG checks and prior static image review do not constitute new interactive-browser or exhaustive pixel-level readability testing.',
   'The six applicable iModulonDB searches return source-local gene context and no component hit; this is not negative evidence for module membership and does not resolve issuing-gene or regulatory conflicts.',
   'Legacy issues 623/624/625 are issue/research history, not fabricated canonical predecessors. This clean current finding list does not itself close external issues or supersede unlinked structured findings.'],
 'notes':['Prescribed inspect ran before the maintained assessment, then explicit successor inspections assessed released page/history/authority inputs; all previous inputs remained byte-identical. Canonical stage reinspected the retained 117-member evidence packet and actual target.',
   'Initial reviewer entity-decoding probe failure and sandbox DNS failure are preserved with successful bounded successors. No scientific/production owner was edited by this reviewer.',
   'Review saving changes only the immutable canonical review bundle; no history, native scientific status, source record, Git or GitHub mutation is implied.'],
 'links':['https://github.com/CultureBotAI/PathwayMech/issues/623','https://github.com/CultureBotAI/PathwayMech/issues/624','https://github.com/CultureBotAI/PathwayMech/issues/625'],
 'tags':['pathway','native-source','glutaryl-coa','scientific-review','graph','bounded-primary-evidence']}
(O/('completed-review.yaml' if complete else 'pending-review.yaml')).write_text(yaml.safe_dump(content,sort_keys=False,allow_unicode=True,width=110))
print(json.dumps({'completion':content['completion'],'verdict':content['verdict'],'inputs':len(content['source']['inputs']),'evidence':len(evidence),'assessments':len(assessments),'checks':len(checks)}))
