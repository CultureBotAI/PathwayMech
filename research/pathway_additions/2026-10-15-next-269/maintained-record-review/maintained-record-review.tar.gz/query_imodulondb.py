from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime, hashlib, json, os, subprocess
O=Path('/private/tmp/pathwaymech-next-269-maintained-record-review')
C=Path('/Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/culturebotai-claw')
runner=C/'.venv/bin/kg-microbe-sources'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def query(q):
    organism,dataset,term=q
    name=f'imodulondb-{organism}-{dataset}-{term.replace(" ","_")}'
    cmd=[str(runner),'imodulondb','--timeout','20','search','--organism',organism,'--dataset',dataset,'--query',term]
    start=utc(); p=subprocess.run(cmd,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'},capture_output=True)
    (O/'results'/(name+'.stdout')).write_bytes(p.stdout);(O/'results'/(name+'.stderr')).write_bytes(p.stderr)
    return {'command':cmd,'started_at':start,'finished_at':utc(),'exit_code':p.returncode,'stdout':name+'.stdout','stderr':name+'.stderr','stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
queries=[('p_putida','precise321',x) for x in ['gdh','glutaryl','CsiR','csiD','lhgO']]
queries += [('e_coli','precise_mg1655','acetyl-CoA acetyltransferase')]
with ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(query,queries))
bindings=[]
for n in ['.venv/bin/kg-microbe-sources','src/kg_microbe_sources/__main__.py','src/kg_microbe_sources/imodulondb.py','pyproject.toml']:
    data=(C/n).read_bytes();dst=O/'inputs/structured-adapter'/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
    bindings.append({'path':str(C/n),'sha256':hashlib.sha256(data).hexdigest()})
(O/'results/imodulondb-search-receipts.json').write_text(json.dumps({'commands':results,'runner_bindings':bindings,'scope':'Bounded context check, not proof of catalysis, native route membership, physiology or regulatory edge; no broad search or runtime change.'},indent=2)+'\n')
print(json.dumps(results,indent=2))
