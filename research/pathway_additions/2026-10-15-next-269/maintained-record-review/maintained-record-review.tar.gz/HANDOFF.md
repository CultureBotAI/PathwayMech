# Frozen maintained scientific/projection evidence

Accepted within the bounded maintained-record scientific and projection scope, with the explicit source limitations in REVIEW.md. No new actionable record finding. Full repository gate completion and canonical save/check are excluded and remain root-coordinated.

Actual base: 7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105; tree 1a0560c741c07fcb7878b1e93d8d38da67b1287c. Target data/pathways/glutaryl-coa-degradation.yaml SHA 3c2ac2ae8443a7bdac87bd8ca9e612eee869fb479f3625231fadf84658e16317. Page SHA cdc1f22bb645a92e09adf30a04b0d1bf637ff48e5529c005a1c26948e1fcf369. All 213 final inspected inputs rehashed unchanged.

All 24 retained archives / 4,781 outer member occurrences replayed. All 59 reference hashes accounted for: 51 archived original bodies and eight external pinned-taxonomy-batch references. Fresh maintained projection: 1,185 passing checks; accepted successor page/KGX identity, source/history display additions, all 80 SVG evidence links and no-JS qualifications verified. Failed reviewer unit-entity probe is preserved; no owner correction needed.

The existing CLAW structured adapter succeeded after a retained sandbox DNS failure. Six applicable searches returned bounded P. putida/E. coli gene annotations and no component hit requiring summarize. See complete applicability/search receipts; no absent-module, catalytic or gene-issuer reconciliation claim.

Independence: this reviewer did not author the scientific record/design/root URL correction. This reviewer authored the authority adapter, prior issuer review and IP08 completion; separate peer authority acceptance is reused with exact bindings, not self-accepted.

Root should retain this entire packet under research/pathway_additions/2026-10-15-next-269/maintained-record-review/maintained-record-review.tar.gz. Then the final canonical reviewer must inspect the actual target and this now-retained evidence plus the terminal full-gate owners from a NEW scratch directory. Do not rerun these scripts in this immutable owner: they write outputs here. No maintained YAML/history/code, Git/GitHub or runtime changes were made. All of this packet's local jobs are terminal.

artifact-manifest.json lists every physical regular file except itself and freeze-proof.json, including hidden/ignored files. The freeze proof binds the manifest. Prior frozen packets remain unchanged.
