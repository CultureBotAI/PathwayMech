from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, tarfile
import yaml

OUT = Path('/private/tmp/pathwaymech-next-269-maintained-record-review')
ROOT = Path('/private/tmp/pathwaymech-next-269-20261015')
RESEARCH = Path('research/pathway_additions/2026-10-15-next-269')
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

# This explicit successor inspection adds released page/history/integration inputs;
# it must preserve all first-inspection bytes before their assessment is reused.
initial = json.loads((OUT/'results/initial-inspect.stdout').read_text())
for row in initial['source']['inputs']:
    assert sha((ROOT/row['path']).read_bytes()) == row['sha256'], row['path']
paths = json.loads((OUT/'inputs/initial-input-paths.json').read_text())
paths += ['pages/records/MetaCyc_PWY-5177.html', 'src/pathwaymech/site_display.py',
          'src/pathwaymech/reaction_mechanisms.py', 'src/pathwaymech/mechanism_view.py']
for dirname in ['history/records/glutaryl-coa-degradation',
                'history/infrastructure/glutaryl-native-authority',
                str(RESEARCH/'integration-review')]:
    paths.extend(str(p.relative_to(ROOT)) for p in (ROOT/dirname).rglob('*') if p.is_file())
paths = sorted(set(paths))
assert all((ROOT/p).is_file() for p in paths)
cmd = [PYTHON, '-B', 'scripts/record_review.py', 'inspect', '--targets', str(OUT/'targets.yaml')]
for p in paths:
    cmd += ['--input', p]
env = {**os.environ, 'PYTHONPATH':str(ROOT/'src'), 'PYTHONDONTWRITEBYTECODE':'1', 'PYTHONNOUSERSITE':'1'}
started = utc()
proc = subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True)
(OUT/'results/released-input-inspect.stdout').write_bytes(proc.stdout)
(OUT/'results/released-input-inspect.stderr').write_bytes(proc.stderr)
save('results/released-input-inspect-command.json', {'command':cmd, 'started_at':started,
     'finished_at':utc(), 'exit_code':proc.returncode, 'cwd':str(ROOT)})
assert proc.returncode == 0, proc.stderr
save('inputs/released-input-paths.json', paths)
save('results/inspection-successor-delta.json', {
    'original_inputs':len(initial['source']['inputs']), 'all_original_inputs_unchanged':True,
    'added_inputs':sorted(set(paths)-set(json.loads((OUT/'inputs/initial-input-paths.json').read_text()))),
    'assessment_boundary':'Page source link, append-only history attribution and separately accepted maintained authority integration; no biology delta.'})

# Decode every outer retained member, including hidden/ignored names, and bind to
# the root inventory and source manifest. Nested execution archives are opaque
# here; earlier independent checks retain their precise internal scope.
archives = []
member_hashes = {}
for directory in ['accepted-preparation', 'integration-preparation', 'review-preparation', 'integration-review']:
    inventory = json.loads((ROOT/RESEARCH/directory/'inventory.json').read_text())
    for packet in inventory['packets']:
        relative = str(RESEARCH/directory/packet['archive'])
        archive = ROOT/relative
        assert archive.stat().st_size == packet['archive_bytes']
        assert sha(archive.read_bytes()) == packet['archive_sha256']
        expected = {x['path']:x for x in packet['files']}
        got = {}
        with tarfile.open(archive, 'r:gz') as tf:
            for member in tf.getmembers():
                assert member.isfile(), (relative, member.name, member.type)
                assert member.name in expected and member.name not in got
                data = tf.extractfile(member).read()
                digest = sha(data)
                assert member.size == expected[member.name]['bytes']
                assert digest == expected[member.name]['sha256']
                got[member.name] = digest
                member_hashes[(relative, member.name)] = digest
                if member.name in {'REVIEW.md','HANDOFF.md','ASSESSMENT.md'}:
                    target = OUT/'inputs/retained-reading'/packet['name']/member.name
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(data)
            assert set(got) == set(expected)
            if 'artifact-manifest.json' in got:
                assert got['artifact-manifest.json'] == packet['source_manifest_sha256']
        archives.append({'archive':relative, 'sha256':packet['archive_sha256'],
                         'physical_members':len(got), 'all_outer_members_rehashed':True,
                         'source_manifest_sha256':packet['source_manifest_sha256']})
save('results/retained-archive-replay.json', {'archives':archives,
    'archive_count':len(archives), 'member_occurrences':sum(x['physical_members'] for x in archives),
    'scope':'All listed outer archive members decoded and rehashed. Nested archives retained as exact bytes; no new recursive-member replay claim.'})

target = ROOT/'data/pathways/glutaryl-coa-degradation.yaml'
raw = target.read_bytes()
assert sha(raw) == '3c2ac2ae8443a7bdac87bd8ca9e612eee869fb479f3625231fadf84658e16317'
(OUT/'inputs/maintained-target.yaml').write_bytes(raw)
accepted = Path('/private/tmp/pathwaymech-next-269-reference-url-independent-acceptance/inputs/successor.yaml')
assert raw == accepted.read_bytes()
record = yaml.safe_load(raw)
retention = json.loads((ROOT/RESEARCH/'reference-original-retention.json').read_text())
assert retention['record_sha256'] == sha(raw)
refs = {x['id']:x for x in record['references']}
assert len(refs) == len(retention['references']) == 59
reference_checks = []
for row in retention['references']:
    ref = refs[row['reference_id']]
    assert row['source_sha256'] == ref['source_sha256']
    if ref['id'].startswith('NCBITaxon:'):
        assert ref['source_sha256'] == '89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d'
        assert ref['source_version'] == 'NCBI Taxonomy 2026-07-12'
        reference_checks.append({'reference_id':ref['id'], 'status':'external pinned full SQLite; selected statements and independent cache verification retained', 'retention':row})
    else:
        assert row['retained_matches']
        for match in row['retained_matches']:
            assert member_hashes[(match['archive'],match['member'])] == ref['source_sha256']
        reference_checks.append({'reference_id':ref['id'], 'status':'all declared retained original matches rehashed', 'matches':row['retained_matches']})
save('results/59-reference-retention-replay.json', reference_checks)
save('results/maintained-record-binding.json', {
    'record':str(target.relative_to(ROOT)), 'sha256':sha(raw), 'bytes':len(raw),
    'accepted_successor_byte_identical':True, 'full_text_read':True,
    'native_declarations':1+len(record['participants'])+len(record['reactions']),
    'taxa':len(record['taxa']), 'edges':len(record['mechanistic_edges']),
    'evidence_items':sum(len(e['evidence']) for e in record['mechanistic_edges']),
    'references':len(refs), 'retained_reference_bodies':51, 'external_pinned_database_references':8,
    'completed_at':utc()})
print(json.dumps({'archives':len(archives),'outer_member_occurrences':sum(x['physical_members'] for x in archives), 'references':len(refs),'inputs':len(paths)+1}))
