from pathlib import Path
import datetime, hashlib, json, os, subprocess, tarfile

O=Path('/private/tmp/pathwaymech-next-269-maintained-record-review')
R=Path('/private/tmp/pathwaymech-next-269-20261015')
PREFIX=Path('research/pathway_additions/2026-10-15-next-269')
PY='/private/tmp/pathwaymech-next-263-verified-venv/bin/python'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
arc=R/PREFIX/'integration-review/authority-integration-independent-review.tar.gz'
with tarfile.open(arc,'r:gz') as tf:
    proof=json.loads(tf.extractfile('integration-check.json').read())
owners=proof['exact_reviewed_owners']
for row in owners:
    data=(R/row['path']).read_bytes()
    assert sha(data)==row['sha256'] and len(data)==row['bytes'],row['path']
save('results/accepted-authority-owner-rebind.json',{'actual_owners':owners,'count':len(owners),
     'matched_independent_integration_acceptance':True,'independence':'This reviewer authored these owners; their acceptance is supplied by the separate peer review, not this byte rebind.'})
prior=json.loads((O/'results/released-input-inspect.stdout').read_text())
for row in prior['source']['inputs']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
paths=json.loads((O/'inputs/released-input-paths.json').read_text())
paths.extend(x['path'] for x in owners)
paths.append(str(PREFIX/'authority-source-originals/.gitattributes'))
paths=sorted(set(paths));assert all((R/x).is_file() for x in paths)
cmd=[PY,'-B','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for p in paths:cmd.extend(['--input',p])
env={**os.environ,'PYTHONPATH':str(R/'src'),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
started=utc(); result=subprocess.run(cmd,cwd=R,env=env,capture_output=True)
(O/'results/owner-complete-inspect.stdout').write_bytes(result.stdout)
(O/'results/owner-complete-inspect.stderr').write_bytes(result.stderr)
save('results/owner-complete-inspect-command.json',{'command':cmd,'cwd':str(R),'started_at':started,'finished_at':utc(),'exit_code':result.returncode})
assert result.returncode==0,result.stderr
save('inputs/owner-complete-input-paths.json',paths)
governance=[]
old=Path('/private/tmp/pathwaymech-next-269-independent-record-review/inputs/governance')
for p in old.rglob('*'):
    if p.is_file():
        rel=str(p.relative_to(old));assert (R/rel).read_bytes()==p.read_bytes(),rel
        governance.append({'path':rel,'sha256':sha(p.read_bytes()),'prior_full_read_unchanged':True})
save('results/governance-rebind.json',governance)
command=['rg','--no-ignore','--hidden','-n','PWY-5177|glutaryl-coa-degradation|N269-D01|N269-D02|N269-R01','reviews/structured']
start=utc();q=subprocess.run(command,cwd=R,capture_output=True)
(O/'results/canonical-lineage-search.stdout').write_bytes(q.stdout)
(O/'results/canonical-lineage-search.stderr').write_bytes(q.stderr)
assert q.returncode in (0,1),q.stderr
save('results/canonical-lineage-search.json',{'command':command,'cwd':str(R),'exit_code':q.returncode,'started_at':start,'finished_at':utc(),'match_lines':len(q.stdout.splitlines()),'scope':'All current reviews/structured text, including hidden/ignored files. No compressed/binary global search claim. Legacy issue reports are not converted to structured predecessors.'})
save('results/actual-base.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip(),'observed_at':utc()})
print(json.dumps({'authority_owners':len(owners),'canonical_inputs':len(paths)+1,'unchanged_governance':len(governance),'canonical_lineage_matches':len(q.stdout.splitlines())}))
