from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
import csv
import hashlib
import io
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

import yaml
from pathwaymech.schema import validate_record
from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx

O = Path('/private/tmp/pathwaymech-next-269-record-draft')
D = O / 'inputs/design'
C = O / 'inputs/taxon-label-correction'
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
checks = []
def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    if not condition:
        (O / 'results/verification-failure.json').write_text(json.dumps(checks, indent=2)+'\n')
        raise AssertionError(name)

path = O / 'draft/data/pathways/glutaryl-coa-degradation.yaml'
raw = yaml.safe_load(path.read_text())
record = validate_record(raw)
check('stable draft bytes', sha(path) == '8b6865f0585b0ec7bd046f8f63f008c969ea7013efc60b8bd04db441440a9f51')
nodes = read(D / 'results/all162-node-and-alias-dispositions.json')
selected = [n for n in nodes if n['graph_disposition'] == 'proposed_native_graph_node']
declared = [raw] + raw['participants'] + raw['reactions']
check('exact 60 native declarations', {x['id'] for x in declared} == {'MetaCyc:'+n['native_id'] for n in selected} and len(declared) == 60)
taxa = read(C / 'results/proposed-eight-taxon-declarations.json')
check('exact eight taxon declarations', raw['taxa'] == [{k:t[k] for k in ('id','label')} for t in taxa])
for n in raw['taxa'] + raw['participants'] + raw['reactions']:
    check('closed node fields '+n['id'], set(n) <= {'id','label','category','direction'})
labels = read(C / 'results/six-canonical-reaction-label-dispositions.json')
for r in labels:
    actual = next(n for n in raw['reactions'] if n['id'] == r['id'])
    check('canonical label '+r['id'], actual['label'] == r['label'])
    native_node = next(n for n in selected if 'MetaCyc:'+n['native_id'] == r['id'])
    native = ET.parse(D/native_node['source']).getroot().find('Reaction')
    directions = {'REVERSIBLE':'reversible','PHYSIOL-LEFT-TO-RIGHT':'left_to_right','PHYSIOL-RIGHT-TO-LEFT':'right_to_left'}
    check('source direction '+r['id'], actual['direction'] == directions[native.findtext('reaction-direction')])

design = read(D / 'results/proposed-native-edge-inventory.json')
edges = {e['id']:e for e in raw['mechanistic_edges']}
refs = {r['id']:r for r in raw['references']}
source_refs = {r['source_path']:r['reference_id_candidate'] for r in read(D/'results/proposed-native-reference-inventory.json')}
check('exact 80 edge IDs', set(edges) == {'native-'+e['design_key'].lower() for e in design} and len(design) == 80)
for e in design:
    out = edges['native-'+e['design_key'].lower()]
    check(e['design_key']+' exact topology', (out['subject'],out['predicate'],out['object']) == ('MetaCyc:'+e['subject_native_id'],e['predicate'],'MetaCyc:'+e['object_native_id']))
    for i,v in enumerate(e['evidence']):
        expected = {'reference_id':source_refs[v['source']], 'source_assertion':v['source_assertion'], 'source_locator':v['source_locator']}
        check(e['design_key']+' source assertion '+str(i), out['evidence'][i] == expected)
        check(e['design_key']+' original source bytes '+str(i), sha(D/v['source']) == v['source_sha256'] == refs[expected['reference_id']]['source_sha256'])
    if 'stoichiometric_coefficient' in e:
        check(e['design_key']+' exact coefficient', 'Exact native occurrence coefficient: '+str(e['stoichiometric_coefficient'])+'.' in out['description'])
    if 'native_component_coefficient' in e:
        check(e['design_key']+' exact component coefficient', 'Native complex component coefficient: '+str(e['native_component_coefficient'])+'.' in out['description'])
check('all 26 material occurrences', sum('stoichiometric_coefficient' in e for e in design) == 26)
counts = dict(Counter(e['predicate'] for e in edges.values()))
check('predicate inventory', counts == {'has_part':16,'consumes':14,'produces':12,'precedes':4,'catalyzes':21,'has_cofactor':1,'inhibits':8,'enables':4})
check('five root members only', len([e for e in edges.values() if e['subject']==raw['id'] and e['predicate']=='has_part']) == 5)
micro_reg = [e for e in design if e['predicate']=='inhibits']
activity_ids = {'MetaCyc:'+e['object_native_id'] for e in micro_reg}
check('four exact regulated activities', len(activity_ids)==4 and activity_ids <= {n['id'] for n in raw['participants'] if n['category']=='molecular_activity'})
taxon_edge = edges['native-ne001']
for t in taxa:
    check('root full taxon qualification '+t['id'], t['description'] in raw['description'])
    check('edge full taxon qualification '+t['id'], t['description'] in taxon_edge['description'])
assoc = [t['source_association_evidence'] for t in read(C/'results/all-nine-direct-pathway-taxon-dispositions.json') if t['native_id']!='TAX-9606']
check('all eight exact species evidence assertions', taxon_edge['evidence'][1:] == assoc)
for r in labels:
    check('reaction qualification on incident edge '+r['id'], any(r['description'] in e['description'] and r['id'] in (e['subject'],e['object']) for e in edges.values()))

preview = O/'preview'
assert not preview.exists()
(preview/'pathways').mkdir(parents=True)
page = _record_page(record)
(preview/'pathways/glutaryl-coa-degradation.html').write_text(page)
shutil.copytree(O/'inputs/validation-code/src/pathwaymech/assets',preview/'assets')
style = subprocess.run(['git','show','ae143113008f8c194748bae322ab80b1853a6d95:pages/style.css'],check=True,capture_output=True).stdout
(preview/'style.css').write_bytes(style)
(O/'results/preview-style-binding.json').write_text(json.dumps({'source':'git:ae143113008f8c194748bae322ab80b1853a6d95:pages/style.css','sha256':sha(preview/'style.css'),'bytes':len(style)},indent=2)+'\n')

class VisibleText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack=[]; self.text=[]; self.before=[]; self.graph_seen=False
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if attrs.get('id')=='pathway-network':self.graph_seen=True
        if tag not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:
            self.stack.append(tag)
    def handle_endtag(self,tag):
        if tag in self.stack:
            index=len(self.stack)-1-self.stack[::-1].index(tag)
            self.stack=self.stack[:index]
    def handle_data(self,data):
        if not {'script','style','details','svg'} & set(self.stack):
            self.text.append(data)
            if not self.graph_seen:self.before.append(data)

parser=VisibleText();parser.feed(page)
visible=''.join(parser.text); before=''.join(parser.before)
for t in taxa:check('no-JS taxon scope before graph '+t['id'],t['description'] in before)
hydration=(C/'results/required-visible-record-label-disclosure.txt').read_text().strip().replace('here and in the reaction description.','here and in the incident edge descriptions.')
check('no-JS exact hydration disclosure before graph',hydration in before)
check('hydration chemistry also visible in edge table', 'Pathway-selected equation:' in visible and 'No redox reaction is inferred from that name.' in visible)
svgs=re.findall(r'<svg\b[^>]*class="pathway-network-svg".*?</svg>',page,flags=re.S)
check('one native SVG',len(svgs)==1)
(preview/'pathway-network.svg').write_text(svgs[0])
svg_nodes=re.findall(r'data-node-id="([^"]+)"',svgs[0])
check('SVG all 68 declared nodes',set(svg_nodes)=={n['id'] for n in declared+raw['taxa']} and len(svg_nodes)==68)

exports=render_kgx([record]);exportdir=O/'exports';exportdir.mkdir()
for filename,contents in exports.items():(exportdir/filename).write_text(contents)
kn=list(csv.DictReader(io.StringIO(exports['nodes.tsv']),delimiter='\t'))
ke=list(csv.DictReader(io.StringIO(exports['edges.tsv']),delimiter='\t'))
check('KGX 68 nodes and 80 edges',len(kn)==68 and len(ke)==80)
check('KGX all declared identifiers', {n['id'] for n in kn}=={n['id'] for n in declared+raw['taxa']})
for e in raw['mechanistic_edges']:
    matches=[k for k in ke if k['description']==e['description']]
    check('KGX full edge description '+e['id'],len(matches)==1)
    if matches:
        ev=json.loads(matches[0]['evidence'])
        check('KGX exact evidence '+e['id'],ev==e['evidence'])
for t in taxa:check('KGX taxon qualification '+t['id'],any(t['description'] in k['description'] for k in ke))
for r in labels:check('KGX canonical reaction label '+r['id'],next(n for n in kn if n['id']==r['id'])['name']==r['label'])
(O/'results/render-export-checks.json').write_text(json.dumps({'checks':checks,'checks_count':len(checks),'all_pass':all(x['passed'] for x in checks),'record_sha256':sha(path),'counts':{'native_nodes':60,'taxa':8,'svg_nodes':len(svg_nodes),'edges':counts,'kgx_nodes':len(kn),'kgx_edges':len(ke)},'no_js_check':'ordinary text outside details/script/style/SVG includes all eight complete taxon qualifications and exact hydration warning before network','browser_qa':'not claimed; static HTML/SVG generated and programmatic fidelity checks only'},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_pass':True,'svg_nodes':len(svg_nodes),'kgx_nodes':len(kn),'kgx_edges':len(ke),'preview':str(preview)},indent=2))
