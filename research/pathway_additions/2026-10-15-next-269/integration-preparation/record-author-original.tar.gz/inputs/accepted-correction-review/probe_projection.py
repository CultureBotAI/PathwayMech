from pathlib import Path
import copy,dataclasses,hashlib,html,json
import yaml
from pathwaymech.schema import validate_record
from pathwaymech.strict import validator,TARGET_CLASS
from pathwaymech.cli import _record_page
from pathwaymech.kgx import kgx_nodes,kgx_edges

O=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
R=Path('/private/tmp/pathwaymech-next-269-native-design-independent-review')
W=Path('/private/tmp/pathwaymech-next-268-20261015')
read=lambda p:json.loads(p.read_text())
record=yaml.safe_load((R/'native-activity-contract-probe.yaml').read_text())
taxa=read(P/'results/proposed-eight-taxon-declarations.json')
reactions=read(P/'results/six-canonical-reaction-label-dispositions.json')
disclosure=(P/'results/required-visible-record-label-disclosure.txt').read_text().strip()
taxon_prose='\n\n'.join(n['description'] for n in taxa)
record['description']='Scratch projection fixture only; no whole-record authority or maintained acceptance.\n\n'+disclosure+'\n\n'+taxon_prose
record['taxa']=[{k:n[k] for k in ['id','label']} for n in taxa]
record['reactions']=[{k:n[k] for k in ['id','label','category']} for n in reactions]
record['references'].append({'id':'MetaCyc:PWY-5177','title':'MetaCyc native PWY-5177','source_version':'27.0','source_sha256':hashlib.sha256((P/'inputs/native/META-PWY-5177.xml').read_bytes()).hexdigest()})
record['mechanistic_edges'].append({'id':'projection-hydration-membership','subject':'MetaCyc:PWY-5177','predicate':'has_part','object':'MetaCyc:RXN-11667','description':disclosure+'\n\nSource pathway taxon-association scope:\n\n'+taxon_prose,'evidence':[{'reference_id':'MetaCyc:PWY-5177','source_assertion':'PWY-5177 lists RXN-11667 as a pathway member and selects its R2L hydration direction. The separate species slots are source pathway associations, not independent whole-route assay evidence.','source_locator':"/ptools-xml/Pathway[@frameid='PWY-5177']/reaction-list; reaction-layout; species"}]})
parsed=validate_record(record)
validation=validator().validate(record,TARGET_CLASS)
assert not validation.results,validation.results
negative=[]
for section,nodes in [('taxa',taxa),('reactions',reactions)]:
    bad=copy.deepcopy(record);bad[section][0]['description']=nodes[0]['description']
    rejected=validator().validate(bad,TARGET_CLASS)
    assert rejected.results
    negative.append({'section':section,'NamedNode_description_rejected':True,'results':[str(x) for x in rejected.results]})
page=_record_page(parsed)
assert page.index(html.escape(disclosure))<page.index('id="pathway-network"')
assert all(html.escape(t['description']) in page for t in taxa)
edges=[dataclasses.asdict(e) for e in kgx_edges([parsed])]
out=next(e for e in edges if e['object']=='MetaCyc:RXN-11667' and e['subject']=='MetaCyc:PWY-5177')
assert disclosure in out['description'] and all(t['description'] in out['description'] for t in taxa)
nodes=[dataclasses.asdict(n) for n in kgx_nodes([parsed])]
assert next(n for n in nodes if n['id']=='MetaCyc:RXN-11667')['category']=='biolink:MolecularActivity'
contracts=['src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','src/pathwaymech/strict.py','src/pathwaymech/cli.py','src/pathwaymech/kgx.py']
bindings=[{'path':str(W/f),'sha256':hashlib.sha256((W/f).read_bytes()).hexdigest()} for f in contracts]
result={'scope':'Structural projection demonstration only, using previously accepted 12-edge activity fixture plus one native pathway membership. Not the forthcoming complete scratch record or its authority gate.','python_and_closed_schema':'pass','negative_NamedNode_description_cases':negative,'ordinary_HTML_before_graph':True,'all_eight_taxon_scopes_visible':True,'KGX_incident_edge_retains_hydration_and_taxon_prose':True,'RXN11667_molecular_activity_category':True,'record_root_description_alone_is_not_KGX_exported':'The probe deliberately duplicates the contextual prose in an incident edge description; current KGX root nodes do not export root description. Final curation must retain this projection rather than relying on root text alone.','contract_bindings':bindings}
(O/'projection-probe.yaml').write_text(yaml.safe_dump(record,sort_keys=False))
(O/'projection-probe.html').write_text(page)
(O/'projection-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
