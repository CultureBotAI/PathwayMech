from pathlib import Path
import hashlib,json,sqlite3,xml.etree.ElementTree as E

O=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
D=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
R=Path('/private/tmp/pathwaymech-next-269-native-design-independent-review')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
checks=[]
def check(name,value):
    checks.append({'check':name,'passed':bool(value)})
    assert value,name
def read(p):return json.loads(p.read_text())
packets=[]
for root,digest in [(P,'7c147a476456cebca82d0cae7f7079528355fe438a608af4cac3514b4e5574d4'),(D,'566059628d3208928ea0a6949d81c325f04e608e2cf29653f81063e1e02ad603'),(R,'4cb706f4bb7507522b061ddd07db4798dbae6a36565a6fa1fd937cd01e2f0651')]:
    check('manifest '+root.name,sha(root/'artifact-manifest.json')==digest)
    m=read(root/'artifact-manifest.json')
    for r in m['files']:check('file '+root.name+'/'+r['path'],sha(root/r['path'])==r['sha256'] and (root/r['path']).stat().st_size==r['bytes'])
    physical={str(x.relative_to(root)) for x in root.rglob('*') if x.is_file()}
    check('complete physical '+root.name,physical=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'})
    packets.append({'root':str(root),'manifest_sha256':digest,'listed':len(m['files']),'physical':len(physical),'all_exact':True})
copies=read(P/'inputs/copied-input-bindings.json')
for r in copies:
    if r['source'].startswith('git:'):
        expected=(R/'identifiers.published268.py').read_bytes()
    else:expected=Path(r['source']).read_bytes()
    check('copied input '+r['path'],(P/r['path']).read_bytes()==expected and sha(P/r['path'])==r['sha256'])
pw=E.parse(P/'inputs/native/META-PWY-5177.xml').getroot().find("Pathway[@frameid='PWY-5177']")
native=[x[0].get('frameid') for x in pw.findall('species')]
dispositions=read(P/'results/all-nine-direct-pathway-taxon-dispositions.json')
check('all9 direct species exact order',[r['native_id'] for r in dispositions]==native and len(native)==9)
mapping={'TAX-9606':'NCBITaxon:9606','TAX-303':'NCBITaxon:303','TAX-1076':'NCBITaxon:1076','TAX-316277':'NCBITaxon:316277','TAX-43774':'NCBITaxon:43774','TAX-43775':'NCBITaxon:43775','TAX-59405':'NCBITaxon:59405','ORG-5962':'NCBITaxon:44139','ORG-5970':'NCBITaxon:59406'}
cache=read(P/'inputs/taxonomy-cache-before.json');C=Path(cache['path']);stat_before=C.stat()
snapshot=read(P/'inputs/ontology-snapshot.json');pin=snapshot['sources']['ncbitaxon-2026-07-12']
check('taxonomy pin unchanged',pin==cache['expected_pin'] and pin['sha256']==read(P/'results/taxonomy-cache-after.json')['sha256'])
conn=sqlite3.connect(C.as_uri()+'?mode=ro&immutable=1',uri=True);conn.row_factory=sqlite3.Row
saved=read(P/'results/nine-taxonomy-statement-sets.json');current={}
for ident in mapping.values():
    rows=[dict(x) for x in conn.execute('SELECT * FROM statements WHERE subject=? ORDER BY predicate,object,value',(ident,))]
    check('issuing rows '+ident,rows==saved[ident]);current[ident]=rows
metadata=[dict(x) for x in conn.execute("SELECT * FROM statements WHERE predicate IN ('owl:versionIRI','owl:versionInfo','dcterms:license')")]
check('release metadata',metadata==read(P/'results/taxonomy-release-metadata.json'))
declarations=read(P/'results/proposed-eight-taxon-declarations.json');refs=read(P/'results/proposed-eight-taxon-reference-metadata.json')
check('eight microbial declarations',len(declarations)==8 and {r['id'] for r in declarations}==set(mapping.values())-{'NCBITaxon:9606'})
check('eight reference identities',{r['id'] for r in refs}=={r['id'] for r in declarations})
for n,r in enumerate(dispositions,1):
    ident=mapping[r['native_id']];rows=current[ident]
    label=[x['value'] for x in rows if x['predicate']=='rdfs:label']
    rank=[x['object'] for x in rows if x['predicate']=='obo:ncbitaxon#has_rank']
    parent=[x['object'] for x in rows if x['predicate']=='rdfs:subClassOf']
    check('taxon label/rank/parent '+ident,label==[r['issuing_label']] and rank==[r['issuing_rank']] and parent==[r['issuing_parent']])
    obj=E.parse(P/'inputs/native'/f"META-{r['native_id']}.xml").getroot().find('Organism')
    check('native label/rank '+ident,obj.findtext('common-name')==r['native_label'] and obj.findtext('rank')==r['native_rank'])
    loc=f"/ptools-xml/Pathway[@frameid='PWY-5177']/species[{n}]/Organism[@frameid='{r['native_id']}']"
    check('direct occurrence locator '+ident,r['direct_pathway_occurrence']['locator']==loc and r['source_association_evidence']['source_locator']==loc)
    if r['native_id'].startswith('TAX-'):
        x=[d.findtext('dblink-oid') for d in obj.findall('dblink') if d.findtext('dblink-db')=='NCBI-TAXONOMY-DB']
        check('exact native issuer xref '+ident,x==[ident.split(':')[1]])
    if ident=='NCBITaxon:9606':check('human excluded','exclude_from_microbial_record' in r['disposition'])
    else:
        node=next(d for d in declarations if d['id']==ident)
        check('declaration label '+ident,node['label']==label[0])
        check('source association limit '+ident,'not independent experimental demonstration' in node['description'])
    check('existing taxonomy owner '+ident,r['current_snapshot_present']==(ident in snapshot['terms']))
new=read(P/'results/three-additive-pinned-ontology-terms.json')
check('only3 additive IDs',set(new)=={'NCBITaxon:316277','NCBITaxon:43774','NCBITaxon:43775'})
for ident,t in new.items():
    rows=current[ident]
    expected={'label':next(x['value'] for x in rows if x['predicate']=='rdfs:label'),'synonyms':sorted({x['value'] for x in rows if x['predicate']=='oio:hasExactSynonym' and x['value']!=t['label']}),'source':'ncbitaxon-2026-07-12'}
    check('additive exact issuing projection '+ident,t==expected and ident not in snapshot['terms'])
for ident in ['44139','59406']:
    obj=E.parse(P/'inputs/accepted-issuer-originals'/f'NCBI-taxonomy-{ident}.xml').getroot().find('Taxon')
    check('accepted issuing TaxID '+ident,obj.findtext('TaxId')==ident)
    if ident=='44139':check('K172 issuer rank retained',obj.findtext('Rank')=='strain' and 'species' in next(r for r in dispositions if r['issuing_id']=='NCBITaxon:44139')['conflicts'][0])
    else:
        text=E.tostring(obj,encoding='unicode')
        check('KB740 issuing type material retained','KB 740' in text and 'DSM 6898' in text and obj.findtext('Rank')=='species')
        check('KB740 no exact strain claim','no invented' not in next(d for d in declarations if d['id']=='NCBITaxon:59406')['description'] and 'at species scope' in next(d for d in declarations if d['id']=='NCBITaxon:59406')['description'])
labels=read(P/'results/six-canonical-reaction-label-dispositions.json')
expected_rxns={e['object_native_id'] for e in read(D/'results/proposed-native-edge-inventory.json') if e['predicate']=='has_part' and e['subject_native_id']=='PWY-5177'}|{'GLUTARYL-COA-DEHYDROGENASE-RXN'}
check('six exact reaction IDs',{r['id'].split(':',1)[1] for r in labels}==expected_rxns)
for r in labels:
    obj=E.parse(P/r['source_original']).getroot().find('Reaction');canonical=obj.findtext('common-name') or obj.get('frameid')
    check('canonical label/category '+r['id'],r['label']==canonical and r['category']=='molecular_activity' and sha(P/r['source_original'])==r['source_sha256'])
disclosure=(P/'results/required-visible-record-label-disclosure.txt').read_text()
check('explicit hydration/name conflict prose',all(s in disclosure for s in ['crotonyl-CoA + water -> (S)-3-hydroxybutanoyl-CoA','dehydrogenase','conflicts','No redox reaction']))
assessment=(P/'ASSESSMENT.md').read_text();correction=read(P/'results/N269-D02-correction-disposition.json')
check('ordinary before graph and KGX requirement','before the graph' in assessment and 'no-JavaScript' in assessment and 'KGX' in correction['record_QA_required'])
check('canonical no policy widening',correction['no_policy_change'] and correction['no_authority_rename'] and correction['no_new_nested_step'])
summary=read(P/'results/taxon-completion-summary.json')
check('source graph remains60/80',summary['native_graph_nodes_unchanged']==60 and summary['edges_unchanged']==80 and summary['total_declarations_with_taxa']==68)
check('prior reviewed source graph exact',sha(D/'results/proposed-native-edge-inventory.json')==next(x['sha256'] for x in read(D/'artifact-manifest.json')['files'] if x['path']=='results/proposed-native-edge-inventory.json'))
conn.close()
digest=sha(C)
check('complete pinned taxonomy cache hash',digest==pin['sha256'] and C.stat().st_size==14115225600 and C.stat().st_mtime_ns==stat_before.st_mtime_ns)
result={'checks':len(checks),'all_passed':all(x['passed'] for x in checks),'packet_bindings':packets,'copied_inputs_exact':len(copies),'direct_native_species':9,'microbial_declarations':8,'human_exclusions':1,'canonical_reactions':6,'taxonomy_cache':{'path':str(C),'bytes':C.stat().st_size,'sha256':digest,'read_only_query':True,'mtime_unchanged':True},'additive_taxa':new,'native_graph_nodes':60,'edges':80,'total_declarations':68,'scope':'Bounded D01/D02 correction acceptance for scratch YAML readiness, not maintained authority/record/merge acceptance. Issues623/624 remain open.','locator_precision_note':'D02 source_locators says check_record_identifiers; actual published function is identifier_errors. Exact file hash and line723-733 identify the intended branch; documentation typo is not a semantic blocker.'}
(O/'review-results.json').write_text(json.dumps({'summary':result,'checks':checks},indent=2)+'\n')
(O/'independent-taxonomy-rows.json').write_text(json.dumps(current,indent=2)+'\n')
print(json.dumps(result,indent=2))
