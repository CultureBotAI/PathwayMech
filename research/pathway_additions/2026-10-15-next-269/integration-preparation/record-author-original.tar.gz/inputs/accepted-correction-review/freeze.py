from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
O=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'artifact-manifest.json')=='7c147a476456cebca82d0cae7f7079528355fe438a608af4cac3514b4e5574d4'
m=json.loads((P/'artifact-manifest.json').read_text())
for r in m['files']:assert sha(P/r['path'])==r['sha256'] and (P/r['path']).stat().st_size==r['bytes']
assert {str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
assert not (O/'artifact-manifest.json').exists() and not (O/'freeze-proof.json').exists()
rows=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file()]
(O/'artifact-manifest.json').write_text(json.dumps({'owner':str(O),'scope':'Bounded D01/D02 correction acceptance for scratch YAML readiness with explicit closed-schema prose projection; issues623/624 remain open','files':rows},indent=2)+'\n')
proof={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'listed_files':len(rows),'physical_files':len(rows)+2,'listed_bytes':sum(r['bytes'] for r in rows),'HANDOFF_sha256':sha(O/'HANDOFF.md'),'REVIEW_sha256':sha(O/'REVIEW.md'),'author_packet_end_recheck_exact':True,'all_local_jobs_terminal':True}
(O/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({**proof,'freeze_sha256':sha(O/'freeze-proof.json')},indent=2))
