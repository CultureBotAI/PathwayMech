import{A as s}from"./constants-BFjk2gNH.js";const u={"AdvancedSearchAutocompleteQuery:e5c0b838fb365a72e35daf65d112e60122f0801e6daf00375045272075cf352f":`query AdvancedSearchAutocomplete($subsite: Subsite, $fieldId: String!, $input: String!) {
  advancedSearchAutocomplete(subsite: $subsite, fieldId: $fieldId, input: $input) {
    label
    value
  }
}`,"AdvancedSearchFreeTextAutocompleteQuery:bc482ae37477a1e8ec49c14989697bf165baaf19f2b5d9dca4b6a0c57098d270":`query AdvancedSearchFreeTextAutocomplete($subsite: Subsite, $fieldId: String!, $input: String!) {
  advancedSearchFreeTextAutocomplete(
    subsite: $subsite
    fieldId: $fieldId
    input: $input
  )
}`,"GetAboutPageQuery:3b7334abc5192c9852ab8e695a9ba82e48c49bd3b81d3f09050e8e833cbcef5a":`query GetAboutPage($subsite: Subsite, $input: AboutPageInput) {
  aboutPage(subsite: $subsite, input: $input) {
    ... on AboutPage {
      metaTags {
        ... on MetaTag {
          name
          property
          content
        }
      }
      publicationTypeAvailable
      publicationTypeSelected
      timePeriodAvailable
      timePeriodMaxRange
      timePeriodSelected
      inputConfigSignature
      statsBoxes {
        subsite
        title
        substitle
        value
        value2
        statsBars {
          label
          value
          percent
          preselectedFacets {
            facetId
            values {
              operator
              value
            }
          }
          targetSubsite
          info
        }
      }
      statsPlot {
        xLabel
        yLabel
        yValues
        legend
        subsitePlot {
          subsite
          label
          plotPiles {
            cells {
              label
              value
              percent
              preselectedFacets {
                facetId
                values {
                  operator
                  value
                }
              }
              targetSubsite
            }
          }
        }
      }
      statsTableOne {
        ... on StatsTable {
          columnsHead {
            cells {
              label
              span
              alignment
              lineThickness
            }
          }
          rows {
            label
            level
            cells {
              value
              percent
              preselectedFacets {
                facetId
                values {
                  operator
                  value
                }
              }
              targetSubsite
            }
          }
        }
      }
      statsTableTwo {
        ... on StatsTable {
          columnsHead {
            cells {
              label
              span
              alignment
              lineThickness
            }
          }
          rows {
            label
            level
            cells {
              value
              percent
              preselectedFacets {
                facetId
                values {
                  operator
                  value
                }
              }
              targetSubsite
            }
          }
        }
      }
    }
  }
}`,"GetAdvancedSearchFormQuery:4e12625e87862ef4aaf1df79e57e2e6d0b8be1eab1bb433f1dbd6cb8cfddbbc3":`query GetAdvancedSearchForm($subsite: Subsite) {
  advancedSearchForm(subsite: $subsite) {
    nodes {
      ... on AdvancedSearchNode {
        __typename
        ... on MultiFieldGroup {
          fields {
            ... on AdvancedSearchField {
              fieldId
              label
              kind
              options {
                ... on AdvancedSearchOption {
                  label
                  value
                  operator
                }
              }
            }
          }
        }
        ... on SingleField {
          field {
            ... on AdvancedSearchField {
              fieldId
              label
              kind
              options {
                ... on AdvancedSearchOption {
                  label
                  value
                  operator
                }
              }
            }
          }
        }
        ... on SingleFieldGroup {
          field {
            ... on AdvancedSearchField {
              fieldId
              label
              kind
              options {
                ... on AdvancedSearchOption {
                  label
                  value
                  operator
                }
              }
            }
          }
        }
      }
    }
  }
}`,"GetAuthorListQuery:fe875fde3aa6c6fc5cbdc60bf034fd3ccd0ee5a5c8ae50038aeb3e777a139d96":`query GetAuthorList($subsite: Subsite!, $input: AuthorListInput) {
  authorList(subsite: $subsite, input: $input) {
    ... on AuthorList {
      metaTags {
        ... on MetaTag {
          name
          property
          content
        }
      }
      letterSelected
      query
      authors {
        ... on Author {
          lastName
          firstName
          id
          fullName
          affiliations {
            ... on Affiliation {
              unitId
              unitName
              unitUrl
              section
              department
              departmentUrl
              division
            }
          }
          orcid
          authorUrl
        }
      }
    }
  }
}`,"GetCitationQuery:48ff0e0419aff5f29da8a6cf3f23dc17f1f38b2f697a8a1652a9b70790ec3e85":`query GetCitation($subsite: Subsite!, $pid: ID!, $style: String) {
  citation(subsite: $subsite, pid: $pid, style: $style) {
    ... on Citation {
      pid
      citation
      stylesAvailable
      styleSelected
    }
  }
}`,"GetCitationCountQuery:4e4d653e3395749199ab5681daafa92049ff3ef6a7067e1a1efcd70c270d07e7":`query GetCitationCount($subsite: Subsite!, $pid: ID!, $source: CitationSource!) {
  citationCount(subsite: $subsite, pid: $pid, source: $source)
}`,"GetFooterQuery:1d21e55a6384496041025a9319916ee0fcffcd6a1d53855ebfcf7dac538bb638":`query GetFooter($subsite: Subsite) {
  footer(subsite: $subsite) {
    ... on Footer {
      column1 {
        label
        content
      }
      column2 {
        label
        content
      }
      column3 {
        label
        items {
          ... on NavigationItem {
            id
            parent
            title
            url
          }
        }
      }
      column4 {
        label
        items {
          ... on NavigationItem {
            id
            parent
            title
            url
          }
        }
      }
    }
  }
}`,"GetFormQuery:3680b9d664662cb41628b9a4542c98ca46a0442964f602694359f0d4ca012a0e":`query GetForm($subsite: Subsite!, $formId: FormId!, $args: JSONString) {
  formGet(subsite: $subsite, formId: $formId, args: $args) {
    ... on FormDisplay {
      title
      submitButtonLabel
      nodes {
        ... on FormNode {
          __typename
          ... on TextInput {
            ... on TextInput {
              id
              label
              tooltipText
              isRequired
              kind
              maxLength
            }
          }
          ... on FileUpload {
            ... on FileUpload {
              id
              label
              tooltipText
              isRequired
              accept
              maxFileSizeBytes
            }
          }
          ... on TwoLevelMultiSelect {
            ... on TwoLevelMultiSelect {
              id
              label
              tooltipText
              isRequired
              options {
                label
                value
                helpText
                options {
                  label
                  value
                }
              }
            }
          }
          ... on FormMarkup {
            ... on FormMarkup {
              id
              label
              content
            }
          }
          ... on FormFieldset {
            ... on FormFieldset {
              id
              label
              collapsible
              collapsed
              children {
                ... on FormLeafNode {
                  __typename
                  ... on TextInput {
                    ... on TextInput {
                      id
                      label
                      tooltipText
                      isRequired
                      kind
                      maxLength
                    }
                  }
                  ... on FileUpload {
                    ... on FileUpload {
                      id
                      label
                      tooltipText
                      isRequired
                      accept
                      maxFileSizeBytes
                    }
                  }
                  ... on TwoLevelMultiSelect {
                    ... on TwoLevelMultiSelect {
                      id
                      label
                      tooltipText
                      isRequired
                      options {
                        label
                        value
                        helpText
                        options {
                          label
                          value
                        }
                      }
                    }
                  }
                  ... on FormMarkup {
                    ... on FormMarkup {
                      id
                      label
                      content
                    }
                  }
                  ... on FormValue {
                    ... on FormValue {
                      id
                      value
                      __typename
                    }
                  }
                }
              }
            }
          }
          ... on FormValue {
            ... on FormValue {
              id
              value
              __typename
            }
          }
        }
      }
    }
  }
}`,"GetHomepageQuery:9729f8a7d5574c5e5120c462d5748760ef01f6d83a19fe4bb6dec755fe2c5cf1":`query GetHomepage {
  homepage {
    ... on Homepage {
      hero {
        ... on Hero {
          leadText
          statistics {
            value
            label
            preselectedFacets {
              facetId
              values {
                operator
                value
              }
            }
          }
        }
      }
      overviewTitle
      overviewDescription
      aboutUs {
        title
        description
        cta {
          ... on CTA {
            label
            url
          }
        }
      }
      openAccessTitle
      openAccessDescription
    }
  }
}`,"GetItemQuery:37dfe86df4698584c00be24f6d46db898c6d4ec878d6e591555a12532755e2b5":`query GetItem($subsite: Subsite!, $pid: ID!) {
  item(subsite: $subsite, pid: $pid) {
    ... on Item {
      __typename
      info {
        metaTags {
          ... on MetaTag {
            name
            property
            content
          }
        }
        pid
        genre
        subsite
        url
        title
        abstract
        laySummaries {
          content {
            lang
            summary
          }
          linkLabel
          sectionLabel
          disclaimer
          authorApproved
        }
        detailFields {
          label
          field
        }
        downloads {
          ... on DownloadMetadata {
            url
            version
            availability
            access
            embargoDate
            license
            licenseUrl
          }
        }
        dataPackages {
          doi
          label
        }
        collections {
          id
          label
        }
        links {
          label
          url
        }
        additionalInfo
        duoProposalId
        lib4riNotes
        source
        stats {
          views
          downloads
        }
      }
      ... on BachelorThesis {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        supervisors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        keywords
        degreeGrantingInstitution
        publisher
        publicationDate
        pageCount
        publicationPlace
      }
      ... on Book {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        seriesTitle
        infoBook {
          ... on BookInfo {
            edition
            seriesVolume
            seriesIssue
            bookVolume
          }
        }
        keywords
        publisher
        publicationPlace
        pageCount
        publicationDate
      }
      ... on BookChapter {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        seriesTitle
        infoBook {
          ... on BookInfo {
            edition
            seriesVolume
            seriesIssue
            bookVolume
          }
        }
        bookTitle
        keywords
        publisher
        publicationPlace
        startPage
        endPage
        publicationDate
        peerReview
      }
      ... on Brochure {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        seriesTitle
        infoBook {
          ... on BookInfo {
            edition
            seriesVolume
            seriesIssue
            bookVolume
          }
        }
        keywords
        publisher
        publicationPlace
        pageCount
        publicationDate
      }
      ... on ConferencePaper {
        __typename
        infoConf {
          ... on ConfInfo {
            authors {
              ... on Author {
                lastName
                firstName
                id
                fullName
                affiliations {
                  ... on Affiliation {
                    unitId
                    unitName
                    unitUrl
                    section
                    department
                    departmentUrl
                    division
                  }
                }
                orcid
                authorUrl
              }
            }
            summaryAuthors
            origAuthorList
            conferenceProceedings
            seriesTitle
            seriesVolume
            seriesIssue
            editors {
              ... on Author {
                lastName
                firstName
                id
                fullName
                affiliations {
                  ... on Affiliation {
                    unitId
                    unitName
                    unitUrl
                    section
                    department
                    departmentUrl
                    division
                  }
                }
                orcid
                authorUrl
              }
            }
            bookVolume
            conference
            conferenceDate
            conferencePlace
            startPage
            endPage
            publicationDate
            publicationPlace
            publisher
            peerReview
            keywords
            fundingInfo {
              ... on Funding {
                funderName
                fundingStream
                awardTitle
                awardNumber
              }
            }
            facilityInfo {
              ... on Facility {
                facility
                beamline
              }
            }
          }
        }
      }
      ... on ConferencePoster {
        __typename
        infoConf {
          ... on ConfInfo {
            authors {
              ... on Author {
                lastName
                firstName
                id
                fullName
                affiliations {
                  ... on Affiliation {
                    unitId
                    unitName
                    unitUrl
                    section
                    department
                    departmentUrl
                    division
                  }
                }
                orcid
                authorUrl
              }
            }
            summaryAuthors
            origAuthorList
            conferenceProceedings
            seriesTitle
            seriesVolume
            seriesIssue
            editors {
              ... on Author {
                lastName
                firstName
                id
                fullName
                affiliations {
                  ... on Affiliation {
                    unitId
                    unitName
                    unitUrl
                    section
                    department
                    departmentUrl
                    division
                  }
                }
                orcid
                authorUrl
              }
            }
            bookVolume
            conference
            conferenceDate
            conferencePlace
            startPage
            endPage
            publicationDate
            publicationPlace
            publisher
            peerReview
            keywords
            fundingInfo {
              ... on Funding {
                funderName
                fundingStream
                awardTitle
                awardNumber
              }
            }
            facilityInfo {
              ... on Facility {
                facility
                beamline
              }
            }
          }
        }
      }
      ... on ConferenceProceedings {
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        keywords
        publisher
        pageCount
        publicationDate
        conference
        conferenceDate
        conferencePlace
        seriesVolume
        seriesTitle
      }
      ... on Dissertation {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        supervisors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        keywords
        degreeGrantingInstitution
        publisher
        publicationPlace
        pageCount
        publicationDate
      }
      ... on EditedBook {
        summaryAuthors
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        infoBook {
          ... on BookInfo {
            edition
            seriesVolume
            seriesIssue
            bookVolume
          }
        }
        seriesTitle
        keywords
        publisher
        publicationPlace
        pageCount
        publicationDate
      }
      ... on JournalArticle {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        journal {
          ... on Journal {
            title
            id
          }
        }
        keywords
        startPage
        endPage
        journalVolume
        journalIssue
        publicationDate
        peerReview
      }
      ... on JournalIssue {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        journal {
          ... on Journal {
            title
            id
          }
        }
        keywords
        journalVolume
        journalIssue
        pageCount
        publicationDate
        peerReview
      }
      ... on MagazineArticle {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        issue
        peerReview
      }
      ... on MagazineIssue {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        editors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        journal {
          ... on Journal {
            title
            id
          }
        }
        keywords
        journalVolume
        journalIssue
        pageCount
        publicationDate
        peerReview
      }
      ... on MasterThesis {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        supervisors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        keywords
        degreeGrantingInstitution
        pageCount
        publicationPlace
        publicationDate
        publisher
      }
      ... on NewspaperArticle {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        issue
        peerReview
      }
      ... on Report {
        authors {
          ... on Author {
            lastName
            firstName
            id
            fullName
            affiliations {
              ... on Affiliation {
                unitId
                unitName
                unitUrl
                section
                department
                departmentUrl
                division
              }
            }
            orcid
            authorUrl
          }
        }
        summaryAuthors
        origAuthorList
        facilityInfo {
          ... on Facility {
            facility
            beamline
          }
        }
        fundingInfo {
          ... on Funding {
            funderName
            fundingStream
            awardTitle
            awardNumber
          }
        }
        keywords
        sponsor
        reportNumber
        seriesTitle
        publisher
        startPage
        endPage
        publicationDate
        publicationPlace
        pageCount
      }
    }
  }
}`,"GetMainNavigationQuery:887a6eb414288e8fa229a5f0563b46b13d8356fa790ad312aaa6d23d3e122363":`query GetMainNavigation($subsite: Subsite) {
  mainNavigation(subsite: $subsite) {
    ... on MainNavigation {
      itemsLeft {
        ... on NavigationItem {
          id
          parent
          title
          url
        }
      }
      itemsRight {
        ... on NavigationItem {
          id
          parent
          title
          url
        }
      }
      cta {
        ... on CTA {
          label
          url
        }
      }
      bannerMessage
    }
  }
}`,"GetStaticPageQuery:ccf16988437cbf5cfa7d2e2533dbb933da275595c04ec4fdd84cb8ab1a52efee":`query GetStaticPage($pageId: StaticPageId!, $subsite: Subsite) {
  staticPage(pageId: $pageId, subsite: $subsite) {
    ... on StaticPage {
      metaTags {
        ... on MetaTag {
          name
          property
          content
        }
      }
      title
      content
    }
  }
}`,"GetSubsiteHomepageQuery:68760baade32364e068d99e0b9535a8f0389735cfecf78ae957007a852a53760":`query GetSubsiteHomepage($subsite: Subsite!) {
  subsiteHomepage(subsite: $subsite) {
    ... on SubsiteHomepage {
      hero {
        ... on Hero {
          leadText
          statistics {
            value
            label
            preselectedFacets {
              facetId
              values {
                operator
                value
              }
            }
          }
        }
      }
      aboutUs {
        title
        description
        primaryCTA {
          ... on CTA {
            label
            url
          }
        }
        secondaryCTA {
          ... on CTA {
            label
            url
          }
        }
      }
    }
  }
}`,"GetSubsiteNavigationQuery:08fcee98b7941b043151580522cad62baaa52469231367df2422b050ba57340e":`query GetSubsiteNavigation($subsite: Subsite!) {
  subsiteNavigation(subsite: $subsite) {
    ... on SubsiteNavigation {
      items {
        ... on NavigationItem {
          id
          parent
          title
          url
        }
      }
    }
  }
}`,"SearchQuery:874cd139b189829a8b9268786aec0d9155abc2aff88a5e063a298a934e2caae0":`query Search($subsite: Subsite, $input: SearchInput!) {
  search(subsite: $subsite, input: $input) {
    total
    limit
    items {
      pid
      subsite
      citation
      downloads {
        ... on DownloadMetadata {
          url
          version
          availability
          access
          embargoDate
          license
          licenseUrl
        }
      }
    }
    facets {
      facetId
      label
      values {
        label
        value
        count
        isActive
        operator
      }
      facetType
    }
    sortOrder
    sortOptions {
      sortId
      label
      isActive
    }
    exportOptions {
      types {
        id
        label
        styles {
          id
          label
        }
      }
    }
  }
}`,"SearchExportMutation:8d6bde6b1a0ce393bcf459cb76de7da0b8dc6979e812fd2a71d842e649efa646":`mutation SearchExport($subsite: Subsite, $searchInput: SearchInput!, $exportInput: SearchExportInput!) {
  searchExport(
    subsite: $subsite
    searchInput: $searchInput
    exportInput: $exportInput
  ) {
    success
    message
  }
}`,"SubmitFormMutation:45ce7db644ad0090a96000fdc5f62ee3fd7f51d60b3b6e9b3608e3ee7b8b4336":`mutation SubmitForm($subsite: Subsite!, $formId: FormId!, $input: FormSubmissionInput!) {
  formSubmit(subsite: $subsite, formId: $formId, input: $input) {
    success
    message
  }
}`};async function c(e,t){const i=new URL(s),{data:a,errors:n}=await(await fetch(i,{method:"POST",body:JSON.stringify({query:u[e],variables:t}),headers:{"Content-Type":"application/json"}})).json();if(n){console.error("Errors in GraphQL response:");for(const o of n){const{message:r,...l}=o;console.error(r,l)}throw new Error("Errors in GraphQL response")}return a}export{c as a};
