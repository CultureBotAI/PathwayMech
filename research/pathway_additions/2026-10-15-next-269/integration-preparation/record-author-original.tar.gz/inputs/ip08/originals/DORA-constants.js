const o="https://apollo-prod.lib4ri.ch",a=o,L=`${a}/upload`,s=`${a}/api/altcha/challenge`;export{a as A,s as C,L as U};
