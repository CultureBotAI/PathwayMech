from pathlib import Path
from datetime import datetime,timezone
import urllib.request,urllib.error,hashlib,json,sys,concurrent.futures
P=Path(__file__).resolve().parents[1]
batch=sys.argv[1]
requests=json.loads((P/'inputs'/('requests-'+batch+'.json')).read_text())
def fetch(x):
 start=datetime.now(timezone.utc).isoformat(); row={'requested_url':x['url'],'name':x['name'],'started_utc':start,'purpose':x['purpose']}
 try:
  headers={'User-Agent':'Mozilla/5.0 (compatible; scientific-source-review)'}
  data=None
  if 'json_body' in x:
   data=json.dumps(x['json_body']).encode();headers['Content-Type']='application/json'
   row['json_body']=x['json_body']
  req=urllib.request.Request(x['url'],data=data,headers=headers)
  try: response=urllib.request.urlopen(req,timeout=40)
  except urllib.error.HTTPError as e: response=e
  with response:
   data=response.read();row.update(status=response.status,final_url=response.geturl(),headers=dict(response.headers.items()))
  dest=P/'originals'/x['name'];assert not dest.exists();dest.write_bytes(data)
  row.update(path=str(dest.relative_to(P)),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),magic_hex=data[:12].hex())
 except Exception as e: row.update(error=type(e).__name__+': '+str(e))
 row['completed_utc']=datetime.now(timezone.utc).isoformat()
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: rows=list(pool.map(fetch,requests))
dest=P/'results'/('acquisition-'+batch+'.json');assert not dest.exists();dest.write_text(json.dumps(rows,indent=2)+'\n')
for row in rows: print(json.dumps({k:row[k] for k in ('name','status','bytes','final_url','error') if k in row}))
