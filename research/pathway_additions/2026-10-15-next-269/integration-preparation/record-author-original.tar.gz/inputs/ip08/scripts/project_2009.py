from pathlib import Path
from html.parser import HTMLParser
import hashlib,json
P=Path(__file__).resolve().parents[1]
class Node:
 def __init__(self,tag,attrs=None): self.tag=tag;self.attrs=dict(attrs or []);self.children=[];self.parent=None
 def text(self): return ''.join(x if isinstance(x,str) else x.text() for x in self.children)
class Parser(HTMLParser):
 def __init__(self): super().__init__();self.root=Node('root');self.stack=[self.root];self.nodes=[]
 def handle_starttag(self,t,a):
  n=Node(t,a);n.parent=self.stack[-1];self.stack[-1].children.append(n);self.nodes.append(n)
  if t not in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}: self.stack.append(n)
 def handle_endtag(self,t):
  for i in range(len(self.stack)-1,0,-1):
   if self.stack[i].tag==t: self.stack=self.stack[:i];break
 def handle_data(self,d): self.stack[-1].children.append(d)
source=P/'inputs/PMC2698508.html';parser=Parser();parser.feed(source.read_text())
rows=[];heading=None
for n in parser.nodes:
 if n.tag not in {'h2','h3','h4','p','table'}:continue
 text=' '.join(n.text().split())
 if n.tag in {'h2','h3','h4'}:heading=text
 ancestors=[];parent=n.parent
 while parent is not None:
  if parent.attrs.get('id'):ancestors.append({'tag':parent.tag,'id':parent.attrs['id']})
  parent=parent.parent
 rows.append({'tag':n.tag,'id':n.attrs.get('id'),'ancestor_ids':ancestors,'preceding_heading':heading,'text_sha256':hashlib.sha256(text.encode()).hexdigest(),'text':text})
selected=[(i,r) for i,r in enumerate(rows) if any(s in r['text'].lower() for s in ['ferrocenium','ferricenium','11 ±','52 ±','his6','his tag','gdhdes','protein concentration','michaelis','km value','glutaconyl-coa to'])]
out={'source':str(source.relative_to(P)),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'all_projected_blocks':rows,'selected_blocks':[dict(index=i,**r) for i,r in selected],'scope':'Fresh full HTML parsing; targeted methods/results/kinetics/construct reading. No new figure visual inspection or whole-paper independent acceptance.'}
(P/'reading/2009-blocks.json').write_text(json.dumps(out,indent=2)+'\n')
for i,r in selected: print(f"[{i} {r['tag']} id={r['id']}] {r['text']}\n")
