from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,collections,xml.etree.ElementTree as E

P=Path(__file__).resolve().parents[1]
I=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
N=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def binding(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not (P/'artifact-manifest.json').exists() and not (P/'freeze-proof.json').exists()

# Selected reused originals and their complete authentic acquisition receipts.
reused=[]
for root,rel,dest in [(N,'receipts/context.json','2009-original-context-receipts.json'),(N,'artifact-manifest.json','initial-manifest.json'),(I,'receipts/first-jobs.json','issuer-first-jobs.json'),(I,'receipts/first-retry-jobs.json','issuer-first-retry-jobs.json')]:
 source=root/rel;manifest=json.loads((root/'artifact-manifest.json').read_text())
 if rel!='artifact-manifest.json':
  expected=next(x for x in manifest['files'] if x['path']==rel)
  assert sha(source)==expected['sha256'] and source.stat().st_size==expected['bytes']
 out=P/'inputs'/dest;assert not out.exists();shutil.copy2(source,out)
 reused.append({'source':binding(source),'copy':str(out.relative_to(P)),'copy_sha256':sha(out)})
for source,copy,expected in [(I/'originals/UniProt-C3UVB0.json',P/'inputs/UniProt-C3UVB0.json','ef408bbf57a79099e8d89905ee342b6639b8a1e35ddfff717fdd739495488ecc'),(N/'originals/PMC2698508.html',P/'inputs/PMC2698508.html','e0583c654b603e47848c1f97405022cce2e8bb0540afa84926472570eabfd70f')]:
 assert sha(source)==sha(copy)==expected
 reused.append({'source':binding(source),'copy':str(copy.relative_to(P)),'copy_sha256':sha(copy)})
dump(P/'inputs/reused-source-bindings.json',reused)
reader=Path('/private/tmp/pathwaymech-next-268-primary/read_pdf')
assert sha(reader)=='b7b275f6edbc5a01f5a4c363683d0bdb89dada70e83c52f3d2017f465f59e90d'
reader_source=reader.with_suffix('.swift');shutil.copy2(reader_source,P/'inputs/read_pdf.swift')
dump(P/'inputs/reader-source-binding.json',{'binary':binding(reader),'source':binding(reader_source),'copied_source_sha256':sha(P/'inputs/read_pdf.swift'),'unchanged':True})

article=E.parse(P/'originals/PubMed-20486657.xml').getroot()
assert article.findtext('.//PMID')=='20486657'
assert any(x.text=='10.1021/bi100317m' and x.get('IdType')=='doi' for x in article.findall('.//ArticleId'))
up=json.loads((P/'inputs/UniProt-C3UVB0.json').read_text())
reference=next(x for x in up['references'] if x['citation']['id']=='20486657')
kinetics=next(x for x in up['comments'] if x['commentType']=='BIOPHYSICOCHEMICAL PROPERTIES')['kineticParameters']
assert 'evidences' not in json.dumps(kinetics)
fg=json.loads((P/'originals/Figshare-2757664.json').read_text());assert fg['resource_doi']=='10.1021/bi100317m' and len(fg['files'])==1
pdf=P/'originals/Figshare-bi100317m_si_001.pdf';data=pdf.read_bytes();assert data.startswith(b'%PDF-') and len(data)==fg['files'][0]['size']==107857
assert hashlib.md5(data).hexdigest()==fg['files'][0]['computed_md5']=='91c84aba67a79acca2d0fdd2bb1b97ca'
dora=json.loads((P/'originals/DORA-psi-15308-metadata-retry.json').read_text())['data']['item']['info'];assert dora['pid']=='psi:15308' and len(dora['downloads'])==1
assert dora['downloads'][0]['access']=='restricted' and dora['downloads'][0]['availability']=='intranet'

attempts=[]
for file in sorted((P/'results').glob('acquisition-??.json')):
 for row_number,row in enumerate(json.loads(file.read_text())):
  if 'path' in row:
   body=P/row['path'];assert body.stat().st_size==row['bytes'] and sha(body)==row['sha256']
  attempts.append({'receipt':str(file.relative_to(P)),'row':row_number,**row})
dump(P/'results/acquisition-summary.json',{'attempt_count':len(attempts),'status_counts':dict(collections.Counter(str(x.get('status','exception')) for x in attempts)),'attempts':attempts,'scope':'Saved bodies include challenge responses and one GraphQL input error; HTTP200 alone does not establish successful source identity.'})

blocks=json.loads((P/'reading/2009-blocks.json').read_text())['all_projected_blocks']
claims=[]
for ident,index,interpretation in [
 ('P09-STRAIN',27,'D. multivorans DSM2059; E. coli BL21(DE3) is expression host, not biological source.'),
 ('P09-ASSAY',39,'30C,pH7.8,50mM Tris,250mM KCl,0.2mM ferrocenium,300nm; artificial acceptor.'),
 ('P09-CONSTRUCT',49,'pEXP5-CT/TOPO, additional C-terminal six histidines; do not replace with native sequence.'),
 ('P09-PREPARATION',50,'18C16h0.5mM IPTG expression; nickel affinity purification.'),
 ('P09-KINETICS-METHOD',54,'GlutarylCoA1-500uM, duplicate/triplicate determinations, Michaelis-Menten fitting.'),
 ('P09-NORMALIZATION',62,'Protein concentration by Bradford.'),
 ('P09-TABLE1',87,'Recombinant GDHDes Km52+/-5uM,Vmax11+/-1umol/min/mg; separate Geo native/recombinant rows.'),
 ('P09-FAD-CONTEXT',96,'Reported FAD reconstitution raises occupancy0.45 to0.65; not proof of2010 preparation equivalence.'),
 ('P09-RESULTS',98,'Purified recombinant GDHDes dehydrogenates to glutaconylCoA; product inhibition and kinetic values with source conditions.')]:
  row=blocks[index];claims.append({'id':ident,'source':'inputs/PMC2698508.html','source_sha256':sha(P/'inputs/PMC2698508.html'),'locator':{'block_index':index,'section_ids':row['ancestor_ids'],'heading':row['preceding_heading'],'text_sha256':row['text_sha256']},'interpretation':interpretation})
for ident,page,scope in [('P10-SI-TABLE',1,'TableS1 primer labels A80E,V88S,N91S,S161T,V366Y; design only, no kinetic results. Right edge clipped at media boundary, no all-base visual/alignment acceptance.'),('P10-SI-TREE',2,'FigureS1 tree and caption, blue-arrow gi228015642/ACP50614.1; sequence-based interpretation, no universal functional proof.'),('P10-SI-CAPTION',3,'Caption continuation: substitution interpretation and Blosum62/JalView2.4.0.'),('P10-SI-BLANK',4,'Blank page, visually inspected.')]:
 claims.append({'id':ident,'source':str(pdf.relative_to(P)),'source_sha256':sha(pdf),'locator':{'PDF_page':page},'interpretation':scope,'visual_file':f'reading/2010-supplement/page-{page:03d}.png'})
dump(P/'results/claim-ledger.json',claims)
dump(P/'results/reading-scope.json',{'fresh':['Exact retained UniProt citation and kineticParameters','Exact PubMed2010 XML metadata/abstract; not full main','Exact DORA item access metadata','All four pages2010SI text and visual','2009targeted methods/preparation/Table1/kinetic results at nine explicit block locators'],'not_read':['2010full main: not acquired','New2009full-paper or figure review','Exact primer/genome alignment','New taxonomic or protein issuer expansion'],'PDF_reader':binding(reader),'render_exit':0,'no_installs_or_repairs':True,'main_acquired':False,'IP08_resolved':False})
dump(P/'results/disposition.json',{'id':'IP08','status':'open_evidence_limited','citation':reference,'issuer_kinetics':kinetics,'primary2009':{'Km':{'value':52,'reported_SD':5,'unit':'uM'},'Vmax':{'value':11,'reported_SD':1,'unit':'umol/min/mg'},'construct':'D.multivorans DSM2059 GDHDes with C-terminal His6 expressed in E.coli BL21(DE3)','acceptor':'ferrocenium hexafluorophosphate','reaction':'glutarylCoA to glutaconylCoA; isolated nondecarboxylating enzyme'},'primary2010':{'full_main_acquired':False,'supporting_information_acquired':True,'kinetics_available_in_acquired_SI':False},'no_global_correction':True,'next_required':'Legitimate full2010main methods/results or exact per-field issuer provenance; retain2009values only with their assay context.'})
dump(P/'results/search-and-tool-scope.json',{'web_search_queries':['"10.1021/bi100317m"','"Structural basis for promoting and preventing decarboxylation in glutaryl-coenzyme A dehydrogenases"','"bi100317m" "mpg"','"bi100317m" pdf','"Structural Basis for Promoting" "mpg.de"','"bi100317m" "Supporting"','"bi100317m" "5350" filetype:pdf','site:acs.figshare.com "Structural Basis for Promoting"','site:pure.mpg.de "bi100317m"'],'adopted_locations':['ACS exactDOI','PubMed exactPMID','OpenAlex exactDOI location leads','MPG exacthandle','DORA psi:15308','ACS Figshare exactresourceDOI'],'web_open_limit':'Several web opens returned internal errors; raw acquisition receipts are authoritative for saved original bytes. Search snippets were discovery only.','browser_attempt':{'api':'cua.getBrowser','url':'https://www.dora.lib4ri.ch/psi/item/psi:15308','outcome':'No browser is available'},'runtime_attempts':['pdftotext/pdftoppm/pdfinfo not on current PATH; common/homebrew paths also unavailable','Existing263Python had no pypdf,fitz,pdfplumber; nothing installed','Existing bound PDFKit executable used successfully'], 'local_absence_scope':'No global local-file absence claim; parent reported a hidden/ignored-inclusive literal search of specific active/preparation owners only, with compressed archives not decoded.'})

# Final rehash of source owners required for this narrow handoff.
assert sha(I/'artifact-manifest.json')=='1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3'
assert sha(N/'artifact-manifest.json')=='bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b'
for row in reused:assert sha(Path(row['source']['path']))==row['source']['sha256']
assert sha(reader)=='b7b275f6edbc5a01f5a4c363683d0bdb89dada70e83c52f3d2017f465f59e90d'
dump(P/'results/final-verification.json',{'completed_utc':datetime.now(timezone.utc).isoformat(),'all_saved_acquisition_bodies_verified':True,'selected_reused_sources_unchanged':True,'reader_unchanged':True,'pubmed_exact_citation_verified':True,'supplement_size_and_issuer_MD5_verified':True,'all_four_supplement_pages_rendered':all((P/f'reading/2010-supplement/page-{n:03d}.png').exists() for n in range(1,5)),'all_jobs_terminal':True,'maintained_Git_GH_runtime_writes':False,'scope':'Selected sources only; earlier frozen packets were never written. No whole-repository gates claimed.'})

excluded={'artifact-manifest.json','freeze-proof.json'}
paths=sorted(P.rglob('*'));assert not any(x.is_symlink() for x in paths)
files=[{'path':str(x.relative_to(P)),'bytes':x.stat().st_size,'sha256':sha(x)} for x in paths if x.is_file() and str(x.relative_to(P)) not in excluded]
dump(P/'artifact-manifest.json',{'owner':str(P),'files':files,'file_count':len(files),'listed_bytes':sum(x['bytes'] for x in files),'excluded':sorted(excluded),'hidden_and_ignored_included':True})
dump(P/'freeze-proof.json',{'frozen_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':sha(P/'artifact-manifest.json'),'listed_files':len(files),'physical_files':len(files)+2,'all_jobs_terminal':True,'status':'FROZEN; no further writes; successor requires new owner'})
actual={str(x.relative_to(P)) for x in P.rglob('*') if x.is_file()};assert actual=={x['path'] for x in files}|excluded
for x in files:assert sha(P/x['path'])==x['sha256'] and (P/x['path']).stat().st_size==x['bytes']
print(json.dumps({'owner':str(P),'listed':len(files),'physical':len(files)+2,'manifest_sha256':sha(P/'artifact-manifest.json'),'freeze_sha256':sha(P/'freeze-proof.json'),'handoff_sha256':sha(P/'HANDOFF.md'),'assessment_sha256':sha(P/'ASSESSMENT.md'),'IP08':'open_evidence_limited'},indent=2))
