# IP08: bounded 2010 primary-source follow-up

**IP08 remains evidence-limited and open.** The exact 2010 citation and authentic supporting-information original are now acquired. The 2010 full main was not acquired through the finite legitimate access routes checked. Its kinetic values, protein preparation, tags and assay conditions therefore cannot be compared reliably with the 2009 experiment. No global database correction or numerical reconciliation is asserted.

This packet was authored by `/root/next268_current_bigg_completion` in a new scratch owner. It is a source-preparation handoff, not independent acceptance, maintained curation, a literature landscape search, or resolution of other next269 prerequisites. Previous packets remain unchanged.

## Exact citation and provenance

Retained UniProt C3UVB0 reference 2 identifies Wischgoll, Demmer, Warkentin, Günther, Boll and Ermler, *Structural basis for promoting and preventing decarboxylation in glutaryl-coenzyme A dehydrogenases*, Biochemistry 49(25):5350–5357 (2010), PMID: 20486657, DOI: 10.1021/bi100317m. The independently acquired PubMed XML confirms the PMID, DOI, journal and title. UniProt referencePositions list crystallography, cofactor and mutagenesis; its kineticParameters object contains no per-value evidence association. Citation presence does not prove that either kinetic value was taken from this paper.

The public ACS Figshare record 2757664 has resource_doi10.1021/bi100317m and supplement DOI: 10.1021/bi100317m.s001. Its only advertised file 4450495 is `bi100317m_si_001.pdf`,107857 bytes, expected MD5 `91c84aba67a79acca2d0fdd2bb1b97ca`. The downloaded PDF matches that length and MD5 and has PDF magic. Exact URLs, redirects, response headers, timestamps, hashes and failed attempts are retained under results/acquisition-*.json. The temporary signed storage URL was issued by the public Figshare downloader; no credentials or authenticated session were supplied.

## Access scope

Five initial requests failed DNS resolution inside the sandbox and are preserved. The authorized public-network retry retrieved publisher landing/PDF/SI endpoints as HTTP 403 challenge bodies, PubMed HTML as a 203 challenge, and OpenAlex exact-DOI metadata. PubMed's legitimate XML endpoint then returned the actual bibliographic record. No error body is treated as a PDF or full article.

OpenAlex's advertised exact institutional locations were followed. The MPG handle returned a bot challenge; no challenge was solved or access control bypassed. DORA's initial page was a client shell. Its public linked application assets provided a read-only GetItem query and public endpoint. The first request had an invalid uppercase subsite enum; the preserved server response supplied `psi`, and the corrected exact-item query returned the matching article. Its only download is explicitly marked **intranet/restricted**, with published-version/in-copyright metadata. No restricted download was attempted. The computer-use tool reported that no browser was available. OpenAlex marks this work closed/no repository full text; that metadata is an access lead, not proof of global absence.

The exact DOI/title searches and endpoints were confined to this publication and its supplement. Unrelated search hits were not adopted as primary evidence. No broad source search, subscription purchase, login, author contact, or new runtime installation was performed. Neither this search nor the parent's bounded local filename/text check establishes that no legitimate copy exists elsewhere.

## What the acquired supplement establishes

The existing PDFKit reader was verified byte-identical against the prior source-completion binding, then used without modification. All four pages were extracted and rendered, and all four were visually inspected:

- Page 1, Table S1: primer pairs for source-labelled substitutions A80E, V88S, N91S, S161T and V366Y. These are mutagenesis design information, not kinetic measurements. The right edge of the rendered table is clipped at the PDF page boundary; extracted text retains primer strings, but no exact primer/genome alignment or all-base visual verification is claimed.
- Page 2, Figure S1 and first caption portion: sequence tree with the blue-arrow GDHDes label gi228015642/ACP50614.1 and the marked sequence subgroup. The caption describes a sequence-based interpretation, not experimental verification of every homolog.
- Page 3: continuation of Figure S1 caption, including its matrix/software description and interpretation of Tyr/Val correspondence.
- Page 4: blank in both rendering and extracted text.

There is no kinetic-results table, assay-condition section, purification description, acceptor assay, Km or Vmax in this acquired four-page supplement. This is a bounded whole-supplement reading, not a claim about the inaccessible main. Sequence-tree identity and primer substitutions do not establish the exact tags, expression construct, enzyme preparation or conditions used for a 2010 kinetic measurement. Source V366Y wording is retained separately from the 2009 discussion's V367 wording; no residue-number correction is inferred.

## Supported 2009 comparison anchor

The exact retained PMC2698508 original was copied unchanged and freshly parsed. The targeted methods, preparation, Table 1 and kinetic-results passages were reread with original section IDs and content hashes. This is not a new independent full-paper/figure review.

| Property | 2009 primary evidence | Locator |
|---|---|---|
| Biological source | Desulfococcus multivorans DSM 2059 | `#sec2`, cultivation |
| Protein preparation | Heterologous GDHDes in E. coli BL21(DE3), pEXP5-CT/TOPO; additional C-terminal six histidines; nickel-affinity purification | `#sec11` |
| Expression | 18°C, 16 h after 0.5 mM IPTG | `#sec11` |
| Assay | Continuous ferrocenium hexafluorophosphate reduction,30°C, 50 mM Tris-HCl pH 7.8, 250 mM KCl, 0.2 mM acceptor, 300 nm readout | `#sec6` |
| Kinetic fit | Glutaryl-CoA 1–500 µM, duplicate-to-triplicate determinations, Michaelis–Menten fit | `#sec13` |
| Protein normalization | Bradford concentration determination | `#sec17` |
| Km | 52±5 µM for recombinant GDHDes | Table 1 `#t1`; Results `#sec27` |
| Vmax | 11±1 µmol min−1 mg−1 for recombinant GDHDes | Table 1 `#t1`; Results `#sec27` |
| Reaction scope | Glutaryl-CoA dehydrogenation to glutaconyl-CoA; purified GDHDes did not yield detected crotonyl-CoA in that assay | `#sec27` |
| Preparation context | Reported FAD occupancy rose from 0.45 to 0.65/subunit after 0.5 mM FAD incubation for 60 min at 30°C followed by excess-FAD removal | `#sec26` |

FAD loading is preparation context; it does not identify which inaccessible 2010 preparation was tested. The 2009 readout uses an artificial electron acceptor and does not establish physiological ETF transfer. A tagged recombinant preparation must not be replaced silently by native sequence/protein identity. The paper's separate GDHGeo native/recombinant results and membrane-fraction decarboxylation observations do not become properties of purified GDHDes.

## Discrepancy disposition

| Field | Current retained UniProtC3UVB0 | Read 2009 assay | Outcome after finite 2010 follow-up |
|---|---|---|---|
| Km | 25 µM, glutaryl-CoA; no per-field evidence | 52±5 µM | Unresolved. The 2010 main is unavailable here; do not merge, overwrite, or explain by construct/preparation without evidence. |
| Vmax | 11 mmol/min/mg; no per-field evidence | 11±1 µmol/min/mg | Explicit unit conflict retained. The nominal literal values differ by 1000-fold, but no global annotation correction or proven transcription-error diagnosis is made. |

The 2009 numbers may be used only with their documented experimental scope. The UniProt values remain separate issuer assertions. The 2010 supplement closes its acquisition/reading subtask but does not close IP08's kinetic reconciliation. Further resolution requires a legitimately accessible full main with the relevant methods/table, or exact per-field annotation provenance. Do not infer missing values from the structural abstract, supplement tree, mutation labels or another paper's review of this work.

All recorded failures, transformations, reading limits and source hashes are retained. No maintained record/authority promotion or complete pathway claim is made.
