# IP08 source follow-up handoff

**IP08 remains open.** Exact citation PMID:20486657 / DOI:10.1021/bi100317m is verified. The authentic ACS supporting-information PDF was acquired, issuer-MD5 checked, extracted and visually read across all four pages. It contains primer Table S1 and sequence Figure S1, with no kinetic results or assay methods. Its sequence/primer information does not certify a 2010 experimental preparation.

The full main remains unacquired in this finite attempt: ACS endpoints returned 403 challenge bodies, the advertised MPG location a bot challenge, and exact DORA metadata marks its published PDF intranet/restricted. No restricted download or challenge bypass was attempted. Browser unavailable. This is not global source absence.

Fresh targeted 2009 reading confirms recombinant DSM 2059 GDHDes with a C-terminal His6 tag, artificial ferrocenium assay at 30°C/pH7.8, Km 52±5 µM and Vmax 11±1 µmol/min/mg. UniProt C3UVB0 instead records 25 µM and 11 mmol/min/mg without per-value evidence. Do not collapse assays or assert a global numerical correction without the missing main/provenance.

See ASSESSMENT.md, results/claim-ledger.json and results/disposition.json. Exact receipts, failed attempts, originals, copied prior source receipts, source/reader bindings, four page renderings, locators and reading limits are included. All sources and scripts were written only in this new scratch owner; previous packets remain unchanged. No maintained/Git/GH edits, installs, runtime repairs or children.

Reproduction uses the existing `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B` and bound `/private/tmp/pathwaymech-next-268-primary/read_pdf`. Scripts write outputs: copy to a NEW owner before rerunning. `scripts/acquire.py` consumes immutable inputs/requests-NN.json, retaining each attempt separately. It requires public network access; sandbox DNS failures are preserved. `scripts/project_2009.py` rebuilds parsed source blocks and locators. `scripts/finalize_packet.py` binds selected reused sources, checks every saved response body, and freezes the packet. Do not run any script in this frozen owner.

This is an author source-preparation handoff for independent review, not maintained acceptance or final next269 curation. The full 2010 main with experiment-level context or exact UniProt per-field provenance is the remaining IP08 prerequisite.
