# Frozen PWY-5177 native graph design

Owner: `/private/tmp/pathwaymech-next-269-native-graph-design`.

The final proposal is **60 native graph nodes, 80 source-backed edges, and one proposed microbial taxon**. It accounts for all five native members, 20 material occurrences, four order assertions, six composite occurrences, all29 enzyme-specific activities, all10 regulations and all2131 direct slots across162 native originals. There are46 native edge-reference objects and an86-ID native node/reference union. No YAML record, adapter or maintained change was authored.

Read `DESIGN.md`, `results/design-verification-summary.json`, the full edge/node/activity/regulation ledgers, `results/regulation-representation-decision.json`, `results/native-authority-requirements.json`, `results/taxon-design.json`, and the exact eight ranked primary-reading tasks in `results/ranked-primary-reading-gaps.json`. `REPRODUCE.md` documents artifact roles and safe replay in a new owner.

The final regulation proposal supersedes an unfrozen context-only draft, preserved under `iterations/pre-regulation-expansion/`. Eight microbial regulations target four exact native Enzymatic-Reaction identities as participants/category molecular_activity; four enables links identify their enzymes. THLCLOS complex composition supplies the thirteenth additional edge: 67+8+4+1=80. The two human ion-regulation contexts remain retained outside the microbial positive graph. There is no activity/reaction equivalence or generic-reaction inhibition.

The current contracts are bound to released commit `ae143113008f8c194748bae322ab80b1853a6d95`, tree `1a0560c741c07fcb7878b1e93d8d38da67b1287c`; all16 copies match committed blobs. Root reported PR622 queued, but this design has not performed actual merged265 baseline rebind. No further reads of the268 worktree are needed. Maintained promotion still requires that rebind, independent design acceptance, bounded new native authority implementation/replay and record review. The design provides a concrete scratch-to-maintained integration sequence.

The accepted independent issuer review is bound to manifest `a8f25883dee855189ca74879e004e1ed1074e4f8443a0770ce5f6c1c8837aad2`. Its finite chemical/taxon/protein acceptance is reused with all limitations. Generic ETF, the sodium-transport mismatch, nine KEGG ionic mismatches, native hydration-label anomaly, historical strain/gene/sequence and kinetic conflicts remain explicit. Native GcdH catalysts attach to the composite only. No selenium cofactor edge is proposed. Full historical paper acquisition is not a blanket blocker to preserving explicit authoritative source assertions; primary upgrade claims remain bounded.

All16 corrected primary claims and five bounded2009 contexts are retained. The2010 C3UVB0 kinetic reading is assigned separately; no mutable successor evidence was absorbed. No further network or broad source hunt occurred.

Terminal inventory verification passed; see `results/final-verification.json` and stdout for assertion counts. All914 original frozen-input files, all45 accepted issuer-review files, and all215 copied inputs remained exact. Physical enumeration includes hidden/ignored files. The helper logs and superseded mutable proposal remain preserved. These are finite design/integrity checks, not maintained full gates or fresh full-paper readings.

The root artifact-manifest.json covers every physical file except itself and freeze-proof.json. The self-excluded freeze proof binds that manifest and this HANDOFF. All work is terminal. Treat this owner as immutable; any correction must use a new owner. No maintained/Git/GitHub/runtime edits, installs, repairs or children.
