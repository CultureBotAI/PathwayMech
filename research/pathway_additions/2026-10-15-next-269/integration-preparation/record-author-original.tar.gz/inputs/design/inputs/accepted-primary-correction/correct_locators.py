"""Correct three locator scalars while preserving all 16 claim bodies."""
from copy import deepcopy
from datetime import datetime,timezone
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
REVIEW=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion-independent-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert (REVIEW/'freeze-proof.json').is_file(), 'Wait for immutable independent findings'
assert not (ROOT/'primary-claim-ledger.json').exists()
inputs=[]
for origin,name in [(SOURCE/'results/primary-claim-ledger.json','predecessor-primary-claim-ledger.json'),
                    (SOURCE/'originals/PMC5974017.html','PMC5974017.html'),
                    (REVIEW/'findings.json','independent-findings.json')]:
 target=ROOT/name;target.write_bytes(origin.read_bytes())
 inputs.append({'path':name,'source_path':str(origin),'bytes':target.stat().st_size,'sha256':sha(target)})
before=json.loads((ROOT/'predecessor-primary-claim-ledger.json').read_text())
after=deepcopy(before)
rows={row['id']:row for row in after['claims']}
assert len(rows)==16
first=rows['N269-SC-P01'];last=rows['N269-SC-P12']
assert first['sources'][0]['locator']=='Results: Another glutarate catabolic pathway exists in P. putida; Figure 1b–e; Methods: Bacterial strains, culture conditions, and plasmids; Construction of mutant strains'
first['sources'][0]['locator']='Results: GDH is not indispensable for glutarate utilization; GDH and CsiD support glutarate dependent growth; Figure 1b; Figure 4a–c; Methods: Bacterial strains, culture conditions, and plasmids; Construction of mutant strains'
assert 'Figure 1 solid plates at 36 h' in first['limits']
first['limits']=first['limits'].replace('Figure 1 solid plates at 36 h','Figure 4c solid plates at 36 h')
assert last['sources'][0]['locator']=='Figure 6; Figure 7; Discussion'
last['sources'][0]['locator']='Figure 7a–c; Discussion'
def diff(a,b,path=''):
 if isinstance(a,dict):
  assert a.keys()==b.keys()
  return [x for k in a for x in diff(a[k],b[k],path+'/'+str(k))]
 if isinstance(a,list):
  assert len(a)==len(b)
  return [x for i,(v,w) in enumerate(zip(a,b)) for x in diff(v,w,path+'/'+str(i))]
 return [] if a==b else [{'path':path,'before':a,'after':b}]
changes=diff(before,after)
assert {row['path'] for row in changes}=={'/claims/0/sources/0/locator','/claims/0/limits','/claims/11/sources/0/locator'}
(ROOT/'primary-claim-ledger.json').write_text(json.dumps(after,indent=2)+'\n')
(ROOT/'correction-receipt.json').write_text(json.dumps({'created_utc':datetime.now(timezone.utc).isoformat(),'findings':['N269-SC-R01','N269-SC-R02'],'inputs':inputs,'independent_review_manifest_sha256':sha(REVIEW/'artifact-manifest.json'),'changes':changes,'unchanged_claim_bodies':16,'all_other_fields_unchanged':True,'scope':'Author locator correction only; original frozen packets unchanged; independent successor acceptance pending.'},indent=2)+'\n')
print(json.dumps({'changed_scalars':len(changes),'unchanged_claim_bodies':16,'output_sha256':sha(ROOT/'primary-claim-ledger.json')}))
