# PWY-5177 bounded issuing-authority preparation

This author packet resolves the requested finite chemical and named-strain leads sufficiently for independent review. It is not independent acceptance, a maintained record, authority promotion, or a claim that all five native members operate together in any one strain. Both prior native/source packets remain immutable. No maintained, Git, GitHub or runtime files were changed. The actual merged 265-record baseline must still be rebound before curation.

## Chemical identity

All 12 exact native ChEBI candidates resolve to retained issuing records. Six records were freshly acquired; six original response bodies and receipts were reused with verified hashes from the frozen next268 chemistry packet. The Rhea 142 RDF, directions table and release properties were likewise reused as issuing originals, not as inherited scientific conclusions. See `inputs/reused-issuing-originals.json`.

| Native material | ChEBI | Native/issuer charge | KEGG candidate | KEGG literal charge |
|---|---:|---:|---|---:|
| ACETOACETYL-COA | 57286 | -4 | C00332 | 0 |
| ACETYL-COA | 57288 | -4 | C00024 | 0 |
| CARBON-DIOXIDE | 16526 | 0 | C00011 | 0 |
| CO-A | 57287 | -4 | C00010 | 0 |
| CROTONYL-COA | 57332 | -4 | C00877 | 0 |
| GLUTACONYL-COA | 57353 | -5 | C02411 | 0 |
| GLUTARYL-COA | 57378 | -5 | C00527 | 0 |
| NAD | 57540 | -1 | C00003 | +1 |
| NADH | 57945 | -2 | C00004 | 0 |
| PROTON | 15378 | +1 | C00080 | +1 |
| S-3-HYDROXYBUTANOYL-COA | 57316 | -4 | C01144 | 0 |
| WATER | 15377 | 0 | C00001 | 0 |

`results/chemical-issuer-comparisons.json` binds every original native direct cross-reference and InChI, issuer structure, formula, charge, recomputed InChIKey, tetrahedral centre and double-bond stereo. All 12 pass bidirectional stereospecific graph isomorphism after parsing native and issuer standard InChI, exact standard InChI, and issuer SMILES/InChI consistency. This is a structural assessment, not name equality. In particular the E double bonds of crotonyl/glutaconyl and the S hydroxybutanoyl centre are preserved by the encoded native and issuer InChIs.

The native CMLs were independently constructed as atom/bond graphs and checked against their formulas, charges and stereo-stripped normalized InChIs. All 12 pass those bounded checks. This does not establish every CML stereochemical annotation, literal tautomer, or proton/charge localization. Standard InChI normalizes mobile hydrogen; the reconstructed graph can differ from the literal drawing. Five native literal SMILES contain generic `[R]` and were not used as exact identities: acetoacetyl-CoA, crotonyl-CoA, glutaryl-CoA, NAD and NADH. Parent CML diagnostics remain separate author evidence, not an accepted input to this conclusion.

All 12 KEGG structure MOL files were acquired and parsed. Water, carbon dioxide and hydron match the native normalized ionic structures. The other nine differ in protonation/charge. Analytical uncharging did not yield identical literal graphs (mobile-H/bond localization persists); NAD also retains a different protonation convention after this operation. A separate explicit diagnostic removes only the standard-InChI protonation layer for nonidentical records and reconstructs both graphs. All 12 then match in normalized constitution and stereochemistry with bidirectional graph checks. This supports a conjugate acid/base correspondence, not exact ionic identity or an instruction to rewrite either source. Both failed and final diagnostic attempts are retained. See `results/kegg-complete-candidate-assessment.json` and `kegg-normalization-diagnostic.json`.

ETF-Oxidized and ETF-Reduced are native Protein classes, not exact sequence-specific proteins. Rhea GENERIC:10685/10686 are also generic polypeptide states without whole-protein formulas or charges. Their reactive parts use CHEBI:57692 and CHEBI:58307; those are flavin parts, not proof that the whole ETF equals free FAD/FADH2. KEGG C04253/C04570 are generic carrier records; both MOL endpoints returned retained empty 404 responses. No ETF sequence, electron-transfer partner or complete whole-ETF balance is established.

## Five reaction candidates and directions

The complete pinned Rhea 142 RDF was parsed (326,097 descriptions); 69 selected statement nodes covering the five exact families, sides, participants, compounds and reactive parts are retained. This is not a global search for every possible alternative reaction. All selected directional reactions are Approved in this release. `results/five-reaction-dispositions.json` preserves native source direction, pathway-selected direction, all coefficients and side-specific issuer residuals without cancelling compartments.

| Native member | Native candidate family | Pathway-direction Rhea | KEGG and selected direction | Disposition |
|---|---|---|---|---|
| GLUTARYL-COA-DEHYDROG-RXN | 20592; master 20589 | 20590 | R10074 L2R | Small molecules and coefficients match; ETF only at explicit generic state-class scope. |
| GLUTACONYL-COA-DECARBOXYLASE-RXN | master 23972 | 23973 | R03028 L2R | Not an exact Rhea replacement: Na+(in) and Na+(out) are additional located participants. |
| RXN-11667 | 26561; master 26558 | 26560 | R03026 R2L | Exact native ionic hydration sides and coefficients. |
| RXN-11662 | 30802; master 30799 | 30800 | R01975 L2R | Exact native ionic NAD-dependent oxidation sides and coefficients. |
| ACETYL-COA-ACETYLTRANSFER-RXN | 21039; master 21036 | 21038 | R00238 R2L | Exact native ionic thiolysis sides, including coefficient 2 acetyl-CoA. |

Rhea 23973 explicitly transports sodium while decarboxylating; native has glutaconyl-CoA + H+ -> crotonyl-CoA + CO2 without sodium or compartments. Cancelling Na across sides would erase the distinguishing transport process. KEGG R03028 omits transport from its equation but lists both EC 1.3.8.6 and 7.2.4.5, with a sodium-pump comment for the latter. Neither identifier permits moving a soluble GcdH catalyst to a sodium pump or equating the separate decarboxylase with the composite dehydrogenase/decarboxylase.

KEGG R10074 and R03028 omit the native left-side proton; other three retain the same side incidence under the explicitly nonidentity ionic-state mapping. The five KEGG equations, comments, ECs and full metadata are retained. Do not call them all exact ionic equivalents simply because their biochemical names or mapped carbon skeletons agree.

Independent elemental/charge replay using the exact ChEBI ionic formulas confirms four fully specified native equations balance. The first and route net remain undetermined for whole ETF: their known terms leave H=-3 and charge=-1 for the first reaction, not a demonstrated full imbalance. The selected native route net is:

`glutaryl-CoA + oxidized ETF + NAD + H2O + CoA + H+ -> 2 acetyl-CoA + reduced ETF + NADH + CO2`

This is formal source stoichiometry, not physiological flux. `results/formal-balance-and-kegg-side-replay.json` retains the complete replay. The five source members are not an exhaustive elementary reaction count, and a composite GcdH activity is not five separate purified catalysts.

## Exact named taxa, genes and proteins

Seven NCBI taxonomy originals and five DSMZ strain catalogue pages were freshly acquired. Taxonomy rank is taken from the actual XML, not a search snippet. Taxonomy labels differ across issuers; strain identities and rank limits are retained.

| Historical scope | Issuer-supported taxon/culture | Exact sequence support | Limit |
|---|---|---|---|
| Pseudomonas sp. K172 | NCBITaxon:44139 Thauera aromatica K172 (strain), parent 59405; DSM 6984 catalogue history names K172 and G. Fuchs/A. Tschech | A0A2R4BN04 = AVR88726.1, 395 aa, CP028339.1 Tharo_1819 | Modern K172 genome annotation; no sequence-level identification of the 1993 purified enzyme. |
| Pseudomonas sp. KB740 | NCBITaxon:59406 Aromatoleum evansii (species), type-material KB740/DSM6898; DSM6898 history names Pseudomonas sp. KB740 | No accepted KB740 GcdH sequence in this finite scope | Species-level taxon is not a newly resolved strain taxon. Species search hit A0ABZ1APQ1 belongs to MAY27, not KB740. |
| G. metallireducens DSM7210 / GS-15 | NCBITaxon:269799 (strain), DSM7210 = ATCC53774/GS-15 | Historical gi78194537 resolves ABB32304.1 = Q39TX0, 392 aa, bamM/Gmet_2075 | Native protein sequence distinct from the 2009 C-terminal His/V5-tagged recombinant construct. |
| D. multivorans DSM2059 | NCBITaxon:1121405 (strain), parent 897; DSM2059 = 1be1/ATCC33890 | ACP50614.1 = C3UVB0, 389 aa; FJ688103.1 acd CDS 2713..3882 | Genomic source uses species taxon897 plus explicit strain DSM2059. 2009 recombinant His-tag construct is distinct from the native sequence. |
| P. putida KT2440 | NCBITaxon:160488 (strain); DSM6125 = mt-2 KT2440/ATCC47054. DSMZ calls P. alloputida, NCBI XML uses P. putida with P. alloputida equivalent name | Q88RH2 = AAN65791.1 = NP_742327.1, 393 aa, gcdH/PP_0158 | 2018 genetic phenotype and multi-gene complementation, not purified GcdH or direct ETF assay. |

`results/protein-exact-sequence-comparisons.json` recomputes sequence MD5/SHA256 and exact full sequence equality across the issuing records. `results/independent-cds-translations.json` independently translates the two acquired exact genomic CDSs under bacterial code 11: FJ688103 acd -> ACP50614.1 and AE016774 gcdH -> AAN65791.1. Both reproduce all residues and the deposited translations. Sequence equality is not experimental enzyme evidence.

The source-native 1993 K172 G-4001 -> MONOMER-5381 link has a conflicting PART-OF cross-reference to AE016774. Actual AE016774.1 is the KT2440 genome section, not K172, and encodes Q88RH2/AAN65791.1. The two strain-specific proteins differ in length and sequence. Preserve the native assertion and conflict; never use AE016774 to transfer the K172 enzyme onto KT2440.

Native PP_0158 GeneID 1043671 is explicitly discontinued (2020-04-02) in its actual NCBI response, with locus PP_RS00815 and no Gene-track_current-id element. Current Q88RH2 GeneID cross-reference 83677406 instead resolves to strain NMI24_14, locus LU682_RS00585, taxon2093743, not KT2440. It is not an accepted replacement. KT2440 protein identity is supported independently by the exact sequence records. The native PP_0158 coordinates 168404..169585 agree with NP_742327.1's NC_002947.4 context; the older AE016774 section has coordinates 168402..169583 for the same 393-aa sequence. Coordinates must stay accession/version-specific.

The apparent KB740 lead A0ABZ1APQ1 equals WRL46492.1 and WP_169132142.1 (395 aa), but WRL46492.1 explicitly derives from MAY27, CP141259.1, U5817_00180. The WP record is nonredundant/species-level; equality does not bind it to KB740. The exact ENA request CAWPLS010000285 returned the CAWPLS010000000 WGS master, an assembly set labelled ena-yuan-GCF_012910805.1, not the requested contig or a KB740 source feature. HTTP200 is not exact-ID resolution.

C3UVB0's current kinetic annotation differs from the read 2009 primary source: JSON gives 11.0 mmol/min/mg and Km25 µM, whereas the 2009 abstract, Table1 and Results give 11 ± 1 µmol/min/mg and Km52 ± 5 µM for recombinant GDHDes. No per-field provenance establishes that these are the same experiment. The later 2010 structure article cited by UniProt was not read here; Km25 is therefore a retained unresolved cross-source discrepancy, not a claim of global error. The unit discrepancy must also remain explicit; use the primary values only for that documented assay.

FJ688103's current feature lengths also differ from the 2009 Figure4 caption: acd CDS1170nt versus caption1173bp; the current partial gcd CDS4258..>5059 covers802nt versus caption >1118bp. No undocumented reconstruction reconciles these. They do not defeat the exact deposited acd translation, but they prohibit silently treating paper cartoon dimensions as current accession coordinates. The rre and gcd annotations are partial sequences, not complete regulatory/pump mechanisms.

## Reading and scope

`reading/reading-scope-ledger.json` distinguishes freshly inspected issuer identity/biological fields, exact structural computations and bounded reuse. The 2009 full-main/three-table/four-figure reading remains the earlier author's reading, hash-bound here; only the identity/kinetic/construct passages were freshly reread. The 2018 full-main/supplement reading is reused from the frozen source-completion packet at its recorded hashes and limits. Neither is a new independent primary review. The unavailable 1993 full article remains unavailable; abstract-level historical evidence does not establish full methods or a modern sequence assignment.

UniProt automatic ARBA/RuleBase and conceptual translation annotations are kept separate from the 2009 direct experiment. Q39TX0, Q88RH2 and modern K172/KB740-search proteins are not experimentally validated merely because their sequence cross-references agree. The selected Rhea entries in these UniProt annotations (including 13389 and 47420) remain annotation leads outside the five-family Rhea replay; no unperformed extra exact-equation audit is claimed.

## Outstanding actions

`UNRESOLVED.json` gives bounded dispositions. Independent source/issuer review, CML stereo interpretation, historical GcdH exact sequence binding, full1993 reading if accessible, downstream catalyst/primary coverage, source-native transport conflict disposition, generic ETF handling, and actual merged-baseline duplicate rebind remain open. The named species/taxa and tested biochemical transformations do not establish a complete PWY-5177 route in each organism. No additional landscape search or PWY-301 reopening was performed.
