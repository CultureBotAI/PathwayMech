# PWY-5177: bounded native and primary preparation

This is an initial source-author preparation for **MetaCyc:PWY-5177, glutaryl-CoA degradation**, not an independently accepted dossier, authority extension, maintained draft or claim of complete microbial pathway characterization. The preceding ranked handoff remains immutable. PWY-301 is deferred.

## What the new originals establish

All five selected native reactions have complete original XML responses. The pathway original is byte-identical to the retained267 source. The thiolase original matches the existing acetoacetate-authority fixture bytes. The source lists five members, but its first two are also explicit constituents of the composite `GLUTARYL-COA-DEHYDROGENASE-RXN`; neither has a directly attached activity. The composite has two activity records, one linking a historical K172 complex and the other a KT2440 gene product. Catalysts must not be transferred indiscriminately between the composite and its constituent chemistry.

| Selected native member | Pathway traversal | Native material equation in that traversal |
|---|---|---|
| GLUTARYL-COA-DEHYDROG-RXN | L2R | glutaryl-CoA + oxidized ETF + H+ → glutaconyl-CoA + reduced ETF |
| GLUTACONYL-COA-DECARBOXYLASE-RXN | L2R | glutaconyl-CoA + H+ → crotonyl-CoA + CO2 |
| RXN-11667 | R2L | crotonyl-CoA + water → (S)-3-hydroxybutanoyl-CoA |
| RXN-11662 | L2R | (S)-3-hydroxybutanoyl-CoA + NAD → acetoacetyl-CoA + NADH + H+ |
| ACETYL-COA-ACETYLTRANSFER-RXN | R2L | acetoacetyl-CoA + CoA → 2 acetyl-CoA |

There are 20 reaction-side occurrences and 14 distinct native material IDs. Formal cancellation gives glutaryl-CoA + oxidized ETF + H+ + water + NAD + CoA → reduced ETF + CO2 + NADH + 2 acetyl-CoA. This is native-ID arithmetic. Generic ETF classes, microstates, conserved CoA stereochemistry, atom balance and physiological electron transfer are not independently established here. The native first-two-member sum matches the composite equation exactly by ID/coefficient.

A source wording hazard is retained: RXN-11667 has common-name “(S)-3-hydroxybutanoyl-CoA dehydrogenase” despite its water-only hydration/dehydration equation and EC-4.2.1.150. Its label is not evidence for redox chemistry. The G1G01-166 protein comment loosely says GcdH acts on glutarate; the associated reaction instead consumes glutaryl-CoA. Preserve the pathway-level interpretation without turning free glutarate into a direct GcdH substrate.

The complete retained native inventory is91 originals: 1 pathway, 8 reaction objects (five members, GCD composite and two thiolase constituents), 29 activities (27 attached to the lower three members and two to the composite), 30 protein/class objects, 13 compounds and 10 regulation instances. All exact request/query/frame/type/detail/byte checks passed. The1267 direct slots and62 distinct embedded publication identifiers are retained. This is a finite acquired inventory, not full forward closure. Seventy enzyme/component/gene/cofactor/regulator/species pointer occurrences still lack a separately acquired original; the ledger distinguishes embedded full objects from low-detail objects and bare pointers.

Most lower-tail activities belong to other metabolic and organism contexts, including archaeal carbon fixation, fermentative pathways, E. coli acetoacetate metabolism and Arabidopsis proteins. Their attachment to a shared reaction does not demonstrate the complete glutaryl-CoA route in those organisms. These contexts remain visible for later per-claim inclusion/exclusion rather than being silently adopted.

## Primary evidence and limits

**Wischgoll et al. 2009, PMID:19395484, DOI:10.1128/JB.00205-09** is freshly acquired as complete PMC2698508 HTML. Complete main text, all three tables as source text, and the reference list were read; all four original figure images were visually inspected. This is new author reading, requiring independent scientific acceptance.

The paper distinguishes decarboxylating Geobacter metallireducens GDH from nondecarboxylating Desulfococcus multivorans GDH. Geobacter native/recombinant preparations produced crotonyl-CoA; recombinant Desulfococcus GDH produced glutaconyl-CoA. Adding Desulfococcus membrane extract enabled subsequent conversion and NaCl increased it. This supports distinct mechanistic contexts, not one universal catalyst assignment. Experiments used artificial ferrocenium acceptor; they do not verify the native generic ETF equation in either organism. The authors report product inhibition for Desulfococcus, with an approximate Ki, and no corresponding inhibition in their Geobacter test. Their gene-cluster RT-PCR is expression evidence, not direct regulator binding or complete pathway flux.

Preparation details are essential: DSM7210 versus DSM2059; native Geobacter protein versus recombinant C-terminal His6/V5 Geobacter and His6 Desulfococcus constructs in E. coli BL21(DE3); 30°C assays, pH7.8, 250mM KCl and0.2mM ferrocenium. FAD occupancy changes after reconstitution. Table1 lists sequence-derived masses, while Results/Fig3 discuss tagged apparent masses. Do not collapse these into one molecular-mass claim. Methods and Results give slightly different inhibitor/substrate concentrations; preserve their respective scopes rather than selecting one silently. Fig2 caption's crotonyl mass differs by one unit from the Results text. The paper proposes energetic/ecological explanations and sequence-residue interpretations; these are not direct demonstrations of every listed species or sodium-translocation stoichiometry.

**Härtel et al.1993, PMID:8439237 / DOI:10.1007/BF00250279** is the actual native composite-activity source. The publisher page was acquired successfully, but it contains only the abstract, references and subscription preview, not full main text. Its abstract reports purified bifunctional enzymes from historical Pseudomonas KB740 and K172, ferricenium assays and similar decarboxylation activity. Exact preparation/method/figure claims remain unavailable in this packet. Native CPLX-4041 stores K172 and four MONOMER-5381 chains; modern strain/sequence reconciliation remains open.

**Zhang et al.2018, PMID:29844506 / DOI:10.1038/s41467-018-04513-0, PMC5974017** is the KT2440 native activity citation. Only indexed metadata/abstract was read in this pass. Native evidence is reaction-blocked-in-mutant, and the protein comment describes the double gcdH/csiD deletion phenotype. The complete main and supplements are explicit next sources; no direct purified GcdH chemistry is inferred from that genetic evidence. Exact links are in the retained metadata.

**PMID:8436125** remains a pathway-level historical lead: its indexed abstract calls the downstream glutaryl/crotonyl continuation proposed. **PMID:11705404** is explicitly human GCD; it cannot establish microbial preparations. Both full publisher requests failed403. Their indexed abstracts are retained, not substituted for full articles.

Focused primary leads from the2009 bibliography include the2008 Azoarcus CIB gcdH/gcdR study (DOI:10.1111/j.1462-2920.2007.01468.x), the1985 Paracoccus GDH/ETF/ETF-Q oxidoreductase study, and exact Syntrophus/fermentative decarboxylase studies. These remain leads, not newly read or accepted evidence. No broad pathway-source landscape search was performed.

## Remaining prerequisites before a record

1. Close the exact native enzyme/component/gene/cofactor/regulator forward objects and assign every retained activity a source-specific biological scope. Do not fill a pathway with all catalysts of a shared generic reaction.
2. Independently inspect all material structures, charges, stereochemistry, carrier classes and exact issuing reaction cross-references. Native Rhea/KEGG links are candidates, not proved equivalences. Resolve transport-bearing biotin decarboxylase chemistry separately from soluble GCD constituent chemistry.
3. Read complete1993 microbial enzyme evidence,2018 KT2440 main/supplements, and the bounded lower-tail/ETF/regulatory primary sources needed for the chosen claims. Establish a complete pathway coverage ledger, with uncertainty rather than cross-organism stitching masquerading as measured whole-route flux.
4. Reconcile historical K172/KB740 names, current genes/protein sequences and recombinant tags. The2009 FJ688103 locus and bamM legacy accession are leads requiring issuer-original verification.
5. Retain all five source members and composite/constituent distinctions. A five-member source projection is not an exhaustive elementary-step count. The rejected yeast GO-CAM still omits defining chemistry and is not a substitute for this source definition.
6. Rebind the actual merged265-record baseline and every new exact alias before maintained work. Nine additional native/comparative IDs were searched across all265 captured full YAML texts with no literal occurrence; that finite scan does not prove universal alias absence. No authority term or maintained record has been added.

## Preservation and reading scope

All265 baseline YAMLs and governing files were copied and hash-verified before releasing the live268 worktree; this packet no longer depends on that worktree. Original native bytes and all response receipts are retained. Initial sandbox DNS failures, primary403/500 responses and the HTTP200 PMC PDF challenge are preserved. The file named PMC2698508.pdf is HTML, not a PDF; it was not used as PDF evidence. Three tables were read structurally as HTML text, not visually in a PDF/browser. No browser QA, complete original source-graph closure, complete all62-paper reading, independent chemistry acceptance or maintained curation approval is claimed.

All91 native originals were structurally parsed and every direct slot retained. Fresh human reading covered the pathway definition, five material equations and their metadata/links, the GCD composite and both full activity records, corresponding source protein biological slots, selected lower-tail activity passages and the complete2009 article. The remaining native context slots and publication leads are retained for later complete scientific review; parsing is not counted as human full-source reading. No installs, runtime repair, maintained edits, Git/GitHub writes or child agents were used.
