# Frozen independent issuer review handoff

Target: `/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation`, manifest `1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3`.

**Accepted within the finite issuer-preparation scope.** No author defect requires a successor. See REVIEW.md and review.json for all twelve compound, five reaction and ten unresolved dispositions. This is not maintained record acceptance, full source/primary acceptance, or actual merged-baseline duplicate rebind.

Independent work: 229 target files and 676 prior packet files rehashed; 98 acquisition rows and 75 saved bodies replayed; 170 chemical and 101 biological identity assertions passed; 326,097 Rhea descriptions parsed and 69 selected nodes replayed; two exact CDS translations; 77 prescribed RDKit runtime files unchanged. Nine KEGG ionic mismatches, generic ETF scope, Rhea sodium transport rejection, exact strain/gene/sequence conflicts and kinetic discrepancies remain explicit. Six 2018 supplement primer rows retain gdh + pp0159 and csiD + lhgO construct scope.

Additional source note IR269-N01: RXN-11667 is called dehydrogenase in the native common-name but its actual equation is hydration/dehydration. The preparation handles the equation correctly. Preserve this anomaly in future curation.

The terminal source-integrity-after.json rebinds target, prior packets and runtime. The whole review packet, including failed reviewer helper attempt, scripts, reading projections, logs and evidence, is covered by artifact-manifest.json. Only the root artifact-manifest.json and freeze-proof.json exclude themselves. All local work is terminal. No maintained/Git/GH/runtime writes, installs, network acquisition or children. Treat this owner as immutable; any successor requires a new owner.

Reproduce by copying helpers and their reading inputs to a fresh scratch owner and using the exact runtimes in command-receipts.json. The Rhea/metadata/sequence helpers use `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`; chemistry uses `RDBASE=/private/tmp/npmech-rdkit-2026.03.5/share/RDKit /private/tmp/npmech-rdkit-2026.03.5/bin/python3.13 -B`. Never rerun a helper in this frozen owner.
