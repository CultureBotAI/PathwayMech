# Independent review of PWY-5177 issuer preparation

**Disposition: accepted within the finite preparation scope, with the limits below.** No correction to the frozen issuer preparation is required by this review. This is not acceptance of a maintained record, all native biological assertions, complete primary coverage, or a merged-baseline duplicate check. The initial and source-completion packets still require their own independent scientific acceptance. No maintained, Git, GitHub, or runtime files were edited; no network acquisition or installation was performed.

Reviewer: `/root/next268_current_bigg_completion`. The reviewer did not author this next269 issuer packet. The reviewer previously authored next268 native/authority work; that work is not self-accepted here. Reused next268 issuing originals are checked as exact input bytes and independently parsed for the present finite claims.

## Bound input and integrity

Target: `/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation`, manifest SHA256 `1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3`. Its 227 listed files and 229 physical files were verified, including hidden and ignored files. The only manifest exclusions are the manifest and freeze proof. The source HANDOFF, ASSESSMENT, UNRESOLVED ledger and reading-scope ledger were read, and the copied add-pathway governance was consulted. Exact original sources and both source and reviewer computations remain distinguishable.

Both bound prior packets were independently checked for complete physical inventories and byte hashes: 423 initial files and 253 source-completion files, 676 in total. Fifteen reused original/receipt bindings and every one of the 98 acquisition-ledger rows were replayed. Those attempts comprise 68 HTTP200, 5 HTTP429, 2 HTTP404 and 23 exceptions; 75 distinct saved response bodies match their receipt hashes and sizes. An HTTP200 wrong-ID WGS response is not counted as successful identity resolution. This is integrity verification, not a claim that all 676 prior artifacts were read scientifically. See `source-integrity-replay.json` and the terminal `source-integrity-after.json`.

## Twelve compound dispositions

The independent RDKit 2026.03.5 replay used only the expressly supplied runtime, with 77 bound runtime files unchanged before and after. It passed 170 assertions. Each native top-level Compound frame, PGDB identity and query was checked directly, then its encoded InChI was compared with the exact released ChEBI accession, issuer SMILES, formula, charge and recomputed InChIKey. Bidirectional stereospecific graph checks and exact standard-InChI checks agree. Epimer rejection controls were applied where a specified stereocentre was available. Crotonyl and glutaconyl E stereochemistry is encoded and retained.

| Native frame | ChEBI | Charge | KEGG | Exact KEGG ionic graph |
|---|---|---:|---|---|
| ACETOACETYL-COA | CHEBI:57286 | -4 | C00332 | No |
| ACETYL-COA | CHEBI:57288 | -4 | C00024 | No |
| CARBON-DIOXIDE | CHEBI:16526 | 0 | C00011 | Yes |
| CO-A | CHEBI:57287 | -4 | C00010 | No |
| CROTONYL-COA | CHEBI:57332 | -4 | C00877 | No |
| GLUTACONYL-COA | CHEBI:57353 | -5 | C02411 | No |
| GLUTARYL-COA | CHEBI:57378 | -5 | C00527 | No |
| NAD | CHEBI:57540 | -1 | C00003 | No |
| NADH | CHEBI:57945 | -2 | C00004 | No |
| PROTON | CHEBI:15378 | +1 | C00080 | Yes |
| S-3-HYDROXYBUTANOYL-COA | CHEBI:57316 | -4 | C01144 | No |
| WATER | CHEBI:15377 | 0 | C00001 | Yes |

All twelve ChEBI dispositions are supported at the **native encoded, normalized ionic-structure** scope. Native CML was independently reconstructed from atoms and bonds and passed formula, charge and stereo-stripped normalized-InChI checks. This does not independently validate CML stereochemical annotations or literal tautomer/proton placement. Standard InChI normalizes mobile hydrogen. Five native literal SMILES contain generic `[R]` and are unsuitable for exact molecular identity.

The nine nonidentical KEGG structures match normalized constitution/stereochemistry only after explicit removal of the standard-InChI protonation layer for those nonidentical pairs. They are conjugate acid/base correspondences, not exact ionic aliases. NAD and NADH retain their native/ChEBI -1/-2 states versus KEGG +1/0. The first reviewer helper incorrectly applied this diagnostic to already-identical hydron and failed; the initial helper and logs are retained, and the corrected helper follows the author's nonidentical-pair restriction. That was a reviewer setup error, not an author/source defect. See `chemical-attempt1-disposition.json`.

## Five reaction dispositions

The entire pinned Rhea 142 RDF was freshly parsed: 326,097 descriptions, with all 69 selected statement nodes reproduced. The exact native Reaction objects, pathway-selected directions, directions table, sides, coefficients, generic classes and explicit location properties were read. This finite five-family audit is not an exhaustive alternative-ID search.

| Native member; selected direction | Directional Rhea | Independent disposition |
|---|---|---|
| GLUTARYL-COA-DEHYDROG-RXN; L2R | 20590, master 20589 | Small-molecule sides and coefficients agree. Native ETF Protein classes and Rhea GENERIC:10685/10686 support only generic redox-state correspondence. |
| GLUTACONYL-COA-DECARBOXYLASE-RXN; L2R | 23973, master 23972 | **Reject exact replacement:** issuer adds CHEBI:29101 at explicit in/out locations and transport status. Native source lacks sodium and compartments. |
| RXN-11667; R2L | 26560, master 26558 | Exact ionic hydration sides and coefficients. |
| RXN-11662; L2R | 30800, master 30799 | Exact ionic NAD-dependent oxidation sides and coefficients. |
| ACETYL-COA-ACETYLTRANSFER-RXN; R2L | 21038, master 21036 | Exact ionic thiolysis sides, including two acetyl-CoA products. |

All selected directional entries are Approved in the pinned release. The KEGG candidates are respectively R10074 L2R, R03028 L2R, R03026 R2L, R01975 L2R and R00238 R2L. The first two omit the native left-side proton; the last three retain side incidence only under the explicitly nonidentity ionic-state mapping. The sodium pump must not be erased by cancelling Na across compartments or assigned a soluble composite GcdH catalyst.

Four fully specified native equations balance by independently recomputed elemental and charge sums. The first equation's known non-ETF terms leave product-minus-reactant H=-3 and charge=-1; whole-ETF and whole-route balance remain **undetermined**, not demonstrated imbalanced. Rhea's reactive flavin parts do not equate whole ETF with free FAD/FADH2. No exact sequence-specific ETF, physiological partner, or isotope/flux measurement is established.

Formal source net: `glutaryl-CoA + oxidized ETF + NAD + H2O + CoA + H+ -> 2 acetyl-CoA + reduced ETF + NADH + CO2`. This is source stoichiometry, not physiological route reconstitution. Composite GcdH activity is not evidence for five separately purified enzymes.

**Additional curation note IR269-N01:** RXN-11667's native common-name is `(S)-3-hydroxybutanoyl-CoA dehydrogenase`, while its native equation is hydration/dehydration and native EC slot is EC-4.2.1.150. The preparation correctly classifies the selected equation as hydration and retains the original. Preserve the label/chemistry discrepancy in later curation; do not treat the source label as oxidation evidence. This is a source anomaly, not a defect in the issuer disposition.

## Named biological identities and conflicts

The independent replay passed 101 identity assertions. Seven NCBI taxonomy originals and targeted identity/history sections of five DSMZ originals were freshly parsed/read. Five UniProt/NCBI full-sequence comparisons reproduce the author result; two complete coding sequences were independently translated under bacterial code 11, preserving all nucleotide coordinate positions.

| Scope | Supported identity | Boundary retained |
|---|---|---|
| K172 | Taxon44139 strain, parent59405; DSM6984; A0A2R4BN04 = AVR88726.1, 395 aa | Modern genome annotation is not identification of the 1993 purified enzyme. Native G-4001 PART-OF AE016774 points to the wrong strain's actual KT2440 sequence. |
| KB740 | Taxon59406 species/type-material KB740/DSM6898 | No accepted exact KB740 GcdH sequence in this finite evidence. A0ABZ1APQ1 = WRL46492.1 = WP_169132142.1, 395 aa, resolves to MAY27; WP equality does not establish KB740. Requested ENA CAWPLS010000285 returned WGS master CAWPLS010000000. |
| GS-15 | Taxon269799 strain; DSM7210/ATCC53774; historical gi78194537 resolves ABB32304.1 = Q39TX0, 392 aa | Native bamM sequence and the 2009 C-terminal His6/V5 recombinant construct are distinct. |
| D. multivorans DSM2059 | Taxon1121405 strain, parent897; DSM2059/1be1/ATCC33890; ACP50614.1 = C3UVB0, 389 aa | FJ688103 uses species taxon897 plus explicit strain. Deposited native sequence and experimental C-terminal His6 construct are distinct. |
| KT2440 | Taxon160488 strain; DSM6125/mt-2 KT2440/ATCC47054; Q88RH2 = AAN65791.1 = NP_742327.1, 393 aa | NCBI and DSMZ source names differ; retain P. putida/P. alloputida attribution. Sequence identity is not purified-enzyme evidence. |

Gene1043671 is explicitly discontinued on 2020-04-02 and the exact response has no Gene-track_current-id. Current UniProt-linked Gene83677406 belongs to NMI24_14, locus LU682_RS00585, not KT2440; it is not a replacement. The supported KT2440 protein sequences remain usable within their own provenance. Native 168404..169585 agrees with NP_742327.1/NC_002947.4; older AE016774.1 uses 168402..169583 for the same 393 residues. Coordinates are accession/version-specific.

FJ688103 acd CDS2713..3882 has 1170 nt and independently translates to all 389 deposited residues. The primary 2009 Figure4 caption says 1173 bp. Current partial gcd4258..>5059 spans802 nt versus caption >1118 bp. Neither discrepancy is silently repaired or used to invent full regulatory/pump sequences.

Targeted fresh 2009 original reading confirms recombinant GDHDes Km52±5µM and Vmax11±1µmol/min/mg, experimental ferrocenium acceptor, exact construct distinctions and the Figure4 dimensions. UniProtC3UVB0 instead gives Km25µM and Vmax11mmol/min/mg without per-field evidence. These remain cross-source discrepancies, not a global numerical correction: the cited 2010 paper was not read here. Ferrocenium assays do not prove physiological ETF transfer.

Targeted fresh 2018 main-original reading supports the PP0158/gdh genetic phenotype. Six primer rows were freshly parsed/read from the retained Supplementary Data2 worksheet HTML derivative: `gdh + pp0159` and `csiD + lhgO` inserts. Exact original/derivative hashes are bound. This was not a new BIFF, hidden-cell, formula, full-figure or full-supplement audit. Initial SI1/SI2 text attempts were mixed binary/text and were not treated as readable complete evidence. Growth rescue must retain the larger constructs; PP0159 gains no inferred function. The 2018 purified assays concern CsiD/LhgO and do not prove purified KT2440 GcdH, ETF transfer, or all five source members in one organism.

## Remaining obligations

The author's IP01–IP10 limits are sustained. This receipt discharges only the independent **issuer-preparation** component of IP01. Initial/native and source-completion scientific acceptance, actual merged265 baseline rebind including hidden/ignored payloads, maintained drafting, authority integration and final record review remain separate work. CML stereo/literal depiction remains open (IP02); the Rhea transport mapping is rejected (IP03); ETF exact identity/balance remains limited (IP04); historical K172 and KB740 sequence binding remains unresolved (IP05–06); current exact KT2440 GeneID remains unresolved (IP07); kinetic/2010-source reconciliation remains open (IP08); sequence-version dimensions remain explicit (IP09); inaccessible 1993 full-main and downstream catalyst/regulation/cofactor/whole-route coverage remain incomplete (IP10).

No global absence, exhaustive identifier search, complete native forward-closure acceptance, full primary-source acceptance, or one-strain whole-pathway function is claimed. Issuer sequences, automatic annotations, conceptual translations, catalog identities, source-native statements and direct experimental evidence must remain distinct. The reviewer did not newly audit UniProt-linked Rhea13389/47420 or expand the five-family scope. No PWY-301 work was undertaken.

Reproduction commands, check receipts, exact source bindings, structured dispositions and all reviewer attempts are included in this packet. Reruns must write to a fresh owner; this packet becomes immutable on freeze.
