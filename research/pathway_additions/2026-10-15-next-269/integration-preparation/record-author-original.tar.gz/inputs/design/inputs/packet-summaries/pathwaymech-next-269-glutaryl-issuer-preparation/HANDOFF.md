# Frozen PWY-5177 issuer preparation

Owner: `/root/next268_chemistry_acceptance`. This is an author preparation for independent review, not curation approval. Created only after actual-path absence was checked. No maintained/Git/GitHub/runtime edits, installs, children or live removed-worktree dependencies.

Read `ASSESSMENT.md`, `UNRESOLVED.json`, `reading/reading-scope-ledger.json`, and the complete selected source originals. This handoff is bounded to 12 native compound candidates, five native reaction families, and the named historical/2009/2018 strain and protein identities.

Results: all12 native/ChEBI normalized ionic structural checks pass; nine KEGG compounds differ in protonation state. Three small-molecule Rhea equations reconcile exactly, first reaction only at generic ETF class scope, and native decarboxylation is not identical to Rhea23973 because the latter transports Na. Four complete native equations balance; first/net whole-ETF balance remains undetermined. Five exact protein-sequence comparisons and two independent genomic-CDS translations pass.

Conflicts retained: K172 native PART-OF AE016774 actually points to KT2440; native KT2440 Gene1043671 is discontinued; current UniProt Gene83677406 is NMI24_14; KB740 search hit is MAY27, and exact contig request returned a WGS master. C3UVB0 kinetic annotation differs from2009 primary values; Fig4/currentFJ688103 dimensions and accession-specific genome coordinates remain explicit.1993 full main and historical purified-enzyme sequence assignments remain open. No physiological whole-route or exact ETF-partner assertion is made.

98 acquisition attempts:68 HTTP200,5 HTTP429,2 HTTP404,23 sandbox DNS failures. All75 fresh response bodies and all failed probes with saved bodies remain.15 pinned original/receipt files reused. Earlier script failures and corrected scripts/results are preserved; see `results/failure-and-limitation-ledger.json`.

All676 physical inputs across the two prior frozen source packets remain exact before/after; all77 bound RDKit runtime files remain exact. All15 reused original/receipt files remain exact. Copied governing/native/primary inputs are individually hash-bound. Fresh versus reused readings are explicit; no new whole-paper visual review is claimed here.

This packet has 227 manifested files and 229 physical files, including manifest and its self-excluded freeze proof. `artifact-inventory.json` enumerates every physical path without gitignore filtering; `artifact-manifest.json` binds all except itself and `freeze-proof.json`. The proof binds manifest and HANDOFF hashes. No files change after this freeze.

Next: independent acceptance of this finite preparation and prior source/primary packets; disposition of the exact remaining actions; actual merged265 baseline rebind before any maintained draft. Current output must remain immutable. Source-wide exhaustion, exhaustive alternative-ID search and complete pathway physiology are not claimed.
