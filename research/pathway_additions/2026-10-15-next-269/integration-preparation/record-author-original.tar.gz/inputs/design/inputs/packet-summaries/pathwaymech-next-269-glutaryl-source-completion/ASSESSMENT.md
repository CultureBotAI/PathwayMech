# PWY-5177 bounded source completion

This successor closes the requested native forward-reference scope and adds a full reading of the accessible 2018 KT2440 study and its published supplementary material. It does not complete chemistry validation, establish every native reaction experimentally in one organism, or authorize a maintained record. The 1993 microbial GCD full article remains unacquired in this finite access attempt.

The predecessor is `/private/tmp/pathwaymech-next-269-glutaryl-preparation`, manifest `bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b`. Its 421 manifested files and 423 physical files were verified at intake. It retains the actual five-member MetaCyc definition, the original 265-record duplicate scope including PWY0-321, and the reason the incomplete `YeastPathways_PWY-5177` GO-CAM projection remains rejected. This successor preserves those distinctions. It has no dependency on a live 268 worktree and makes no claim that the current baseline has been rebound after merge.

## Native closure and object roles

The initial 70 forward occurrences identify 60 unique objects: 12 proteins, 14 genes, 27 organisms and 7 compounds. All 60 full originals were acquired. These exposed 11 additional gene targets, also acquired. The resulting 71 new originals comprise 12 proteins, 25 genes, 27 organisms and 7 compounds; they contain 864 direct XML slots. Every new original passed receipt/hash/size, query, single-object, frame ID, expected type, META PGDB, full detail, one-result and Pathway Tools 27.0 checks. Both sodium and potassium requests needed the literal plus in the native bare query; the failed percent-encoded requests remain recorded.

The combined 91 initial plus 71 new originals give 162 native objects. Exactly 137 direct occurrences in `gene`, `component`, `components`, `cofactor`, `prosthetic-group`, `regulated-by`, `regulator`, `enzyme`, and `species` resolve to full originals, with zero unclosed targets in that bounded scope. This is not ontology-wide closure. Class parents, inverse reaction/activity/usage backlinks, publications, credits and external issuer records are excluded. The retained all-descendant-reference inventory has 33,568 occurrences, including those excluded contexts; they are not silently treated as resolved.

`results/native-71-object-scope.json` records all 71 object identities, full-source hashes, actual incoming owner/slot contexts, literal cross-reference relationship types, reading scope and evidence implications. `results/native-71-all-direct-slots.json` retains every new direct slot. The type-specific reading projections preserve biological assertions while explicitly excluding metadata/credits, broad inverse links and CML from the human-reading claim. All selected biological projections were read completely. The full original bytes remain available for further checks; this is not a claim of independent acceptance of every embedded assertion.

Several boundaries matter for later curation:

- A protein reached as a complex component does not inherit an isolated catalytic activity automatically. The reaction-associated examples span bacterial, archaeal, yeast, plant and human proteins; their existence does not establish PWY-5177 in every listed organism.
- The native GcdH subunit `MONOMER-5381` points to historical `ORG-5962` (Pseudomonas Sp. K172). Its gene `G-4001` has `ENTREZ:AE016774` as `PART-OF`. This is not an accepted exact gene/protein/modern-strain mapping. `ORG-5962` and `ORG-5970` lack a native NCBI taxonomy cross-reference and have a literal rank of species despite strain-like labels.
- `G1G01-166` identifies native gcdH/PP_0158, positive strand 168404–169585 and product `G1G01-166-MONOMER`; its NCBI Gene/STRING values are leads. `TAX-160488` records the KT2440 strain under the source name Pseudomonas putida. Current issuer taxonomy, assembly and sequence identity remain to be checked.
- AtoB's native specificity, induction and BL21/K-12 identity statements remain native literature-linked assertions. Computational GO/features and direct-assay annotations retain their different evidence codes.
- `SELENOMETHIONINE` is literally a cofactor of `ENZRXN-14343`, a selenium-containing C. kluyveri thiolase example. That activity's physiological direction is synthesis, opposite the pathway's thiolysis orientation. It does not justify free selenomethionine consumption or a universal thiolase requirement.
- ATP, butanoyl-CoA, DTNB, iodoacetamide, K+, Na+ and selenomethionine are forward context objects, not newly added pathway reactants. Iodoacetamide has a structurally suspicious native thiobarbituric-acid synonym; Na+ has a CAS cross-reference requiring exact issuer checking. No synonym or source cross-reference is promoted to validated equivalence.

## 2018 primary evidence

The complete published main text of PMID:29844506 / DOI:10.1038/s41467-018-04513-0 was read from the PMC original, including methods, table, captions and references. The authentic 14-page publisher PDF was rendered; all seven figures and Table 1 were visually inspected. All five publisher-linked supplements were acquired. The full supplementary document text (methods, 13 figure captions, six tables, seven references) was read, and all 13 embedded figures were visually inspected. Both spreadsheet supplements were read through every nonblank rendered worksheet; all three sheet previews in each were inventoried. This is not a hidden-cell/formula/BIFF audit. The short data-description supplement was read in full.

The 37-page published peer-review file was read completely as extracted text, with pages 19, 26, 30 and 33 additionally inspected visually. It is correspondence, not a replacement for the final article. Historical claims changed during review are distinguished from final results. The reading ledger binds the exact originals and derivatives and records unsuccessful extraction attempts.

The 16-row `results/primary-claim-ledger.json` records source hashes, exact figures/sections/table rows, evidence levels and limits. Principal implications are:

- PP0158/gdh deletion supports a KT2440 genetic phenotype on glutarate; the paper's purified-enzyme experiments concern the alternative CsiD/LhgO route. It does not assay purified KT2440 GcdH, physiological ETF transfer or all five PWY-5177 member reactions.
- **The stated complementation inserts are larger than the short plasmid labels suggest.** Supplementary Data 2 specifies `csiD + lhgO` for the csiD-cF/cR primer sets and `gdh + pp0159` for the gdh-cF/cR sets. Growth rescue must retain these construct boundaries. It cannot be presented as single-gene-only rescue. No function is assigned to PP0159 from adjacency or inclusion.
- RT-PCR/qPCR is expression evidence. The final glucose-precultured zero-hour sample was collected immediately after contact with glutarate; it is not a pre-exposure constitutive-expression measurement. No isotope flux tracing was performed.
- CsiD assays, product MS, enzyme selectivity and LhgO turnover support the proposed L-2-HG route. Mass alone does not establish stereochemistry. Ascorbate is an assay activator, and omission of added iron or ascorbate left substantial activity; those controls are not zero-activity requirements.
- Final LhgO FAD-stimulated oxygen reactivity supersedes an earlier correspondence-stage interpretation. Artificial-acceptor assays and oxygen assays are kept distinct, and neither establishes native GcdH electron acceptance.
- The oxygen-only CsiD trace did not measure the O2/glutarate ratio. The authors' likely 1:1 expectation came from enzyme-family chemistry. Figure 7 is an interpreted metabolic network, not a measured stoichiometric or flux reconstitution of PWY-5177.
- Competition, glutarate-production yield and glyoxylate-cycle phenotypes are retained with their strains and conditions. The larger inserts also limit interpretation of the complemented growth comparison. The KT2440 CsiR/glutarate-effector mechanism remains a hypothesis; E. coli regulation is not transferred automatically.
- Historical homolog counts and selected CsiD/LhgO homolog assays are distinct. They are not evidence for a complete GcdH pathway in every homolog-bearing taxon. Source accession and strain oddities remain issuer-check prerequisites.

## 1993 access and reused evidence

The exact DOI PDF endpoint for PMID:8439237 / DOI:10.1007/BF00250279 returned HTTP 200 with publisher HTML, not a PDF. Its abstract and subscription-preview marker were freshly inspected. The file is named `BF00250279.pdf` to preserve the attempted endpoint, and its actual format is explicitly recorded. Its bytes differ from the initial preview, although its access role is the same. Exact DOI/title full-text searches yielded metadata, abstracts and citation lists in this finite attempt, with no acquired full original. No access control bypass was attempted.

The abstract reports anaerobically induced GCD activity in Pseudomonas strains KB740/K172, purified enzyme, ferricenium assays, glutaconyl-CoA decarboxylation and FAD homotetramers. It is insufficient for full methods/figures/assay-control acceptance, precise physiological electron-transfer claims or modern strain/sequence identity.

The initial 2009 GCD paper reading is reused only at its recorded exact source hashes and scope: full main text and three tables as text, four figures visually inspected. This successor does not claim a fresh independent reread or independent acceptance. The initial distinction between a decarboxylating GCD and a nondecarboxylating GCD plus separate decarboxylase remains important. A five-member native pathway is not five independently purified catalysts or an exhaustive elementary mechanism count.

## Remaining prerequisites

1. Independently review both the initial native-definition packet and this source-completion successor before scientific curation.
2. Resolve the strongest native microbial GCD primary support at full-main depth if accessible; otherwise retain the exact abstract-only limit. The 1993 full article remains open. Other native-linked downstream activity papers require claim-specific reading before catalyst or organism-wide transfers.
3. Audit chemistry for all source members and material contexts using actual structures, charge/protonation, stereochemistry and exact issuer records. Generic source strings, class ETF endpoints and labels are insufficient. The parent is separately preparing chemical diagnostics; those mutable results are not accepted evidence in this packet.
4. Resolve exact microbial strain, gene, sequence and protein identities where required. Native PART-OF/RELATED-TO links are not unification. Retain the 2018 genetic evidence level and larger complementation inserts.
5. Complete claim-by-claim coverage for every native member, regulation/cofactor assertion and planned nested mechanism. Preserve source equations and composite versus isolated activity distinctions. The available 2018 results do not close all five reactions in one strain.
6. Rebind duplicates and provenance to the actual merged 265-record baseline and root-owned next worktree before any maintained draft. Existing copies support only the documented finite candidate screen. PWY-301 remains deferred; this task did not reopen it.

The handoff advances native source completeness and primary-reading depth. It leaves those six prerequisites explicit rather than converting bounded source closure into blanket pathway approval.
