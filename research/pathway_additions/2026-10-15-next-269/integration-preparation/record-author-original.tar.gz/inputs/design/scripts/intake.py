from pathlib import Path
import hashlib,json,shutil
O=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
roots=[Path('/private/tmp/'+x) for x in ['pathwaymech-next-269-glutaryl-preparation','pathwaymech-next-269-glutaryl-source-completion','pathwaymech-next-269-root-locator-correction','pathwaymech-next-269-glutaryl-issuer-preparation']]
bind=[]
for root in roots:
 m=json.loads((root/'artifact-manifest.json').read_text()); rows=m['files'] if isinstance(m,dict) else m
 for r in rows:assert sha(root/r['path'])==r['sha256']
 allfiles=[{'path':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(root.rglob('*')) if p.is_file()]
 bind.append({'root':str(root),'manifest_sha256':sha(root/'artifact-manifest.json'),'physical_count':len(allfiles),'files':allfiles})
(O/'inputs/frozen-input-bindings-before.json').write_text(json.dumps(bind,indent=2)+'\n')
copy=[]
def cp(s,d):
 d.parent.mkdir(parents=True,exist_ok=True);assert not d.exists();shutil.copy2(s,d);copy.append({'source':str(s),'path':str(d.relative_to(O)),'sha256':sha(s),'bytes':s.stat().st_size})
for root in roots[:2]:
 for s in sorted((root/'originals').glob('META-*.xml')):cp(s,O/'inputs/native'/s.name)
for root in roots:
 for name in ['HANDOFF.md','ASSESSMENT.md']:
  if (root/name).exists():cp(root/name,O/'inputs/packet-summaries'/root.name/name)
for s in sorted(roots[2].iterdir()):
 if s.is_file():cp(s,O/'inputs/accepted-primary-correction'/s.name)
for rel in ['results/primary-reading-bindings.json','results/PMC2698508-full-page-text.txt','results/five-member-equations.json','results/native-composite-reconciliation.json']:
 cp(roots[0]/rel,O/'inputs/initial-ledgers'/Path(rel).name)
for rel in ['results/162-object-forward-closure.json','results/native-biological-reading-projection.json','results/native-71-object-scope.json']:
 cp(roots[1]/rel,O/'inputs/source-ledgers'/Path(rel).name)
for rel in ['UNRESOLVED.json','results/five-reaction-dispositions.json','results/chemical-issuer-comparisons.json','results/protein-exact-sequence-comparisons.json','results/gene-issuer-status.json']:
 cp(roots[3]/rel,O/'inputs/issuer-preparation'/Path(rel).name)
work=Path('/private/tmp/pathwaymech-next-268-20261015')
for rel in ['.claude/skills/add-pathway/SKILL.md','CLAUDE.md','docs/CAUSAL_GRAPHS.md','docs/CURATION.md','docs/IDENTIFIERS.md','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','src/pathwaymech/reaction_mechanisms.py','src/pathwaymech/biocyc_phenylacetate.py','conf/identifier_sources.json']:
 cp(work/rel,O/'inputs/current-contracts'/rel)
(O/'inputs/copied-input-bindings.json').write_text(json.dumps(copy,indent=2)+'\n')
(O/'inputs/current-contract-baseline.json').write_text(json.dumps({'worktree':str(work),'commit':'ae143113008f8c194748bae322ab80b1853a6d95','tree':'1a0560c741c07fcb7878b1e93d8d38da67b1287c','verified_by':'git rev-parse HEAD HEAD^{tree} read-only; parent released exact committed head','status':'unmerged draft PR622; no actual merged265 rebind yet','copied_contracts':[r for r in copy if '/current-contracts/' in '/'+r['path']]},indent=2)+'\n')
print(json.dumps({'frozen_input_files':sum(b['physical_count'] for b in bind),'native_objects':len(list((O/'inputs/native').glob('*.xml'))),'copied_inputs':len(copy)},indent=2))
