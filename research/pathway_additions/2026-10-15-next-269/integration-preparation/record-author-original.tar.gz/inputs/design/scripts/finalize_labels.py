from pathlib import Path
import json,hashlib
O=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
p=O/'results/all162-node-and-alias-dispositions.json';j=json.loads(p.read_text())
labels={'GLUTARYL-COA-DEHYDROG-RXN':'Glutaryl-CoA dehydrogenation to (E)-glutaconyl-CoA','GLUTACONYL-COA-DECARBOXYLASE-RXN':'Glutaconyl-CoA decarboxylation to crotonyl-CoA','RXN-11667':'Crotonyl-CoA hydration to (S)-3-hydroxybutanoyl-CoA','RXN-11662':'(S)-3-Hydroxybutanoyl-CoA oxidation to acetoacetyl-CoA','ACETYL-COA-ACETYLTRANSFER-RXN':'Acetoacetyl-CoA thiolysis to two acetyl-CoA','GLUTARYL-COA-DEHYDROGENASE-RXN':'Glutaryl-CoA oxidative decarboxylation (native composite context)'}
for n in j:
 if n['native_id']=='FAD':n['category']='cofactor'
 if n['native_id'] in labels:
  n['proposed_display_label']=labels[n['native_id']];n['display_label_authorization']='Existing identifier_policy.yaml contextual_labels rule: MetaCyc namespace, sections record/reactions, record_prefixes MetaCyc. The authority label remains exact native text; this is a source-equation/pathway-orientation display description, not an alias or preferred-name rewrite.'
 if n['native_id']=='RXN-11667':n['label_hazard']='Native direct common-name says dehydrogenase, but the equation is dehydration and PWY-5177 selects hydration. Preserve native authority label; show the contextual hydration display label allowed by existing explicit policy, plus this discrepancy in visible description/evidence.'
p.write_text(json.dumps(j,indent=2)+'\n')
policy=O/'inputs/current-contracts/conf/identifier_policy.yaml'
(O/'results/contextual-label-disposition.json').write_text(json.dumps({'policy':str(policy.relative_to(O)),'sha256':hashlib.sha256(policy.read_bytes()).hexdigest(),'locator':'contextual_labels: namespace MetaCyc; sections record/reactions; record_prefixes MetaCyc','six_equation_scoped_display_labels':labels,'authority_labels':'remain exact native canonical/frame-token values; no new synonym minted','participant_exception':'FAD category is cofactor as required by has_cofactor endpoint contract','no_schema_or_policy_change_required':True},indent=2)+'\n')
