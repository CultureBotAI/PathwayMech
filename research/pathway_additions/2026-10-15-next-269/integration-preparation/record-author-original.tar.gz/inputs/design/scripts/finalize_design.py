from pathlib import Path
from collections import Counter
import hashlib, json, shutil, xml.etree.ElementTree as ET, re, html

O = Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def get(n): return json.loads((O/n).read_text())
def put(n, x): (O/n).write_text(json.dumps(x, indent=2)+'\n')
def clean(s): return html.unescape(re.sub('<[^>]+>', '', s or '')).strip()
objs = {}
for p in sorted((O/'inputs/native').glob('*.xml')):
    n = next(x for x in ET.parse(p).getroot() if x.tag != 'metadata')
    objs[n.get('frameid')] = (n, p)
def evidence(id, loc, claim):
    n,p = objs[id]
    assert len(claim) <= 400
    return {'source':str(p.relative_to(O)), 'source_sha256':sha(p),
            'source_locator':f"/ptools-xml/{n.tag}[@frameid='{id}']/{loc}",
            'source_assertion':claim, 'evidence_class':'source_native_assertion',
            'primary_support':'Not implied by a cited publication or native evidence code.'}

# Preserve the earlier mutable proposal, not an accepted or frozen predecessor.
old = O/'iterations/pre-regulation-expansion'
old.mkdir(parents=True, exist_ok=False)
names = ['all162-node-and-alias-dispositions.json','all29-activity-contexts.json',
         'all10-regulation-contexts.json','proposed-native-edge-inventory.json',
         'native-authority-requirements.json','design-verification-summary.json',
         'all-native-direct-slot-dispositions.json','proposed-native-reference-inventory.json',
         'reference-and-node-authority-union.json']
for name in names: shutil.copyfile(O/'results'/name, old/name)

edges=get('results/proposed-native-edge-inventory.json')
nodes=get('results/all162-node-and-alias-dispositions.json')
activities=get('results/all29-activity-contexts.json')
regs=get('results/all10-regulation-contexts.json')
byid={n['native_id']:n for n in nodes}
ab={a['native_id']:a for a in activities}
selected_regs=[r for r in regs if 'TAX-9606' not in r['species_context']]
activity_ids=sorted({r['regulated_activity'] for r in selected_regs})
assert len(selected_regs)==8 and len(activity_ids)==4
def edge(s,p,o,ev,**kw):
    edges.append({'design_key':f'NE{len(edges)+1:03d}','subject_native_id':s,
                  'predicate':p,'object_native_id':o,'evidence':[ev],
                  'status':'proposed source-native graph claim; not maintained',**kw})
for r in selected_regs:
    assert r['mode']=='-'
    edge(r['regulator'],'inhibits',r['regulated_activity'], evidence(r['native_id'],
        'regulator; regulated-entity; mode; mechanism; citation',
        f"Native regulation {r['native_id']} inhibits enzyme-specific activity {r['regulated_activity']} by {r['regulator']}. Enzyme context: {r['enzyme_context']}. Preserve conditions and native units; this is not inhibition of every catalyst of the generic reaction."),
        regulation_native_id=r['native_id'], mechanism=r['mechanism'],
        enzyme_context=r['enzyme_context'], native_generic_reaction_context=r['reaction_context'])
    r['disposition']='propose_exact_activity_inhibition_edge'
    r['reason']='Exact native activity is a molecular_activity participant. Regulation stays on this source target; no equivalence to its generic Reaction or whole-pathway flux is asserted.'
for id in activity_ids:
    a=ab[id]
    edge(a['enzyme'],'enables',id,evidence(id,'enzyme; reaction; reaction-direction',
        f"Native enzyme link identifies {a['enzyme']} as enabling exact activity {id}. The generic reaction link is retained as context, not identity equivalence. Activity direction: {a['source_activity_direction'] or 'unspecified'}; no route-direction claim is added."),
        native_activity_direction=a['source_activity_direction'],
        native_generic_reaction_context=a['reaction'])
    a['exact_activity_node_proposed']=True
    a['generic_reaction_edge_disposition']=a['disposition']
    if id=='THLCLOS-ENZRXN':
        a['disposition']='exact_activity_context_with_regulation; opposite_direction_excludes_route_generic_catalysis'
n,p=objs['THLCLOS-CPLX']
slots=[s for s in n if s.tag in ('component','components')]
assert len(slots)==1
sub=next(x for x in slots[0] if x.get('frameid'))
assert sub.get('frameid')=='THLCLOS-MONOMER'
co=slots[0].findtext('coefficient') or sub.findtext('coefficient') or 'unspecified'
edge('THLCLOS-CPLX','has_part','THLCLOS-MONOMER',evidence('THLCLOS-CPLX',slots[0].tag+'[1]',
    f"Native THLCLOS-CPLX includes THLCLOS-MONOMER; source component coefficient {co}. This supports assembly context for its regulated condensation activity, not independent subunit catalysis or route thiolysis."),native_component_coefficient=co)
graphids={e[k] for e in edges for k in ['subject_native_id','object_native_id']}
assert len(edges)==80 and len(graphids)==60
for n in nodes:
    if n['native_id'] in graphids:
        n['graph_disposition']='proposed_native_graph_node'
        if n['native_id'] in activity_ids:
            n['reason']='Exact enzyme-specific native activity, retained as participants/category molecular_activity; enables and regulation attach here. Generic reaction association remains description/evidence only.'
            n['proposed_collection']='participants'
    if n['tag']=='Regulation':
        r=next(r for r in regs if r['native_id']==n['native_id'])
        n['reason']=r['reason']
    n['alias_acceptance']='Native IDs retained. Selected issuer comparisons are independently accepted only within their stated chemical/taxon/protein bounds; all other dblink values remain unverified source assertions. No public alias replaces the proposed native node.'
put('results/all162-node-and-alias-dispositions.json',nodes)
put('results/all29-activity-contexts.json',activities)
put('results/all10-regulation-contexts.json',regs)
put('results/proposed-native-edge-inventory.json',edges)
slots=get('results/all-native-direct-slot-dispositions.json')
for s in slots:
    if s['native_id'] in activity_ids and s['tag'] in ['enzyme','reaction','reaction-direction']:
        s['disposition']='supports_exact_activity_node_and_enables_context; generic Reaction remains distinct'
    if s['native_id'] in {r['native_id'] for r in selected_regs} and s['tag'] in ['regulator','regulated-entity','mode','mechanism','citation','ki']:
        s['disposition']='supports_exact_activity_inhibition_edge_and_retained_conditions'
put('results/all-native-direct-slot-dispositions.json',slots)

requirements=get('results/native-authority-requirements.json')
for r in requirements:
    r['graph_proposed']=r['id'].split(':',1)[1] in graphids
    r['external_alias_status']=byid[r['id'].split(':',1)[1]]['alias_acceptance']
    if r['native_tag']=='Enzymatic-Reaction':
        r['proposed_role']='participants/category molecular_activity when selected; otherwise evidence/context only'
        r['requirement']='Exact native activity identity and all enzyme/reaction/regulation/evidence slots require bounded typed-source coverage. Do not authorize this activity as a generic Reaction or silently reuse phenylacetate-specific role ownership.'
put('results/native-authority-requirements.json',requirements)
refs={}
for e in edges:
    for ev in e['evidence']:
        p=O/ev['source']; root=ET.parse(p).getroot();n=next(x for x in root if x.tag!='metadata');id='MetaCyc:'+n.get('frameid')
        refs[id]={'reference_id_candidate':id,'source_path':ev['source'],'source_sha256':sha(p),
                  'source_version':'MetaCyc Pathway Tools 27.0',
                  'source_self_reported_xml_base':root.get('{http://www.w3.org/XML/1998/namespace}base'),
                  'source_role':'issuing native object; not a quotation from embedded cited papers',
                  'edge_design_keys':refs.get(id,{}).get('edge_design_keys',[])+[e['design_key']]}
put('results/proposed-native-reference-inventory.json',list(refs.values()))
snap=get('inputs/current-contracts/data/identifier_authorities/sources.json')
union={'MetaCyc:'+i for i in graphids}|set(refs)
put('results/reference-and-node-authority-union.json',{
    'graph_ids':len(graphids),'native_reference_ids':len(refs),'union_ids':len(union),
    'ids':[{'id':i,'graph_node':i.split(':',1)[1] in graphids,'evidence_reference':i in refs,'in_current_snapshot':i in snap['terms']} for i in sorted(union)],
    'limit':'Native graph and evidence-source union only; one proposed NCBI taxon is accounted separately. Full 162-object source context is retained; not all context objects are graph nodes.'})
summary=get('results/design-verification-summary.json')
summary.update(proposed_graph_nodes=len(graphids),proposed_edges=len(edges),
    predicate_counts=dict(Counter(e['predicate'] for e in edges)),
    regulations_context_only=2,regulations_exact_activity_graph=8,exact_activity_participants=4,
    activity_dispositions=dict(Counter(a['disposition'] for a in activities)),
    proposed_native_ids_currently_present=sum(r['graph_proposed'] and r['current_snapshot_present'] for r in requirements),
    proposed_native_ids_requiring_new_authority_terms=sum(r['graph_proposed'] and not r['current_snapshot_present'] for r in requirements),
    native_evidence_references=len(refs),native_node_reference_union=len(union),
    proposed_microbe_taxon_declarations=1,declared_nodes_including_proposed_taxon=61)
put('results/design-verification-summary.json',summary)
put('results/regulation-representation-decision.json',{
    'superseded':'iterations/pre-regulation-expansion retains an unfrozen 50-node/67-edge proposal. Its blanket context-only regulation rationale was too restrictive.',
    'contract':'Current NODE_ROLES maps native_phenylacetate_activity to participants/molecular_activity; schema permits enables and inhibits between declared nodes. New glutaryl typed-source roles must independently preserve this distinction.',
    'decision':'Eight microbial regulations on four exact native activities; two human mitochondrial thiolase ion regulations retained as nonmicrobial context. No activity–reaction identity edge.',
    'arithmetic':'67 + 8 inhibits + 4 enables + 1 THLCLOS complex has_part = 80 edges; 50 + 4 activities + 4 regulators + 2 THLCLOS complex/subunit = 60 native nodes.',
    'extra_complex_component_coefficient':co,
    'activity_ids':activity_ids,
    'regulation_ids':[r['native_id'] for r in selected_regs],
    'excluded_human_regulations':['REG-12707','REG-12708'],
    'units_hazard':'REG-14465 native ki=120 units=&micro;mole is retained literally. Do not silently convert to micromolar or assert an experimentally verified unit.'})

# All embedded publication objects and comment links are leads, not full reading.
pubs={}
for id,(n,p) in objs.items():
    for q in n.iter('Publication'):
        pid=q.findtext('pubmed-id')
        if not pid and (q.get('frameid') or '').startswith('PUB-'):
            suffix=q.get('frameid')[4:]
            if suffix.isdigit():pid=suffix
        if not pid:continue
        row=pubs.setdefault(pid,{'pmid':pid,'url':'https://pubmed.ncbi.nlm.nih.gov/'+pid+'/',
                                 'metadata_variants':[],'native_occurrences':[],'reading_status':'native citation lead only unless separately bound prior reading'})
        meta={k:[x.text for x in q.findall(k)] for k in ['title','author','year','source'] if q.findall(k)}
        if meta and meta not in row['metadata_variants']:row['metadata_variants'].append(meta)
        row['native_occurrences'].append({'native_object':id,'source':str(p.relative_to(O)),'sha256':sha(p),'kind':'embedded Publication element'})
    for s in n.findall('comment'):
        for pid in sorted(set(re.findall(r'pubmed/(\d+)',s.text or ''))):
            row=pubs.setdefault(pid,{'pmid':pid,'url':'https://pubmed.ncbi.nlm.nih.gov/'+pid+'/', 'metadata_variants':[],'native_occurrences':[],'reading_status':'native comment lead only; title not invented'})
            row['native_occurrences'].append({'native_object':id,'source':str(p.relative_to(O)),'sha256':sha(p),'kind':'direct comment PMID link'})
put('results/native-publication-lead-inventory.json',list(pubs.values()))
ranked=[
 (1,'GAP-GCD-1993',['8439237'],['ENZRXN-5541','CPLX-4041'],
  'Obtain the full 1993 main to check K172 versus KB740 purification, FAD stoichiometry, enzyme assay acceptor and exact decarboxylation evidence. Existing abstract and native structured assertion remain explicitly separate.',
  'Native composite catalysis and FAD edges remain source-only. No assignment to isolated half-reactions, current K172 sequence or a physiological ETF partner.'),
 (2,'GAP-SELENIUM',['6956900','2857719','6149704'],['ENZRXN-14343','CPLX-7510'],
  'Read the 1982 selenium-containing thiolase study together with the native-cited 1985 reassessment and 1984 purification. PMID2857719 is an exact native comment lead; no title metadata occurs in the inspected 162 originals.',
  'No selenium cofactor edge. Native cofactor assertion and later native comment denying a required biological function are both retained; enzyme physiology is condensation, not asserted route thiolysis.'),
 (3,'GAP-HYDRATASE',['678016','4150713','5057466'],['ENZRXN-12257','CPLX-6989','ENZRXN-41','CPLX-41','REG-10076'],
  'Check P. putida hydratase substrate/stereochemistry and strain scope; separately read C. acetobutylicum crotonase and crotonyl-CoA inhibition conditions. Preserve the native 1972 title spelling cortonase.',
  'Source-only hydratase and activity-specific inhibition may be retained. P. putida species evidence is not KT2440 identity or proof of a complete glutaryl route.'),
 (4,'GAP-DEHYDROGENASE',['1444364','11946544','16346566'],['ENZRXN-18144','CPLX-7035','ENZRXN-14344','ENZRXN-20211'],
  'Read the NAD-linked 3-hydroxybutyryl-CoA dehydrogenase assays and particulate/crude-extract studies at their actual purification depth; distinguish NAD and NADP, oxidative versus biosynthetic assay direction and exact strains.',
  'Do not upgrade native catalysis annotations to purified NAD-specific oxidative-route support or transfer enzyme identity between clostridia.'),
 (5,'GAP-ECOLI-THIOLASE',['9904','236278','27380370'],['ACETYL-COA-ACETYLTRANSFER-ENZRXN','ACETYL-COA-ACETYLTRANSFER-CPLX','REG0-7500'],
  'Read original cleavage/condensation assays, acetoacetyl-CoA inhibition, and structural construct details. Reconcile E. coli B, BL21/construct, and native K-12 annotations explicitly before sequence-specific claims.',
  'Source-only catalysis and exact activity inhibition remain bounded; no strain-level transfer or new elementary mechanism.'),
 (6,'GAP-REGULATION',['16347774','11914342'],['THLCLOS-ENZRXN','THLCLOS-CPLX','REG-13248','REG-7495','REG-7496','REG-7497','REG-7498','ENZRXN-22164','REG-14465'],
  'Check ATCC824 thiolase inhibitors/assay direction and recombinant E. faecalis bifunctional MvaE CoA inhibition. Preserve source Ki unit anomaly (120 micro-mole) until the paper is inspected.',
  'Eight microbial native regulation edges target exact activity nodes. THLCLOS physiological condensation stays separate from pathway-selected thiolysis; no universal generic-reaction inhibition.'),
 (7,'GAP-ARCHAEAL-MULTIFUNCTION',['18079405','21169482','24532060'],['ENZRXN-14679','ENZRXN-14680','ENZRXN-14681','MONOMER-13738'],
  'Check archaeal downstream activity assays and multifunctional enzyme context in the carbon-fixation route; identify construct and substrate scopes before primary promotion.',
  'A native catalyst annotation on a shared reaction does not establish glutaryl-CoA degradation in Metallosphaera sedula.'),
 (8,'GAP-2010-KINETICS-ASSIGNED',['20486657'],[],
  '2010 UniProt C3UVB0 kinetic citation is already assigned to next268_current_bigg_completion. No acquisition or new reading performed here.',
  'Retain IP08 and 2009 assay values separately until that independent successor is reviewed. Do not silently correct the source database.')]
out=[]
for rank,id,pmids,targets,read,limit in ranked:
    out.append({'rank':rank,'id':id,'native_targets':targets,'publication_leads':[pubs.get(p,{'pmid':p,'url':'https://pubmed.ncbi.nlm.nih.gov/'+p+'/','metadata_status':'exact lead from frozen issuer preparation; no new metadata lookup'}) for p in pmids], 'bounded_next_reading':read,'current_disposition':limit,'blocks_faithful_source_only_record':False})
put('results/ranked-primary-reading-gaps.json',out)

# Bind accepted independent issuer review without absorbing a mutable successor.
R=Path('/private/tmp/pathwaymech-next-269-independent-glutaryl-issuer-review')
expected={'artifact-manifest.json':'a8f25883dee855189ca74879e004e1ed1074e4f8443a0770ce5f6c1c8837aad2',
 'freeze-proof.json':'189dd28f9fc464c9d21a46ddf2e1b716d47a16ddb870fa04efded1ee19bad8bd',
 'HANDOFF.md':'84f39fadaca50d230cafeafb604a17bbece7aede85f580991e616967c828e4a6',
 'review.json':'024d0f596dfa98ed37eb6076ba4d84a576e2c2fd812440469ed62c361a68bd3f'}
for n,h in expected.items():assert sha(R/n)==h
files=[{'path':str(p.relative_to(R)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(R.rglob('*')) if p.is_file()]
assert len(files)==45
m=json.loads((R/'artifact-manifest.json').read_text())
rows=m if isinstance(m,list) else m['files']
for r in rows: assert sha(R/r['path'])==r['sha256']
put('inputs/accepted-issuer-review-bindings.json',{'root':str(R),'files':files,'scope':'Root accepted bounded issuer review; fresh integrity checked here, biological checks reused rather than rerun.'})
dest=O/'inputs/accepted-issuer-review';dest.mkdir()
bindings=get('inputs/copied-input-bindings.json')
for name in ['HANDOFF.md','REVIEW.md','review.json','reaction-review.json','biological-identity-review.json','artifact-manifest.json','freeze-proof.json']:
    p=R/name;q=dest/name;shutil.copyfile(p,q)
    bindings.append({'source':str(p),'path':str(q.relative_to(O)),'sha256':sha(q),'bytes':q.stat().st_size})
I=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
for name in ['NCBI-taxonomy-44139.xml','DSM-6984.html']:
    p=I/'originals'/name;q=dest/name;shutil.copyfile(p,q)
    bindings.append({'source':str(p),'path':str(q.relative_to(O)),'sha256':sha(q),'bytes':q.stat().st_size})
put('inputs/copied-input-bindings.json',bindings)
base=get('inputs/current-contract-baseline.json')
base['copied_contracts']=[b for b in bindings if b['path'].startswith('inputs/current-contracts/')]
base['status']='PR622 released committed baseline, later parent reports ready and auto-merge enabled; actual merged265 rebind still not performed here.'
put('inputs/current-contract-baseline.json',base)
put('results/taxon-design.json',{
 'proposed_taxa':[{'id':'NCBITaxon:44139','label':'Thauera aromatica K172',
 'native_scope':'PWY-5177 direct species ORG-5962; historical Pseudomonas sp. K172 independently reconciled to this strain.',
 'evidence':['inputs/native/META-PWY-5177.xml','inputs/native/META-ORG-5962.xml','inputs/accepted-issuer-review/NCBI-taxonomy-44139.xml','inputs/accepted-issuer-review/DSM-6984.html'],
 'snapshot':'Already present in copied pinned NCBI Taxonomy 2026-07-12 ontology snapshot; recheck merged baseline and producer/consumer integrity before integration.',
 'limit':'Source pathway association is not independent demonstration of all five reactions, physiological ETF, or flux in one strain.'}],
 'other26_native_organisms':'All remain explicitly scoped in all27-organism-contexts.json; no automatic whole-route taxon expansion from catalyst species.',
 'KT2440':'Retain exact taxon and primary genetic evidence in description/research context. Do not turn 2018 gdh+pp0159 complementation into proof of all five native members.',
 'record_references':'46 native edge references plus NCBITaxon:44139 taxon reference proposed; named primary references may support only the explicit descriptive contexts with bound locators.'})
print(json.dumps(summary,indent=2))
