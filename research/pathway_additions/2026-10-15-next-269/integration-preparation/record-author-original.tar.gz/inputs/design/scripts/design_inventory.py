from pathlib import Path
from collections import Counter,defaultdict
import hashlib,html,json,re,xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,x):(O/'results'/n).write_text(json.dumps(x,indent=2)+'\n')
def text(x):return html.unescape(re.sub('<[^>]+>','',x or '')).strip()
obj={};meta={}
for p in sorted((O/'inputs/native').glob('*.xml')):
 root=ET.parse(p).getroot();nodes=[x for x in root if x.tag!='metadata'];assert len(nodes)==1;n=nodes[0];id=n.get('frameid');assert id not in obj;obj[id]=n
 meta[id]={'native_id':id,'curie_candidate':'MetaCyc:'+id,'tag':n.tag,'source':str(p.relative_to(O)),'sha256':sha(p),'direct_slot_counts':dict(Counter(x.tag for x in n)),'direct_common_name':n.findtext('common-name'),'native_identity':'complete issuing META original retained; new maintained adapter promotion pending','category':('complex' if any(x.get('frameid')=='Protein-Complexes' for x in n.findall('parent/Protein')) else 'protein') if n.tag=='Protein' else {'Compound':'small_molecule','Reaction':'molecular_activity','Enzymatic-Reaction':'molecular_activity','Gene':'gene','Pathway':'pathway'}.get(n.tag),'candidate_aliases':[{c.tag:c.text for c in d} for d in n.findall('dblink')]}
def refs(id,slot):return [c.get('frameid') for s in obj[id].findall(slot) for c in s if c.get('frameid')]
def sc(id):
 o=obj[id];return {'evidence_slots':[ET.tostring(s,encoding='unicode') for s in o.findall('evidence')], 'comments':[s.text for s in o.findall('comment')], 'direct_citations':[ET.tostring(s,encoding='unicode') for s in o.findall('citation')]}
def evidence(id,loc,claim):
 assert len(claim)<=400
 return {'source':meta[id]['source'],'source_sha256':meta[id]['sha256'],'source_locator':f"/ptools-xml/{obj[id].tag}[@frameid='{id}']/{loc}",'source_assertion':claim,'evidence_class':'source_native_assertion','primary_support':'not implied by a cited publication or native evidence code'}
activity=[]
for id in sorted(obj):
 if obj[id].tag!='Enzymatic-Reaction':continue
 enz=refs(id,'enzyme');rxn=refs(id,'reaction');assert len(enz)==len(rxn)==1
 protein=enz[0];taxa=refs(protein,'species');direction=obj[id].findtext('reaction-direction')
 excluded_taxon=bool(set(taxa)&{'TAX-9606','ORG-5993'})
 opposing=rxn[0]=='ACETYL-COA-ACETYLTRANSFER-RXN' and direction=='PHYSIOL-LEFT-TO-RIGHT'
 disposition='context_only_nonmicrobial_catalyst' if excluded_taxon else 'context_only_opposite_physiological_direction' if opposing else 'propose_source_only_catalyst_edge'
 activity.append({**meta[id],'enzyme':protein,'reaction':rxn[0],'species_native_ids':taxa,'species_labels':[text(obj[t].findtext('common-name')) for t in taxa],'source_activity_direction':direction,'physiologically_relevant':obj[id].findtext('physiologically-relevant'),'cofactors':refs(id,'cofactor'),'regulation_ids':refs(id,'regulated-by'),'scope':sc(id),'disposition':disposition,'qualifier':'Catalysis annotation applies to this exact source activity and its conditions. It is not evidence of the whole pathway in the enzyme taxon or of the pathway-selected flux.'})
put('all29-activity-contexts.json',activity)
proteins=[]
for id in sorted(obj):
 if obj[id].tag=='Protein':proteins.append({**meta[id],'species':refs(id,'species'),'genes':refs(id,'gene'),'components':[ET.tostring(s,encoding='unicode') for s in obj[id] if s.tag in ['component','components']],'cofactor':refs(id,'cofactor'),'prosthetic_group':refs(id,'prosthetic-group'),'class':obj[id].get('class'),'activity_contexts':[a['native_id'] for a in activity if a['enzyme']==id],'scope':sc(id)})
put('all42-protein-contexts.json',proteins)
reg=[]
for id in sorted(obj):
 if obj[id].tag!='Regulation':continue
 target=refs(id,'regulated-entity');regulator=refs(id,'regulator');assert len(target)==len(regulator)==1
 a=next(a for a in activity if a['native_id']==target[0])
 reg.append({**meta[id],'regulator':regulator[0],'regulated_activity':target[0],'enzyme_context':a['enzyme'],'reaction_context':a['reaction'],'species_context':a['species_native_ids'],'mode':obj[id].findtext('mode'),'mechanism':obj[id].findtext('mechanism'),'all_direct_slots':[ET.tostring(s,encoding='unicode') for s in obj[id]],'disposition':'retain_context_no_positive_graph_edge','reason':'Target is enzyme-specific activity, not universal reaction inhibition. Current first design declares source reactions and proteins, not a new equivalence between native activity and reaction. Preserve complete target, mechanism, conditions and units in evidence ledger.'})
put('all10-regulation-contexts.json',reg)
for tag,name in [('Gene','all25-gene-contexts.json'),('Organism','all27-organism-contexts.json'),('Compound','all20-compound-contexts.json')]:
 put(name,[{**meta[id],'direct_slots':[ET.tostring(s,encoding='unicode') for s in obj[id]],'disposition':'source context and alias candidate; no automatic public mapping or whole-route claim'} for id in sorted(obj) if obj[id].tag==tag])
# Finite graph proposal: all source-native members, complete material occurrences, source order, composite context.
rows=json.loads((O/'inputs/initial-ledgers/five-member-equations.json').read_text())['rows'];members={r['frame'] for r in rows};corematerials=set();edges=[];nodes={'PWY-5177'}
def edge(s,p,o,ev,**kw):
 edges.append({'design_key':f'NE{len(edges)+1:03d}','subject_native_id':s,'predicate':p,'object_native_id':o,'evidence':[ev],'status':'proposed source-native graph claim; not maintained',**kw});nodes.update([s,o])
for r in rows:
 id=r['frame'];edge('PWY-5177','has_part',id,evidence('PWY-5177','reaction-list',f"The native PWY-5177 reaction-list includes {id}."))
 q=r['equation'];q=q if r['selected_direction']=='L2R' else {'left':q['right'],'right':q['left']}
 for side,pred in [('left','consumes'),('right','produces')]:
  for t in q[side]:
   mid=t['id'];corematerials.add(mid);s,o=(mid,id) if side=='left' else (id,mid)
   ev=evidence(id,t['slot'],f"Native {t['slot']} contains {t['coefficient']} {mid}; PWY-5177 selects {r['selected_direction']}. The displayed route edge follows that selection; the reaction's original direction remains metadata.")
   edge(s,pred,o,ev,stoichiometric_coefficient=t['coefficient'],coefficient_storage='edge description/evidence; top-level closed Edge has no coefficient field',native_source_direction=r['source_direction'],pathway_selected_direction=r['selected_direction'])
for i,s in enumerate(obj['PWY-5177'].findall('reaction-ordering'),1):
 target=s.find('Reaction').get('frameid');prev=s.find('predecessor-reactions/Reaction').get('frameid')
 edge(prev,'precedes',target,evidence('PWY-5177',f'reaction-ordering[{i}]',f"Native reaction-ordering names {prev} as a predecessor of {target}. This does not establish channeling, temporal kinetics or physiological flux."))
comp='GLUTARYL-COA-DEHYDROGENASE-RXN'
for sub in refs(comp,'reaction-list'):edge(comp,'has_part',sub,evidence(comp,'reaction-list',f"The native composite lists {sub} as a constituent. The composite is context, not a sixth PWY-5177 member."))
for side,pred in [('left','consumes'),('right','produces')]:
 for i,slot in enumerate(obj[comp].findall(side),1):
  target=next(x for x in slot if x.get('frameid'));mid=target.get('frameid');co=slot.findtext('coefficient') or target.findtext('coefficient') or '1';co=int(float(co))
  s,o=(mid,comp) if side=='left' else (comp,mid)
  edge(s,pred,o,evidence(comp,f'{side}[{i}]',f"The native composite {side}[{i}] contains {co} {mid}. Preserve its whole equation and activity attachments; do not transfer catalysts to isolated constituents."),stoichiometric_coefficient=co,coefficient_storage='edge description/evidence; no top-level coefficient field')
for a in activity:
 if a['disposition']!='propose_source_only_catalyst_edge':continue
 ev=evidence(a['native_id'],'enzyme; reaction; reaction-direction; evidence',f"Native activity {a['native_id']} connects enzyme {a['enzyme']} to reaction {a['reaction']}. Activity direction: {a['source_activity_direction'] or 'unspecified'}. This is source annotation, not a new purified-protein or full-route assertion.")
 edge(a['enzyme'],'catalyzes',a['reaction'],ev,activity_context=a['native_id'],activity_direction=a['source_activity_direction'],primary_support_status='source only; native evidence codes retained in all29-activity-contexts.json')
selected_proteins={x for x in nodes if x in obj and obj[x].tag=='Protein'}
for id in sorted(selected_proteins):
 for slotname in ['component','components']:
  for i,slot in enumerate(obj[id].findall(slotname),1):
   for c in slot:
    if not c.get('frameid'):continue
    mid=c.get('frameid');co=slot.findtext('coefficient') or c.findtext('coefficient') or 'unspecified'
    edge(id,'has_part',mid,evidence(id,f'{slotname}[{i}]',f"Native complex {id} includes {mid}; source component coefficient {co}. Component membership does not make the subunit an independently demonstrated catalyst."),native_component_coefficient=co)
edge('CPLX-4041','has_cofactor','FAD',evidence('ENZRXN-5541','cofactor',"Native GcdH activity ENZRXN-5541 lists FAD as a cofactor of CPLX-4041. This does not identify the external physiological electron-transfer partner or equate FAD with whole ETF."),primary_support_status='compatible with1993 abstract-only FAD report; no full-main upgrade')
assert len(coremater:=corematerials)==14
assert sum(e['predicate'] in ['consumes','produces'] and (e['subject_native_id'] in members or e['object_native_id'] in members) for e in edges)==20
assert all(e['subject_native_id'] in obj and e['object_native_id'] in obj for e in edges)
assert not any(e['predicate']=='catalyzes' and e['object_native_id'] in ['GLUTARYL-COA-DEHYDROG-RXN','GLUTACONYL-COA-DECARBOXYLASE-RXN'] for e in edges)
assert len({x['design_key'] for x in edges})==len(edges)
put('proposed-native-edge-inventory.json',edges)
# Every native object receives a positive or contextual disposition; no implicit disappearance.
activity_by={a['native_id']:a for a in activity};reg_by={r['native_id']:r for r in reg}
allnodes=[]
for id in sorted(obj):
 m=meta[id].copy();typ=obj[id].tag
 m['graph_disposition']='proposed_native_graph_node' if id in nodes else 'context_only_no_positive_graph_node'
 m['label_rule']='decoded direct common-name only; if absent use exact native frame ID; never borrow nested labels or silently fix source nomenclature'
 m['proposed_native_label']=text(m['direct_common_name']) if m['direct_common_name'] else id
 m['alias_acceptance']='all direct dblink values retained as native assertions only; selected12compound and namedstrain/protein issuer assessment awaits separate acceptance; no unreviewed public replacement'
 if id=='RXN-11667':m['label_hazard']='Literal source common-name is dehydrogenase, while equation is dehydration with route-selected hydration. Preserve literal authority label and put exact equation/correction warning in description; any alternative display-label policy needs separately reviewed authority handling.'
 if typ=='Enzymatic-Reaction':m['reason']=activity_by[id]['disposition']+'; remains evidence coordinate, not declared equivalent to a Reaction CURIE'
 elif typ=='Regulation':m['reason']=reg_by[id]['reason']
 elif typ=='Gene':m['reason']='Gene-product links retained in context ledger; no encodes predicate in closed contract and no invented gene enables enzyme relation.'
 elif typ=='Organism':m['reason']='Native species/strain context retained; do not treat a catalyst species as whole-route proof or native TAX alias as independently resolved NCBI taxon. Named selected mappings remain review-gated.'
 elif id in ['RXN-20154','RXN-20155']:m['reason']='Thiolase constituent reactions retained as context; bound-state full originals PROT-CYS and Protein-S-Acetyl-Cysteines not present in finite162-object packet; no nested graph or invented counterpart.'
 elif id not in nodes:m['reason']='Retained source context outside bounded positive graph; inspect incident activity/regulation/gene/species rows. No source fact is deleted.'
 else:m['reason']='Source-native material/member/composite/catalyst/composition/cofactor role; complete source assertion retained.'
 allnodes.append(m)
put('all162-node-and-alias-dispositions.json',allnodes)
# Complete slot accounting includes ignored biological/backlink/context fields without pretending to graph them.
slotrows=[]
for id in sorted(obj):
 count=Counter()
 for slot in obj[id]:
  count[slot.tag]+=1;tag=slot.tag
  disposition='retained_source_context_no_positive_edge'
  if tag in ['credits','creation-date','last-modified']:disposition='provenance_metadata'
  elif tag in ['cml','inchi','inchi-key','dblink','common-name','synonym','parent','molecular-weight','monoisotopic-mw']:disposition='identity_structure_or_class_context; no automatic public mapping'
  elif tag in ['appears-in-left-side-of','appears-in-right-side-of','in-pathway','component-of','product','catalyzes','regulates','super-pathways','pathway-link']:disposition='inverse_or_adjacent_context; only explicitly selected sourcegraph roles promoted'
  elif any(e['evidence'][0]['source']==meta[id]['source'] and (e['evidence'][0]['source_locator'].split('/')[-1].startswith(tag) or tag in e['evidence'][0]['source_locator'].split('/')[-1].split('; ')) for e in edges):disposition='supports_proposed_edge_or_its_exact_context'
  slotrows.append({'native_id':id,'tag':tag,'occurrence':count[tag],'source_sha256':meta[id]['sha256'],'locator':f"/ptools-xml/{obj[id].tag}[@frameid='{id}']/{tag}[{count[tag]}]",'xml':ET.tostring(slot,encoding='unicode'),'disposition':disposition})
put('all-native-direct-slot-dispositions.json',slotrows)
# Actual current authority presence, never identity acceptance from cache membership alone.
terms={}
for name in ['sources','ontology']:
 data=json.loads((O/f'inputs/current-contracts/data/identifier_authorities/{name}.json').read_text())
 for id,t in data['terms'].items():terms[id]={'snapshot':name,'term':t}
requirements=[]
for n in allnodes:
 key=n['curie_candidate'];existing=terms.get(key)
 requirements.append({'id':key,'graph_proposed':n['native_id'] in nodes,'native_tag':n['tag'],'source_original':n['source'],'source_sha256':n['sha256'],'current_snapshot_present':existing is not None,'existing_snapshot_entry':existing,'requirement':'preserve existing authoritative term and provenance; compare native current27 bytes separately before additive use' if existing else 'new bounded native profile/metadata and exactoriginal-byte producer/consumer replay required before maintainedpromotion','public_aliases':n['candidate_aliases'],'external_alias_status':n['alias_acceptance']})
put('native-authority-requirements.json',requirements)
summary={'native_objects':len(obj),'types':dict(Counter(n.tag for n in obj.values())),'source_members':len(members),'source_material_occurrences':20,'source_material_ids':len(coremater),'activities':len(activity),'activity_dispositions':dict(Counter(a['disposition'] for a in activity)),'regulations_context_only':len(reg),'proposed_graph_nodes':len(nodes),'proposed_edges':len(edges),'predicate_counts':dict(Counter(e['predicate'] for e in edges)),'complete_native_direct_slots':len(slotrows),'proposed_native_ids_currently_present':sum(r['current_snapshot_present'] and r['graph_proposed'] for r in requirements),'proposed_native_ids_requiring_new_authority_terms':sum(not r['current_snapshot_present'] and r['graph_proposed'] for r in requirements),'nested_mechanisms':'none proposed in first boundedcuration; native members already preserveGCD substeps; thiolaseboundstate prerequisites remainopen','primary_graph_edges':'no new primary-only positive graph edge claimed;2018 genetic/context ledger cannot be promoted to exactETF catalysis','no_record_or_adapter_written':True}
put('design-verification-summary.json',summary);print(json.dumps(summary,indent=2))
