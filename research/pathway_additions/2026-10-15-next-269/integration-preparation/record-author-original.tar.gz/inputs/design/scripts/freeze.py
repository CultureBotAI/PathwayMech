from pathlib import Path
from datetime import datetime, timezone
import hashlib,json
O=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'artifact-manifest.json').exists()
assert not (O/'freeze-proof.json').exists()
verification=json.loads((O/'results/final-verification.json').read_text())
assert verification['passed']
assert verification['physical_frozen_input_count']==959
assert verification['copied_inputs_verified']==215
excluded=['artifact-manifest.json','freeze-proof.json']
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and str(p.relative_to(O)) not in excluded]
manifest={'owner':str(O),'scope':'Bounded PWY-5177 native graph/curation design; no maintained implementation',
          'files':files,'listed_files':len(files),'listed_bytes':sum(r['bytes'] for r in files),'self_excluded':excluded}
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof={'frozen_utc':datetime.now(timezone.utc).isoformat(),'owner':str(O),
       'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),
       'design_sha256':sha(O/'DESIGN.md'),'verification_sha256':sha(O/'results/final-verification.json'),
       'listed_files':len(files),'physical_files':len(files)+2,'self_excluded':excluded,
       'all_work_terminal':True,'frozen_inputs_unchanged':959,'copied_inputs_exact':215}
(O/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
for r in files:assert sha(O/r['path'])==r['sha256']
assert len([p for p in O.rglob('*') if p.is_file()])==len(files)+2
print(json.dumps({**proof,'freeze_sha256':sha(O/'freeze-proof.json'),'listed_bytes':manifest['listed_bytes']},indent=2))
