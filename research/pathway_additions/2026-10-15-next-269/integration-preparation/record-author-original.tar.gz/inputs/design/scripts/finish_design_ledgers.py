from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def put(name,x):(O/'results'/name).write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ledger=json.loads((O/'inputs/accepted-primary-correction/primary-claim-ledger.json').read_text())
rows=[]
for c in ledger['claims']:
 i=int(c['id'].split('P')[-1])
 if i in [1,2,3]:d='retain KT2440 genetic/construct/expression context; no purifiedGcdH or exactETF catalysis edge'
 elif i in [4,5,6,7,8,9]:d='retain as alternative CsiD/LhgO route context; outside PWY5177 native membership and positive graph'
 elif i in [10,11,12]:d='retain condition-specific physiological/network context; no new material, member or measuredflux edge'
 elif i==13:d='retain proposed CsiR/glutarate hypothesis in contextual notes; no positive regulator edge'
 elif i==14:d='retain historicalhomology/selectedotherenzyme assay scope; no whole-route taxon expansion'
 elif i==15:d='retain abstract-only1993 support; compatibleFAD context does not upgrade native activity edges to full-main primary acceptance'
 else:d='retain explicit finite coverage limit for allfive native members'
 rows.append({'claim_id':c['id'],'corrected_claim':c,'accepted_correction_status':'parent explicitly reports independently accepted corrected ledger; embedded historical author disposition preserved unchanged','current_positive_primary_graph_edge':False,'design_disposition':d})
put('all16-corrected-primary-dispositions.json',rows)
primary2009=[
 {'id':'P2009-01','locator':'Abstract; purification/nativeGDHGeo Results; Table1; GDHGeo heterologousexpression section','support':'Benzoate-grown GS15 nativeGDH and C-terminalHis6/V5 recombinantBamM catalyze oxidative decarboxylation to crotonyl-CoA in the documented artificialacceptor assays.','limit':'No direct nativeETF assay or complete five-member route; do not put purified-evidence on a bare exactETF netreaction edge.'},
 {'id':'P2009-02','locator':'GDHDes identification/heterologousexpression Results; Figure2; Table1','support':'RecombinantHis-taggedDSM2059 GDHDes produces glutaconyl-CoA without detected crotonyl-CoA in ferrocenium assay.','limit':'Carbontransformation matches the isolateddehydrogenation; exactETF reaction/sequence-specific physiologicalpartner not established.'},
 {'id':'P2009-03','locator':'Abstract; GDHactivity inD.multivorans extracts Results; Figure2','support':'Benzoate-grownmembraneextract addition with20mMNaCl convertsglutaconyl-CoA tocrotonyl-CoA.','limit':'No exactpurifiedpump catalyst or transportstoichiometry established by thisaddition; cannot inferRhea23973 Na translocation.'},
 {'id':'P2009-04','locator':'Table1; GDHDeskinetics Results','support':'RecombinantGDHDes Km52±5µM andVmax11±1µmol/min/mg underdocumentedassay.','limit':'Keep UniProtC3UVB0 discrepant25µM/11mmol perminpermg annotation separate; later2010 sourceunread.'},
 {'id':'P2009-05','locator':'Figure4caption; sequenceidentification Results; Methodsconstructsections','support':'Finite genecluster/constructidentification supports bamM andacd association to measured enzymes.','limit':'FJ688103 current CDSsizes differfromcaption; exactmodernsequence bindings remain issuer-review gated, and tags are notnative sequences.'}]
# Exact initial-source originals stay under frozen binding, no fresh full-paper reading claimed.
bind=json.loads((O/'inputs/frozen-input-bindings-before.json').read_text());b=bind[0]
evidence=[{'source':str(Path(b['root'])/r['path']),**r} for r in b['files'] if r['path'] in ['originals/PMC2698508.html','originals/PMC2698508.pdf','results/PMC2698508-full-page-text.txt']]
put('bounded-2009-primary-design-context.json',{'mode':'reuse of previously read exact initialsource; targetedidentity/kinetic reread performedin frozen issuerpreparation; no fresh fullreading here','sources':evidence,'claims':primary2009})
# Cache presence is explicitly not absence of an identity; no unperformed original-byte replay asserted.
snap=O/'inputs/current-contracts/data/identifier_authorities/sources.json';j=json.loads(snap.read_text());extras=[]
for id in ['MetaCyc:PROT-CYS','MetaCyc:Protein-S-Acetyl-Cysteines']:
 t=j['terms'][id];s=j['sources'][t['source']]
 extras.append({'id':id,'snapshot_sha256':sha(snap),'term':t,'source_metadata':s,'status':'already present in copied current maintained authority snapshot; NOT missing from repository','remaining_scope':'not among162 freshnativeoriginals; this design has not retrieved/replayed the original236 bytes or reviewed fullthiolaseprimarymechanism. No nestedmechanism proposed; sourceclassidentity is a bounded available lead, not invented or globallyabsent.'})
put('existing-thiolase-class-cache-leads.json',extras)
p=O/'results/all162-node-and-alias-dispositions.json';nodes=json.loads(p.read_text())
for n in nodes:
 if n['native_id'] in ['RXN-20154','RXN-20155']:n['reason']='Thiolase constituent reactions retained as context. Both PROT-CYS and Protein-S-Acetyl-Cysteines already exist in the copied current authority snapshot with source metadata, but their full original bytes are not in this162-object packet and have not been replayed here. Defer nestedmechanism pending bounded source/primary review; do not claim the IDs are missing globally.'
p.write_text(json.dumps(nodes,indent=2)+'\n')
# Finite reference/evidence inventory; reference IDs remain exact native evidence coordinates.
edges=json.loads((O/'results/proposed-native-edge-inventory.json').read_text());refs={}
for e in edges:
 for ev in e['evidence']:
  p=O/ev['source'];root=ET.parse(p).getroot();n=next(x for x in root if x.tag!='metadata');id='MetaCyc:'+n.get('frameid')
  refs[id]={'reference_id_candidate':id,'source_path':ev['source'],'source_sha256':ev['source_sha256'],'source_version':'MetaCyc PathwayTools27.0','source_self_reported_xml_base':root.get('{http://www.w3.org/XML/1998/namespace}base'),'source_role':'issuing native object; not a quote from embedded cited papers','edge_design_keys':refs.get(id,{}).get('edge_design_keys',[])+[e['design_key']]}
put('proposed-native-reference-inventory.json',list(refs.values()))
graphids={n['curie_candidate'] for n in nodes if n['graph_disposition']=='proposed_native_graph_node'};allused=graphids|set(refs)
put('reference-and-node-authority-union.json',{'graph_ids':len(graphids),'native_reference_ids':len(refs),'union_ids':len(allused),'ids':[{'id':i,'graph_node':i in graphids,'evidence_reference':i in refs,'in_current_snapshot':i in j['terms']} for i in sorted(allused)],'limit':'Presence in current snapshot is not standalone approval; new graphterms and nativeevidence-source coverage require exactprofile validation. Do not silently emit all162 contextualobjects as graphnodes.'})
print('Corrected16primaryclaims,5bounded2009contexts,2existingclasscacheleads and',len(refs),'nativeevidencereferences retained.')
