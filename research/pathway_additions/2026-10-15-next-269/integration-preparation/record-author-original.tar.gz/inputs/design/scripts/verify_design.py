from pathlib import Path
from collections import Counter
import ast, hashlib, json, xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads((O/p).read_text())
checks=[]
def check(label,condition):
    checks.append({'check':label,'passed':bool(condition)})
    assert condition,label
nodes=get('results/all162-node-and-alias-dispositions.json')
nb={n['native_id']:n for n in nodes}
edges=get('results/proposed-native-edge-inventory.json')
regs=get('results/all10-regulation-contexts.json')
acts=get('results/all29-activity-contexts.json')
slots=get('results/all-native-direct-slot-dispositions.json')
refs=get('results/proposed-native-reference-inventory.json')
objs={n['native_id']:next(x for x in ET.parse(O/n['source']).getroot() if x.tag!='metadata') for n in nodes}
check('162 unique native originals',len(objs)==162)
check('2131 direct native slots exhaust physical originals',len(slots)==2131==sum(len(x) for x in objs.values()))
for id,n in objs.items():
    expected=Counter(ET.tostring(s,encoding='unicode') for s in n)
    actual=Counter(s['xml'] for s in slots if s['native_id']==id)
    check('complete direct slots '+id,expected==actual)
graphids={e[k] for e in edges for k in ['subject_native_id','object_native_id']}
check('60 graph identities exactly declared',graphids=={n['native_id'] for n in nodes if n['graph_disposition']=='proposed_native_graph_node'} and len(graphids)==60)
check('80 unique edge keys',len(edges)==80==len({e['design_key'] for e in edges}))
tree=ast.parse((O/'inputs/current-contracts/src/pathwaymech/schema.py').read_text())
enums={}
for stmt in tree.body:
    if isinstance(stmt,ast.Assign) and len(stmt.targets)==1 and isinstance(stmt.targets[0],ast.Name) and stmt.targets[0].id in ['ALLOWED_EDGE_PREDICATES','NODE_CATEGORIES']:
        enums[stmt.targets[0].id]=ast.literal_eval(stmt.value)
check('all proposed predicates in copied closed schema',all(e['predicate'] in enums['ALLOWED_EDGE_PREDICATES'] for e in edges))
check('all node categories in copied schema',all(nb[i]['category'] in enums['NODE_CATEGORIES'] for i in graphids))
for e in edges:
    for ev in e['evidence']:
        check('exact source hash '+e['design_key'],sha(O/ev['source'])==ev['source_sha256'])
        check('bounded assertion and locator '+e['design_key'],0<len(ev['source_assertion'])<=400 and ev['source_locator'].startswith('/ptools-xml/'))
    if e['predicate'] in ['consumes','produces']:
        rid=e['object_native_id'] if e['predicate']=='consumes' else e['subject_native_id']
        mid=e['subject_native_id'] if e['predicate']=='consumes' else e['object_native_id']
        check('material endpoint roles '+e['design_key'],objs[rid].tag=='Reaction' and objs[mid].tag in ['Compound','Protein'] and nb[mid]['category'] not in ['molecular_activity','pathway','biological_process','cellular_component'])
    if e['predicate']=='inhibits':
        check('inhibition targets exact activity '+e['design_key'],objs[e['object_native_id']].tag=='Enzymatic-Reaction' and nb[e['object_native_id']]['category']=='molecular_activity')
    if e['predicate']=='enables':
        check('enables exact enzyme/activity roles '+e['design_key'],objs[e['subject_native_id']].tag=='Protein' and objs[e['object_native_id']].tag=='Enzymatic-Reaction')
    if e['predicate']=='has_cofactor':
        check('cofactor role '+e['design_key'],nb[e['object_native_id']]['category']=='cofactor' and nb[e['subject_native_id']]['category'] in ['protein','complex'])

rows=get('inputs/initial-ledgers/five-member-equations.json')['rows']
members={x['frame'] for x in rows}
native_members={q.get('frameid') for s in objs['PWY-5177'].findall('reaction-list') for q in s if q.get('frameid')}
check('five exact native members',members==native_members and len(members)==5)
rootparts={e['object_native_id'] for e in edges if e['subject_native_id']=='PWY-5177' and e['predicate']=='has_part'}
check('root has only five members',rootparts==members)
def equation(n):
    out=[]
    for side in ['left','right']:
        for s in n.findall(side):
            q=next(x for x in s if x.get('frameid'))
            co=int(s.findtext('coefficient') or q.findtext('coefficient') or '1')
            out.append((side,q.get('frameid'),co))
    return out
material_count=0
for r in rows:
    id=r['frame'];q=equation(objs[id])
    expected=Counter((('consumes' if side=='left' else 'produces') if r['selected_direction']=='L2R' else ('produces' if side=='left' else 'consumes'),mid,co) for side,mid,co in q)
    actual=Counter()
    for e in edges:
        if e['predicate']=='consumes' and e['object_native_id']==id:actual[('consumes',e['subject_native_id'],e['stoichiometric_coefficient'])]+=1
        if e['predicate']=='produces' and e['subject_native_id']==id:actual[('produces',e['object_native_id'],e['stoichiometric_coefficient'])]+=1
    material_count+=sum(actual.values())
    check('exact route-oriented occurrences '+id,actual==expected)
check('20 member occurrences',material_count==20)
ordering={(s.find('predecessor-reactions/Reaction').get('frameid'),s.find('Reaction').get('frameid')) for s in objs['PWY-5177'].findall('reaction-ordering')}
check('four exact ordering edges',ordering=={(e['subject_native_id'],e['object_native_id']) for e in edges if e['predicate']=='precedes'} and len(ordering)==4)
comp='GLUTARYL-COA-DEHYDROGENASE-RXN'
def net(id):
    v=Counter()
    for side,mid,co in equation(objs[id]):v[mid]+=co if side=='right' else -co
    return v
parts=[q.get('frameid') for s in objs[comp].findall('reaction-list') for q in s if q.get('frameid')]
v=Counter()
for p in parts:
    for k,c in net(p).items():v[k]+=c
check('composite exact native sum',{k:c for k,c in v.items() if c}==dict(net(comp)))
check('no catalyst transferred to isolated GCD members',not any(e['predicate']=='catalyzes' and e['object_native_id'] in parts for e in edges))
check('eight microbial regulation assertions',len([e for e in edges if e['predicate']=='inhibits'])==8)
for r in regs:
    matches=[e for e in edges if e.get('regulation_native_id')==r['native_id']]
    if r['native_id'] in ['REG-12707','REG-12708']:
        check('human regulator retained without graph edge '+r['native_id'],not matches and 'TAX-9606' in r['species_context'])
    else:
        check('exact native regulation identity '+r['native_id'],len(matches)==1 and matches[0]['subject_native_id']==r['regulator'] and matches[0]['object_native_id']==r['regulated_activity'] and r['mode']=='-')
check('all29 activity dispositions retained',len(acts)==29)
check('four exact activity participants',sum(objs[i].tag=='Enzymatic-Reaction' for i in graphids)==4)
check('no selenium cofactor edge',not any(e['predicate']=='has_cofactor' and e['object_native_id']=='SELENOMETHIONINE' for e in edges))
check('46 native references cover all80 edges',len(refs)==46 and {k for r in refs for k in r['edge_design_keys']}=={e['design_key'] for e in edges})
check('all16 corrected primary claims retained',len(get('results/all16-corrected-primary-dispositions.json'))==16)
check('all8 finite reading priorities retained',len(get('results/ranked-primary-reading-gaps.json'))==8)
check('no scratch YAML record or adapter',not (O/'data/pathways').exists() and not (O/'src').exists())

integrity=[]
sources=get('inputs/frozen-input-bindings-before.json')
issuer=get('inputs/accepted-issuer-review-bindings.json')
sources.append({'root':issuer['root'],'files':issuer['files'],'physical_count':len(issuer['files'])})
for group in sources:
    root=Path(group['root']);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    expected={r['path'] for r in group['files']}
    check('exact physical inventory '+str(root),actual==expected)
    for r in group['files']:
        check('unchanged frozen input '+str(root/r['path']),sha(root/r['path'])==r['sha256'] and (root/r['path']).stat().st_size==r['bytes'])
    integrity.append({'root':str(root),'physical_files':len(actual),'all_exact':True})
bindings=get('inputs/copied-input-bindings.json')
for b in bindings:check('unchanged copied input '+b['path'],sha(O/b['path'])==b['sha256'] and (O/b['path']).stat().st_size==b['bytes'])
result={'passed':True,'assertion_count':len(checks),'checks':checks,'frozen_inputs':integrity,
        'physical_frozen_input_count':sum(x['physical_files'] for x in integrity),
        'copied_inputs_verified':len(bindings),'hidden_and_ignored_included':True,
        'scope':'Finite design, source integrity and closed vocabulary checks; not maintained record/adapter tests or new scientific acceptance.'}
(O/'results/final-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
