# PWY-5177: bounded native graph and curation design

The proposed first record preserves **MetaCyc:PWY-5177**, glutaryl-CoA degradation, as a reviewed native pathway definition. It contains five native members and their complete 20 material occurrences, four native order assertions, and a separately identified composite GcdH reaction. The final design proposes **60 native graph nodes and 80 edges**, plus one independently resolved microbial taxon declaration. It is a design inventory, not a YAML record, adapter, primary acceptance of every annotation, or maintained integration.

The source assertions can support a faithful record under the current add-pathway contract. Unacquired historical papers limit primary interpretation; they do not require deleting an authoritative structured assertion. The record must visibly distinguish source annotations from independently read primary results, assay activity from physiological flux, and shared downstream enzyme contexts from proof of the complete route in each enzyme's taxon.

## Exact scope and baseline

This owner retains 162 full native XML originals: 1 pathway, 8 reactions, 29 enzyme-specific activities, 42 proteins, 25 genes, 27 organism objects, 20 compounds and 10 regulation objects. All 2,131 direct native slots have a disposition. This is the defined forward-reference closure from the initial and source-completion packets, not all possible backlinks, citation objects, or an exhaustive biological network.

Sixteen copied governing/authority files are bound to commit `ae143113008f8c194748bae322ab80b1853a6d95`, tree `1a0560c741c07fcb7878b1e93d8d38da67b1287c`. These are the released PR622 contracts. Each copy matched its committed blob. Parent subsequently reported PR622 ready and queued; this design performs **no actual merged265 baseline rebind**. All worktree reads have been released, and this owner has no dependency on that worktree's continued existence.

Prior duplicate results belong to the frozen initial packet's 265-record candidate baseline, including PWY0-321. Before maintained work, repeat exact ID, label, reaction, alias and publication searches across the actual merged baseline, including hidden and ignored files, and read any newly found dispositions. Do not infer absence from ordinary `rg` defaults or from this finite design inventory.

## Five members, orientation and composite

| Native member | Native orientation | Route selection | Source material occurrences |
|---|---|---|---:|
| GLUTARYL-COA-DEHYDROG-RXN | reversible | left to right | 5 |
| GLUTACONYL-COA-DECARBOXYLASE-RXN | physiological left to right | left to right | 4 |
| RXN-11667 | reversible | right to left, hydration | 3 |
| RXN-11662 | reversible | left to right, oxidation | 5 |
| ACETYL-COA-ACETYLTRANSFER-RXN | reversible | right to left, thiolysis | 3 |

The 20 occurrences cover all 14 source material IDs, including oxidized and reduced generic ETF. The acetyl-CoA occurrence has coefficient two. The top-level Edge contract has no coefficient field: retain exact coefficients in edge descriptions/source assertions and the full source equation ledger. `stoichiometric_coefficient` in the design inventory is an explicit design annotation, not a proposed YAML key. Source reaction orientation and route-selected display direction must remain separately described.

The native composite `GLUTARYL-COA-DEHYDROGENASE-RXN` has six material occurrences, including two protons, and names the first two members as constituents. Their exact native-ID sum reproduces this equation. This is formal reconciliation, not evidence for an ETF identity, an elementary mechanism, or flux. The composite is not a sixth pathway member. Native activities `ENZRXN-5541` (K172 CPLX-4041) and `ENZRXN1G01-2525` (KT2440 G1G01-166-MONOMER) attach to the composite only; neither catalyst is transferred onto the isolated dehydrogenation or decarboxylation member.

Four complete small-molecule equations balance within the accepted issuer assessment. The ETF equation and whole-route elemental balance remain undetermined because the ETF states are protein classes without complete formula/charge. Known-term residuals are not evidence of a complete imbalance. Rhea23973 includes located sodium transport absent from the native member, so it cannot replace that member or justify a sodium pump edge.

RXN-11667's native common-name says “dehydrogenase”; its actual equation is dehydration, selected as hydration in this pathway. Preserve the literal authority label and this anomaly. The existing MetaCyc contextual-label rule for record/reactions permits the equation-scoped display “Crotonyl-CoA hydration to (S)-3-hydroxybutanoyl-CoA.” No authority rename or new synonym is proposed. The other five contextual reaction labels likewise describe native equations and selected direction.

## Finite graph inventory

`results/proposed-native-edge-inventory.json` is the complete 80-edge proposal. Its source locators and hashes point to retained full originals. The nodes are the root pathway, six native Reaction nodes, and 53 participants: 14 source materials, 30 selected catalyst/complex/subunit proteins, FAD, four additional regulator compounds, and four exact enzyme-specific activity participants. One further taxon declaration, `NCBITaxon:44139` (Thauera aromatica K172), is proposed from the native pathway's historical K172 association and independently reconciled issuing records. That association is not a new claim that all five reactions were demonstrated together in K172.

| Edge group | Count | Scope |
|---|---:|---|
| Pathway has_part member | 5 | Exactly the native five-member list |
| Member material edges | 20 | All native occurrences and coefficients |
| Member precedes member | 4 | Native ordering, not channeling or measured flux |
| Composite has_part constituent | 2 | Composite context, not additional root membership |
| Composite material edges | 6 | Complete composite equation |
| Protein/complex catalyzes generic reaction | 21 | Native activity annotations with source direction and taxon context |
| Complex has_part subunit | 9 | Complete selected assembly context; no independent subunit catalysis |
| CPLX-4041 has_cofactor FAD | 1 | Native activity cofactor assertion; no physiological ETF identification |
| Compound inhibits exact native activity | 8 | Microbial enzyme-specific regulation |
| Protein/complex enables exact native activity | 4 | Native enzyme/activity link, distinct from generic reaction identity |

There are 46 native evidence-object references, an 86-ID union of native nodes and native edge references, and a separate proposed NCBITaxon reference. Primary references may additionally accompany only the bounded descriptive contexts with their accepted locators. Their presence must not imply primary support for every edge. All declarations remain visible; no detail-only participant filtering is proposed.

## Activities and regulation

All 29 native activity records are individually accounted. Twenty-one support source-only catalyst annotations. Three additional microbial thiolase activities remain contextual because their explicit physiological condensation direction opposes the displayed route thiolysis. A fourth such activity, THLCLOS-ENZRXN, is represented as an exact regulated activity but has no generic route-thiolysis catalyst edge. Four human/plant catalyst activities remain outside this microbial graph. An unspecified direction or reversible annotation does not establish the route-selected flux.

The earlier mutable 50-node/67-edge proposal left all ten regulations contextual. That was unnecessarily restrictive and is retained under `iterations/pre-regulation-expansion/` as superseded reasoning, not as an accepted predecessor. The current adapter precedent places Enzymatic-Reaction identities in **participants/category molecular_activity**, separately from Reaction nodes in reactions. The closed contract supports source-specific `enables` and `inhibits` on these exact declared identities.

The final design adds eight microbial inhibition edges targeting four exact native activities: ENZRXN-41, ENZRXN-22164, ACETYL-COA-ACETYLTRANSFER-ENZRXN and THLCLOS-ENZRXN. Four enzyme `enables` edges preserve the native enzyme links. The thirteenth added edge is THLCLOS-CPLX `has_part` THLCLOS-MONOMER. Thus 67 + 8 + 4 + 1 = 80. There is no equivalence edge between an enzyme-specific activity and its generic reaction, no inhibition of every catalyst of a generic reaction, and no extra route membership. Activity node labels retain their authoritative native names; enzyme identity and assay limitations belong in their descriptions/evidence.

REG-12707 and REG-12708, human mitochondrial thiolase sodium/potassium activation contexts, remain completely retained but outside the microbial positive graph. The other eight regulations preserve exact targets, mode, mechanism, citations, and native units. In particular REG-14465 records Ki 120 with units `&micro;mole`; this must not silently become 120 micromolar or an independently verified kinetic value.

The native ENZRXN-14343 cofactor slot names selenomethionine, while CPLX-7510's comment cites a later study concluding selenium occurs adventitiously and is not biologically required. Both are retained. No selenium cofactor edge or free selenomethionine material edge is proposed. Native FAD support for GcdH does not resolve this separate thiolase conflict.

## Identity, taxa and primary evidence

Native IDs remain the proposed graph identities. Independent issuer acceptance supports twelve ChEBI normalized encoded ionic structures, selected exact small-molecule Rhea equations and named organism/protein findings within its stated bounds. It does not accept CML stereo drawings, literal proton/tautomer localization, nine different KEGG ionic states as exact identities, generic ETF as a sequence-specific carrier, or located sodium transport as native chemistry. No automatic public-ID replacement is proposed.

All 27 native organism and 25 gene contexts remain in explicit ledgers. The K172 gene's native AE016774 association conflicts with the actual KT2440 sequence record. Historical KB740 protein identity is unresolved; a MAY27 protein is not substituted. The discontinued KT2440 Entrez identifier and an unrelated strain identifier are not promoted. Current sequence equality is not evidence that a modern annotation is the protein purified in 1993. Sequence coordinates remain accession/version-specific. No gene `encodes` predicate or gene–enzyme equivalence is invented.

The corrected 16-claim primary ledger is retained without scientific claim edits, including the corrected 2018 figure locators and 36-hour plate versus 12-hour supplement distinction. KT2440 genetic/complementation and expression results retain gdh + pp0159 and csiD + lhgO construct scope. They are not purified GcdH assays, all-five-member demonstration, physiological ETF identification or measured pathway flux. CsiD/LhgO is a separate route and is not added as a PWY-5177 member.

The 2009 GS15 and DSM2059 findings retain exact native versus tagged recombinant enzyme, ferrocenium acceptor, dehydrogenation versus decarboxylation, membrane-extract and 20 mM NaCl conditions. They do not by themselves establish a purified sodium pump or exact ETF reaction. The accepted issuer review retains kinetic and sequence-length/version conflicts. The 2010 C3UVB0 kinetic citation is assigned separately to `next268_current_bigg_completion`; this design neither duplicates that acquisition nor absorbs mutable findings. The 1993 main remains unacquired, with abstract and native citation support explicitly bounded.

`results/ranked-primary-reading-gaps.json` provides eight finite priorities with exact native locators and publication leads. First are PMID8439237 (1993 GcdH), the selenium series PMID6956900/2857719/6149704, hydratases PMID678016/4150713/5057466, NAD-linked dehydrogenase studies PMID1444364/11946544/16346566, and thiolase/regulation studies PMID9904/236278/27380370/16347774/11914342. These are claim-specific improvement tasks, not blanket prerequisites for preserving reviewed structured source assertions.

## Concrete maintained integration plan

1. After independent design acceptance, prepare an isolated scratch implementation using these copied contracts. Before any maintained promotion, bind the actual merged265 baseline and repeat hidden/ignored-inclusive duplicate and prior-disposition searches. If schema, source pins or owners changed, reassess the delta rather than assuming PR622's candidate is the merged baseline.
2. Preserve full source originals and acquisition receipts in one dated research owner. Implement a bounded new native PWY-5177 authority profile (for example `biocyc_glutaryl.py`) using existing envelope/identity safety principles without changing phenylacetate-specific ownership. Exact selected identities, type, PGDB/release, complete direct-slot counts, descendant frame identities, source request including literal bare query, full body hash and projection must agree. Partial identities, missing frame IDs, wrong PGDB/request, mutated labels/slots and typed-source downgrades must fail closed. Context-only objects may be retained as source evidence without being emitted as graph terms.
3. Promote only the required new terms, preserving every existing term and owner. In the copied baseline 11 of 60 native graph IDs already exist; 49 need additive authority coverage. The 86-ID node/reference union and full 162-object evidence closure are separate scopes. Four exact native activities must authorize participants/molecular_activity, not generic reactions or protein material. Existing native parent/class caches are available leads, not globally missing identities. Additive producer/consumer replay and source manifest reproduction must precede record acceptance. NCBITaxon44139 already exists in the pinned ontology snapshot; preserve the pin and authoritative label.
4. Author one record, provisionally `data/pathways/glutaryl-coa-degradation.yaml`, with the source-native ID, all five members, 60 native nodes, one proposed taxon, and 80 evidence-bearing edges. Reconcile the name/path against the merged corpus first. Include exact coefficient descriptions, source versus route directions, the hydration label anomaly, composite-only GcdH attachments, exact activity regulation, all selected assembly coefficients, generic ETF scope and the explicit primary limitations. Do not copy design-only inventory keys into the closed schema. Keep primary descriptions and retained research context separate from source-only edge evidence.
5. Verify original-byte replay, authority additions, all equation occurrences and ordering, native activity targets, display-label policy, category roles and all context omissions. Render and inspect the complete page and graph, including evidence, legends, no-JS access and SVG links; export KGX and confirm all native IDs and evidence survive. Run the current required render-pages, validate/strict/provenance/identifier/coverage gates, tests, lint and diff checks in the authorized owned worktree. Preserve all existing record outputs unless a separately reviewed change is necessary.
6. Obtain independent scientific and implementation review, retain actionable findings and dispositions, then follow the parent's authorized PR/review/issue/merge workflow. This packet does not approve an adapter, a record, generated pages or release licensing.

## Reading and verification limits

Fresh work here consists of copied-contract inspection, complete structural parsing and disposition of all 162 originals/2,131 direct slots, focused native comments and evidence contexts, finite graph construction, exact issuer-review intake, and inventory validation. Primary full-text readings are bounded reuse from the frozen initial/source-completion and accepted correction/issuer review, with exact hashes and claimed reading depth retained. This is not a new full reading of all historical cited papers or every repeated boilerplate comment. Embedded citation metadata is a lead, not an acquired paper.

No network acquisition, maintained edit, Git/GitHub mutation, install, runtime repair, YAML draft or adapter implementation occurred. Final integrity checks cover all 914 original frozen-input files, all 45 accepted issuer-review files, and every copied input. Physical enumeration includes hidden/ignored files. The package is frozen with a complete artifact manifest; subsequent changes require a new owner.
