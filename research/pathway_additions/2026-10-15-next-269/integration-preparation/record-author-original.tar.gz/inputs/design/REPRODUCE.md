# Reproduction and artifact roles

Do not run scripts in this frozen owner. Copy the package to a fresh absent scratch directory and replace the hard-coded output owner in copied helpers. Use the existing `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B` with `PYTHONDONTWRITEBYTECODE=1` and `PYTHONNOUSERSITE=1`; no installation is required.

The inventory helper order is `design_inventory.py`, `finish_design_ledgers.py`, `finalize_labels.py`, then `finalize_design.py`. The last helper deliberately requires its superseded-iteration directory to be absent; it is not safe to rerun destructively. For an independent replay, use a new owner with only bound inputs and the copied helpers. `intake.py` is historical intake, not a reason to reread or recreate the released268 worktree. Sixteen committed-contract copies and their blob-verification receipt make the design independent of that worktree.

`verify_design.py` validates the final inventory and unchanged source inputs without creating a YAML record. This is an inventory verification, not a maintained full test/identifier gate. `freeze.py` writes the final manifest/proof only after terminal verification and handoff are present.

Artifact roles:

- `inputs/native/`: all162 complete issuing XML originals, exact copied bytes.
- `inputs/current-contracts/`:16 committed contracts/authority snapshots; historical worktree path appears only in provenance.
- `inputs/initial-ledgers/`, `source-ledgers/`, `issuer-preparation/`: bounded equation, closure, primary and issuer reuse ledgers.
- `inputs/accepted-primary-correction/`: exact nine-file accepted locator correction packet, historical status text preserved.
- `inputs/accepted-issuer-review/`: seven exact accepted review files and two exact issuing taxon/strain originals; the entire45-file review is separately hash-bound.
- `inputs/*bindings*.json`: full physical and copy inventories with hashes, including hidden/ignored files.
- `results/all*-contexts.json` and `all162-node-and-alias-dispositions.json`: finite biological context and graph/context dispositions.
- `results/all-native-direct-slot-dispositions.json`: all2131 slots, not an implicit graph expansion.
- `results/proposed-native-edge-inventory.json`, reference/authority inventories and `taxon-design.json`: exact finite implementation inputs; design-only fields are not schema extensions.
- `results/ranked-primary-reading-gaps.json` and `native-publication-lead-inventory.json`: exact finite citation leads with native locations, not claims of acquired/full-read papers.
- `iterations/pre-regulation-expansion/`: preserved mutable proposal superseded by exact activity regulation, never frozen or independently accepted.
- `results/*stdout`, `*stderr`, verification receipts: terminal helper evidence. Original source packets retain their own failed acquisition/reading attempts unchanged. No new acquisition was attempted here.
- `DESIGN.md`, `HANDOFF.md`, this file: rationale, implementation path and review boundaries.

The manifest excludes only its own root file and root freeze-proof.json. The freeze proof binds the manifest and HANDOFF; the complete physical inventory is the manifest plus those two declared exclusions. Never treat a manifest check as biological acceptance.
