from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sqlite3,xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def get(n):return json.loads((O/n).read_text())
checks=[]
def check(n,v):checks.append({'check':n,'passed':bool(v)});assert v,n
d=get('results/all-nine-direct-pathway-taxon-dispositions.json');taxa=get('results/proposed-eight-taxon-declarations.json')
check('all9 direct entries retained',len(d)==9 and len({r['native_id'] for r in d})==9)
check('exact8 microbial declarations',len(taxa)==8 and {t['id'] for t in taxa}=={'NCBITaxon:'+i for i in ['303','1076','316277','43774','43775','59405','44139','59406']})
check('human excluded but retained',next(x for x in d if x['native_id']=='TAX-9606')['disposition']=='exclude_from_microbial_record_but_retain_direct_source_association' and 'NCBITaxon:9606' not in {t['id'] for t in taxa})
check('all selected identities have labels/ranks/parents',all(x['issuing_label'] and x['issuing_rank'] and x['issuing_parent'] for x in d))
check('seven entries added to prior one',len(taxa)-len(get('inputs/predecessor/results/taxon-design.json')['proposed_taxa'])==7)
check('exact three additive pinned terms',set(get('results/three-additive-pinned-ontology-terms.json'))=={'NCBITaxon:316277','NCBITaxon:43774','NCBITaxon:43775'})
check('K172 native species versus issuing strain explicit',next(x for x in d if x['native_id']=='ORG-5962')['native_rank']=='species' and next(x for x in d if x['native_id']=='ORG-5962')['issuing_rank']=='NCBITaxon:strain')
check('KB740 only species scope',next(x for x in d if x['native_id']=='ORG-5970')['issuing_rank']=='NCBITaxon:species')
for x in d:
 check('association locator '+x['native_id'],x['native_id'] in x['direct_pathway_occurrence']['locator'] and sha(O/x['direct_pathway_occurrence']['source'])==x['direct_pathway_occurrence']['sha256'])
labels=get('results/six-canonical-reaction-label-dispositions.json')
check('exact6 native reaction labels retained',len(labels)==6)
for r in labels:
 p=O/r['source_original'];n=ET.parse(p).getroot().find('Reaction')
 check('canonical direct name/frame '+r['id'],r['label']==(n.findtext('common-name') or n.get('frameid')) and sha(p)==r['source_sha256'])
check('hydration conflict explicit',all(s in next(x for x in labels if x['id']=='MetaCyc:RXN-11667')['description'] for s in ['crotonyl-CoA + water','dehydrogenase','naming conflict']))
check('visible record disclosure present',(O/'results/required-visible-record-label-disclosure.txt').stat().st_size>0)
sources=get('inputs/frozen-input-bindings-before.json');count=0
for g in sources:
 root=Path(g['root']);actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 check('physical source inventory '+str(root),actual=={r['path'] for r in g['files']})
 for r in g['files']:
  check('unchanged source '+str(root/r['path']),sha(root/r['path'])==r['sha256'] and (root/r['path']).stat().st_size==r['bytes']);count+=1
copied=get('inputs/copied-input-bindings.json')
for r in copied:check('unchanged copied input '+r['path'],sha(O/r['path'])==r['sha256'] and (O/r['path']).stat().st_size==r['bytes'])
before=get('inputs/taxonomy-cache-before.json');cache=Path(before['path'])
c=sqlite3.connect(cache.as_uri()+'?mode=ro&immutable=1',uri=True)
lineages=[]
for x in d:
 chain=[];current=x['issuing_id']
 while current!='NCBITaxon:1':
  assert current not in chain;chain.append(current)
  parents=[row[0] for row in c.execute("select object from statements where subject=? and predicate='rdfs:subClassOf'",(current,))]
  assert len(parents)==1;current=parents[0]
 chain.append(current)
 labels_in_chain={id:c.execute("select value from statements where subject=? and predicate='rdfs:label'",(id,)).fetchone()[0] for id in chain}
 check('microbial taxonomy lineage '+x['native_id'],('NCBITaxon:2' in chain) if x['native_id']!='TAX-9606' else ('NCBITaxon:2759' in chain and 'NCBITaxon:33208' in chain))
 lineages.append({'id':x['issuing_id'],'ancestor_chain':chain,'labels':labels_in_chain})
c.close()
(O/'results/issuing-taxonomy-lineages.json').write_text(json.dumps(lineages,indent=2)+'\n')
after={'path':str(cache),'bytes':cache.stat().st_size,'sha256':sha(cache),'checked_utc':datetime.now(timezone.utc).isoformat()}
check('full taxonomy cache unchanged and exact pin',after['sha256']==before['sha256']==before['expected_pin']['sha256'] and after['bytes']==before['bytes'])
(O/'results/taxonomy-cache-after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'passed':True,'assertions':len(checks),'checks':checks,'frozen_input_physical_files_verified':count,'copied_inputs_verified':len(copied),'cache_bytes_verified_before_and_after':after['bytes'],'hidden_and_ignored_included':True,'scope':'Exact taxon/label author correction and integrity verification; no independent self-acceptance or maintained validation.'}
(O/'results/final-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'},indent=2))
