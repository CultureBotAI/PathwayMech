from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
O=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'artifact-manifest.json').exists() and not (O/'freeze-proof.json').exists()
v=json.loads((O/'results/final-verification.json').read_text());assert v['passed']
assert v['frozen_input_physical_files_verified']==543 and v['copied_inputs_verified']==33
excluded=['artifact-manifest.json','freeze-proof.json']
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and str(p.relative_to(O)) not in excluded]
m={'owner':str(O),'scope':'N269-D01 direct pathway taxa and N269-D02 canonical label author correction','files':files,'listed_files':len(files),'listed_bytes':sum(r['bytes'] for r in files),'self_excluded':excluded}
(O/'artifact-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
f={'frozen_utc':datetime.now(timezone.utc).isoformat(),'owner':str(O),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'assessment_sha256':sha(O/'ASSESSMENT.md'),'verification_sha256':sha(O/'results/final-verification.json'),'listed_files':len(files),'physical_files':len(files)+2,'self_excluded':excluded,'all_work_terminal':True,'source_files_unchanged':543,'copied_inputs_exact':33,'taxonomy_cache_unchanged':True}
(O/'freeze-proof.json').write_text(json.dumps(f,indent=2)+'\n')
for r in files:assert sha(O/r['path'])==r['sha256']
assert len([p for p in O.rglob('*') if p.is_file()])==len(files)+2
print(json.dumps({**f,'freeze_sha256':sha(O/'freeze-proof.json'),'listed_bytes':m['listed_bytes']},indent=2))
