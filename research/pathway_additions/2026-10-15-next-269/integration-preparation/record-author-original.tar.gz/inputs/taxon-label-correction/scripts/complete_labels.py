from pathlib import Path
import json,hashlib,shutil,xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
D=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
bindings=json.loads((O/'inputs/copied-input-bindings.json').read_text())
def copy(p,n):
 q=O/'inputs'/n;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copyfile(p,q)
 bindings.append({'source':str(p),'path':str(q.relative_to(O)),'bytes':q.stat().st_size,'sha256':sha(q)})
for name in ['contextual-label-disposition.json','all162-node-and-alias-dispositions.json']:
 copy(D/'results'/name,'predecessor/results/'+name)
copy(D/'inputs/current-contracts/conf/identifier_policy.yaml','current-identifier-policy.yaml')
nodes=json.loads((D/'results/all162-node-and-alias-dispositions.json').read_text())
rows=[]
for n in nodes:
 if n['tag']!='Reaction' or n['graph_disposition']!='proposed_native_graph_node':continue
 p=D/n['source'];copy(p,'native/'+p.name)
 entity=ET.parse(p).getroot().find('Reaction')
 name=entity.findtext('common-name')
 expected=name if name else n['native_id']
 assert n['proposed_native_label']==expected
 scientific=n['proposed_display_label']
 description=scientific+'. Preserve native source direction and exact equation; source association is not a new claim of measured physiological flux.'
 if n['native_id']=='RXN-11667':
  description="Crotonyl-CoA hydration to (S)-3-hydroxybutanoyl-CoA: crotonyl-CoA + water -> (S)-3-hydroxybutanoyl-CoA. The native common-name says dehydrogenase, a naming conflict with its actual hydration/dehydration equation. The source writes reversible dehydration; PWY-5177 selects the reverse hydration direction."
 rows.append({'id':'MetaCyc:'+n['native_id'],'label':expected,'category':'molecular_activity','description':description,
 'source_original':'inputs/native/'+p.name,'source_sha256':sha(p),
 'name_basis':'exact direct native common-name' if name else 'exact native frame ID; no direct common-name in issuing object',
 'superseded_display_label':scientific,'display_phrase_destination':'visible record and reaction description/evidence, not authority/node label',
 'label_authority_unchanged':True})
assert len(rows)==6
(O/'inputs/copied-input-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
(O/'results/six-canonical-reaction-label-dispositions.json').write_text(json.dumps(rows,indent=2)+'\n')
warning="The pathway-selected hydration is crotonyl-CoA + water -> (S)-3-hydroxybutanoyl-CoA. Its native reaction RXN-11667 is named '(S)-3-hydroxybutanoyl-CoA dehydrogenase'; that source name conflicts with the actual hydration/dehydration equation. The record preserves the authoritative node label and explains the chemistry here and in the reaction description. No redox reaction is inferred from that name."
(O/'results/required-visible-record-label-disclosure.txt').write_text(warning+'\n')
receipt={'finding_id':'N269-D02','status':'authored correction; awaiting independent acceptance',
 'predecessor':'results/contextual-label-disposition.json in frozen native graph design',
 'consumer_source':'inputs/current-identifiers.py','consumer_sha256':sha(O/'inputs/current-identifiers.py'),
 'consumer_binding':'git ae143113008f8c194748bae322ab80b1853a6d95:src/pathwaymech/identifiers.py',
 'source_locators':['check_record_identifiers canonical entity_type=reaction branch, lines723-733','full native profile branch before contextual_labels evaluation','contextual_labels evaluated later, lines807-820'],
 'defect':'The broad MetaCyc contextual-label rule was treated as sufficient for six replacement labels; canonical native Reaction and full-profile validation takes precedence. RXN-11667 replacement violates that contract.',
 'correction':'Keep exact authoritative labels for all six Reaction nodes. For unnamed reactions retain the exact native frame token. Put accurate chemistry and naming conflict in visible descriptions/evidence before the graph and on the reaction, not only a tooltip.',
 'no_policy_change':True,'no_new_nested_step':True,'no_authority_rename':True,
 'verification_scope':'Fresh inspection of committed consumer source and direct names in six issuing originals. Independent reviewer separately reports real-consumer probes; this author packet does not claim to have rerun them.',
 'record_QA_required':'Verify disclosure in rendered ordinary HTML before the graph and reaction description with JavaScript disabled, and retain full description in KGX.'}
(O/'results/N269-D02-correction-disposition.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'reaction_labels':6,'canonical_native_names':sum(r['name_basis']=='exact direct native common-name' for r in rows),'frame_token_names':sum(r['name_basis'].startswith('exact native frame') for r in rows),'copied_inputs':len(bindings)},indent=2))
