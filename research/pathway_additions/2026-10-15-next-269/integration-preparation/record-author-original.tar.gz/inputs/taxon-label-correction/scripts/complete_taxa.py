from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sqlite3,shutil,xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-direct-taxon-completion')
D=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
I=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
R=Path('/private/tmp/pathwaymech-next-269-independent-glutaryl-issuer-review')
C=Path('/private/tmp/pathwaymech-curation-authorities/ncbitaxon.db')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def put(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
source_groups=[]
for root,expected in [(D,'566059628d3208928ea0a6949d81c325f04e608e2cf29653f81063e1e02ad603'),(I,'1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3'),(R,'a8f25883dee855189ca74879e004e1ed1074e4f8443a0770ce5f6c1c8837aad2')]:
 assert sha(root/'artifact-manifest.json')==expected
 m=json.loads((root/'artifact-manifest.json').read_text());rows=m if isinstance(m,list) else m['files']
 for r in rows:assert sha(root/r['path'])==r['sha256']
 files=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(root.rglob('*')) if p.is_file()]
 source_groups.append({'root':str(root),'manifest_sha256':expected,'physical_files':len(files),'files':files})
put('inputs/frozen-input-bindings-before.json',source_groups)
copied=[]
def copy(p,name):
 q=O/'inputs'/name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copyfile(p,q)
 copied.append({'source':str(p),'path':str(q.relative_to(O)),'bytes':q.stat().st_size,'sha256':sha(q)})
ids=['TAX-9606','TAX-303','TAX-1076','TAX-316277','TAX-43774','TAX-43775','TAX-59405','ORG-5962','ORG-5970']
for id in ['PWY-5177']+ids:copy(D/f'inputs/native/META-{id}.xml',f'native/META-{id}.xml')
for name in ['HANDOFF.md','DESIGN.md','results/taxon-design.json','results/design-verification-summary.json','inputs/current-contract-baseline.json']:
 copy(D/name,'predecessor/'+name)
copy(D/'inputs/current-contracts/data/identifier_authorities/ontology.json','ontology-snapshot.json')
for name in ['NCBI-taxonomy-44139.xml','NCBI-taxonomy-59406.xml','DSM-6984.html','DSM-6898.html']:
 copy(I/'originals'/name,'accepted-issuer-originals/'+name)
for name in ['HANDOFF.md','review.json','biological-identity-review.json']:
 copy(R/name,'accepted-issuer-review/'+name)
put('inputs/copied-input-bindings.json',copied)
pin=json.loads((O/'inputs/ontology-snapshot.json').read_text())['sources']['ncbitaxon-2026-07-12']
before={'path':str(C),'bytes':C.stat().st_size,'sha256':sha(C),'checked_utc':datetime.now(timezone.utc).isoformat(),'mode':'complete byte hash; subsequent SQLite opened mode=ro&immutable=1','expected_pin':pin}
assert before['sha256']==pin['sha256']
put('inputs/taxonomy-cache-before.json',before)
c=sqlite3.connect(C.as_uri()+'?mode=ro&immutable=1',uri=True);c.row_factory=sqlite3.Row
metadata=[dict(x) for x in c.execute("select * from statements where predicate in ('owl:versionIRI','owl:versionInfo','dcterms:license')")]
put('results/taxonomy-release-metadata.json',metadata)
taxids=['9606','303','1076','316277','43774','43775','59405','44139','59406']
rows={}
for tid in taxids: rows['NCBITaxon:'+tid]=[dict(x) for x in c.execute('select * from statements where subject=? order by predicate,object,value',('NCBITaxon:'+tid,))]
put('results/nine-taxonomy-statement-sets.json',rows)
snapshot=json.loads((O/'inputs/ontology-snapshot.json').read_text())
mapping=dict(zip(ids,taxids))
pw=ET.parse(O/'inputs/native/META-PWY-5177.xml').getroot().find('Pathway')
native_entries=[next(iter(s)).get('frameid') for s in pw.findall('species')]
assert native_entries==ids
dispositions=[];decl=[];refs=[];newterms={}
for index,nid in enumerate(ids,1):
 id='NCBITaxon:'+mapping[nid];rs=rows[id]
 label=[r['value'] for r in rs if r['predicate']=='rdfs:label'];rank=[r['object'] for r in rs if r['predicate']=='obo:ncbitaxon#has_rank'];parent=[r['object'] for r in rs if r['predicate']=='rdfs:subClassOf']
 assert len(label)==len(rank)==len(parent)==1
 n=ET.parse(O/f'inputs/native/META-{nid}.xml').getroot().find('Organism')
 native_label=n.findtext('common-name');native_rank=n.findtext('rank')
 xrefs=[{q.tag:q.text for q in s} for s in n.findall('dblink')]
 if nid.startswith('TAX-'):
  matches=[x for x in xrefs if x.get('dblink-db')=='NCBI-TAXONOMY-DB']
  assert len(matches)==1 and matches[0]['dblink-oid']==mapping[nid]
 direct={'source':'inputs/native/META-PWY-5177.xml','sha256':sha(O/'inputs/native/META-PWY-5177.xml'),'locator':f"/ptools-xml/Pathway[@frameid='PWY-5177']/species[{index}]/Organism[@frameid='{nid}']"}
 resolution='Exact native direct NCBI Taxonomy xref independently resolves in the pinned issuing ontology at the same label and rank.'
 conflicts=[]
 if nid=='ORG-5962':
  resolution='Accepted issuer reconciliation binds historical Pseudomonas sp. K172 / DSM6984 to Thauera aromatica K172, NCBITaxon44139; issuer rank is strain.'
  conflicts=['Native common-name is historical Pseudomonas Sp. K172 and native rank is species; authoritative label/rank are Thauera aromatica K172/strain. Native rank is preserved as a source discrepancy.','This taxon reconciliation does not identify the1993 purified enzyme with a current sequence; native AE016774 gene association remains a separate conflict.']
 if nid=='ORG-5970':
  resolution='Accepted DSM6898/NCBI issuing originals bind KB740 to the type material of Aromatoleum evansii, NCBITaxon59406, at species scope.'
  conflicts=['Historical Pseudomonas sp. KB740 label differs from current species name Aromatoleum evansii. Declare species scope with KB740/type-material qualifier; do not invent an exact strain taxon or sequence mapping.','MAY27 sequence and nonredundant protein equality do not identify KB740.']
 if nid.startswith('TAX-'):assert native_label==label[0] and native_rank==rank[0].split(':')[1]
 if nid=='TAX-9606':decision='exclude_from_microbial_record_but_retain_direct_source_association'
 else:decision='propose_taxon_declaration_from_direct_native_pathway_association'
 limit='Direct source pathway association only; not independent experimental demonstration of all five members, physiological ETF or whole-route flux in this taxon.'
 description=(f"Native PWY-5177 directly associates {nid} ({native_label}). {limit}" if nid not in ['ORG-5962','ORG-5970'] else f"Native PWY-5177 directly associates historical {native_label}. {resolution} {limit}")
 evidence={'reference_id':'MetaCyc:PWY-5177','source_assertion':f"PWY-5177 directly lists {nid} in species. This is a native pathway association, not whole-route experimental proof.",'source_locator':direct['locator']}
 d={'native_id':nid,'native_label':native_label,'native_rank':native_rank,'native_source_xrefs':xrefs,'direct_pathway_occurrence':direct,'issuing_id':id,'issuing_label':label[0],'issuing_rank':rank[0],'issuing_parent':parent[0],'resolution':resolution,'conflicts':conflicts,'disposition':decision,'current_snapshot_present':id in snapshot['terms'],'evidence_description':description,'source_association_evidence':evidence,'scope_limit':limit}
 dispositions.append(d)
 if nid=='TAX-9606':continue
 decl.append({'id':id,'label':label[0],'description':description})
 refs.append({'id':id,'title':label[0]+' — NCBI Taxonomy','url':'https://www.ncbi.nlm.nih.gov/Taxonomy/Browser/wwwtax.cgi?id='+mapping[nid],
 'source_version':'NCBI Taxonomy 2026-07-12','issuing_release_url':pin['url'],'source_sha256':pin['sha256'],
 'source_sha256_scope':pin['sha256_scope'],'source_locator':"statements WHERE subject='"+id+"'; rdfs:label, obo:ncbitaxon#has_rank, rdfs:subClassOf",
 'note':'Reference metadata proposal; project into actual Reference schema when drafting, keeping extra authority fields in retained provenance.'})
 if id not in snapshot['terms']:
  newterms[id]={'label':label[0],'synonyms':sorted({r['value'] for r in rs if r['predicate']=='oio:hasExactSynonym' and r['value']!=label[0]}),'source':'ncbitaxon-2026-07-12'}
put('results/all-nine-direct-pathway-taxon-dispositions.json',dispositions)
put('results/proposed-eight-taxon-declarations.json',decl)
put('results/proposed-eight-taxon-reference-metadata.json',refs)
put('results/three-additive-pinned-ontology-terms.json',newterms)
put('results/taxon-completion-summary.json',{'predecessor_taxa':1,'proposed_taxa':len(decl),'additional_taxa':7,'native_direct_species_occurrences':9,'microbial_direct_associations':8,'human_exclusion':1,'new_terms_in_copied_snapshot':sorted(newterms),'existing_term_owners_unchanged':True,'pinned_source_unchanged':True,'native_graph_nodes_unchanged':60,'edges_unchanged':80,'total_declarations_with_taxa':68,'source_only_scope_preserved':True,'network_acquisitions':0})
c.close()
print(json.dumps({'taxa':len(decl),'additional':7,'new_authority_terms':sorted(newterms),'source_files_bound':sum(s['physical_files'] for s in source_groups),'cache_pin_matches':True},indent=2))
