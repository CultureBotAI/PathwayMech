# Direct-pathway taxon completion for PWY-5177

This targeted successor corrects the taxon completeness gap in the frozen native graph design. `PWY-5177/species` contains nine direct entries: eight microbial associations and one human association. These are direct pathway annotations, distinct from taxa appearing only through shared catalyst or gene backlinks. The predecessor proposed only K172 and therefore lacked explicit dispositions for seven other microbial pathway associations. Reviewer reserved finding **N269-D01** for this defect.

The corrected proposal declares **all eight supported microbial taxa**, excludes Homo sapiens explicitly, and retains all nine native occurrences with exact source locators. It adds seven taxa to the predecessor's one; the biochemical graph remains60 native nodes/80 edges. The total proposed declarations are68 including the eight taxa. No taxonomy association is promoted to experimental demonstration of all five reactions, physiological ETF identity, or whole-route flux.

| Native direct entry | Proposed issuing taxon | Issuing label and rank | Disposition |
|---|---|---|---|
| TAX-9606 | NCBITaxon:9606 | Homo sapiens; species | Retain native association; exclude from microbial record |
| TAX-303 | NCBITaxon:303 | Pseudomonas putida; species | Declare direct source association at species scope |
| TAX-1076 | NCBITaxon:1076 | Rhodopseudomonas palustris; species | Declare direct source association at species scope |
| TAX-316277 | NCBITaxon:316277 | Syntrophus aciditrophicus; species | Declare direct source association at species scope |
| TAX-43774 | NCBITaxon:43774 | Syntrophus buswellii; species | Declare direct source association at species scope |
| TAX-43775 | NCBITaxon:43775 | Syntrophus gentianae; species | Declare direct source association at species scope |
| TAX-59405 | NCBITaxon:59405 | Thauera aromatica; species | Preserve this direct species association separately from K172 |
| ORG-5962 | NCBITaxon:44139 | Thauera aromatica K172; strain | Accepted historical K172/DSM6984 reconciliation; preserve native species-rank discrepancy |
| ORG-5970 | NCBITaxon:59406 | Aromatoleum evansii; species | Accepted KB740/DSM6898 type-material reconciliation at species scope; no invented strain or sequence identity |

All seven TAX-prefixed entries, including human, contain an exact native NCBI Taxonomy xref. The selected issuing terms were freshly queried from the existing read-only Semantic SQL database pinned to NCBI Taxonomy2026-07-12, SHA256 `89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d`. Complete selected statement sets retain labels, rank assertions, parents, synonyms and xrefs. These are exact issuing ontology assertions from the pinned release, not labels guessed from the native IDs or a claim about the latest live taxonomy.

K172 and KB740 use the exact issuing originals and accepted independent reconciliation retained from the issuer-preparation packet. The native K172 object says `Pseudomonas Sp. K172` with rank `species`; issuing taxonomy gives `Thauera aromatica K172` with rank `strain`. This mismatch is recorded explicitly, not copied into the authoritative declaration. The source's Thauera aromatica species association and its K172 association remain distinct even though one is a parent of the other.

KB740 is supported as type material of Aromatoleum evansii at NCBITaxon59406 species scope. The record description must visibly retain the historical KB740 qualification. It must not assign a strain-level NCBI identifier, MAY27 protein, or nonredundant sequence as though that were the historical KB740 enzyme. Similarly, K172 taxon resolution does not fix the native gene's AE016774 cross-reference conflict or bind a modern annotation to the1993 purified protein.

Five proposed taxa already exist in the copied ontology snapshot:303,1076,59405,44139,59406. Three additional terms—316277,43774,43775—are available in the same pinned cache and require additive extraction through the existing ontology builder. The source pin, release, metadata and existing term owners stay unchanged. The finite snapshot absence was checked by reading every term key; it is not a claim that the issuing IDs or other local evidence do not exist.

`results/proposed-eight-taxon-declarations.json` contains concrete named-node fields. `results/proposed-eight-taxon-reference-metadata.json` supplies exact issuing IDs, URLs, release, source hash and query locators; project those into the actual Reference schema and retain the extra authority metadata in research provenance. `results/all-nine-direct-pathway-taxon-dispositions.json` preserves the complete per-entry decisions and exact structured source assertions. The existing record reference to MetaCyc:PWY-5177 supports the direct association text; the taxon issuer references support identity/rank. No unsupported `in_taxon` predicate or route-flux edge is invented.

The correction is limited to direct pathway taxa. The other18 of the27 native organism objects remain catalyst/gene/background contexts in the predecessor's complete organism ledger. Their treatment must not be confused with these nine direct pathway entries. Shared enzyme occurrence does not automatically broaden a pathway's taxon list.

## Separate canonical-label correction: N269-D02

The frozen predecessor remains untouched. Parent approved a second bounded correction after the reviewer and authority author confirmed that canonical Reaction/full native-profile validation precedes the broad MetaCyc contextual-label rule. The predecessor's six proposed replacement display labels cannot be treated as automatically authorized by that broad rule. The current consumer source was freshly copied from the exact released commit and inspected; the independent reviewer owns the separate runtime probes.

`results/six-canonical-reaction-label-dispositions.json` retains exact source labels for all six Reaction nodes. RXN-11667 keeps its direct native common-name `(S)-3-hydroxybutanoyl-CoA dehydrogenase`. The other five native Reaction originals lack a direct common-name and retain their exact frame-token labels. No source label, synonym, policy or adapter role is broadened. The accurate scientific phrases move into ordinary visible descriptions/evidence rather than becoming node or authority labels.

For RXN-11667, the record must state the hydration equation `crotonyl-CoA + water -> (S)-3-hydroxybutanoyl-CoA` and the native naming conflict **before the graph** and in its reaction description/evidence. `results/required-visible-record-label-disclosure.txt` supplies the exact proposed prose. A tooltip or collapsed/script-only display is insufficient. Final page review must check ordinary no-JavaScript visibility, and KGX must retain the complete description. No invented nested step is needed merely to rename a node.

`results/N269-D02-correction-disposition.json` records the exact consumer binding, branch evidence and proposed remedy. This author correction does not self-accept either D01 or D02. No record YAML is included here. Scratch record preparation follows independently accepted correction dispositions. Actual merged-baseline rebind remains parent-owned before maintained integration.

All evidence came from existing pinned caches and immutable accepted inputs; no network acquisition or historical-paper hunt was needed. This is an author correction proposal, not independent acceptance of itself. Source integrity and read-only cache checks are retained separately from the biological assessment.
