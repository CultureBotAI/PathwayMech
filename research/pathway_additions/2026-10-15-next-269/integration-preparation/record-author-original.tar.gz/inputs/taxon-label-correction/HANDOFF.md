# Taxon and canonical-label correction handoff

Owner: `/private/tmp/pathwaymech-next-269-direct-taxon-completion`.

This separate author successor addresses **N269-D01** (direct pathway taxon completeness) and **N269-D02** (canonical reaction labels) without changing the frozen native graph design. Tracked as GitHub issues623 and624, both OPEN. Both remain subject to independent acceptance; this packet does not close GitHub issues or self-approve a record.

The corrected proposal retains all nine direct PWY-5177 species entries: eight microbial taxa are declared, human9606 is explicitly excluded. Seven taxa are added to the predecessor's K172-only selection. Three additional snapshot terms—NCBITaxon316277,43774,43775—come from the already pinned NCBI Taxonomy2026-07-12 database; no pin/version/source-owner change or network acquisition is needed. K172's native species-rank versus issuer strain-rank discrepancy is explicit. KB740 is supported only at NCBITaxon59406 species/type-material scope; no exact strain sequence is asserted. Direct association remains source evidence, not whole-route experimental proof.

All six Reaction nodes retain exact authoritative labels: RXN-11667's direct native common-name and the other five exact native frame tokens. The scientifically accurate hydration equation and naming conflict are required in ordinary visible prose before the graph and in reaction description/evidence. No policy broadening, authority rename, invented nested step or tooltip-only correction is proposed. Parent approved this bounded remedy; the independent reviewer owns the separate real-consumer probes.

The biological graph stays60 native nodes/80 edges. With eight taxa, the total proposed declarations become68. The eight taxon reference metadata rows and source association assertions are explicit. All other source, primary, issuer, direction, cofactor, generic ETF, sodium-transport, gene/strain/sequence and kinetic limitations remain unchanged. This packet does not absorb a mutable source successor or change the accepted2009/2018/IP08 scientific scopes.

Read ASSESSMENT.md and both `results/N269-D0*-correction-disposition.json` files, then all-nine taxon dispositions, eight declarations/reference rows, three additive ontology terms, six label dispositions, and the exact required visible disclosure. `results/final-verification.json` and the before/after full-cache hashes separate structural/source integrity checks from biological conclusions.

Frozen inputs:269 predecessor-design files,229 issuer-preparation files and45 independent issuer-review files,543 total. All33 copied inputs include16 native objects, selected accepted issuing originals, review evidence, the pinned snapshot and exact committed consumer source. All source/copy hashes and the complete14,115,225,600-byte taxonomy cache are checked before/after. Physical enumeration includes hidden and ignored files.

No YAML record or adapter is included. Independent acceptance must precede scratch record drafting; actual merged-baseline duplicate/provenance rebind remains parent-owned before maintained promotion. No maintained/Git/GitHub/runtime changes, installs, repairs or new network acquisitions occurred. Existing sources and the predecessor remain immutable.

Reproduction: use a new absent owner and existing263 verified Python with `-B`, `PYTHONDONTWRITEBYTECODE=1`, `PYTHONNOUSERSITE=1`. `complete_taxa.py` binds frozen inputs, hashes the existing cache and extracts complete selected issuing rows; `complete_labels.py` writes bounded label dispositions; `verify_and_rebind.py` checks all source/copy inventories, explicit decisions, lineages and full-cache immutability. These helpers have fixed output paths and must never run inside this frozen owner. The committed identifiers.py copy was obtained read-only with `git show ae143113008f8c194748bae322ab80b1853a6d95:src/pathwaymech/identifiers.py` and bound separately.

The manifest covers all physical files except itself and the root freeze-proof.json. All work is terminal; any correction requires a new owner.
