# Bounded reproduction

Use the existing `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B` with `PYTHONDONTWRITEBYTECODE=1` and `PYTHONNOUSERSITE=1`. No installation or repair is required.

The copied validation package is `inputs/validation-code/src`; use it as PYTHONPATH. Load the scratch YAML with yaml.safe_load, call `pathwaymech.schema.validate_record`, and run `pathwaymech.strict.strict_errors([path], draft_root)`. The successful final receipt is `results/closed-schema-final.json`.

`scripts/verify_render_export.py` writes preview/exports and results into its hard-coded owned directory, and refuses an existing preview. Do not rerun it in this frozen owner. Copy the packet to a fresh owner, change its O constant to the new owner, preserve/move that copy's preview/exports before execution, and run there. It verifies exact design topology, native source hashes/evidence, coefficients, closed node projection, taxon and label scopes, ordinary no-JS HTML visibility and KGX retention. Its final result is `results/render-export-checks.json` (581 passing checks).

`scripts/build_record.py` is the deterministic author projection. It requires a fresh owner with prepared inputs and absent output YAML/accepted-review copy, copies the independent acceptance, then writes the record and projection receipts. Use a fresh output owner and change O before reproducing; never overwrite this packet. The final wording replacement is included in the script. `scripts/prepare_inputs.py` documents exact copies and released Git-object bindings; source packets are read-only.

`scripts/check_inputs.py` compares every physical file in the four frozen input packets, their copies, and 73 individual source/Git-object bindings. It reads source packets and Git objects only; its result is `results/input-bindings-after.json`. Its output path must likewise be redirected to a fresh owner before rerunning.

The graph PNGs were rendered with the existing `/usr/local/bin/rsvg-convert -w 1800` from the exact generated SVG; the white version adds `-b white`. No browser surface was available. The candidate must still receive independent record review, authority review, parent-owned actual merged-baseline rebind, maintained history/provenance integration and full corpus gates.
