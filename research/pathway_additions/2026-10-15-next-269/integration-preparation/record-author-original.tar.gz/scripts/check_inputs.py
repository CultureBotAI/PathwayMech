from pathlib import Path
import hashlib
import json
import subprocess

O=Path('/private/tmp/pathwaymech-next-269-record-draft')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
for group in json.loads((O/'inputs/frozen-packet-bindings-before.json').read_text()):
    source=Path(group['root']);copy=O/group['copy']
    expected={r['path']:r for r in group['files']}
    for root,role in [(source,'frozen source'),(copy,'owned copy')]:
        physical={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
        assert physical==set(expected),(root,'physical inventory changed')
        for rel,row in expected.items():
            assert sha(root/rel)==row['sha256'] and (root/rel).stat().st_size==row['bytes']
        results.append({'root':str(root),'role':role,'files':len(expected),'unchanged':True})
binding=json.loads((O/'inputs/accepted-correction-review-binding.json').read_text())
for root in [Path(binding['root']),O/'inputs/accepted-correction-review']:
    assert {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}=={r['path'] for r in binding['files']}
    for r in binding['files']:assert sha(root/r['path'])==r['sha256']
    results.append({'root':str(root),'role':'independent acceptance','files':len(binding['files']),'unchanged':True})
individual=json.loads((O/'inputs/individual-copy-bindings.json').read_text())
for r in individual:
    assert sha(O/r['path'])==r['sha256']
    if r['source'].startswith('git:'):
        data=subprocess.run(['git','show',r['source'][4:]],check=True,capture_output=True).stdout
        assert hashlib.sha256(data).hexdigest()==r['sha256']
    else:assert sha(Path(r['source']))==r['sha256']
results.append({'role':'exact individual input copies and sources','files':len(individual),'unchanged':True})
for r in json.loads((O/'results/authority-author-receipt-binding.json').read_text())['files']:
    assert sha(O/r['path'])==r['sha256']==sha(Path(r['source']))
results.append({'role':'released authority-author receipts and copies','files':2,'unchanged':True})
(O/'results/input-bindings-after.json').write_text(json.dumps({'results':results,'all_unchanged':True,'physical_enumeration':'Path.rglob includes hidden and ignored files; exact physical inventory compared','frozen_packet_originals':sum(g['physical_files'] for g in json.loads((O/'inputs/frozen-packet-bindings-before.json').read_text()))+len(binding['files']),'individual_copies':len(individual)},indent=2)+'\n')
print(json.dumps({'all_unchanged':True,'frozen_packet_originals':431,'individual_copies':len(individual)},indent=2))
