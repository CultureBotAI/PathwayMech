from pathlib import Path
import hashlib,json,shutil,subprocess
O=Path('/private/tmp/pathwaymech-next-269-record-draft')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
groups=[]
for label,path,expected in [
 ('design','/private/tmp/pathwaymech-next-269-native-graph-design','566059628d3208928ea0a6949d81c325f04e608e2cf29653f81063e1e02ad603'),
 ('taxon-label-correction','/private/tmp/pathwaymech-next-269-direct-taxon-completion','7c147a476456cebca82d0cae7f7079528355fe438a608af4cac3514b4e5574d4'),
 ('ip08','/private/tmp/pathwaymech-next-269-ip08-2010-primary-completion','e677b4bc13145724a7d6f3fa0c056445d333a304b8fb7a53b3c3490f27e8b549')]:
 root=Path(path);assert sha(root/'artifact-manifest.json')==expected
 m=json.loads((root/'artifact-manifest.json').read_text());rows=m if isinstance(m,list) else m['files']
 for r in rows:assert sha(root/r['path'])==r['sha256']
 dest=O/'inputs'/label;assert not dest.exists();shutil.copytree(root,dest)
 files=[]
 for p in sorted(root.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(root);assert sha(dest/rel)==sha(p)
  files.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)})
 groups.append({'label':label,'root':str(root),'copy':str(dest.relative_to(O)),'manifest_sha256':expected,'physical_files':len(files),'files':files})
(O/'inputs/frozen-packet-bindings-before.json').write_text(json.dumps(groups,indent=2)+'\n')
copied=[]
def copy(p,name):
 q=O/'inputs'/name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copyfile(p,q)
 copied.append({'source':str(p),'path':str(q.relative_to(O)),'bytes':q.stat().st_size,'sha256':sha(q)})
initial=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
source=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
for p in sorted((initial/'originals').glob('PMC2698508*')):copy(p,'primary2009/'+p.name)
for name in ['PMC5974017.html','41467_2018_4513_MOESM1_ESM.doc','41467_2018_4513_MOESM3_ESM.xls','41467_2018_4513_MOESM4_ESM.xls','41467_2018_4513_MOESM5_ESM.pdf','BF00250279.pdf']:
 copy(source/'originals'/name,'primary2018-and1993/'+name)
commit='ae143113008f8c194748bae322ab80b1853a6d95'
paths=subprocess.run(['git','ls-tree','-r','--name-only',commit,'--','src/pathwaymech'],capture_output=True,check=True,text=True).stdout.splitlines()
for rel in paths:
 data=subprocess.run(['git','show',commit+':'+rel],capture_output=True,check=True).stdout
 p=O/'inputs/validation-code'/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
 copied.append({'source':'git:'+commit+':'+rel,'path':str(p.relative_to(O)),'bytes':len(data),'sha256':sha(p)})
(O/'inputs/individual-copy-bindings.json').write_text(json.dumps(copied,indent=2)+'\n')
(O/'results/preparation-only-status.json').write_text(json.dumps({'record_yaml_written':False,'design_successor_acceptance_pending':True,'actual_merged_baseline_rebind':'root-owned; not performed here','validation_code_commit':commit,'no_maintained_changes':True,'input_packet_files':sum(x['physical_files'] for x in groups),'individual_copies':len(copied)},indent=2)+'\n')
print(json.dumps({'packet_files':sum(x['physical_files'] for x in groups),'individual_copies':len(copied),'validation_code_files':len(paths),'no_record_yaml':True},indent=2))
