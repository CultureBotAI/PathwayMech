from pathlib import Path
from collections import Counter
import hashlib,json,shutil,html,re,xml.etree.ElementTree as ET
import yaml
O=Path('/private/tmp/pathwaymech-next-269-record-draft')
D=O/'inputs/design';C=O/'inputs/taxon-label-correction'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def clean(s):return html.unescape(re.sub('<[^>]+>','',s or '')).strip()
R=Path('/private/tmp/pathwaymech-next-269-direct-taxon-label-independent-acceptance')
assert sha(R/'artifact-manifest.json')=='bbf93a71845ebdd3b23eb238d2062b61347b0b7c09baabf449d264112fc0f797'
assert sha(R/'HANDOFF.md')=='07c03ac7aea0f5302740f5a86dd88f852f42d189e8731479e3ebfdaf7756de65'
dest=O/'inputs/accepted-correction-review';assert not dest.exists();shutil.copytree(R,dest)
reviewfiles=[]
for p in sorted(R.rglob('*')):
 if p.is_file():
  rel=p.relative_to(R);assert sha(p)==sha(dest/rel);reviewfiles.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)})
(O/'inputs/accepted-correction-review-binding.json').write_text(json.dumps({'root':str(R),'physical_files':len(reviewfiles),'files':reviewfiles},indent=2)+'\n')
allnodes=read(D/'results/all162-node-and-alias-dispositions.json');nb={n['native_id']:n for n in allnodes}
graphnodes=[n for n in allnodes if n['graph_disposition']=='proposed_native_graph_node']
design_edges=read(D/'results/proposed-native-edge-inventory.json')
taxa_design=read(C/'results/proposed-eight-taxon-declarations.json')
labelrows=read(C/'results/six-canonical-reaction-label-dispositions.json');reaction_prose={r['id']:r['description'] for r in labelrows}
native={n['native_id']:ET.parse(D/n['source']).getroot().find(n['tag']) for n in allnodes}
activities={a['native_id']:a for a in read(D/'results/all29-activity-contexts.json')}
regulations={r['native_id']:r for r in read(D/'results/all10-regulation-contexts.json')}
rows=read(D/'inputs/initial-ledgers/five-member-equations.json')['rows']
selected={r['frame']:r['selected_direction'] for r in rows}
def matlabel(id):return nb[id]['proposed_native_label']+' ['+id+']'
def equation(id,invert=False):
 n=native[id];sides=[]
 for side in (['right','left'] if invert else ['left','right']):
  terms=[]
  for s in n.findall(side):
   q=next(x for x in s if x.get('frameid'));co=int(s.findtext('coefficient') or q.findtext('coefficient') or '1')
   terms.append((str(co)+' ' if co!=1 else '')+matlabel(q.get('frameid')))
  sides.append(' + '.join(terms))
 return ' -> '.join(sides)
for r in labelrows:
 id=r['id'].split(':',1)[1]
 reaction_prose[r['id']]+=' Native equation as written: '+equation(id)+'.'
 if id in selected:reaction_prose[r['id']]+=' Pathway-selected equation: '+equation(id,selected[id]=='R2L')+'.'
 else:reaction_prose[r['id']]+=' This is composite context, not a sixth pathway member; its catalysts are not transferred to the isolated constituent reactions.'
def namespace(id):return 'MetaCyc:'+id
participants=[];reactions=[]
for n in graphnodes:
 if n['native_id']=='PWY-5177':continue
 out={'id':namespace(n['native_id']),'label':n['proposed_native_label'],'category':n['category']}
 if n['tag']=='Reaction':
  out['label']=next(r['label'] for r in labelrows if r['id']==out['id'])
  direction=native[n['native_id']].findtext('reaction-direction')
  out['direction']={'REVERSIBLE':'reversible','PHYSIOL-LEFT-TO-RIGHT':'left_to_right','PHYSIOL-RIGHT-TO-LEFT':'right_to_left'}[direction]
  reactions.append(out)
 else:participants.append(out)
assert len(participants)==53 and len(reactions)==6
taxa=[{k:t[k] for k in ['id','label']} for t in taxa_design]
taxon_prose='Pathway-level taxon scope (not proof of an isolated member reaction): '+' '.join(t['id']+': '+t['description'] for t in taxa_design)+' The native human association is retained in the source ledger and excluded from this microbial record.'
hydration=(C/'results/required-visible-record-label-disclosure.txt').read_text().strip().replace('here and in the reaction description.','here and in the incident edge descriptions.')
paragraphs=[
 'This source-native glutaryl-CoA degradation pathway converts glutaryl-CoA through glutaconyl-CoA, crotonyl-CoA, (S)-3-hydroxybutanoyl-CoA and acetoacetyl-CoA to two acetyl-CoA molecules. MetaCyc PWY-5177 defines five members and their order. Free-glutarate activation, alternative glutarate hydroxylation and downstream TCA/glyoxylate metabolism are outside these native pathway boundaries. All graph edges below preserve explicit structured source assertions; native evidence codes and cited papers are retained without treating unread citations as independently verified experiments.',
 hydration,
 'The five native member equations and the auxiliary composite retain all material occurrences, integer coefficients and source directions. Source reversibility differs from the pathway-selected direction: RXN-11667 is displayed as hydration and ACETYL-COA-ACETYLTRANSFER-RXN as thiolysis. The combined GLUTARYL-COA-DEHYDROGENASE-RXN equation formally equals the first two members, but the K172 and KT2440 GcdH activity annotations attach only to that composite. It is not a sixth pathway member, and neither catalyst is assigned to an isolated half-reaction.',
 'Oxidized and reduced ETF are generic native protein classes, not identified physiological carrier sequences. Their missing complete formula/charge prevents a complete elemental-balance claim for the first reaction or whole route. FAD is separately asserted as a cofactor of the native K172 GcdH complex. The external Rhea23973 decarboxylation includes located sodium transport absent from the native equation; no sodium pump or transport stoichiometry is asserted here. Twelve accepted ChEBI comparisons concern normalized encoded ionic structures, not blanket acceptance of CML stereo or literal proton/tautomer placement; nine KEGG ionic states differ. Native graph IDs are retained.',
 taxon_prose,
 'Shared catalyst annotations from additional microbial taxa are reaction-specific source contexts and do not broaden the direct pathway taxon list or establish the complete route in those organisms. All29 native activities are retained in the research ledger:21 provide generic-reaction catalyst annotations; four microbial thiolase activities have explicitly opposing physiological condensation directions and do not become route-thiolysis catalyst edges. THLCLOS-ENZRXN is nevertheless represented as its exact regulated activity. Four human/plant catalyst activities remain outside this microbial positive graph. Missing activity direction is not evidence for pathway flux.',
 'Eight microbial regulation assertions target four exact enzyme-specific activity participants, with enzyme enables links. They do not inhibit every catalyst of a generic reaction. The native CoA inhibition record REG-14465 reports Ki120 with units "&micro;mole"; the unit is retained without silently converting it to micromolar. Two human mitochondrial thiolase ion-regulation assertions remain outside the microbial graph. A separate native selenomethionine cofactor annotation conflicts with a later native-cited conclusion that selenium in the Clostridium kluyveri thiolase is adventitious and not required; no selenium cofactor edge is asserted. Selected complex composition does not establish independent catalytic activity of each subunit.',
 'Primary evidence has narrower experimental scope than the complete source graph. In the2009 study (PMID:19395484), native and tagged recombinant GS15 GcdH supported oxidative decarboxylation, whereas recombinant DSM2059 GDHDes supported glutaryl-CoA dehydrogenation without detected crotonyl-CoA in the reported assay. These used an artificial ferrocenium acceptor; membrane-extract conversion with20mM NaCl is not a purified sodium-pump or physiological ETF demonstration. Protein preparation, organism and assay distinctions remain separate from the native composite annotations.',
 'The2018 KT2440 study (PMID:29844506) supports condition-specific gdh deletion/growth, substrate-consumption and expression observations. The complementing inserts called gdh and csiD comprise gdh+pp0159 and csiD+lhgO, respectively. Expression sampling followed contact with glutarate; it is not proof of a pre-exposure constitutive state or pathway flux. Figure4c plates were read at36h, while Supplementary Figure9 concerns12h. The purified CsiD/LhgO experiments establish a separate hydroxylation route, not purified GcdH, every native PWY-5177 member, or native ETF coupling. Figure7 is a network interpretation; no13C flux tracing was performed. Proposed CsiR/glutarate control is not added as a demonstrated regulatory edge.',
 'The authentic1993 publisher abstract (PMID:8439237) reports purified historical K172/KB740 GcdH and FAD-containing homotetramers; the full main remains unacquired here. Its abstract support does not supply full methods, a physiological ETF partner, or a modern exact protein sequence. The native K172 gene association with AE016774 conflicts with the issuing KT2440 sequence record. Historical KB740 sequence identity and the current KT2440 gene identifier remain unresolved; unrelated strain identifiers and MAY27 sequences are not substituted.',
 'The2009 tagged DSM2059 preparation had reported Km52±5µM and Vmax11±1µmol/min/mg in a ferrocenium assay at30°C/pH7.8. Retained UniProt C3UVB0 instead records25µM and11mmol/min/mg without per-value evidence. The2010 citation was verified and its authentic supplement read, but the full main was not acquired; its primer/sequence information supplies no kinetic reconciliation or exact2010 assay preparation. IP08 therefore remains open; no global numerical correction or attribution of the database values to that paper is claimed. Sequence-length, residue-number and accession/version coordinate differences remain explicit in the retained research ledger.',
 'Source-native catalyst, cofactor and regulation assertions without a newly acquired full historical paper remain explicitly source-only. The retained research package accounts for every source object and omitted positive edge, including all genes, organism contexts, ten regulations and thiolase constituent reactions. No unsupported gene-product relation, activity–reaction equivalence, full-route taxon expansion, nested elementary mechanism or public-identifier replacement is introduced.'
]
# Improve prose spacing without changing scientific values or source literal units.
for i,p in enumerate(paragraphs):
 for a,b in [('all29','all 29'),(':21',': 21'),('the2009','the 2009'),('the2018','the 2018'),('The2018','The 2018'),('The2009','The 2009'),('the2010','the 2010'),('The2010','The 2010'),('authentic1993','authentic 1993'),('exact2010','exact 2010'),('with20mM','with 20 mM'),('at36h','at 36 h'),('concerns12h','concerns 12 h'),('no13C','no 13C'),('Km52','Km 52'),('Vmax11','Vmax 11'),('records25','records 25'),('and11mmol','and 11 mmol'),('at30°C','at 30°C'),('Ki120','Ki 120')]:p=p.replace(a,b)
 paragraphs[i]=p
refs=[]
for r in read(D/'results/proposed-native-reference-inventory.json'):
 id=r['reference_id_candidate'];node=nb[id.split(':',1)[1]]
 refs.append({'id':id,'title':'MetaCyc '+id.split(':',1)[1]+' — '+node['proposed_native_label'],
              'url':r['source_self_reported_xml_base'],'source_version':'Pathway Tools 27.0; exact retained native XML',
              'source_sha256':r['source_sha256']})
for r in read(C/'results/proposed-eight-taxon-reference-metadata.json'):
 refs.append({k:r[k] for k in ['id','title','url','source_version','source_sha256']})
primary_refs=[
 ('PMID:19395484','Decarboxylating and Nondecarboxylating Glutaryl-Coenzyme A Dehydrogenases in the Aromatic Metabolism of Obligately Anaerobic Bacteria','https://pmc.ncbi.nlm.nih.gov/articles/PMC2698508/','2009 full main; bounded accepted preparation/assay interpretation','primary2009/PMC2698508.html'),
 ('PMID:29844506','Increased glutarate production by blocking the glutaryl-CoA dehydrogenation pathway and a catabolic pathway involving l-2-hydroxyglutarate','https://pmc.ncbi.nlm.nih.gov/articles/PMC5974017/','2018 main with retained supplements and corrected claim locators','primary2018-and1993/PMC5974017.html'),
 ('PMID:8439237','Purification of glutaryl-CoA dehydrogenase from Pseudomonas sp., an enzyme involved in the anaerobic degradation of benzoate.','https://pubmed.ncbi.nlm.nih.gov/8439237/','1993 publisher abstract/preview only; full main not acquired','primary2018-and1993/BF00250279.pdf'),
 ('DOI:10.1021/bi100317m.s001','Supporting information: Structural basis for promoting and preventing decarboxylation in glutaryl-coenzyme A dehydrogenases','https://doi.org/10.1021/bi100317m.s001','2010 authentic four-page supplement; no kinetic results; full main not acquired','ip08/originals/Figshare-bi100317m_si_001.pdf'),
 ('UniProtKB:C3UVB0','UniProt C3UVB0 — retained issuer annotation with unresolved kinetic discrepancy','https://www.uniprot.org/uniprotkb/C3UVB0/entry','Exact retained issuer JSON; per-value kinetic provenance unresolved','ip08/inputs/UniProt-C3UVB0.json')]
for id,title,url,version,p in primary_refs:refs.append({'id':id,'title':title,'url':url,'source_version':version,'source_sha256':sha(O/'inputs'/p)})
ref_by_source={r['source_path']:r['reference_id_candidate'] for r in read(D/'results/proposed-native-reference-inventory.json')}
edges=[];projection=[]
for e in design_edges:
 desc=[e['evidence'][0]['source_assertion']]
 if 'stoichiometric_coefficient' in e:desc.append('Exact native occurrence coefficient: '+str(e['stoichiometric_coefficient'])+'.')
 if 'native_component_coefficient' in e:desc.append('Native complex component coefficient: '+str(e['native_component_coefficient'])+'.')
 if e.get('activity_context'):
  a=activities[e['activity_context']]
  desc.append('Enzyme-specific source context '+a['native_id']+'; species: '+', '.join(a['species_labels'])+'; source activity direction: '+str(a['source_activity_direction'] or 'unspecified')+'. Native annotation and its evidence code are not a new primary assay or whole-route assertion.')
  codes=sorted({x.get('frameid') for s in native[a['native_id']].findall('evidence') for x in s if x.tag=='Evidence-Code'})
  if codes:desc.append('Native evidence codes: '+', '.join(codes)+'.')
 if e.get('regulation_native_id'):
  r=regulations[e['regulation_native_id']]
  desc.append('Exact native regulator target: '+r['regulated_activity']+'; enzyme '+r['enzyme_context']+'; generic reaction '+r['reaction_context']+' is context only. Mode '+str(r['mode'])+'; mechanism '+str(r['mechanism'] or 'unspecified')+'.')
  if r['native_id']=='REG-14465':desc.append('Native Ki is120 with literal units "&micro;mole"; no micromolar conversion or independent numerical validation is asserted.')
 if e['predicate']=='enables':
  a=activities[e['object_native_id']]
  desc.append('Exact enzyme-specific activity participant, not a generic Reaction identity. Species context: '+', '.join(a['species_labels'])+'.')
 if e['subject_native_id']=='PWY-5177' and e['predicate']=='has_part':
  desc.append(reaction_prose[namespace(e['object_native_id'])])
 if e['design_key']=='NE030':desc.append(reaction_prose['MetaCyc:GLUTARYL-COA-DEHYDROGENASE-RXN'])
 if e['design_key']=='NE001':desc.append(taxon_prose)
 ev=[{'reference_id':ref_by_source[v['source']],'source_assertion':v['source_assertion'],'source_locator':v['source_locator']} for v in e['evidence']]
 # Scope is attached to an existing pathway-member edge, without inventing a taxon predicate.
 if e['design_key']=='NE001':
  for t in read(C/'results/all-nine-direct-pathway-taxon-dispositions.json'):
   if t['native_id']=='TAX-9606':continue
   ev.append(t['source_association_evidence'])
 out={'id':'native-'+e['design_key'].lower(),'subject':namespace(e['subject_native_id']),'predicate':e['predicate'],'object':namespace(e['object_native_id']),'description':' '.join(desc),'evidence':ev}
 edges.append(out)
 projection.append({'design_key':e['design_key'],'record_edge_id':out['id'],'source_assertions_retained':len(e['evidence']),'extra_taxon_scope_assertions':len(ev)-len(e['evidence']),'coefficient':e.get('stoichiometric_coefficient'),'component_coefficient':e.get('native_component_coefficient')})
record={'id':'MetaCyc:PWY-5177','label':nb['PWY-5177']['proposed_native_label'],'description':'\n\n'.join(paragraphs),'pathway_type':'organic-acid-degradation','taxa':taxa,'participants':participants,'reactions':reactions,'mechanistic_edges':edges,'references':refs}
target=O/'draft/data/pathways/glutaryl-coa-degradation.yaml';target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()
class Dumper(yaml.SafeDumper):pass
def scalar(d,s):return d.represent_scalar('tag:yaml.org,2002:str',s,style='|' if '\n' in s else None)
Dumper.add_representer(str,scalar)
target.write_text(yaml.dump(record,Dumper=Dumper,allow_unicode=True,sort_keys=False,width=110))
(O/'results/design-to-record-projection.json').write_text(json.dumps({'record':str(target.relative_to(O)),'nodes':{'native':60,'taxa':8,'participants':53,'reactions':6,'total':68},'edges':projection,'references':len(refs),'node_fields_only':['id','label','category','direction'],'description_projection':'root prose before graph plus incident edge descriptions/evidence; no NamedNode.description','consumer_locator_precision':'Canonical branch is in identifier_errors, not the predecessor correction receipt function name check_record_identifiers. Exact committed file hash/line range unchanged.','native_authority_implementation':'owned separately by next268_current_bigg_completion; no adapter changes here','source_baseline':'copied released commit ae143113008f8c194748bae322ab80b1853a6d95; actual merged-baseline rebind remains parent-owned'},indent=2)+'\n')
(O/'results/current-draft-status.json').write_text(json.dumps({'record_yaml_written':True,'independent_correction_acceptance_bound':True,'actual_merged_baseline_rebind':'parent-owned, pending separate receipt','maintained_changes':False,'record_sha256':sha(target),'edges':len(edges),'references':len(refs)},indent=2)+'\n')
print(json.dumps({'record':str(target),'sha256':sha(target),'taxa':len(taxa),'participants':len(participants),'reactions':len(reactions),'edges':len(edges),'references':len(refs),'description_characters':len(record['description'])},indent=2))
