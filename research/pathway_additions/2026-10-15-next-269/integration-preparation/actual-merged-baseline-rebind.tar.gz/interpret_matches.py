from pathlib import Path
import json,re,hashlib
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015')
pat=re.compile(r'PWY-5177|glutaryl[- ]?CoA.{0,8}degrad|glutarate.{0,8}degrad',re.I)
rows=[]
for line in (O/'plain-text-search.stdout').read_text().splitlines():
    name,number,body=line.split(':',2)
    rows.append({'path':name.removeprefix('./'),'line':int(number),'contexts':[body[max(0,m.start()-100):m.end()+160] for m in list(pat.finditer(body))[:20]]})
(O/'plain-search-contexts.json').write_text(json.dumps(rows,indent=2)+'\n')
records=json.loads((O/'maintained-record-inventory.json').read_text())
members={'MetaCyc:GLUTARYL-COA-DEHYDROG-RXN','MetaCyc:GLUTACONYL-COA-DECARBOXYLASE-RXN','MetaCyc:RXN-11667','MetaCyc:RXN-11662','MetaCyc:ACETYL-COA-ACETYLTRANSFER-RXN'}
related=[{**r,'shared_members':sorted(set(r['reactions'])&members)} for r in records if set(r['reactions'])&members]
assert len(related)==1 and related[0]['id']=='MetaCyc:ACETOACETATE-DEG-PWY' and len(related[0]['shared_members'])==1
(O/'shared-reaction-records.json').write_text(json.dumps(related,indent=2)+'\n')
ids={r['id']:r for r in records}
queries=['MetaCyc:PWY-5177','MetaCyc:PWY-7402','MetaCyc:TRYPTOPHAN-DEGRADATION-1','MetaCyc:PWY-5184']
source=json.loads((W/'data/identifier_authorities/sources.json').read_text())
details=[
 ('research/source_discovery/current_open_source_ingest_triage.md','YeastPathways_PWY-5177','Prior GO-CAM lead is deferred because it omits defining glutaryl-CoA steps; a source-specific incomplete representation, not an existing maintained complete MetaCyc route.'),
 ('research/pathway_additions/2026-10-15-next-266/README.md','subsequent glutaryl-CoA degradation is downstream','CENTBENZCOA-PWY is the upstream seven-reaction benzoyl-CoA route, not this downstream five-member route.'),
 ('research/pathway_additions/2026-10-15-next-267/README.md','glutaryl-CoA degradation','P321-PWY is the upstream nine-reaction route with glutaryl-CoA degradation outside its boundary.'),
 ('src/pathwaymech/biocyc_pathway.py','MetaCyc:PWY-5177','The native pathway-link guard retains a glutaryl-CoA downstream link; it is not a maintained PWY-5177 record or authority term.'),
 ('tests/fixtures/aceto_authority/META-ACETYL-COA-ACETYLTRANSFER-RXN.xml','PWY-5177','A shared native thiolase reaction backlink does not identify a complete duplicate pathway.'),
 ('reviews/structured/20261015T211329Z-benzoyl-coa-iii-scientific-review/review.md','downstream glutaryl-CoA degradation','Prior accepted source-boundary statement explicitly excludes the downstream route; no prior next269 acceptance is inferred.')]
provenance=[]
for path,needle,meaning in details:
    p=W/path;text=p.read_text();assert needle in text
    lines=[{'line':i,'text':line} for i,line in enumerate(text.splitlines(),1) if needle in line]
    provenance.append({'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'locator_hits':lines,'disposition':meaning})
result={'plain_match_lines':len(rows),'plain_match_files':len({r['path'] for r in rows}),'maintained_root_ID_queries':{k:k in ids for k in queries},'maintained_candidate_title_or_ID_duplicates':json.loads((O/'maintained-identity-matches.json').read_text()),'full_five_native_member_set_duplicates':[r['id'] for r in records if members<=set(r['reactions'])],'native_candidate_authority_term_present':'MetaCyc:PWY-5177' in source['terms'],'shared_reaction_overlap':[{'id':r['id'],'shared':r['shared_members']} for r in related],'source_dispositions':provenance,'identity_scope':'No native direct synonym or external pathway dblink was found in the complete retained PWY-5177 original. Its in-pathway parent IDs are checked separately above. Broad maintained title search additionally covers glutaryl-CoA/glutarate degradation. Source and compressed archive mentions are not globally absent and are not automatically records.'}
(O/'identity-and-source-dispositions.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='source_dispositions'},indent=2))
