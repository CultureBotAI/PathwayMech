from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.run(['git','rev-parse','HEAD','HEAD^{tree}'],cwd=W,check=True,capture_output=True).stdout.decode().splitlines()
status=subprocess.run(['git','--no-optional-locks','status','--porcelain=v1','--untracked-files=all'],cwd=W,check=True,capture_output=True).stdout.decode()
assert head==['7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105','1a0560c741c07fcb7878b1e93d8d38da67b1287c'] and status==''
for r in json.loads((O/'maintained-record-inventory.json').read_text()):assert sha(W/r['path'])==r['sha256']
for r in json.loads((O/'contract-and-source-owner-bindings.json').read_text()):assert sha(W/r['path'])==r['sha256']
(O/'baseline-end-state.json').write_text(json.dumps({'commit':head[0],'tree':head[1],'status':status,'265_record_hashes_unchanged':True,'16_contract_source_owners_unchanged':True,'all_local_jobs_terminal':True},indent=2)+'\n')
assert not (O/'artifact-manifest.json').exists() and not (O/'freeze-proof.json').exists()
rows=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file()]
(O/'artifact-manifest.json').write_text(json.dumps({'owner':str(O),'scope':'Actual merged baseline duplicate and source-owner rebind for PWY-5177; no maintained implementation acceptance or global discovery exhaustion','files':rows},indent=2)+'\n')
proof={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'listed_files':len(rows),'physical_files':len(rows)+2,'listed_bytes':sum(r['bytes'] for r in rows),'HANDOFF_sha256':sha(O/'HANDOFF.md'),'REVIEW_sha256':sha(O/'REVIEW.md'),'all_jobs_terminal':True}
(O/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({**proof,'freeze_sha256':sha(O/'freeze-proof.json')},indent=2))
