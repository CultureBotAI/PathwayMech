from pathlib import Path
import hashlib,json,subprocess
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015')
entries=subprocess.run(['git','ls-tree','-rz','HEAD','--','data/pathways'],cwd=W,capture_output=True,check=True).stdout.split(b'\0')
blobs={}
for item in entries:
    if not item:continue
    metadata,path=item.split(b'\t',1);mode,kind,oid=metadata.decode().split()
    blobs[path.decode()]=oid
records=json.loads((O/'maintained-record-inventory.json').read_text());rows=[]
for r in records:
    data=(W/r['path']).read_bytes();oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert oid==blobs[r['path']] and hashlib.sha256(data).hexdigest()==r['sha256']
    rows.append({'path':r['path'],'id':r['id'],'sha256':r['sha256'],'git_blob':oid,'matches_actual_merged_blob':True})
(O/'maintained-merged-blob-bindings.json').write_text(json.dumps(rows,indent=2)+'\n')
print('PASS: all265 maintained YAML files equal actual merged commit blobs; complete recursive corpus includes hidden/ignored paths.')
