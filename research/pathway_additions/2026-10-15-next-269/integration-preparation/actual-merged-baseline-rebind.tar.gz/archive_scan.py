from pathlib import Path
import collections,gzip,hashlib,io,json,re,tarfile,zipfile
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015')
pattern=re.compile(rb'PWY-5177|glutaryl[- ]?CoA.{0,8}degrad|glutarate.{0,8}degrad',re.I)
files=[p for p in sorted(W.rglob('*')) if p.is_file() and p.suffix in {'.zip','.gz','.tgz','.tar','.bz2','.xz','.zst','.7z'}]
inventory=[];members=[];hits=[];errors=[];cache={}
def scan_stream(stream,identity):
    first=stream.read(8192)
    if not first:return {'status':'empty','bytes_read':0}
    if first.startswith((b'%PDF-',b'\x89PNG',b'\xff\xd8',b'GIF8',b'SQLite format',b'PK\x03\x04',b'\x1f\x8b')) or b'\0' in first:
        return {'status':'binary_or_nested_container_not_text_searched','bytes_read':len(first),'magic':first[:16].hex()}
    pos=0;carry=b'';chunk=first;local=[];seen=set()
    while chunk:
        data=carry+chunk;start=pos-len(carry)
        for m in pattern.finditer(data):
            offset=start+m.start()
            if offset in seen:continue
            seen.add(offset)
            if len(local)<100:local.append({'byte_offset':offset,'match':m.group().decode('utf-8','replace'),'context':data[max(0,m.start()-100):m.end()+160].decode('utf-8','replace').replace('\n',' ')})
        pos+=len(chunk);carry=data[-512:];chunk=stream.read(1024*1024)
    if local:hits.append({'identity':identity,'match_count':len(seen),'first100_contexts':local})
    return {'status':'text_stream_searched','bytes_read':pos,'matches':len(seen)}
def process_archive(path):
    name=str(path.relative_to(W));data=path.read_bytes();digest=hashlib.sha256(data).hexdigest()
    row={'path':name,'compressed_bytes':len(data),'sha256':digest}
    if digest in cache:
        row['identical_compressed_content_of']=cache[digest];row['status']='covered_by_identical_bytes';inventory.append(row);return
    cache[digest]=name
    try:
        if name.endswith(('.tar.gz','.tgz','.tar')):
            with tarfile.open(fileobj=io.BytesIO(data),mode='r:*') as tf:
                for m in tf:
                    mr={'archive':name,'member':m.name,'bytes':m.size,'regular_file':m.isfile()}
                    if m.isfile():
                        with tf.extractfile(m) as f:mr.update(scan_stream(f,name+'!'+m.name))
                    else:mr['status']='nonregular_member_not_opened'
                    members.append(mr)
            row['status']='tar_members_enumerated'
        elif name.endswith('.zip'):
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for m in z.infolist():
                    mr={'archive':name,'member':m.filename,'bytes':m.file_size,'regular_file':not m.is_dir()}
                    if not m.is_dir():
                        with z.open(m) as f:mr.update(scan_stream(f,name+'!'+m.filename))
                    else:mr['status']='directory_not_opened'
                    members.append(mr)
            row['status']='zip_members_enumerated'
        elif name.endswith('.gz'):
            with gzip.GzipFile(fileobj=io.BytesIO(data)) as f:row.update(scan_stream(f,name+'!gzip-payload'))
        else:row['status']='unsupported_compression_not_opened'
    except Exception as e:
        row['status']='read_error';errors.append({'path':name,'error':repr(e)})
    inventory.append(row)
for p in files:process_archive(p)
for n,v in [('archive-inventory.json',inventory),('archive-members.json',members),('archive-search-hits.json',hits),('archive-errors.json',errors)]:
    (O/n).write_text(json.dumps(v,indent=2)+'\n')
summary={'outer_compressed_files':len(files),'outer_compressed_bytes':sum(r['compressed_bytes'] for r in inventory),'unique_compressed_sha256':len(cache),'outer_status':dict(collections.Counter(r['status'] for r in inventory)),'archive_members_enumerated':len(members),'member_status':dict(collections.Counter(r['status'] for r in members)),'matched_payloads':len(hits),'matched_occurrences':sum(h['match_count'] for h in hits),'read_errors':errors,'pattern':pattern.pattern.decode(),'scope':'All physical outer gz/zip/tar-type paths including hidden/ignored. Identical compressed digests searched once and aliases retained. Tar/zip members enumerated and all first-level nonbinary text streams scanned. Binary PDF/images/SQLite and nested compressed member payloads are deliberately not interpreted/OCRed or recursively expanded. Plain text was independently rg-searched. This is not all-source/global discovery exhaustion.'}
(O/'archive-scope-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
