# Actual-merged duplicate/provenance receipt

Accepted bounded rebind to commit `7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105`, tree `1a0560c741c07fcb7878b1e93d8d38da67b1287c`, clean owned next269 worktree. All265 maintained YAML files match committed blobs; all16 frozen design contract/source-owner copies match actual merged owners and blobs.

No maintained PWY-5177 root ID/title or complete five-member set duplicate. One generic thiolase is shared with acetoacetate degradation; upstream CENTBENZCOA/P321 explicitly exclude further glutaryl-CoA degradation. Prior YeastPathways_PWY-5177 is a source-specific incomplete GO-CAM lead. The exact complete native PWY-5177 source original is already retained in next266 and was independently rebound byte-for-byte to current candidate input.

Ignored/hidden paths included:35,969 physical files;268 plain-text matching lines in40files. Compressed scope:16,666 outer files,13,641 unique digests,17,605archive members;446matching payloads/2,471occurrences;zero read errors. Binary/nested-container interiors remain explicit exclusions, not global absence claims. See REVIEW.md, per-file/member archive inventories and actual source/record bindings.

No maintained or source packet edits, Git/GH mutation, network or runtime changes. This is candidate duplicate/provenance readiness, not maintained-record or new-adapter acceptance. All local checks are terminal. Reproduction helpers have this owner as output location; copy to a fresh owner before rerunning. Freeze must remain immutable.
