from pathlib import Path
import collections, hashlib, json, subprocess, yaml

O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015')
D=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(args):return subprocess.run(args,cwd=W,capture_output=True,check=True).stdout.decode()
def put(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
identity={'commit':cmd(['git','rev-parse','HEAD']).strip(),'tree':cmd(['git','rev-parse','HEAD^{tree}']).strip(),'branch':cmd(['git','branch','--show-current']).strip(),'status':cmd(['git','status','--porcelain=v1','--untracked-files=all'])}
assert identity['commit']=='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105' and identity['tree']=='1a0560c741c07fcb7878b1e93d8d38da67b1287c' and identity['status']==''
identity['receipt']=json.loads(Path('/private/tmp/pathwaymech-next-269-ci/worktree-identity.json').read_text())
identity['root']=str(W);put('baseline-identity.json',identity)
files=[p for p in sorted(W.rglob('*')) if p.is_file()]
put('physical-file-inventory.json',[{'path':str(p.relative_to(W)),'bytes':p.stat().st_size,'symlink':p.is_symlink()} for p in files])
contracts=json.loads((D/'results/committed-contract-blob-verification.json').read_text())['files']
bindings=[]
for r in contracts:
    p=W/r['path'];assert sha(p)==r['sha256']
    expected=subprocess.run(['git','show',identity['commit']+':'+r['path']],cwd=W,capture_output=True,check=True).stdout
    assert expected==p.read_bytes()
    bindings.append({'path':r['path'],'sha256':sha(p),'matches_design_copy':True,'matches_merged_blob':True})
put('contract-and-source-owner-bindings.json',bindings)
records=[];matches=[]
needles=['pwy-5177','glutaryl-coa degradation','glutarate degradation']
for p in sorted((W/'data/pathways').rglob('*')):
    if p.is_file() and p.suffix.lower() in {'.yaml','.yml'}:
        d=yaml.safe_load(p.read_text());name=d.get('label','');record={'path':str(p.relative_to(W)),'id':d.get('id'),'label':name,'sha256':sha(p),'reactions':[r['id'] for r in d.get('reactions',[])]}
        records.append(record)
        if d.get('id')=='MetaCyc:PWY-5177' or any(s in name.lower() for s in needles):matches.append(record)
assert len(records)==265
put('maintained-record-inventory.json',records)
put('maintained-identity-matches.json',matches)
pattern=r'PWY-5177|glutaryl[- ]?CoA.{0,8}degrad|glutarate.{0,8}degrad'
run=subprocess.run(['rg','--no-ignore','--hidden','--with-filename','-n','-i','-e',pattern,'.'],cwd=W,capture_output=True)
assert run.returncode in [0,1]
(O/'plain-text-search.stdout').write_bytes(run.stdout);(O/'plain-text-search.stderr').write_bytes(run.stderr)
summary={'physical_files':len(files),'bytes':sum(p.stat().st_size for p in files),'maintained_records':len(records),'maintained_identity_matches':matches,'contract_source_owner_bindings':len(bindings),'plain_search_pattern':pattern,'plain_search_command':['rg','--no-ignore','--hidden','--with-filename','-n','-i','-e',pattern,'.'],'plain_search_exit':run.returncode,'plain_search_lines':len(run.stdout.splitlines()),'scope':'All physical worktree paths including hidden/ignored files; ripgrep defaults skip binary content. Compressed content is separately inventoried/searched by archive_scan.py. .git is only a worktree pointer file; external Git object database is not a source search target.'}
put('rebind-summary.json',summary);print(json.dumps(summary,indent=2))
