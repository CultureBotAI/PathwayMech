# Reproduce in a new writable copy

This packet is an author proposal, not maintained integration. Never run its helpers inside the frozen packet. Copy the complete packet to a new scratch owner, use the existing verified interpreter and explicitly select copied candidate code. No network, package installation or environment repair is required.

From the new copy's root:

```bash
PYTHONPATH=candidate/src:candidate /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/reproduce_additions.py
```

This stages the 49 exact production originals from the candidate research owner, uses the normal source builder for a finite identifier selection, passes the complete resulting source authority through the real consumer, and appends only new source/term objects to the exact baseline snapshots. For the three ontology terms it opens `/private/tmp/pathwaymech-curation-authorities/ncbitaxon.db` read-only with immutable SQLite access, uses unchanged `read_source` and `extract_terms`, and requires the entire14,115,225,600-byte cache to match the existing source hash/version/license. It never downloads a replacement. The cache is an explicitly external pinned input; selected complete issuing rows, source metadata and the successful full-hash receipt are retained in `results/reproduction/`.

Run targeted tests from `candidate/`:

```bash
PYTHONPATH=src:. /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m pytest -q tests/test_glutaryl_authority.py tests/test_phenylacetate_authority.py tests/test_p321_authority.py tests/test_typed_authority_consumer_integrity.py tests/test_source_identifier_snapshot.py
PYTHONPATH=src:. /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m ruff check src/pathwaymech/biocyc_glutaryl.py src/pathwaymech/identifiers.py scripts/build_source_identifier_snapshot.py tests/test_glutaryl_authority.py
```

`results/test-receipts.json` records actual terminal outcomes and log hashes. The copied265-record corpus consumer is separately exercised; this is not a full `just validate`/`just test` claim and there is no maintained next269 record here. No displayed-page or KGX visibility acceptance is asserted by an authority-only test.

`prepare_glutaryl_authority.py` is the retained initial authoring script. It records how the first profile/fixture proposal was assembled; it predates the explicit actual-request correction and is not the final reproduction entry point. The final code is the hash-bound candidate, and `reproduce_additions.py` is the supported additive replay. Earlier test/collection and request-normalization attempts are retained, with their scope separated from final receipts.

The prospective patch owner list is in `results/patch-owner-inventory.json`; do not copy the whole candidate tree into a repository. Root must first rebind against the actual merged baseline and obtain independent implementation acceptance. Only then integrate the listed files and the documentation fragment through the owning maintainer. No governed file, schema, graph, record, Git or GitHub change is part of this packet.
