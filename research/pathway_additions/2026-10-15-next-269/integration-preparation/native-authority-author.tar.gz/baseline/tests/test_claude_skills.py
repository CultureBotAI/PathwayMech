from __future__ import annotations

import yaml

from scripts.validate_claude_skills import SKILLS_DIR, validate_skills


def test_claude_skills_validate() -> None:
    assert validate_skills() == []


def test_expected_claude_skills_exist() -> None:
    names = {path.parent.name for path in SKILLS_DIR.glob("*/SKILL.md")}

    assert {
        "add-pathway",
        "cross-mech-protein-links",
        "pathwaymech-discover-sources",
        "review-open-issues",
        "review-yaml-category",
        "review-yaml-record",
        "source-triage",
    } <= names


def test_cross_mech_assessment_is_a_registered_review_route() -> None:
    root = SKILLS_DIR.parent.parent
    profile = yaml.safe_load((root / "conf/record_review.yaml").read_text())
    assert ".claude/skills/cross-mech-protein-links/SKILL.md" in profile["skills"]
