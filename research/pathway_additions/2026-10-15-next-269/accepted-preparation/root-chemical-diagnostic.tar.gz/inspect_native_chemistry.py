"""Diagnose the exact native material fields without asserting cross-source identity."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from rdkit import Chem, rdBase
from rdkit.Chem import rdMolDescriptors

ROOT = Path(__file__).resolve().parent
equations = json.loads((ROOT / "inputs/five-member-equations.json").read_text())
materials = {}
for identifier in equations["material_ids"]:
    path = ROOT / "inputs" / f"META-{identifier}.xml"
    node, = [item for item in ET.parse(path).getroot() if item.get("frameid") == identifier]
    row = {
        "native_id": identifier, "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "native_type": node.tag, "native_class": node.get("class") == "true",
        "label": node.findtext("common-name"), "inchi": node.findtext("inchi"),
        "inchi_key": node.findtext("inchi-key"), "cml": [],
        "xref_candidates_not_equivalences": [
            {child.tag: child.text for child in link} for link in node.findall("dblink")
        ],
    }
    for molecule in node.findall("cml/molecule"):
        formula, = molecule.findall("formula")
        tokens = formula.get("concise").split()
        elements = {tokens[n]: int(tokens[n + 1]) for n in range(0, len(tokens), 2)}
        strings = [{"attributes": item.attrib, "value": item.text}
                   for item in molecule.findall("string")]
        row["cml"].append({
            "attributes": molecule.attrib, "element_counts": elements,
            "charge": int(molecule.get("formalCharge")), "strings": strings,
            "has_generic_R_smiles": any(item["attributes"].get("title") == "smiles"
                                        and "[R]" in (item["value"] or "") for item in strings),
            "atom_array_count": len(molecule.findall("atomArray/atom")),
            "graph_stereochemistry_independently_verified": False,
        })
    if row["inchi"]:
        mol = Chem.MolFromInchi(row["inchi"])
        assert mol is not None, identifier
        explicit = Chem.AddHs(mol)
        counts = dict(Counter(atom.GetSymbol() for atom in explicit.GetAtoms()))
        charge = Chem.GetFormalCharge(mol)
        key = Chem.MolToInchiKey(mol)
        row["inchi_diagnostic"] = {
            "formula": rdMolDescriptors.CalcMolFormula(mol), "element_counts": counts,
            "formal_charge": charge, "recomputed_key": key,
            "matches_native_key": "InChIKey=" + key == row["inchi_key"],
            "isomeric_smiles_from_inchi": Chem.MolToSmiles(mol, isomericSmiles=True),
            "chiral_centers": Chem.FindMolChiralCenters(mol, includeUnassigned=True),
            "cml_formula_and_charge_match": all(
                counts == value["element_counts"] and charge == value["charge"]
                for value in row["cml"]
            ),
        }
    else:
        row["inchi_diagnostic"] = None
    materials[identifier] = row

balances = []
for reaction in equations["rows"]:
    delta = Counter()
    charge = 0
    unresolved = []
    sides = reaction["equation"]
    for side, sign in (("left", -1), ("right", 1)):
        if reaction["selected_direction"] == "R2L":
            sign *= -1
        for term in sides[side]:
            row = materials[term["id"]]
            if not row["cml"]:
                unresolved.append({"native_id": term["id"], "signed_coefficient":
                                   sign * term["coefficient"], "reason":
                                   "Generic protein state without a native molecular formula"})
                continue
            cml, = row["cml"]
            for element, count in cml["element_counts"].items():
                delta[element] += sign * term["coefficient"] * count
            charge += sign * term["coefficient"] * cml["charge"]
    balances.append({
        "native_reaction": reaction["frame"], "selected_direction": reaction["selected_direction"],
        "known_material_delta_products_minus_inputs": {k: v for k, v in delta.items() if v},
        "known_charge_delta_products_minus_inputs": charge, "unresolved_terms": unresolved,
        "all_terms_element_and_charge_balanced": not unresolved and not +delta and not -delta
        and charge == 0,
        "scope": "Arithmetic on declared native formulas; not a physiological flux assertion.",
    })

result = {
    "rdkit_version": rdBase.rdkitVersion, "materials": list(materials.values()),
    "balances": balances,
    "limitations": [
        "Cross-resource xrefs are leads; no issuing authority equivalences assessed.",
        "No independent native CML graph/stereochemistry comparison has been made.",
        "InChI formula and key consistency does not prove biological identity or flux.",
        "Generic ETF states cannot be assigned concrete formulas from this arithmetic.",
    ],
}
(ROOT / "native-chemical-diagnostic.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({
    "materials": len(materials), "generic_smiles": [key for key, row in materials.items()
        if any(m["has_generic_R_smiles"] for m in row["cml"])],
    "inchi_consistency": {key: row["inchi_diagnostic"]["matches_native_key"]
        and row["inchi_diagnostic"]["cml_formula_and_charge_match"]
        for key, row in materials.items() if row["inchi_diagnostic"]},
    "balances": balances,
}, indent=2))
