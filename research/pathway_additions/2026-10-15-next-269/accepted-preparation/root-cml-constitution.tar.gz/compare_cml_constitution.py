"""Compare native atom/bond arrays to InChI without assigning absent stereochemistry."""
from collections import Counter
import json
from pathlib import Path
import xml.etree.ElementTree as ET

from rdkit import Chem, rdBase

ROOT = Path(__file__).resolve().parent
rows = []
for path in sorted((ROOT / 'inputs').glob('META-*.xml')):
    node, = [item for item in ET.parse(path).getroot() if item.tag == 'Compound']
    cml, = node.findall('cml/molecule')
    atoms = cml.findall('atomArray/atom')
    bonds = cml.findall('bondArray/bond')
    explicit_stereo = [ET.tostring(item, encoding='unicode') for item in cml.iter()
                       if item.tag in {'atomParity', 'bondStereo'}]
    assert not explicit_stereo, 'This diagnostic only handles the observed stereo-free arrays'
    molecule = Chem.RWMol()
    indices = {}
    for atom in atoms:
        identifier = atom.get('id')
        assert identifier not in indices
        value = Chem.Atom(atom.get('elementType'))
        value.SetFormalCharge(int(atom.get('formalCharge', 0)))
        indices[identifier] = molecule.AddAtom(value)
    for bond in bonds:
        first, second = bond.get('atomRefs').split()
        kind = {'1': Chem.BondType.SINGLE, '2': Chem.BondType.DOUBLE}[bond.get('order')]
        molecule.AddBond(indices[first], indices[second], kind)
    native = molecule.GetMol()
    Chem.SanitizeMol(native)
    native = Chem.RemoveHs(native)
    issued = Chem.MolFromInchi(node.findtext('inchi'))
    assert issued is not None
    issued = Chem.RemoveHs(issued)
    issued_stereo = Chem.FindMolChiralCenters(issued, includeUnassigned=True)
    Chem.RemoveStereochemistry(native)
    Chem.RemoveStereochemistry(issued)
    left = Chem.MolToSmiles(native, isomericSmiles=True)
    right = Chem.MolToSmiles(issued, isomericSmiles=True)
    formula = dict(Counter(atom.GetSymbol() for atom in Chem.AddHs(native).GetAtoms()))
    tokens = cml.find('formula').get('concise').split()
    declared = {tokens[n]: int(tokens[n + 1]) for n in range(0, len(tokens), 2)}
    rows.append({
        'native_id': node.get('frameid'), 'native_atom_count': len(atoms),
        'native_bond_count': len(bonds), 'explicit_graph_stereo_elements': explicit_stereo,
        'inchi_chiral_centers_before_removal': issued_stereo,
        'cml_constitution_smiles': left, 'inchi_constitution_smiles': right,
        'constitution_matches_after_stereo_removal': left == right,
        'cml_graph_formula_matches_declared': formula == declared,
        'cml_graph_charge_matches_declared': Chem.GetFormalCharge(native)
        == int(cml.get('formalCharge')),
        'stereochemical_identity_proved_by_this_check': False,
    })
result = {'rdkit_version': rdBase.rdkitVersion, 'materials': rows,
          'scope': 'Exact native arrays vs InChI constitution/formula/charge only. '
                   'No issuing authority equivalence, physiological interpretation or stereo proof.'}
(ROOT / 'cml-constitution-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'compounds': len(rows), 'constitution_matches': sum(
    row['constitution_matches_after_stereo_removal'] for row in rows),
    'formula_matches': sum(row['cml_graph_formula_matches_declared'] for row in rows),
    'charge_matches': sum(row['cml_graph_charge_matches_declared'] for row in rows),
    'explicit_graph_stereo_present': sum(bool(row['explicit_graph_stereo_elements']) for row in rows),
    'mismatches': [row for row in rows if not row['constitution_matches_after_stereo_removal']]},
    indent=2))
