"""Distinguish a strict graph mismatch from standard InChI normalization."""
import json
from pathlib import Path
from rdkit import Chem, rdBase

ROOT = Path(__file__).resolve().parent
first = json.loads((ROOT / 'cml-constitution-results.json').read_text())
rows = []
for row in first['materials']:
    values = [Chem.MolToInchi(Chem.MolFromSmiles(row[field])) for field in
              ('cml_constitution_smiles', 'inchi_constitution_smiles')]
    rows.append({'native_id': row['native_id'],
                 'strict_graph_equal_without_stereo':
                 row['constitution_matches_after_stereo_removal'],
                 'normalized_cml_inchi_without_stereo': values[0],
                 'normalized_decoded_inchi_without_stereo': values[1],
                 'standard_inchi_equal_without_stereo': values[0] == values[1]})
result = {'rdkit_version': rdBase.rdkitVersion, 'materials': rows,
          'scope': 'Standard InChI normalization comparison after removing all stereo. '
                   'This does not prove original stereo, identical fixed proton positions, '
                   'cross-resource identity or biological equivalence.'}
(ROOT / 'normalized-inchi-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'compounds': len(rows), 'strict_graph_matches': sum(
    row['strict_graph_equal_without_stereo'] for row in rows),
    'standard_inchi_matches_without_stereo': sum(
    row['standard_inchi_equal_without_stereo'] for row in rows)}, indent=2))
