# Native CML and InChI representation diagnostic

This is an author diagnostic of 12 exact native compound originals for next269, not independent acceptance or issuer identity verification. It extends the separately frozen root formula/InChI diagnostic without modifying it or the maintained repository.

All 12 native CML atom/bond graphs reproduce the declared elemental formula and formal charge. The arrays contain no explicit atomParity or bondStereo elements. No stereo was inferred from their 2D coordinates. The parser follows the observed native atomRefs spelling; the official CML molecular convention is recorded in source-format-context.json.

The initial canonical-SMILES graph comparison, with stereo removed, matches only three materials exactly. Nine complex materials differ in explicit bond orders and hydrogen/charge placement after decoding the source standard InChI. These are retained diagnostic observations, not findings of nine chemical identity defects. Standard InChI normalization of both graph representations, after removing stereo, matches for all 12 materials. This demonstrates agreement at that normalization level only. It does not establish identical fixed proton positions, original stereochemistry, issuer cross-reference identity, enzymatic specificity, or physiological equivalence.

The first script and result use the shorthand `constitution` in field names. Interpret those fields as strict canonical graph equality including explicit bond and charge placement after stereo removal; they do not by themselves adjudicate tautomer-normalized identity. Read normalized-inchi-comparison.json alongside cml-constitution-results.json. Both original results and stderr warnings are preserved.

Both commands completed with exit 0 using the existing RDKit 2026.03.5 interpreter at /private/tmp/npmech-rdkit-2026.03.5/bin/python3.13. No packages were installed. Runtime receipts bind the exact scripts and logs. No native ETF formula, whole-route balance, or S-product stereochemical proof is claimed.
