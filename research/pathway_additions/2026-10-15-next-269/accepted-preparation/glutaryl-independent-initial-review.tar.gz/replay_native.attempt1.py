from pathlib import Path
import xml.etree.ElementTree as ET
import json, hashlib
from collections import Counter

BASE=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
OUT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d): (OUT/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def refs(n,slot): return [x.get('frameid') for s in n.findall(slot) for x in s if x.get('frameid')]
nodes={}; inventory=[]
for p in sorted((BASE/'originals').glob('META-*.xml')):
    r=ET.parse(p).getroot()
    ns=[x for x in r if x.tag!='metadata']
    assert len(ns)==1
    n=ns[0]; f=n.get('frameid'); assert f and n.get('detail')=='full'
    assert p.name=='META-'+f+'.xml'
    nodes[f]=n
    inventory.append(dict(frame=f,type=n.tag,sha256=sha(p),bytes=p.stat().st_size,direct_slot_count=len(n),label=n.findtext('common-name')))
assert len(nodes)==91
counts=dict(Counter(n.tag for n in nodes.values()))
assert counts=={'Compound':13,'Protein':30,'Enzymatic-Reaction':29,'Reaction':8,'Regulation':10,'Pathway':1},counts
assert sum(len(n) for n in nodes.values())==1267
published={x.findtext('pubmed-id') for n in nodes.values() for x in n.iter('Publication') if x.findtext('pubmed-id')}
# The author's 62 embedded-publication count is frame IDs, including records without PMID.
pubframes={x.get('frameid') for n in nodes.values() for x in n.iter('Publication')}
assert len(pubframes)==62,len(pubframes)
author=json.loads((BASE/'results/native-originals-inventory.json').read_text())['objects']
assert {(x['frame'],x['sha256'],x['direct_slot_count']) for x in author}=={(x['frame'],x['sha256'],x['direct_slot_count']) for x in inventory}
save('independent-native-inventory.json',dict(objects=inventory,type_counts=counts,total_direct_slots=1267,embedded_publication_frames=sorted(pubframes),embedded_pmids=sorted(published),scope='All original envelopes/direct-slot counts and linkage projections; not full scientific reading of all 91 objects or 62 cited works.'))
pathway=nodes['PWY-5177']
order=['GLUTARYL-COA-DEHYDROG-RXN','GLUTACONYL-COA-DECARBOXYLASE-RXN','RXN-11667','RXN-11662','ACETYL-COA-ACETYLTRANSFER-RXN']
assert set(refs(pathway,'reaction-list'))==set(order)
layout={x.find('Reaction').get('frameid'):x.findtext('direction') for x in pathway.findall('reaction-layout')}
assert [layout[f] for f in order]==['L2R','L2R','R2L','L2R','R2L']
def side(n,s):
    result=[]
    for slot in n.findall(s):
        targets=[x for x in slot if x.get('frameid')]
        assert len(targets)==1
        t=targets[0]; c=int(slot.findtext('coefficient','1'))
        assert c>0
        result.append(dict(id=t.get('frameid'),coefficient=c,type=t.tag,native_class=t.get('class')=='true'))
    return result

def equation(f,direction):
    n=nodes[f]; raw={s:side(n,s) for s in ['left','right']}
    selected={'inputs':raw['left' if direction=='L2R' else 'right'],'outputs':raw['right' if direction=='L2R' else 'left']}
    return dict(frame=f,sha256=sha(BASE/'originals'/('META-'+f+'.xml')),raw_direction=n.findtext('reaction-direction'),pathway_direction=direction,raw=raw,selected=selected,activities=refs(n,'enzymatic-reaction'),constituents=refs(n,'reaction-list'),parents=refs(n,'parent'),in_reaction=refs(n,'in-reaction'),label=n.findtext('common-name'))
rows=[equation(f,layout[f]) for f in order]
assert [len(r['activities']) for r in rows]==[0,0,5,4,18]
assert sum(len(r['raw']['left'])+len(r['raw']['right']) for r in rows)==20
materials=sorted({x['id'] for r in rows for s in r['selected'].values() for x in s})
assert len(materials)==14

def net(rs):
    result=Counter()
    for r in rs:
        for s,sign in [('inputs',-1),('outputs',1)]:
            for t in r['selected'][s]: result[t['id']]+=sign*t['coefficient']
    return {k:v for k,v in sorted(result.items()) if v}
comp=equation('GLUTARYL-COA-DEHYDROGENASE-RXN','L2R')
assert set(comp['constituents'])==set(order[:2])
assert net(rows[:2])==net([comp])
assert set(comp['activities'])=={'ENZRXN1G01-2525','ENZRXN-5541'}
assert net(rows)=={'ACETYL-COA':2,'CARBON-DIOXIDE':1,'CO-A':-1,'ETF-Oxidized':-1,'ETF-Reduced':1,'GLUTARYL-COA':-1,'NAD':-1,'NADH':1,'PROTON':-1,'WATER':-1}
assert set(rows[-1]['constituents'])=={'RXN-20154','RXN-20155'}
thiolase=[equation(f,'L2R') for f in ['RXN-20154','RXN-20155']]
# Native constituents are retained as supplied, not automatically additional route members.
save('independent-native-equations.json',dict(pathway_sha256=sha(BASE/'originals/META-PWY-5177.xml'),member_rows=rows,material_ids=materials,composite=comp,first_two_net=net(rows[:2]),formal_pathway_net=net(rows),thiolase_constituents=thiolase,interpretation='Native-ID arithmetic and exact source layout only; not chemical identity, carrier physiology, or organism-level flux proof.'))
activityrows=[]
for r in rows+[comp]:
    for a in r['activities']:
        n=nodes[a]
        assert refs(n,'reaction')==[r['frame']],(a,refs(n,'reaction'))
        enzymes=refs(n,'enzyme'); assert all(e in nodes for e in enzymes)
        activityrows.append(dict(activity=a,sha256=sha(BASE/'originals'/('META-'+a+'.xml')),source_reaction=r['frame'],enzyme=[dict(id=e,sha256=sha(BASE/'originals'/('META-'+e+'.xml')),species=[{'id':x.get('frameid'),'label':x.findtext('common-name')} for slot in nodes[e].findall('species') for x in slot],comment=nodes[e].findtext('comment'),components=refs(nodes[e],'component')) for e in enzymes],evidence=[{'code':x.get('frameid'),'label':x.findtext('common-name')} for slot in n.findall('evidence') for x in slot if x.tag=='Evidence-Code'],pmids=sorted({x.findtext('pubmed-id') for x in n.iter('Publication') if x.findtext('pubmed-id')}),direction=n.findtext('reaction-direction'),comments=[x.text for x in n.findall('comment')]))
assert len(activityrows)==29
save('independent-activity-contexts.json',activityrows)
print(json.dumps(dict(native_originals=len(nodes),type_counts=counts,direct_slots=1267,publications=len(pubframes),members=len(rows),materials=len(materials),activities=len(activityrows),composite_first_two_exact=True),indent=2))
