from pathlib import Path
import hashlib,json,xml.etree.ElementTree as ET
from collections import Counter
from rdkit import Chem,rdBase
ROOT=Path(__file__).resolve().parent
SRC=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation/originals')
D=Path('/private/tmp/pathwaymech-next-269-root-chemical-diagnostic')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((D/'artifact-manifest.json').read_text())
for x in manifest['files']:
 p=D/x['path'];assert sha(p)==x['sha256'] and p.stat().st_size==x['bytes']
assert len(manifest['files'])==27 and len([p for p in D.rglob('*') if p.is_file()])==29
b=json.loads((ROOT/'independent-native-equations.json').read_text())
rows=[];formulas={}
for i in b['material_ids']:
 p=SRC/('META-'+i+'.xml');n=ET.parse(p).getroot().find('*[@frameid="'+i+'"]')
 assert n is not None
 assert (D/'inputs'/p.name).read_bytes()==p.read_bytes()
 r={'id':i,'sha256':sha(p),'type':n.tag,'native_class':n.get('class')=='true'}
 c=n.find('cml/molecule');inchi=n.findtext('inchi');stored=n.findtext('inchi-key')
 if c is None:
  assert n.tag=='Protein' and n.get('class')=='true' and not inchi
  r.update(status='undetermined_generic_protein_state',formula=None)
 else:
  tok=c.find('formula').get('concise').split();declared=dict(zip(tok[::2],map(int,tok[1::2])))
  charge=int(c.get('formalCharge'))
  mol=Chem.MolFromInchi(inchi);assert mol is not None
  counted=Counter()
  for atom in mol.GetAtoms():
   counted[atom.GetSymbol()]+=1
   counted['H']+=atom.GetTotalNumHs()
  counted={k:v for k,v in counted.items() if v}
  computed_charge=sum(a.GetFormalCharge() for a in mol.GetAtoms())
  key=Chem.InchiToInchiKey(inchi)
  assert stored=='InChIKey='+key,(i,key,stored)
  assert counted==declared and charge==computed_charge,(i,counted,declared)
  formulas[i]=(declared,charge)
  r.update(status='internal_inchi_key_formula_charge_consistent',formula=declared,charge=charge,key=key,generic_R_smiles=any('[R]' in (s.text or '') for s in c.findall('string') if s.get('title')=='smiles'))
 rows.append(r)
assert len(formulas)==12
assert sorted(r['id'] for r in rows if r.get('generic_R_smiles'))==['ACETOACETYL-COA','CROTONYL-COA','GLUTARYL-COA','NAD','NADH']
results=[]
for reaction in b['member_rows']:
 sums=Counter();q=0;unknown=[]
 for side,sign in [('inputs',-1),('outputs',1)]:
  for t in reaction['selected'][side]:
   i=t['id'];n=sign*t['coefficient']
   if i not in formulas:unknown.append({'id':i,'signed_coefficient':n});continue
   formula,charge=formulas[i]
   for el,v in formula.items():sums[el]+=n*v
   q+=n*charge
 delta={k:v for k,v in sums.items() if v}
 result={'reaction':reaction['frame'],'unknown_terms':unknown,'known_terms_only_element_residual':delta,'known_terms_only_charge_residual':q,'full_balance_status':'undetermined' if unknown else 'balanced' if not delta and not q else 'unbalanced'}
 results.append(result)
assert results[0]['full_balance_status']=='undetermined'
assert results[0]['known_terms_only_element_residual']=={'H':-3} and results[0]['known_terms_only_charge_residual']==-1
assert all(r['full_balance_status']=='balanced' for r in results[1:])
# Compare final facts to root report, not its algorithm or input equation projection.
a=json.loads((D/'native-chemical-diagnostic.json').read_text())
for mine,theirs in zip(results,a['balances']):
 assert mine['reaction']==theirs['native_reaction']
 assert mine['known_terms_only_element_residual']==theirs['known_material_delta_products_minus_inputs']
 assert mine['known_terms_only_charge_residual']==theirs['known_charge_delta_products_minus_inputs']
report={'diagnostic_root':str(D),'manifest_sha256':sha(D/'artifact-manifest.json'),'listed_verified':27,'physical_verified':29,'rdkit_version':rdBase.rdkitVersion,'materials':rows,'member_equation_diagnostics':results,'limits':['Same installed RDKit/InChI toolkit, independently written original-source projection and equation arithmetic; not independent chemistry-engine confirmation.','Native CML atom/bond graph and stereo, cross-resource equivalence and measured physiological carrier coupling are unreviewed.','An incomplete known-term residual is not a full imbalance and cannot assign formulas or stoichiometry to generic ETF protein classes.']}
(ROOT/'independent-chemical-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'originals':len(rows),'consistent_inchi':len(formulas),'balances':results,'diagnostic_integrity':'27 listed/29 physical pass'},indent=2))
