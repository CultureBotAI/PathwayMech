# Independent initial review: MetaCyc PWY-5177

**Qualified acceptance of the frozen initial source preparation, not acceptance of a complete dossier, maintained record, public identifier mapping or whole-pathway experimental proof.** No scientific blocker was found in the author's bounded interpretation. One publication-count clarification and additional source-specific cautions below must survive downstream use.

## Exact review boundary

The source-author packet is `/private/tmp/pathwaymech-next-269-glutaryl-preparation`, manifest `bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b`. All 421 listed and 423 physical files were checked against their exact sizes/hashes. The independent replay parses all 91 native originals and checks 1267 direct slots, five members, 20 side occurrences, 14 material identifiers and 29 linked activity objects. This is structural coverage, not a claim of reading every biological assertion in 91 objects or every cited paper.

Human scientific reading covered the five equation projections and source layout, the full GCD composite and its two activity records, corresponding protein biological slots, selected lower-tail contextual passages, and the complete authentic 2009 article: all main text/Methods, three HTML tables/footnotes, four original figure images and 42 reference entries. The 1993 publisher abstract/access boundary was checked. No full 1993 paper or 2018 main/supplement reading is claimed. No ongoing next269 completion owner was read. The copied curation/harmonization governance was consulted. Author originals, maintained files and runtimes were unchanged.

## Native mechanism and biological scope

The selected native traversal is glutaryl-CoA dehydrogenation L2R, glutaconyl-CoA decarboxylation L2R, RXN-11667 hydration R2L, RXN-11662 oxidation L2R and thiolysis R2L. The first two equations add exactly to `GLUTARYL-COA-DEHYDROGENASE-RXN`, including consumption of two native protons. Neither constituent has a directly attached activity. The composite alone links the historical K172 complex through ENZRXN-5541 and the KT2440 protein through ENZRXN1G01-2525. Keep source/composite/isolated-step distinctions; the shared composite attachment is not separate experimental proof of each elementary event in each preparation. Thiolase has its own two constituents, which are not extra PWY-5177 members.

The source's oxidized/reduced ETF entries are generic Protein classes. They are not small molecules or exact assayed carrier sequences. RXN-11667's erroneous-looking dehydrogenase label does not override its water-only hydration equation and lyase EC assignment. The KT2440 protein's free-glutarate wording does not establish free glutarate as a direct GcdH substrate.

The 27 lower-tail activities include carbon fixation, fermentation, mevalonate/PHB biosynthesis, acetoacetate metabolism, plant/human preparations and predicted assignments. For example, Methylibium MONOMER-19851 is explicitly predicted, several thiolase activity directions are biosynthetic, and the E.coli activity description mentions an initial E. coli B preparation despite a native K12 taxon attachment. Such contexts must remain qualified; neither organism names nor shared-reaction backlinks prove the entire glutaryl-CoA route. The author correctly warns against that inference.

## Primary evidence

PMC2698508 HTML SHA256 `e0583c654b603e47848c1f97405022cce2e8bb0540afa84926472570eabfd70f` supports preparation-specific decarboxylating Geobacter and nondecarboxylating Desulfococcus GDH activities with artificial ferrocenium acceptor. It does not establish their native ETF coupling. Geobacter crude-extract assays explicitly stop before acetoacetyl-CoA/acetyl-CoA because NAD+ is absent. Desulfococcus membrane addition and NaCl stimulation support a membrane-dependent context, not purified decarboxylase assembly identity or measured sodium-transport stoichiometry.

Native Geobacter, C-terminalHis6/V5 recombinant Geobacter and C-terminalHis6 recombinant Desulfococcus must remain separate. FAD occupancy/reconstitution, inferred alpha4 assembly, sequence-derived versus apparent tagged masses, and approximate product inhibition are preparation-specific. RT-PCR supports benzoate-induced expression/co-transcription, not direct Rre binding or a regulatory sign. Table 2 residue comparisons and Table 3 energetic/ecological distribution are partly inference and prior-literature synthesis. Figure 1 is context, not a five-step flux experiment. The main paper does not demonstrate the absoluteS configuration of its hydroxybutyryl product.

Retain the already-noted inhibitor-concentration and crotonyl-mass discrepancies. Further cautions: native Geobacter mass167 ± 10kDa in Results versus170 ± 10 in Table 1; purification maximal specific activity 12 versus kineticVmax 3.2 ± 0.2µmol/min/mg; human-position T170 corresponds to S181 in the Rho column; Introduction and Discussion use different carbon-bond indices. These are source-specific inconsistencies/qualifications, not grounds to invent a single reconciled value. The 15 dispositions in `primary-claim-review.json` give exact paragraph/table/figure locators.

## Bounded chemistry diagnostic

The separately authored root packet `/private/tmp/pathwaymech-next-269-root-chemical-diagnostic`, manifest `4e9fd9e90def3c5d2673f665a85b68db33d9ad670905ed794569a6567afacbf9`, passes independent 27-listed/29-physical integrity checks. An independently written parser/arithmetic replay using the same existing RDKit 2026.03.5 confirms 12 InChI/stored-key/formula/charge agreements and five native SMILES containing `[R]`. Decarboxylation, hydration, NAD oxidation and thiolysis balance their declared formulas/charges.

The ETF equation remains **undetermined**. H=-3 and charge=-1 are residuals of known terms only, not a full chemical imbalance and not permission to invent ETF formulas. This review does not verify CML graph/stereochemical equivalence, exact external issuer mappings, biological microstates, or physiological carrier coupling. A later root CML constitution check was explicitly outside this review.

## Publication-count clarification

The reproducible 62 count is a count of mixed PMID and native-frame identifier strings; it represents 44 distinct native Publication frames. The same paper may appear once by PMID and again by a pointer's frame ID. Thus “62 identifiers” is supported, but the preservation paragraph's shorthand “all62-paper reading” should not become a 62-distinct-paper coverage denominator. Normalize aliases in a successor literature ledger. Even 44 frames are not independently deduplicated bibliographic works. This is a minor reporting clarification, not a defect in the underlying source preservation.

## Still open before maintained curation

- Complete/disposition the finite native forward-reference and activity scopes. The author's 70 missing-original occurrences cover nine selected slot names, not universal graph closure; embedded full objects remain different from separately acquired originals.
- Independently ground chemical structures, stereochemistry and any exact public mappings; handle membrane transport chemistry separately from soluble GCD constituent chemistry. The12-material consistency check does not include the additional FAD cofactor original.
- Read the exact primary evidence needed for selected historical 1993, KT2440 2018, lower-tail, ETF or regulatory claims, or retain explicit unavailable/unsupported dispositions. Do not stitch different taxa/preparations into measured whole-route flux or continue unbounded access searches.
- Verify historical K172/KB740 and current taxon/sequence identities, FJ688103/bamM accession scope and actual construct limits before using exact protein endpoints. No complete tag sequence is established here.
- Preserve all five native members and source conflicts, and rebind the actual merged 265-record baseline/aliases before maintained work.

The failed optional bs4/rdkit imports and one reviewer count-assumption assertion are retained. All successful replay jobs are terminal. No dependency installation, source mutation, Git/GitHub write or maintained draft was performed.
