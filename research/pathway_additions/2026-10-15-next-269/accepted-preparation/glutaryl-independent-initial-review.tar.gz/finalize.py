from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,xml.etree.ElementTree as ET
P=Path(__file__).resolve().parent
A=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
D=Path('/private/tmp/pathwaymech-next-269-root-chemical-diagnostic')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(P/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
verifications=[]
for folder,expected in [(A,'bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b'),(D,'4e9fd9e90def3c5d2673f665a85b68db33d9ad670905ed794569a6567afacbf9')]:
 assert sha(folder/'artifact-manifest.json')==expected
 m=json.loads((folder/'artifact-manifest.json').read_text())
 for r in m['files']:
  f=folder/r['path'];assert f.stat().st_size==r['bytes'] and sha(f)==r['sha256']
 physical=[f for f in folder.rglob('*') if f.is_file()]
 assert {str(f.relative_to(folder)) for f in physical}=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
 verifications.append(dict(root=str(folder),listed=len(m['files']),physical=len(physical),manifest_sha256=sha(folder/'artifact-manifest.json'),handoff_sha256=sha(folder/'HANDOFF.md'),freeze_sha256=sha(folder/'freeze-proof.json'),unchanged=True))
# Supplement direct-slot accounting with byte-bound source metadata and normalized XML replay.
nodes={}
for f in (A/'originals').glob('META-*.xml'):
 r=ET.parse(f).getroot();name=f.stem.removeprefix('META-');n=r.find('*[@frameid="'+name+'"]')
 assert r.findtext('metadata/query')=='META:'+name and r.findtext('metadata/num_results')=='1'
 assert r.find('metadata/PGDB').get('orgid')=='META' and r.get('ptools-version')=='27.0'
 assert n.get('ID')=='META:'+name and n.get('orgid')=='META' and n.get('detail')=='full'
 nodes[name]=n
slots=json.loads((A/'results/complete-retained-native-direct-slots.json').read_text())
assert len(slots)==1267
assert len({(x['frame'],x['global_index']) for x in slots})==1267
for x in slots:
 n=list(nodes[x['frame']])[x['global_index']-1]
 assert n.tag==x['slot'] and ET.tostring(n,encoding='unicode')==x['xml']
forward=[]
selected={'gene','component','components','cofactor','prosthetic-group','regulated-by','regulator','enzyme','species'}
for name,n in nodes.items():
 for slot in n:
  if slot.tag not in selected:continue
  for target in slot:
   if target.get('frameid') and target.get('frameid') not in nodes:
    forward.append((name,slot.tag,target.get('frameid'),target.tag,target.get('detail')))
a=json.loads((A/'results/unacquired-forward-original-prerequisites.json').read_text())
assert Counter(forward)==Counter((x['owner'],x['slot'],x['target'],x['type'],x['detail_in_owner']) for x in a)
assert len(forward)==70
save('independent-forward-scope.json',dict(selected_slots=sorted(selected),occurrences=len(forward),distinct_missing_targets=len({x[2] for x in forward}),rows=[dict(owner=x[0],slot=x[1],target=x[2],type=x[3],embedded_detail=x[4]) for x in sorted(forward,key=lambda x:tuple(str(t) for t in x))],scope='Finite direct-slot projection including embedded full objects; not all references in all slots, not universal closure.'))
save('final-input-verification.json',dict(utc=datetime.now(timezone.utc).isoformat(),packets=verifications,source_envelopes_checked=91,complete_retained_direct_slots_replayed=1267,finite_forward_occurrences_replayed=70,scope_excludes_ongoing_source_completion=True))
print(json.dumps({'packets':verifications,'slots_replayed':1267,'forward_occurrences':70},indent=2))
