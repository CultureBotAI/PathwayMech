# Initial independent acceptance handoff

Read REVIEW.md and primary-claim-review.json first. The frozen initial PWY-5177 preparation is accepted at its limited source-preparation scope. It is not a complete record, authority extension, full-source-graph closure, all-literature review or demonstration of the complete route in each attached organism.

Independent results: all 421 listed/423 physical author files match;91 native originals/1267 slots; five equations/20 occurrences/14 materials; first two sum exactly to the GCD composite;29 activity contexts preserve source-only boundaries. The complete 2009 main, all 3 HTML tables, all 4 original figure images and bibliography were read. Fifteen source-specific claim dispositions retain preparation, inference and negative-result limits.

Minor reporting clarification:62 mixed publication identifiers represent 44 native Publication frames, not 62 distinct papers. A successor literature ledger should normalize these aliases.

The root's separate frozen chemical diagnostic also binds exactly (27 listed/29 physical). Independent source parsing and calculation reproduce 12 InChI/key/formula/charge checks and four balanced fully specified equations. ETF balance is undetermined; the known-term residual is not a full imbalance. CML graph/stereo and issuer equivalence remain unaccepted.

All original and attempted audit files remain retained. No maintained inputs, source originals, Git/GitHub state or runtimes were changed. No ongoing source-completion packet was read. The review's final-input-verification.json and artifact-manifest.json bind its exact scope and outputs.
