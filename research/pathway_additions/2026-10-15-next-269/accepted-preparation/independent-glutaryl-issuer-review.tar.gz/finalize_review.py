from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

P=Path(__file__).resolve().parent
S=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
def now(): return datetime.now(timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value): (P/name).write_text(json.dumps(value,indent=2)+'\n')
def bind(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}

assert not (P/'artifact-manifest.json').exists() and not (P/'freeze-proof.json').exists()
target_manifest=json.loads((S/'artifact-manifest.json').read_text())

chem=json.loads((P/'chemical-review.json').read_text())
reaction=json.loads((P/'reaction-review.json').read_text())
bio=json.loads((P/'biological-identity-review.json').read_text())
integrity=json.loads((P/'source-integrity-replay.json').read_text())
unresolved=json.loads((S/'UNRESOLVED.json').read_text())
commands=[
 {'script':'review_chemistry.attempt1.py','runtime':'/private/tmp/npmech-rdkit-2026.03.5/bin/python3.13 -B','RDBASE':'/private/tmp/npmech-rdkit-2026.03.5/share/RDKit','exit':1,'stdout':'chemical-review.attempt1.stdout','stderr':'chemical-review.attempt1.stderr','disposition':'Reviewer helper applied protonation-layer removal to already-identical hydron; preserved and corrected, see chemical-attempt1-disposition.json.'},
 {'script':'review_chemistry.py','runtime':'/private/tmp/npmech-rdkit-2026.03.5/bin/python3.13 -B','RDBASE':'/private/tmp/npmech-rdkit-2026.03.5/share/RDKit','exit':0,'stdout':'chemical-review.stdout','stderr':'chemical-review.stderr'},
 *[{'script':script,'runtime':'/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B','exit':0,'stdout':stem+'.stdout','stderr':stem+'.stderr'} for script,stem in [('review_reactions.py','reaction-review'),('review_biological_identity.py','biological-identity-review'),('review_integrity.py','source-integrity-replay'),('review_targeted_context.py','targeted-context-review')]]
]
write('command-receipts.json',{'scope':'Actual terminal reviewer helper results; warnings remain in original stderr. No full repository gates were run or claimed. Run copied helpers only in a new scratch owner; biological helper requires retained fresh-reading files.','commands':commands})

review={
 'reviewer':'/root/next268_current_bigg_completion','prepared_utc':now(),
 'target':bind(S/'artifact-manifest.json'),
 'disposition':'bounded_acceptance_with_explicit_limits','author_defects_requiring_successor':[],
 'scientific_review_scope':'Twelve encoded compound identities, five native reaction/issuer families, and named taxon/gene/protein/sequence/kinetic conflicts; not maintained acceptance or merged-baseline dedup.',
 'independence':'No authorship of this next269 issuer packet. Prior next268 native/authority authorship disclosed; reused originals are rehashed and independently parsed, not self-accepted as maintained authority implementations.',
 'integrity':integrity,
 'checks':{'chemical_assertions':len(chem['checks']),'chemical_all_passed':all(x['passed'] for x in chem['checks']),'biological_assertions':len(bio['checks']),'biological_all_passed':all(x['passed'] for x in bio['checks']),'rhea_descriptions_parsed':reaction['rdf_descriptions_parsed'],'selected_rhea_nodes_replayed':reaction['all_selected_RDF_statements_replayed'],'runtime_files_unchanged':chem['runtime_bound_files_verified_before_after'],'cds_translations':len(bio['translations'])},
 'compound_dispositions':[{'native':x['native'],'chebi':'CHEBI:'+x['chebi'],'charge':x['native_issuer']['charge'],'kegg':x['kegg'],'native_encoded_normalized_ionic_structure_supported':True,'kegg_exact_ionic_graph':x['kegg_exact_ionic_graph'],'CML_stereo_accepted':False,'literal_tautomer_or_proton_localization_accepted':False} for x in chem['rows']],
 'reaction_dispositions':[{'native':x['native'],'pathway_direction':x['pathway_direction'],'rhea_directional':x['rhea_directional'],'decision':('generic_ETF_state_correspondence_only' if x['whole_ETF_balance_undetermined'] else 'exact_replacement_rejected_located_sodium' if x['native']=='GLUTACONYL-COA-DECARBOXYLASE-RXN' else 'exact_native_ionic_sides_and_coefficients_supported'),'evidence':'reaction-review.json'} for x in reaction['rows']],
 'additional_notes':[{'id':'IR269-N01','kind':'source_label_anomaly_nonblocking','native':'RXN-11667','description':reaction['source_label_anomaly'],'action':'Preserve source common-name and actual equation as distinct; do not use the common-name as oxidation evidence.','evidence':'reaction-review.json'}],
 'unresolved_dispositions':[dict(x,independent_disposition='Sustained; only issuer-preparation review component discharged here.' if x['id']=='IP01' else 'Sustained within finite review scope.') for x in unresolved],
 'excluded':['Maintained record/authority acceptance','Merged265 baseline rebind or exhaustive hidden/ignored dedup','Independent full scientific acceptance of all676 prior artifacts','CML stereo/literal tautomer acceptance','Whole-ETF exact identity and full balance','Unacquired1993 full-main and unread2010 primary','Full2018 supplement visual/BIFF/hidden-cell/formula review','Rhea13389/47420 or exhaustive alternative reaction search','One-strain all-five-member functional or physiological flux proof'],
 'evidence':[bind(P/name) for name in ['REVIEW.md','chemical-review.json','reaction-review.json','biological-identity-review.json','targeted-context-review.json','source-integrity-before.json','source-integrity-replay.json','2009-targeted-passages.json','2018-targeted-reading.json','chemical-attempt1-disposition.json','command-receipts.json']]
}
write('review.json',review)
(P/'HANDOFF.md').write_text('''# Frozen independent issuer review handoff

Target: `/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation`, manifest `1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3`.

**Accepted within the finite issuer-preparation scope.** No author defect requires a successor. See REVIEW.md and review.json for all twelve compound, five reaction and ten unresolved dispositions. This is not maintained record acceptance, full source/primary acceptance, or actual merged-baseline duplicate rebind.

Independent work: 229 target files and 676 prior packet files rehashed; 98 acquisition rows and 75 saved bodies replayed; 170 chemical and 101 biological identity assertions passed; 326,097 Rhea descriptions parsed and 69 selected nodes replayed; two exact CDS translations; 77 prescribed RDKit runtime files unchanged. Nine KEGG ionic mismatches, generic ETF scope, Rhea sodium transport rejection, exact strain/gene/sequence conflicts and kinetic discrepancies remain explicit. Six 2018 supplement primer rows retain gdh + pp0159 and csiD + lhgO construct scope.

Additional source note IR269-N01: RXN-11667 is called dehydrogenase in the native common-name but its actual equation is hydration/dehydration. The preparation handles the equation correctly. Preserve this anomaly in future curation.

The terminal source-integrity-after.json rebinds target, prior packets and runtime. The whole review packet, including failed reviewer helper attempt, scripts, reading projections, logs and evidence, is covered by artifact-manifest.json. Only the root artifact-manifest.json and freeze-proof.json exclude themselves. All local work is terminal. No maintained/Git/GH/runtime writes, installs, network acquisition or children. Treat this owner as immutable; any successor requires a new owner.

Reproduce by copying helpers and their reading inputs to a fresh scratch owner and using the exact runtimes in command-receipts.json. The Rhea/metadata/sequence helpers use `/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B`; chemistry uses `RDBASE=/private/tmp/npmech-rdkit-2026.03.5/share/RDKit /private/tmp/npmech-rdkit-2026.03.5/bin/python3.13 -B`. Never rerun a helper in this frozen owner.
''')

# Recheck physical inventories, all prior bindings and prescribed runtime before freezing.
before=json.loads((S/'inputs/frozen-source-bindings-before.json').read_text())
def inventory(root):
    paths=sorted(root.rglob('*'))
    assert not any(p.is_symlink() for p in paths),str(root)
    return {str(p.relative_to(root)):p for p in paths if p.is_file()}
def verify(root,rows,excluded=()):
    files=inventory(root)
    assert set(files)=={x['path'] for x in rows}|set(excluded),str(root)
    for x in rows:
        p=root/x['path']; assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],str(p)
    return len(files)
assert sha(S/'artifact-manifest.json')=='1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3'
assert sha(S/'artifact-manifest.json')==sha(P/'source-manifest.json')
assert sha(S/'freeze-proof.json')==sha(P/'source-freeze-proof.json')
target_count=verify(S,target_manifest['files'],target_manifest['excluded'])
prior_counts=[]
for packet in before:
    root=Path(packet['root']); n=verify(root,packet['physical_files'])
    assert sha(root/'artifact-manifest.json')==packet['manifest_sha256']
    prior_counts.append({'root':str(root),'physical_files':n,'manifest_sha256':packet['manifest_sha256']})
runtime=json.loads((S/'inputs/rdkit-runtime-binding.json').read_text())['binding']['files']
for x in runtime: assert sha(Path(x['path']))==x['sha256'],x['path']
after={'completed_utc':now(),'target':str(S),'target_manifest_sha256':sha(S/'artifact-manifest.json'),'target_physical_files_verified':target_count,'target_listed_files_verified':len(target_manifest['files']),'prior_packet_verification':prior_counts,'prior_physical_files_verified':sum(x['physical_files'] for x in prior_counts),'runtime_files_unchanged':len(runtime),'hidden_and_ignored_included':True,'inventories_exact_no_extra_files':True,'scope':'Byte-integrity rebind only; not actual merged-baseline duplicate review or full semantic review of prior artifacts.'}
write('source-integrity-after.json',after)
review['terminal_input_integrity']=bind(P/'source-integrity-after.json')
review['completed_utc']=now()
write('review.json',review)

excluded={'artifact-manifest.json','freeze-proof.json'}
files=inventory(P)
assert not (set(files)&excluded)
rows=[{'path':name,'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in files.items()]
manifest={'owner':str(P),'reviewer':'/root/next268_current_bigg_completion','files':rows,'file_count':len(rows),'listed_bytes':sum(x['bytes'] for x in rows),'excluded':sorted(excluded)}
write('artifact-manifest.json',manifest)
freeze={'frozen_utc':now(),'owner':str(P),'manifest_sha256':sha(P/'artifact-manifest.json'),'listed_files':len(rows),'physical_files':len(rows)+2,'target_manifest_sha256':sha(S/'artifact-manifest.json'),'review_sha256':sha(P/'review.json'),'handoff_sha256':sha(P/'HANDOFF.md'),'all_jobs_terminal':True,'status':'frozen; no further writes; successor requires new owner'}
write('freeze-proof.json',freeze)
assert verify(P,rows,excluded)==len(rows)+2
print(json.dumps({'status':'FROZEN','owner':str(P),'manifest':bind(P/'artifact-manifest.json'),'freeze':bind(P/'freeze-proof.json'),'handoff':bind(P/'HANDOFF.md'),'review':bind(P/'review.json'),'listed':len(rows),'physical':len(rows)+2,'all_replayed':True},indent=2))

