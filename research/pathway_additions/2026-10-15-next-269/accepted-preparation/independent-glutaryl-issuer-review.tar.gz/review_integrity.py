from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json
S=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
groups=json.loads((S/'inputs/frozen-source-bindings-before.json').read_text());prior=[]
for g in groups:
 root=Path(g['root']);actual={x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file()};expected={x['path'] for x in g['physical_files']};assert actual==expected
 for row in g['physical_files']:
  path=root/row['path'];assert not path.is_symlink();assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],path
 assert sha(root/'artifact-manifest.json')==g['manifest_sha256'];prior.append({'root':str(root),'physical_files_verified':len(expected),'manifest_sha256':g['manifest_sha256']})
reused=json.loads((S/'inputs/reused-issuing-originals.json').read_text())
for x in reused:assert sha(Path(x['source']))==sha(S/x['target'])==x['sha256'];assert Path(x['source']).stat().st_size==(S/x['target']).stat().st_size==x['bytes']
a=json.loads((S/'results/acquisition-inventory.json').read_text());statuses=Counter();bodies=[]
for row in a['rows']:
 receipt=json.loads((S/row['receipt']).read_text())[row['row']-1];assert {k:v for k,v in row.items() if k not in ['receipt','row']}==receipt
 statuses[str(row.get('status','exception'))]+=1
 if 'path' in row:
  file=S/row['path'];assert sha(file)==row['sha256'] and file.stat().st_size==row['bytes'];bodies.append(row['path'])
assert len(a['rows'])==98 and dict(statuses)==a['status_counts'] and len(bodies)==len(set(bodies))==75
m=json.loads((S/'artifact-manifest.json').read_text());assert len(m['files'])==227
for x in m['files']:assert sha(S/x['path'])==x['sha256'],x['path']
out={'checked_utc':datetime.now(timezone.utc).isoformat(),'prior_frozen_packet_bindings':prior,'prior_physical_members_verified':sum(x['physical_files_verified'] for x in prior),'all15reused_originals_and_receipts_verified':len(reused)==15,'current_source_227listed_files_unchanged':True,'acquisition_attempts':len(a['rows']),'status_counts':dict(statuses),'unique_saved_response_bodies':len(bodies),'all_receipt_rows_match':True,'scope':'Physical inventory includes hidden and ignored files; confirms selected packet integrity, not semantic review of all prior content or merged-baseline dedup.'};assert out['prior_physical_members_verified']==676;(P/'source-integrity-replay.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
