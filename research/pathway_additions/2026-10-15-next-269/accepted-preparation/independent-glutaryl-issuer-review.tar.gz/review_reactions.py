from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import json,hashlib,gzip,re,xml.etree.ElementTree as E
S=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation');P=Path(__file__).resolve().parent;R='http://rdf.rhea-db.org/';D='http://www.w3.org/1999/02/22-rdf-syntax-ns#'
expected=json.loads((S/'results/rhea-five-family-replay.json').read_text());selected=set(expected['complete_selected_statements']);graph={};count=0
with gzip.open(S/'originals/rhea.rdf.gz','rb') as h:
 for _,el in E.iterparse(h,events=['end']):
  if el.tag!='{'+D+'}Description':continue
  count+=1;uri=el.get('{'+D+'}about')
  if uri in selected:graph.setdefault(uri,[]).extend({'predicate':x.tag[1:].replace('}',''),'resource':x.get('{'+D+'}resource'),'literal':x.text,'attributes':dict(x.attrib)} for x in el)
  el.clear()
assert count==326097 and graph==expected['complete_selected_statements'] and len(graph)==69
v=lambda u,p:[x['resource'] if x['resource'] is not None else x['literal'] for x in graph[u] if x['predicate']==p]
def one(u,p):
 values=v(u,R+p);assert len(set(values))==1,(u,p,values);return values[0]
chem=json.loads((P/'chemical-review.json').read_text())['rows'];mapping={x['native']:'CHEBI:'+x['chebi'] for x in chem};kmapping={x['native']:x['kegg'] for x in chem};mapping.update({'ETF-Oxidized':'GENERIC:10685','ETF-Reduced':'GENERIC:10686'});kmapping.update({'ETF-Oxidized':'C04253','ETF-Reduced':'C04570'})
pwy_path=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation/originals/META-PWY-5177.xml');pwy=E.parse(pwy_path).getroot().find('Pathway');directions={x.find('Reaction').get('frameid'):x.findtext('direction') for x in pwy.findall('reaction-layout')};assert len(directions)==5
plans=[('GLUTARYL-COA-DEHYDROG-RXN','20590','R10074','L2R'),('GLUTACONYL-COA-DECARBOXYLASE-RXN','23973','R03028','L2R'),('RXN-11667','26560','R03026','R2L'),('RXN-11662','30800','R01975','L2R'),('ACETYL-COA-ACETYLTRANSFER-RXN','21038','R00238','R2L')]
families=[x.split('\t') for x in (S/'originals/rhea-directions.tsv').read_text().splitlines()[1:]];rows=[];net=Counter()
def terms(s):
 out=Counter()
 for x in s:
  ident=next(n for n in x if n.get('frameid'));out[ident.get('frameid')]+=int(x.findtext('coefficient') or 1)
 return out
def diff(a,b):return {k:a[k]-b[k] for k in sorted(a.keys()|b.keys()) if a[k]!=b[k]}
for native,rid,kid,kdir in plans:
 n=E.parse(S/'inputs'/('META-'+native+'.xml')).getroot().find('Reaction');assert n.get('frameid')==native and n.get('detail')=='full';left,right=terms(n.findall('left')),terms(n.findall('right'))
 if directions[native]=='R2L':left,right=right,left
 issued=[]
 family=next(x for x in families if rid in x);assert rid==family[1] or rid==family[2];assert one(R+family[0],'status')==R+'Approved'
 for role in ['substrates','products']:
  side=one(R+rid,role);out=Counter()
  for t in graph[side]:
   match=re.fullmatch(re.escape(R)+'contains(\d+)',t['predicate'])
   if not match:continue
   participant=t['resource'];compound=one(participant,'compound');ident=one(compound,'accession');loc=v(participant,R+'location');assert len(loc)<=1;key=ident+('['+loc[0].removeprefix(R).lower()+']' if loc else '');out[key]+=int(match.group(1))
  issued.append(out)
 residuals=[diff(Counter({mapping[k]:z for k,z in side.items()}),iss) for side,iss in zip([left,right],issued)]
 expected_res=([{'CHEBI:29101[in]':-1},{'CHEBI:29101[out]':-1}] if rid=='23973' else [{},{}]);assert residuals==expected_res,(native,residuals)
 formula=Counter();unknown=[]
 for sign,side in [(-1,left),(1,right)]:
  for ident,coeff in side.items():
   net[ident]+=sign*coeff
   if ident.startswith('ETF-'):unknown.append(ident);continue
   c=json.loads((S/'originals'/('ChEBI-'+mapping[ident].split(':')[1]+'.json')).read_text())['chemical_data']
   for el,num in re.findall(r'([A-Z][a-z]?)(\d*)',c['formula']):formula[el]+=sign*coeff*int(num or 1)
   formula['charge']+=sign*coeff*c['charge']
 balance={k:z for k,z in formula.items() if z};assert balance==({'H':-3,'charge':-1} if unknown else {}),(native,balance)
 raw=(S/'originals'/('KEGG-'+kid+'.txt')).read_text();eq=next(l[12:].strip() for l in raw.splitlines() if l.startswith('EQUATION'));sides=[]
 for half in eq.split(' <=> '):
  d=Counter()
  for term in half.split(' + '):
   match=re.fullmatch(r'(?:(\d+) )?(C\d+)',term);assert match,term;d[match.group(2)]+=int(match.group(1) or 1)
  sides.append(d)
 if kdir=='R2L':sides.reverse()
 kres=[diff(Counter({kmapping[k]:z for k,z in side.items()}),kside) for side,kside in zip([left,right],sides)];assert kres==([{'C00080':1},{}] if rid in ['20590','23973'] else [{},{}])
 rows.append({'native':native,'source_direction':n.findtext('reaction-direction'),'pathway_direction':directions[native],'native_left':dict(left),'native_right':dict(right),'rhea_directional':rid,'family':family,'rhea_issued_sides':[dict(x) for x in issued],'native_minus_rhea':residuals,'kegg':kid,'kegg_equation':eq,'native_minus_kegg_nonidentity_microstate_mapping':kres,'known_balance_residual':balance,'whole_ETF_balance_undetermined':bool(unknown),'source_common_name':n.findtext('common-name'),'source_ec':n.findtext('ec-number')})
for ident in ['ETF-Oxidized','ETF-Reduced']:
 n=E.parse(S/'inputs'/('META-'+ident+'.xml')).getroot().find('Protein');assert n is not None and n.get('class')=='true'
for num in ['10685','10686']:
 u=R+'Compound_'+num;assert not v(u,R+'formula') and not v(u,R+'charge');assert R+'GenericPolypeptide' in v(u,'http://www.w3.org/2000/01/rdf-schema#subClassOf')
assert one(R+'23972','isTransport')=='true'
net={k:z for k,z in sorted(net.items()) if z};assert net==json.loads((S/'results/formal-balance-and-kegg-side-replay.json').read_text())['route_net_native_coefficients_products_minus_substrates']
out={'completed_utc':datetime.now(timezone.utc).isoformat(),'rdf_descriptions_parsed':count,'all_selected_RDF_statements_replayed':len(graph),'pathway_original':str(pwy_path),'pathway_sha256':hashlib.sha256(pwy_path.read_bytes()).hexdigest(),'rows':rows,'formal_route_net':net,'generic_ETF':'No whole formula/charge or sequence; native class states and generic Rhea polypeptides only. No free-FAD identity transfer.','source_label_anomaly':'RXN-11667 common-name says dehydrogenase while its exact equation is dehydration/hydration and its source EC is EC-4.2.1.150. Preserve the native label/source distinction; do not use this label as oxidation evidence.','scope':'Five selected native families, actual pathway direction, side-specific location and ionic states; not an alternative-ID exhaustion or full physiological flux review.'};(P/'reaction-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'reactions':len(rows),'rdf_descriptions':count,'selected_statements':len(graph),'exact_small_molecule_reactions':3,'generic_ETF_reactions':1,'sodium_transport_mismatches':1}))
