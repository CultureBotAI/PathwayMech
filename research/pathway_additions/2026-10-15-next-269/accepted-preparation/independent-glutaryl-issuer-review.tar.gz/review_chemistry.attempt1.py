from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,re,xml.etree.ElementTree as E
from rdkit import Chem,rdBase
from rdkit.Chem import rdMolDescriptors
S=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation');P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bindings=json.loads((S/'inputs/rdkit-runtime-binding.json').read_text())['binding']['files']
for x in bindings:assert sha(Path(x['path']))==x['sha256'],x['path']
assert rdBase.rdkitVersion=='2026.03.5'
rows=[];checks=[]
def chk(name,value):checks.append({'name':name,'passed':bool(value)});assert value,name
def eq(a,b):return a.GetNumAtoms()==b.GetNumAtoms() and a.GetNumBonds()==b.GetNumBonds() and a.HasSubstructMatch(b,useChirality=True) and b.HasSubstructMatch(a,useChirality=True)
def state(m):return {'formula':rdMolDescriptors.CalcMolFormula(m),'charge':Chem.GetFormalCharge(m),'inchi':Chem.MolToInchi(m),'key':Chem.MolToInchiKey(m),'chiral':Chem.FindMolChiralCenters(m,includeUnassigned=True),'stereo_bonds':[str(b.GetStereo()) for b in m.GetBonds() if b.GetStereo()!=Chem.BondStereo.STEREONONE]}
def withoutp(i):return '/'.join(x for x in i.split('/') if not x.startswith('p'))
for expected in json.loads((S/'inputs/native-chebi-candidates.json').read_text()):
 native=expected['native_id'];path=S/'inputs'/('META-'+native+'.xml');doc=E.parse(path).getroot();nodes=[x for x in doc if x.tag=='Compound'];chk(native+' full root identity',len(nodes)==1);n=nodes[0];chk(native+' identity envelope',n.attrib.get('ID')=='META:'+native and n.attrib.get('frameid')==native and n.attrib.get('orgid')=='META' and n.attrib.get('detail')=='full' and doc.findtext('metadata/query')=='META:'+native)
 cross={x.findtext('dblink-db'):x.findtext('dblink-oid') for x in n.findall('dblink')};chebi=cross['CHEBI'];c=json.loads((S/'originals'/('ChEBI-'+chebi+'.json')).read_text());chk(native+' issuer ID',c['chebi_accession']=='CHEBI:'+chebi and c['is_released']);a=Chem.MolFromInchi(n.findtext('inchi'));b=Chem.MolFromInchi(c['default_structure']['standard_inchi']);sm=Chem.MolFromSmiles(c['default_structure']['smiles']);chk(native+' parse',all(x is not None for x in [a,b,sm]));chk(native+' exact stereo graph',eq(a,b));chk(native+' exact InChI',Chem.MolToInchi(a)==Chem.MolToInchi(b));chk(native+' issuer SMILES consistency',Chem.MolToInchi(sm)==Chem.MolToInchi(b));chk(native+' key',Chem.MolToInchiKey(a)==n.findtext('inchi-key').removeprefix('InChIKey=')==c['default_structure']['standard_inchi_key']);chk(native+' formula/charge',re.sub(r'[+-]\d*$','',rdMolDescriptors.CalcMolFormula(b))==c['chemical_data']['formula'] and Chem.GetFormalCharge(a)==Chem.GetFormalCharge(b)==c['chemical_data']['charge'])
 k=cross['LIGAND-CPD'];km=Chem.MolFromMolFile(str(S/'originals'/('KEGG-'+k+'.mol')),sanitize=True,removeHs=True,strictParsing=True);chk(native+' KEGG parse',km is not None);ki=Chem.MolToInchi(km);exact=eq(km,a);an=Chem.MolFromInchi(withoutp(Chem.MolToInchi(a)));kn=Chem.MolFromInchi(withoutp(ki));chk(native+' KEGG only p-layer-normalized identity',eq(an,kn));
 cml=n.find('cml/molecule');rw=Chem.RWMol();indices={}
 for atom in cml.findall('atomArray/atom'):
  at=Chem.Atom(atom.get('elementType'));at.SetFormalCharge(int(atom.get('formalCharge','0')));indices[atom.get('id')]=rw.AddAtom(at)
 for bond in cml.findall('bondArray/bond'):
  l,r=(bond.get('atomRefs') or bond.get('atomRefs2')).split();rw.AddBond(indices[l],indices[r],{1:Chem.BondType.SINGLE,2:Chem.BondType.DOUBLE,3:Chem.BondType.TRIPLE}[int(bond.get('order'))])
 cm=rw.GetMol();Chem.SanitizeMol(cm);plain=Chem.Mol(a);Chem.RemoveStereochemistry(plain);chk(native+' CML no-stereo normalized constitution',Chem.MolToInchi(cm)==Chem.MolToInchi(plain));chk(native+' CML formula/charge',rdMolDescriptors.CalcMolFormula(cm)==rdMolDescriptors.CalcMolFormula(a) and Chem.GetFormalCharge(cm)==Chem.GetFormalCharge(a)==int(cml.get('formalCharge','0')))
 mutated=None
 for atom in a.GetAtoms():
  if atom.GetChiralTag()!=Chem.ChiralType.CHI_UNSPECIFIED:
   mutant=Chem.Mol(a);mutant.GetAtomWithIdx(atom.GetIdx()).InvertChirality();mutated=not eq(a,mutant);chk(native+' epimer rejected',mutated);break
 rows.append({'native':native,'chebi':chebi,'native_version':doc.find('metadata/PGDB').get('version'),'native_sha256':sha(path),'issuer_sha256':sha(S/'originals'/('ChEBI-'+chebi+'.json')),'native_issuer':state(a),'kegg':k,'kegg_state':state(km),'kegg_exact_ionic_graph':exact,'generic_literal_smiles':'[R]' in (cml.findtext("string[@title='smiles']") or ''),'CML_scope':'Formula, charge and stereo-stripped normalized InChI only; no CML stereo acceptance.'})
chk('twelve rows',len(rows)==12);chk('nine KEGG ionic mismatches',sum(not r['kegg_exact_ionic_graph'] for r in rows)==9);chk('five generic native SMILES',sum(r['generic_literal_smiles'] for r in rows)==5)
for native in ['CROTONYL-COA','GLUTACONYL-COA']:
 row=next(r for r in rows if r['native']==native);chk(native+' E double bond present','STEREOE' in row['native_issuer']['stereo_bonds'])
for x in bindings:assert sha(Path(x['path']))==x['sha256']
out={'completed_utc':datetime.now(timezone.utc).isoformat(),'runtime_version':rdBase.rdkitVersion,'runtime_bound_files_verified_before_after':len(bindings),'scope':'Independent original parsing and finite exact graph checks; no CML stereo acceptance, no global identifier search, no whole-ETF assertion. Standard InChI normalization is explicit.','checks':checks,'rows':rows};(P/'chemical-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'checks':len(checks),'compounds':len(rows),'kegg_ionic_mismatches':9,'runtime_files':len(bindings)}))
