from pathlib import Path
from datetime import datetime, timezone
from html.parser import HTMLParser
import hashlib, json, xml.etree.ElementTree as E

P = Path(__file__).resolve().parent
S = Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
C = Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
def bind(p):
    return {'path': str(p), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}

class Rows(HTMLParser):
    def __init__(self):
        super().__init__(); self.rows=[]; self.row=None; self.cell=None
    def handle_starttag(self, tag, attrs):
        if tag == 'tr': self.row=[]
        if tag in ('td', 'th') and self.row is not None: self.cell=[]
    def handle_data(self, data):
        if self.cell is not None: self.cell.append(data)
    def handle_endtag(self, tag):
        if tag in ('td', 'th') and self.cell is not None:
            self.row.append(' '.join(''.join(self.cell).split())); self.cell=None
        if tag == 'tr' and self.row is not None:
            self.rows.append(self.row); self.row=None

supp = C/'reading/quicklook/41467_2018_4513_MOESM4_ESM.xls.qlpreview/Attachment3.html'
parser=Rows(); parser.feed(supp.read_text())
selected=[row for row in parser.rows if any(x in ' '.join(row) for x in ('gdh-cF','gdh-cR','csiD-cF','csiD-cR'))]
assert len(selected)==6
assert all('gdh and pp0159' in ' '.join(row) for row in selected if 'gdh-c' in ' '.join(row))
assert all('csiD and lhgO' in ' '.join(row) for row in selected if 'csiD-c' in ' '.join(row))

gpath=S/'inputs/META-G-4001.xml'
gene=E.parse(gpath).getroot().find('Gene')
dblink=[E.tostring(x,encoding='unicode') for x in gene.findall('dblink') if x.findtext('dblink-oid')=='AE016774']
assert len(dblink)==1 and 'PART-OF' in dblink[0] and 'ENTREZ' in dblink[0]
product=E.tostring(gene.find('product'),encoding='unicode')
assert 'MONOMER-5381' in product
ktpath=S/'inputs/META-G1G01-166.xml'
kt=E.parse(ktpath).getroot().find('Gene')
kt_slots={x.tag: E.tostring(x,encoding='unicode') for x in kt if x.tag in ('left-end-position','right-end-position','transcription-direction','product')}
assert any('168404' in x for x in kt_slots.values()) and any('169585' in x for x in kt_slots.values())
retired=S/'originals/retry-NCBI-gene-1043671.xml'
old=E.parse(retired).getroot()
date=old.find('.//Gene-track_discontinue-date')
assert date.findtext('.//Date-std_year')=='2020' and date.findtext('.//Date-std_month')=='4' and date.findtext('.//Date-std_day')=='2'
out={
 'completed_utc':datetime.now(timezone.utc).isoformat(),
 '2018_complementation':{
  'source_original':bind(C/'originals/41467_2018_4513_MOESM4_ESM.xls'),
  'retained_rendered_derivative':bind(supp), 'selected_rows':selected,
  'scope':'Fresh targeted parsing and reading of six rows in the previously retained Quick Look derivative of Supplementary Data 2. Original and derivative bytes are verified. This is not a new BIFF/hidden-cell/formula audit, full visual supplement review, or full primary-source acceptance.',
  'disposition':'Preserve gdh + pp0159 and csiD + lhgO insert boundaries; do not assign PP0159 function from inclusion.'},
 'native_K172_cross_reference':{'source':bind(gpath),'dblink':dblink,'product':product,'disposition':'PART-OF is not exact identity; actual AE016774.1 is KT2440.'},
 'native_KT2440_coordinates':{'source':bind(ktpath),'slots':kt_slots,'disposition':'Native coordinates agree with NC_002947.4, not the two-nucleotide-offset older AE016774.1 coordinate system.'},
 'retired_gene_date':{'source':bind(retired),'slot':E.tostring(date,encoding='unicode'),'disposition':'Discontinued 2020-04-02; no current-id in this exact response, not a global claim that no replacement exists.'},
 'prior_inadequate_text_attempts':{
  'paths':[bind(C/'reading/SI1.txt'),bind(C/'reading/SI2.txt')],
  'disposition':'Initial targeted rg reads encountered mixed binary/text and were not accepted as complete readable supplement evidence. Switched to retained rendered worksheet HTML. No source files modified.'}
}
(P/'targeted-context-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'supplement_primer_rows':len(selected),'native_cross_reference_verified':True,'native_KT_coordinates_verified':True,'retired_gene_date_verified':True}))
