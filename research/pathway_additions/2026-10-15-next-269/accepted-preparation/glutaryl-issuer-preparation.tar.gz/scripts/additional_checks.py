from pathlib import Path
from collections import Counter
import hashlib,json,re
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
# Independently translate the two exact retrieved genomic CDS records (bacterial code 11).
bases='TCAG'; aas='FFLLSSSSYY**CC*WLLLLPPPPHHQQRRRRIIIMTTTTNNKKSSRRVVVVAAAADDEEGGGG'
code=dict(zip((a+b+c for a in bases for b in bases for c in bases),aas))
proteins=json.loads((O/'results/ncbi-protein-projection.json').read_text())
translations=[]
for f,accession in [('ENA-FJ688103.txt','ACP50614.1'),('ENA-AE016774.txt','AAN65791.1')]:
 s=(O/'originals'/f).read_text(); dna=re.sub('[^acgt]','',s.split('\nSQ   Sequence',1)[1].split('\n',1)[1].split('//')[0]).upper()
 blocks=re.split(r'(?=^FT   \S)',s,flags=re.M)
 b=next(x for x in blocks if x.startswith('FT   CDS') and f'/protein_id="{accession}"' in x)
 a,z=map(int,re.match(r'FT   CDS\s+(\d+)\.\.(\d+)',b).groups())
 d=dna[a-1:z]; aa=''.join(code[d[i:i+3]] for i in range(0,len(d),3)); assert aa.endswith('*')
 if d[:3] in ['TTG','CTG','ATT','ATC','ATA','ATG','GTG']:aa='M'+aa[1:]
 aa=aa[:-1]; deposited=re.sub(r'\s','',re.sub(r'^FT\s*','',re.search(r'/translation="([^"]+)"',b,re.S)[1],flags=re.M))
 target=next(x['sequence'] for x in proteins if x['version']==accession)
 assert aa==deposited==target
 translations.append({'file':f,'sha256':hashlib.sha256((O/'originals'/f).read_bytes()).hexdigest(),'protein':accession,'cds_location':[a,z],'cds_nucleotides':len(d),'translation_table':11,'start_codon':d[:3],'length':len(aa),'sequence_sha256':hashlib.sha256(aa.encode()).hexdigest(),'recomputed_dna_translation_equals_deposited_translation_and_ncbi_protein':True,'source_cds_feature':b})
(O/'results/independent-cds-translations.json').write_text(json.dumps(translations,indent=2)+'\n')
# Recompute exact native route-side incidence, using issuing ChEBI ionic formulas.
chem={}
for f in (O/'originals').glob('ChEBI-*.json'):
 if 'receipt' in f.name:continue
 j=json.loads(f.read_text()); chem[j['chebi_accession']]=j['chemical_data']
ids={x['native_id']:'CHEBI:'+str(x['chebi']).replace('CHEBI:','') for x in json.loads((O/'inputs/native-chebi-candidates.json').read_text())}
native=json.loads((O/'inputs/five-member-equations.json').read_text())['rows']
ki=json.loads((O/'results/kegg-complete-candidate-assessment.json').read_text())
nk={x['native_id']:x['kegg'] for x in ki['compounds']};nk.update({'ETF-Oxidized':'C04253','ETF-Reduced':'C04570'})
dispositions={r['native']:r for r in json.loads((O/'results/five-reaction-dispositions.json').read_text())}
rows=[];net=Counter()
for r in native:
 q=r['equation'];q=q if r['selected_direction']=='L2R' else {'left':q['right'],'right':q['left']}
 residue=Counter();unknown=[]
 for side,sign in [('left',-1),('right',1)]:
  for t in q[side]:
   net[t['id']]+=sign*t['coefficient']; key=ids.get(t['id'])
   if key is None:unknown.append({'side':side,**t});continue
   d=chem[key]
   for e,n in re.findall(r'([A-Z][a-z]?)(\d*)',d['formula']):residue[e]+=sign*t['coefficient']*int(n or 1)
   residue['charge']+=sign*t['coefficient']*d['charge']
 disp=dispositions[r['frame']];k=next(x for x in ki['reactions'] if x['file']=='KEGG-'+disp['kegg']+'.txt')
 kl,kr=k['fields']['EQUATION'][0].split(' <=> ')
 if disp['kegg_pathway_direction']=='R2L':kl,kr=kr,kl
 def parse(s):
  d=Counter()
  for t in s.split(' + '):
   parts=t.split();d[parts[-1]]+=int(parts[0]) if len(parts)>1 else 1
  return d
 krx={'left':parse(kl),'right':parse(kr)};diff={}
 for side in ['left','right']:
  n=Counter()
  for t in q[side]:n[nk[t['id']]]+=t['coefficient']
  diff[side]={i:n[i]-krx[side][i] for i in sorted(n.keys()|krx[side].keys()) if n[i]!=krx[side][i]}
 rows.append({'native':r['frame'],'selected_direction':r['selected_direction'],'known_formula_residual_products_minus_substrates':{k:v for k,v in sorted(residue.items()) if v},'unknown_whole_materials':unknown,'complete_formal_balance':not any(residue.values()) if not unknown else None,'kegg':disp['kegg'],'kegg_source_equation':k['fields']['EQUATION'][0],'selected_kegg_direction':disp['kegg_pathway_direction'],'native_minus_kegg_side_terms_under_nonidentity_microstate_mapping':diff,'mapping_limit':'KEGG IDs for nine compounds are distinct protonation states, so even zero residual here is not exact issuing ionic equation identity.'})
assert sum(r['complete_formal_balance'] is True for r in rows)==4
(O/'results/formal-balance-and-kegg-side-replay.json').write_text(json.dumps({'rows':rows,'route_net_native_coefficients_products_minus_substrates':{k:v for k,v in sorted(net.items()) if v},'complete_route_balance':'undetermined: whole ETF formulas/charges unspecified','physiology':'Formal stoichiometry neither establishes physiological electron acceptor identity nor whole-route flux in any strain.'},indent=2)+'\n')
print(json.dumps({'translations':[{k:v for k,v in r.items() if k!='source_cds_feature'} for r in translations],'balance':rows,'net':{k:v for k,v in sorted(net.items()) if v}},indent=2))
