from pathlib import Path
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
from rdkit.Chem.MolStandardize import rdMolStandardize

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')


def flat(text):
    fields = {}
    key = None
    for line in text.splitlines():
        if line == '///':
            continue
        if line[:12].strip():
            key = line[:12].strip()
        if key:
            fields.setdefault(key, []).append(line[12:])
    return fields


def info(m):
    return {'formula': rdMolDescriptors.CalcMolFormula(m), 'charge': Chem.GetFormalCharge(m),
            'isomeric_smiles': Chem.MolToSmiles(m), 'inchi': Chem.MolToInchi(m), 'inchi_key': Chem.MolToInchiKey(m),
            'tetrahedral_centres': Chem.FindMolChiralCenters(m, includeUnassigned=True),
            'double_bond_stereo': [str(b.GetStereo()) for b in m.GetBonds() if b.GetBondType() == Chem.BondType.DOUBLE]}


def iso(a, b):
    return a.GetNumAtoms() == b.GetNumAtoms() and a.GetNumBonds() == b.GetNumBonds() and a.HasSubstructMatch(b, useChirality=True) and b.HasSubstructMatch(a, useChirality=True)


rows = []
for r in json.loads((O / 'inputs/native-chebi-candidates.json').read_text()):
    p = O / 'inputs' / ('META-' + r['native_id'] + '.xml')
    obj = ET.parse(p).getroot().find('Compound')
    ids = [x.findtext('dblink-oid') for x in obj.findall('dblink') if x.findtext('dblink-db') == 'LIGAND-CPD']
    assert len(ids) == 1
    kid = ids[0]
    kf = O / 'originals' / ('KEGG-' + kid + '.txt')
    mf = O / 'originals' / ('KEGG-' + kid + '.mol')
    fields = flat(kf.read_text())
    assert fields['ENTRY'][0].split()[0] == kid
    m = Chem.MolFromMolBlock(mf.read_text(), sanitize=True, removeHs=True, strictParsing=True)
    assert m is not None
    native = Chem.MolFromInchi(r['native_inchi'])
    nu = rdMolStandardize.Uncharger().uncharge(native)
    ku = rdMolStandardize.Uncharger().uncharge(m)
    rows.append({'native_id': r['native_id'], 'native_chebi': r['chebi'], 'kegg': kid,
                 'kegg_record_sha256': hashlib.sha256(kf.read_bytes()).hexdigest(),
                 'kegg_mol_sha256': hashlib.sha256(mf.read_bytes()).hexdigest(),
                 'selected_issuing_fields': {k: fields[k] for k in ['ENTRY','NAME','FORMULA','COMMENT','DBLINKS'] if k in fields},
                 'native': info(native), 'kegg_mol': info(m),
                 'exact_parsed_stereospecific_graph': iso(native, m),
                 'exact_standard_inchi': Chem.MolToInchi(native) == Chem.MolToInchi(m),
                 'after_explicit_analytical_uncharging': {'native': info(nu), 'kegg': info(ku), 'stereospecific_graph_equal': iso(nu, ku)},
                 'limit': 'Analytical uncharging is a diagnostic for conjugate-acid/base relationships, not an identity-preserving rewrite or approval to merge source ionic states. Native and KEGG literal structures are retained.'})
reactions = []
for p in sorted((O / 'originals').glob('KEGG-R*.txt')):
    f = flat(p.read_text())
    reactions.append({'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'fields': f})
generic = []
for kid in ['C04253', 'C04570']:
    p = O / 'originals' / ('KEGG-' + kid + '.txt')
    generic.append({'id': kid, 'record': flat(p.read_text()), 'mol_status': '404 empty body retained; no structure from issuing endpoint',
                    'scope': 'Electron-transfer flavoprotein state class, not a sequence-specific molecular entity.'})
(O / 'results/kegg-complete-candidate-assessment.json').write_text(json.dumps({'compounds': rows, 'reactions': reactions, 'generic_carriers': generic}, indent=2) + '\n')
for r in rows:
    print(r['native_id'], r['kegg'], r['native']['charge'], r['kegg_mol']['charge'], 'exact', r['exact_standard_inchi'], 'uncharged graph', r['after_explicit_analytical_uncharging']['stereospecific_graph_equal'])
