from pathlib import Path
from collections import Counter
import hashlib,json,re,shutil,xml.etree.ElementTree as ET
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
B=json.loads((O/'inputs/frozen-source-bindings-before.json').read_text())
source_by_name={p['path']: (Path(b['root'])/p['path'],p) for b in B for p in b['physical_files']}
selected=['originals/META-G-4001.xml','originals/META-MONOMER-5381.xml','originals/META-ORG-5962.xml','originals/META-ORG-5970.xml','originals/META-G1G01-166.xml','originals/META-G1G01-166-MONOMER.xml','originals/PMC2698508.html','originals/PMC2698508.pdf','results/PMC2698508-full-page-text.txt']
bindings=[]
for rel in selected:
 src,r=source_by_name[rel]; dst=O/'inputs'/src.name
 assert hashlib.sha256(src.read_bytes()).hexdigest()==r['sha256']
 if not dst.exists():shutil.copy2(src,dst)
 assert hashlib.sha256(dst.read_bytes()).hexdigest()==r['sha256']
 bindings.append({'source':str(src),'copy':str(dst.relative_to(O)),**r})
(O/'inputs/additional-source-copy-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
chebi={r['native_id']:'CHEBI:'+str(r['chebi']).replace('CHEBI:','') for r in json.loads((O/'inputs/native-chebi-candidates.json').read_text())}
chebi.update({'ETF-Oxidized':'GENERIC:10685','ETF-Reduced':'GENERIC:10686'})
rhea=json.loads((O/'results/rhea-five-family-replay.json').read_text())
reactions=json.loads((O/'inputs/five-member-equations.json').read_text())['rows']
mapids={'GLUTARYL-COA-DEHYDROG-RXN':('20590','R10074','L2R'),'GLUTACONYL-COA-DECARBOXYLASE-RXN':('23973','R03028','L2R'),'RXN-11667':('26560','R03026','R2L'),'RXN-11662':('30800','R01975','L2R'),'ACETYL-COA-ACETYLTRANSFER-RXN':('21038','R00238','R2L')}
rows=[]
for n in reactions:
 rid,kid,kdir=mapids[n['frame']]
 r=next(x for x in rhea['equations'] if x['id']==rid)
 eq=n['equation']; ne=eq if n['selected_direction']=='L2R' else {'left':eq['right'],'right':eq['left']}
 sides={}
 for ns,rs in [('left','substrates'),('right','products')]:
  native=Counter();issued=Counter();located=[]
  for t in ne[ns]:native[chebi[t['id']]]+=t['coefficient']
  for t in r[rs]:
   accession=t['accession'][0];loc='in' if t['participant'].endswith('_in') else 'out' if t['participant'].endswith('_out') else None
   key=accession+('['+loc+']' if loc else '')
   issued[key]+=t['coefficient'];located.append({'id':accession,'compartment':loc,'coefficient':t['coefficient'],'issuer_participant':t['participant']})
  sides[ns]={'native_mapped_terms':dict(native),'issuing_terms':located,'native_minus_issuer':{k:native[k]-issued[k] for k in sorted(native.keys()|issued.keys()) if native[k]!=issued[k]}}
 rows.append({'native':n['frame'],'native_sha256':n['source_sha256'],'native_source_direction':n['source_direction'],'native_pathway_selected_direction':n['selected_direction'],'rhea_candidate_crossrefs':[x for x in n['xrefs'] if 'RHEA' in str(x)],'rhea_master':r['master'],'rhea_selected_directional_id':rid,'rhea_direction':r['direction'],'rhea_equation':r['equation'],'side_reconciliation':sides,'exact_side_terms_after_stated_mapping':all(not s['native_minus_issuer'] for s in sides.values()),'kegg':kid,'kegg_pathway_direction':kdir,'disposition':('same small-molecule equation plus broad ETF state-class correspondence; no exact whole-protein identity or complete elemental balance' if rid=='20590' else 'reject exact replacement: issuer includes Na+(in)->Na+(out), absent from native; no cancellation or transport/catalyst transfer' if rid=='23973' else 'exact native ionic small-molecule sides and coefficients in selected direction; curation still requires independent acceptance and source preservation')})
assert sum(x['exact_side_terms_after_stated_mapping'] for x in rows)==4
(O/'results/five-reaction-dispositions.json').write_text(json.dumps(rows,indent=2)+'\n')
# Exact gene fields and current replacement scope, retaining both original bodies.
genes=[]
for f in ['retry-NCBI-gene-1043671.xml','NCBI-gene-83677406.xml']:
 root=ET.parse(O/'originals'/f).getroot()
 status=root.find('.//Gene-track_status')
 genes.append({'file':f,'sha256':hashlib.sha256((O/'originals'/f).read_bytes()).hexdigest(),'geneid':root.findtext('.//Gene-track_geneid'),'status':status.attrib.get('value') if status is not None else 'not explicitly supplied','taxname':root.findtext('.//Org-ref_taxname'),'locus':root.findtext('.//Gene-ref_locus'),'locus_tag':root.findtext('.//Gene-ref_locus-tag'),'synonyms':[x.text for x in root.findall('.//Gene-ref_syn_E')],'strain':[x.findtext('OrgMod_subname') for x in root.findall('.//OrgMod') if x.find('OrgMod_subtype') is not None and x.find('OrgMod_subtype').get('value')=='strain'],'current_id_elements':[ET.tostring(x,encoding='unicode') for x in root.findall('.//Gene-track_current-id')]})
(O/'results/gene-issuer-status.json').write_text(json.dumps(genes,indent=2)+'\n')
for r in rows:print(r['native'],r['rhea_selected_directional_id'],r['exact_side_terms_after_stated_mapping'],r['disposition'])
print(json.dumps(genes,indent=2))
