from pathlib import Path
from collections import Counter
import hashlib,json,datetime
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def out(n,x):
 p=O/n;assert not p.exists();p.write_text(json.dumps(x,indent=2)+'\n')
assert not (O/'artifact-manifest.json').exists() and not (O/'freeze-proof.json').exists()
bind=[]
for r in json.loads((O/'inputs/reused-issuing-originals.json').read_text()):
 for p in [Path(r['source']),O/r['target']]:assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
 bind.append({**r,'source_and_copy_unchanged':True})
out('results/reused-issuing-originals-after.json',bind)
sourcebyhash={}
for b in json.loads((O/'inputs/frozen-source-bindings-before.json').read_text()):
 for r in b['physical_files']:sourcebyhash.setdefault(r['sha256'],[]).append(str(Path(b['root'])/r['path']))
copy=[]
for p in sorted((O/'inputs').rglob('*')):
 if not p.is_file():continue
 if p.name.startswith('META-') or '/governance/' in str(p) or p.name.startswith('initial-') or p.name.startswith('PMC2698508') or p.name=='five-member-equations.json':
  h=sha(p);assert h in sourcebyhash,(str(p),h);copy.append({'path':str(p.relative_to(O)),'sha256':h,'source_paths':sourcebyhash[h]})
out('results/copied-source-input-bindings.json',copy)
# Full physical inventory is gitignore-independent; prospective self/manifest/proof paths are explicit.
paths=sorted(str(p.relative_to(O)) for p in O.rglob('*') if p.is_file())
for n in ['HANDOFF.md','artifact-inventory.json','artifact-manifest.json','freeze-proof.json']:
 assert n not in paths;paths.append(n)
paths.sort(); listed=len(paths)-2
(O/'HANDOFF.md').write_text(f'''# Frozen PWY-5177 issuer preparation

Owner: `/root/next268_chemistry_acceptance`. This is an author preparation for independent review, not curation approval. Created only after actual-path absence was checked. No maintained/Git/GitHub/runtime edits, installs, children or live removed-worktree dependencies.

Read `ASSESSMENT.md`, `UNRESOLVED.json`, `reading/reading-scope-ledger.json`, and the complete selected source originals. This handoff is bounded to 12 native compound candidates, five native reaction families, and the named historical/2009/2018 strain and protein identities.

Results: all12 native/ChEBI normalized ionic structural checks pass; nine KEGG compounds differ in protonation state. Three small-molecule Rhea equations reconcile exactly, first reaction only at generic ETF class scope, and native decarboxylation is not identical to Rhea23973 because the latter transports Na. Four complete native equations balance; first/net whole-ETF balance remains undetermined. Five exact protein-sequence comparisons and two independent genomic-CDS translations pass.

Conflicts retained: K172 native PART-OF AE016774 actually points to KT2440; native KT2440 Gene1043671 is discontinued; current UniProt Gene83677406 is NMI24_14; KB740 search hit is MAY27, and exact contig request returned a WGS master. C3UVB0 kinetic annotation differs from2009 primary values; Fig4/currentFJ688103 dimensions and accession-specific genome coordinates remain explicit.1993 full main and historical purified-enzyme sequence assignments remain open. No physiological whole-route or exact ETF-partner assertion is made.

98 acquisition attempts:68 HTTP200,5 HTTP429,2 HTTP404,23 sandbox DNS failures. All75 fresh response bodies and all failed probes with saved bodies remain.15 pinned original/receipt files reused. Earlier script failures and corrected scripts/results are preserved; see `results/failure-and-limitation-ledger.json`.

All676 physical inputs across the two prior frozen source packets remain exact before/after; all77 bound RDKit runtime files remain exact. All15 reused original/receipt files remain exact. Copied governing/native/primary inputs are individually hash-bound. Fresh versus reused readings are explicit; no new whole-paper visual review is claimed here.

This packet has {listed} manifested files and {len(paths)} physical files, including manifest and its self-excluded freeze proof. `artifact-inventory.json` enumerates every physical path without gitignore filtering; `artifact-manifest.json` binds all except itself and `freeze-proof.json`. The proof binds manifest and HANDOFF hashes. No files change after this freeze.

Next: independent acceptance of this finite preparation and prior source/primary packets; disposition of the exact remaining actions; actual merged265 baseline rebind before any maintained draft. Current output must remain immutable. Source-wide exhaustion, exhaustive alternative-ID search and complete pathway physiology are not claimed.
''')
out('artifact-inventory.json',{'physical_count':len(paths),'manifested_count':listed,'paths':paths,'self_excluded_hash_files':['artifact-manifest.json','freeze-proof.json'],'hidden_and_ignored_included':True,'top_level_counts':dict(Counter(x.split('/')[0] for x in paths))})
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name not in ['artifact-manifest.json','freeze-proof.json']:
  files.append({'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)})
assert len(files)==listed
out('artifact-manifest.json',{'owner':str(O),'files':files,'file_count':len(files),'listed_bytes':sum(r['bytes'] for r in files),'excluded':['artifact-manifest.json','freeze-proof.json']})
out('freeze-proof.json',{'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'manifested_file_count':listed,'physical_file_count':len(paths),'self_excluded':['artifact-manifest.json','freeze-proof.json'],'all_676_prior_source_files_unchanged':True,'all_77_rdkit_runtime_files_unchanged':True,'all_15_reused_issuing_files_unchanged':True,'scope':'bounded author issuer preparation; independent acceptance outstanding'})
actual=sorted(str(p.relative_to(O)) for p in O.rglob('*') if p.is_file());assert actual==paths
for r in files:assert sha(O/r['path'])==r['sha256'] and (O/r['path']).stat().st_size==r['bytes']
print(json.dumps({'manifested':listed,'physical':len(paths),'listed_bytes':sum(r['bytes'] for r in files),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'assessment_sha256':sha(O/'ASSESSMENT.md'),'freeze_sha256':sha(O/'freeze-proof.json')},indent=2))
