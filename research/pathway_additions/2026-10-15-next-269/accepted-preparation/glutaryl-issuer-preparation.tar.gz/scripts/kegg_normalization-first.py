from pathlib import Path
import json
from rdkit import Chem
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')
def iso(a,b):
 return a.GetNumAtoms()==b.GetNumAtoms() and a.GetNumBonds()==b.GetNumBonds() and a.HasSubstructMatch(b,useChirality=True) and b.HasSubstructMatch(a,useChirality=True)
def no_p(s): return '/'.join(x for i,x in enumerate(s.split('/')) if i==0 or not x.startswith('p'))
rows=[]
for r in json.loads((O/'results/kegg-complete-candidate-assessment.json').read_text())['compounds']:
 a,b=r['native']['inchi'],r['kegg_mol']['inchi']
 na,nb=no_p(a),no_p(b)
 ma,mb=Chem.MolFromInchi(na),Chem.MolFromInchi(nb)
 un=r['after_explicit_analytical_uncharging']
 rows.append({'native_id':r['native_id'],'kegg':r['kegg'],'literal_native_standard_inchi':a,'literal_kegg_standard_inchi':b,'exact_state_match':r['exact_standard_inchi'],'normalized_base_inchi_without_protonation_layer_native':na,'normalized_base_inchi_without_protonation_layer_kegg':nb,'same_nonprotonation_layers':na==nb,'stereospecific_normalized_base_graph_match':iso(ma,mb),'uncharger_exact_inchi_equal':un['native']['inchi']==un['kegg']['inchi'],'uncharger_exact_graph_equal':un['stereospecific_graph_equal'],'disposition':'exact normalized ionic structure' if r['exact_standard_inchi'] else 'same standard-InChI normalized constitution and stereo with different protonation state; not exact ionic identity','limits':'The analytical removal of the InChI protonation layer and graph reconstruction is a diagnostic, not a rewrite of either issuing original. Standard-InChI mobile-H normalization can hide literal bond/proton-placement differences. No CML stereo acceptance.'})
assert all(r['same_nonprotonation_layers'] and r['stereospecific_normalized_base_graph_match'] for r in rows)
(O/'results/kegg-normalization-diagnostic.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows: print(r['native_id'],r['kegg'],r['disposition'])
