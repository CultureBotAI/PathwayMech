from pathlib import Path
from html.parser import HTMLParser
import hashlib
import json
import re
import xml.etree.ElementTree as ET

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')


class HTMLText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.out = []
        self.skip = 0

    def handle_starttag(self, t, a):
        if t in ['style', 'script']:
            self.skip += 1
        if t in ['p', 'div', 'tr', 'h1', 'h2', 'h3', 'br', 'li']:
            self.out.append('\n')
        if t in ['td', 'th']:
            self.out.append(' | ')

    def handle_endtag(self, t):
        if t in ['style', 'script']:
            self.skip -= 1

    def handle_data(self, d):
        if not self.skip:
            self.out.append(d)


for p in sorted((O / 'originals').glob('DSM-*.html')):
    h = HTMLText()
    h.feed(p.read_text())
    txt = '\n'.join(' '.join(x.split()) for x in ''.join(h.out).splitlines() if x.strip())
    (O / 'reading' / (p.stem + '.txt')).write_text(txt + '\n')
taxa = []
for p in sorted((O / 'originals').glob('NCBI-taxonomy-[0-9]*.xml')):
    t = ET.parse(p).getroot().find('Taxon')
    taxa.append({'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                 'id': t.findtext('TaxId'), 'name': t.findtext('ScientificName'), 'rank': t.findtext('Rank'),
                 'parent': t.findtext('ParentTaxId'), 'other_names': ET.tostring(t.find('OtherNames'), encoding='unicode'),
                 'lineage': t.findtext('Lineage'), 'updated': t.findtext('UpdateDate')})
(O / 'results/taxonomy-projection.json').write_text(json.dumps(taxa, indent=2) + '\n')
uniprot = []
for p in sorted((O / 'originals').glob('UniProt*.json')):
    j = json.loads(p.read_text())
    for r in j.get('results', [j]):
        uniprot.append({'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                        **{k: r.get(k) for k in ['primaryAccession', 'entryType', 'entryAudit', 'proteinDescription', 'genes', 'organism', 'comments', 'references', 'sequence', 'uniProtKBCrossReferences']}})
(O / 'reading/uniprot-complete-biological-projection.json').write_text(json.dumps(uniprot, indent=2) + '\n')
gb = []
for p in sorted((O / 'originals').glob('*.gb')):
    s = p.read_text()
    if not s.startswith('LOCUS'):
        continue
    sequence = re.sub('[^A-Za-z]', '', s.split('ORIGIN', 1)[1].split('//', 1)[0]).upper()
    gb.append({'file': p.name, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
               'version': re.search(r'^VERSION\s+(\S+)', s, re.M)[1], 'length': len(sequence),
               'sequence_sha256': hashlib.sha256(sequence.encode()).hexdigest(), 'sequence': sequence,
               'source_and_features': s.split('FEATURES', 1)[1].split('ORIGIN', 1)[0],
               'organism': re.search(r'^  ORGANISM\s+(.+)', s, re.M)[1]})
(O / 'results/ncbi-protein-projection.json').write_text(json.dumps(gb, indent=2) + '\n')
matches = []
for u in uniprot:
    seq = u['sequence']['value']
    matches.append({'uniprot': u['primaryAccession'], 'uniprot_file': u['file'], 'length': len(seq),
                    'md5_recomputed': hashlib.md5(seq.encode()).hexdigest().upper(), 'issuer_md5': u['sequence']['md5'],
                    'sequence_sha256': hashlib.sha256(seq.encode()).hexdigest(),
                    'exact_ncbi_sequence_matches': [g['version'] for g in gb if g['sequence'] == seq]})
(O / 'results/protein-exact-sequence-comparisons.json').write_text(json.dumps(matches, indent=2) + '\n')
print(json.dumps(matches, indent=2))
