from pathlib import Path
import collections
import hashlib
import json
import xml.etree.ElementTree as ET
from rdkit import Chem, rdBase
from rdkit.Chem import rdMolDescriptors

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation')


def details(m):
    return {'formula': rdMolDescriptors.CalcMolFormula(m), 'charge': Chem.GetFormalCharge(m),
            'atoms': m.GetNumAtoms(), 'bonds': m.GetNumBonds(),
            'canonical_isomeric_smiles': Chem.MolToSmiles(m, isomericSmiles=True),
            'standard_inchi': Chem.MolToInchi(m), 'inchi_key': Chem.MolToInchiKey(m),
            'tetrahedral_centres': Chem.FindMolChiralCenters(m, includeUnassigned=True),
            'bond_stereo': [{'atom1': b.GetBeginAtomIdx(), 'atom2': b.GetEndAtomIdx(), 'stereo': str(b.GetStereo())}
                            for b in m.GetBonds() if b.GetStereo() != Chem.BondStereo.STEREONONE]}


rows = []
for r in json.loads((O / 'inputs/native-chebi-candidates.json').read_text()):
    np = O / 'inputs' / ('META-' + r['native_id'] + '.xml')
    b = np.read_bytes()
    assert hashlib.sha256(b).hexdigest() == r['source_sha256']
    n = ET.fromstring(b).find('Compound')
    assert n is not None and n.get('frameid') == r['native_id']
    assert n.findtext('inchi') == r['native_inchi']
    assert [x.findtext('dblink-oid') for x in n.findall('dblink') if x.findtext('dblink-db') == 'CHEBI'] == [r['chebi']]
    cp = O / 'originals' / ('ChEBI-' + r['chebi'] + '.json')
    c = json.loads(cp.read_text())
    assert c['chebi_accession'] == 'CHEBI:' + r['chebi'] and c['is_released']
    st = c['default_structure']
    nm = Chem.MolFromInchi(r['native_inchi'])
    cm = Chem.MolFromInchi(st['standard_inchi'])
    sm = Chem.MolFromSmiles(st['smiles'])
    assert nm is not None and cm is not None and sm is not None
    nd, cd, sd = details(nm), details(cm), details(sm)
    graph_match = nm.GetNumAtoms() == cm.GetNumAtoms() and nm.GetNumBonds() == cm.GetNumBonds() and nm.HasSubstructMatch(cm, useChirality=True) and cm.HasSubstructMatch(nm, useChirality=True)
    native_cml = n.find('cml/molecule')
    assert native_cml is not None
    rw = Chem.RWMol()
    index = {}
    atoms = native_cml.findall('atomArray/atom')
    bonds = native_cml.findall('bondArray/bond')
    for a in atoms:
        atom = Chem.Atom(a.get('elementType'))
        atom.SetFormalCharge(int(a.get('formalCharge', '0')))
        index[a.get('id')] = rw.AddAtom(atom)
    for bond in bonds:
        refs = bond.get('atomRefs') or bond.get('atomRefs2')
        a, z = refs.split()
        rw.AddBond(index[a], index[z], {'1': Chem.BondType.SINGLE, '2': Chem.BondType.DOUBLE, '3': Chem.BondType.TRIPLE}[bond.get('order')])
    cml = rw.GetMol()
    Chem.SanitizeMol(cml)
    unst = Chem.Mol(cm)
    Chem.RemoveStereochemistry(unst)
    checks = {
        'native_inchi_key_recomputed': nd['inchi_key'] == r['native_key'].removeprefix('InChIKey='),
        'issuer_inchi_key_recomputed': cd['inchi_key'] == st['standard_inchi_key'],
        'native_and_issuer_stereospecific_graph_isomorphism': graph_match,
        'exact_standard_inchi': nd['standard_inchi'] == cd['standard_inchi'],
        'issuer_smiles_inchi_consistent': sd['standard_inchi'] == cd['standard_inchi'],
        'native_issuer_formula_charge': (nd['formula'], nd['charge']) == (cd['formula'], cd['charge']),
        'issuer_declared_formula_charge': (cd['formula'], cd['charge']) == (c['chemical_data']['formula'], c['chemical_data']['charge']),
        'native_cml_constitution_without_stereo': Chem.MolToInchi(cml) == Chem.MolToInchi(unst),
        'native_cml_formula_charge': (rdMolDescriptors.CalcMolFormula(cml), Chem.GetFormalCharge(cml)) == (cd['formula'], cd['charge']),
    }
    rows.append({'native': r, 'issuer_path': str(cp.relative_to(O)), 'issuer_sha256': hashlib.sha256(cp.read_bytes()).hexdigest(),
                 'issuer_name': c['name'], 'issuer_definition': c['definition'], 'issuer_chemical_data': c['chemical_data'],
                 'issuer_structure': st, 'native_parsed': nd, 'issuer_inchi_parsed': cd, 'issuer_smiles_parsed': sd,
                 'checks': checks, 'native_cml_atom_count': len(atoms), 'native_cml_bond_count': len(bonds),
                 'native_cml_stereo_limit': 'Native CML atom/bond connectivity checked without stereo. 2D drawing coordinates are not independently accepted stereochemical assertions; native InChI owns the compared stereo.',
                 'issuer_relations': c['ontology_relations']})
(O / 'results/chemical-issuer-comparisons.json').write_text(json.dumps({'rdkit_version': rdBase.rdkitVersion, 'rows': rows}, indent=2) + '\n')
for r in rows:
    print(r['native']['native_id'], r['issuer_name'], r['native_parsed']['formula'], r['native_parsed']['charge'], 'FAILURES', [k for k, v in r['checks'].items() if not v])
