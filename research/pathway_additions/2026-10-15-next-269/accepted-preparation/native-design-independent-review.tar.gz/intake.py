from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs={
'/private/tmp/pathwaymech-next-269-glutaryl-preparation':'bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b',
'/private/tmp/pathwaymech-next-269-glutaryl-source-completion':'064e77fe52d9a72510acb39c6693f0da230ee44b986969ee48c34a5de857a6ed',
'/private/tmp/pathwaymech-next-269-glutaryl-issuer-preparation':'1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3',
'/private/tmp/pathwaymech-next-269-glutaryl-independent-initial-review':'fbe09ce3c8cf2cb9f17445a1a197959e5aa7b968c8eadea9efb02395048aa377',
'/private/tmp/pathwaymech-next-269-glutaryl-source-completion-independent-review':'d1549db6b7a0bab365cf8b672876392e2390d6c8615acc92fab7a571d846ff75',
'/private/tmp/pathwaymech-next-269-locator-correction-independent-acceptance':'ba461a5493938f28d3b7f685490438cfb4a76d17a2e82649e42407a4e0b212ee',
'/private/tmp/pathwaymech-next-269-root-locator-correction':'1f558e3c08b70361840e6eefd9173d6aea107278fd40e954641bb80ec905b3de',
'/private/tmp/pathwaymech-next-269-independent-glutaryl-issuer-review':'a8f25883dee855189ca74879e004e1ed1074e4f8443a0770ce5f6c1c8837aad2'}
rows=[]
for name,digest in inputs.items():
 root=Path(name);assert sha(root/'artifact-manifest.json')==digest
 m=json.loads((root/'artifact-manifest.json').read_text())
 for r in m['files']:assert (root/r['path']).stat().st_size==r['bytes'] and sha(root/r['path'])==r['sha256']
 actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()};assert actual=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
 rows.append({'root':name,'manifest_sha256':digest,'listed':len(m['files']),'physical':len(actual),'handoff_sha256':sha(root/'HANDOFF.md'),'all_exact':True})
(P/'accepted-input-intake.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'packets':len(rows),'physical':sum(r['physical'] for r in rows),'all_exact':True},indent=2))
