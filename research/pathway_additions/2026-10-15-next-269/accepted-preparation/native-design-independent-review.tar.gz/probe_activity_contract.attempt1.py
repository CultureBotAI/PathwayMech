from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,dataclasses,re,html
import yaml
from pathwaymech.schema import validate_record,ValidationError
from pathwaymech.strict import validator,TARGET_CLASS
from pathwaymech.kgx import kgx_nodes,kgx_edges
from pathwaymech.graph_view import graph_html
P=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-268-20261015');A=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation/originals');B=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion/originals')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();nodes={};files={}
for root in (A,B):
 for p in root.glob('META-*.xml'):
  n=next(x for x in ET.parse(p).getroot() if x.tag!='metadata');nodes[n.get('frameid')]=n;files[n.get('frameid')]=p
def target(n,s):return n.find(s)[0].get('frameid')
def label(n):return html.unescape(re.sub('<[^>]*>','',n.findtext('common-name') or n.get('frameid')))
def ident(s):return 'MetaCyc:'+s
regids=['REG-10076','REG-13248','REG-14465','REG-7495','REG-7496','REG-7497','REG-7498','REG0-7500'];activityids={target(nodes[x],'regulated-entity') for x in regids};assert len(activityids)==4
record={'id':'MetaCyc:PWY-5177','label':'Glutaryl-CoA degradation — structural review probe','description':'Scratch contract probe of exact native enzyme-activity inhibition contexts only; not a complete curated pathway or maintained authority acceptance. Opposing activity directions remain source context.','pathway_type':'metabolic','taxa':[],'participants':[],'reactions':[],'mechanistic_edges':[],'references':[]}
parts={};refs={};edges=record['mechanistic_edges']
def node(key,cat):parts[key]={'id':ident(key),'label':label(nodes[key]),'category':cat}
def evidence(key,assertion,locator):
 refs[key]={'id':ident(key),'title':'MetaCyc native '+key,'source_version':'27.0','source_sha256':sha(files[key])}
 return [{'reference_id':ident(key),'source_assertion':assertion,'source_locator':locator}]
for key in sorted(activityids):
 n=nodes[key];enzyme=target(n,'enzyme');node(key,'molecular_activity');node(enzyme,'complex' if nodes[enzyme].find('component') is not None else 'protein')
 edges.append({'id':'probe-enables-'+key,'subject':ident(enzyme),'predicate':'enables','object':ident(key),'description':'Native enzyme-specific activity context. Its reaction direction and organism do not establish whole-route flux.','evidence':evidence(key,f'{key} explicitly identifies {enzyme} as its enzyme.','Enzymatic-Reaction/enzyme/Protein@frameid')})
for key in regids:
 n=nodes[key];activity=target(n,'regulated-entity');regulator=target(n,'regulator');assert n.findtext('mode')=='-';node(regulator,'small_molecule')
 edges.append({'id':'probe-inhibition-'+key,'subject':ident(regulator),'predicate':'inhibits','object':ident(activity),'description':'Native enzyme-specific inhibitory assertion; exact assay conditions and source evidence limits require retained source context, not transfer to a generic pathway reaction.','evidence':evidence(key,f'{key} assigns inhibitory mode - to regulator {regulator} and exact enzymatic activity {activity}.','Regulation/mode; Regulation/regulator/*@frameid; Regulation/regulated-entity/Enzymatic-Reaction@frameid')})
record['participants']=list(parts.values());record['references']=list(refs.values())
parsed=validate_record(record);strict=validator().validate(record,TARGET_CLASS);assert not strict.results,strict.results
ns=[dataclasses.asdict(n) for n in kgx_nodes([parsed])];es=[dataclasses.asdict(e) for e in kgx_edges([parsed])];assert len(es)==12
for key in activityids:
 n,=[n for n in ns if n['id']==ident(key)];assert n['category']=='biolink:MolecularActivity'
htmlpage=graph_html(parsed);assert all(ident(k) in htmlpage for k in activityids)
# Existing native authority role explicitly uses participants, not reactions.
from pathwaymech.biocyc_phenylacetate import NODE_ROLES
assert NODE_ROLES['native_phenylacetate_activity']==('participants',{'molecular_activity'})
(P/'native-activity-contract-probe.yaml').write_text(yaml.safe_dump(record,sort_keys=False))
(P/'native-activity-contract-probe.html').write_text(htmlpage)
contracts=['src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','src/pathwaymech/strict.py','src/pathwaymech/identifiers.py','src/pathwaymech/biocyc_phenylacetate.py','src/pathwaymech/kgx.py','src/pathwaymech/graph_view.py','docs/CAUSAL_GRAPHS.md']
result={'source_bindings':[{'frame':k,'path':str(files[k]),'sha256':sha(files[k])} for k in sorted(set(parts)|set(refs))],'contract_bindings':[{'path':str(W/f),'sha256':sha(W/f)} for f in contracts],'participants':len(parts),'activity_participants':4,'enables':4,'inhibits':8,'python_and_closed_schema':'pass','KGX_molecular_activity_category':'pass','source_graph_activity_presence':'pass','kgx_nodes':ns,'kgx_edges':es,'limits':'Structural contract probe only. No current next269 authority integration, complete pathway, source biological independence or whole-route validation claimed. Actual source qualifiers must be retained in final design/record; this probe is not a final curation fragment.'}
(P/'native-activity-contract-results.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS: 4 native activity participants; 4 enables and 8 inhibition edges; Python/closed schema, KGX category and graph presence')
