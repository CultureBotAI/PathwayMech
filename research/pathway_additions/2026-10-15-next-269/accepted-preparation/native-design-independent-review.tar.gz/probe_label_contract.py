from pathlib import Path
import copy, hashlib, json, shutil, subprocess
from unittest.mock import patch
import yaml
from pathwaymech import identifiers as I

O=Path(__file__).resolve().parent
P=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
W=Path('/private/tmp/pathwaymech-next-268-20261015')
sha=lambda b:hashlib.sha256(b).hexdigest()
source=W/'src/pathwaymech/identifiers.py'
blob=subprocess.run(['git','show','ae143113008f8c194748bae322ab80b1853a6d95:src/pathwaymech/identifiers.py'],cwd=W,check=True,capture_output=True).stdout
assert source.read_bytes()==blob
(O/'identifiers.published268.py').write_bytes(blob)
policy=yaml.safe_load((P/'inputs/current-contracts/conf/identifier_policy.yaml').read_text())
policy['namespaces']={'MetaCyc':policy['namespaces']['MetaCyc']}
policy['namespaces']['MetaCyc']['snapshot']='authority-fixture.json'
canonical='(S)-3-hydroxybutanoyl-CoA dehydrogenase'
display='Crotonyl-CoA hydration to (S)-3-hydroxybutanoyl-CoA'
record={'id':'MetaCyc:PWY-5177','label':'glutaryl-CoA degradation','taxa':[],'participants':[],'reactions':[{'id':'MetaCyc:RXN-11667','label':display,'category':'molecular_activity'}]}
root=O/'label-probe-root';root.mkdir(exist_ok=True)
rows=[]
for kind,labelkind,displayvalue,expect in [
 ('reaction','canonical',display,False),
 ('native_phenylacetate_reaction','canonical',display,False),
 ('reaction','canonical',canonical,True),
 ('native_phenylacetate_reaction','canonical',canonical,True),
 ('reaction','source_context',display,True),
]:
    r=copy.deepcopy(record);r['reactions'][0]['label']=displayvalue
    terms={'MetaCyc:PWY-5177':{'label':r['label'],'synonyms':[],'entity_type':'native_pathway'},'MetaCyc:RXN-11667':{'label':canonical,'synonyms':[],'entity_type':kind,'label_kind':labelkind}}
    with patch.object(I,'_load_policy',return_value=policy),patch.object(I,'pathway_files',return_value=[root/'fixture.yaml']),patch.object(I,'load_yaml_file',return_value=r),patch.object(I,'_load_authority',return_value=terms):
        errors=I.identifier_errors(root)
    assert (not errors)==expect,(kind,labelkind,errors)
    if not expect:assert len(errors)==1 and 'LABEL_MISMATCH' in errors[0]
    rows.append({'entity_type':kind,'label_kind':labelkind,'display_label':displayvalue,'errors':errors,'expected_acceptance':expect})
result={'scope':'Real published identifier_errors consumer branch, supplied authority fixtures only. Mocked snapshot loading isolates role/label policy; not a new authority producer/consumer acceptance. source_context is a negative-design control: misclassifying a named native reaction would allow contextual bypass and is not a valid fix.', 'published_commit':'ae143113008f8c194748bae322ab80b1853a6d95','identifiers_sha256':sha(blob),'policy_sha256':sha((P/'inputs/current-contracts/conf/identifier_policy.yaml').read_bytes()),'native_RXN11667_sha256':sha((P/'inputs/native/META-RXN-11667.xml').read_bytes()),'all_five_expected_results':True,'cases':rows,'finding':'N269-D02: current broad MetaCyc contextual-label rule does not override the existing recognized native canonical or full-profile Reaction naming guards. A new bounded profile must explicitly define and test its derived display-label contract.'}
(O/'label-contract-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
