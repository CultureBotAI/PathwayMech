from pathlib import Path
from datetime import datetime, timezone
import hashlib,json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
A=Path('/private/tmp/pathwaymech-next-269-native-graph-design')
assert sha(A/'artifact-manifest.json')=='566059628d3208928ea0a6949d81c325f04e608e2cf29653f81063e1e02ad603'
m=json.loads((A/'artifact-manifest.json').read_text())
for r in m['files']:assert sha(A/r['path'])==r['sha256'] and (A/r['path']).stat().st_size==r['bytes']
assert {str(x.relative_to(A)) for x in A.rglob('*') if x.is_file()}=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
assert not (P/'artifact-manifest.json').exists() and not (P/'freeze-proof.json').exists()
files=[{'path':str(x.relative_to(P)),'bytes':x.stat().st_size,'sha256':sha(x)} for x in sorted(P.rglob('*')) if x.is_file()]
(P/'artifact-manifest.json').write_text(json.dumps({'owner':str(P),'scope':'Independent bounded design review; N269-D01 issue623 and N269-D02 issue624 require successors; no maintained acceptance','files':files},indent=2)+'\n')
proof={'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'manifest_sha256':sha(P/'artifact-manifest.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(r['bytes'] for r in files),'author_packet_end_recheck_exact':True,'author_manifest_sha256':sha(A/'artifact-manifest.json'),'handoff_sha256':sha(P/'HANDOFF.md'),'review_sha256':sha(P/'REVIEW.md'),'all_local_jobs_terminal':True}
(P/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({**proof,'freeze_sha256':sha(P/'freeze-proof.json')},indent=2))
