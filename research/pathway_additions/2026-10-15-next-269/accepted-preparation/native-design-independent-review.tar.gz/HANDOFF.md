# Frozen independent design review

Changes required: **N269-D01 / issue623** direct pathway taxon omissions and **N269-D02 / issue624** unsupported contextual reaction-label permission. See REVIEW.md for exact reproduction and acceptance conditions. The original author packet remains unchanged. Root owns eventual issue closure after corrected maintained content is merged and verified.

Inputs: `/private/tmp/pathwaymech-next-269-native-graph-design`; manifest `566059628d3208928ea0a6949d81c325f04e608e2cf29653f81063e1e02ad603`; 267 listed / 269 physical files. Exact copied published contract baseline: `ae143113008f8c194748bae322ab80b1853a6d95` (not a merged-baseline assertion).

Evidence: `design-intake.json`, `independent-replay.json` (590 passes; 162 objects / 2,131 exact slots / 60 native nodes / 80 edges), `supplemental-bindings.json` (215 copies / 16 committed contracts / 16 corrected primary claims / 46 references), `label-contract-results.json` (five expected consumer cases), and the small activity schema/graph/KGX probe. `accepted-input-intake.json` binds eight prior packets / 1,045 physical files. Failed harness attempts are retained explicitly.

The existing activity-participant contract handles all eight microbial regulations without a new schema or invented generic-reaction equivalence. Three source-only plus one regulated opposing activity stay distinct from route thiolysis; two human regulations remain context. The topology and scientific qualifications pass the finite scope in REVIEW.md; the two required defects prevent complete design acceptance.

No maintained implementation, authority promotion, public mapping expansion or actual-merged deduplication is accepted here. No maintained/source-packet/Git/GH/runtime mutations or new installations occurred. Successors must be reviewed in separate owned packets. Run helpers only into a fresh scratch successor: their original output paths are this frozen owner.
