from pathlib import Path
import collections, hashlib, json, re, xml.etree.ElementTree as E

P = Path('/private/tmp/pathwaymech-next-269-native-graph-design')
O = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda name: json.loads((P/'results'/f'{name}.json').read_text())
checks = []
def check(name, value):
    checks.append({'check': name, 'passed': bool(value)})
    assert value, name
nodes = read('all162-node-and-alias-dispositions')
objects = {}
for r in nodes:
    path=P/r['source']; root=E.parse(path).getroot()
    obj=root.find(f"{r['tag']}[@frameid='{r['native_id']}']")
    check('native original '+r['native_id'], obj is not None and sha(path)==r['sha256'])
    check('direct slots '+r['native_id'], dict(collections.Counter(x.tag for x in obj))==r['direct_slot_counts'])
    objects[r['native_id']]=obj
check('162 unique originals',len(objects)==162)
slots=read('all-native-direct-slot-dispositions')
expected=[]
for r in nodes:
    counts=collections.Counter()
    for x in objects[r['native_id']]:
        counts[x.tag]+=1
        expected.append((r['native_id'],x.tag,counts[x.tag],E.tostring(x,encoding='unicode'),r['sha256']))
check('all2131 exact direct slots',expected==[(r['native_id'],r['tag'],r['occurrence'],r['xml'],r['source_sha256']) for r in slots])
edges=read('proposed-native-edge-inventory')
check('80 unique edge keys',len(edges)==len({e['design_key'] for e in edges})==80)
selected={r['native_id'] for r in nodes if r['graph_disposition']=='proposed_native_graph_node'}
check('60 declared native endpoints',len(selected)==60 and {e[k] for e in edges for k in ['subject_native_id','object_native_id']}==selected)
pathway=objects['PWY-5177']; composite='GLUTARYL-COA-DEHYDROGENASE-RXN'
ids=lambda obj,path:[x.get('frameid') for x in obj.findall(path)]
one=lambda obj,path:obj.find(path).get('frameid')
members=ids(pathway,'reaction-list/Reaction')
layouts={x.find('Reaction').get('frameid'):x.findtext('direction') for x in pathway.findall('reaction-layout')}
order={(p.get('frameid'),x.find('Reaction').get('frameid')) for x in pathway.findall('reaction-ordering') for p in x.findall('predecessor-reactions/Reaction')}
check('five member memberships',set(members)=={e['object_native_id'] for e in edges if e['subject_native_id']=='PWY-5177' and e['predicate']=='has_part'} and len(members)==5)
check('four native order pairs',order=={(e['subject_native_id'],e['object_native_id']) for e in edges if e['predicate']=='precedes'} and len(order)==4)
check('two composite memberships',set(ids(objects[composite],'reaction-list/Reaction'))=={e['object_native_id'] for e in edges if e['subject_native_id']==composite and e['predicate']=='has_part'})
equations={}
for rid in members+[composite]:
    obj=objects[rid]; direction=layouts.get(rid,'L2R'); terms=[]
    for side in ['left','right']:
        for n,x in enumerate(obj.findall(side),1):
            fid=next(t.get('frameid') for t in x if t.get('frameid'))
            coef=int(x.findtext('coefficient','1'))
            consumed=(side=='left')==(direction=='L2R')
            triple=(fid,'consumes',rid) if consumed else (rid,'produces',fid)
            found=[e for e in edges if (e['subject_native_id'],e['predicate'],e['object_native_id'])==triple]
            check(f'equation {rid}/{side}{n}',len(found)==1 and found[0]['stoichiometric_coefficient']==coef)
            terms.append({'side':side,'occurrence':n,'native_id':fid,'coefficient':coef,'route_consumed':consumed})
    equations[rid]={'native_direction':obj.findtext('reaction-direction'),'route_direction':direction,'terms':terms}
check('20member and6composite occurrences',sum(len(equations[x]['terms']) for x in members)==20 and len(equations[composite]['terms'])==6)
def net(rid):
    c=collections.Counter()
    for t in equations[rid]['terms']:c[t['native_id']]+=t['coefficient']*(-1 if t['route_consumed'] else 1)
    return c
a=net('GLUTARYL-COA-DEHYDROG-RXN');a.update(net('GLUTACONYL-COA-DECARBOXYLASE-RXN'))
check('exact composite algebra',{k:v for k,v in a.items() if v}==dict(net(composite)))
activities=read('all29-activity-contexts')
for r in activities:
    x=objects[r['native_id']]
    check('activity links '+r['native_id'],one(x,'enzyme/*')==r['enzyme'] and one(x,'reaction/*')==r['reaction'] and x.findtext('reaction-direction')==r['source_activity_direction'])
    check('activity organism '+r['native_id'],ids(objects[r['enzyme']],'species/*')==r['species_native_ids'])
    actual=[e for e in edges if e['predicate']=='catalyzes' and e.get('activity_context')==r['native_id']]
    proposed=r['disposition']=='propose_source_only_catalyst_edge'
    check('catalysis disposition '+r['native_id'],len(actual)==int(proposed))
    if actual:check('catalysis endpoint '+r['native_id'],(actual[0]['subject_native_id'],actual[0]['object_native_id'])==(r['enzyme'],r['reaction']))
for e in edges:
    for ev in e['evidence']:check('evidence hash '+e['design_key'],sha(P/ev['source'])==ev['source_sha256'])
    if e['predicate']=='has_part' and objects[e['subject_native_id']].tag=='Protein':
        x=objects[e['subject_native_id']]; terms=[t for t in x.findall('component') if t[0].get('frameid')==e['object_native_id']]
        check('complex component '+e['design_key'],len(terms)==1 and terms[0].findtext('coefficient','unspecified')==e['native_component_coefficient'])
    if e['predicate']=='enables':check('exact activity enabling '+e['design_key'],one(objects[e['object_native_id']],'enzyme/*')==e['subject_native_id'])
    if e['predicate']=='has_cofactor':check('cofactor '+e['design_key'],e['object_native_id'] in ids(objects['ENZRXN-5541'],'cofactor/*') and e['subject_native_id']==one(objects['ENZRXN-5541'],'enzyme/*'))
regulations=read('all10-regulation-contexts')
for r in regulations:
    x=objects[r['native_id']]
    check('regulation source '+r['native_id'],one(x,'regulator/*')==r['regulator'] and one(x,'regulated-entity/*')==r['regulated_activity'] and x.findtext('mode')==r['mode'] and x.findtext('mechanism')==r['mechanism'])
    found=[e for e in edges if e.get('regulation_native_id')==r['native_id']]
    check('regulation disposition '+r['native_id'],len(found)==int(r['disposition']=='propose_exact_activity_inhibition_edge'))
    if found:check('regulation triple '+r['native_id'],(found[0]['subject_native_id'],found[0]['predicate'],found[0]['object_native_id'])==(r['regulator'],'inhibits',r['regulated_activity']) and r['mode']=='-')
species=[]
for n,x in enumerate(pathway.findall('species'),1):
    fid=x[0].get('frameid');o=objects[fid]
    species.append({'native_id':fid,'native_label':o.findtext('common-name'),'native_rank':o.findtext('rank'),'native_source_sha256':sha(P/'inputs/native'/f'META-{fid}.xml'),'pathway_locator':f"/ptools-xml/Pathway[@frameid='PWY-5177']/species[{n}]",'native_ncbi_dblink':[d.findtext('dblink-oid') for d in o.findall('dblink') if d.findtext('dblink-db')=='NCBI-TAXONOMY-DB'],'selected_by_design':fid=='ORG-5962','microbial':fid!='TAX-9606'})
check('nine direct species eight microbes',len(species)==9 and sum(r['microbial'] for r in species)==8)
summary={'checks':len(checks),'passed':all(r['passed'] for r in checks),'native_objects':len(objects),'direct_slots':len(slots),'native_nodes':len(selected),'edges':len(edges),'predicate_counts':dict(collections.Counter(e['predicate'] for e in edges)),'members':members,'equations':equations,'direct_species':species,'taxon_completeness_finding':'N269-D01: seven additional direct microbial associations lack individually justified proposed declarations/dispositions; the other26 assertion conflates direct species with shared-catalyst context.'}
(O/'independent-replay.json').write_text(json.dumps({'summary':summary,'checks':checks},indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['equations','direct_species']},indent=2))
