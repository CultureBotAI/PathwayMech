from pathlib import Path
import hashlib,json,subprocess
P=Path('/private/tmp/pathwaymech-next-269-native-graph-design');O=Path(__file__).resolve().parent
W=Path('/private/tmp/pathwaymech-next-268-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda n:json.loads((P/n).read_text())
copies=read('inputs/copied-input-bindings.json')
for r in copies:
    a=Path(r['source']).read_bytes();b=(P/r['path']).read_bytes()
    assert a==b and sha(b)==r['sha256'] and len(b)==r['bytes'],r['path']
contracts=read('results/committed-contract-blob-verification.json')
for r in contracts['files']:
    b=subprocess.run(['git','show',contracts['commit']+':'+r['path']],cwd=W,check=True,capture_output=True).stdout
    assert b==(P/'inputs/current-contracts'/r['path']).read_bytes() and sha(b)==r['sha256']
ledger=read('inputs/accepted-primary-correction/primary-claim-ledger.json')
assert sha((P/'inputs/accepted-primary-correction/primary-claim-ledger.json').read_bytes())=='6120d49e468bbf056922f2f09b122fae3080cc981ee4457d6f25871a8332353b'
dispositions=read('results/all16-corrected-primary-dispositions.json')
assert [r['corrected_claim'] for r in dispositions]==ledger['claims']
assert all(not r['current_positive_primary_graph_edge'] for r in dispositions)
edges=read('results/proposed-native-edge-inventory.json');refs=read('results/proposed-native-reference-inventory.json')
actual={}
for e in edges:
    for v in e['evidence']:actual.setdefault(v['source'],[]).append(e['design_key'])
assert len(refs)==46 and {r['source_path'] for r in refs}==set(actual)
for r in refs:assert r['edge_design_keys']==actual[r['source_path']] and sha((P/r['source_path']).read_bytes())==r['source_sha256']
requirements=read('results/native-authority-requirements.json');nodes=read('results/all162-node-and-alias-dispositions.json')
nodeids={r['curie_candidate'] for r in nodes if r['graph_disposition']=='proposed_native_graph_node'}
assert len(nodeids)==60 and len(nodeids | {r['reference_id_candidate'] for r in refs})==86
snapshot=read('inputs/current-contracts/data/identifier_authorities/sources.json')
terms=snapshot['terms']
assert sum(i in terms for i in nodeids)==11
for r in requirements:assert r['current_snapshot_present']==(r['id'] in terms),r['id']
result={'copied_inputs_exact':len(copies),'published_contract_blobs_exact':len(contracts['files']),'published_commit':contracts['commit'],'corrected_primary_claims_exact':len(dispositions),'no_primary_graph_upgrade':True,'native_references_exact':len(refs),'node_reference_union':86,'native_nodes_in_copied_snapshot':11,'native_nodes_needing_addition':49,'scope':'Finite design binding; no maintained adapter or merged-baseline acceptance.'}
(O/'supplemental-bindings.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
