from pathlib import Path
from hashlib import sha256
from html.parser import HTMLParser
import json
P=Path(__file__).resolve().parent
C=Path('/private/tmp/pathwaymech-next-269-root-locator-correction')
A=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
R=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion-independent-review')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
packets=[]
for root in (C,A,R):
 m=json.loads((root/'artifact-manifest.json').read_text())
 for row in m['files']:
  p=root/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 files={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
 assert files=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
 packets.append({'root':str(root),'manifest_sha256':sha(root/'artifact-manifest.json'),'listed':len(m['files']),'physical':len(files),'all_exact':True})
assert packets[0]['manifest_sha256']=='1f558e3c08b70361840e6eefd9173d6aea107278fd40e954641bb80ec905b3de'
assert (C/'predecessor-primary-claim-ledger.json').read_bytes()==(A/'results/primary-claim-ledger.json').read_bytes()
assert (C/'PMC5974017.html').read_bytes()==(A/'originals/PMC5974017.html').read_bytes()
assert (C/'independent-findings.json').read_bytes()==(R/'findings.json').read_bytes()
before=json.loads((C/'predecessor-primary-claim-ledger.json').read_text());after=json.loads((C/'primary-claim-ledger.json').read_text())
def flatten(value,path=()):
 if isinstance(value,dict):return {k:v for key,x in value.items() for k,v in flatten(x,path+(key,)).items()}
 if isinstance(value,list):return {k:v for i,x in enumerate(value) for k,v in flatten(x,path+(i,)).items()}
 return {path:value}
b=flatten(before);a=flatten(after);assert b.keys()==a.keys()
deltas=[{'path':list(k),'before':b[k],'after':a[k]} for k in a if a[k]!=b[k]]
assert {tuple(r['path']) for r in deltas}=={('claims',0,'sources',0,'locator'),('claims',0,'limits'),('claims',11,'sources',0,'locator')}
assert before['claims'][0]['limits'].replace('Figure 1 solid plates','Figure 4c solid plates')==after['claims'][0]['limits']
assert after['claims'][11]['sources'][0]['locator']=='Figure 7a–c; Discussion'
expected='Results: GDH is not indispensable for glutarate utilization; GDH and CsiD support glutarate dependent growth; Figure 1b; Figure 4a–c; Methods: Bacterial strains, culture conditions, and plasmids; Construction of mutant strains'
assert after['claims'][0]['sources'][0]['locator']==expected
assert len(after['claims'])==16 and all(x['claim']==y['claim'] for x,y in zip(before['claims'],after['claims']))
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_data(self,data):self.parts.append(data)
h=Text();h.feed((C/'PMC5974017.html').read_text());text=' '.join(' '.join(h.parts).split())
checks=['GDH is not indispensable for glutarate utilization','GDH and CsiD support glutarate dependent growth','Phylogenetic distribution of CsiD and LhgO','Metabolic pathways of glutarate in P. putida KT2440','after 36 h']
for phrase in checks:assert phrase in text,phrase
# Bind to prior independent visual checks of Figure 1/4 and Figure 6/7: main PDF pages 3/6/9/10.
source_bindings=[]
for c in after['claims']:
 for s in c['sources']:
  assert sha(A/s['path'])==s['sha256'];source_bindings.append({'claim':c['id'],**s})
assert sha(C/'primary-claim-ledger.json')=='6120d49e468bbf056922f2f09b122fae3080cc981ee4457d6f25871a8332353b'
result={'packets':packets,'three_scalar_differences':deltas,'claim_bodies_unchanged':16,'all_other_scalar_fields_unchanged':True,'all_original_source_bindings':source_bindings,'fresh_original_heading_caption_checks':checks,'visual_evidence_reuse':'Unchanged prior independent review, publisher main PDF pages 3/6/9/10; no repeated full-source reading claim.','dispositions':{'N269-SC-R01':'resolved','N269-SC-R02':'resolved'},'scope':'Locator correction accepted only; all prior scientific and source-availability boundaries remain.'}
(P/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'result':'PASS','physical_files_verified':sum(p['physical'] for p in packets),'changes':len(deltas),'unchanged_claim_bodies':16,'source_bindings':len(source_bindings),'resolved':['N269-SC-R01','N269-SC-R02']},indent=2))
