from pathlib import Path
import collections
import datetime
import hashlib
import json

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
P = Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def bind(p, base):
    return {'path': str(p.relative_to(base)), 'sha256': sha(p), 'bytes': p.stat().st_size}


before = json.loads((O / 'inputs/predecessor-binding.json').read_text())
assert sha(P / 'artifact-manifest.json') == before['manifest_sha256']
assert sha(P / 'HANDOFF.md') == before['handoff_sha256']
assert sha(P / 'ASSESSMENT.md') == before['assessment_sha256']
assert sha(P / 'freeze-proof.json') == before['freeze_sha256']
manifest = json.loads((P / 'artifact-manifest.json').read_text())
rows = manifest['files']
for r in rows:
    p = P / r['path']
    assert p.is_file() and not p.is_symlink()
    assert sha(p) == r['sha256'] and p.stat().st_size == r['bytes']
physical = [p for p in P.rglob('*') if p.is_file()]
assert len(rows) == 421 and len(physical) == 423
assert {str(p.relative_to(P)) for p in physical} == {r['path'] for r in rows} | {'artifact-manifest.json', 'freeze-proof.json'}
all_receipts = []
receipted = []
for p in sorted((O / 'receipts').glob('*.json')):
    for i, r in enumerate(json.loads(p.read_text())):
        all_receipts.append({'receipt': str(p.relative_to(O)), 'index': i, **r})
        if r.get('path'):
            f = O / r['path']
            assert sha(f) == r['sha256'] and f.stat().st_size == r['bytes']
            receipted.append(r['path'])
assert len(set(receipted)) == len(receipted) == 80
assert set(receipted) == {str(p.relative_to(O)) for p in (O / 'originals').rglob('*') if p.is_file()}
scope = json.loads((O / 'results/native-71-object-scope.json').read_text())
assert scope['count'] == len(scope['objects']) == 71
claims = json.loads((O / 'results/primary-claim-ledger.json').read_text())
assert claims['claim_count'] == len(claims['claims']) == 16
for row in claims['claims']:
    for source in row['sources']:
        assert sha(O / source['path']) == source['sha256']
forward = json.loads((O / 'results/162-object-forward-closure.json').read_text())
assert forward['object_count'] == 162 and len(forward['occurrences']) == 137 and not forward['unclosed']
assert len(json.loads((O / 'results/all-162-native-object-references.json').read_text())) == 33568
for p in O.rglob('*'):
    assert not p.is_symlink(), str(p)
result = {
    'checked_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'predecessor_before_binding': before,
    'predecessor_after': {'all_421_manifested_files_exact': True, 'physical_count_including_hidden_ignored': len(physical),
                        'all_423_physical_files': [bind(p, P) for p in sorted(physical)]},
    'new_acquisition_attempts': len(all_receipts), 'successful_saved_originals': len(receipted),
    'failed_attempts': [r for r in all_receipts if not r.get('path')],
    'native_original_count': 71, 'native_types': scope['types'],
    'native_receipt_envelope_checks': 'Complete, see finalize_ledgers.py; single object/frame/type/orgid/full/query/count/release plus exact bare request query, receipt hash and size.',
    'combined_native_original_count': 162, 'bounded_forward_occurrences': 137, 'bounded_forward_unclosed': 0,
    'all_descendant_reference_occurrences': 33568, 'primary_claim_count': 16,
    'source_bindings': 'Every source hash in all sixteen primary claims recomputed exact.',
    'scope': 'No maintained/Git/GitHub edits, installations, runtime repair, or live-worktree dependency. Author preparation, not independent scientific acceptance.'
}
(O / 'results/final-verification.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ['predecessor_after', 'predecessor_before_binding', 'failed_attempts']}, indent=2))
