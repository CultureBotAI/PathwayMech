from pathlib import Path
from html.parser import HTMLParser
import collections
import hashlib
import json
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
P = Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def save(name, data):
    (O / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


def binding(p):
    return {'path': str(p.relative_to(O)) if p.is_relative_to(O) else str(p),
            'bytes': p.stat().st_size, 'sha256': sha(p)}


receipts = []
for p in sorted((O / 'receipts').glob('*.json')):
    for i, row in enumerate(json.loads(p.read_text())):
        receipts.append((p, i, row))
allobjs = {}
for base in [P, O]:
    for p in sorted((base / 'originals').glob('META-*.xml')):
        root = ET.parse(p).getroot()
        obj = [n for n in root if n.tag != 'metadata'][0]
        assert obj.get('frameid') not in allobjs
        allobjs[obj.get('frameid')] = (p, root, obj)
assert len(allobjs) == 162
closure = json.loads((O / 'results/162-object-forward-closure.json').read_text())
incoming = collections.defaultdict(list)
for r in closure['occurrences']:
    incoming[r['target']].append({k: r[k] for k in ['owner', 'slot', 'type']})
assert len(closure['occurrences']) == 137 and not closure['unclosed']
expected = {r['target']: r['type'] for r in json.loads((O / 'inputs/forward-occurrences.json').read_text())}
assert len(expected) == 60
for _, _, r in receipts:
    if 'frame' in r and 'path' in r and r['frame'] not in expected:
        expected[r['frame']] = 'Gene'
assert len(expected) == 71

descriptions = {
    'Protein': 'Native component/subunit of a reaction-associated enzyme or complex. Component identity and source claims are retained; neither the parent activity nor an entire pathway is transferred to the isolated subunit without primary evidence.',
    'Gene': 'Native gene/product/accession/coordinate record. Product pointers and cross-reference relationship types are retained; no current sequence or strain equivalence is inferred from names or PART-OF accessions.',
    'Organism': 'Native taxon/strain context for a pathway, enzyme or organism-specific example. A source organism occurrence does not establish the complete five-member pathway in that organism. Current taxonomy issuer validation remains separate.',
    'Compound': 'Native cofactor or regulator-context material reached by a direct forward pointer. This is not automatically a stoichiometric pathway participant or a physiological requirement. Exact chemical issuer equivalence, CML atom/charge/stereo checks and primary assay context remain separate.'
}
specific = {
    'MONOMER-5381': 'Source gcdH subunit of CPLX-4041; species is historical ORG-5962 (Pseudomonas Sp. K172). Its gene G-4001 has ENTREZ:AE016774 PART-OF, not an exact validated gene/protein/strain identity.',
    'G-4001': 'gcdH; product MONOMER-5381; ENTREZ:AE016774 relationship PART-OF. No current strain reassignment or exact sequence mapping accepted.',
    'G1G01-166': 'gcdH, PP_0158, positive strand coordinates 168404–169585; native NCBI-GENE:1043671 and STRING:160488.PP_0158 are leads. The 2018 primary supports a KT2440 genetic phenotype; no purified GcdH assay was found in its complete main/supplement scope.',
    'ORG-5962': 'Literal common-name Pseudomonas Sp. K172 with rank species; no NCBI taxon cross-reference. Preserve historical strain wording and do not collapse to a modern taxon.',
    'ORG-5970': 'Literal common-name Pseudomonas sp. KB 740 with rank species; no NCBI taxon cross-reference. Preserve historical strain wording and do not collapse to a modern taxon.',
    'TAX-160488': 'Literal strain KT2440 under common-name Pseudomonas putida, native NCBI taxonomy lead 160488. Current taxonomy/assembly/sequence validation remains unperformed.',
    'ACETYL-COA-ACETYLTRANSFER-MONOMER': 'AtoB native comment distinguishes acetoacetyl-CoA specificity from broad FadA; reports acetoacetate induction and BL21/K-12 sequence identity. These are native source assertions with separately tagged computational and experimental GO/features, not fresh primary acceptance or glutaryl-CoA pathway evidence.',
    'SELENOMETHIONINE': 'Literal cofactor of ENZRXN-14343 / CPLX-7510, a selenium-containing Clostridium kluyveri thiolase example. Native activity physiological direction is left-to-right synthesis, opposite the pathway thiolysis orientation. Do not assert free selenomethionine consumption or a universal thiolase requirement.',
    'IODOACETAMIDE': 'Native synonym N-(3-methoxy-4-butoxybenzyl)thiobarbituric acid appears structurally inconsistent with the native iodoacetamide InChI. Retain as a source identity hazard pending issuer/structure assessment; do not propagate the synonym as validated equivalence.',
    'NA+': 'Bare-query literal plus succeeds; percent-encoded plus returned 404. Native InChI denotes Na+; CAS:7440-23-5 is retained only as a source cross-reference, not an accepted ion equivalence.',
    'K+': 'Bare-query literal plus succeeds; percent-encoded plus returned 404. Native ion identity is retained; exact external issuer equivalence remains unassessed.',
}
inventory = []
slots = []
for p in sorted((O / 'originals').glob('META-*.xml')):
    root = ET.parse(p).getroot()
    objs = [x for x in root if x.tag != 'metadata']
    assert len(objs) == 1
    obj = objs[0]
    f = obj.get('frameid')
    matches = [(rp, i, r) for rp, i, r in receipts if r.get('path') == str(p.relative_to(O))]
    assert len(matches) == 1
    rp, i, r = matches[0]
    assert r['frame'] == f and sha(p) == r['sha256'] and p.stat().st_size == r['bytes']
    assert urlsplit(r['url']).query == 'META:' + f
    assert urlsplit(r['url']).hostname == 'bf2i-artsymbiocyc.insa-lyon.fr'
    assert urlsplit(r['url']).path == '/getxml'
    assert root.findtext('metadata/query') == 'META:' + f
    assert root.findtext('metadata/num_results') == '1'
    assert obj.tag == expected[f] and obj.get('orgid') == 'META' and obj.get('detail') == 'full'
    assert root.get('ptools-version') == '27.0'
    xrefs = [{'database': x.findtext('dblink-db'), 'identifier': x.findtext('dblink-oid'),
              'relationship': x.findtext('dblink-relationship')} for x in obj.findall('dblink')]
    row = {'frame': f, 'type': obj.tag, 'label': obj.findtext('common-name'),
           **binding(p), 'receipt': str(rp.relative_to(O)), 'receipt_array_index': i,
           'query': root.findtext('metadata/query'), 'num_results': 1, 'orgid': 'META',
           'detail': 'full', 'ptools_version': '27.0', 'direct_slots': len(obj),
           'incoming_bounded_forward_occurrences': incoming[f],
           'native_xrefs': xrefs, 'scope': descriptions[obj.tag],
           'specific_caution': specific.get(f),
           'human_reading': 'Complete selected biological projection for this type; full original retained. Metadata/credits/global inverse links and CML graphs are not asserted to have been read or independently validated.'}
    inventory.append(row)
    for i, x in enumerate(obj):
        slots.append({'owner': f, 'slot': x.tag, 'index': i + 1, 'xml': ET.tostring(x, encoding='unicode')})
assert len(inventory) == 71 and {r['frame'] for r in inventory} == set(expected)
save('results/native-71-object-scope.json', {'count': 71, 'types': dict(collections.Counter(r['type'] for r in inventory)),
     'validated': 'Every receipt/hash/size, request query, single-full-object frame/type/orgid/detail, result count and release version checked.',
     'objects': inventory})
save('results/native-71-all-direct-slots.json', slots)

image_names = ['Attachment10.png', 'Attachment13.png', 'Attachment3.png', 'Attachment11.png',
               'Attachment7.png', 'Attachment9.png', 'Attachment1.png', 'Attachment6.png',
               'Attachment8.png', 'Attachment4.png', 'Attachment2.png', 'Attachment12.png', 'Attachment5.png']
q = O / 'reading/quicklook/41467_2018_4513_MOESM1_ESM.doc.qlpreview'
save('results/supplement-image-caption-map-verified.json', {
    'original': binding(O / 'originals/41467_2018_4513_MOESM1_ESM.doc'),
    'preview': binding(q / 'Preview.html'),
    'method': 'Actual document order plus fresh visual inspection of all thirteen images and their captions.',
    'supersedes_failed_attempt': 'results/supplement-image-caption-map.json',
    'failure': 'Automated following-caption regex incorrectly matched figure 9 for figures 5–8 because of HTML markup/nonbreaking spaces. That attempt is preserved and must not be used as the final map.',
    'figures': [{'figure': i + 1, 'image': binding(q / name), 'visually_inspected': True} for i, name in enumerate(image_names)]})


class TextReader(HTMLParser):
    def __init__(self):
        super().__init__()
        self.skip = 0
        self.data = []

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self.skip += 1
        if tag in ('p', 'div', 'section', 'h1', 'h2', 'h3'):
            self.data.append('\n')

    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self.skip -= 1

    def handle_data(self, value):
        if not self.skip:
            self.data.append(value)


reader = TextReader()
reader.feed((O / 'originals/BF00250279.pdf').read_text())
(O / 'reading/1993-publisher-preview.txt').write_text('\n'.join(' '.join(x.split()) for x in ''.join(reader.data).splitlines() if x.strip()) + '\n')
save('results/reading-scope.json', {
 'fresh': [
  {'source': binding(O / 'originals/PMC5974017.html'), 'scope': 'Complete main text, methods, all tables, figure captions and references read as text.', 'derivative': binding(O / 'reading/PMC5974017.txt')},
  {'source': binding(O / 'originals/s41467-018-04513-0.pdf'), 'scope': 'Fourteen pages rendered. All seven main figures and Table 1 visually inspected; pages 2–10 inspected. Full PDF text available; complete main reading was from PMC HTML, not a claim that all fourteen rendered pages were visually read.', 'visual_pages': [2,3,4,5,6,7,8,9,10]},
  {'source': binding(O / 'originals/s41467-018-04513-0.html'), 'scope': 'Publisher source and actual supplement link inventory inspected; not a second full-main reading.'},
  {'source': binding(O / 'originals/41467_2018_4513_MOESM1_ESM.doc'), 'scope': 'Complete QuickLook document text: supplementary methods, thirteen captions, six tables and seven references. All thirteen embedded figures visually inspected. No paginated DOC table-layout or underlying binary-document audit claimed.'},
  {'source': binding(O / 'originals/41467_2018_4513_MOESM2_ESM.doc'), 'scope': 'Complete short supplementary-data description read.'},
  {'source': binding(O / 'originals/41467_2018_4513_MOESM3_ESM.xls'), 'scope': 'All rendered nonblank worksheet text read (strains/plasmids); all three worksheet previews inventoried. Other two previews blank. No hidden-row, formula, BIFF-cell or full workbook semantic audit claimed.'},
  {'source': binding(O / 'originals/41467_2018_4513_MOESM4_ESM.xls'), 'scope': 'All rendered nonblank worksheet text read (oligonucleotides and their stated uses); all three worksheet previews inventoried. Other two previews blank. No hidden-row, formula, BIFF-cell or exact primer/genome alignment audit claimed.'},
  {'source': binding(O / 'originals/41467_2018_4513_MOESM5_ESM.pdf'), 'scope': 'All thirty-seven pages of peer-review correspondence read as extracted text; pages 19, 26, 30, 33 additionally visually inspected. Historical revisions distinguished from final published claims.', 'visual_pages': [19,26,30,33]},
  {'source': binding(O / 'originals/BF00250279.pdf'), 'scope': 'Actual format is HTML publisher preview. Exact abstract and access marker freshly inspected. Not a PDF or full 1993 main reading.'},
  {'source': 'results/native-71-object-scope.json', 'scope': 'All 71 new objects covered in type-specific selected biological reading projections; complete originals, every direct XML slot, and every descendant reference retained separately. This is native assertion reading, not primary validation.'}
 ],
 'bounded_reuse': {
  'packet': str(P), 'manifest_sha256': sha(P / 'artifact-manifest.json'),
  'native_scope': 'Initial complete pathway, five member equations, three associated reactions, 29 enzyme activities, 30 protein/class objects, 13 compounds, 10 regulations; exact historical reading scope remains in initial HANDOFF/ASSESSMENT.',
  '2009': json.loads((P / 'results/primary-reading-bindings.json').read_text()),
  'limitation': 'No fresh re-reading or independent acceptance of the 2009 source or initial scientific assessment is claimed by this successor.'
 },
 'reader_binary': binding(Path('/private/tmp/pathwaymech-next-268-primary/read_pdf')),
 'failed_attempts': 'results/reader-attempts.json',
 'not_claimed': ['Current issuer validation for any newly acquired native cross-reference', 'Complete chemistry/atom/stereo audit', 'Whole-pathway direct experimental reconstitution', 'Global source exhaustion', 'Independent review acceptance', 'Merged-baseline rebind or maintained curation']
})
print('New native originals:', len(inventory), 'direct slots:', len(slots))
print('Types:', dict(collections.Counter(r['type'] for r in inventory)))
