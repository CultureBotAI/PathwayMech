from pathlib import Path
import urllib.request,urllib.parse,datetime,hashlib,json,concurrent.futures,shutil
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion'); P=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if not (O/'inputs/forward-occurrences.json').exists():
 for src,dest in [('results/unacquired-forward-original-prerequisites.json','forward-occurrences.json'),('results/native-originals-inventory.json','predecessor-native-inventory.json'),('HANDOFF.md','predecessor-HANDOFF.md'),('ASSESSMENT.md','predecessor-ASSESSMENT.md')]: shutil.copyfile(P/src,O/'inputs'/dest)
 shutil.copytree(P/'inputs/governing-and-ledgers',O/'inputs/governance')
rows=json.loads((O/'inputs/forward-occurrences.json').read_text()); unique={r['target']:r['type'] for r in rows}
requests=[{'frame':f,'expected_type':t,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?'+urllib.parse.quote('META:'+f,safe=':'),'name':'META-'+f+'.xml'} for f,t in sorted(unique.items())]
requests += [
 {'name':'PMC5974017.html','url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC5974017/'},
 {'name':'s41467-018-04513-0.html','url':'https://www.nature.com/articles/s41467-018-04513-0'},
 {'name':'s41467-018-04513-0.pdf','url':'https://www.nature.com/articles/s41467-018-04513-0.pdf'},
 {'name':'BF00250279.pdf','url':'https://link.springer.com/content/pdf/10.1007/BF00250279.pdf'}]
(O/'inputs/acquisition-requests.json').write_text(json.dumps(requests,indent=2)+'\n')
def fetch(row):
 r={**row,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(row['url'],headers={'User-Agent':'PathwayMech evidence preparation'}),timeout=35) as resp:
   data=resp.read();r.update(status=resp.status,final_url=resp.url,headers={k:v for k,v in resp.headers.items() if k.lower()!='set-cookie'},bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),path='originals/'+row['name'])
  with (O/r['path']).open('xb') as f:f.write(data)
 except Exception as e:r['error']=repr(e)
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:results=list(ex.map(fetch,requests))
with (O/'receipts/first-acquisition.json').open('x') as f:json.dump(results,f,indent=2);f.write('\n')
print(json.dumps([{'name':r['name'],'status':r.get('status'),'bytes':r.get('bytes'),'error':r.get('error')} for r in results],indent=2))
