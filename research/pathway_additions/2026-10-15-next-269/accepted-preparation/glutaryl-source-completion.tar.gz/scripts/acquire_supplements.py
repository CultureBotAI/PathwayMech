from pathlib import Path
import json,urllib.request,datetime,hashlib,concurrent.futures
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
links=json.loads((O/'results/s41467-018-04513-0.html-links.json').read_text())
rows=[{'name':u.rsplit('/',1)[-1],'url':u,'discovered_in':'originals/s41467-018-04513-0.html'} for u in links if 'media.springernature.com/' in u]
for frame in ['NA+','K+']:
 rows += [{'name':'META-'+frame+'-literal.xml','url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+frame,'frame':frame,'attempt':'literal bare query after percent encoded 404'}]
def fetch(row):
 r={**row,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(row['url'],headers={'User-Agent':'PathwayMech evidence preparation'}),timeout=35) as resp:
   data=resp.read();r.update(status=resp.status,final_url=resp.url,headers={k:v for k,v in resp.headers.items() if k.lower()!='set-cookie'},bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),path='originals/'+row['name'])
  with (O/r['path']).open('xb') as f:f.write(data)
 except Exception as e:r['error']=repr(e)
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rs=list(ex.map(fetch,rows))
(O/'receipts/supplements-and-query-retry.json').write_text(json.dumps(rs,indent=2)+'\n');print(json.dumps(rs,indent=2))
