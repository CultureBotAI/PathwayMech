from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,xml.etree.ElementTree as E,collections
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion');P=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
def wr(n,x): (O/'results'/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
receipts=sum([json.loads(p.read_text()) for p in (O/'receipts').glob('*.json')],[])
objects=[];slots=[];byframe={};remaining=[];pubs={}
old=json.loads((O/'inputs/predecessor-native-inventory.json').read_text());have={x['frame'] for x in old['objects']}
expected={x['target']:x['type'] for x in json.loads((O/'inputs/forward-occurrences.json').read_text())}
for r in receipts:
 if 'path' in r:
  p=O/r['path'];assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
  if 'frame' not in r:continue
  root=E.parse(p).getroot();nodes=[x for x in root if x.tag!='metadata'];assert len(nodes)==1
  obj=nodes[0];f=r['frame'];assert obj.get('frameid')==f and obj.get('orgid')=='META' and obj.get('detail')=='full';assert root.findtext('metadata/query')=='META:'+f and root.findtext('metadata/num_results')=='1';assert obj.tag==expected[f]
  assert f not in byframe;byframe[f]=obj;have.add(f)
  objects.append({'frame':f,'type':obj.tag,'label':obj.findtext('common-name'),'path':r['path'],'sha256':sha(p),'bytes':p.stat().st_size,'version':root.get('ptools-version'),'direct_slot_count':len(obj)})
  for i,x in enumerate(obj):slots.append({'owner':f,'slot':x.tag,'index':i+1,'xml':E.tostring(x,encoding='unicode')})
assert set(byframe)==set(expected)
projection=[]
for f,obj in byframe.items():
 q={'frame':f,'type':obj.tag,'label':obj.findtext('common-name'),'slots':[]}
 for x in obj:
  if x.tag not in ['catalyzes','appears-in-left-side-of','appears-in-right-side-of','component-of','cofactor-of','regulates','inhibits','activates','instance','parent','subclass','cml']:
   q['slots'].append(E.tostring(x,encoding='unicode').strip())
 for slot in ['gene','component','components','cofactor','prosthetic-group','regulated-by','regulator','enzyme','species']:
  for node in obj.findall(slot):
   for x in node:
    target=x.get('frameid')
    if target and target not in have:remaining.append({'owner':f,'slot':slot,'target':target,'type':x.tag,'detail':x.get('detail')})
 for x in obj.iter('Publication'):
  pid=x.findtext('pubmed-id') or x.get('frameid');pubs.setdefault(pid,{'id':pid,'origins':[],'title':x.findtext('title')})['origins'].append(f)
 projection.append(q)
wr('native-60-inventory.json',{'count':len(objects),'types':dict(collections.Counter(x['type'] for x in objects)),'objects':objects,'checks':'All60 request/frame/type/orgid/full/query/num_results/hash/size exact;70 inherited occurrences all resolve.'})
wr('complete-native-direct-slots.json',slots);wr('native-biological-reading-projection.json',projection);wr('new-forward-prerequisites.json',remaining);wr('publication-leads.json',list(pubs.values()))
class H(HTMLParser):
 def __init__(self):super().__init__();self.out=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['style','script']:self.skip+=1
  if t in ['p','div','tr','h1','h2','h3']:self.out.append('\n')
  if t in ['td','th']:self.out.append(' | ')
 def handle_endtag(self,t):
  if t in ['style','script']:self.skip-=1
 def handle_data(self,d):
  if not self.skip:self.out.append(d)
for p in sorted((O/'reading/quicklook').rglob('*.html')):
 h=H();h.feed(p.read_text());s='\n'.join(' '.join(l.split()) for l in ''.join(h.out).splitlines() if l.strip());(p.parent/(p.name+'.txt')).write_text(s+'\n')
print('Objects',len(objects),'slots',len(slots),'types',dict(collections.Counter(x['type'] for x in objects)),'newforward',len(remaining),'targets',len({x['target'] for x in remaining}));print(json.dumps(remaining,indent=2))
