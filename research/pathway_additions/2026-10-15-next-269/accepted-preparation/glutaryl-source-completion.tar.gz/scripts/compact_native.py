from pathlib import Path
import xml.etree.ElementTree as E,json,hashlib,collections
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion');P=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
rows=[];allobjs={};allpaths={}
for base in [P,O]:
 for p in sorted((base/'originals').glob('META-*.xml')):
  root=E.parse(p).getroot();obj=[x for x in root if x.tag!='metadata'][0];allobjs[obj.get('frameid')]=obj;allpaths[obj.get('frameid')]=p
skip={'cml','credits','created-by','creation-date','last-curated','data-source','gibbs-0','molecular-weight-exp','molecular-weight-seq','pI','splice-form-introns','splice-form-encoding','citations','citation','component-of','catalyzes','cofactor-of','inhibitor-of','activator-of','appears-in-left-side-of','appears-in-right-side-of','parent','instance','subclass'}
for p in sorted((O/'originals').glob('META-*.xml')):
 root=E.parse(p).getroot();obj=[x for x in root if x.tag!='metadata'][0];f=obj.get('frameid');rec={'frame':f,'type':obj.tag,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'slots':[],'skipped_slot_counts':dict(collections.Counter(x.tag for x in obj if x.tag in skip))}
 for x in obj:
  if x.tag in skip:continue
  if x.tag=='dblink': rec['slots'].append({'slot':x.tag,'db':x.findtext('dblink-db'),'id':x.findtext('dblink-oid'),'relationship':x.findtext('dblink-relationship')})
  elif len(x):rec['slots'].append({'slot':x.tag,'value':' '.join(x.itertext()).strip(),'object_refs':[{'tag':n.tag,'frame':n.get('frameid'),'org':n.get('orgid')} for n in x.iter() if n.get('frameid')]})
  else:rec['slots'].append({'slot':x.tag,'value':x.text,'attributes':x.attrib})
 rows.append(rec)
for typ in ['Protein','Gene','Organism','Compound']:
 selected=[r for r in rows if r['type']==typ];s='\n'.join(json.dumps(r,ensure_ascii=False) for r in selected)+'\n';(O/'reading'/('native-'+typ+'.jsonl')).write_text(s);print(typ,len(selected),len(s))
forward=[];allrefs=[]
for f,obj in allobjs.items():
 for x in obj:
  for n in x.iter():
   if n.get('frameid'):allrefs.append({'owner':f,'slot':x.tag,'target':n.get('frameid'),'type':n.tag,'class':n.get('class'),'present_full_original':n.get('frameid') in allobjs})
  if x.tag in ['gene','component','components','cofactor','prosthetic-group','regulated-by','regulator','enzyme','species']:
   for n in x:
    if n.get('frameid'):forward.append({'owner':f,'slot':x.tag,'target':n.get('frameid'),'type':n.tag,'present_full_original':n.get('frameid') in allobjs})
(O/'results/162-object-forward-closure.json').write_text(json.dumps({'object_count':len(allobjs),'scope_slots':['gene','component','components','cofactor','prosthetic-group','regulated-by','regulator','enzyme','species'],'occurrences':forward,'unclosed':[r for r in forward if not r['present_full_original']],'limitation':'This closure excludes class parents, inverse reaction/activity links, all unrelated global uses of cofactors and inhibitors, publications, credits and external cross-reference issuer records. It is not full ontology closure or scientific acceptance.'},indent=2)+'\n')
(O/'results/all-162-native-object-references.json').write_text(json.dumps(allrefs,indent=2)+'\n');print('forward',len(forward),'unclosed',sum(not r['present_full_original'] for r in forward),'allrefs',len(allrefs))
