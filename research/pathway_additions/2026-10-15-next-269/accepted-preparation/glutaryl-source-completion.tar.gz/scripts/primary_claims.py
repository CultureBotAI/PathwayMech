from pathlib import Path
import hashlib
import json

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')


def src(name, locator):
    p = O / 'originals' / name
    return {'path': str(p.relative_to(O)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'locator': locator}


M = 'PMC5974017.html'
S = '41467_2018_4513_MOESM1_ESM.doc'
D1 = '41467_2018_4513_MOESM3_ESM.xls'
D2 = '41467_2018_4513_MOESM4_ESM.xls'
R = '41467_2018_4513_MOESM5_ESM.pdf'
claims = []


def add(n, claim, level, evidence, limits):
    claims.append({'id': 'N269-SC-P%02d' % n, 'claim': claim, 'evidence_level': level,
                   'sources': [src(*x) for x in evidence], 'limits': limits})


add(1, 'KT2440 PP0158/gdh deletion modestly reduces growth and glutarate consumption; additional csiD deletion prevents observed growth under the tested glutarate conditions.',
    'Genetic perturbation and growth/substrate consumption',
    [(M, 'Results: Another glutarate catabolic pathway exists in P. putida; Figure 1b–e; Methods: Bacterial strains, culture conditions, and plasmids; Construction of mutant strains'),
     (S, 'Supplementary Table 1; Supplementary Figure 9'), (D1, 'Supplementary Data 1: KT2440 wild-type and deletion strains')],
    'MSM with 5 g/L glutarate, 30°C, 200 rpm unless otherwise stated; Figure 1 solid plates at 36 h, Supplementary Figure 9 at 12 h. Genetic association is not a purified GcdH assay, exact ETF coupling, or reconstitution of every native PWY-5177 member.')
add(2, 'The complementation constructs called csiD and gdh have larger stated inserts: csiD plus lhgO, and gdh plus pp0159, respectively.',
    'Published construct-method specification, reconciled with phenotype labeling',
    [(D2, 'Supplementary Data 2: csiD-cF (Pc), csiD-cF (Ptac), csiD-cR; gdh-cF (Pc), gdh-cF (Ptac), gdh-cR, Use column; extracted text lines 45–52'),
     (S, 'Complementation of csiD and gdh in ΔgdhΔcsiD; Supplementary Figure 8'),
     (D1, 'pMMPc-Gm-csiD, pMMPc-Gm-gdh, pMMPtac-Gm-csiD, pMMPtac-Gm-gdh rows')],
    'Rescue of the double mutant cannot be described as isolated single-gene-only complementation from these methods. This does not negate the deletion phenotype. PP0159 function, exact cloned sequence and polar effects were not independently determined here. Larger insert scope is explicit in the primer-use table, while the main text and plasmid names use shorter labels.')
add(3, 'Both gdh and csiD transcripts are detected at early sampling during glutarate growth; the final zero-hour sample follows contact with glutarate.',
    'RT-PCR and absolute qPCR expression',
    [(M, 'Results: Competitive advantage of glutarate hydroxylation pathway; Methods: RT-PCR and quantitative real-time PCR'),
     (S, 'Sample preparation for qPCR; Construction of standard curves for qPCR; Supplementary Figures 4–7, 13'),
     (R, 'PDF page 30, author response on revised glucose preculture and immediate post-transfer sampling')],
    'Glucose preculture, exponential harvest, three washes, transfer to MSM 5 g/L glutarate, then immediate sampling; three independent biological cultures. Expression does not quantify pathway flux or establish a pre-exposure constitutive state. Absolute plasmid-standard qPCR supersedes earlier review-stage relative normalization.')
add(4, 'Purified KT2440 CsiD is an Fe(II)/2-ketoglutarate-dependent glutarate hydroxylase, supported by oxygen consumption, product assays and controls.',
    'Purified recombinant enzyme assays',
    [(M, 'Results: CsiD is a Fe2+/2-KG-dependent glutarate hydroxylase; Figure 2; Methods: Expression and purification of enzymes; Enzyme assays'),
     (S, 'Supplementary Figure 1; Materials')],
    'PP2909 CsiD was expressed from pETDuet-1 in E. coli BL21(DE3), induced at 16°C for 10 h with 1 mM IPTG, HisTrap-purified. The CsiD assay is not a GcdH assay; free glutarate specificity does not establish glutaryl-CoA turnover by CsiD.')
add(5, 'CsiD cofactor-omission controls show low activity without glutarate or 2-KG, and reduced but substantial activity without added Fe2+ or ascorbate.',
    'Purified-enzyme assay controls',
    [(M, 'Figure 2f and corresponding Results; Methods: Enzyme assays'), (R, 'PDF pages 26–27, ascorbate clarification')],
    'Standard mixture: 20 mM imidazole pH 6.7, 1 mM glutarate, 1 mM 2-KG, 0.4 mM ascorbate, 50 µM Fe2+, 2 µg enzyme per 500 µL. Reported residual activities: about 7% without glutarate, negligible without 2-KG, 80.3% without added Fe2+, 42.6% without ascorbate. Do not relabel the last two controls as zero activity or infer ascorbate stoichiometric consumption.')
add(6, 'The source assigns the hydroxylation product as L-2-hydroxyglutarate using multiple assays.',
    'Mass-spectrometric constitution plus enzyme-selectivity and downstream-substrate evidence',
    [(M, 'Figures 2h–i, 3c–d and associated Results'), (S, 'Enzymatic assay of HGDH; Supplementary Figures 1–2; Quantification of l-lysine and l-2-HG')],
    'Mass alone does not resolve enantiomers. The product lacked response in an NAD-dependent D-2-HG dehydrogenase assay with D-2-HG positive control, and was consumed by LhgO. SI separately describes chiral LC-MS/MS with a Chirobiotic R column and isotope internal standard for cellular L-2-HG quantification. No independent reanalysis of raw spectra or stereochemical issuer records is claimed.')
add(7, 'CsiD oligomeric and kinetic observations belong to the purified recombinant CsiD construct.',
    'Gel filtration and fitted enzyme kinetics',
    [(M, 'Figure 2a–b; Table 1; Methods: Determination of polymerization degree of CsiD; Enzyme assays')],
    'Calculated monomer 38.9 kDa and gel-filtration polymerization estimate 7.85 support an octamer under the assay. Km values for glutarate, 2-KG and O2 are 145.67±1.53, 95.33±0.97 and 266.33±13.58 µM. These are not GcdH constants or evidence for the native GcdH oligomer.')
add(8, 'Purified KT2440 LhgO converts L-2-HG to 2-KG and can consume O2 with FAD supplementation.',
    'Purified recombinant enzyme assays',
    [(M, 'Results: LhgO is an l-2-HG oxidase; Figure 3; Methods: Expression and purification of enzymes; Enzyme assays'),
     (S, 'Supplementary Figure 2; Supplementary Table 3')],
    'PP2910 was expressed/purified as the CsiD construct protocol. Standard DCPIP assay uses 5 mM L-2-HG, 0.1 mM DCPIP, 0.021 mg/mL enzyme at 30°C in 50 mM Tris-HCl pH 7.4. Oxygen assay preincubates enzyme with 50 µM FAD or FMN for 1 h on ice. Final oxidase evidence supersedes an early correspondence claim of poor O2 activity; no native ETF identity follows from this separate pathway.')
add(9, 'The CsiD oxygen/glutarate 1:1 stoichiometric expectation was not measured by the oxygen-only trace.',
    'Explicit author limitation in correspondence, consistent with final assay design',
    [(R, 'PDF page 26, response to question 2 on O2/glutarate stoichiometry'),
     (M, 'Figure 2c; Methods: Enzyme assays; Figure 7a schematic')],
    'The authors state the Clark electrode measures O2 consumption only and infer likely 1:1 from the enzyme family. Preserve the distinction between a proposed formal equation and independently measured product/substrate stoichiometry. This pertains to CsiD, not the native GcdH reaction.')
add(10, 'The competition experiments support a condition-specific fitness advantage of the hydroxylation route.',
    'Pairwise competition and growth model',
    [(M, 'Figure 4; Methods: Fitness assays'), (S, 'Supplementary Figure 3; Supplementary Table 1; Modeling of bacterial growth')],
    'Five independent competition experiments, 24 h glutarate culture and bphC-marking control. Reported W: wild type versus ΔcsiD 20.64±0.65; wild type versus Δgdh 5.70±0.19; Δgdh versus ΔcsiD 5.35±0.16. These are not universal pathway fitness constants or direct carbon fluxes.')
add(11, 'The engineered triple mutant accumulated glutarate from lysine with the reported 0.85 mol/mol yield.',
    'Engineered-strain production phenotype',
    [(M, 'Figure 5; Results: Production of glutarate from l-lysine; Methods: Growth conditions'),
     (D1, 'KT2440 ΔgdhΔcsiDΔalr row')],
    'Glucose plus lysine culture produced 1.92 g/L in ΔgdhΔcsiD and 1.94 g/L with additional alr deletion; lysine-only double mutant gave approximately 0.04 g/L after 24 h. Do not transfer engineered yield to wild type or infer purified downstream pathway chemistry from production.')
add(12, 'The paper relates the two glutarate routes to glyoxylate/TCA metabolism, with a proposed explanation for faster growth via succinate.',
    'Network interpretation supported by genetic growth comparisons',
    [(M, 'Figure 6; Figure 7; Discussion'), (S, 'Supplementary Figure 10'),
     (R, 'PDF pages 18–19, response on unavailable U-13C-glutarate and lack of tracer experiment')],
    'No 13C flux tracing was performed. Figure 7 includes upstream free-glutarate activation and downstream TCA/glyoxylate contexts beyond native PWY-5177. Do not expand native membership or claim measured flux partition from the schematic.')
add(13, 'KT2440 CsiR control and glutarate as its effector are proposed, not directly demonstrated by this study.',
    'Regulatory hypothesis',
    [(M, 'Discussion: CsiD expression, CsiR PP2908 and glutarate effector paragraph'),
     (R, 'PDF pages 32–34; page 33 explicitly speculative CsiR/glutarate mechanism')],
    'The E. coli RpoS/CsiR literature and KT2440 gene adjacency/expression are distinct contexts. No KT2440 CsiR binding, effector or regulator-deletion experiment is established by these sources.')
add(14, 'The homolog survey and the small experimentally assayed homolog panel have different evidential scope.',
    'Finite sequence-homology survey plus selected recombinant assays',
    [(M, 'Discussion; Methods: Identification of homologs of CsiD, LhgO, and GDH; Expression and purification of enzymes'),
     (S, 'Supplementary Tables 2–6'), (D1, 'CsiD/LhgO expression constructs')],
    'The survey used GenBank dated 2016-04-06, >90% coverage, >50% identity, E-value <1e-30. Counts 454 CsiD, 612 LhgO, 1004 GDH are historical hits, not experimentally established whole pathways. Purified homolog assays are CsiD/LhgO examples, not a GcdH panel. Source strain wording and duplicate/odd accession rows require issuer checks before reuse.')
add(15, 'The acquired 1993 GCD endpoint provides only the authentic publisher abstract/preview.',
    'Abstract-only primary evidence',
    [('BF00250279.pdf', 'Actual HTML: dc.description and Abstract section, source line 876; preview-of-subscription marker at lines 893–895')],
    'HTTP 200 and a .pdf request path do not establish a PDF. It reports purified KB740/K172 GCD, ferricenium-based assays, decarboxylation, FAD homotetramers and avidin-negative behavior, but full methods/results/figures were not obtained. No full-main acceptance, exact physiological acceptor, sodium-pump stoichiometry or modern strain/sequence binding is inferred.')
add(16, 'The 2018 study does not directly establish all five source-native PWY-5177 reactions in KT2440.',
    'Finite full-main and supplement scope assessment',
    [(M, 'Complete Results/Methods; Figure 7'), (S, 'Complete supplementary methods, figures and tables'),
     (D1, 'All displayed strains/plasmids rows'), (D2, 'All displayed primer-use rows')],
    'The genetic PP0158 association may support organism-specific context for a GcdH-containing route. Purified downstream hydratase, NAD-dependent dehydrogenase, thiolase, isolated GcdH half-reactions and native ETF coupling are not demonstrated in this finite source set. Absence is limited to these displayed originals; no universal literature absence is claimed.')

(O / 'results/primary-claim-ledger.json').write_text(json.dumps({'source_doi': '10.1038/s41467-018-04513-0',
 'source_pmid': '29844506', 'claim_count': len(claims), 'claims': claims,
 'disposition': 'Author preparation; requires independent review before curation. Exact source-level support and unresolved boundaries are preserved.'}, indent=2, ensure_ascii=False) + '\n')
print('Claims:', len(claims))
