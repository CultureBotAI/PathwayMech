from pathlib import Path
import json,urllib.request,datetime,hashlib,concurrent.futures
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion'); rows=json.loads((O/'results/new-forward-prerequisites.json').read_text())
def fetch(row):
 f=row['target'];r={**row,'frame':f,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+f,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(r['url'],headers={'User-Agent':'PathwayMech evidence preparation'}),timeout=35) as resp:
   d=resp.read();r.update(status=resp.status,final_url=resp.url,bytes=len(d),sha256=hashlib.sha256(d).hexdigest(),path='originals/META-'+f+'.xml')
  with (O/r['path']).open('xb') as stream:stream.write(d)
 except Exception as e:r['error']=repr(e)
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rs=list(ex.map(fetch,rows))
(O/'receipts/gene-completion.json').write_text(json.dumps(rs,indent=2)+'\n');print(json.dumps([{'frame':r['frame'],'status':r.get('status'),'error':r.get('error')} for r in rs],indent=2))
