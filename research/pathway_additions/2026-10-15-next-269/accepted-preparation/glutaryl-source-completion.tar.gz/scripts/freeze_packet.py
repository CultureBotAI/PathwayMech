from pathlib import Path
import datetime
import hashlib
import json

O = Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
excluded = {'artifact-manifest.json', 'freeze-proof.json'}
assert not any((O / name).exists() for name in excluded), 'Never overwrite a frozen packet'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def files():
    return sorted(p for p in O.rglob('*') if p.is_file() and str(p.relative_to(O)) not in excluded)


handoff = '''# PWY-5177 source-completion handoff

FROZEN AUTHOR PREPARATION. Independent scientific review, exact chemistry/issuer checks and an actual merged-baseline rebind remain required before maintained curation.

Owner: `/private/tmp/pathwaymech-next-269-glutaryl-source-completion`.
Predecessor: `/private/tmp/pathwaymech-next-269-glutaryl-preparation`, manifest `bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b`. All 421 manifested / 423 physical predecessor files remained exact before and after this task. No live 268 worktree dependency or maintained/Git/GitHub/runtime changes.

## Result

- All initial 70 native forward-reference occurrences resolve through 60 newly acquired unique full originals; eleven further genes close the newly exposed direct gene references. New total: 71 native originals (12 proteins, 25 genes, 27 organisms, 7 compounds), 864 direct slots. Combined with the initial 91: 162 objects and 137 direct occurrences in the explicit nine-slot closure, zero unclosed in that scope.
- All 71 source responses passed exact receipt/hash/size, request query, frame/type/PGDB/full-detail, one-result and release checks. Every unique object has an owner/slot/evidence-scope row. All-descendant inventory retains 33,568 references without claiming full ontology closure.
- Full 2018 KT2440 main reading and all seven main figures/Table 1 visual inspection; all five publisher supplements acquired. Complete SI text and all thirteen SI figures read/inspected; every nonblank workbook preview read, with hidden-cell/formula audit explicitly excluded. All 37 peer-review pages read as text, four pages additionally visually inspected.
- The most important construct caveat: Supplementary Data 2 specifies **csiD + lhgO** and **gdh + pp0159** inserts. Complemented growth is not single-gene-only rescue evidence. The 2018 GcdH evidence is genetic; the purified assays concern CsiD/LhgO. O2/glutarate stoichiometry and carbon flux were not directly measured, and KT2440 CsiR/glutarate regulation remains hypothetical.
- The 1993 DOI PDF request returned an HTML subscription preview. Abstract-only support is retained; full-main reading remains open. The failed requests/extractions and corrected figure-map attempt are preserved.

## Review entry points

Read `ASSESSMENT.md` in full, then:

1. `results/primary-claim-ledger.json`: sixteen claims with exact source hashes, locators, evidence levels and limits.
2. `results/native-71-object-scope.json`: all unique new objects, literal xref relationships, incoming contexts and reading scope.
3. `results/162-object-forward-closure.json`, `results/native-71-all-direct-slots.json`, and the complete original XMLs for mechanical closure and biological source assertions.
4. `results/reading-scope.json`, `results/supplement-image-caption-map-verified.json`, original primary files and retained reading derivatives for actual reading depth.
5. `results/final-verification.json` for all 423 unchanged predecessor bindings, 82 request attempts / 80 saved originals, and exact primary source bindings. `REPRODUCE.md` explains historical stage scripts and failures.

## Remaining prerequisites

Independent review of both author packets; full microbial GCD/downstream claim-specific primary evidence where obtainable; structure/charge/stereo and exact issuer identity audit; exact strain/gene/protein resolution; complete native-member/regulatory/catalyst evidence mapping; actual merged265 baseline rebind before any maintained record. The incomplete GO-CAM projection remains rejected and PWY-301 deferred. This is a bounded source-completion result, not blanket pathway acceptance.

## Freeze

__LISTED__ manifested files / __PHYSICAL__ physical files, including hidden/ignored outputs and preserved failures. `artifact-manifest.json` and `freeze-proof.json` are the only manifest exclusions. HANDOFF is manifested; the proof binds its hash and the manifest. No files should be mutated after this freeze.
'''
(O / 'HANDOFF.md').write_text(handoff)
listed = len(files())
(O / 'HANDOFF.md').write_text(handoff.replace('__LISTED__', str(listed)).replace('__PHYSICAL__', str(listed + 2)))
rows = [{'path': str(p.relative_to(O)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files()]
manifest = {'files': rows, 'file_count': len(rows), 'listed_bytes': sum(r['bytes'] for r in rows),
            'exclusions': sorted(excluded), 'inventory_includes_hidden_and_ignored': True}
(O / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
proof = {'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'owner': str(O), 'manifest_sha256': sha(O / 'artifact-manifest.json'),
         'handoff_sha256': sha(O / 'HANDOFF.md'), 'assessment_sha256': sha(O / 'ASSESSMENT.md'),
         'listed_count': len(rows), 'physical_count': len(rows) + 2,
         'listed_bytes': manifest['listed_bytes'], 'self_excluded': 'freeze-proof.json',
         'manifest_excluded': sorted(excluded),
         'disposition': 'Frozen author preparation; no independent acceptance or maintained integration claimed.'}
(O / 'freeze-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
physical = [p for p in O.rglob('*') if p.is_file()]
assert len(physical) == len(rows) + 2
assert {str(p.relative_to(O)) for p in physical} == {r['path'] for r in rows} | excluded
for r in rows:
    p = O / r['path']
    assert sha(p) == r['sha256'] and p.stat().st_size == r['bytes']
print(json.dumps({**proof, 'freeze_sha256': sha(O / 'freeze-proof.json'), 'all_listed_hashes_rechecked': True}, indent=2))
