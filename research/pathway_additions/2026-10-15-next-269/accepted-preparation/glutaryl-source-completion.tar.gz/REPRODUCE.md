# Reproduction and preserved limitations

No installation is required. The author used the existing verified interpreter:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/finalize_ledgers.py
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/primary_claims.py
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/final_verify.py
```

These scripts use absolute author paths and write outputs. **Do not run them against the frozen owner.** Copy the packet to a new owned directory, rebind `O` to that directory, and keep `P` bound to the unchanged frozen initial packet. Reproduction must preserve the originals and existing failed attempts. The initial manifest and final verification bind all 423 predecessor files, including hidden/ignored physical inventory. No live maintained worktree is needed.

`acquire.py`, `acquire_supplements.py` and `acquire_genes.py` are historical acquisition stages, not an instruction to refetch over originals. Their receipts retain actual URLs, times, response outcomes, hashes and sizes. `project.py` is the first 60-object stage: its exact-set assertion deliberately reflects that stage and does not apply after the eleven-gene extension. The final 71-object ledger is produced by `finalize_ledgers.py`. `compact_native.py` reconstructs the explicit nine-slot closure and the broad descendant-reference inventory; its human reading projection excludes listed metadata/inverse/CML slots.

The existing PDFKit executable `/private/tmp/pathwaymech-next-268-primary/read_pdf` rendered the two authentic PDFs into numbered PNG pages and extracted text. Its exact executable hash is recorded in `results/reading-scope.json`. This is an existing scratch tool, not a live repository or environment modification. The main PDF produced a generic CoreGraphics log warning but exited successfully and produced all fourteen pages; the inspected figures and table were readable.

Legacy DOC/XLS files required existing macOS QuickLook previews. Initial LibreOffice conversion exited 134 without PDFs. Automatic textutil treated the large SI DOC as binary text; those derivative outputs are retained and excluded from scientific evidence. Forced DOC extraction reported a format error. Sandboxed QuickLook failed on a path-filter initialization error; the same bounded local preview command was allowed with escalation and wrote only under this scratch owner. No documents were uploaded, packages installed, or runtime repaired. Exact outcomes are in `results/reader-attempts.json`.

The QuickLook workbook display covered all nonblank rendered worksheets and retained blank preview sheets. It is not a workbook hidden-row/formula/BIFF audit. The supplementary figure mapping initially misidentified figures 5–8 due to a caption regex; `results/supplement-image-caption-map-verified.json` supersedes the preserved failed map after document-order and visual checking.

The 1993 DOI PDF endpoint's `.pdf` filename is historical. Magic/content inspection establishes HTML publisher preview. A 200 response does not establish a full article. The initial preview and new response are separately hash-bound and are not byte-identical. No full-main claim is made.

Manifest verification is sufficient to reproduce byte-integrity checks; it does not replace the recorded source reading, exact claim-level interpretation, independent review, chemistry/issuer checks or later merged-baseline rebind.
