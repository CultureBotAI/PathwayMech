# Native publication alias accounting

The 62 mixed identifiers in the frozen initial preparation each map to exactly one of 44 native Publication frames. The mapping uses explicit native frame identifiers and pubmed-id fields from all 91 exact native XML originals. It does not infer equivalence from a title or a numeric-looking frame name. Every source occurrence has its file hash and ordinal locator.

This corrects the count denominator only. Forty-four native frames are not a verified count of distinct bibliographic works, and this is not a claim that all cited papers were read. Issuer metadata, versions, duplicates and each selected claim's primary evidence remain separately reviewable. Source preparation and maintained files were unchanged. Input bindings cover the frozen manifest's finite native-original set, including its complete previously verified file inventory, not a global literature search.
