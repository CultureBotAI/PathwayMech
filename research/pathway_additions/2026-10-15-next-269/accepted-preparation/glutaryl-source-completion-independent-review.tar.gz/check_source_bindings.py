from pathlib import Path
import hashlib,json,re
P=Path(__file__).resolve().parent
S=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ledger=json.loads((S/'results/primary-claim-ledger.json').read_text());bindings=[]
for claim in ledger['claims']:
 for row in claim['sources']:
  assert sha(S/row['path'])==row['sha256']
  bindings.append({'claim':claim['id'],**row})
assert len(ledger['claims'])==16
raw=(S/'originals/BF00250279.pdf').read_bytes()
assert not raw.startswith(b'%PDF') and b'<html' in raw.lower() and b'This is a preview of subscription content' in raw
sheets=[]
for no in [3,4]:
 root=S/f'reading/quicklook/41467_2018_4513_MOESM{no}_ESM.xls.qlpreview'
 for p in sorted(root.glob('Attachment*.html.txt')):
  t=p.read_text();sheets.append({'path':str(p.relative_to(S)),'sha256':sha(p),'characters':len(t),'stripped_characters':len(t.strip()),'content':t if len(t.strip())<200 else 'Full displayed text independently read; not duplicated.'})
assert len(sheets)==6
xls=S/'originals/41467_2018_4513_MOESM4_ESM.xls'
rawxls=xls.read_bytes();phrases=['csiD and lhgO','gdh and pp0159']
# Raw substring corroboration of displayed Use cells, not a BIFF or sequence-alignment audit.
raw_support=[{'phrase':s,'ascii_present':s.encode() in rawxls,'utf16le_present':s.encode('utf-16-le') in rawxls} for s in phrases]
assert all(r['ascii_present'] or r['utf16le_present'] for r in raw_support)
(P/'source-binding-checks.json').write_text(json.dumps({'claims':16,'binding_events':bindings,'unavailable_1993_actual_format':'HTML subscription preview, not PDF/full main','worksheet_previews':sheets,'raw_primer_use_corroboration':raw_support},indent=2)+'\n')
print(json.dumps({'claims':16,'binding_events':len(bindings),'worksheet_previews':6,'1993':'HTML preview','construct_phrase_raw_support':raw_support},indent=2))
