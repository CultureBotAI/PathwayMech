from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
paths=['/private/tmp/pathwaymech-next-269-glutaryl-source-completion','/private/tmp/pathwaymech-next-269-glutaryl-preparation','/private/tmp/pathwaymech-next-269-root-cml-constitution','/private/tmp/pathwaymech-next-269-glutaryl-independent-initial-review']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();out=[]
for name in paths:
 s=Path(name);m=json.loads((s/'artifact-manifest.json').read_text());rows=m['files']
 for r in rows:
  f=s/r['path'];assert f.stat().st_size==r['bytes'] and sha(f)==r['sha256'],str(f)
 actual={str(f.relative_to(s)) for f in s.rglob('*') if f.is_file()}
 assert actual=={r['path'] for r in rows}|{'artifact-manifest.json','freeze-proof.json'}
 out.append({'root':name,'manifest_sha256':sha(s/'artifact-manifest.json'),'listed':len(rows),'physical':len(actual),'all_exact':True,'handoff_sha256':sha(s/'HANDOFF.md')})
initial=json.loads((P/'intake-integrity.json').read_text())
for r in initial:
 n=next(n for n in out if n['root']==r['root']);assert n['manifest_sha256']==r['manifest_sha256'] and n['listed']==r['listed'] and n['physical']==r['physical']
(P/'final-input-integrity.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
