from pathlib import Path
from collections import Counter
from hashlib import sha256
import json, xml.etree.ElementTree as ET
from rdkit import Chem, rdBase
P=Path(__file__).resolve().parent
S=Path('/private/tmp/pathwaymech-next-269-root-cml-constitution')
I=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation/originals')
digest=lambda p:sha256(p.read_bytes()).hexdigest()
m=json.loads((S/'artifact-manifest.json').read_text())
for r in m['files']:
 p=S/r['path'];assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256']
assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
assert len(m['files'])==24
rows=[]
for p in sorted((S/'inputs').glob('*.xml')):
 assert p.read_bytes()==(I/p.name).read_bytes()
 n=ET.parse(p).getroot().find('Compound');c=n.find('cml/molecule');rw=Chem.RWMol();ix={}
 assert not c.findall('.//atomParity') and not c.findall('.//bondStereo')
 for a in c.findall('atomArray/atom'):
  assert a.attrib.keys()<={'id','elementType','formalCharge','x2','y2'}
  atom=Chem.Atom(a.get('elementType'));atom.SetFormalCharge(int(a.get('formalCharge','0')));ix[a.get('id')]=rw.AddAtom(atom)
 for b in c.findall('bondArray/bond'):
  left,right=b.get('atomRefs').split();rw.AddBond(ix[left],ix[right],{1:Chem.BondType.SINGLE,2:Chem.BondType.DOUBLE}[int(b.get('order'))])
 native=rw.GetMol();Chem.SanitizeMol(native)
 issued=Chem.MolFromInchi(n.findtext('inchi'));assert issued is not None
 explicit=Chem.AddHs(native);counts=dict(Counter(a.GetSymbol() for a in explicit.GetAtoms()))
 toks=c.find('formula').get('concise').split();declared=dict(zip(toks[::2],map(int,toks[1::2])))
 assert counts==declared and Chem.GetFormalCharge(native)==int(c.get('formalCharge'))
 molecules=[Chem.RemoveHs(x) for x in (native,issued)]
 for x in molecules:Chem.RemoveStereochemistry(x)
 strict=[Chem.MolToSmiles(x,isomericSmiles=True) for x in molecules]
 normalized=[Chem.MolToInchi(x) for x in molecules]
 rows.append({'id':n.get('frameid'),'sha256':digest(p),'graph_formula':counts,'charge':Chem.GetFormalCharge(native),'strict_no_stereo_smiles':strict,'strict_equal':strict[0]==strict[1],'standard_inchi_no_stereo':normalized,'normalized_equal':normalized[0]==normalized[1]})
assert len(rows)==12 and sum(r['strict_equal'] for r in rows)==3 and all(r['normalized_equal'] for r in rows)
out={'source_manifest_sha256':digest(S/'artifact-manifest.json'),'listed':24,'physical':26,'all_inputs_equal_initial_originals':True,'rdkit_version':rdBase.rdkitVersion,'results':rows,'interpretation':'Twelve graph formulas/charges and standard InChI-normalized stereo-stripped structures agree. Only three strict stereo-stripped graphs agree. Nine strict graph differences are not established identity defects. No proof of stereo, fixed proton positions, public issuer equivalence or biological identity; same RDKit implementation as author, independent script and fresh original parsing.'}
(P/'independent-cml-replay.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS: 24/26 integrity; 12 original inputs; 12 formula/charge; 3 strict no-stereo and 12 normalized no-stereo matches')
