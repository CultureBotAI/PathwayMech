from pathlib import Path
import xml.etree.ElementTree as ET,json,hashlib
from collections import Counter
P=Path(__file__).resolve().parent
A=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
B=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
nodes={};rows=[]
for owner in [A,B]:
 for f in sorted((owner/'originals').glob('META-*.xml')):
  r=ET.parse(f).getroot();top=[x for x in r if x.tag!='metadata'];assert len(top)==1
  n=top[0];i=n.get('frameid');assert i not in nodes
  assert n.get('orgid')=='META' and n.get('ID')=='META:'+i and n.get('detail')=='full'
  assert f.name=='META-'+i+'.xml' and r.findtext('metadata/query')=='META:'+i
  assert r.findtext('metadata/num_results')=='1' and r.find('metadata/PGDB').get('orgid')=='META' and r.get('ptools-version')=='27.0'
  nodes[i]=n;rows.append(dict(frame=i,type=n.tag,owner=str(owner),path=str(f),sha256=sha(f),direct_slots=len(n)))
new=[x for x in rows if x['owner']==str(B)]
assert len(new)==71 and sum(x['direct_slots'] for x in new)==864
assert dict(Counter(x['type'] for x in new))=={'Protein':12,'Gene':25,'Organism':27,'Compound':7}
slots=json.loads((B/'results/native-71-all-direct-slots.json').read_text())
print('slot keys',slots[0].keys())
selected={'gene','component','components','cofactor','prosthetic-group','regulated-by','regulator','enzyme','species'}
links=[]
for i,n in nodes.items():
 for s in n:
  if s.tag not in selected:continue
  for t in s:
   target=t.get('frameid')
   if target:links.append(dict(owner=i,slot=s.tag,target=target,type=t.tag,closed=target in nodes))
assert len(nodes)==162 and len(links)==137 and all(x['closed'] for x in links)
initial=json.loads((A/'results/unacquired-forward-original-prerequisites.json').read_text())
assert len(initial)==70 and len({x['target'] for x in initial})==60
assert {x['target'] for x in initial}<={r['frame'] for r in new}
extra={r['frame'] for r in new}-{x['target'] for x in initial}
assert len(extra)==11 and all(nodes[x].tag=='Gene' for x in extra)
focus={}
for i in ['MONOMER-5381','G-4001','ORG-5962','ORG-5970','G1G01-166','TAX-160488','ACETYL-COA-ACETYLTRANSFER-MONOMER','SELENOMETHIONINE']:
 n=nodes[i];focus[i]={'source':next(x for x in rows if x['frame']==i),'fields':[{'slot':x.tag,'xml':ET.tostring(x,encoding='unicode')} for x in n if x.tag in {'common-name','synonym','comment','dblink','species','gene','product','component','left-end-position','right-end-position','transcription-direction','rank','accession-1','accession-2'}]}
result={'new_originals':new,'total_originals':len(nodes),'new_type_counts':dict(Counter(x['type'] for x in new)),'new_direct_slots':864,'selected_slots':sorted(selected),'selected_occurrences':links,'initial_missing_occurrences':70,'initial_missing_unique_targets':60,'additional_gene_frames':sorted(extra),'focus':focus,'scope':'Only nine direct-slot names; no automatic primary-science or exact cross-resource identity acceptance.'}
(P/'independent-native-closure.json').write_text(json.dumps(result,indent=2)+'\n')
print('pass:162 originals,71 new,864 direct slots,137 closed direct occurrences')
