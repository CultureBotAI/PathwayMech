from pathlib import Path
import urllib.request,datetime,hashlib,json,concurrent.futures
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation'); rows=json.loads((O/'results/forward-native-requests.json').read_text())
def fetch(row):
 frame=row['frame'];url=row['url'];name=f'META-{frame}.xml';r={**row,'path':'originals/'+name,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PathwayMech evidence preparation'}),timeout=35) as resp:
   data=resp.read();r.update(status=resp.status,final_url=resp.url,headers={k:v for k,v in resp.headers.items() if k.lower()!='set-cookie'},bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  with (O/'originals'/name).open('xb') as f:f.write(data)
 except Exception as e:r['error']=repr(e)
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rs=list(ex.map(fetch,rows))
(O/'receipts/forward-native.json').write_text(json.dumps(rs,indent=2)+'\n');print(json.dumps([{'frame':r['frame'],'status':r.get('status'),'bytes':r.get('bytes'),'error':r.get('error')} for r in rs],indent=2))
