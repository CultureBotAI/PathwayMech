from pathlib import Path
import urllib.request,datetime,hashlib,json,concurrent.futures
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation')
frames=['PWY-5177','GLUTARYL-COA-DEHYDROG-RXN','GLUTACONYL-COA-DECARBOXYLASE-RXN','RXN-11667','RXN-11662','ACETYL-COA-ACETYLTRANSFER-RXN']
reqs=[(f'META-{f}.xml',f'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:{f}') for f in frames]
reqs += [(f'EPMC-{p}.json',f'https://www.ebi.ac.uk/europepmc/webservices/rest/search?query=EXT_ID:{p}%20AND%20SRC:MED&format=json&resultType=core') for p in ['8436125','11705404']]
def fetch(item):
 name,url=item;r={'url':url,'path':'originals/'+name,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PathwayMech evidence preparation'}),timeout=35) as resp:
   data=resp.read();r.update(status=resp.status,final_url=resp.url,headers={k:v for k,v in resp.headers.items() if k.lower() not in ['set-cookie']},bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  with (O/'originals'/name).open('xb') as f:f.write(data)
 except Exception as e:r['error']=repr(e)
 r['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rs=list(ex.map(fetch,reqs))
(O/'receipts/initial.json').write_text(json.dumps(rs,indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['url','status','bytes','error'] if k in r} for r in rs],indent=2))
