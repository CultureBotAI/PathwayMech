from pathlib import Path
import xml.etree.ElementTree as E,json,hashlib,collections
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation');R=O/'originals'
order=['GLUTARYL-COA-DEHYDROG-RXN','GLUTACONYL-COA-DECARBOXYLASE-RXN','RXN-11667','RXN-11662','ACETYL-COA-ACETYLTRANSFER-RXN'];reverse={'RXN-11667','ACETYL-COA-ACETYLTRANSFER-RXN'}
rows=[];requests={};net=collections.Counter();slots=[]
for frame in ['PWY-5177']+order:
 p=R/f'META-{frame}.xml';root=E.parse(p).getroot();obj=[x for x in root if x.tag!='metadata'];assert len(obj)==1;obj=obj[0];assert obj.get('frameid')==frame and obj.get('orgid')=='META' and obj.get('detail')=='full';assert root.findtext('metadata/query')=='META:'+frame
 for i,s in enumerate(obj):slots.append({'frame':frame,'slot':s.tag,'index':i+1,'xml':E.tostring(s,encoding='unicode'),'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
 if frame=='PWY-5177':continue
 sides={}
 for side in ['left','right']:
  sides[side]=[]
  for i,s in enumerate(obj.findall(side)):
   mats=[x for x in s if x.get('frameid')];assert len(mats)==1
   x=mats[0];row={'id':x.get('frameid'),'type':x.tag,'coefficient':int(s.findtext('coefficient','1')),'slot':f'{side}[{i+1}]'};sides[side].append(row);requests[x.get('frameid')]={'reason':'selected equation material','tag':x.tag}
   sign=1 if side=='right' else -1
   if frame in reverse:sign=-sign
   net[x.get('frameid')]+=sign*row['coefficient']
 acts=[x.get('frameid') for x in obj.findall('enzymatic-reaction/Enzymatic-Reaction')]
 for x in acts:requests[x]={'reason':'selected member activity','tag':'Enzymatic-Reaction'}
 composites=[x.get('frameid') for x in obj.findall('in-pathway/Reaction')]
 for x in composites:requests[x]={'reason':'owning composite reaction context','tag':'Reaction'}
 constituents=[x.get('frameid') for x in obj.findall('reaction-list/Reaction')]
 for x in constituents:requests[x]={'reason':'constituent reaction context','tag':'Reaction'}
 rows.append({'frame':frame,'source':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_direction':obj.findtext('reaction-direction'),'selected_direction':'R2L' if frame in reverse else 'L2R','common_name':obj.findtext('common-name'),'equation':sides,'activities':acts,'composites':composites,'constituents':constituents,'xrefs':[{x.tag:x.text for x in s} for s in obj.findall('dblink')],'ec':obj.findtext('ec-number')})
(O/'results/six-full-native-direct-slots.json').write_text(json.dumps(slots,indent=2)+'\n')
(O/'results/five-member-equations.json').write_text(json.dumps({'rows':rows,'material_occurrences':sum(len(v) for r in rows for v in r['equation'].values()),'material_ids':sorted({x['id'] for r in rows for v in r['equation'].values() for x in v}),'formal_net_native_ids':{k:v for k,v in net.items() if v},'scope':'Exact native ID cancellation only; not chemical balance or physiological flux.'},indent=2)+'\n')
(O/'results/forward-native-requests.json').write_text(json.dumps([{'frame':k,**v,'url':'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:'+k} for k,v in requests.items()],indent=2)+'\n')
print(json.dumps({'rows':rows,'request_count':len(requests),'request_frames':list(requests),'net':{k:v for k,v in net.items() if v}},indent=2))
