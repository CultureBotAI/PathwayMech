from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,xml.etree.ElementTree as E,collections,re
O=Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
objects=[];slots=[];pubs={};unclosed=[];have={p.stem.removeprefix('META-') for p in (O/'originals').glob('META-*.xml')}
for p in sorted((O/'originals').glob('META-*.xml')):
 root=E.parse(p).getroot();ds=[x for x in root if x.tag!='metadata'];assert len(ds)==1;obj=ds[0];frame=p.stem.removeprefix('META-');assert obj.get('frameid')==frame and obj.get('orgid')=='META' and obj.get('detail')=='full';assert root.findtext('metadata/query')=='META:'+frame;assert root.findtext('metadata/num_results')=='1'
 objects.append({'frame':frame,'type':obj.tag,'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p),'version':root.get('ptools-version'),'label':obj.findtext('common-name'),'direct_slot_count':len(obj)})
 for i,x in enumerate(obj):slots.append({'frame':frame,'slot':x.tag,'global_index':i+1,'xml':E.tostring(x,encoding='unicode')})
 for x in obj.iter('Publication'):
  key=x.findtext('pubmed-id') or x.get('frameid');r=pubs.setdefault(key,{'id':key,'origins':[],'titles':[]});r['origins'].append(frame)
  if x.findtext('title') and x.findtext('title') not in r['titles']:r['titles'].append(x.findtext('title'))
 for slot in ['gene','component','components','cofactor','prosthetic-group','regulated-by','regulator','enzyme','species']:
  for node in obj.findall(slot):
   for x in node:
    target=x.get('frameid')
    if target and target not in have:unclosed.append({'owner':frame,'slot':slot,'target':target,'type':x.tag,'detail_in_owner':x.get('detail'),'disposition':'Separate original not acquired in this bounded source pass; embedded full/low/reference is explicitly distinguished.'})
for rsfile in (O/'receipts').glob('*.json'):
 for r in json.loads(rsfile.read_text()):
  if r.get('status')==200 and 'path' in r:
   p=O/r['path'];assert p.is_file() and sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
def wr(name,x):(O/'results'/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
wr('native-originals-inventory.json',{'objects':objects,'count':len(objects),'types':dict(collections.Counter(x['type'] for x in objects)),'all_exact_request_single_full_object_checks_passed':True,'scope':'Envelope and byte-integrity checks do not constitute independent authority or scientific acceptance.'})
wr('complete-retained-native-direct-slots.json',slots)
wr('native-publication-leads.json',list(pubs.values()))
wr('unacquired-forward-original-prerequisites.json',unclosed)
class R(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.out=[]
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
  if t in ['p','h1','h2','h3','h4','div','section','tr','li']:self.out.append('\n')
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip-=1
 def handle_data(self,s):
  if not self.skip:self.out.append(s)
p=O/'originals/PMID8439237-publisher.html';r=R();r.feed(p.read_text());text='\n'.join(' '.join(s.split()) for s in ''.join(r.out).splitlines() if s.strip());(O/'results/PMID8439237-publisher-text.txt').write_text(text+'\n')
wr('primary-access-classification.json',[{'path':'originals/PMC2698508.html','role':'Full article HTML acquired; complete main text plus all references read; all4figures visually inspected; all3tables read as source text. No PDF/table visual inspection claimed.'},{'path':'originals/PMC2698508.pdf','role':'HTTP200 but not a PDF; failed delivery preserved.','first80':(O/'originals/PMC2698508.pdf').read_bytes()[:80].decode(errors='replace'),'pdf_magic':(O/'originals/PMC2698508.pdf').read_bytes().startswith(b'%PDF')},{'path':'originals/PMID8439237-publisher.html','role':'Publisher body retained; access scope assessed from actual rendered-text extraction, not status code.'}])
newids=['RHEA:20592','RHEA:23972','RHEA:13389','KEGG:R10074','KEGG:R03028','KEGG:R02488','MetaCyc:GLUTARYL-COA-DEHYDROGENASE-RXN','PMID:8439237','PMID:19395484']
hits=[]
for p in sorted((O/'inputs/current265/data/pathways').rglob('*.yaml')):
 s=p.read_text();matched=[id for id in newids if id in s]
 if matched:hits.append({'record':p.name,'ids':matched,'sha256':sha(p)})
wr('additional-alias-baseline-scan.json',{'patterns':newids,'scope':'All265 captured complete YAML texts; exact literal occurrences only, no chemical equivalence or universal alias closure. Full repository must be rebound at next merged baseline.','hits':hits})
print('objects',len(objects),'types',dict(collections.Counter(x['type'] for x in objects)),'slots',len(slots),'publicationIDs',len(pubs),'forwardOriginalPrerequisites',len(unclosed),'newIdHits',hits)
print('PUBLISHER TEXT',text[:16000])
