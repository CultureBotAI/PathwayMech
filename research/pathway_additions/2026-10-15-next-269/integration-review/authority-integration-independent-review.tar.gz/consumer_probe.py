# Exact source used by the maintained integration consumer probe (executed from stdin).
import json
from pathlib import Path
import pathwaymech.identifiers as ids
import pathwaymech.biocyc_glutaryl as native
w=Path.cwd();assert Path(ids.__file__).resolve()==w/'src/pathwaymech/identifiers.py';assert Path(native.__file__).resolve()==w/'src/pathwaymech/biocyc_glutaryl.py'
values={}
for n in ['sources','ontology']:
 p=w/'data/identifier_authorities'/f'{n}.json';snapshot=json.loads(p.read_text());terms=ids._load_authority(p);assert terms==snapshot['terms'];values[n]={'source_owners':len(snapshot['sources']),'terms':len(terms)}
assert values=={'sources':{'source_owners':1323,'terms':3335},'ontology':{'source_owners':5,'terms':2203}}
print(json.dumps({'status':'pass','maintained_imports':[str(Path(ids.__file__).resolve()),str(Path(native.__file__).resolve())],'loaded_authorities':values},indent=2))
