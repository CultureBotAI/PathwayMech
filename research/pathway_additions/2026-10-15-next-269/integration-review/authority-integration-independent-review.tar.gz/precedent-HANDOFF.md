# Independent acceptance of native-source packaging attributes

Accepted without findings for this bounded packaging change:
`research/pathway_additions/2026-10-15-next-268/authority-source-originals/.gitattributes`
SHA256 `e45a7b03da689cb95ab36d3ac17d8d7f44b40ce285e6bf05bbcff8e14f200367`.

The exact reviewed content is a preservation comment followed by `*.xml -text whitespace=-blank-at-eol`. The rule preserves native XML bytes, suppresses only the end-of-line whitespace diagnostic for those files, and does not set `diff` to binary. Git text hunks remain available.

All 65 maintained XML originals and their existing staged bytes match the corresponding hash-bound `clean-native/phenyl268` originals in the frozen independent authority implementation review. The source-provenance manifest hashes also agree. Fresh raw-line counting reproduces 89 upstream trailing-whitespace diagnostics in 34 files. No source trimming or scientific change occurred.

Read-only Git attribute checks cover 35,970 tracked and negative-probe paths. The rule applies only to XML in the authority-source-originals directory tree, including hypothetical nested XML and future XML additions. It does not apply to source code, pathway data, sibling XML, local text files or receipt JSON. The affected XML has `text=unset`, `whitespace=-blank-at-eol`, and `diff=unspecified`; all checked outside paths retain unspecified attributes. A gitignore-independent inventory found this as the only repository `.gitattributes` file at review time.

Eleven tests in an isolated scratch repository passed. Source end-of-line spaces are accepted; source CRLF bytes are retained even when staging with `core.autocrlf=true`. Trailing whitespace in code, data, sibling XML, receipt JSON and ordinary local text is rejected. Conflict markers are rejected both inside the source XML and outside it. Source space-before-tab indentation and blank-at-EOF diagnostics remain active. A separate normal-diff check confirms readable text hunks for source XML.

`check_packaging.py`, stdout/stderr, all source bindings, attribute-scope results and individual probe outputs are retained. The exact scratch Git repository is archived in `scratch-git-evidence.tar.gz`, with every file hash in `scratch-git-inventory.json`; its original directory was moved intact to `/private/tmp/pathwaymech-next-268-source-attributes-git-probe` after the completed run so this packet contains no embedded `.git` directory. The executed script is unchanged. The archived repository intentionally contains malformed test files; they are test fixtures, not source records.

Owner `/root/next268_reaction_review_completion`; change author `/root`. Existing verified Python only; no installs, runtime changes, maintained writes, maintained Git mutations or GitHub actions. Only scratch Git `init`/`add` operations were used, without commits or remotes. All jobs terminal. This acceptance is limited to the exact attribute bytes and source hashes; scientific/code review scopes remain in their immutable prior packets. Parent retains the review and owns final staging/commit/head binding. Replay scripts only from a new copied owner after freeze.
