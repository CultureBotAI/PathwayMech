import hashlib,json,subprocess,tarfile
from pathlib import Path
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015');A=Path('/private/tmp/pathwaymech-next-269-native-authority-implementation');R=Path('/private/tmp/pathwaymech-next-269-native-authority-independent-review');CI=Path('/private/tmp/pathwaymech-next-269-ci');HEAD='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105'
def sha(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):return sha(p.read_bytes())
def dump(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def git(*args):return subprocess.check_output(['git','--no-optional-locks',*args],cwd=W)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','HEAD^{tree}').decode().strip()=='1a0560c741c07fcb7878b1e93d8d38da67b1287c'
state=git('status','--porcelain=v1','--untracked-files=all').decode();(O/'status-before.txt').write_text(state)
# Reuse frozen acceptance only after rebinding every physical byte (including its executed archive).
accept=json.loads((R/'artifact-manifest.json').read_text());physical={str(p.relative_to(R)) for p in R.rglob('*') if p.is_file()};assert physical=={r['path'] for r in accept['files']}|{'artifact-manifest.json','freeze-proof.json'}
for row in accept['files']:assert hashfile(R/row['path'])==row['sha256'] and (R/row['path']).stat().st_size==row['bytes']
assert hashfile(R/'artifact-manifest.json')=='60c68cc4dcf21c3f7e0a6641f29c4315c1abadf2c5cf2d9dea4a5bcbfa557703'
receipt=json.loads((CI/'authority-maintained-integration.json').read_text());inv=json.loads((A/'results/patch-owner-inventory.json').read_text());owners=inv['modified']+inv['added'];assert receipt['exact_reviewed_owners']==owners and len(owners)==152
previous=[];now=[]
for row in owners:
 p=W/row['path'];assert p.read_bytes()==(A/'candidate'/row['path']).read_bytes() and hashfile(p)==row['sha256'] and p.stat().st_size==row['bytes']
 if row['action']=='modify':
  before=git('show',HEAD+':'+row['path']);assert sha(before)==row['before_sha256']==hashfile(A/'baseline'/row['path']);previous.append({'path':row['path'],'sha256':sha(before),'git_blob':git('rev-parse',HEAD+':'+row['path']).decode().strip()})
 else:
  probe=subprocess.run(['git','cat-file','-e',HEAD+':'+row['path']],cwd=W,capture_output=True);assert probe.returncode!=0
 now.append(row)
# The previous source/ontology owners and term order are independently preserved in maintained snapshots.
counts={}
for name in ['sources','ontology']:
 p='data/identifier_authorities/'+name+'.json';old=json.loads(git('show',HEAD+':'+p));new=json.loads((W/p).read_text())
 for section in ['sources','terms']:
  assert list(new[section])[:len(old[section])]==list(old[section]);assert all(v==new[section][k] for k,v in old[section].items())
 counts[name]={'old_sources_exact':len(old['sources']),'old_terms_exact':len(old['terms']),'added_sources':len(new['sources'])-len(old['sources']),'added_terms':len(new['terms'])-len(old['terms'])}
# Exact append, no modifications to prior documentation.
doc=receipt['documentation'];before=git('show',HEAD+':docs/IDENTIFIERS.md');after=(W/doc['path']).read_bytes();fragment=(CI/'identifier-doc-addendum.md').read_bytes()
assert sha(before)==doc['before_sha256'] and sha(after)==doc['after_sha256'] and sha(fragment)==doc['fragment_sha256'];assert after==before+fragment
(O/'identifier-doc-addendum.md').write_bytes(fragment);(O/'documentation.diff').write_bytes(git('diff','--','docs/IDENTIFIERS.md'))
link=W/'research/pathway_additions/2026-10-15-next-269/authority-source-originals/README.md';assert link.is_file()
owner='research/pathway_additions/2026-10-15-next-269/authority-source-originals';oldowner=owner.replace('next-269','next-268');rule=(W/owner/'.gitattributes').read_bytes();precedent=git('show',HEAD+':'+oldowner+'/.gitattributes')
assert rule==precedent==(W/oldowner/'.gitattributes').read_bytes();assert sha(rule)==receipt['scoped_byte_preservation_attributes']['sha256']=='e45a7b03da689cb95ab36d3ac17d8d7f44b40ce285e6bf05bbcff8e14f200367';(O/'reviewed.gitattributes').write_bytes(rule)
xmls=sorted((W/owner).rglob('*.xml'));assert len(xmls)==75
tracked=git('ls-files','-z').decode().split('\0');tracked=[p for p in tracked if p]
negative=[owner+'/future.xml',owner+'/nested/future.xml',owner+'/receipt.json',owner+'/notes.txt','research/pathway_additions/2026-10-15-next-269/outside.xml','data/pathways/negative.xml','src/negative.xml']
paths=sorted(set(tracked+[r['path'] for r in owners]+[str(p.relative_to(W)) for p in xmls]+negative));args=['git','--no-optional-locks','check-attr','-z','--stdin','text','whitespace','diff']
raw=subprocess.run(args,cwd=W,input=('\0'.join(paths)+'\0').encode(),capture_output=True,check=True).stdout;tokens=raw.decode().split('\0');assert tokens[-1]=='';tokens=tokens[:-1];attrs={}
for i in range(0,len(tokens),3):p,k,v=tokens[i:i+3];attrs.setdefault(p,{})[k]=v
for p,a in attrs.items():
 affected=p.startswith((owner+'/',oldowner+'/')) and p.endswith('.xml')
 assert a==({'text':'unset','whitespace':'-blank-at-eol','diff':'unspecified'} if affected else {'text':'unspecified','whitespace':'unspecified','diff':'unspecified'}),(p,a)
# Inventory every attribute owner without ignore filtering; detect unforeseen overrides.
attribute_files=[{'path':str(p.relative_to(W)),'sha256':hashfile(p)} for p in sorted(W.rglob('.gitattributes')) if p.is_file()]
assert {r['path'] for r in attribute_files}=={owner+'/.gitattributes',oldowner+'/.gitattributes'}
ws=[]
for p in xmls:
 lines=[i for i,line in enumerate(p.read_bytes().splitlines(),1) if line.rstrip(b' \t')!=line]
 if lines:ws.append({'path':str(p.relative_to(W)),'lines':lines,'sha256':hashfile(p)})
assert sorted(ws,key=lambda r:r['path'])==sorted(receipt['original_xml_with_trailing_spaces'],key=lambda r:r['path'])
# Rebind the committed previous packaging review without rerunning its 11 scratch Git probes.
archive=W/'research/pathway_additions/2026-10-15-next-268/source-byte-preservation/packaging-correction-evidence.tar.gz';assert archive.read_bytes()==git('show',HEAD+':'+str(archive.relative_to(W)))
with tarfile.open(archive,'r:gz') as t:
 members={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()};m=json.loads(members['independent-review/artifact-manifest.json'])
 for row in m['files']:
  raw=members['independent-review/'+row['path']];assert sha(raw)==row['sha256'] and len(raw)==row['bytes']
 assert members['independent-review/reviewed.gitattributes']==rule and members['owner/.gitattributes']==rule
 for n in ['HANDOFF.md','probe-results.json','freeze-proof.json','artifact-manifest.json']:(O/('precedent-'+n)).write_bytes(members['independent-review/'+n])
 precedence={'path':str(archive.relative_to(W)),'sha256':hashfile(archive),'git_blob':git('rev-parse',HEAD+':'+str(archive.relative_to(W))).decode().strip(),'members':len(members),'review_manifest_sha256':sha(members['independent-review/artifact-manifest.json']),'scratch_tests_reused':11,'scratch_tests_newly_rerun':False}
(O/'root-integration-receipt.json').write_bytes((CI/'authority-maintained-integration.json').read_bytes())
dump('attribute-scope.json',{'attributes':attrs,'attribute_files':attribute_files,'checked_paths':len(paths),'hidden_ignored_inventory_included':True,'retained_xml_count':len(xmls),'trailing_whitespace_files':len(ws),'trailing_whitespace_lines':sum(len(r['lines']) for r in ws),'source_xml_hashes':[{'path':str(p.relative_to(W)),'sha256':hashfile(p),'bytes':p.stat().st_size} for p in xmls]})
dump('integration-check.json',{'status':'pass','baseline_head':HEAD,'baseline_tree':'1a0560c741c07fcb7878b1e93d8d38da67b1287c','accepted_manifest':hashfile(R/'artifact-manifest.json'),'accepted_physical_files_rehashed':len(physical),'root_receipt_sha256':hashfile(CI/'authority-maintained-integration.json'),'exact_reviewed_owners':now,'five_previous_owners_from_actual_commit':previous,'preserved_snapshot_objects_and_order':counts,'documentation':doc,'documentation_exact_append':True,'attributes_sha256':sha(rule),'precedent_packaging':precedence,'scope':'Exact authority integration and two extra files only; record, history, pages, KGX and other in-flight maintained additions excluded.'})
print(json.dumps({'status':'pass','integrated_owners':len(now),'old_owners':len(previous),'xmls':len(xmls),'checked_attribute_paths':len(paths),'source_whitespace_files':len(ws),'source_whitespace_lines':sum(len(r['lines']) for r in ws),'docs_exact_append':True,'precedent_rule_byte_identical':True}))
