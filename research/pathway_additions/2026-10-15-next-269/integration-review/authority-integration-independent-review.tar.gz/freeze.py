import datetime,hashlib,json,subprocess
from pathlib import Path
O=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-269-20261015');CI=Path('/private/tmp/pathwaymech-next-269-ci')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
report=json.loads((O/'integration-check.json').read_text());assert json.loads((O/'check.stdout').read_text())['status']=='pass';assert json.loads((O/'consumer.stdout').read_text())['status']=='pass'
assert not (O/'check.stderr').read_bytes() and not (O/'consumer.stderr').read_bytes()
for r in report['exact_reviewed_owners']:assert sha(W/r['path'])==r['sha256'] and (W/r['path']).stat().st_size==r['bytes']
assert sha(W/'docs/IDENTIFIERS.md')==report['documentation']['after_sha256']
assert sha(W/'research/pathway_additions/2026-10-15-next-269/authority-source-originals/.gitattributes')==report['attributes_sha256']
assert sha(CI/'authority-maintained-integration.json')==report['root_receipt_sha256']
assert (CI/'identifier-doc-addendum.md').read_bytes()==(O/'identifier-doc-addendum.md').read_bytes()
status=subprocess.check_output(['git','--no-optional-locks','status','--porcelain=v1','--untracked-files=all'],cwd=W);(O/'status-after.txt').write_bytes(status)
write('terminal-receipts.json',{'all_jobs_terminal':True,'integration_check_exit_code':0,'maintained_consumer_exit_code':0,'exact_reviewed_owners_rehashed_before_after':152,'docs_and_attribute_bytes_unchanged_before_after':True,'root_receipt_unchanged':True,'no_maintained_writes':True,'no_network_installs_or_git_github_mutations':True,'consumer_result':json.loads((O/'consumer.stdout').read_text()),'logs':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.glob('*.std*'))}})
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['artifact-manifest.json','freeze-proof.json']]
write('artifact-manifest.json',{'scope':'All physical regular files except artifact-manifest.json and freeze-proof.json, hidden/ignored included. Prior packaging probes are reused via exact committed archive binding.','files':files,'listed_files':len(files),'listed_bytes':sum(r['bytes'] for r in files)})
write('freeze-proof.json',{'status':'frozen; all jobs terminal','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'handoff_sha256':sha(O/'HANDOFF.md'),'review_sha256':sha(O/'REVIEW.md'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(r['bytes'] for r in files),'conclusion':'bounded maintained authority integration and extras acceptance; no actionable issue; separate record and publication gates remain open'})
print(json.dumps({'owner':str(O),'manifest':sha(O/'artifact-manifest.json'),'handoff':sha(O/'HANDOFF.md'),'review':sha(O/'REVIEW.md'),'freeze':sha(O/'freeze-proof.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(r['bytes'] for r in files)}))
