import datetime,hashlib,json
from pathlib import Path
O=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
receipt=json.loads((O/'terminal-receipts.json').read_text());receipt['logs']={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in O.glob('*.std*')};receipt['finalize']={'exit_code':0,'result':json.loads((O/'finalize.stdout').read_text())};write('terminal-receipts.json',receipt)
assert (O/'finalize.stderr').read_bytes()==b''
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['artifact-manifest.json','freeze-proof.json']]
write('artifact-manifest.json',{'scope':'All regular physical files except artifact-manifest.json and freeze-proof.json; hidden/ignored included. Complete execution workspaces retained in decoded-and-hashed archive.','files':files,'listed_files':len(files),'listed_bytes':sum(r['bytes'] for r in files)})
write('freeze-proof.json',{'status':'frozen; all jobs terminal','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':sha(O/'artifact-manifest.json'),'review_sha256':sha(O/'REVIEW.md'),'handoff_sha256':sha(O/'HANDOFF.md'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(r['bytes'] for r in files),'author_manifest_sha256':'6dd0c390cfce79b82d2baa99ba3515691859747a46120abcf46794538111b4a2','conclusion':'bounded implementation acceptance; no actionable finding; integration and issues623/624 remain separately open'})
print(json.dumps({'owner':str(O),'manifest':sha(O/'artifact-manifest.json'),'handoff':sha(O/'HANDOFF.md'),'review':sha(O/'REVIEW.md'),'freeze':sha(O/'freeze-proof.json'),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(r['bytes'] for r in files)}))
