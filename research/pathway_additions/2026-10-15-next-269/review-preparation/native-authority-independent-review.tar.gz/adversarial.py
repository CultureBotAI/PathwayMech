import base64,copy,hashlib,itertools,json
from pathlib import Path
from xml.etree import ElementTree as E
from pathwaymech.biocyc_glutaryl import FIELD,KIND,PROFILES,_NATIVE_OBJECT_TAGS,glutaryl_metadata,glutaryl_term,validate_glutaryl_assertions
from pathwaymech.identifiers import _load_authority
from scripts.build_source_identifier_snapshot import build_snapshot
O=Path(__file__).resolve().parent;C=O/'replay/candidate';P=C/'research/pathway_additions/2026-10-15-next-269/authority-source-originals';T=O/'adversarial-tmp';T.mkdir(exist_ok=True)
entries=json.loads((P/'manifest.json').read_text()); originals={}; metas={}; examples={};results=[]
for e in entries:
 raw=(P/'originals'/Path(e['path']).name).read_bytes();ident='MetaCyc:'+e['url'].split('META:')[1];originals[ident]=(e,raw);p=T/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);metas[ident]=glutaryl_metadata(e,T)
 for i,n in enumerate(E.fromstring(raw)[1].iter()):
  if i and n.tag in _NATIVE_OBJECT_TAGS:examples.setdefault(n.tag,(ident,i))
assert set(examples)==_NATIVE_OBJECT_TAGS
identity={'frameid','orgid','ID','resource'}
def consumer(meta):
 p=T/'consumer.json';p.write_text(json.dumps({'version':1,'sources':{'x':meta},'terms':{}}));return _load_authority(p)
def rewritten(ident,root):
 e=copy.deepcopy(originals[ident][0]);raw=E.tostring(root,encoding='utf-8',xml_declaration=True);e['sha256']=hashlib.sha256(raw).hexdigest();(T/e['path']).write_bytes(raw)
 m=copy.deepcopy(metas[ident]);m['sha256']=e['sha256'];n=m[FIELD];n['original_base64']=base64.b64encode(raw).decode();n['root_attributes']=dict(root.attrib);n['metadata_xml']=E.tostring(root[0],encoding='unicode');n['projection']['slots']=[{'ordinal':i,'name':x.tag,'xml':E.tostring(x,encoding='unicode')} for i,x in enumerate(root[1],1)]
 return e,m
for tag,(ident,index) in sorted(examples.items()):
 root=E.fromstring(originals[ident][1]);node=list(root[1].iter())[index];attrs=sorted(identity.intersection(node.attrib));variants=[('remove_'+','.join(subset),subset) for k in range(1,len(attrs)+1) for subset in itertools.combinations(attrs,k)]
 variants += [(x,()) for x in ['both_ID_resource','foreign_org_coherent','foreign_resource_only','unknown_tag_incomplete','empty_frame']]
 for label,subset in variants:
  rt=copy.deepcopy(root);n=list(rt[1].iter())[index]
  if subset:
   for a in subset:del n.attrib[a]
  elif label=='both_ID_resource':n.set('ID','META:'+n.get('frameid'));n.set('resource','getxml?META:'+n.get('frameid'))
  elif label=='foreign_org_coherent':
   n.set('orgid','ECOLI');a='ID' if 'ID' in n.attrib else 'resource';n.set(a,('' if a=='ID' else 'getxml?')+'ECOLI:'+n.get('frameid'))
  elif label=='foreign_resource_only':
   n.attrib.pop('ID',None);n.set('resource','getxml?ECOLI:WRONG')
  elif label=='unknown_tag_incomplete':n.tag='future-native-object';n.attrib.pop('frameid')
  elif label=='empty_frame':n.set('frameid','')
  e,m=rewritten(ident,rt)
  for boundary in ['producer','consumer']:
   try:glutaryl_metadata(e,T) if boundary=='producer' else consumer(m)
   except ValueError as err:
    assert 'embedded' in str(err),(tag,label,boundary,str(err));results.append({'tag':tag,'id':ident,'mutation':label,'boundary':boundary,'outcome':'rejected_by_embedded_semantics','message':str(err)})
   else:raise AssertionError(('ACCEPTED',tag,label,boundary))
  (T/e['path']).write_bytes(originals[ident][1])
# Complete unselected producer/consumer failure, independently constructed.
full=[];good=originals['MetaCyc:FAD'][0]
for tag in ['Compound','Protein','Reaction']:
 ident,index=examples[tag];rt=E.fromstring(originals[ident][1]);n=list(rt[1].iter())[index]
 for a in identity:n.attrib.pop(a,None)
 e,m=rewritten(ident,rt);manifest=T/'manifest.json';manifest.write_text(json.dumps([e]));corpus=T/'selection';corpus.mkdir(exist_ok=True);(corpus/'record.yaml').write_text('id: MetaCyc:NOT-SELECTED\n')
 try:build_snapshot(manifest,corpus,T)
 except ValueError as err:assert 'embedded' in str(err);full.append({'tag':tag,'boundary':'normal_builder_unselected','message':str(err)})
 else:raise AssertionError(('unselected accepted',tag))
 (T/e['path']).write_bytes(originals[ident][1])
# Exact profile preselection includes bare and standard parameter URLs; unrelated tokens do not acquire identity.
base={'url':'','version':'27.0','license':'review probe','sha256':'0'*64};urlrows=[]
for ident in PROFILES:
 frame=ident.split(':',1)[1]
 for host in ['bf2i-artsymbiocyc.insa-lyon.fr','biocyc.org','www.biocyc.org','metacyc.org','www.metacyc.org']:
  for query in ['META:'+frame,'id=META:'+frame,'object=META:'+frame]:
   meta={**base,'url':'https://'+host+'/getxml?'+query}
   try:validate_glutaryl_assertions({'unselected':meta},[])
   except ValueError as err:assert 'typed source' in str(err);urlrows.append({'url':meta['url'],'outcome':'rejected'})
   else:raise AssertionError(('downgrade accepted',meta))
negatives=['https://example.org/getxml?META:PWY-5177','https://biocyc.org/other?META:PWY-5177','https://biocyc.org/getxml?comment=META:PWY-5177','https://biocyc.org/getxml?META:PWY-5177&x=1','https://biocyc.org/getxml?META:PWY-5177-extra','https://biocyc.org/getxml?ECOLI:PWY-5177','https://biocyc.org/getxml?META:UNKNOWN','ftp://biocyc.org/getxml?META:PWY-5177','https://biocyc.org/getxml?x=META:PWY-5177','https://biocyc.org/getxml?META%3APWY-5177','https://biocyc.org/GETXML?META:PWY-5177','https://evilbiocyc.org/getxml?META:PWY-5177']
for url in negatives:validate_glutaryl_assertions({'unselected':{**base,'url':url}},[]);urlrows.append({'url':url,'outcome':'not_misidentified'})
# Full consumers reject override for every selected term, independent of contextual-label policy.
terms=[]
for ident,m in metas.items():
 key,term=glutaryl_term(m,'x');assert key==ident
 for field,value in [('label','review invented label'),('synonyms',['review invented alias']),('entity_type','native_glutaryl_reaction' if term['entity_type']!='native_glutaryl_reaction' else 'native_glutaryl_protein')]:
  changed={**term,field:value};p=T/'term.json';p.write_text(json.dumps({'version':1,'sources':{'x':m},'terms':{ident:changed}}))
  try:_load_authority(p)
  except ValueError as err:assert 'complete glutaryl projection' in str(err);terms.append({'id':ident,'field':field,'outcome':'rejected'})
  else:raise AssertionError(('term override accepted',ident,field))
report={'status':'pass','embedded_tests':results,'normal_builder_unselected':full,'url_boundaries':urlrows,'all49_term_override_tests':terms,'test_scope':'Producer and real snapshot consumer; all body hashes, original base64, root metadata and opaque slot projections recalculated for identity mutations; no incidental checksum failure counted.'}
(O/'adversarial-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'embedded_rejections':len(results),'normal_unselected_builder_rejections':len(full),'recognized_downgrade_rejections':len(urlrows)-len(negatives),'unrelated_url_negatives':len(negatives),'term_override_rejections':len(terms),'status':'pass'}))
