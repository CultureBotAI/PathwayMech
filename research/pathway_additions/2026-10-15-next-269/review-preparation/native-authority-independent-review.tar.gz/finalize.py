import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
O=Path(__file__).resolve().parent;A=Path('/private/tmp/pathwaymech-next-269-native-authority-implementation');W=Path('/private/tmp/pathwaymech-next-269-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
assert json.loads((O/'corpus-consumer.stdout').read_text())=={'records':265,'errors':[]}
assert '386 passed' in (O/'pytest.stdout').read_text() and 'All checks passed!' in (O/'lint.stdout').read_text()
assert json.loads((O/'adversarial.stdout').read_text())['status']=='pass'
for log in ['intake','pytest','source-audit','adversarial','reproduce','corpus-consumer','lint']:assert (O/(log+'.stderr')).read_bytes()==b'',log
r=O/'replay/results/reproduction';out=O/'reproduction-results';out.mkdir()
for n in ['snapshot-preservation.json','taxonomy-source-check.json','taxonomy-selected-statements.json','new-taxonomy-projection.json']:shutil.copy2(r/n,out/n)
rows=[]
for rel in ['replay','pytest-tmp','adversarial-tmp']:
 for p in sorted((O/rel).rglob('*')):
  if p.is_file():rows.append({'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)})
archive=O/'execution-workspaces.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for r in rows:tar.add(O/r['path'],arcname=r['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for m,row in zip(members,rows):
  assert m.name==row['path'] and m.isfile() and m.size==row['bytes'];raw=tar.extractfile(m).read();assert hashlib.sha256(raw).hexdigest()==row['sha256']
write('execution-archive-inventory.json',{'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'decoded_files':len(rows),'decoded_bytes':sum(r['bytes'] for r in rows),'all_members_decoded_and_hashed':True,'files':rows,'purpose':'Lossless retention of complete executed input copy, pytest and independent probe workspaces; no source owner modified.'})
# Delete only our own now-byte-verified redundant working directories, retaining every file losslessly.
for rel in ['replay','pytest-tmp','adversarial-tmp']:shutil.rmtree(O/rel)
manifest=json.loads((A/'artifact-manifest.json').read_text());allfiles={str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()};assert allfiles=={r['path'] for r in manifest['files']}|{'artifact-manifest.json','freeze-proof.json'}
for r in manifest['files']:assert sha(A/r['path'])==r['sha256'] and (A/r['path']).stat().st_size==r['bytes']
assert sha(A/'artifact-manifest.json')=='6dd0c390cfce79b82d2baa99ba3515691859747a46120abcf46794538111b4a2'
intake=json.loads((O/'input-integrity.json').read_text())
for p in (A/'baseline').rglob('*'):
 if p.is_file():assert sha(p)==sha(W/p.relative_to(A/'baseline'))
for row in intake['patch_owners']:
 if row['action']=='add':assert not (W/row['path']).exists()
 else:assert sha(W/row['path'])==row['before_sha256']
state=subprocess.run(['git','--no-optional-locks','status','--porcelain=v1','--untracked-files=all'],cwd=W,text=True,capture_output=True,check=True).stdout
write('terminal-integrity.json',{'all_jobs_terminal':True,'author_files_exact_before_after':len(allfiles),'baseline_files_exact_before_after':823,'maintained_prospective_owners_unchanged':152,'status_after':state,'no_maintained_edits':True,'no_network_installs_or_git_github_mutations':True,'execution_archive_members':len(rows),'execution_archive_bytes':archive.stat().st_size})
write('terminal-receipts.json',{'intake':{'exit_code':0,'listed':2351,'physical':2353},'pytest':{'exit_code':0,'passed':386,'elapsed_seconds':24.28,'scope':['tests/test_glutaryl_authority.py','tests/test_typed_authority_consumer_integrity.py']},'independent_source_audit':{'exit_code':0,'originals':49,'slots':891,'identity_nodes':4656,'reference_only':26},'adversarial':{'exit_code':0,**json.loads((O/'adversarial.stdout').read_text())},'normal_reproduction':{'exit_code':0,'byte_identical_source_and_ontology_snapshots':True},'copied_corpus_consumer':{'exit_code':0,'records':265,'errors':0},'ruff':{'exit_code':0},'logs':{p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in O.glob('*.std*')}})
print(json.dumps({'status':'pass','archive_files':len(rows),'archive_bytes':archive.stat().st_size,'author_files_rehashed':len(allfiles),'maintained_status':state}))
