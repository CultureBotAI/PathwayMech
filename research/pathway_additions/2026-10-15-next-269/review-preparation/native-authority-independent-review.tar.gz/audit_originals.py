import base64,collections,gzip,hashlib,html,json,re
from pathlib import Path
from xml.etree import ElementTree as E
from pathwaymech.biocyc_glutaryl import PROFILES,COMPLEXES,NODE_ROLES,FIELD
O=Path(__file__).resolve().parent; C=O/'replay/candidate'; B=O/'replay/baseline'; P=C/'research/pathway_additions/2026-10-15-next-269/authority-source-originals'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def flat(n):return html.unescape(re.sub('<[^>]+>','', ''.join(n.itertext()))).strip()
new=load(C/'data/identifier_authorities/sources.json');old=load(B/'data/identifier_authorities/sources.json'); bindings=load(P/'source-bindings.json'); refs=load(P/'reference-context-bindings.json'); entries=load(P/'manifest.json'); byid={'MetaCyc:'+r['url'].split('META:')[1]:r for r in entries}; assert len(byid)==49
assert set(byid)==set(PROFILES)==set(new['terms'])-set(old['terms'])
for key in ['sources','terms']:
 assert list(new[key])[:len(old[key])]==list(old[key])
 assert all(json.dumps(v,ensure_ascii=False,indent=2)==json.dumps(new[key][k],ensure_ascii=False,indent=2) for k,v in old[key].items())
profile_total=0;types=collections.Counter();nodes=collections.Counter();identities=0;rows=[]
for b in bindings:
 ident=b['id']; ent=byid[ident]; path=P/'originals'/Path(ent['path']).name; raw=path.read_bytes(); rt=E.fromstring(raw); entity=rt[1]
 assert sha(path)==b['sha256']==ent['sha256'] and len(raw)==b['bytes']; assert entity.get('frameid')==ident.split(':',1)[1] and entity.get('orgid')=='META'
 assert rt.get('ptools-version')=='27.0' and entity.get('detail')=='full' and entity.get('class') is None
 slots=dict(collections.Counter(n.tag for n in entity)); assert slots==b['profile']['slots']==PROFILES[ident]['slots'];assert entity.tag==b['native_type']==PROFILES[ident]['tag']
 profile_total+=len(entity);types[entity.tag]+=1
 receipt=load(P/b['acquisition']['receipt'])[b['acquisition']['array_index']]
 assert receipt['sha256']==sha(path) and receipt['bytes']==len(raw) and receipt['status']==200 and receipt['url']==b['request']==ent['url']==b['acquisition']['url']==receipt['final_url']
 assert receipt['url'].endswith('/getxml?META:'+entity.get('frameid')) and rt.findtext('metadata/query')=='META:'+entity.get('frameid')
 meta=new['sources'][ent['key']];projection=meta[FIELD]['projection']; assert base64.b64decode(meta[FIELD]['original_base64'],validate=True)==raw
 assert projection['slots']==[{'ordinal':i,'name':n.tag,'xml':E.tostring(n,encoding='unicode')} for i,n in enumerate(entity,1)]
 # Independent label flattening agrees with issuer common-name or explicit frame fallback.
 name=entity.find('common-name');label=flat(name) if name is not None else entity.get('frameid');aliases=sorted({flat(n) for n in entity.findall('synonym')}-{label})
 assert projection['label']==new['terms'][ident]['label']==label,(ident,label,projection['label'])
 assert projection['synonyms']==new['terms'][ident]['synonyms']==aliases
 if entity.tag=='Protein':role='native_glutaryl_complex' if ident in COMPLEXES else 'native_glutaryl_protein'
 else:role={'Compound':'native_glutaryl_compound','Reaction':'native_glutaryl_reaction','Enzymatic-Reaction':'native_glutaryl_activity','Pathway':'native_pathway'}[entity.tag]
 assert new['terms'][ident]['entity_type']==role
 for node in entity.iter():
  if any(a in node.attrib for a in ['frameid','orgid','ID','resource']):
   identities+=1;nodes[node.tag]+=1
   assert node.get('frameid') and node.get('orgid')=='META'
   expected='META:'+node.get('frameid');assert (node.get('ID')==expected) != (node.get('resource') in ['#'+expected,'getxml?'+expected])
 # The actual retained source equations, activities and complexes are not relabeled classes.
 if entity.tag=='Reaction':
  for side in ['left','right']:
   expected=[]
   for wrapper in entity.findall(side):
    material=next(n for n in wrapper if n.tag!='coefficient');coeff=wrapper.findtext('coefficient');expected.append({'material':'MetaCyc:'+material.get('frameid'),'native_type':material.tag,'is_class':material.get('class')=='true','coefficient':int(coeff) if coeff is not None else None})
   assert projection['sides'][side]==expected
  assert projection['reaction_direction']==entity.findtext('reaction-direction')
 if entity.tag=='Enzymatic-Reaction':
  for slot in ['enzyme','reaction']:assert projection[slot]=='MetaCyc:'+entity.find(slot)[0].get('frameid')
 rows.append({'id':ident,'sha256':sha(path),'slots':len(entity),'type':entity.tag,'label':label,'receipt':b['acquisition'],'source_key':ent['key']})
assert profile_total==891 and len(rows)==49
refrows=[]
for b in refs:
 p=P/b['path'];rt=E.fromstring(p.read_bytes());assert sha(p)==b['sha256'] and p.stat().st_size==b['bytes'] and b['id']=='MetaCyc:'+rt[1].get('frameid')
 r=load(P/b['acquisition']['receipt'])[b['acquisition']['array_index']];assert r['sha256']==b['sha256'] and r['bytes']==b['bytes'] and r['status']==200 and r['url']==b['acquisition']['url']
 assert b['id'] not in byid and b['id'] not in set(new['terms'])-set(old['terms']) and b['id'] not in PROFILES
 refrows.append({'id':b['id'],'sha256':b['sha256'],'receipt':b['acquisition'],'authority_promoted':False})
assert len(refrows)==26
# Actual complete config append and previous entries/order, not just snapshot equality.
confnew=load(C/'conf/identifier_sources.json');confold=load(B/'conf/identifier_sources.json');assert isinstance(confnew,list)
assert confnew[:len(confold)]==confold and confnew[len(confold):]==entries
onto=load(C/'data/identifier_authorities/ontology.json');prev=load(B/'data/identifier_authorities/ontology.json')
for key in ['sources','terms']:
 assert list(onto[key])[:len(prev[key])]==list(prev[key]) and all(v==onto[key][k] for k,v in prev[key].items())
assert set(onto['terms'])-set(prev['terms'])=={'NCBITaxon:316277','NCBITaxon:43774','NCBITaxon:43775'}
summary={'status':'pass','complete_originals':49,'direct_slots':profile_total,'native_types':dict(types),'embedded_identity_nodes':identities,'identity_tags':dict(nodes),'source_rows':rows,'reference_only_originals':refrows,'old_source_owners_preserved':len(old['sources']),'old_source_terms_preserved':len(old['terms']),'new_source_owners':len(new['sources'])-len(old['sources']),'new_source_terms':len(new['terms'])-len(old['terms']),'old_ontology_owners_preserved':len(prev['sources']),'old_ontology_terms_preserved':len(prev['terms']),'new_taxa':sorted(set(onto['terms'])-set(prev['terms'])),'all_old_objects_and_order_exact':True,'config_prior_entries_and_order_exact':True}
(O/'independent-source-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k not in ['source_rows','reference_only_originals']}))
