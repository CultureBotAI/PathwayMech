import hashlib,json,shutil,subprocess
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-269-native-authority-independent-review'); A=Path('/private/tmp/pathwaymech-next-269-native-authority-implementation'); W=Path('/private/tmp/pathwaymech-next-269-20261015')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(name,value): (O/name).write_text(json.dumps(value,indent=2)+'\n')
m=json.loads((A/'artifact-manifest.json').read_text()); files={r['path']:r for r in m['files']};actual={str(p.relative_to(A)) for p in A.rglob('*') if p.is_file()};assert actual==set(files)|{'artifact-manifest.json','freeze-proof.json'}
for path,row in files.items():
 p=A/path;assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'],path
assert sha(A/'artifact-manifest.json')=='6dd0c390cfce79b82d2baa99ba3515691859747a46120abcf46794538111b4a2'
inv=json.loads((A/'results/patch-owner-inventory.json').read_text()); changes=inv['modified']+inv['added'];assert len(changes)==152
for r in changes:
 assert sha(A/'candidate'/r['path'])==r['sha256'],r['path']
 if r['action']=='modify': assert sha(W/r['path'])==r['before_sha256']==sha(A/'baseline'/r['path'])
 else: assert not (W/r['path']).exists(),r['path']
base={str(p.relative_to(A/'baseline')):sha(p) for p in (A/'baseline').rglob('*') if p.is_file()};assert len(base)==823
for p,h in base.items(): assert sha(W/p)==h,p
state=subprocess.run(['git','--no-optional-locks','status','--porcelain=v1','--untracked-files=all'],cwd=W,text=True,capture_output=True,check=True).stdout
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=W,text=True).strip()
assert head=='7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105' and tree=='1a0560c741c07fcb7878b1e93d8d38da67b1287c'
# Independent immutable input copy: all author inputs retained, replay writes only here.
shutil.copytree(A,O/'replay')
emit('input-integrity.json',{'author':str(A),'manifest_sha256':sha(A/'artifact-manifest.json'),'freeze_sha256':sha(A/'freeze-proof.json'),'handoff_sha256':sha(A/'HANDOFF.md'),'listed_files':len(files),'physical_files':len(actual),'listed_bytes':sum(r['bytes'] for r in files.values()),'all_listed_hashes_pass':True,'exact_physical_inventory_pass':True,'actual_merged_head':head,'actual_merged_tree':tree,'baseline_files_exact':len(base),'patch_owners':changes,'status_before':state,'ignored_hidden_included':True})
print(json.dumps({'listed':len(files),'physical':len(actual),'baseline_files_exact':len(base),'patch_owners':len(changes),'head':head,'status':state}))
