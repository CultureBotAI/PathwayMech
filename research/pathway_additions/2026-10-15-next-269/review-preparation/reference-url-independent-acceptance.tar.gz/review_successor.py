from pathlib import Path
import csv,hashlib,io,json,re,shutil,sys,xml.etree.ElementTree as ET
from lxml import html
import yaml
O=Path('/private/tmp/pathwaymech-next-269-reference-url-independent-acceptance')
S=Path('/private/tmp/pathwaymech-next-269-root-reference-url-correction')
P=Path('/private/tmp/pathwaymech-next-269-record-draft')
V=Path('/private/tmp/pathwaymech-next-269-independent-record-review')
sys.path.insert(0,str(P/'inputs/validation-code/src'))
from pathwaymech.schema import validate_record
from pathwaymech.strict import strict_errors
from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(f,data):(O/'results'/f).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
bindings=[]
for d,digest in [(S,'8b362fe1da6e26f019edcfd8e0d5791f67bb897a1dc933679d95d5144f5d274f'),(P,'52c7eb3f87d86f919400fe7b0e8ffd83e1894b7eb220e17174d5c954c0f8cd8d'),(V,'88e716205c7d6bc8dfc252304c34c633af2dec13d4856aabe1d7d542e0a7092e')]:
 m=d/'artifact-manifest.json';assert sha(m)==digest;records=json.loads(m.read_text())['files']
 for x in records:
  p=d/x['path'];assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
 actual={str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()};assert actual=={x['path'] for x in records}|{'artifact-manifest.json','freeze-proof.json'}
 bindings.append({'owner':str(d),'manifest_sha256':digest,'listed':len(records),'physical':len(actual),'all_members_replayed':True,'hidden_ignored_included':True})
save('whole-packet-bindings.json',bindings)
for src,name in [(S/'draft/data/pathways/glutaryl-coa-degradation.yaml','successor.yaml'),(V/'REVIEW.md','original-REVIEW.md'),(V/'HANDOFF.md','original-HANDOFF.md'),(V/'results/R01-all46-acquired-url-bindings.json','independent-acquired-url-bindings.json'),(S/'artifact-manifest.json','successor-manifest.json'),(V/'artifact-manifest.json','original-review-manifest.json')]:shutil.copyfile(src,O/'inputs'/name)
old=yaml.safe_load((P/'draft/data/pathways/glutaryl-coa-degradation.yaml').read_text());new=yaml.safe_load((O/'inputs/successor.yaml').read_text())
diffs=[]
def diff(a,b,loc=''):
 if type(a)!=type(b):diffs.append({'path':loc,'before':a,'after':b});return
 if isinstance(a,dict):
  assert a.keys()==b.keys(),loc
  for k in a:diff(a[k],b[k],loc+'/'+k)
 elif isinstance(a,list):
  assert len(a)==len(b),loc
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,loc+'/'+str(i))
 elif a!=b:diffs.append({'path':loc,'before':a,'after':b})
diff(old,new);save('exact-record-scalar-diffs.json',diffs)
checks=[]
def check(name,ok,detail=None):checks.append({'check':name,'passed':bool(ok),'detail':detail})
check('exact46 URL scalar changes',len(diffs)==46 and all(re.fullmatch(r'/references/\d+/url',d['path']) for d in diffs))
expected=json.loads((V/'results/R01-all46-acquired-url-bindings.json').read_text());expected={x['reference_id']:x for x in expected}
receipts=json.loads((S/'results/correction.json').read_text())['changes'];receipt_by_id={x['reference_id']:x for x in receipts}
newrefs={x['id']:x for x in new['references']};oldrefs={x['id']:x for x in old['references']}
native_originals={}
for p in (S/'inputs/source').rglob('*.xml'):
 t=ET.parse(p).getroot();n=next(x for x in t if x.get('detail')=='full' and x.get('frameid'));native_originals['MetaCyc:'+n.get('frameid')]=(p,t)
for id,ref in newrefs.items():
 if id not in expected:check(id+' unchanged non-native ref',ref==oldrefs[id]);continue
 ex=expected[id];check(id+' exact acquired URL and digest',ref['url']==ex['requested_url'] and ref['source_sha256']==ex['source_sha256_unchanged'])
 check(id+' only URL metadata changed',{k:v for k,v in ref.items() if k!='url'}=={k:v for k,v in oldrefs[id].items() if k!='url'})
 c=receipt_by_id[id];receipt=json.loads((S/c['receipt']).read_text())[c['array_index']]
 check(id+' successful retained request',receipt['status']==200 and receipt['url']==ref['url'] and receipt['sha256']==ref['source_sha256'])
 p,t=native_originals[id];check(id+' original XML digest unchanged',sha(p)==ref['source_sha256'])
 check(id+' original literal XML base unchanged',t.get('{http://www.w3.org/XML/1998/namespace}base')==oldrefs[id]['url'])
record=validate_record(new);errors=strict_errors([O/'inputs/successor.yaml'],O);check('Python and closed schema',not errors,errors)
page=_record_page(record);(O/'results/reproduced-successor.html').write_text(page)
check('exact successor page reproduction',page==(S/'preview/pathways/glutaryl-coa-degradation.html').read_text())
oldpage=(P/'preview/pathways/glutaryl-coa-degradation.html').read_text();expectedpage=oldpage
for v in sorted(expected.values(),key=lambda v:len(v['old_url']),reverse=True):expectedpage=expectedpage.replace(v['old_url'],v['requested_url'])
check('HTML changes only exact native URLs',page==expectedpage)
doc=html.fromstring(page);links=doc.xpath('//@href');ids=doc.xpath('//*[@id]/@id')
for id,v in expected.items():check(id+' navigation link present',v['requested_url'] in links and v['old_url'] not in links)
check('all local links resolve',all(h[1:] in ids for h in links if h.startswith('#')))
check('all HTML IDs unique',len(ids)==len(set(ids)))
oldsvg=re.findall(r'<svg\b[^>]*class="pathway-network-svg".*?</svg>',oldpage,re.S)
newsvg=re.findall(r'<svg\b[^>]*class="pathway-network-svg".*?</svg>',page,re.S)
check('native SVG exactly unchanged',len(newsvg)==1 and newsvg==oldsvg)
exports=render_kgx([record])
for name,content in exports.items():
 (O/'results'/('reproduced-'+name)).write_text(content)
 check(name+' exact successor KGX reproduction',content==(S/'exports'/name).read_text())
check('KGX node bytes unchanged',exports['nodes.tsv']==(P/'exports/nodes.tsv').read_text())
before=list(csv.DictReader((P/'exports/edges.tsv').open(),delimiter='\t'));after=list(csv.DictReader(io.StringIO(exports['edges.tsv']),delimiter='\t'))
check('KGX preserves80 ordered edges',len(before)==len(after)==80)
seen=set()
for i,(a,b) in enumerate(zip(before,after),1):
 check(f'KGX edge{i} only reference metadata',{k:v for k,v in a.items() if k!='reference_metadata'}=={k:v for k,v in b.items() if k!='reference_metadata'})
 original=json.loads(a['reference_metadata']);actual=json.loads(b['reference_metadata'])
 projected=[newrefs[v['id']] for v in original]
 check(f'KGX edge{i} exact metadata',actual==projected)
 seen.update(v['id'] for v in actual)
check('all46 native URL references retained in KGX',set(expected)<=seen)
save('review-results.json',{'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']],'new_record_sha256':sha(O/'inputs/successor.yaml'),'new_page_sha256':hashlib.sha256(page.encode()).hexdigest(),'scope':'Narrow independent R01 successor acceptance, relying on frozen complete original-record scientific review; no new network or authority-adapter acceptance.'})
print(json.dumps({'checks':len(checks),'failed':[x for x in checks if not x['passed']]}))
