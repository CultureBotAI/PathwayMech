from pathlib import Path
import hashlib,json,datetime
O=Path('/private/tmp/pathwaymech-next-269-reference-url-independent-acceptance')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'freeze-proof.json').exists()
r=json.loads((O/'results/review-results.json').read_text());assert r['passed']==461 and not r['failed']
for owner in json.loads((O/'results/whole-packet-bindings.json').read_text()):
 d=Path(owner['owner']);assert sha(d/'artifact-manifest.json')==owner['manifest_sha256']
 for f in json.loads((d/'artifact-manifest.json').read_text())['files']:
  assert sha(d/f['path'])==f['sha256']
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name not in {'artifact-manifest.json','freeze-proof.json'}]
(O/'artifact-manifest.json').write_text(json.dumps({'scope':'Independent bounded R01 successor acceptance; canonical maintained review pending','self_exclusions':['artifact-manifest.json','freeze-proof.json'],'files':files},indent=2)+'\n')
freeze={'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':str(O),'manifest_sha256':sha(O/'artifact-manifest.json'),'review_sha256':sha(O/'REVIEW.md'),'handoff_sha256':sha(O/'HANDOFF.md'),'target_record_sha256':r['new_record_sha256'],'listed':len(files),'physical':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'checks_passed':461,'disposition':'accepted bounded successor; R01 corrected; maintained integration/fullgates/canonical review pending','all_jobs_terminal':True,'no_further_writes':True}
(O/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n')
assert len([p for p in O.rglob('*') if p.is_file()])==len(files)+2
print(json.dumps({'manifest':freeze['manifest_sha256'],'freeze':sha(O/'freeze-proof.json'),'HANDOFF':freeze['handoff_sha256'],'REVIEW':freeze['review_sha256'],'listed':len(files),'physical':len(files)+2},indent=2))
