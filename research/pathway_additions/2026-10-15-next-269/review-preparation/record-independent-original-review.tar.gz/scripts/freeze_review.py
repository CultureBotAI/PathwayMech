from pathlib import Path
import hashlib,json,datetime
O=Path('/private/tmp/pathwaymech-next-269-independent-record-review')
P=Path('/private/tmp/pathwaymech-next-269-record-draft')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (O/'freeze-proof.json').exists()
m=json.loads((P/'artifact-manifest.json').read_text())
for r in m['files']:
 p=P/r['path'];assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
assert {str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}=={x['path'] for x in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
for f,count in [('native-check-results.json',840),('projection-review.json',1183),('context-check-results.json',72)]:
 result=json.loads((O/'results'/f).read_text());assert result['passed']==count and not result['failed']
finding={'id':'N269-R01','issue':'https://github.com/CultureBotAI/PathwayMech/issues/625','severity':'medium','status':'confirmed_requires_successor','record_sha256':'8b6865f0585b0ec7bd046f8f63f008c969ea7013efc60b8bd04db441440a9f51','affected_url_scalars':46,'exact_original_acquisition_mapping':'results/R01-all46-acquired-url-bindings.json','live_request_scope':'One exact draft HTTP443 link failed with curl52/HTTP000; its retained HTTPS acquisition URL returnedHTTP200/body SHA18ad29bd... identical to original. Not46 live pairs.','requested_fix':'Use46 exact acquired HTTPS request URLs for navigable references only; preserve originalXML/xml:base, allscientific assertions, labels, locators and digests.','authority_implementation_independence':'Not assessed: reviewer authored adapter; separate peer review required/owned elsewhere.'}
(O/'results/findings.json').write_text(json.dumps([finding],indent=2)+'\n')
(O/'results/web-tool-diagnostic.json').write_text(json.dumps({'operation':'web.open exact HTTP443 and HTTPS PWY5177 URLs','outcome':'Tool rewrote bare query to META%3APWY-5177=; inaccessible/invalid-reference result','scope':'Diagnostic only; not evidence that original source or link is absent. Later exact curl requests establish finding.'},indent=2)+'\n')
after={'target_manifest_sha256':sha(P/'artifact-manifest.json'),'target_record_sha256':sha(P/'draft/data/pathways/glutaryl-coa-degradation.yaml'),'all569_target_members_unchanged':True,'own_sessions_terminal':True,'maintained_mutations':False,'full_repository_gates':'not run; parent-directed bounded scratch review','canonical_review':'not saved; actual maintained target and gates pending root integration'}
(O/'results/final-target-recheck.json').write_text(json.dumps(after,indent=2)+'\n')
files=[{'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(O.rglob('*')) if p.is_file() and p.name not in {'artifact-manifest.json','freeze-proof.json'}]
manifest={'scope':'independent bounded original scratch record review with confirmed R01; not canonical maintained review','self_exclusions':['artifact-manifest.json','freeze-proof.json'],'files':files}
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze={'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'owner':str(O),'manifest_sha256':sha(O/'artifact-manifest.json'),'review_sha256':sha(O/'REVIEW.md'),'handoff_sha256':sha(O/'HANDOFF.md'),'listed':len(files),'physical':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'target_record_sha256':after['target_record_sha256'],'checks_passed':2095,'findings':['N269-R01'],'no_further_writes':True}
(O/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n')
for f in files:assert sha(O/f['path'])==f['sha256']
assert len([p for p in O.rglob('*') if p.is_file()])==len(files)+2
print(json.dumps({'manifest':freeze['manifest_sha256'],'freeze':sha(O/'freeze-proof.json'),'HANDOFF':freeze['handoff_sha256'],'REVIEW':freeze['review_sha256'],'listed':len(files),'physical':len(files)+2},indent=2))
