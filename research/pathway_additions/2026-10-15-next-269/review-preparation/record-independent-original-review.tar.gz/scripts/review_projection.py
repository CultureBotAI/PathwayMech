from pathlib import Path
import csv, hashlib, html, io, json, re, sys
from lxml import html as LH
import yaml
P=Path('/private/tmp/pathwaymech-next-269-record-draft')
O=Path('/private/tmp/pathwaymech-next-269-independent-record-review')
sys.path.insert(0,str(P/'inputs/validation-code/src'))
from pathwaymech.schema import validate_record
from pathwaymech.strict import strict_errors
from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx

path=O/'inputs/glutaryl-coa-degradation.yaml'
raw=yaml.safe_load(path.read_text()); record=validate_record(raw)
checks=[]
def check(name,ok,detail=None): checks.append({'check':name,'passed':bool(ok),'detail':detail})
strict=strict_errors([path],O)
check('Python and closed null-free schema',not strict,strict)
page=_record_page(record)
(O/'results/reproduced-record.html').write_text(page)
check('HTML exact deterministic reproduction',page==(P/'preview/pathways/glutaryl-coa-degradation.html').read_text())
doc=LH.fromstring(page)
ids=doc.xpath('//*[@id]/@id'); check('unique HTML IDs',len(ids)==len(set(ids)),len(ids))
broken=[a for a in doc.xpath('//@href') if a.startswith('#') and a[1:] not in ids]
check('all local fragment links resolve',not broken,broken)
visible=LH.fromstring(page)
for n in visible.xpath('//script|//style|//svg|//details'): n.drop_tree()
ordinary=' '.join(visible.text_content().split())
for para in raw['description'].split('\n\n'):
    check('root paragraph visible '+para[:60], ' '.join(html.unescape(para).split()) in ordinary)
prefix=page[:page.index('id="pathway-network"')]
pre=LH.fromstring(prefix+'</body></html>')
for n in pre.xpath('//script|//style|//svg|//details'):n.drop_tree()
before=' '.join(pre.text_content().split())
for para in raw['description'].split('\n\n')[:5]:check('pre-network ordinary scope '+para[:60],' '.join(para.split()) in before)
svg=doc.xpath('//svg[contains(@class,"pathway-network-svg")]')
check('one native biochemical network',len(svg)==1)
svg=svg[0]
native_ids={raw['id']}|{x['id'] for x in raw['participants']+raw['reactions']}
svgids=svg.xpath('.//*[@data-node-id]/@data-node-id')
check('60 native SVG IDs exact',set(svgids)==native_ids and len(svgids)==60)
check('taxa stay table scope without artificial biochemical links',all(t['id'] in ordinary and t['id'] not in svgids for t in raw['taxa']))
links=svg.xpath('.//a[@data-subject and @data-object and @data-predicate]')
check('80 explicit SVG edge occurrences',len(links)==80,len(links))
svg_edge_receipts=[]
for index,e in enumerate(raw['mechanistic_edges'],1):
    hits=[x for x in links if x.get('href')==f'#mechanism-edge-{index}']
    check(e['id']+' exact SVG occurrence',len(hits)==1)
    if hits:
        x=hits[0]; target=x.get('href') or x.get('{http://www.w3.org/1999/xlink}href'); title=' '.join(x.text_content().split())
        check(e['id']+' directional endpoints',x.get('data-subject')==e['subject'] and x.get('data-object')==e['object'],dict(x.attrib))
        check(e['id']+' arrowhead',bool(x.xpath('.//*[@marker-end]')))
        targetnodes=doc.xpath('//*[@id=$id]',id=(target or '')[1:])
        check(e['id']+' evidence table target',len(targetnodes)==1)
        if targetnodes:
            tabletext=' '.join(targetnodes[0].text_content().split())
            check(e['id']+' visible exact description',' '.join(e['description'].split()) in tabletext)
            for ev in e['evidence']:
                check(e['id']+' visible source assertion',' '.join(ev['source_assertion'].split()) in tabletext)
                check(e['id']+' visible locator',' '.join(ev['source_locator'].split()) in tabletext)
        svg_edge_receipts.append({'id':e['id'],'attributes':dict(x.attrib),'target':target})
exports=render_kgx([record]); kgx={}
for name,content in exports.items():
    (O/'results'/('reproduced-'+name)).write_text(content)
    check('exact reproduced KGX '+name,content==(P/'exports'/name).read_text())
    kgx[name]=list(csv.DictReader(io.StringIO(content),delimiter='\t'))
kn=kgx['nodes.tsv']; ke=kgx['edges.tsv']; refs={r['id']:r for r in raw['references']}
check('all 68 KGX declarations exact',{n['id'] for n in kn}==native_ids|{t['id'] for t in raw['taxa']} and len(kn)==68)
check('80 KGX edges',len(ke)==80)
for e in raw['mechanistic_edges']:
    hits=[k for k in ke if k['description']==e['description']]
    check(e['id']+' exact KGX claim',len(hits)==1)
    if hits:
        k=hits[0]
        check(e['id']+' KGX endpoints',k['subject']==e['subject'] and k['object']==e['object'])
        expected_predicate='BFO:0000051' if e['predicate']=='has_part' else 'pathwaymech:'+e['predicate']
        check(e['id']+' KGX predicate',k['predicate']==expected_predicate)
        check(e['id']+' KGX full evidence',json.loads(k['evidence'])==e['evidence'])
        expected=[refs[id] for id in sorted({v['reference_id'] for v in e['evidence']})]
        actual=json.loads(k['reference_metadata'])
        check(e['id']+' KGX complete cited reference metadata',sorted(actual,key=lambda v:v['id'])==expected)
        check(e['id']+' no introduced endpoint qualifier',k['endpoint_qualifiers']=='')
for n in kn:
    if n['id'] in {x['id'] for x in raw['reactions']}|{x['id'] for x in raw['participants'] if x['category']=='molecular_activity'}:
        check(n['id']+' KGX activity type',n['category']=='biolink:MolecularActivity')
    if n['id'].startswith('NCBITaxon:'):check(n['id']+' KGX taxon type',n['category']=='biolink:OrganismTaxon')
for e in raw['mechanistic_edges']:
    check(e['id']+' source-only graph',all(v['reference_id'].startswith('MetaCyc:') for v in e['evidence']))
out={'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']],'svg_edge_receipts':svg_edge_receipts,'page_sha256':hashlib.sha256(page.encode()).hexdigest(),'browser_qa':'not claimed; static lxml/HTML SVG, exact renderer and KGX reproduction'}
(O/'results/projection-review.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checks':len(checks),'failed':out['failed']}))
