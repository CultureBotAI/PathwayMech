from pathlib import Path
import collections, hashlib, html, json, re, shutil, xml.etree.ElementTree as ET
import yaml

O=Path('/private/tmp/pathwaymech-next-269-independent-record-review')
P=Path('/private/tmp/pathwaymech-next-269-record-draft')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, data): (O/'results'/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
manifest=json.loads((P/'artifact-manifest.json').read_text())
assert digest(P/'artifact-manifest.json')=='52c7eb3f87d86f919400fe7b0e8ffd83e1894b7eb220e17174d5c954c0f8cd8d'
actual={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}
expected={x['path'] for x in manifest['files']}|set(manifest['self_exclusions'])
assert actual==expected
for row in manifest['files']:
    p=P/row['path']; assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256'], row
save('whole-author-packet-verification.json',{'manifest_sha256':digest(P/'artifact-manifest.json'),'freeze_sha256':digest(P/'freeze-proof.json'),'listed':len(manifest['files']),'physical':len(actual),'bytes':sum(x['bytes'] for x in manifest['files']),'hidden_ignored_included':True,'all_members_match':True})
recordpath=P/'draft/data/pathways/glutaryl-coa-degradation.yaml'
shutil.copyfile(recordpath,O/'inputs/glutaryl-coa-degradation.yaml')
shutil.copyfile(P/'artifact-manifest.json',O/'inputs/author-artifact-manifest.json')
shutil.copyfile(P/'freeze-proof.json',O/'inputs/author-freeze-proof.json')
r=yaml.safe_load(recordpath.read_text())
refs={x['id']:x for x in r['references']}
originaldir=P/'inputs/design/inputs/native'
originals={next(x.get('frameid') for x in ET.parse(p).getroot() if x.get('detail')=='full' and x.get('frameid')):p for p in originaldir.glob('*.xml')}
trees={k:ET.parse(p).getroot() for k,p in originals.items()}
nodes={k:next(x for x in t if x.get('frameid')==k and x.get('detail')=='full') for k,t in trees.items()}
def plain(s): return re.sub('<[^>]+>','',html.unescape(s or '')).strip()
def directids(n,slot): return [x.attrib['frameid'] for s in n.findall(slot) for x in s if 'frameid' in x.attrib]
def slotdata(n,slot): return [ET.tostring(x,encoding='unicode') for x in n.findall(slot)]
checks=[]
def check(label, ok, detail=None):
    checks.append({'check':label,'passed':bool(ok),'detail':detail})

check('all 162 original native objects present',len(nodes)==162)
declarations=[{'id':r['id'],'label':r['label'],'category':'pathway'}]+r['participants']+r['reactions']
for d in declarations:
    fid=d['id'].split(':',1)[1]; n=nodes[fid]
    label=plain(n.findtext('common-name')) or fid
    check('canonical label '+fid,d['label']==label,{'actual':d['label'],'expected':label})
    category={'Compound':'small_molecule','Reaction':'molecular_activity','Enzymatic-Reaction':'molecular_activity','Pathway':'pathway','Protein':('complex' if n.findall('component') else 'protein')}[n.tag]
    if fid=='FAD':category='cofactor'
    check('native declaration type '+fid,d['category']==category,{'actual':d['category'],'expected':category})
    if d in r['reactions']:
        expected_direction={'REVERSIBLE':'reversible','LEFT-TO-RIGHT':'left_to_right','RIGHT-TO-LEFT':'right_to_left','PHYSIOL-LEFT-TO-RIGHT':'left_to_right','PHYSIOL-RIGHT-TO-LEFT':'right_to_left'}[n.findtext('reaction-direction')]
        check('reaction direction '+fid,d['direction']==expected_direction)
check('ETF objects remain native classes',all(nodes[k].tag=='Protein' and nodes[k].get('class')=='true' for k in ['ETF-Oxidized','ETF-Reduced']))

hash_paths=collections.defaultdict(list)
for x in manifest['files']:hash_paths[x['sha256']].append(x['path'])
reference_replay=[]
for ref in r['references']:
    id=ref['id']; paths=hash_paths.get(ref['source_sha256'],[])
    entry={'reference':ref,'exact_packet_paths':paths}
    if id.startswith('MetaCyc:'):
        fid=id.split(':',1)[1]; t=trees[fid]
        check('reference exact original '+id,digest(originals[fid])==ref['source_sha256'])
        check('reference native version '+id,t.get('ptools-version')=='27.0' and '27.0' in ref['source_version'])
        check('reference URL native xml:base '+id,ref['url']==t.get('{http://www.w3.org/XML/1998/namespace}base'))
        entry['url_role']='literal native xml:base, not asserted acquisition URL'
    elif id.startswith('NCBITaxon:'):
        check('external pinned taxonomy reference '+id,not paths and ref['source_sha256']=='89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d' and ref['source_version']=='NCBI Taxonomy 2026-07-12')
        entry['scope']='External full 14,115,225,600-byte pinned SQLite hash; selected statements retained, not individual URL response bytes.'
    else:check('non-native reference bytes retained '+id,bool(paths))
    reference_replay.append(entry)
save('all59-reference-replay.json',reference_replay)

native=nodes['PWY-5177']; layouts={}
for slot in native.findall('reaction-layout'):
    layouts[slot.find('Reaction').get('frameid')]=slot.findtext('direction')
edge_replay=[]
for e in r['mechanistic_edges']:
    sub=e['subject'].split(':',1)[1]; obj=e['object'].split(':',1)[1]
    p=e['predicate']; ev=e['evidence'][0]; fid=ev['reference_id'].split(':',1)[1]; n=nodes[fid]
    sourceparts=[]
    for i,v in enumerate(e['evidence']):
        loc=v['source_locator']; vfid=v['reference_id'].split(':',1)[1]; vn=nodes[vfid]
        # Semicolon locators describe a direct-slot group; absent optional fields mean unspecified.
        prefix=f"/ptools-xml/{vn.tag}[@frameid='{vfid}']/"
        check(e['id']+f' evidence {i} owner locator',loc.startswith(prefix))
        pieces=loc[len(prefix):].split('; ')
        selected=[]
        for piece in pieces:
            found=vn.findall(piece)
            selected.extend(ET.tostring(s,encoding='unicode') for s in found)
            check(e['id']+f' evidence {i} required locator {piece}',bool(found) or piece in ['reaction-direction','mechanism','citation'])
        check(e['id']+f' evidence {i} structured grammar','quote' not in v and bool(v.get('source_assertion')) and len(v['source_assertion'])<=400)
        sourceparts.append({'evidence':v,'selected_original_slots':selected})
    if p in ['consumes','produces']:
        m=re.search(r'/(left|right)\[(\d+)\]$',ev['source_locator']); side=m.group(1); i=int(m.group(2))
        s=n.findall(side)[i-1]; material=next(x.get('frameid') for x in s if x.get('frameid'))
        coeff=s.findtext('coefficient') or '1'; coeff=str(int(float(coeff)))
        orient='L2R' if fid=='GLUTARYL-COA-DEHYDROGENASE-RXN' else layouts[fid]
        expected_p='consumes' if ((side=='left')==(orient=='L2R')) else 'produces'
        check(e['id']+' exact material, orientation and coefficient',p==expected_p and (sub,obj)==((material,fid) if p=='consumes' else (fid,material)) and f'coefficient: {coeff}.' in e['description'],{'material':material,'side':side,'coefficient':coeff,'route_direction':orient})
    elif p=='has_part':
        slot='component' if n.tag=='Protein' else 'reaction-list'
        check(e['id']+' exact member',sub==fid and obj in directids(n,slot))
        if slot=='component':
            s=next(s for s in n.findall(slot) if obj in [x.get('frameid') for x in s]); coeff=s.findtext('coefficient') or 'unspecified'
            check(e['id']+' component coefficient',f'coefficient: {coeff}.' in e['description'])
    elif p=='precedes':
        s=n.findall('reaction-ordering')[int(re.search(r'\[(\d+)\]$',ev['source_locator']).group(1))-1]
        successor=s.find('Reaction').get('frameid'); predecessors=directids(s,'predecessor-reactions'); check(e['id']+' exact predecessor',successor==obj and predecessors==[sub],{'successor':successor,'predecessors':predecessors})
    elif p in ['catalyzes','enables']:
        check(e['id']+' enzyme exact',directids(n,'enzyme')==[sub])
        check(e['id']+' exact target',directids(n,'reaction')==[obj] if p=='catalyzes' else obj==fid)
        direction=n.findtext('reaction-direction') or 'unspecified'
        check(e['id']+' activity direction qualified',direction in e['description'])
        codes=directids(n,'evidence'); codes=[x for x in codes if x.startswith('EV-')]
        if p=='catalyzes':check(e['id']+' source evidence codes retained',all(x in e['description'] for x in codes))
        species=directids(nodes[sub],'species'); names=[plain(nodes[x].findtext('common-name')) for x in species]
        check(e['id']+' species context',all(name in e['description'] for name in names),names)
    elif p=='has_cofactor':check(e['id']+' FAD exact enzyme cofactor',directids(n,'enzyme')==[sub] and obj in directids(n,'cofactor'))
    elif p=='inhibits':
        check(e['id']+' exact regulated activity',directids(n,'regulator')==[sub] and directids(n,'regulated-entity')==[obj] and n.findtext('mode')=='-')
        mechanism=n.findtext('mechanism') or 'unspecified'; check(e['id']+' mechanism',f'mechanism {mechanism}' in e['description'])
        if n.find('ki') is not None:check(e['id']+' literal source Ki',float(n.findtext('ki'))==120 and n.find('ki').get('units')=='&micro;mole' and '"&micro;mole"' in e['description'])
    else:raise AssertionError(p)
    edge_replay.append({'id':e['id'],'edge':e,'originals':sourceparts})
save('all80-edge-source-replay.json',edge_replay)
save('native-check-results.json',{'record_sha256':digest(recordpath),'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']]})
print(json.dumps({'checks':len(checks),'failed':[x for x in checks if not x['passed']]}))
