from pathlib import Path
import hashlib,json,shutil,xml.etree.ElementTree as ET
from lxml import html
import yaml
O=Path('/private/tmp/pathwaymech-next-269-independent-record-review')
P=Path('/private/tmp/pathwaymech-next-269-record-draft')
R=Path('/private/tmp/pathwaymech-next-269-20261015')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value): (O/'results'/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
dependencies=[]
for directory,expected in [
 ('pathwaymech-next-269-glutaryl-preparation','bce3ac166611cb811b334a57d4780fc1dae7c3670faae676873520a1e84b229b'),
 ('pathwaymech-next-269-glutaryl-source-completion','064e77fe52d9a72510acb39c6693f0da230ee44b986969ee48c34a5de857a6ed'),
 ('pathwaymech-next-269-independent-glutaryl-issuer-review','a8f25883dee855189ca74879e004e1ed1074e4f8443a0770ce5f6c1c8837aad2'),
 ('pathwaymech-next-269-glutaryl-issuer-preparation','1655c5df9624a439ff0384e6b3dbff091612ed6e0663063f70e2730797cebba3')]:
 d=Path('/private/tmp')/directory;m=d/'artifact-manifest.json';assert sha(m)==expected
 inventory=json.loads(m.read_text());actual={str(p.relative_to(d)) for p in d.rglob('*') if p.is_file()}
 for f in inventory['files']:
  p=d/f['path'];assert p.stat().st_size==f['bytes'] and sha(p)==f['sha256'],str(p)
 listed={f['path'] for f in inventory['files']};assert actual-listed=={'artifact-manifest.json','freeze-proof.json'}
 dependencies.append({'owner':str(d),'manifest_sha256':sha(m),'listed':len(listed),'physical':len(actual),'all_files_replayed':True,'hidden_ignored_included':True})
save('earlier-evidence-byte-rebind.json',dependencies)
copies=[]
for rel in ['.claude/skills/review-yaml-record/SKILL.md','docs/record-reviews.md','docs/record-review-profile.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','CLAUDE.md','justfile','conf/record_review.yaml']:
 src=R/rel;dst=O/'inputs/governance'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);copies.append({'path':str(src),'copy':str(dst.relative_to(O)),'sha256':sha(src)})
S=Path('/private/tmp/pathwaymech-next-269-glutaryl-source-completion')
for rel in ['reading/quicklook/41467_2018_4513_MOESM1_ESM.doc.qlpreview/Preview.html.txt','reading/quicklook/41467_2018_4513_MOESM4_ESM.xls.qlpreview/Attachment3.html.txt','reading/peer-review-pdf/complete-text.txt','reading/1993-publisher-preview.txt']:
 src=S/rel;dst=O/'inputs/primary-readings'/Path(rel).parent.name/Path(rel).name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);copies.append({'path':str(src),'copy':str(dst.relative_to(O)),'sha256':sha(src)})
save('additional-input-bindings.json',copies)
extracts=[]
for name,source,locators in [
 ('2009',P/'inputs/primary2009/PMC2698508.html',['abstract1','sec2','sec6','sec7','sec11','sec12','sec13','sec20','sec21','sec22','t1','sec25','sec26','sec27']),
 ('2018',P/'inputs/primary2018-and1993/PMC5974017.html',['Par7','Par20','Par23','Par27','Par29','Par34','Par36','Par37','Par40','Par42','Par43','Par44','Par45'])]:
 d=html.fromstring(source.read_bytes())
 for loc in locators:
  found=d.xpath('//*[@id=$loc]',loc=loc);assert len(found)==1,(name,loc)
  extracts.append({'publication':name,'source':str(source),'source_sha256':sha(source),'locator':'//*[@id="'+loc+'"]','text':' '.join(found[0].text_content().split())})
save('primary-original-extracts.json',extracts)
r=yaml.safe_load((O/'inputs/glutaryl-coa-degradation.yaml').read_text())
checks=[]
def check(name,ok,detail=None):checks.append({'check':name,'passed':bool(ok),'detail':detail})
ts=P/'inputs/taxon-label-correction/results';stmts=json.loads((ts/'nine-taxonomy-statement-sets.json').read_text());disps=json.loads((ts/'all-nine-direct-pathway-taxon-dispositions.json').read_text());meta=json.loads((ts/'taxonomy-release-metadata.json').read_text())
check('taxonomy issuing release exact',any(x['predicate']=='owl:versionInfo' and x['value']=='2026-07-12' for x in meta))
taxreceipts=[]
for d in disps:
 id=d['issuing_id'];rows=stmts[id]
 labels=[x['value'] for x in rows if x['predicate']=='rdfs:label'];rank=[x['object'] for x in rows if x['predicate']=='obo:ncbitaxon#has_rank'];parents=[x['object'] for x in rows if x['predicate']=='rdfs:subClassOf']
 check(id+' issuing selected statements',labels==[d['issuing_label']] and rank==[d['issuing_rank']] and d['issuing_parent'] in parents)
 if id!='NCBITaxon:9606':
  check(id+' record exact canonical label',{'id':id,'label':d['issuing_label']} in r['taxa'])
  check(id+' scope on root and exported edge',d['evidence_description'] in r['description'] and d['evidence_description'] in r['mechanistic_edges'][0]['description'])
 else:check('human direct species explicitly excluded',all(t['id']!=id for t in r['taxa']) and 'native human association' in r['description'])
 taxreceipts.append({'id':id,'native_id':d['native_id'],'labels':labels,'rank':rank,'parents':parents,'native_locator':d['direct_pathway_occurrence']['locator'],'scope':d['evidence_description']})
save('taxonomy-scope-replay.json',{'statements_sha256':sha(ts/'nine-taxonomy-statement-sets.json'),'release_sha256':sha(ts/'taxonomy-release-metadata.json'),'taxa':taxreceipts,'database_hash_scope':'Full external SQLite, 14,115,225,600 bytes, previously whole-hash-verified in independently accepted correction; not rehashed in this bounded record review; selected issuing statements exact and metadata checked. Eight record source_locators locate native XML species associations; taxonomy refs do not claim individual web response bytes.'})
ns={}
for p in (P/'inputs/design/inputs/native').glob('*.xml'):
 n=next(x for x in ET.parse(p).getroot() if x.get('detail')=='full' and x.get('frameid'));ns[n.get('frameid')]=n
activity_dispositions=[]
opposed={'THLCLOS-ENZRXN','ENZRXN-14343','ENZRXN-29247','ENZRXN-19447'}
nonmicrobial={'ENZRXNQT-6870','ENZRXNQT-6800','ENZRXN66-1724','ENZRXN66-3041'}
for fid,n in ns.items():
 if n.tag!='Enzymatic-Reaction':continue
 enzymes=[x.get('frameid') for x in n.findall('enzyme/*')];reactions=[x.get('frameid') for x in n.findall('reaction/*')]
 catalysts=[e['id'] for e in r['mechanistic_edges'] if e['predicate']=='catalyzes' and e['subject']=='MetaCyc:'+enzymes[0] and e['object']=='MetaCyc:'+reactions[0]]
 disposition='source-only generic reaction catalyst' if fid not in opposed|nonmicrobial else ('opposed physiological condensation; no route thiolysis catalyst' if fid in opposed else 'human/plant source context excluded')
 check(fid+' catalyst disposition',bool(catalysts)==(fid not in opposed|nonmicrobial))
 if fid in opposed:check(fid+' opposed source direction',n.findtext('reaction-direction')=='PHYSIOL-LEFT-TO-RIGHT' and reactions==['ACETYL-COA-ACETYLTRANSFER-RXN'])
 activity_dispositions.append({'id':fid,'enzyme':enzymes,'reaction':reactions,'direction':n.findtext('reaction-direction'),'disposition':disposition,'record_edges':catalysts})
check('29 activities accounted',len(activity_dispositions)==29)
regdisps=[]
for fid,n in ns.items():
 if n.tag!='Regulation':continue
 edges=[e['id'] for e in r['mechanistic_edges'] if any(v['reference_id']=='MetaCyc:'+fid for v in e['evidence'])]
 check(fid+' regulation graph scope',bool(edges)==(fid not in {'REG-12707','REG-12708'}))
 regdisps.append({'id':fid,'target':[x.get('frameid') for x in n.findall('regulated-entity/*')],'record_edges':edges,'disposition':'human excluded' if not edges else 'source-only exact activity target'})
check('10 regulations accounted',len(regdisps)==10)
save('all29-activities-and10-regulations.json',{'activities':activity_dispositions,'regulations':regdisps})
allclaims=json.loads((P/'inputs/design/results/all16-corrected-primary-dispositions.json').read_text())
mapping={1:9,2:9,3:9,4:9,5:None,6:None,7:None,8:9,9:None,10:None,11:None,12:9,13:9,14:None,15:10,16:9}
paras=r['description'].split('\n\n')
claim_receipts=[]
for c in allclaims:
 i=int(c['claim_id'].split('P')[-1]);paragraph=mapping[i]
 claim_receipts.append({'claim_id':c['claim_id'],'accepted_source_claim':c['corrected_claim'],'record_description_paragraph_1_based':paragraph,'record_text':paras[paragraph-1] if paragraph else None,'disposition':'bounded narrative support; no primary-derived graph edge' if paragraph else 'unchanged retained research context, not an added record assertion','no_positive_primary_edge':all(all(v['reference_id'].startswith('MetaCyc:') for v in e['evidence']) for e in r['mechanistic_edges'])})
save('all16-primary-claim-placement.json',claim_receipts)
save('context-check-results.json',{'checks':checks,'passed':sum(x['passed'] for x in checks),'failed':[x for x in checks if not x['passed']]})
requests=[]
for owner in [Path('/private/tmp/pathwaymech-next-269-glutaryl-preparation'),S]:
 for receipt in (owner/'receipts').glob('*.json'):
  rows=json.loads(receipt.read_text())
  if isinstance(rows,list):
   for row in rows:
    if isinstance(row,dict) and row.get('status')==200:
     requests.append((receipt,row))
corrections=[]
for ref in r['references']:
 if not ref['id'].startswith('MetaCyc:'):continue
 candidates=[(p,x) for p,x in requests if x.get('sha256')==ref['source_sha256'] and x.get('url','').startswith('https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:')]
 assert candidates,ref['id']
 urls={x['url'] for p,x in candidates};assert len(urls)==1,urls
 url=next(iter(urls));assert url.endswith(ref['id'].replace('MetaCyc:','META:'))
 corrections.append({'reference_id':ref['id'],'target_locator':'references[id='+ref['id']+'].url','old_url':ref['url'],'requested_url':url,'source_sha256_unchanged':ref['source_sha256'],'acquisition_receipts':[{'path':str(p),'sha256':sha(p),'row':x} for p,x in candidates]})
assert len(corrections)==46
save('R01-all46-acquired-url-bindings.json',corrections)
print(json.dumps({'checks':len(checks),'failed':[x for x in checks if not x['passed']]}))
