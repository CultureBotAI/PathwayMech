The frozen glutaryl-CoA degradation draft copies the source XML's literal `http://bf2i-artsymbiocyc.insa-lyon.fr:443/getxml?META:FRAME` base into all 46 native `references[].url` fields. That embedded base is source provenance, but it is not the HTTPS endpoint used to acquire the originals and is unsuitable as the navigable reference link.

Confirmed during independent record review of `data/pathways/glutaryl-coa-degradation.yaml`, draft SHA-256 `8b6865f0585b0ec7bd046f8f63f008c969ea7013efc60b8bd04db441440a9f51`, author-packet manifest `52c7eb3f87d86f919400fe7b0e8ffd83e1894b7eb220e17174d5c954c0f8cd8d`.

All 46 fields share this construction. A direct representative test on 2026-10-16 found:

- `http://bf2i-artsymbiocyc.insa-lyon.fr:443/getxml?META:PWY-5177`: curl exit 52, empty reply, HTTP status 000.
- The acquired `https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:PWY-5177`: HTTP 200; response SHA-256 `18ad29bd6fdc7cc1a11c942bc07a6280064cb221f49ae70f5f344b38916932d0`, exactly matching the retained source original.

This is a bounded reference-link defect, not a claim that all 46 URLs were separately live-tested or that the original source assertions are wrong. The 31 open issues were checked before filing. Issue #518 concerns five different maintained references and does not cover this pending record.

Acceptance:

- Set each of the 46 native reference URLs to its exact successful acquired HTTPS endpoint, verified against the retained acquisition metadata and source digest.
- Preserve every original XML byte, including its literal `xml:base`, and preserve all reference IDs, titles, versions and source hashes.
- Leave the 13 non-native references and all record descriptions, taxa, participants, reactions, edges and scientific evidence unchanged; verify the exact scalar delta in a separate successor packet.
- Regenerate and check the ordinary HTML reference links and KGX reference metadata, then independently review the correction and run the normal integration gates.

Keep the original review and failed-link evidence. Close only after the corrected maintained record lands and the actual merged tree is verified.

<!-- pathwaymech-next269-review:N269-R01 -->
