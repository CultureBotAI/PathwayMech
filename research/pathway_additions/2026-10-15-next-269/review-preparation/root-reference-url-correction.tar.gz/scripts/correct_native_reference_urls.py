"""Make the narrow, receipt-bound N269-R01 record successor in fresh scratch."""

import copy
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

import yaml
from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx
from pathwaymech.schema import validate_record
from pathwaymech.strict import strict_errors


O = Path("/private/tmp/pathwaymech-next-269-root-reference-url-correction")
A = Path("/private/tmp/pathwaymech-next-269-record-draft")
S = Path("/private/tmp/pathwaymech-next-269-glutaryl-preparation")
W = Path("/private/tmp/pathwaymech-next-269-20261015")
R = Path("/private/tmp/pathwaymech-next-269-independent-record-review")
EXPECTED = "8b6865f0585b0ec7bd046f8f63f008c969ea7013efc60b8bd04db441440a9f51"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    O.mkdir(exist_ok=False)
    (O / "inputs").mkdir()
    (O / "results").mkdir()
    bindings = []

    def retain(source, relative):
        data = source.read_bytes()
        dest = O / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            assert dest.read_bytes() == data
        else:
            dest.write_bytes(data)
        bindings.append({"source": str(source), "retained": relative,
                         "bytes": len(data), "sha256": sha(data)})
        return data

    original = retain(A / "draft/data/pathways/glutaryl-coa-degradation.yaml", "inputs/original.yaml")
    assert sha(original) == EXPECTED
    for name in ["artifact-manifest.json", "freeze-proof.json", "HANDOFF.md"]:
        retain(A / name, "inputs/author/" + name)
    for name in ["artifact-manifest.json", "freeze-proof.json"]:
        retain(S / name, "inputs/source/" + name)
    # The two status/diagnostic pairs and successful body suffice for this
    # bounded network observation; do not copy unrelated response headers.
    for name in ["native-http443-confirmation.status", "native-http443-confirmation.stderr",
                 "native-https-confirmation.status", "native-https-confirmation.stderr",
                 "native-https-confirmation.body"]:
        retain(R / "results" / name, "inputs/network/" + name)
    assert sha((O / "inputs/network/native-https-confirmation.body").read_bytes()) == (
        "18ad29bd6fdc7cc1a11c942bc07a6280064cb221f49ae70f5f344b38916932d0"
    )
    receipts = []
    for receipt in sorted((S / "receipts").glob("*.json")):
        for index, row in enumerate(json.loads(receipt.read_text())):
            if row.get("status") == 200 and row.get("sha256"):
                receipts.append((receipt, index, row))
    before = yaml.safe_load(original)
    after = copy.deepcopy(before)
    text = original.decode()
    changes = []
    for index, ref in enumerate(after["references"]):
        if not ref["id"].startswith("MetaCyc:"):
            continue
        matches = [(p, i, r) for p, i, r in receipts
                   if r["sha256"] == ref["source_sha256"]]
        assert matches, ref["id"]
        urls = {r.get("final_url", r["url"]) for _, _, r in matches}
        assert len(urls) == 1, ref["id"]
        new_url = urls.pop()
        frame = ref["id"].split(":", 1)[1]
        assert new_url == "https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?META:" + frame
        receipt, row_index, match = matches[0]
        assert match["url"] == new_url
        body = retain(S / match["path"], "inputs/source/" + match["path"])
        assert sha(body) == ref["source_sha256"] and len(body) == match["bytes"]
        native = ET.fromstring(body)
        old_url = ref["url"]
        assert native.attrib["{http://www.w3.org/XML/1998/namespace}base"] == old_url
        assert old_url == "http://bf2i-artsymbiocyc.insa-lyon.fr:443/getxml?META:" + frame
        old_line, new_line = "  url: " + old_url + "\n", "  url: " + new_url + "\n"
        assert text.count(old_line) == 1
        text = text.replace(old_line, new_line)
        ref["url"] = new_url
        retain(receipt, "inputs/source/receipts/" + receipt.name)
        changes.append({"field": f"references[{index}].url", "reference_id": ref["id"],
                        "before": old_url, "after": new_url, "source_sha256": ref["source_sha256"],
                        "receipt": "inputs/source/receipts/" + receipt.name, "array_index": row_index})
    assert len(changes) == 46 and len(after["references"]) == 59
    assert yaml.safe_load(text) == after
    for key in before:
        if key != "references":
            assert before[key] == after[key]
    for left, right in zip(before["references"], after["references"], strict=True):
        assert {k: v for k, v in left.items() if k != "url"} == {
            k: v for k, v in right.items() if k != "url"
        }
        if not left["id"].startswith("MetaCyc:"):
            assert left == right
    target = O / "draft/data/pathways/glutaryl-coa-degradation.yaml"
    target.parent.mkdir(parents=True)
    target.write_text(text)
    record = validate_record(after)
    errors = strict_errors([target], O / "draft")
    assert not errors, errors
    page = _record_page(record)
    prior_page = retain(A / "preview/pathways/glutaryl-coa-degradation.html", "inputs/original-page.html").decode()
    expected_page = prior_page
    for change in changes:
        expected_page = expected_page.replace(change["before"], change["after"])
        assert 'href="' + change["after"] + '"' in page
        assert 'href="' + change["before"] + '"' not in page
    assert page == expected_page
    preview = O / "preview"
    (preview / "pathways").mkdir(parents=True)
    (preview / "pathways/glutaryl-coa-degradation.html").write_text(page)
    shutil.copytree(W / "src/pathwaymech/assets", preview / "assets")
    shutil.copyfile(W / "pages/style.css", preview / "style.css")
    svg = re.findall(r'<svg\b[^>]*class="pathway-network-svg".*?</svg>', page, flags=re.S)
    assert len(svg) == 1 and svg[0] == (A / "preview/pathway-network.svg").read_text()
    (preview / "pathway-network.svg").write_text(svg[0])
    exports = render_kgx([record])
    (O / "exports").mkdir()
    for name, body in exports.items():
        (O / "exports" / name).write_text(body)
    assert exports["nodes.tsv"] == (A / "exports/nodes.tsv").read_text()
    old_edges = list(csv.DictReader(io.StringIO((A / "exports/edges.tsv").read_text()), delimiter="\t"))
    new_edges = list(csv.DictReader(io.StringIO(exports["edges.tsv"]), delimiter="\t"))
    refs = {r["id"]: r for r in after["references"]}
    used_native = set()
    assert len(old_edges) == len(new_edges) == 80
    for left, right in zip(old_edges, new_edges, strict=True):
        assert {k: v for k, v in left.items() if k != "reference_metadata"} == {
            k: v for k, v in right.items() if k != "reference_metadata"
        }
        for ref in json.loads(right["reference_metadata"]):
            assert ref == refs[ref["id"]]
            if ref["id"].startswith("MetaCyc:"):
                used_native.add(ref["id"])
    assert used_native == {c["reference_id"] for c in changes}
    contracts = []
    for relative in ["src/pathwaymech/cli.py", "src/pathwaymech/kgx.py", "src/pathwaymech/graph_view.py",
                     "src/pathwaymech/schema.py", "src/pathwaymech/strict.py", "src/pathwaymech/schema/pathwaymech.yaml"]:
        body = (W / relative).read_bytes()
        committed = subprocess.check_output(["git", "show", "7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105:" + relative], cwd=W)
        assert body == committed
        contracts.append({"path": relative, "sha256": sha(body)})
    for binding in bindings:
        assert sha(Path(binding["source"]).read_bytes()) == binding["sha256"]
    result = {"checked_utc": datetime.now(timezone.utc).isoformat(), "issue": 625,
              "issue_key": "N269-R01", "before_record_sha256": EXPECTED,
              "after_record_sha256": sha(target.read_bytes()), "changed_url_scalars": 46,
              "other_record_data_unchanged": True, "all_original_inputs_unchanged": True,
              "python_and_closed_schema_pass": True, "page_only_46_url_replacements": True,
              "svg_unchanged": True, "kgx_nodes_unchanged": True,
              "kgx_edges_only_reference_metadata_changed": True,
              "all46_native_reference_urls_preserved_in_kgx": True,
              "page_sha256": sha(page.encode()), "changes": changes,
              "code_baseline": "7dcc4e6586a7c2b8a9c0a3d733e0399e7ba68105", "contracts": contracts,
              "scope": "Root-authored URL-only correction; independent acceptance and maintained integration pending. One representative pair was live-tested by reviewer; all46 acquired URLs are bound to retained successful receipts, not newly re-fetched."}
    (O / "results/correction.json").write_text(json.dumps(result, indent=2) + "\n")
    (O / "results/input-bindings.json").write_text(json.dumps(bindings, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in {"changes", "contracts"}}, indent=2))


if __name__ == "__main__":
    main()
