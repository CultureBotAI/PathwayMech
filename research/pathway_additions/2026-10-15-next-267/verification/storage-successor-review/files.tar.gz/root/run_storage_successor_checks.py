"""Check the saved storage successor without repeating unchanged science tests."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import subprocess
import time

CI = Path('/private/tmp/pathwaymech-next-267-ci')
spec = importlib.util.spec_from_file_location('prior_documentation_checks', CI / 'run_final_documentation_checks.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
ROOT, ENV, PYTHON, BASE = prior.ROOT, prior.ENV, prior.PYTHON, prior.BASE
OUT = Path('/private/tmp/pathwaymech-next-267-checks-storage-successor')


def main():
    assert not OUT.exists(), 'Observe the existing run; never restart on timeout.'
    save = json.loads((CI / 'canonical-storage-successor-save.json').read_text())
    assert save['exit_code'] == 0
    current = prior.inventory()
    original = json.loads((prior.INITIAL / 'tested-core-input-hashes.json').read_text())
    assert all(current.get(p) == digest for p, digest in original.items())
    added = sorted(set(current) - set(original))
    assert all(p.startswith((prior.REPORT, 'reviews/structured/', prior.HISTORY)) for p in added)
    bundles = sorted({str(Path(p).parent) for p in added if p.startswith('reviews/structured/')})
    assert len(bundles) == 3
    for folder in bundles:
        assert (ROOT / folder / 'review.yaml').is_file() and (ROOT / folder / 'review.md').is_file()
    earlier = json.loads((Path('/private/tmp/pathwaymech-next-267-checks-final-documentation') / 'checked-input-hashes.json').read_text())
    removed = sorted(set(earlier) - set(current))
    changed = sorted(p for p in earlier.keys() & current.keys() if earlier[p] != current[p])
    diff_path = prior.REPORT + 'evidence-retention/successor-proof/decoder-exact.diff'
    assert removed == [diff_path], removed
    assert changed == [prior.REPORT + 'README.md', prior.REPORT + 'evidence-retention/artifact-manifest.json'], changed
    correction = json.loads((CI / 'publication-storage-successor-adoption.json').read_text())
    assert correction['all_predecessor_files_recoverable'] and correction['whitespace_policy_unchanged']
    assert prior.sha(ROOT / prior.REPORT / 'README.md') == correction['new_report_sha256']
    assert prior.sha(ROOT / prior.REPORT / 'evidence-retention/artifact-manifest.json') == correction['current_manifest_sha256']
    OUT.mkdir()
    accounting = {'original_tested_files': len(original), 'all_initial_tested_inputs_unchanged': True,
        'explicit_previous_documentation_changes': changed, 'losslessly_stored_previous_path': removed,
        'added_since_initial_tests': added, 'review_bundles': bundles,
        'ignored_and_hidden_included': True, 'storage_successor_receipt_sha256': prior.sha(CI / 'publication-storage-successor-adoption.json')}
    (OUT / 'delta-accounting.json').write_text(json.dumps(accounting, indent=2) + '\n')
    (OUT / 'checked-input-hashes.json').write_text(json.dumps(current, indent=2) + '\n')
    commands = [[PYTHON, '-B', 'scripts/record_review.py', 'check', '--base', BASE],
                [PYTHON, '-B', 'scripts/validate_history.py', 'history'],
                ['uv', 'run', 'pathwaymech-check-docs'],
                ['uv', 'run', 'pathwaymech-deep-research-contract'],
                ['just', 'lint'], ['git', 'diff', '--check']]
    receipts = []
    for i, command in enumerate(commands):
        log = OUT / f'{i + 1:02d}.log'
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        with log.open('w') as stream:
            result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        row = {'command': command, 'started_utc': started, 'elapsed_seconds': round(time.monotonic() - clock, 2),
               'exit_code': result.returncode, 'log_path': str(log), 'log_sha256': prior.sha(log)}
        receipts.append(row)
        (OUT / 'receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        if result.returncode:
            print(log.read_text()[-6000:], flush=True)
            raise SystemExit(result.returncode)
    assert current == prior.inventory()
    (OUT / 'final-input-preservation.json').write_text(json.dumps({'all_unchanged': True,
        'checked_files': len(current), 'review_bundles': bundles,
        'all_initial_29580_tested_inputs_unchanged': True}, indent=2) + '\n')
    print('All six storage-successor checks passed. Actual staged-index proof follows.', flush=True)


if __name__ == '__main__':
    main()
