"""Retain the frozen independent storage review and save it natively once."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import yaml

ROOT = Path('/private/tmp/pathwaymech-next-267-20261015')
CI = Path('/private/tmp/pathwaymech-next-267-ci')
DEST = ROOT / 'research/pathway_additions/2026-10-15-next-267/verification/storage-successor-review'
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    assert not DEST.exists() and not (CI / 'canonical-storage-successor-save.json').exists()
    spec = json.loads((CI / 'storage-review-package-spec.json').read_text())
    folder = Path(spec['folder'])
    assert sha(folder / 'artifact-manifest.json') == spec['manifest_sha256']
    assert sha(folder / spec['freeze_file']) == spec['freeze_sha256']
    assert sha(folder / 'HANDOFF.md') == spec['handoff_sha256']
    manifest = json.loads((folder / 'artifact-manifest.json').read_text())['files']
    sources = {}
    for parent, dirs, files in os.walk(folder, followlinks=False):
        for name in dirs:
            assert not (Path(parent) / name).is_symlink()
        for name in files:
            p = Path(parent) / name
            assert p.is_file() and not p.is_symlink()
            sources['review/' + p.relative_to(folder).as_posix()] = p
    physical = {name.removeprefix('review/') for name in sources}
    assert len(physical) == spec['physical_files']
    assert physical == {row['path'] for row in manifest} | {'artifact-manifest.json', spec['freeze_file']}
    for row in manifest:
        p = folder / row['path']
        assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes']
    draft = folder / spec['review_path']
    assert sha(draft) == spec['review_sha256']
    review = yaml.load(draft.read_text(), Loader=yaml.CSafeLoader)
    assert review['completion'] == 'completed' and review['verdict'] == 'pass_with_limitations'
    assert review['scientific_review'] is False and review['findings'] == []
    assert review['source']['state'] == 'working_tree'
    assert review['source']['git_revision'] == '02bc234143d40e0e825737f27dfdcb5fd358322f'
    assert all(check['status'] == 'passed' for check in review['checks'] if check['required'])
    for row in review['source']['inputs']:
        assert sha(ROOT / row['path']) == row['sha256'], row['path']
    bundle = ROOT / 'reviews/structured' / review['review_id']
    assert not bundle.exists()
    for name in ['storage-review-package-spec.json', 'publication-storage-successor-adoption.json',
                 'persist_storage_successor_review.py', 'run_storage_successor_checks.py',
                 'stage_storage_successor_candidate.py']:
        sources['root/' + name] = CI / name
    DEST.mkdir(parents=True)
    rows = []
    archive = DEST / 'files.tar.gz'
    with archive.open('xb') as target:
        with gzip.GzipFile(fileobj=target, filename='', mode='wb', mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w|') as tar:
                for name, path in sorted(sources.items()):
                    data = path.read_bytes()
                    item = tarfile.TarInfo(name)
                    item.size, item.mode, item.mtime = len(data), 0o644, 0
                    tar.addfile(item, io.BytesIO(data))
                    rows.append({'member': name, 'source': str(path), 'bytes': len(data), 'sha256': sha(path)})
    expected = {row['member']: row for row in rows}
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        assert len(members) == len(expected) and {m.name for m in members} == set(expected)
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            data = tar.extractfile(member).read()
            row = expected[member.name]
            assert data == Path(row['source']).read_bytes()
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert archive.stat().st_size < 100 * 1024 * 1024
    write(DEST / 'source-file-manifest.json', {'files': rows, 'complete_review_directory_including_hidden_ignored': True,
        'archive_sha256': sha(archive), 'scope': 'Complete frozen independent storage review and selected root adoption/save/stage helpers. Saved native review and current final gates follow separately.'})
    (DEST / 'README.md').write_text('''# Independent storage successor review

This archive preserves the complete frozen independent technical review of
issue607's lossless archival-storage correction. Every regular member was read
back against its exact source. The source manifest preserves original locations,
roles, lengths and hashes, including failed reviewer controls and corrections.

The review binds the actual gzip, complete predecessor reconstruction, unchanged
payload/source-map/decoder/scientific inputs, explicit historical review cutoffs,
new report/history lineage and complete failed-stage evidence. Earlier canonical
scientific and technical reviews remain unchanged. This bounded successor is
saved separately with the native structured-review helper. Actual staged checks,
published-head acceptance, remote CI and protected merge are later observations.
''')
    write(DEST / 'artifact-manifest.json', {'files': [{'path': p.name, 'bytes': p.stat().st_size,
        'sha256': sha(p)} for p in sorted(DEST.iterdir())]})
    write(CI / 'storage-review-construction-retention.json', {'archive_members': len(rows),
        'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
        'complete_review_package_preserved': True, 'all_members_read_back': True,
        'all_review_input_hashes_current_before_save': True})
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
               PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT))
    command = [PYTHON, '-B', 'scripts/record_review.py', 'save', '--content', str(draft)]
    result = subprocess.run(command, cwd=ROOT, env=env, text=True, capture_output=True)
    receipt = {'utc': datetime.now(timezone.utc).isoformat(), 'command': command, 'exit_code': result.returncode,
               'stdout': result.stdout, 'stderr': result.stderr, 'bundle': str(bundle.relative_to(ROOT))}
    if result.returncode == 0:
        assert yaml.load((bundle / 'review.yaml').read_text(), Loader=yaml.CSafeLoader) == review
        assert (bundle / 'review.md').read_bytes() == (folder / spec['rendered_path']).read_bytes()
        receipt['files'] = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)}
                            for p in sorted(bundle.iterdir())]
    write(CI / 'canonical-storage-successor-save.json', receipt)
    print(json.dumps(receipt), flush=True)
    assert result.returncode == 0, result.stderr


if __name__ == '__main__':
    main()
