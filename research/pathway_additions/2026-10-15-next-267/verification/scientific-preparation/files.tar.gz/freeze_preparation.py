import datetime, hashlib, json, os
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
excluded={'artifact-manifest.json','freeze.json'}
rows=[]
for directory,dirs,files in os.walk(O):
    dirs.sort()
    for name in sorted(files):
        p=Path(directory)/name;rel=str(p.relative_to(O))
        if rel in excluded: continue
        assert not p.is_symlink(), rel
        b=p.read_bytes();rows.append(dict(path=rel,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
rows.sort(key=lambda x:x['path'])
manifest=dict(schema_version='1.0.0',scope='Complete frozen external maintained scientific review preparation; hidden and ignored files included. Manifest and freeze receipt excluded from self-hash.',files=rows)
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
h=hashlib.sha256((O/'artifact-manifest.json').read_bytes()).hexdigest()
freeze=dict(frozen_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_sha256=h,manifested_files=len(rows),physical_files=len(rows)+2,completion='partial',new_scientific_findings=0,canonical_bundle_saved=False,all_preceding_writers_terminal=True,continuation='Use a separate final-scientific-review extension for adopted retention/report and remaining native gate bindings; preserve this pending original draft.')
(O/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps(freeze))
