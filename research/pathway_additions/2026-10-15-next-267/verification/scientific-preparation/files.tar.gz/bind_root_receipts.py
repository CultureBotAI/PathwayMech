import datetime, hashlib, json
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
C=Path('/private/tmp/pathwaymech-next-267-ci')
def bind(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
k=json.loads((C/'kgx-record-fidelity.json').read_bytes())
assert len(k['record_edges_checked'])==100 and all(x['complete_claim_equal'] for x in k['record_edges_checked'])
assert len(k['named_contexts_checked'])==80 and all(x['complete_context_equal'] for x in k['named_contexts_checked'])
assert k['actual_cli_exports_equal_generated_downloads'] and k['all_prior_edge_rows_exact']==13689
for x in k['outputs']: assert bind(Path(x['path']))['sha256']==x['sha256']
b=json.loads((C/'browser-maintained/browser-cdp-result.json').read_bytes())
v=json.loads((C/'browser-maintained-visual-assessment.json').read_bytes())
assert not b['runtime_errors'] and b['page_sha256']==v['page_sha256']=='023a4d76d157dc058becdfaca6e1b25dfae33140c89214987d8d25ca8b05c730'
for x in v['observed_captures']: assert bind(Path(x['path']))['sha256']==x['sha256']
assert v['actual_graph']=={'graph-edge':100,'graph-edge-context':27,'graph-edge-mechanism':73}
paths=[C/'kgx-record-fidelity.json',C/'browser-maintained/browser-cdp-result.json',C/'browser-maintained-visual-assessment.json',C/'render-pages-receipt.json',Path('/private/tmp/pathwaymech-next-267-vendored-check/receipt.json')]+[Path(x['path']) for x in v['observed_captures']]
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs=[bind(p) for p in paths],kgx='Parsed every row of root exact comparisons; verified both output hashes. 100 edges/80 local node contexts and 13,689 baseline edge rows preserved. This is receipt intake, not fabricated rerunning of root native export.',browser='Parsed actual browser measurements and corrected context count; personally viewed all three exact screenshots with view_image. Dense 15% overview; selected reaction at 100% is readable. Desktop/mobile graph is contained by scrolling viewport. No cross-browser/accessibility audit.',visual_scope='Direct inspection of root-captured screenshots of the actual maintained page; interactive automation and runtime-error measurements are root-owned.',vendor='Read native terminal-zero receipt; no redundant full vendor rerun.')
(O/'root-receipt-intake.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='pass',receipts=len(paths),screenshots_viewed=3)))
