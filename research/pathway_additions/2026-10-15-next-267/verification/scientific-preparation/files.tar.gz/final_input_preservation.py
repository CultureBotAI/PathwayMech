import datetime, hashlib, json, shutil, tarfile
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
checks=[]
def check(n,ok):
    checks.append(dict(check=n,passed=bool(ok)))
    assert ok,n
for x in read(O/'rendering-inspect.json')['source']['inputs']:
    check('Native source input unchanged '+x['path'],sha((W/x['path']).read_bytes())==x['sha256'])
owners=[('pathwaymech-next-267-design','71222f9a28c44d0a15f65b0657f0ddf4dc80c19be64a94dc763e06c7a7eebf6d'),('pathwaymech-next-267-design-successor','b59dd6959c89dbc36890c942ba09cc14dd7f1fe83bc3dd2c3219bc6435dffdae'),('pathwaymech-next-267-independent-full-design-review','4923b1747cdadc8c880bd9a2429c84e5e767873c69e2c29859b45e2cdf5de74e'),('pathwaymech-next-267-independent-design-successor-review','80b0ef1c4a24202a8276482fc823439b4f46238426f2c7517940175d304a26a1')]
counts=[]
for name,h in owners:
    root=Path('/private/tmp')/name; manifest=root/'artifact-manifest.json'
    check('Owner manifest '+name,sha(manifest.read_bytes())==h)
    for x in read(manifest)['files']:
        p=root/x['path'];b=p.read_bytes();check('Owner body '+str(p),len(b)==x['bytes'] and sha(b)==x['sha256'])
    counts.append(dict(owner=str(root),manifest_sha256=h,manifested_files=len(read(manifest)['files'])))
archives={}
for x in read(O/'all-64-maintained-reference-bindings.json'):
    s=x['source']
    if 'archive' in s:
        ap=Path(s['archive']['path'])
        if str(ap) not in archives:
            check('Original archive '+str(ap),sha(ap.read_bytes())==s['archive']['sha256'])
            archives[str(ap)]=tarfile.open(ap)
        b=archives[str(ap)].extractfile(s['member']).read()
    else:b=Path(s['path']).read_bytes()
    check('Current original source '+x['reference_id'],len(b)==s['bytes'] and sha(b)==s['sha256'])
for a in archives.values():a.close()
rr=O/'root-receipts';rr.mkdir(exist_ok=False)
copies=[]
for x in read(O/'root-receipt-intake.json')['inputs']:
    p=Path(x['path']);b=p.read_bytes();check('Root receipt unchanged '+str(p),sha(b)==x['sha256'])
    destination=rr/p.name;check('Distinct root receipt filename '+p.name,not destination.exists());destination.write_bytes(b)
    copies.append(dict(original=str(p),retained_relative=str(destination.relative_to(O)),sha256=sha(b)))
cor=read(O/'research-wording-correction-acceptance.json')
for filename,h in [('research-report-draft.before-purification-wording.md',cor['before']),('research-report-draft.md',cor['after'])]:
    p=Path('/private/tmp/pathwaymech-next-267-ci')/filename;b=p.read_bytes();check('Explicitly reviewed report revision '+filename,sha(b)==h)
    (rr/filename).write_bytes(b);copies.append(dict(original=str(p),retained_relative=str((rr/filename).relative_to(O)),sha256=h))
out=dict(finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='pass',checks=checks,check_count=len(checks),native_inputs_unchanged=30,upstream_owners=counts,reference_originals_rebound=64,root_receipt_copies=copies,known_change='External research report changed once from 865b2713... to be7a4931... with the independently accepted exact shorter-purification wording; both revisions retained, no silent hash refresh.',scope='Maintained 30 inspected input files, four prior scientific owners, all 64 record reference originals and terminal root receipts preserved. Entire external environment, runtime filesystem and later root source retention are not claimed covered by this bounded preservation check. No live old266 worktree reads.')
(O/'final-input-preservation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='pass',checks=len(checks),native_inputs=30,source_originals=64,root_receipt_copies=len(copies))))
