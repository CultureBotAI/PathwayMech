import datetime, hashlib, json, subprocess, sys
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
old=json.loads((O/'extended-inspect.json').read_bytes())
checks=[]
for x in old['source']['inputs']:
    h=hashlib.sha256((W/x['path']).read_bytes()).hexdigest()
    checks.append(dict(path=x['path'],before=x['sha256'],after=h,unchanged=h==x['sha256']))
    assert h==x['sha256'], x['path']
extra=['src/pathwaymech/cli.py','src/pathwaymech/site_display.py','pages/style.css','pages/assets/pathway-network.css','pages/assets/pathway-network.js']
args=[sys.executable,'-B','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for n in [x['path'] for x in old['source']['inputs'] if x['role']!='target']+extra: args+=['--input',n]
r=subprocess.run(args,cwd=W,capture_output=True)
(O/'rendering-inspect.json').write_bytes(r.stdout)
(O/'rendering-inspect.stderr.txt').write_bytes(r.stderr)
(O/'rendering-inspect-receipt.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=args,exit_code=r.returncode,previous_input_rechecks=checks,new_inputs=extra,scope='Native page generator sections directly read. Existing style/script bytes bound to root browser receipts and three screenshots personally inspected; no independent full implementation audit of these assets.'),indent=2)+'\n')
assert r.returncode==0
print(json.dumps(dict(status='pass',previous_unchanged=len(checks),new_inputs=len(extra))))
