import hashlib,json,os,subprocess,datetime
from pathlib import Path
import yaml
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation');W=Path('/private/tmp/pathwaymech-next-267-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
receipt=json.loads(Path('/private/tmp/pathwaymech-next-267-ci/maintained-record-integration.json').read_bytes());old=receipt['all263_previous_record_bytes_preserved'];prior=[]
for x in old:
 b=(W/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];prior.append({'path':x['path'],'sha256':sha(b)})
records=[]
for top,dirs,files in os.walk(W/'data/pathways'):
 for name in files:
  if name.endswith('.yaml'):
   p=Path(top)/name;b=p.read_bytes();r=yaml.safe_load(b);records.append({'path':str(p.relative_to(W)),'id':r['id'],'label':r['label'],'sha256':sha(b)})
selected=[x for x in records if x['id']=='MetaCyc:P321-PWY'];assert len(records)==264 and len(selected)==1
reviews=[]
for top,dirs,files in os.walk(W/'reviews/structured'):
 for name in files:
  if name!='review.yaml':continue
  p=Path(top)/name;b=p.read_bytes();r=yaml.safe_load(b)
  if any(t['target_id']=='MetaCyc:P321-PWY' or t['path']=='data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml' for t in r.get('targets',[])):reviews.append({'path':str(p.relative_to(W)),'review_id':r['review_id'],'sha256':sha(b)})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pathway_inventory':records,'maintained_records':len(records),'selected':selected,'prior263_exact_bytes_unchanged':prior,'prior_canonical_reviews_of_exact_target':reviews,'search_scope':'Complete os.walk of actual data/pathways and reviews/structured, including hidden and ignored files; no global repository or literature absence claim. The source-context global discovery is explicitly inherited from separately bound prior full-design review.'}
(O/'maintained-scope-and-lineage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'maintained':len(records),'exact_target':len(selected),'old_unchanged':len(prior),'prior_target_reviews':len(reviews)}))
