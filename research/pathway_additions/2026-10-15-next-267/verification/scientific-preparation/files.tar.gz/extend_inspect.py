import datetime,hashlib,json,subprocess,sys
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation');W=Path('/private/tmp/pathwaymech-next-267-20261015')
initial=json.loads((O/'initial-inspect.json').read_bytes());prior=initial['source']['inputs'];checks=[]
for x in prior:
 observed=hashlib.sha256((W/x['path']).read_bytes()).hexdigest();checks.append({'path':x['path'],'before':x['sha256'],'after':observed,'unchanged':observed==x['sha256']});assert observed==x['sha256']
extra=['conf/identifier_policy.yaml','conf/identifier_sources.json','conf/rhea_identifier_updates.json','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json','pages/records/MetaCyc_P321-PWY.html','src/pathwaymech/render.py']
# Discover the generator from the actual local source tree before naming an unavailable path.
extra=[x for x in extra if (W/x).is_file()]
args=[sys.executable,'-B','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for name in [x['path'] for x in prior if x['role']!='target']+extra:args.extend(['--input',name])
r=subprocess.run(args,cwd=W,capture_output=True);(O/'extended-inspect.json').write_bytes(r.stdout);(O/'extended-inspect.stderr.txt').write_bytes(r.stderr)
(O/'inspect-extension-receipt.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':args,'exit_code':r.returncode,'initial_input_rechecks':checks,'new_context_inputs':extra,'reason':'Actual page now generated and adopted authority owners available; reviewed before assessing these new input surfaces. No previous hash silently refreshed.'},indent=2)+'\n')
assert r.returncode==0
print(json.dumps({'status':'pass','initial_unchanged':len(checks),'new_context_inputs':len(extra)}))
