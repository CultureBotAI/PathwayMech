# Scientific review preparation: benzoyl-CoA degradation III (anaerobic)

- Review: 20261015T202656Z-benzoyl-coa-iii-scientific-preparation
- Repository: CultureBotAI/PathwayMech
- Started UTC: 2026-10-15T20:11:06Z
- Finished UTC: 2026-10-15T20:26:56Z
- Reviewer: /root/next267_regulatory_acceptance (independent)
- Completion: partial
- Verdict: pass_with_limitations
- Scientific review: true

## Summary

The entire actual maintained P321 record has a supported bounded scientific assessment: all 80 identities, 100 edges, 196 evidence items, 64 references, nine native reactions and separate auxiliary chemistry retain their source and assay limitations. No new actionable scientific defect was found. This external draft remains partial until final native gate receipts and maintained retention/report adoption are rebound; no canonical persistence or publication approval is implied.

## Scope And Provenance

One complete actual maintained pathway record, every declared identity, edge, endpoint qualifier and reference, actual render/export contexts, and exact explicitly reused independent source assessments.

Selection: Root-assigned new maintained MetaCyc:P321-PWY record adopted from accepted correction successor SHA256 40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51.
Coverage: full; 1 reviewed / 1 in the declared population.
Source: working_tree at Git base 02bc234143d40e0e825737f27dfdcb5fd358322f.
Working-tree hashes do not imply those bytes were committed.

| Target | Path / selector | Kind | Label |
| --- | --- | --- | --- |
| MetaCyc:P321-PWY | data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml | maintained | benzoyl-CoA degradation III (anaerobic) |

## Validation

| Check | Status | Required | Targets | Result |
| --- | --- | --- | --- | --- |
| Complete actual maintained scientific replay | passed | True | MetaCyc:P321-PWY | 1,658 assertions; complete target/source/authority/page coverage. |
| Actual maintained population and prior-review inventory | passed | True | MetaCyc:P321-PWY | 264 records; 263 previous bytes unchanged; exact one target; no earlier canonical target review within complete hidden/ignored-inclusive inventory. |
| Required structured iModulonDB catalog route | passed | True | MetaCyc:P321-PWY | Existing CLAW runner successfully returned complete available dataset catalog. |
| Organism search and module summarization | not_applicable | True | MetaCyc:P321-PWY | No selected native organism has a dataset in returned catalog; no unsupported host-based substitution. |
| Actual native render-pages | passed | True | MetaCyc:P321-PWY | Root terminal-zero receipt: all 264 records rendered. Actual target page freshly checked. |
| Native KGX export fidelity | passed | True | MetaCyc:P321-PWY | Root export receipt fully parsed and output hashes rebound: all 100 new edges/80 contexts, every qualifier, 13,689 previous edge rows preserved. |
| Actual desktop/mobile page smoke check | passed | True | MetaCyc:P321-PWY | Root browser measurements and reviewer direct view of all three captured screenshots support bounded visual acceptance. |
| Native vendored gate | passed | True | MetaCyc:P321-PWY | Root native terminal-zero receipt binds 22 artifacts to canonical pin a5d562962c75a2ad9efd8160b548df5944315422. |
| Required full corpus just validate | passed | True | MetaCyc:P321-PWY | Root native full-corpus validation passed for 264 records and 20,651 evidence blocks. Actual complete log and terminal receipt independently bound; cutoff precedes final retention/report adoption. |
| Required full corpus just test | unavailable | True | MetaCyc:P321-PWY | Root owns live native gates; terminal receipt and final reviewed source cutoff not yet bound in this provisional content. |
| Required full corpus just lint | unavailable | True | MetaCyc:P321-PWY | Root owns live native gates; terminal receipt and final reviewed source cutoff not yet bound in this provisional content. |
| Required full corpus git diff --check | unavailable | True | MetaCyc:P321-PWY | Root owns live native gates; terminal receipt and final reviewed source cutoff not yet bound in this provisional content. |
| Final maintained evidence retention and research report | unavailable | True | MetaCyc:P321-PWY | Author retention and final report adoption not yet independently rebound. Current source originals and accepted external owners are verified; this is not final retained-input acceptance. |

## Scientific And Domain Assessments

### Exact route identity and source boundaries

identity: supported. Targets: MetaCyc:P321-PWY.

P321 is the complete selected nine-step saturated-intermediate route; benzoate activation and downstream glutaryl-CoA degradation are outside it. Adjacent seven-step CENTBENZCOA is distinct. Current inventory contains one P321 and preserves all 263 earlier records.

### Exact structures, material states and carrier conventions

grounding: supported. Targets: MetaCyc:P321-PWY.

All 42 material occurrences/23 frames and 19 core molecular identities plus four generic carrier-state classes are accounted for. Charges, unspecified stereochemistry, E-specific lower enoyl intermediate and native carrier conventions are retained.

Formal net: benzoyl-CoA + 2 reduced ferredoxin cluster units + 2 ATP + 5 water + reduced ETF + 3 NAD + CoA -&gt; 2 oxidized ferredoxin cluster units + 2 ADP + 2 phosphate + oxidized ETF + 5 protons + 3 NADH + glutaryl-CoA + acetyl-CoA. This is symbolic source accounting, not measured whole-pathway flux or demonstrated physiological electron coupling.

### BadDEFG genetics and purified Thauera BCR

evidence: supported. Targets: MetaCyc:P321-PWY.

BadDEFG enables is genetics-supported; purified Thauera BCR catalyzes is a separate preparation/taxon context. Neither means each monomer independently catalyzes.

Approximately 2 ATP per two electrons is qualified by uncoupled ATPase and a minor four-electron product. Whole donor proteins, donor cluster-state equation units, intrinsic BCR clusters and magnesium remain distinct.

### Reverse-assay Syntrophus construct and physiological donor limit

scope: supported. Targets: MetaCyc:P321-PWY.

Q2LQN9 is the native 414-aa protein; the reported 397-aa downstream-ATG segment plus C-terminal His6 is a separate construct. Reverse artificial-reductant diene reduction supports qualified enables, not measured physiological ETF coupling.

Expression host BL21 Star(DE3), tag/linker uncertainty and FAD text-versus-table occupancy conflict remain explicit. No unique cofactor occupancy or charge is asserted.

### BadK, BadH and BadI preparation-specific catalysis

evidence: supported. Targets: MetaCyc:P321-PWY.

BadK crude extract, tagged BadH and native purified BadI retain their actual preparation scope. BadH NAD-positive/NADP-negative and negative C7-substrate result do not fill the eighth step.

BadK crude E. coli DH5alpha/pDP111 activity is not purification or monomer proof. Native CPLX-926 omitted component coefficient stays unspecified. BadI four-column apparent homogeneity, approximately 90%-pure shorter preparation, and approximately 5% intended substrate mixture refer to different quantities; no CoASH stimulation/free-acid activity or reverse ring closure is invented. Automated modern protein naming cannot override the assayed substrate.

### Pim predictions, whole-operon genetics and unassigned eighth catalyst

evidence: supported. Targets: MetaCyc:P321-PWY.

All lower native chemistry is retained while PimCD/PimF/PimB use predicted enables. The eighth putative reaction has no catalyst. The 772-nt pimE pseudogene is not an active protein.

Whole-operon growth/operon evidence, aerobic RNA context, residual growth and native wild-type caprylate growth are retained. Possible PimF bifunctionality and a formal NAD-versus-predicted-flavin distinction remain unresolved; isolated C7 catalysis is not inferred.

### Native component and cofactor roles

graph: supported. Targets: MetaCyc:P321-PWY.

All 16 monomer identities, seven assemblies, 14 component associations and four cofactor pointers preserve actual source roles, coefficients and assay qualification.

The corrected e083 spectroscopy assertion is limited to the retained PMID10903310 abstract. It no longer attributes 1997 nonunique cluster discussion or a three-paper chronology to that abstract. AadR Fnr-family analogy is not measured fixed FeS occupancy; Syntrophus FAD occupancy conflict is retained.

### BadM, BadR, AadR and genetic BadL/BadM relationships

evidence: supported. Targets: MetaCyc:P321-PWY.

Direct BadM/BadR promoter-binding and repression results are distinct from AadR-dependent expression and the genetic BadL/BadM relation. Historical BadR activation interpretation is revised by the later controlled repression evidence.

23-bp BadM and 18-bp BadR footprints retain actual constructs and assay contexts. BadM 2015 tag-position conflict/163-aa reconstruction versus 156/154-aa native contexts, and BadR 182-aa tagged reconstruction versus 175-aa native sequence, are not silently reconciled. Keto-CoA binding effects provide no physiological concentration or Kd. No direct AadR binding, native BadL-BadM binding or BadM acetylation is inferred.

### Three exact assay reagents and BadM effects

grounding: supported. Targets: MetaCyc:P321-PWY.

Ortho PubChem6971, meta48847 and para19266 are distinct neutral C9H9NO3 reagents. All measured BadM effects remain represented without treating reagent acids as formal anions or depicted zwitterions.

Nominal 10 mM EMSA conditions with 72 nM BadM and 12 nM 212-bp probe, no effect at 5 mM ortho, and meta/para solubility/precipitation limits are explicit. These do not identify a physiological ligand, establish affinity rank or permit a Kd inference.

### Exact ortho auxiliary chemistry and two homolog preparations

scope: supported. Targets: MetaCyc:P321-PWY.

RHEA28551 is the balanced anthranilate + acetyl-CoA(4-) -&gt; N-acetylanthranilate + CoA(4-) reaction, with four material and two qualified catalyst edges outside native P321 membership/order.

Q2W1S9 from current P. magneticum AMB-1 and Q39TU9 from G. metallireducens GS-15 retain separate native length/taxon and reported JE9314 expression contexts. Both homologs have TLC-supported ortho/meta/para products; only MmBadL meta product has reported direct HPLC/MS comparison. Below-background kinetics cannot establish preference/constants. Exact meta/para activity identifiers remain gaps; no native RpBadL catalysis or tenth P321 step is inferred.

### Taxon, strain, expression host and construct specificity

scope: supported. Targets: MetaCyc:P321-PWY.

All seven source/assay taxa and exact native sequence mappings are retained; they are not a claim that all seven complete the entire pathway.

Experimental constructs are qualified endpoints, not new native identity assertions. The AMB-1 taxon spelling update is issuing taxonomy identity; older Magnetospirillum wording remains the publication context.

### Full claim/source coverage and honest primary-reading depth

provenance: supported. Targets: MetaCyc:P321-PWY.

All 100 edges and 196 evidence items (177 edge + 19 endpoint-qualifier items), 64 references, 28 primary claims and 15 design obligations are accounted for. Every original reference body was freshly rebound; prior literature interpretations retain their explicit read depth.

Previously unavailable full texts/supplements remain unavailable. PMID10903310 is abstract-only; prior reused claims are not presented as a fresh whole-paper read. The 76 source-lead dispositions and finite hidden/ignored/archive context are not global literature exhaustion. Original failed probes and corrected executions are retained.

### Actual 80-node authority reconciliation

grounding: supported. Targets: MetaCyc:P321-PWY.

Every selected identifier, category and label agrees with the adopted native authority union. Existing terms/owners remain preserved and ordinary-source additions remain separate from ontology additions.

The source union has 3,221 terms/1,209 owners; ontology has 2,196 terms/five owners. Full union rebuild, ordered-owner preservation and code checks are root-owned evidence; the current scientific review directly verifies all 80 consumer bindings. Identifier agreement alone does not demonstrate catalysis.

### Required structured-source route

evidence: not_applicable. Targets: MetaCyc:P321-PWY.

The successful complete iModulonDB dataset catalog does not cover selected native taxa; organism search/module summarization is not applicable.

Catalog absence is coverage information only. E. coli and P. aeruginosa expression-host coverage cannot establish regulation of the native pathway or recombinant target. Initial missing dependency and sandbox DNS failures are preserved; existing runner succeeded without installation after approved public network access.

### Actual page, graph and KGX fidelity

representation: supported. Targets: MetaCyc:P321-PWY.

Native page fields, 100 relationships and all source qualifiers survive actual rendering/export. The 92 graph nodes include qualified endpoint contexts beyond 80 declared identities.

Reviewer personally viewed root-captured desktop overview, focused desktop and focused mobile screenshots. Overview is dense at 15%; selected reaction is readable at 100%; graph scrolls inside its viewport. Root browser measures zero runtime errors and document-width containment. This is a smoke check, not accessibility or cross-browser certification. All 13,689 earlier export edge rows remain exact.

### R01–R04 predecessor handling

consistency: supported. Targets: MetaCyc:P321-PWY.

The actual record is byte-identical to the independently accepted corrected successor. Four original external findings remain preserved with their needs-curation verdict; their corrected successor has bounded acceptance.

No prior canonical review for this target was found in the hidden/ignored-inclusive review inventory. External issues #600–603 are documentary lineage, not fabricated structured previous_occurrences. This review creates no scientific status promotion or issue-closure action.

### Human-readable research report

consistency: supported. Targets: MetaCyc:P321-PWY.

The separately reviewed external draft agrees with the maintained scientific claims, formal net, evidence counts and limitations.

Final report/retention adoption is still pending at this provisional draft cutoff; its exact maintained bytes must be inspected and reassessed before completed review persistence.

### e001 MetaCyc:1.3.99.15-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 1 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e002 CHEBI:57369 consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e003 MetaCyc:Reduced-ferredoxins consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 2 in selected R2L traversal. Generic ferredoxin cluster units are not whole-protein counts. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e004 CHEBI:30616 consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e005 CHEBI:15377 consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[4]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e006 MetaCyc:1.3.99.15-RXN produces CHEBI:57374

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e007 MetaCyc:1.3.99.15-RXN produces MetaCyc:Oxidized-ferredoxins

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 2 in selected R2L traversal. Generic ferredoxin cluster units are not whole-protein counts. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e008 MetaCyc:1.3.99.15-RXN produces CHEBI:456216

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e009 MetaCyc:1.3.99.15-RXN produces CHEBI:43474

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[4]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']

### e010 MetaCyc:R265-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 2 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']

### e011 CHEBI:57374 consumes MetaCyc:R265-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:R265-RXN /ptools-xml/Reaction[@frameid='R265-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']

### e012 MetaCyc:ETF-Reduced consumes MetaCyc:R265-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Generic ETF redox-state convention; physiological coupling unresolved. Exact locators: MetaCyc:R265-RXN /ptools-xml/Reaction[@frameid='R265-RXN']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']

### e013 MetaCyc:R265-RXN produces CHEBI:76270

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:R265-RXN /ptools-xml/Reaction[@frameid='R265-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']

### e014 MetaCyc:R265-RXN produces MetaCyc:ETF-Oxidized

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Generic ETF redox-state convention; physiological coupling unresolved. Exact locators: MetaCyc:R265-RXN /ptools-xml/Reaction[@frameid='R265-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']

### e015 MetaCyc:R265-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:R265-RXN /ptools-xml/Reaction[@frameid='R265-RXN']/left[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']

### e016 MetaCyc:R266-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 3 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']

### e017 CHEBI:76270 consumes MetaCyc:R266-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R266-RXN /ptools-xml/Reaction[@frameid='R266-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']

### e018 CHEBI:15377 consumes MetaCyc:R266-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R266-RXN /ptools-xml/Reaction[@frameid='R266-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']

### e019 MetaCyc:R266-RXN produces PubChem:90657894

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R266-RXN /ptools-xml/Reaction[@frameid='R266-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']

### e020 MetaCyc:R267-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 4 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']

### e021 PubChem:90657894 consumes MetaCyc:R267-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN /ptools-xml/Reaction[@frameid='R267-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']

### e022 CHEBI:57540 consumes MetaCyc:R267-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN /ptools-xml/Reaction[@frameid='R267-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']

### e023 MetaCyc:R267-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN /ptools-xml/Reaction[@frameid='R267-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']

### e024 MetaCyc:R267-RXN produces PubChem:90658738

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN /ptools-xml/Reaction[@frameid='R267-RXN']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']

### e025 MetaCyc:R267-RXN produces CHEBI:57945

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN /ptools-xml/Reaction[@frameid='R267-RXN']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']

### e026 MetaCyc:R268-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 5 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']

### e027 PubChem:90658738 consumes MetaCyc:R268-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN /ptools-xml/Reaction[@frameid='R268-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']

### e028 CHEBI:15377 consumes MetaCyc:R268-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN /ptools-xml/Reaction[@frameid='R268-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']

### e029 MetaCyc:R268-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN /ptools-xml/Reaction[@frameid='R268-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']

### e030 MetaCyc:R268-RXN produces CHEBI:57360

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN /ptools-xml/Reaction[@frameid='R268-RXN']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']

### e031 MetaCyc:1.3.1.62-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 6 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']

### e032 CHEBI:57360 consumes MetaCyc:1.3.1.62-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']

### e033 CHEBI:57540 consumes MetaCyc:1.3.1.62-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']

### e034 MetaCyc:1.3.1.62-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']

### e035 MetaCyc:1.3.1.62-RXN produces CHEBI:57945

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']

### e036 MetaCyc:1.3.1.62-RXN produces PubChem:90657525

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']

### e037 MetaCyc:RXN-8031 part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 7 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']

### e038 PubChem:90657525 consumes MetaCyc:RXN-8031

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8031 /ptools-xml/Reaction[@frameid='RXN-8031']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']

### e039 CHEBI:15377 consumes MetaCyc:RXN-8031

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8031 /ptools-xml/Reaction[@frameid='RXN-8031']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']

### e040 MetaCyc:RXN-8031 produces CHEBI:57343

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8031 /ptools-xml/Reaction[@frameid='RXN-8031']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']

### e041 MetaCyc:1.1.1.259-RXN part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 8 of the complete selected nine-step route. Native YES-PUTATIVE has no assigned activity; no active PimE or substitute catalyst is curated. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/orphan; complete reaction object

### e042 CHEBI:57343 consumes MetaCyc:1.1.1.259-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']

### e043 CHEBI:57540 consumes MetaCyc:1.1.1.259-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']

### e044 MetaCyc:1.1.1.259-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']

### e045 MetaCyc:1.1.1.259-RXN produces CHEBI:57945

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']

### e046 MetaCyc:1.1.1.259-RXN produces CHEBI:57350

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']

### e047 MetaCyc:RXN-8032 part_of MetaCyc:P321-PWY

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Step 9 of the complete selected nine-step source route. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']

### e048 CHEBI:57350 consumes MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']

### e049 CHEBI:57287 consumes MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']

### e050 MetaCyc:RXN-8032 produces CHEBI:57378

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']

### e051 MetaCyc:RXN-8032 produces CHEBI:57288

graph: supported. Targets: MetaCyc:P321-PWY.

Original P321 reaction-layout and nine whole native reactions independently reconstructed; directions/coefficients/frame identities exact.

Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']

### e052 MetaCyc:1.3.99.15-RXN provides_input_for MetaCyc:R265-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material CHEBI:57374; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e053 MetaCyc:R265-RXN provides_input_for MetaCyc:R266-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material CHEBI:76270; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e054 MetaCyc:R266-RXN provides_input_for MetaCyc:R267-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material PubChem:90657894; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e055 MetaCyc:R267-RXN provides_input_for MetaCyc:R268-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material PubChem:90658738; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e056 MetaCyc:R268-RXN provides_input_for MetaCyc:1.3.1.62-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material CHEBI:57360; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e057 MetaCyc:1.3.1.62-RXN provides_input_for MetaCyc:RXN-8031

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material PubChem:90657525; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e058 MetaCyc:RXN-8031 provides_input_for MetaCyc:1.1.1.259-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material CHEBI:57343; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e059 MetaCyc:1.1.1.259-RXN provides_input_for MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:P321-PWY.

Consecutive selected reactions share actual output/input frames; route remains complete through glutaryl-CoA+acetyl-CoA.

Claim: Exact shared primary material CHEBI:57350; coefficient 1 produced and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]

### e060 MetaCyc:CPLX-883 enables MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: Native R. palustris first-step assignment has mutant and sequence evidence. badE/badF mutant/complementation/expression evidence supports a genetic contribution; do not claim isolated holoenzyme, each subunit independently catalyzes, or fixed donor/cofactor occupancy. Feeding substrate was labelled benzoate, not benzoyl-CoA. Exact locators: MetaCyc:ENZRXN-1102 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1102']/*[self::enzyme or self::reaction or self::evidence]; PMID:9177244 PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs

### e061 MetaCyc:CPLX-1341 catalyzes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: Shared first reaction, experimentally characterized Thauera BCR context. Exact four subunit identities established. Intrinsic clusters and Mg2+ remain separate from donor cluster-state equation units. Purified Thauera evidence is not a purified R. palustris BadDEFG preparation. Exact locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/*[self::enzyme or self::reaction or self::evidence]; PMID:9108255 pp841–845; Table1; Figures1–5; PMID:12081970 Methods; Figure3; Tables3–4; Figure5

### e062 MetaCyc:CPLX-8778 enables MetaCyc:R265-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: Source assigns the generic ETF reaction; recombinant reverse diene reduction uses Ti(III)/methyl viologen. This enables assignment does not assert measured physiological ETF catalysis or an exact R. palustris catalyst. Exact locators: MetaCyc:ENZRXN-22280 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-22280']/*[self::enzyme or self::reaction or self::evidence]; PMID:23667239 PMC3697644 Results Ch1CoA dehydrogenase; Figures3–6; Table2; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2 Endpoint context: subject experimental_construct: Syntrophus SB SYN_02587 downstream-ATG native segment (397 aa) plus C-terminal His6 in E. coli BL21 Star(DE3); not the deposited full 414-aa preparation. Linker bases unavailable.

### e063 MetaCyc:CPLX-926 catalyzes MetaCyc:R266-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: BadK hydration of the native monoene, not hydroxylation. 1997 assay used recombinant E. coli crude extract; one-component native complex is not experimental oligomeric-state proof. Exact BadK identity differs from BadJ/AliB adjacent entry. Exact locators: MetaCyc:ENZRXN-1144 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1144']/*[self::enzyme or self::reaction or self::evidence]; PMID:9177244 PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs); PMID:9177244 PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs) Endpoint context: subject experimental_construct: Recombinant E. coli DH5alpha pDP111 crude extract containing BadK; no purified protein or measured native oligomeric state.

### e064 MetaCyc:CPLX-885 catalyzes MetaCyc:R267-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: BadH saturated cyclic substrate oxidation is NAD-dependent. Primary assay used N-terminal His6/factor Xa construct in E. coli DH5alpha, not purification from R. palustris. Apparent tetramer is preparation-specific; negative 3-hydroxypimeloyl-CoA activity prevents filling the lower C7 step. Exact locators: MetaCyc:ENZRXN-1104 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1104']/*[self::enzyme or self::reaction or self::evidence]; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5 Endpoint context: subject experimental_construct: N-terminal His6/factor Xa BadH expressed in E. coli DH5alpha. Tagged recombinant apparent tetramer; native 27-kDa immunoblot is a different preparation.

### e065 MetaCyc:CPLX-884 catalyzes MetaCyc:R268-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: BadI saturated cyclic ring-opening has native purification and mutant evidence. Approximately 100-fold/four-column purification to apparent homogeneity differs from the shortened 90%-pure preparation and approximately 5% intended substrate mixture. Automated UniProt functional name does not override exact source/product assay; substrate mixture limits affinity/chemical interpretation, not reported protein purity. Exact locators: MetaCyc:ENZRXN-1103 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1103']/*[self::enzyme or self::reaction or self::evidence]; PMID:9573182 PMC107172 sec16–sec18; Table1; Figures2–4; PMID:9573182 PMC107172 substrate specificity and Discussion; Figure5

### e066 MetaCyc:CPLX-9349 enables MetaCyc:1.3.1.62-RXN

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: PimCD is a predicted lower pimeloyl-CoA dehydrogenase assignment. Exact C/D sequences and proposed 1:1 assembly are identifiable; operon deletion/cotranscription does not establish purified enzyme, fixed flavin occupancy, or direct NAD usage in the native formal equation. Keep biological hypothesis separate from reaction chemistry. Exact locators: MetaCyc:ENZRXN-26771 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-26771']/*[self::enzyme or self::reaction or self::evidence]; PMID:15758219 PDF pp728,731,734; Figure1; PMID:15758219 PDF pp729–734; Figures2,3; Table2

### e067 UniProtKB:Q6N3H7 enables MetaCyc:RXN-8031

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: PimF is a predicted lower enoyl-CoA hydratase assignment. 699-aa protein identity is exact; domain composition and 2005 bifunctionality hypothesis do not establish C7 hydration/oxidation assays. Do not turn the paper Fig. 1 dual-role hypothesis into a measured step 8 catalyst. Exact locators: MetaCyc:ENZRXN-26772 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-26772']/*[self::enzyme or self::reaction or self::evidence]; PMID:15758219 PDF pp731,734; Figure1; PMID:15758219 PDF pp729–734; Figures2,3; Table2

### e068 UniProtKB:Q6N3H9 enables MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:P321-PWY.

R. palustris BadDEFG genetics distinguished from Thauera purified BCR; Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD specificity/negative C7; native BadI protein purity versus a 5% substrate mixture; PimCD/F/B prediction only.

Claim: PimB is a predicted lower CoA thiolysis assignment. Exact protein/gene identity does not make operon-level evidence a purified 3-oxopimeloyl-CoA thiolase assay; separate PimA acid activation is outside the selected boundary. Exact locators: MetaCyc:ENZRXN-26773 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-26773']/*[self::enzyme or self::reaction or self::evidence]; PMID:15758219 PDF pp728,731,734; Figure1; PMID:15758219 PDF pp729–734; Figures2,3; Table2

### e069 MetaCyc:CPLX-1341 has_part UniProtKB:O87876

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341 /Protein[@frameid="CPLX-1341"]/component[1]

### e070 MetaCyc:CPLX-1341 has_part UniProtKB:O87875

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341 /Protein[@frameid="CPLX-1341"]/component[2]

### e071 MetaCyc:CPLX-1341 has_part UniProtKB:O87874

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341 /Protein[@frameid="CPLX-1341"]/component[3]

### e072 MetaCyc:CPLX-1341 has_part UniProtKB:O87877

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341 /Protein[@frameid="CPLX-1341"]/component[4]

### e073 MetaCyc:CPLX-8778 has_part UniProtKB:Q2LQN9

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 4; Preparation-specific apparent homotetramer. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-8778 /Protein[@frameid="CPLX-8778"]/component[1]; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2 Endpoint context: subject experimental_construct: Syntrophus SB SYN_02587 downstream-ATG native segment (397 aa) plus C-terminal His6 in E. coli BL21 Star(DE3); not the deposited full 414-aa preparation. Linker bases unavailable.; object experimental_construct: Syntrophus SB SYN_02587 downstream-ATG native segment (397 aa) plus C-terminal His6 in E. coli BL21 Star(DE3); not the deposited full 414-aa preparation. Linker bases unavailable.

### e074 MetaCyc:CPLX-883 has_part UniProtKB:O07460

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Genetically inferred R. palustris BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[1]; PMID:9177244 PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs

### e075 MetaCyc:CPLX-883 has_part UniProtKB:O07461

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Genetically inferred R. palustris BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[2]; PMID:9177244 PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs

### e076 MetaCyc:CPLX-883 has_part UniProtKB:O07462

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Genetically inferred R. palustris BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[3]; PMID:9177244 PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs

### e077 MetaCyc:CPLX-883 has_part UniProtKB:O07463

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Genetically inferred R. palustris BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[4]; PMID:9177244 PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs

### e078 MetaCyc:CPLX-884 has_part UniProtKB:O07456

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 4; Preparation-specific apparent homotetramer. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-884 /Protein[@frameid="CPLX-884"]/component[1]; PMID:9573182 PMC107172 substrate specificity and Discussion; Figure5

### e079 MetaCyc:CPLX-885 has_part UniProtKB:O07457

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 4; Preparation-specific apparent homotetramer. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-885 /Protein[@frameid="CPLX-885"]/component[1]; PMID:10781543 PMC101983 sec17; Figure4 (purification/SDS-PAGE) and sec17 final paragraph (gel filtration/subunit mass); sec18 (CGA720 nonpolar mutant, retained BadI and native BadH immunoblot text; immunoblot data not shown); PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5 Endpoint context: subject experimental_construct: N-terminal His6/factor Xa BadH expressed in E. coli DH5alpha. Tagged recombinant apparent tetramer; native 27-kDa immunoblot is a different preparation.; object experimental_construct: N-terminal His6/factor Xa BadH expressed in E. coli DH5alpha. Tagged recombinant apparent tetramer; native 27-kDa immunoblot is a different preparation.

### e080 MetaCyc:CPLX-926 has_part UniProtKB:O07453

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native singleton component link with no explicit coefficient; one distinct component type is bookkeeping, with unknown multiplicity and no proof of monomeric enzyme. Exact locators: MetaCyc:CPLX-926 /Protein[@frameid="CPLX-926"]/component[1]; PMID:9177244 PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs); PMID:9177244 PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs) Endpoint context: subject experimental_construct: Recombinant E. coli DH5alpha pDP111 crude extract containing BadK; no purified protein or measured native oligomeric state.; object experimental_construct: Recombinant E. coli DH5alpha pDP111 crude extract containing BadK; no purified protein or measured native oligomeric state.

### e081 MetaCyc:CPLX-9349 has_part UniProtKB:Q6N3I1

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Proposed PimCD heterodimer; no purified assembly. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-9349 /Protein[@frameid="CPLX-9349"]/component[1]; PMID:15758219 PDF pp728,731,734; Figure1

### e082 MetaCyc:CPLX-9349 has_part UniProtKB:Q6N3I0

graph: supported. Targets: MetaCyc:P321-PWY.

All seven source assemblies and 16 core monomers crosswalked to exact native components/coefficients; apparent/putative/singleton assembly limits retained.

Claim: Native component multiplicity 1; Proposed PimCD heterodimer; no purified assembly. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-9349 /Protein[@frameid="CPLX-9349"]/component[2]; PMID:15758219 PDF pp728,731,734; Figure1

### e083 MetaCyc:CPLX-1341 has_cofactor MetaCyc:CPD-7

graph: supported. Targets: MetaCyc:P321-PWY.

Actual native cofactor pointer and corrected PMID10903310 abstract-only spectroscopy/three-cluster claim are supported. The original R01 chronology attribution was independently corrected; no fixed occupancy or donor equivalence is asserted.

Claim: Native intrinsic-cluster annotation; no fixed cluster count or equality to whole ferredoxin donor. Exact locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/cofactor[Compound/@frameid='CPD-7']; PMID:10903310 Europe PMC CORE JSON $.resultList.result[0].abstractText, sentences 3–4; indexed abstract only. Complete paper and spectra not examined.

### e084 MetaCyc:CPLX-1341 has_cofactor CHEBI:18420

graph: supported. Targets: MetaCyc:P321-PWY.

Actual native cofactor pointers retained; magnesium has no fixed metal occupancy, Syntrophus FAD text/table conflict and construct qualification are preserved, and tested BadH NAD is a soluble redox cosubstrate rather than an asserted prosthetic group.

Claim: Activity-specific magnesium annotation; no fixed metal occupancy. Exact locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/cofactor[Compound/@frameid='MG+2']

### e085 MetaCyc:CPLX-8778 has_cofactor CHEBI:57692

graph: supported. Targets: MetaCyc:P321-PWY.

Actual native cofactor pointers retained; magnesium has no fixed metal occupancy, Syntrophus FAD text/table conflict and construct qualification are preserved, and tested BadH NAD is a soluble redox cosubstrate rather than an asserted prosthetic group.

Claim: Recombinant Syntrophus flavoprotein context. Text 1.05 FAD/monomer conflicts with Table 2 values of 0.41/0.67; no fixed occupancy or bound charge. Exact locators: MetaCyc:ENZRXN-22280 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-22280']/cofactor[Compound/@frameid='FAD']; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2 Endpoint context: subject experimental_construct: Syntrophus SB SYN_02587 downstream-ATG native segment (397 aa) plus C-terminal His6 in E. coli BL21 Star(DE3); not the deposited full 414-aa preparation. Linker bases unavailable.

### e086 MetaCyc:CPLX-885 has_cofactor CHEBI:57540

graph: supported. Targets: MetaCyc:P321-PWY.

Actual native cofactor pointers retained; magnesium has no fixed metal occupancy, Syntrophus FAD text/table conflict and construct qualification are preserved, and tested BadH NAD is a soluble redox cosubstrate rather than an asserted prosthetic group.

Claim: NAD is the tested soluble redox cosubstrate; native cofactor annotation does not establish a bound prosthetic group. NADP was negative. Exact locators: MetaCyc:ENZRXN-1104 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1104']/cofactor[Compound/@frameid='NAD']; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5 Endpoint context: subject experimental_construct: N-terminal His6/factor Xa BadH expressed in E. coli DH5alpha. Tagged recombinant apparent tetramer; native 27-kDa immunoblot is a different preparation.

### e087 UniProtKB:O07465 regulates MetaCyc:G-545

graph: supported. Targets: MetaCyc:P321-PWY.

The 2015 BadR repression revises the 1999 cassette interpretation; BadM direct footprint versus the 2006 genetics; AadR indirect action possible; BadL genetics does not assert direct binding or catalysis.

Claim: BadM represses badD promoter/operon transcription. Direct 23-bp footprint overlaps promoter/start; no direct inhibition of reductase catalysis. Exact locators: PMID:17041049 PMC1698244 main text; Tables1,2; Figures2–4; PMID:25888170 PMC4475878 sec3-1; Figures2–3 (binding and 23-bp footprint), Figure4 (expression context); PMID:25888170 PMC4475878 sec2-3; Table1; Table2 Endpoint context: subject experimental_construct: BadM produced in P. aeruginosa PAO1-T7; Methods C-terminal versus Table 1 N-terminal His6 labels conflict. Primer-based 163-aa reconstruction is not measured clone sequence; legacy 156-aa and current 154-aa sequences are distinct.

### e088 UniProtKB:O07458 regulates MetaCyc:G-550

graph: supported. Targets: MetaCyc:P321-PWY.

The 2015 BadR repression revises the 1999 cassette interpretation; BadM direct footprint versus the 2006 genetics; AadR indirect action possible; BadL genetics does not assert direct binding or catalysis.

Claim: BadR represses badH-associated operon transcription and binds the 18-bp badH-badR intergenic site. The 2015 in-frame deletion revises old insertion-associated activator interpretation. Exact locators: PMID:25888170 PMC4475878 sec3-2,sec3-3,sec4; Figure5; reinterpretation of the1999 cassette-insertion phenotype; PMID:25888170 PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic keto-CoA effector); Figures6–8; PMID:25888170 PMC4475878 sec2-3; Table1; Table2 Endpoint context: subject experimental_construct: N-terminal His6 BadR from pQF5016b expressed in E. coli Rosetta; primer-reconstructed 182-aa construct is distinct from untagged 175-aa issuer sequence.

### e089 PubChem:90658738 inhibits UniProtKB:O07458

graph: supported. Targets: MetaCyc:P321-PWY.

The 2015 BadR repression revises the 1999 cassette interpretation; BadM direct footprint versus the 2006 genetics; AadR indirect action possible; BadL genetics does not assert direct binding or catalysis.

Claim: Cyclic keto-CoA disrupts BadR DNA binding at 40 nmol/10 µL in gel shift. This is an assay effect, not a physiological Kd, endogenous concentration or structural ligand complex. Exact locators: PMID:25888170 PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic keto-CoA effector); Figures6–8; PMID:25888170 PMC4475878 sec2-3; Table1; Table2 Endpoint context: object experimental_construct: N-terminal His6 BadR from pQF5016b expressed in E. coli Rosetta; scope is the purified gel-shift preparation.

### e090 UniProtKB:Q01980 regulates MetaCyc:G-545

graph: supported. Targets: MetaCyc:P321-PWY.

The 2015 BadR repression revises the 1999 cassette interpretation; BadM direct footprint versus the 2006 genetics; AadR indirect action possible; BadL genetics does not assert direct binding or catalysis.

Claim: AadR-dependent anaerobic badD expression is supported by mutant/reporters. Indirect action remains possible; no direct promoter binding or fixed Fe-S occupancy is asserted. Exact locators: PMID:10094687 PMC93622 sec10–sec15; Table2; Figures2–4

### e091 UniProtKB:G3XCQ2 regulates UniProtKB:O07465

graph: supported. Targets: MetaCyc:P321-PWY.

The 2015 BadR repression revises the 1999 cassette interpretation; BadM direct footprint versus the 2006 genetics; AadR indirect action possible; BadL genetics does not assert direct binding or catalysis.

Claim: badL loss reduces badD expression and aromatic growth; badM deletion rescues the defect. This genetic BadL–BadM relationship does not establish direct binding, exact R. palustris BadL acetyltransferase chemistry or an endogenous ligand. Exact locators: PMID:30327443 PMC6191541 s2.1–s2.3; Figures2–6

### e092 PubChem:6971 inhibits UniProtKB:O07465

graph: supported. Targets: MetaCyc:P321-PWY.

All three neutral free-acid reagents with dose/solubility/preparation limits; previous independent whole 2018 original and 14-figure assessment explicitly reused.

Claim: 2-acetamidobenzoic acid reduces BadM binding to the 212-bp badCD promoter probe in EMSA (72 nM BadM, 12 nM probe). The 10 mM 2-acetamido reagent disrupted BadM-DNA binding; 5 mM did not. The 2-amino control did not reproduce the effect. Nominal 10 mM addition and solubility limits do not establish affinity, dissolved concentration, physiological ligand identity or bound protonation. Exact locators: PMID:30327443 PMC6191541 s2.5; Figures 8 and 9; reagent s4.1; preparation s4.3; PubChem:6971 PropertyTable.Properties[0]; full atom/bond structure and ring-position replay bound in regulatory chemistry owner; PMID:30327443 PMC6191541 s4.3; unavailable supplementary protocol is not read Endpoint context: object experimental_construct: 2018 BadM preparation: pRpBadM8 expressed in E. coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage and construct sequence are unavailable; no transfer from the 2015 PAO1-T7 preparation.

### e093 PubChem:48847 inhibits UniProtKB:O07465

graph: supported. Targets: MetaCyc:P321-PWY.

All three neutral free-acid reagents with dose/solubility/preparation limits; previous independent whole 2018 original and 14-figure assessment explicitly reused.

Claim: 3-acetamidobenzoic acid reduces BadM binding to the 212-bp badCD promoter probe in EMSA (72 nM BadM, 12 nM probe). The 3-acetamido reagent increased free probe under the same nominal conditions, with a smaller effect than the 2-isomer. Precipitation/limited solubility prevented quantitative ligand comparisons. Nominal 10 mM addition and solubility limits do not establish affinity, dissolved concentration, physiological ligand identity or bound protonation. Exact locators: PMID:30327443 PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; PubChem:48847 PropertyTable.Properties[0]; full atom/bond structure and ring-position replay bound in regulatory chemistry owner; PMID:30327443 PMC6191541 s4.3; unavailable supplementary protocol is not read Endpoint context: object experimental_construct: 2018 BadM preparation: pRpBadM8 expressed in E. coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage and construct sequence are unavailable; no transfer from the 2015 PAO1-T7 preparation.

### e094 PubChem:19266 inhibits UniProtKB:O07465

graph: supported. Targets: MetaCyc:P321-PWY.

All three neutral free-acid reagents with dose/solubility/preparation limits; previous independent whole 2018 original and 14-figure assessment explicitly reused.

Claim: 4-acetamidobenzoic acid reduces BadM binding to the 212-bp badCD promoter probe in EMSA (72 nM BadM, 12 nM probe). The 4-acetamido reagent increased free probe under the same nominal conditions, with a smaller effect than the 2-isomer. Precipitation/limited solubility prevented quantitative ligand comparisons. Nominal 10 mM addition and solubility limits do not establish affinity, dissolved concentration, physiological ligand identity or bound protonation. Exact locators: PMID:30327443 PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; PubChem:19266 PropertyTable.Properties[0]; full atom/bond structure and ring-position replay bound in regulatory chemistry owner; PMID:30327443 PMC6191541 s4.3; unavailable supplementary protocol is not read Endpoint context: object experimental_construct: 2018 BadM preparation: pRpBadM8 expressed in E. coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage and construct sequence are unavailable; no transfer from the 2015 PAO1-T7 preparation.

### e095 CHEBI:16567 consumes RHEA:28551

graph: supported. Targets: MetaCyc:P321-PWY.

Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis, no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.

Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These explicit anionic states are equation normalization, not measured assay protonation. This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551 rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_3530; http://rdf.rhea-db.org/Compound_3530

### e096 CHEBI:57288 consumes RHEA:28551

graph: supported. Targets: MetaCyc:P321-PWY.

Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis, no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.

Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These explicit anionic states are equation normalization, not measured assay protonation. This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551 rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4271; http://rdf.rhea-db.org/Compound_4271

### e097 RHEA:28551 produces CHEBI:16803

graph: supported. Targets: MetaCyc:P321-PWY.

Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis, no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.

Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These explicit anionic states are equation normalization, not measured assay protonation. This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551 rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4182; http://rdf.rhea-db.org/Compound_4182

### e098 RHEA:28551 produces CHEBI:57287

graph: supported. Targets: MetaCyc:P321-PWY.

Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis, no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.

Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These explicit anionic states are equation normalization, not measured assay protonation. This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551 rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_1264; http://rdf.rhea-db.org/Compound_1264

### e099 UniProtKB:Q2W1S9 catalyzes RHEA:28551

graph: supported. Targets: MetaCyc:P321-PWY.

Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis, no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.

Claim: The heterologous homolog preparation transfers acetyl from acetyl-CoA to the ortho amino substrate in TLC. Rhea provides the formal anionic equation; no native R. palustris BadL catalysis or assay microstate is inferred. Both homologs also acetylated meta/para isomers, whose exact activity IDs remain unresolved after bounded lookup. Exact locators: PMID:30327443 PMC6191541 s2.3 / Figure 6A-C; s2.4 / Figure 7; s4.3; UniProtKB:Q2W1S9 primaryAccession; genes; organism.taxonId; sequence; PMID:30327443 PMC6191541 s4.3; complete supplementary construct protocol unavailable Endpoint context: subject experimental_construct: pMmBadL2 expressed in Escherichia coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage and amino-acid construct boundaries are not recoverable from the blocked supplement. Reference sequence length is not an assertion of the assayed construct sequence.

### e100 UniProtKB:Q39TU9 catalyzes RHEA:28551

graph: supported. Targets: MetaCyc:P321-PWY.

Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis, no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.

Claim: The heterologous homolog preparation transfers acetyl from acetyl-CoA to the ortho amino substrate in TLC. Rhea provides the formal anionic equation; no native R. palustris BadL catalysis or assay microstate is inferred. Both homologs also acetylated meta/para isomers, whose exact activity IDs remain unresolved after bounded lookup. Exact locators: PMID:30327443 PMC6191541 s2.3 / Figure 6A-C; s2.4 / Figure 7; s4.3; UniProtKB:Q39TU9 primaryAccession; genes; organism.taxonId; sequence; PMID:30327443 PMC6191541 s4.3; complete supplementary construct protocol unavailable Endpoint context: subject experimental_construct: pGmBadL1 expressed in Escherichia coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage and amino-acid construct boundaries are not recoverable from the blocked supplement. Reference sequence length is not an assertion of the assayed construct sequence.

## Findings

No findings recorded within this review's declared scope.

## Recommended Actions And Acceptance Checks

## Category Boundaries


## Evidence

| Evidence | Reference / locator | Support | Observation |
| --- | --- | --- | --- |
| source-001 | https://biocyc.org/META/NEW-IMAGE?object=P321-PWY; e001: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e002: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e003: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e004: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e005: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e006: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e007: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e008: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e009: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']; e010: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']; e011: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']; e012: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']; e013: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']; e014: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']; e015: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R265-RXN']; e016: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']; e017: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']; e018: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']; e019: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R266-RXN']; e020: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']; e021: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']; e022: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']; e023: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']; e024: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']; e025: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R267-RXN']; e026: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']; e027: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']; e028: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']; e029: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']; e030: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='R268-RXN']; e031: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']; e032: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']; e033: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']; e034: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']; e035: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']; e036: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.3.1.62-RXN']; e037: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']; e038: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']; e039: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']; e040: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8031']; e041: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; e042: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; e043: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; e044: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; e045: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; e046: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']; e047: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']; e048: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']; e049: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']; e050: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']; e051: /ptools-xml/Pathway[@frameid='P321-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']; e052: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e053: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e054: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e055: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e056: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e057: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e058: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering]; e059: /ptools-xml/Pathway[@frameid='P321-PWY']/*[self::reaction-layout or self::reaction-ordering] | supports | MetaCyc 27.0 native Pathway: P321-PWY. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-P321-PWY.xml |
| source-002 | https://biocyc.org/META/NEW-IMAGE?object=1.3.99.15-RXN; e002: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[1]; e003: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[2]; e004: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[3]; e005: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[4]; e006: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[1]; e007: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[2]; e008: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[3]; e009: /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[4] | supports | MetaCyc 27.0 native Reaction: 1.3.99.15-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-1.3.99.15-RXN.xml |
| source-003 | https://biocyc.org/META/NEW-IMAGE?object=R265-RXN; e011: /ptools-xml/Reaction[@frameid='R265-RXN']/right[1]; e012: /ptools-xml/Reaction[@frameid='R265-RXN']/right[2]; e013: /ptools-xml/Reaction[@frameid='R265-RXN']/left[1]; e014: /ptools-xml/Reaction[@frameid='R265-RXN']/left[2]; e015: /ptools-xml/Reaction[@frameid='R265-RXN']/left[3] | supports | MetaCyc 27.0 native Reaction: R265-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R265-RXN.xml |
| source-004 | https://biocyc.org/META/NEW-IMAGE?object=R266-RXN; e017: /ptools-xml/Reaction[@frameid='R266-RXN']/left[1]; e018: /ptools-xml/Reaction[@frameid='R266-RXN']/left[2]; e019: /ptools-xml/Reaction[@frameid='R266-RXN']/right[1] | supports | MetaCyc 27.0 native Reaction: R266-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R266-RXN.xml |
| source-005 | https://biocyc.org/META/NEW-IMAGE?object=R267-RXN; e021: /ptools-xml/Reaction[@frameid='R267-RXN']/left[1]; e022: /ptools-xml/Reaction[@frameid='R267-RXN']/left[2]; e023: /ptools-xml/Reaction[@frameid='R267-RXN']/right[1]; e024: /ptools-xml/Reaction[@frameid='R267-RXN']/right[2]; e025: /ptools-xml/Reaction[@frameid='R267-RXN']/right[3] | supports | MetaCyc 27.0 native Reaction: R267-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R267-RXN.xml |
| source-006 | https://biocyc.org/META/NEW-IMAGE?object=R268-RXN; e027: /ptools-xml/Reaction[@frameid='R268-RXN']/left[1]; e028: /ptools-xml/Reaction[@frameid='R268-RXN']/left[2]; e029: /ptools-xml/Reaction[@frameid='R268-RXN']/right[1]; e030: /ptools-xml/Reaction[@frameid='R268-RXN']/right[2] | supports | MetaCyc 27.0 native Reaction: R268-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R268-RXN.xml |
| source-007 | https://biocyc.org/META/NEW-IMAGE?object=1.3.1.62-RXN; e032: /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/left[1]; e033: /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/left[2]; e034: /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/right[1]; e035: /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/right[2]; e036: /ptools-xml/Reaction[@frameid='1.3.1.62-RXN']/right[3] | supports | MetaCyc 27.0 native Reaction: 1.3.1.62-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-1.3.1.62-RXN.xml |
| source-008 | https://biocyc.org/META/NEW-IMAGE?object=RXN-8031; e038: /ptools-xml/Reaction[@frameid='RXN-8031']/left[1]; e039: /ptools-xml/Reaction[@frameid='RXN-8031']/left[2]; e040: /ptools-xml/Reaction[@frameid='RXN-8031']/right[1] | supports | MetaCyc 27.0 native Reaction: RXN-8031. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-RXN-8031.xml |
| source-009 | https://biocyc.org/META/NEW-IMAGE?object=1.1.1.259-RXN; e041: /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/orphan; complete reaction object; e042: /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/left[1]; e043: /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/left[2]; e044: /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[1]; e045: /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[2]; e046: /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[3] | supports | MetaCyc 27.0 native Reaction: 1.1.1.259-RXN. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-1.1.1.259-RXN.xml |
| source-010 | https://biocyc.org/META/NEW-IMAGE?object=RXN-8032; e048: /ptools-xml/Reaction[@frameid='RXN-8032']/left[1]; e049: /ptools-xml/Reaction[@frameid='RXN-8032']/left[2]; e050: /ptools-xml/Reaction[@frameid='RXN-8032']/right[1]; e051: /ptools-xml/Reaction[@frameid='RXN-8032']/right[2] | supports | MetaCyc 27.0 native Reaction: RXN-8032. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-RXN-8032.xml |
| source-011 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1102; e060: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1102']/*[self::enzyme or self::reaction or self::evidence] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1102. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1102.xml |
| source-012 | https://pubmed.ncbi.nlm.nih.gov/9177244/; e060: PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs; e063: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs); e063: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs); e074: PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs; e075: PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs; e076: PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs; e077: PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs; e080: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs); e080: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs) | supports | A cluster of bacterial genes for anaerobic benzene ring biodegradation. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC21076.html |
| source-013 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1821; e061: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/*[self::enzyme or self::reaction or self::evidence]; e083: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/cofactor[Compound/@frameid='CPD-7']; e084: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/cofactor[Compound/@frameid='MG+2'] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1821. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1821.xml |
| source-014 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-22280; e062: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-22280']/*[self::enzyme or self::reaction or self::evidence]; e085: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-22280']/cofactor[Compound/@frameid='FAD'] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-22280. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-22280.xml |
| source-015 | https://pubmed.ncbi.nlm.nih.gov/23667239/; e062: PMC3697644 Results Ch1CoA dehydrogenase; Figures3–6; Table2; e062: PMC3697644 Methods expression; Results recombinant enzyme; Table2; e062: PMC3697644 Methods expression; Results recombinant enzyme; Table2; e073: PMC3697644 Methods expression; Results recombinant enzyme; Table2; e073: PMC3697644 Methods expression; Results recombinant enzyme; Table2; e073: PMC3697644 Methods expression; Results recombinant enzyme; Table2; e085: PMC3697644 Methods expression; Results recombinant enzyme; Table2; e085: PMC3697644 Methods expression; Results recombinant enzyme; Table2 | supports | Cyclohexanecarboxyl-Coenzyme A (CoA) and Cyclohex-1-ene-1-Carboxyl-CoA Dehydrogenases, Two Enzymes Involved in the Fermentation of Benzoate and Crotonate in Syntrophus aciditrophicus. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC3697644.html |
| source-016 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1144; e063: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1144']/*[self::enzyme or self::reaction or self::evidence] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1144. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1144.xml |
| source-017 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1104; e064: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1104']/*[self::enzyme or self::reaction or self::evidence]; e086: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1104']/cofactor[Compound/@frameid='NAD'] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1104. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1104.xml |
| source-018 | https://pubmed.ncbi.nlm.nih.gov/10781543/; e064: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e064: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e079: PMC101983 sec17; Figure4 (purification/SDS-PAGE) and sec17 final paragraph (gel filtration/subunit mass); sec18 (CGA720 nonpolar mutant, retained BadI and native BadH immunoblot text; immunoblot data not shown); e079: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e079: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e086: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e086: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5 | supports | 2-Hydroxycyclohexanecarboxyl Coenzyme A Dehydrogenase, an Enzyme Characteristic of the Anaerobic Benzoate Degradation Pathway Used by Rhodopseudomonas palustris. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC101983.html |
| source-019 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1103; e065: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1103']/*[self::enzyme or self::reaction or self::evidence] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1103. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1103.xml |
| source-020 | https://pubmed.ncbi.nlm.nih.gov/9573182/; e065: PMC107172 sec16–sec18; Table1; Figures2–4; e065: PMC107172 substrate specificity and Discussion; Figure5; e078: PMC107172 substrate specificity and Discussion; Figure5 | supports | 2-Ketocyclohexanecarboxyl Coenzyme A Hydrolase, the Ring Cleavage Enzyme Required for Anaerobic Benzoate Degradation by Rhodopseudomonas palustris. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC107172.html |
| source-021 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-26771; e066: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-26771']/*[self::enzyme or self::reaction or self::evidence] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-26771. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-26771.xml |
| source-022 | https://pubmed.ncbi.nlm.nih.gov/15758219/; e066: PDF pp728,731,734; Figure1; e066: PDF pp729–734; Figures2,3; Table2; e067: PDF pp731,734; Figure1; e067: PDF pp729–734; Figures2,3; Table2; e068: PDF pp728,731,734; Figure1; e068: PDF pp729–734; Figures2,3; Table2; e081: PDF pp728,731,734; Figure1; e082: PDF pp728,731,734; Figure1 | supports | The pimFABCDE operon from Rhodopseudomonas palustris mediates dicarboxylic acid degradation and participates in anaerobic benzoate degradation. Bound publisher PDF and retained PDFKit text pages1,2,3,5,6,8 read for bibliography, predictions, whole-operon genetics, aerobic RNA condition, residual growth and pseudogene limits. No fresh PDF text engine or visual proof claimed. This qualified prior reading is reused; the title page was personally viewed during the independent correction review. Current original bytes and maintained claims were freshly rebound. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/followup/PMID15758219-publisher-pdf.pdf |
| source-023 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-26772; e067: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-26772']/*[self::enzyme or self::reaction or self::evidence] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-26772. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-26772.xml |
| source-024 | https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-26773; e068: /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-26773']/*[self::enzyme or self::reaction or self::evidence] | supports | MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-26773. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-26773.xml |
| source-025 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-1341; e069: /Protein[@frameid="CPLX-1341"]/component[1]; e070: /Protein[@frameid="CPLX-1341"]/component[2]; e071: /Protein[@frameid="CPLX-1341"]/component[3]; e072: /Protein[@frameid="CPLX-1341"]/component[4] | supports | MetaCyc 27.0 native Protein: CPLX-1341. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-1341.xml |
| source-026 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-8778; e073: /Protein[@frameid="CPLX-8778"]/component[1] | supports | MetaCyc 27.0 native Protein: CPLX-8778. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-8778.xml |
| source-027 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-883; e074: /Protein[@frameid="CPLX-883"]/component[1]; e075: /Protein[@frameid="CPLX-883"]/component[2]; e076: /Protein[@frameid="CPLX-883"]/component[3]; e077: /Protein[@frameid="CPLX-883"]/component[4] | supports | MetaCyc 27.0 native Protein: CPLX-883. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-883.xml |
| source-028 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-884; e078: /Protein[@frameid="CPLX-884"]/component[1] | supports | MetaCyc 27.0 native Protein: CPLX-884. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-884.xml |
| source-029 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-885; e079: /Protein[@frameid="CPLX-885"]/component[1] | supports | MetaCyc 27.0 native Protein: CPLX-885. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-885.xml |
| source-030 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-926; e080: /Protein[@frameid="CPLX-926"]/component[1] | supports | MetaCyc 27.0 native Protein: CPLX-926. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-926.xml |
| source-031 | https://biocyc.org/META/NEW-IMAGE?object=CPLX-9349; e081: /Protein[@frameid="CPLX-9349"]/component[1]; e082: /Protein[@frameid="CPLX-9349"]/component[2] | supports | MetaCyc 27.0 native Protein: CPLX-9349. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-9349.xml |
| source-032 | https://pubmed.ncbi.nlm.nih.gov/25888170/; e087: PMC4475878 sec3-1; Figures2–3 (binding and 23-bp footprint), Figure4 (expression context); e087: PMC4475878 sec2-3; Table1; Table2; e088: PMC4475878 sec3-2,sec3-3,sec4; Figure5; reinterpretation of the1999 cassette-insertion phenotype; e088: PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic keto-CoA effector); Figures6–8; e088: PMC4475878 sec2-3; Table1; Table2; e089: PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic keto-CoA effector); Figures6–8; e089: PMC4475878 sec2-3; Table1; Table2 | supports | BadR and BadM Proteins Transcriptionally Regulate Two Operons Needed for Anaerobic Benzoate Degradation by Rhodopseudomonas palustris. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/fourth/PMC4475878.html |
| source-033 | https://pubmed.ncbi.nlm.nih.gov/17041049/; e087: PMC1698244 main text; Tables1,2; Figures2–4 | supports | BadM Is a Transcriptional Repressor and One of Three Regulators That Control Benzoyl Coenzyme A Reductase Gene Expression in Rhodopseudomonas palustris. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/followup/PMC1698244.html |
| source-034 | https://pubmed.ncbi.nlm.nih.gov/10094687/; e090: PMC93622 sec10–sec15; Table2; Figures2–4 | supports | BadR, a New MarR Family Member, Regulates Anaerobic Benzoate Degradation by Rhodopseudomonas palustris in Concert with AadR, an Fnr Family Member. Reuses this reviewer’s prior independent reading of actual claim-supporting original methods/results/discussion paragraphs and captions, including surrounding negative/conflicting evidence. The complete maintained claims were freshly read and original bytes freshly rebound; no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/third/PMC93622.html |
| source-035 | https://pubmed.ncbi.nlm.nih.gov/30327443/; e091: PMC6191541 s2.1–s2.3; Figures2–6; e092: PMC6191541 s2.5; Figures 8 and 9; reagent s4.1; preparation s4.3; e092: PMC6191541 s4.3; unavailable supplementary protocol is not read; e093: PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; e093: PMC6191541 s4.3; unavailable supplementary protocol is not read; e094: PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; e094: PMC6191541 s4.3; unavailable supplementary protocol is not read; e099: PMC6191541 s2.3 / Figure 6A-C; s2.4 / Figure 7; s4.3; e099: PMC6191541 s4.3; complete supplementary construct protocol unavailable; e100: PMC6191541 s2.3 / Figure 6A-C; s2.4 / Figure 7; s4.3; e100: PMC6191541 s4.3; complete supplementary construct protocol unavailable | supports | Small-Molecule Acetylation Controls the Degradation of Benzoate and Photosynthesis in Rhodopseudomonas palustris. Reuses this reviewer’s independent reading of the complete 2018 main text and all 14 figures during regulatory review. Unavailable supplements and exact construct/tag details remain unavailable. Current claim-to-original binding freshly checked. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/fourth/PMC6191541.html |
| source-036 | https://www.uniprot.org/uniprotkb/O87876/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O87876. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87876.json |
| source-037 | https://www.uniprot.org/uniprotkb/O87875/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O87875. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87875.json |
| source-038 | https://www.uniprot.org/uniprotkb/O87874/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O87874. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87874.json |
| source-039 | https://www.uniprot.org/uniprotkb/O87877/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O87877. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87877.json |
| source-040 | https://www.uniprot.org/uniprotkb/O07460/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07460. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07460.json |
| source-041 | https://www.uniprot.org/uniprotkb/O07461/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07461. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07461.json |
| source-042 | https://www.uniprot.org/uniprotkb/O07462/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07462. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07462.json |
| source-043 | https://www.uniprot.org/uniprotkb/O07463/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07463. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07463.json |
| source-044 | https://www.uniprot.org/uniprotkb/O07456/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07456. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07456.json |
| source-045 | https://www.uniprot.org/uniprotkb/O07457/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07457. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07457.json |
| source-046 | https://www.uniprot.org/uniprotkb/O07453/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07453. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07453.json |
| source-047 | https://www.uniprot.org/uniprotkb/Q2LQN9/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:Q2LQN9. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q2LQN9.json |
| source-048 | https://www.uniprot.org/uniprotkb/Q6N3I0/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:Q6N3I0. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3I0.json |
| source-049 | https://www.uniprot.org/uniprotkb/Q6N3I1/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:Q6N3I1. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3I1.json |
| source-050 | https://www.uniprot.org/uniprotkb/Q6N3H7/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:Q6N3H7. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3H7.json |
| source-051 | https://www.uniprot.org/uniprotkb/Q6N3H9/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:Q6N3H9. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3H9.json |
| source-052 | https://www.uniprot.org/uniprotkb/Q01980/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:Q01980. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-Q01980.json |
| source-053 | https://www.uniprot.org/uniprotkb/O07458/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07458. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-O07458.json |
| source-054 | https://www.uniprot.org/uniprotkb/O07465/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:O07465. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-O07465.json |
| source-055 | https://www.uniprot.org/uniprotkb/G3XCQ2/entry; Record reference and native identity/component context | supports | Complete issuing UniProtKB record UniProtKB:G3XCQ2. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-G3XCQ2.json |
| source-056 | https://pubmed.ncbi.nlm.nih.gov/9108255/; e061: pp841–845; Table1; Figures1–5 | supports | Benzoyl-CoA reductase (dearomatizing), a key enzyme of anaerobic aromatic metabolism. A study of adenosinetriphosphatase activity, ATP stoichiometry of the reaction and EPR properties of the enzyme. Explicit prior acceptance reused; bound cached original PDF text title and printed843,844,848 inspected for ATPase/stoichiometry and nonunique cluster assignment. Preserve previous visual747 versus cached741 correction; no fresh full13page/visual read claimed. This qualified prior reading is reused; the title page was personally viewed during the independent correction review. Current original bytes and maintained claims were freshly rebound. Original binding: /private/tmp/pathwaymech-next-267-primary/reused/prior266-primary-packet.tar.gz :: inputs/chemistry/originals/PMID-9108255.pdf |
| source-057 | https://pubmed.ncbi.nlm.nih.gov/12081970/; e061: Methods; Figure3; Tables3–4; Figure5 | supports | Properties of 2-Oxoglutarate:Ferredoxin Oxidoreductase from Thauera aromatica and Its Role in Enzymatic Reduction of the Aromatic Ring. Bound full HTML original; citation title and actual reconstitution Methods/Results, donor versus intrinsic clusters, contaminating hydratase, Methods0.0325mg versus caption0.325mg examined. Qualified prior independent reading reused; current maintained claim and bound original bytes checked. Original binding: /private/tmp/pathwaymech-next-267-primary/reused/prior266-primary-packet.tar.gz :: originals/PMC135165.html |
| source-058 | https://pubmed.ncbi.nlm.nih.gov/10903310/; e083: Europe PMC CORE JSON $.resultList.result[0].abstractText, sentences 3–4; indexed abstract only. Complete paper and spectra not examined. | supports | EPR and Mössbauer studies of benzoyl-CoA reductase.. Complete7803-byte EuropePMC core original/abstract read; fullpaper inaccessible scope retained. Qualified prior independent reading reused; current maintained claim and bound original bytes checked. Original binding: /private/tmp/pathwaymech-next-267-primary/reused/prior266-primary-packet.tar.gz :: inputs/chemistry/originals/PMID-10903310-EuropePMC-core.json |
| source-059 | https://pubchem.ncbi.nlm.nih.gov/compound/6971; e092: PropertyTable.Properties[0]; full atom/bond structure and ring-position replay bound in regulatory chemistry owner | supports | N-acetylanthranilic acid. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-regulatory-chemistry/originals/pubchem-6971-properties.json |
| source-060 | https://pubchem.ncbi.nlm.nih.gov/compound/48847; e093: PropertyTable.Properties[0]; full atom/bond structure and ring-position replay bound in regulatory chemistry owner | supports | 3-Acetamidobenzoic acid. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-regulatory-chemistry/originals/pubchem-48847-properties.json |
| source-061 | https://pubchem.ncbi.nlm.nih.gov/compound/19266; e094: PropertyTable.Properties[0]; full atom/bond structure and ring-position replay bound in regulatory chemistry owner | supports | p-Acetamidobenzoic acid. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-regulatory-chemistry/originals/pubchem-19266-properties.json |
| source-062 | https://www.rhea-db.org/rhea/28551; e095: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_3530; http://rdf.rhea-db.org/Compound_3530; e096: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4271; http://rdf.rhea-db.org/Compound_4271; e097: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4182; http://rdf.rhea-db.org/Compound_4182; e098: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_1264; http://rdf.rhea-db.org/Compound_1264 | supports | anthranilate + acetyl-CoA =&gt; N-acetylanthranilate + CoA. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-chemistry/originals/rhea/rhea.rdf.gz |
| source-063 | https://www.uniprot.org/uniprotkb/Q2W1S9; e099: primaryAccession; genes; organism.taxonId; sequence | supports | N-acetyltransferase domain-containing protein. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-Q2W1S9.json |
| source-064 | https://www.uniprot.org/uniprotkb/Q39TU9; e100: primaryAccession; genes; organism.taxonId; sequence | supports | Acetyltransferase, putative. Exact issuing source object retained and bound. Native reaction/material/component assertions were directly reconstructed from whole XML objects; identity or metadata support is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-Q39TU9.json |
| record | data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml | supports | Entire actual 2,053-line maintained record read, including every node, edge, reference, source assertion, locator and endpoint qualifier. |
| science-replay | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/maintained-scientific-replay.json | supports | Independent 1,658-assertion replay binds all 80 authorities, 100 edges, 64 sources, 9 native steps and 511 actual page fields. Required full corpus gates remain separate. |
| edge-ledger | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/all-100-maintained-edge-assessments.json | supports | Complete claim-specific assessment of every maintained edge and its evidence/qualifier context. |
| authority-ledger | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/all-80-maintained-authority-assessments.json | supports | All 80 declared identities agree with actual adopted authoritative terms, labels and entity categories; experimental roles remain separately evaluated. |
| native-materials | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/actual-native-material-replay.json | supports | Direct replay of all 42 source material occurrences with exact native frames, coefficients, chosen directions and source locators. |
| source-authority | data/identifier_authorities/sources.json | supports | Actual full source union contains 3,221 terms/1,209 owners; all selected identities independently compared with frozen planned exact term values. |
| ontology-authority | data/identifier_authorities/ontology.json | supports | Actual ontology union contains 2,196 terms and five owners; formal chemistry and existing anthranilate reuse remain distinct from assay reagents. |
| prior-science | /private/tmp/pathwaymech-next-267-independent-full-design-review/HANDOFF.md | supports | Independent complete design review found four minor defects and retained a needs-curation verdict. Its full primary-reading scope, source closure and scientific assessments are explicitly reused, with current maintained adoption freshly verified. |
| prior-corrections | /private/tmp/pathwaymech-next-267-independent-design-successor-review/HANDOFF.md | supports | Independent bounded correction acceptance resolved external findings R01–R04 (#600–603): exact abstract attribution, four original titles, 23 displayed prose fields and six synthetic-member metadata rows. Original review remains unchanged; no fabricated canonical predecessor. |
| primary-reading-scope | /private/tmp/pathwaymech-next-267-independent-full-design-review/primary-reading-scope.json | supports | Exact prior original reading depths and unavailable material delimit reuse for this maintained review. |
| scope-search | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/maintained-scope-and-lineage.json | supports | 264 maintained records: exactly one P321 target and all 263 previous records exact. No prior canonical review for this target was found in the bounded review inventory. |
| imodulondb | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/imodulondb-assessment.json | supports | Existing CLAW structured runner successfully returned 28 dataset rows across 20 organisms; none cover the selected native organisms or the older Magnetospirillum name. Expression-host E. coli/P. aeruginosa coverage does not establish target native regulation. |
| actual-page | pages/records/MetaCyc_P321-PWY.html | supports | Actual native rendered page preserves 511 reviewed textual fields, all 64 reference titles/URLs/source versions and 100 graph edges. Source hashes remain in YAML/export; the renderer does not display them as bibliography text. |
| root-exports-visual | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/root-receipt-intake.json | supports | Root native export comparisons and browser measurements rebound. Reviewer independently parsed all 100 edge/80 context comparison rows, checked output hashes and personally viewed three actual-page screenshots. Runtime interaction checks are root-owned. |
| research-draft | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/research-draft-assessment.json | supports | Separate full research-draft read and formal-net/evidence-count calculation agrees with maintained science. Shorter-purification wording recommendation concerns clarity, not altered sequence identity. Final maintained report and retention not yet bound. |
| initial-native-validate | /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/initial-native-validate-receipt.json | supports | Root full native validate returned zero for all 264 records, 20,651 evidence blocks and current pages. Complete 573-byte log and exact terminal receipt were rebound. This is the code/corpus cutoff preceding final retention/report adoption. |

## Limits And Additional Notes

- Provisional external preparation only: full terminal corpus gate receipts and final maintained evidence retention/report bindings remain pending. No completed canonical review or publication approval is claimed.
- Primary literature interpretation explicitly reuses this reviewer’s earlier independent original readings at their documented depth. Fresh current work reads the whole maintained record and rebinds original bytes; it is not a fabricated new whole-paper review.
- PMID10903310 support is the retained complete metadata/abstract, not inaccessible full spectroscopy text. Unavailable supplements and exact missing construct/tag/linker details remain unknown.
- Unassigned eighth catalyst, isolated lower C7 Pim activities, physiological ETF coupling, BadM physiological ligand and exact meta/para acetylation activity identifiers remain open scientific gaps already represented in the record.
- Structured-source catalog coverage and finite source/archive searches do not establish biological absence or global source/literature exhaustion.
- Visual work is a smoke check of root-captured actual-page screenshots plus root browser measurements; no accessibility/cross-browser audit or fresh visual reading of every source PDF/image interior.
- Public-release licensing is the separate later decision requested by the user; scientific review does not resolve source licensing.
- External original design findings #600–603 have independent correction acceptance. They are not invented canonical predecessors or issue closures.
- No maintained/source/Git/GH/runtime writes, package installs, curation-history actions or scientific status promotions performed by this reviewer.
- This timestamp ends the provisional draft assessment pass; final follow-up must reinspect changes, use an actual final UTC finish and regenerate the review_id.

## Complete Structured Record

The sibling review.yaml is authoritative.

```yaml
schema_version: 1.0.0
review_id: 20261015T202656Z-benzoyl-coa-iii-scientific-preparation
kind: record
repository: CultureBotAI/PathwayMech
title: 'Scientific review preparation: benzoyl-CoA degradation III (anaerobic)'
started_at: '2026-10-15T20:11:06Z'
finished_at: '2026-10-15T20:26:56Z'
reviewer:
  identity: /root/next267_regulatory_acceptance
  kind: agent
  independence: independent
  independence_basis: Reviewer independently reviewed frozen scientific design and
    corrections, and authored no maintained scientific or authority implementation
    change. Scientific design and corrections were authored by another agent; adoption
    and final integration are root-owned.
skill: .claude/skills/review-yaml-record/SKILL.md
completion: partial
verdict: pass_with_limitations
scientific_review: true
summary: 'The entire actual maintained P321 record has a supported bounded scientific
  assessment: all 80 identities, 100 edges, 196 evidence items, 64 references, nine
  native reactions and separate auxiliary chemistry retain their source and assay
  limitations. No new actionable scientific defect was found. This external draft
  remains partial until final native gate receipts and maintained retention/report
  adoption are rebound; no canonical persistence or publication approval is implied.'
source:
  git_revision: 02bc234143d40e0e825737f27dfdcb5fd358322f
  state: working_tree
  inputs:
  - path: .claude/skills/add-pathway/SKILL.md
    sha256: f0d394f29cad1a1cd6a004abceb5f59f8e567d6b885cd6c4ff07c629c4d6db7a
    role: context
  - path: .claude/skills/review-yaml-record/SKILL.md
    sha256: 6a57ac6065171e35499578522a38c576e7bf7b6213286487d6cc0947fc477f3f
    role: context
  - path: CLAUDE.md
    sha256: c067d99547f9e9e9a6edb892d71126b6765239348d0021b907f3102907a4cf00
    role: context
  - path: conf/identifier_policy.yaml
    sha256: f57137cbec6ee2ffb4abc1c2e448dd93766e37edac9b07c43cab24c5809d27f7
    role: context
  - path: conf/identifier_sources.json
    sha256: c5b0224296302efea9e11f231d79e254c29df8eb1f8c08f4e0fdcee77d07dc4f
    role: context
  - path: conf/record_review.yaml
    sha256: a2d6578719a7d080eadc9520695ea7203618b0a7b274ee78fb25dbc17794876b
    role: context
  - path: conf/rhea_identifier_updates.json
    sha256: 8502da3089b5df4bc81d5ac6efa51454a2fe785f69cce4dbd4e4193e9484ba0a
    role: context
  - path: data/identifier_authorities/ontology.json
    sha256: 35731826db801575035eb91ad610427790349c3bdbcd0af1dfcbb5234648ee65
    role: context
  - path: data/identifier_authorities/sources.json
    sha256: 6463275f8ee68e5bc55a84e796836a8dd04f441df4e020b939761c267ea5b553
    role: context
  - path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    sha256: 40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51
    role: target
  - path: docs/CAUSAL_GRAPHS.md
    sha256: 4f3f46d1f4b8ebafa9b2d04d9700510df18b6ec6f881856fda521879f494d153
    role: context
  - path: docs/CURATION.md
    sha256: 408f7c7705b4e6d667b513920e4c39612162d549e0c2666d85bfd53b2c2687f7
    role: context
  - path: docs/HARMONIZATION.md
    sha256: 072884773d626ea909bd1e4f275901f0a6053f660d5e68a294ee54149b6496b0
    role: context
  - path: docs/IDENTIFIERS.md
    sha256: 6d51dd8cdcc0ee4c0f285bc0769885cfe0444235957b4f3d2312ee646437be60
    role: context
  - path: docs/record-review-profile.md
    sha256: f3f00eebb7841e9d5ac891271e269f45e926995e16856b8e9a885436570c7819
    role: context
  - path: docs/record-reviews.md
    sha256: 452a19ab688276747b7c4308523a14d4d99c1c39ef6909ae8a90b85b7a9b3e9b
    role: context
  - path: justfile
    sha256: 6d3df7c8fb17835c316a5f37a59c0ff7e61541bbb0781d4dd62ee6ec5fce7df2
    role: context
  - path: pages/assets/pathway-network.css
    sha256: ffe62865f9ede1d8ae7c361a5576823921c850542cf03d2ca7b3c945d63d7645
    role: context
  - path: pages/assets/pathway-network.js
    sha256: 23b6fc25a1522c945cf61b7c269dadf93a90b8c78c357652e6653a05bcb97eac
    role: context
  - path: pages/records/MetaCyc_P321-PWY.html
    sha256: 023a4d76d157dc058becdfaca6e1b25dfae33140c89214987d8d25ca8b05c730
    role: context
  - path: pages/style.css
    sha256: e4516964a76d665e2b4f098764656866bc5f673b72ab67badb1def724fb3e44c
    role: context
  - path: schema/record_review.yaml
    sha256: 229baf9b69118a1fe318e4c31085c0820e4e3d1365e7b04d6ace451b7c35f9bb
    role: context
  - path: scripts/record_review.py
    sha256: 95a4ec41e38ec47ba3578e76838c46a0adbf47e49ad3636524735d08cfcb1c4d
    role: context
  - path: src/pathwaymech/cli.py
    sha256: a170e60e3c398755a21e1304e3bec9e2af743af46ca62de3bbb47ea878ca0b7e
    role: context
  - path: src/pathwaymech/graph_view.py
    sha256: 45bbedd4459f21d4189e3eeb35504ff71ba664e975f4cdde7250a61e9ae3215b
    role: context
  - path: src/pathwaymech/schema.py
    sha256: bd99c1e6ca1f6eec5c82c58aa1ae3f43f696d30be66fbe0977dcace81292e0b8
    role: context
  - path: src/pathwaymech/schema/mech_shared.yaml
    sha256: c2e7054fd32635e380c698282bd886a9105861009b9f0474f02bb1b80865e895
    role: context
  - path: src/pathwaymech/schema/pathwaymech.yaml
    sha256: c66be7d0ae830e5041608eb6b2ce9755c601ed596ec9df5fb3567d41b202478b
    role: context
  - path: src/pathwaymech/site_display.py
    sha256: f70d143af1d9be9c72e73c736ae4ce3e0b7abfbf24f82b814235f7a9670e9a73
    role: context
  - path: src/pathwaymech/strict.py
    sha256: 2f6a7edf501952ee4aaa41be2f9512d20e1edb2dd87a22b6add6d26928c0dc84
    role: context
scope:
  description: One complete actual maintained pathway record, every declared identity,
    edge, endpoint qualifier and reference, actual render/export contexts, and exact
    explicitly reused independent source assessments.
  selection: Root-assigned new maintained MetaCyc:P321-PWY record adopted from accepted
    correction successor SHA256 40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51.
  coverage: full
  population_size: 1
  reviewed_target_ids:
  - MetaCyc:P321-PWY
  exclusions:
  - target: Other 263 maintained records
    reason: Exact preservation/dedup context checked; no fresh scientific reassessment.
  - target: Authority-profile implementation and full native build
    reason: Separately independently reviewed/root-verified; this review evaluates
      actual selected scientific consumers and binds receipts.
  - target: Public release and licensing
    reason: Separate later user-directed decision.
targets:
- target_id: MetaCyc:P321-PWY
  path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  label: benzoyl-CoA degradation III (anaerobic)
  record_class: PathwayRecord
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: Maintained scientific assertions, node identities, qualifiers and references
checks:
- check_id: scientific-replay
  name: Complete actual maintained scientific replay
  status: passed
  required: true
  summary: 1,658 assertions; complete target/source/authority/page coverage.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - science-replay
  command: Verified 263 Python -B replay_maintained_science_v2.py
  exit_code: 0
  expected_exit_code: 0
- check_id: scope-lineage
  name: Actual maintained population and prior-review inventory
  status: passed
  required: true
  summary: 264 records; 263 previous bytes unchanged; exact one target; no earlier
    canonical target review within complete hidden/ignored-inclusive inventory.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - scope-search
  command: Verified 263 Python -B maintained_scope.py
  exit_code: 0
  expected_exit_code: 0
- check_id: structured-catalog
  name: Required structured iModulonDB catalog route
  status: passed
  required: true
  summary: Existing CLAW runner successfully returned complete available dataset catalog.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - imodulondb
  command: PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 .venv/bin/python -B .venv/bin/kg-microbe-sources
    imodulondb --timeout 30 datasets
  exit_code: 0
  expected_exit_code: 0
- check_id: structured-search
  name: Organism search and module summarization
  status: not_applicable
  required: true
  summary: No selected native organism has a dataset in returned catalog; no unsupported
    host-based substitution.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - imodulondb
- check_id: native-render
  name: Actual native render-pages
  status: passed
  required: true
  summary: 'Root terminal-zero receipt: all 264 records rendered. Actual target page
    freshly checked.'
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - actual-page
  - root-exports-visual
  command: just render-pages (root-owned terminal receipt)
  exit_code: 0
  expected_exit_code: 0
- check_id: native-kgx
  name: Native KGX export fidelity
  status: passed
  required: true
  summary: 'Root export receipt fully parsed and output hashes rebound: all 100 new
    edges/80 contexts, every qualifier, 13,689 previous edge rows preserved.'
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - root-exports-visual
- check_id: browser
  name: Actual desktop/mobile page smoke check
  status: passed
  required: true
  summary: Root browser measurements and reviewer direct view of all three captured
    screenshots support bounded visual acceptance.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - root-exports-visual
- check_id: vendored
  name: Native vendored gate
  status: passed
  required: true
  summary: Root native terminal-zero receipt binds 22 artifacts to canonical pin a5d562962c75a2ad9efd8160b548df5944315422.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - root-exports-visual
  command: just vendored-check (root-owned terminal receipt)
  exit_code: 0
  expected_exit_code: 0
- check_id: validate
  name: Required full corpus just validate
  status: passed
  required: true
  summary: Root native full-corpus validation passed for 264 records and 20,651 evidence
    blocks. Actual complete log and terminal receipt independently bound; cutoff precedes
    final retention/report adoption.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - initial-native-validate
  command: just validate (root-owned terminal receipt)
  exit_code: 0
  expected_exit_code: 0
- check_id: test
  name: Required full corpus just test
  status: unavailable
  required: true
  summary: Root owns live native gates; terminal receipt and final reviewed source
    cutoff not yet bound in this provisional content.
  target_ids:
  - MetaCyc:P321-PWY
  command: just test (pending terminal receipt; not rerun by reviewer)
- check_id: lint
  name: Required full corpus just lint
  status: unavailable
  required: true
  summary: Root owns live native gates; terminal receipt and final reviewed source
    cutoff not yet bound in this provisional content.
  target_ids:
  - MetaCyc:P321-PWY
  command: just lint (pending terminal receipt; not rerun by reviewer)
- check_id: diff-check
  name: Required full corpus git diff --check
  status: unavailable
  required: true
  summary: Root owns live native gates; terminal receipt and final reviewed source
    cutoff not yet bound in this provisional content.
  target_ids:
  - MetaCyc:P321-PWY
  command: git diff --check (pending terminal receipt; not rerun by reviewer)
- check_id: retention
  name: Final maintained evidence retention and research report
  status: unavailable
  required: true
  summary: Author retention and final report adoption not yet independently rebound.
    Current source originals and accepted external owners are verified; this is not
    final retained-input acceptance.
  target_ids:
  - MetaCyc:P321-PWY
evidence:
- evidence_id: source-001
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=P321-PWY
  locator: 'e001: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e002: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e003: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e004: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e005: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e006: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e007: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e008: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e009: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN''];
    e010: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN''];
    e011: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN''];
    e012: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN''];
    e013: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN''];
    e014: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN''];
    e015: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN''];
    e016: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN''];
    e017: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN''];
    e018: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN''];
    e019: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN''];
    e020: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN''];
    e021: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN''];
    e022: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN''];
    e023: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN''];
    e024: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN''];
    e025: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN''];
    e026: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN''];
    e027: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN''];
    e028: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN''];
    e029: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN''];
    e030: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN''];
    e031: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN''];
    e032: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN''];
    e033: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN''];
    e034: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN''];
    e035: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN''];
    e036: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN''];
    e037: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031''];
    e038: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031''];
    e039: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031''];
    e040: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031''];
    e041: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    e042: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    e043: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    e044: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    e045: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    e046: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    e047: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032''];
    e048: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032''];
    e049: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032''];
    e050: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032''];
    e051: /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032''];
    e052: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e053: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e054: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e055: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e056: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e057: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e058: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering];
    e059: /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout or self::reaction-ordering]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Pathway: P321-PWY. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-P321-PWY.xml'
  snapshot_sha256: b246f0fa3c425bebfe6394d2a639b683d3cd54fdd80d507221636dbc6215b236
- evidence_id: source-002
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=1.3.99.15-RXN
  locator: 'e002: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[1]; e003:
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[2]; e004: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[3];
    e005: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[4]; e006: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[1];
    e007: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[2]; e008: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[3];
    e009: /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[4]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: 1.3.99.15-RXN. Exact issuing source object
    retained and bound. Native reaction/material/component assertions were directly
    reconstructed from whole XML objects; identity or metadata support is distinguished
    from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-1.3.99.15-RXN.xml'
  snapshot_sha256: 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f
- evidence_id: source-003
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=R265-RXN
  locator: 'e011: /ptools-xml/Reaction[@frameid=''R265-RXN'']/right[1]; e012: /ptools-xml/Reaction[@frameid=''R265-RXN'']/right[2];
    e013: /ptools-xml/Reaction[@frameid=''R265-RXN'']/left[1]; e014: /ptools-xml/Reaction[@frameid=''R265-RXN'']/left[2];
    e015: /ptools-xml/Reaction[@frameid=''R265-RXN'']/left[3]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: R265-RXN. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R265-RXN.xml'
  snapshot_sha256: 867069c26bd93912c4e950e5ef8b7d6e32603683b3ad76191ffc498c54eaf516
- evidence_id: source-004
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=R266-RXN
  locator: 'e017: /ptools-xml/Reaction[@frameid=''R266-RXN'']/left[1]; e018: /ptools-xml/Reaction[@frameid=''R266-RXN'']/left[2];
    e019: /ptools-xml/Reaction[@frameid=''R266-RXN'']/right[1]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: R266-RXN. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R266-RXN.xml'
  snapshot_sha256: 61e325609080cc7cc74edb020f40b2dd50e36ff25507c0e5c7394c673f406e3c
- evidence_id: source-005
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=R267-RXN
  locator: 'e021: /ptools-xml/Reaction[@frameid=''R267-RXN'']/left[1]; e022: /ptools-xml/Reaction[@frameid=''R267-RXN'']/left[2];
    e023: /ptools-xml/Reaction[@frameid=''R267-RXN'']/right[1]; e024: /ptools-xml/Reaction[@frameid=''R267-RXN'']/right[2];
    e025: /ptools-xml/Reaction[@frameid=''R267-RXN'']/right[3]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: R267-RXN. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R267-RXN.xml'
  snapshot_sha256: 9ffcbe685107bc851f53cc9a69493495ba70abb04b86621ff88dfce984944faa
- evidence_id: source-006
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=R268-RXN
  locator: 'e027: /ptools-xml/Reaction[@frameid=''R268-RXN'']/left[1]; e028: /ptools-xml/Reaction[@frameid=''R268-RXN'']/left[2];
    e029: /ptools-xml/Reaction[@frameid=''R268-RXN'']/right[1]; e030: /ptools-xml/Reaction[@frameid=''R268-RXN'']/right[2]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: R268-RXN. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-R268-RXN.xml'
  snapshot_sha256: ec8e6f3e20ccb84bd8eec1cc37e07475c470f0664c26123253a4edf8e0043a6a
- evidence_id: source-007
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=1.3.1.62-RXN
  locator: 'e032: /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/left[1]; e033: /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/left[2];
    e034: /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/right[1]; e035: /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/right[2];
    e036: /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/right[3]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: 1.3.1.62-RXN. Exact issuing source object
    retained and bound. Native reaction/material/component assertions were directly
    reconstructed from whole XML objects; identity or metadata support is distinguished
    from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-1.3.1.62-RXN.xml'
  snapshot_sha256: 975c199ac8abeee57e73f3e232251c06dd84164dae32885daf445b0a35bf005d
- evidence_id: source-008
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=RXN-8031
  locator: 'e038: /ptools-xml/Reaction[@frameid=''RXN-8031'']/left[1]; e039: /ptools-xml/Reaction[@frameid=''RXN-8031'']/left[2];
    e040: /ptools-xml/Reaction[@frameid=''RXN-8031'']/right[1]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: RXN-8031. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-RXN-8031.xml'
  snapshot_sha256: f4211e1b2102f81999b9e57e4ffdf3ad4d1077ff302c30e7720ec89a88398772
- evidence_id: source-009
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=1.1.1.259-RXN
  locator: 'e041: /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/orphan; complete
    reaction object; e042: /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/left[1];
    e043: /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/left[2]; e044: /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[1];
    e045: /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[2]; e046: /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[3]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: 1.1.1.259-RXN. Exact issuing source object
    retained and bound. Native reaction/material/component assertions were directly
    reconstructed from whole XML objects; identity or metadata support is distinguished
    from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-1.1.1.259-RXN.xml'
  snapshot_sha256: b6591668c106849c13141da28a39ee82a6364e085b0dbd4ac30692af9567c502
- evidence_id: source-010
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=RXN-8032
  locator: 'e048: /ptools-xml/Reaction[@frameid=''RXN-8032'']/left[1]; e049: /ptools-xml/Reaction[@frameid=''RXN-8032'']/left[2];
    e050: /ptools-xml/Reaction[@frameid=''RXN-8032'']/right[1]; e051: /ptools-xml/Reaction[@frameid=''RXN-8032'']/right[2]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Reaction: RXN-8032. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-RXN-8032.xml'
  snapshot_sha256: e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a
- evidence_id: source-011
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1102
  locator: 'e060: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1102'']/*[self::enzyme
    or self::reaction or self::evidence]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1102. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1102.xml'
  snapshot_sha256: 861b31b7be3305955524f3acbc11915c8bba149a3fe232fd256dfc7dffe10121
- evidence_id: source-012
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/9177244/
  locator: 'e060: PMC21076 Results; Figures2–5; badE/badF mutant and complementation
    paragraphs; e063: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization
    paragraphs); e063: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization
    paragraphs); e074: PMC21076 Results; Figures2–5; badE/badF mutant and complementation
    paragraphs; e075: PMC21076 Results; Figures2–5; badE/badF mutant and complementation
    paragraphs; e076: PMC21076 Results; Figures2–5; badE/badF mutant and complementation
    paragraphs; e077: PMC21076 Results; Figures2–5; badE/badF mutant and complementation
    paragraphs; e080: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization
    paragraphs); e080: PMC21076 sec5, sec6 and sec8 (BadK assay and characterization
    paragraphs)'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'A cluster of bacterial genes for anaerobic benzene ring biodegradation.
    Reuses this reviewer’s prior independent reading of actual claim-supporting original
    methods/results/discussion paragraphs and captions, including surrounding negative/conflicting
    evidence. The complete maintained claims were freshly read and original bytes
    freshly rebound; no new whole-paper or whole-figure reading is claimed. Original
    binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC21076.html'
  snapshot_sha256: f3b8ce845719965b28841882aff9802aba4a7a42588e44bad3c39fc75ff75c98
- evidence_id: source-013
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1821
  locator: 'e061: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/*[self::enzyme
    or self::reaction or self::evidence]; e083: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/cofactor[Compound/@frameid=''CPD-7''];
    e084: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/cofactor[Compound/@frameid=''MG+2'']'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1821. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1821.xml'
  snapshot_sha256: fbb3bc99f1a1da7bd24e855e5ff55ae24c938a2c2d713689bade1e2b3054b7b6
- evidence_id: source-014
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-22280
  locator: 'e062: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-22280'']/*[self::enzyme
    or self::reaction or self::evidence]; e085: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-22280'']/cofactor[Compound/@frameid=''FAD'']'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-22280. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-22280.xml'
  snapshot_sha256: 3b7d9c9ecc60925d34c0b3772aef6d14cdcf7a0c98a9b12dcaf8803f81d4dcfd
- evidence_id: source-015
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/23667239/
  locator: 'e062: PMC3697644 Results Ch1CoA dehydrogenase; Figures3–6; Table2; e062:
    PMC3697644 Methods expression; Results recombinant enzyme; Table2; e062: PMC3697644
    Methods expression; Results recombinant enzyme; Table2; e073: PMC3697644 Methods
    expression; Results recombinant enzyme; Table2; e073: PMC3697644 Methods expression;
    Results recombinant enzyme; Table2; e073: PMC3697644 Methods expression; Results
    recombinant enzyme; Table2; e085: PMC3697644 Methods expression; Results recombinant
    enzyme; Table2; e085: PMC3697644 Methods expression; Results recombinant enzyme;
    Table2'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Cyclohexanecarboxyl-Coenzyme A (CoA) and Cyclohex-1-ene-1-Carboxyl-CoA
    Dehydrogenases, Two Enzymes Involved in the Fermentation of Benzoate and Crotonate
    in Syntrophus aciditrophicus. Reuses this reviewer’s prior independent reading
    of actual claim-supporting original methods/results/discussion paragraphs and
    captions, including surrounding negative/conflicting evidence. The complete maintained
    claims were freshly read and original bytes freshly rebound; no new whole-paper
    or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC3697644.html'
  snapshot_sha256: d91cb09e4d822ef4cd74e6fdc8f31701c981207a034b28a033c97a4555be7774
- evidence_id: source-016
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1144
  locator: 'e063: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1144'']/*[self::enzyme
    or self::reaction or self::evidence]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1144. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1144.xml'
  snapshot_sha256: a1460c41144068a44060da9f60f3bc354dcb95d3357cda2b33b1d2b09ae6130c
- evidence_id: source-017
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1104
  locator: 'e064: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1104'']/*[self::enzyme
    or self::reaction or self::evidence]; e086: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1104'']/cofactor[Compound/@frameid=''NAD'']'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1104. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1104.xml'
  snapshot_sha256: 67df556ed8cb676d2d81af9754efd365c3f6c5741197932e0ce090181820709a
- evidence_id: source-018
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/10781543/
  locator: 'e064: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e064: PMC101983
    sec4–sec10, sec15–sec18; Table1; Figures2–5; e079: PMC101983 sec17; Figure4 (purification/SDS-PAGE)
    and sec17 final paragraph (gel filtration/subunit mass); sec18 (CGA720 nonpolar
    mutant, retained BadI and native BadH immunoblot text; immunoblot data not shown);
    e079: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; e079: PMC101983 sec4–sec10,
    sec15–sec18; Table1; Figures2–5; e086: PMC101983 sec4–sec10, sec15–sec18; Table1;
    Figures2–5; e086: PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: '2-Hydroxycyclohexanecarboxyl Coenzyme A Dehydrogenase, an Enzyme Characteristic
    of the Anaerobic Benzoate Degradation Pathway Used by Rhodopseudomonas palustris.
    Reuses this reviewer’s prior independent reading of actual claim-supporting original
    methods/results/discussion paragraphs and captions, including surrounding negative/conflicting
    evidence. The complete maintained claims were freshly read and original bytes
    freshly rebound; no new whole-paper or whole-figure reading is claimed. Original
    binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC101983.html'
  snapshot_sha256: ca41160644aceaf3565144d651519b2baa940cd2907b5cc6e6c0e6944cf88eb7
- evidence_id: source-019
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-1103
  locator: 'e065: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1103'']/*[self::enzyme
    or self::reaction or self::evidence]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-1103. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-1103.xml'
  snapshot_sha256: 08cd5d1254c9a4eb9f31323eb5f3c8568c0bf6bc8aeca4e4f114a7446510ac5a
- evidence_id: source-020
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/9573182/
  locator: 'e065: PMC107172 sec16–sec18; Table1; Figures2–4; e065: PMC107172 substrate
    specificity and Discussion; Figure5; e078: PMC107172 substrate specificity and
    Discussion; Figure5'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: '2-Ketocyclohexanecarboxyl Coenzyme A Hydrolase, the Ring Cleavage Enzyme
    Required for Anaerobic Benzoate Degradation by Rhodopseudomonas palustris. Reuses
    this reviewer’s prior independent reading of actual claim-supporting original
    methods/results/discussion paragraphs and captions, including surrounding negative/conflicting
    evidence. The complete maintained claims were freshly read and original bytes
    freshly rebound; no new whole-paper or whole-figure reading is claimed. Original
    binding: /private/tmp/pathwaymech-next-267-primary/originals/PMC107172.html'
  snapshot_sha256: a8d81a6deb74b19eed4e371f09ceb30f0fd380c031d7410b8516eca7e5374e88
- evidence_id: source-021
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-26771
  locator: 'e066: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-26771'']/*[self::enzyme
    or self::reaction or self::evidence]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-26771. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-26771.xml'
  snapshot_sha256: c1446f497bc25a621c396fc0f5ad26ca8229fc082445d35b6971ee7125bed7c5
- evidence_id: source-022
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/15758219/
  locator: 'e066: PDF pp728,731,734; Figure1; e066: PDF pp729–734; Figures2,3; Table2;
    e067: PDF pp731,734; Figure1; e067: PDF pp729–734; Figures2,3; Table2; e068: PDF
    pp728,731,734; Figure1; e068: PDF pp729–734; Figures2,3; Table2; e081: PDF pp728,731,734;
    Figure1; e082: PDF pp728,731,734; Figure1'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'The pimFABCDE operon from Rhodopseudomonas palustris mediates dicarboxylic
    acid degradation and participates in anaerobic benzoate degradation. Bound publisher
    PDF and retained PDFKit text pages1,2,3,5,6,8 read for bibliography, predictions,
    whole-operon genetics, aerobic RNA condition, residual growth and pseudogene limits.
    No fresh PDF text engine or visual proof claimed. This qualified prior reading
    is reused; the title page was personally viewed during the independent correction
    review. Current original bytes and maintained claims were freshly rebound. Original
    binding: /private/tmp/pathwaymech-next-267-primary/acquisition/followup/PMID15758219-publisher-pdf.pdf'
  snapshot_sha256: d3cb08cb4c39d928e7c3b0e9591306823c7f7fad152d99359229a17da94e9344
- evidence_id: source-023
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-26772
  locator: 'e067: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-26772'']/*[self::enzyme
    or self::reaction or self::evidence]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-26772. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-26772.xml'
  snapshot_sha256: 53c97fa81dbf4ed5f027633058e250a8586f4d204e751c4fd21ab65c1ebdea30
- evidence_id: source-024
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=ENZRXN-26773
  locator: 'e068: /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-26773'']/*[self::enzyme
    or self::reaction or self::evidence]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Enzymatic-Reaction: ENZRXN-26773. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-ENZRXN-26773.xml'
  snapshot_sha256: 9677c4bfc4b02aed713044291908bb71a9d44d74ff5e06799819f0f1ab2ee8a3
- evidence_id: source-025
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-1341
  locator: 'e069: /Protein[@frameid="CPLX-1341"]/component[1]; e070: /Protein[@frameid="CPLX-1341"]/component[2];
    e071: /Protein[@frameid="CPLX-1341"]/component[3]; e072: /Protein[@frameid="CPLX-1341"]/component[4]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-1341. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-1341.xml'
  snapshot_sha256: c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf
- evidence_id: source-026
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-8778
  locator: 'e073: /Protein[@frameid="CPLX-8778"]/component[1]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-8778. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-8778.xml'
  snapshot_sha256: f6722d74c17b62a43b85b1d7565e6861414c3f4f7e7386bc9e183b2c1dea6b9f
- evidence_id: source-027
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-883
  locator: 'e074: /Protein[@frameid="CPLX-883"]/component[1]; e075: /Protein[@frameid="CPLX-883"]/component[2];
    e076: /Protein[@frameid="CPLX-883"]/component[3]; e077: /Protein[@frameid="CPLX-883"]/component[4]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-883. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-883.xml'
  snapshot_sha256: a79b3e4d3aa714e1b654fa42692cf0ac2e4831c90f166cfec6e5de5adf649ad1
- evidence_id: source-028
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-884
  locator: 'e078: /Protein[@frameid="CPLX-884"]/component[1]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-884. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-884.xml'
  snapshot_sha256: 8b2c2458253075c0f27242c44230eeb69615d0183c60bfc3be2d6ea6fcc610b6
- evidence_id: source-029
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-885
  locator: 'e079: /Protein[@frameid="CPLX-885"]/component[1]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-885. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-885.xml'
  snapshot_sha256: c8b0f094bd96e83b4b3ba9b5ee327a94393d1f0319010d05876b6942cbf58148
- evidence_id: source-030
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-926
  locator: 'e080: /Protein[@frameid="CPLX-926"]/component[1]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-926. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-926.xml'
  snapshot_sha256: 4361c52a8dce6eaebbcdfaa843711f54fe20f836a719abf3538be6f6fd2c7af8
- evidence_id: source-031
  kind: database
  reference: https://biocyc.org/META/NEW-IMAGE?object=CPLX-9349
  locator: 'e081: /Protein[@frameid="CPLX-9349"]/component[1]; e082: /Protein[@frameid="CPLX-9349"]/component[2]'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'MetaCyc 27.0 native Protein: CPLX-9349. Exact issuing source object retained
    and bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/originals/META-CPLX-9349.xml'
  snapshot_sha256: 148b45408de10fcf2f57444c6d4828eea36c66153e385d6b1af13a73eecb04a8
- evidence_id: source-032
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/25888170/
  locator: 'e087: PMC4475878 sec3-1; Figures2–3 (binding and 23-bp footprint), Figure4
    (expression context); e087: PMC4475878 sec2-3; Table1; Table2; e088: PMC4475878
    sec3-2,sec3-3,sec4; Figure5; reinterpretation of the1999 cassette-insertion phenotype;
    e088: PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic
    keto-CoA effector); Figures6–8; e088: PMC4475878 sec2-3; Table1; Table2; e089:
    PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic
    keto-CoA effector); Figures6–8; e089: PMC4475878 sec2-3; Table1; Table2'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'BadR and BadM Proteins Transcriptionally Regulate Two Operons Needed for
    Anaerobic Benzoate Degradation by Rhodopseudomonas palustris. Reuses this reviewer’s
    prior independent reading of actual claim-supporting original methods/results/discussion
    paragraphs and captions, including surrounding negative/conflicting evidence.
    The complete maintained claims were freshly read and original bytes freshly rebound;
    no new whole-paper or whole-figure reading is claimed. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/fourth/PMC4475878.html'
  snapshot_sha256: 0cd9fdf7ebd311613df03a9c0f7beadc883858b2f52b36bf26def545c262d5df
- evidence_id: source-033
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/17041049/
  locator: 'e087: PMC1698244 main text; Tables1,2; Figures2–4'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'BadM Is a Transcriptional Repressor and One of Three Regulators That Control
    Benzoyl Coenzyme A Reductase Gene Expression in Rhodopseudomonas palustris. Reuses
    this reviewer’s prior independent reading of actual claim-supporting original
    methods/results/discussion paragraphs and captions, including surrounding negative/conflicting
    evidence. The complete maintained claims were freshly read and original bytes
    freshly rebound; no new whole-paper or whole-figure reading is claimed. Original
    binding: /private/tmp/pathwaymech-next-267-primary/acquisition/followup/PMC1698244.html'
  snapshot_sha256: 5873f28015c4a8f396b58d4c4e0594ea955a7cf1b60f08c4ccbb187b2283bb9f
- evidence_id: source-034
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/10094687/
  locator: 'e090: PMC93622 sec10–sec15; Table2; Figures2–4'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'BadR, a New MarR Family Member, Regulates Anaerobic Benzoate Degradation
    by Rhodopseudomonas palustris in Concert with AadR, an Fnr Family Member. Reuses
    this reviewer’s prior independent reading of actual claim-supporting original
    methods/results/discussion paragraphs and captions, including surrounding negative/conflicting
    evidence. The complete maintained claims were freshly read and original bytes
    freshly rebound; no new whole-paper or whole-figure reading is claimed. Original
    binding: /private/tmp/pathwaymech-next-267-primary/acquisition/third/PMC93622.html'
  snapshot_sha256: a12d8a3ffe0143468d670890fdb0b54dce3f6dd53847a7f294cb63a4f1ce2907
- evidence_id: source-035
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/30327443/
  locator: 'e091: PMC6191541 s2.1–s2.3; Figures2–6; e092: PMC6191541 s2.5; Figures
    8 and 9; reagent s4.1; preparation s4.3; e092: PMC6191541 s4.3; unavailable supplementary
    protocol is not read; e093: PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation
    s4.3; e093: PMC6191541 s4.3; unavailable supplementary protocol is not read; e094:
    PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; e094: PMC6191541
    s4.3; unavailable supplementary protocol is not read; e099: PMC6191541 s2.3 /
    Figure 6A-C; s2.4 / Figure 7; s4.3; e099: PMC6191541 s4.3; complete supplementary
    construct protocol unavailable; e100: PMC6191541 s2.3 / Figure 6A-C; s2.4 / Figure
    7; s4.3; e100: PMC6191541 s4.3; complete supplementary construct protocol unavailable'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Small-Molecule Acetylation Controls the Degradation of Benzoate and Photosynthesis
    in Rhodopseudomonas palustris. Reuses this reviewer’s independent reading of the
    complete 2018 main text and all 14 figures during regulatory review. Unavailable
    supplements and exact construct/tag details remain unavailable. Current claim-to-original
    binding freshly checked. Original binding: /private/tmp/pathwaymech-next-267-primary/acquisition/fourth/PMC6191541.html'
  snapshot_sha256: 9573c41c1fd934e717b401ee80dc58146e13b4ccb2fb287ba7b5b5b52261cced
- evidence_id: source-036
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O87876/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O87876. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87876.json'
  snapshot_sha256: dc0df29747cc66cfc921d2f077e8e1dc1508d496e5fdfa28b6766693b77ae9ec
- evidence_id: source-037
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O87875/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O87875. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87875.json'
  snapshot_sha256: 4342bcbd9e4801d04b7c28d197b4961e1b9c543296d9115628fab9c42379560c
- evidence_id: source-038
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O87874/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O87874. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87874.json'
  snapshot_sha256: f352d1f3b0426184f3b09922be186b23d1a78d3a96c7e8239e04c82a5c550f70
- evidence_id: source-039
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O87877/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O87877. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O87877.json'
  snapshot_sha256: 105c88103b6f704595f041188d9d40207f9fcdc551d89f4a7dab315ac04cad3a
- evidence_id: source-040
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07460/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07460. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07460.json'
  snapshot_sha256: d2a25aa8e165720e30ba5e8df62323f1fa604c33455b390e9a9eef6a53bc3dfd
- evidence_id: source-041
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07461/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07461. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07461.json'
  snapshot_sha256: 7bfce0456732febe560993c3e942717841fa33b62265edcecc7d936a4f158f8f
- evidence_id: source-042
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07462/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07462. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07462.json'
  snapshot_sha256: f1d1ba52f37bc1d06517e986fa0bb4c63dc6dc873591a5d28f78b7731e54dbea
- evidence_id: source-043
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07463/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07463. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07463.json'
  snapshot_sha256: 188c17c5b6c2a649b231516e89cb06cd88dd5ce9ea9fa75c403b87681ed435b1
- evidence_id: source-044
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07456/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07456. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07456.json'
  snapshot_sha256: 0c9c40ee820ec6613ccb5c52303e2f739ef03e7b56c1c35ea4938b87dc8fcdaf
- evidence_id: source-045
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07457/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07457. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07457.json'
  snapshot_sha256: 7f0604cdec804074074b045836a3629fbe863232cbfbf976413620e85cd55124
- evidence_id: source-046
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07453/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07453. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-O07453.json'
  snapshot_sha256: 858bada2f2aba04a153e2383f3e62181fe6ebab731bbced906c1159f63658a1e
- evidence_id: source-047
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q2LQN9/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:Q2LQN9. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q2LQN9.json'
  snapshot_sha256: 5aa8e695b7f5e8c312ff5518f27af97c0e4c75ccb596789039fa50b4d30d50f2
- evidence_id: source-048
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q6N3I0/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:Q6N3I0. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3I0.json'
  snapshot_sha256: 51cf5e6d8416247d6740245b4acde3ac329ce854b35ad4be3d063d33f852eded
- evidence_id: source-049
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q6N3I1/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:Q6N3I1. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3I1.json'
  snapshot_sha256: ba05dd6e24b069531fb7ba5b03dc20e29e02ff20b6dff32138f55e8a671960d0
- evidence_id: source-050
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q6N3H7/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:Q6N3H7. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3H7.json'
  snapshot_sha256: e80b47e1c24bf7364e5b069ca9ae0d43db5031151a34ac7c1aeec5c58ad39cdb
- evidence_id: source-051
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q6N3H9/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:Q6N3H9. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/issuer-originals/UniProt-Q6N3H9.json'
  snapshot_sha256: 014f126359728a5e14f213600df78216983b54919ccd34283aa9662101e2338b
- evidence_id: source-052
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q01980/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:Q01980. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-Q01980.json'
  snapshot_sha256: d268c62aae2c7deb6d3d5bf3358f45f0386c34d8c19bd3f93356deaf380c56a3
- evidence_id: source-053
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07458/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07458. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-O07458.json'
  snapshot_sha256: 6073f7c89269f2554a7779b5c651534218ce4b4062065e12761acecc64530472
- evidence_id: source-054
  kind: database
  reference: https://www.uniprot.org/uniprotkb/O07465/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:O07465. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-O07465.json'
  snapshot_sha256: 46603198bc9147e6ecfb56eb12afa159412cc3542d7e07fca0ffe9828fa65dc5
- evidence_id: source-055
  kind: database
  reference: https://www.uniprot.org/uniprotkb/G3XCQ2/entry
  locator: Record reference and native identity/component context
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Complete issuing UniProtKB record UniProtKB:G3XCQ2. Exact issuing source
    object retained and bound. Native reaction/material/component assertions were
    directly reconstructed from whole XML objects; identity or metadata support is
    distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-G3XCQ2.json'
  snapshot_sha256: e78cf624dd7f6df93397bd67e543b5ca6d78104ffd22b465cebae27be7e79b79
- evidence_id: source-056
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/9108255/
  locator: 'e061: pp841–845; Table1; Figures1–5'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Benzoyl-CoA reductase (dearomatizing), a key enzyme of anaerobic aromatic
    metabolism. A study of adenosinetriphosphatase activity, ATP stoichiometry of
    the reaction and EPR properties of the enzyme. Explicit prior acceptance reused;
    bound cached original PDF text title and printed843,844,848 inspected for ATPase/stoichiometry
    and nonunique cluster assignment. Preserve previous visual747 versus cached741
    correction; no fresh full13page/visual read claimed. This qualified prior reading
    is reused; the title page was personally viewed during the independent correction
    review. Current original bytes and maintained claims were freshly rebound. Original
    binding: /private/tmp/pathwaymech-next-267-primary/reused/prior266-primary-packet.tar.gz
    :: inputs/chemistry/originals/PMID-9108255.pdf'
  snapshot_sha256: 064cc1b46d9fcfdc7e80098d49025b97e7fbbc352b1167ca1b2362d45c1173fe
- evidence_id: source-057
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/12081970/
  locator: 'e061: Methods; Figure3; Tables3–4; Figure5'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Properties of 2-Oxoglutarate:Ferredoxin Oxidoreductase from Thauera aromatica
    and Its Role in Enzymatic Reduction of the Aromatic Ring. Bound full HTML original;
    citation title and actual reconstitution Methods/Results, donor versus intrinsic
    clusters, contaminating hydratase, Methods0.0325mg versus caption0.325mg examined.
    Qualified prior independent reading reused; current maintained claim and bound
    original bytes checked. Original binding: /private/tmp/pathwaymech-next-267-primary/reused/prior266-primary-packet.tar.gz
    :: originals/PMC135165.html'
  snapshot_sha256: 26b04500469166d048b8b24618caf71d2d4af50fbb002eb2e5552362feaafd9e
- evidence_id: source-058
  kind: primary_source
  reference: https://pubmed.ncbi.nlm.nih.gov/10903310/
  locator: 'e083: Europe PMC CORE JSON $.resultList.result[0].abstractText, sentences
    3–4; indexed abstract only. Complete paper and spectra not examined.'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'EPR and Mössbauer studies of benzoyl-CoA reductase.. Complete7803-byte
    EuropePMC core original/abstract read; fullpaper inaccessible scope retained.
    Qualified prior independent reading reused; current maintained claim and bound
    original bytes checked. Original binding: /private/tmp/pathwaymech-next-267-primary/reused/prior266-primary-packet.tar.gz
    :: inputs/chemistry/originals/PMID-10903310-EuropePMC-core.json'
  snapshot_sha256: b8716d4910433f5ee90740c9e1c1c3bb138a622879248147baf3398351e4d840
- evidence_id: source-059
  kind: database
  reference: https://pubchem.ncbi.nlm.nih.gov/compound/6971
  locator: 'e092: PropertyTable.Properties[0]; full atom/bond structure and ring-position
    replay bound in regulatory chemistry owner'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'N-acetylanthranilic acid. Exact issuing source object retained and bound.
    Native reaction/material/component assertions were directly reconstructed from
    whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-regulatory-chemistry/originals/pubchem-6971-properties.json'
  snapshot_sha256: 9385a2f899ecc168326f3215bc91f64b74c0ff473488539b6c0962d8b9a14102
- evidence_id: source-060
  kind: database
  reference: https://pubchem.ncbi.nlm.nih.gov/compound/48847
  locator: 'e093: PropertyTable.Properties[0]; full atom/bond structure and ring-position
    replay bound in regulatory chemistry owner'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: '3-Acetamidobenzoic acid. Exact issuing source object retained and bound.
    Native reaction/material/component assertions were directly reconstructed from
    whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-regulatory-chemistry/originals/pubchem-48847-properties.json'
  snapshot_sha256: ac47f6fb4eb685f76a7a58ce6c6516ab635eff70241029706d2975a0b7e2f9ef
- evidence_id: source-061
  kind: database
  reference: https://pubchem.ncbi.nlm.nih.gov/compound/19266
  locator: 'e094: PropertyTable.Properties[0]; full atom/bond structure and ring-position
    replay bound in regulatory chemistry owner'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'p-Acetamidobenzoic acid. Exact issuing source object retained and bound.
    Native reaction/material/component assertions were directly reconstructed from
    whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-regulatory-chemistry/originals/pubchem-19266-properties.json'
  snapshot_sha256: 677d831eeff18542731df4de1a524b3af621791a4b546cb2fc27400a00625242
- evidence_id: source-062
  kind: database
  reference: https://www.rhea-db.org/rhea/28551
  locator: 'e095: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_3530;
    http://rdf.rhea-db.org/Compound_3530; e096: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"];
    http://rdf.rhea-db.org/Participant_28550_compound_4271; http://rdf.rhea-db.org/Compound_4271;
    e097: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4182;
    http://rdf.rhea-db.org/Compound_4182; e098: rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"];
    http://rdf.rhea-db.org/Participant_28550_compound_1264; http://rdf.rhea-db.org/Compound_1264'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'anthranilate + acetyl-CoA => N-acetylanthranilate + CoA. Exact issuing
    source object retained and bound. Native reaction/material/component assertions
    were directly reconstructed from whole XML objects; identity or metadata support
    is distinguished from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-chemistry/originals/rhea/rhea.rdf.gz'
  snapshot_sha256: 8ee48d7044cf3eef1001fa730dae2a491902ab25b259b519d6826796bb8acedf
- evidence_id: source-063
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q2W1S9
  locator: 'e099: primaryAccession; genes; organism.taxonId; sequence'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'N-acetyltransferase domain-containing protein. Exact issuing source object
    retained and bound. Native reaction/material/component assertions were directly
    reconstructed from whole XML objects; identity or metadata support is distinguished
    from primary experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-Q2W1S9.json'
  snapshot_sha256: 22d3b450eceb9c8e1127d711c59620aef4c86b0d06b5b6c6e323b3ed31958187
- evidence_id: source-064
  kind: database
  reference: https://www.uniprot.org/uniprotkb/Q39TU9
  locator: 'e100: primaryAccession; genes; organism.taxonId; sequence'
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Acetyltransferase, putative. Exact issuing source object retained and
    bound. Native reaction/material/component assertions were directly reconstructed
    from whole XML objects; identity or metadata support is distinguished from primary
    experimental evidence. Original binding: /private/tmp/pathwaymech-next-267-native/new-issuer-originals/UniProt-Q39TU9.json'
  snapshot_sha256: 43eab5857ef5c15bbbb4f77479c4ccbbb314a1f138a362c02923ad3d46aba2a7
- evidence_id: record
  kind: record_content
  reference: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Entire actual 2,053-line maintained record read, including every node,
    edge, reference, source assertion, locator and endpoint qualifier.
  snapshot_sha256: 40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51
- evidence_id: science-replay
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/maintained-scientific-replay.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Independent 1,658-assertion replay binds all 80 authorities, 100 edges,
    64 sources, 9 native steps and 511 actual page fields. Required full corpus gates
    remain separate.
  snapshot_sha256: faef055f9b28976476b218fb1557a24118fcc970a74baaa0fef5d750997f5efd
- evidence_id: edge-ledger
  kind: record_content
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/all-100-maintained-edge-assessments.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Complete claim-specific assessment of every maintained edge and its evidence/qualifier
    context.
  snapshot_sha256: 379557302c25d4c3a1139a17e78114c989bc0fe23698c1847f1ae58b000dab1f
- evidence_id: authority-ledger
  kind: authority
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/all-80-maintained-authority-assessments.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: All 80 declared identities agree with actual adopted authoritative terms,
    labels and entity categories; experimental roles remain separately evaluated.
  snapshot_sha256: ee13cda91e52a8f3a252f841f03fe6d0aa3bd5cc6347474cfa3d57e70ad1d0e7
- evidence_id: native-materials
  kind: database
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/actual-native-material-replay.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Direct replay of all 42 source material occurrences with exact native frames,
    coefficients, chosen directions and source locators.
  snapshot_sha256: 43e0ae3fd824bda874474af8c7012607ff1763f4385d9e6f4d5418fc37b66f9a
- evidence_id: source-authority
  kind: authority
  reference: data/identifier_authorities/sources.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Actual full source union contains 3,221 terms/1,209 owners; all selected
    identities independently compared with frozen planned exact term values.
  snapshot_sha256: 6463275f8ee68e5bc55a84e796836a8dd04f441df4e020b939761c267ea5b553
- evidence_id: ontology-authority
  kind: authority
  reference: data/identifier_authorities/ontology.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Actual ontology union contains 2,196 terms and five owners; formal chemistry
    and existing anthranilate reuse remain distinct from assay reagents.
  snapshot_sha256: 35731826db801575035eb91ad610427790349c3bdbcd0af1dfcbb5234648ee65
- evidence_id: prior-science
  kind: prior_review
  reference: /private/tmp/pathwaymech-next-267-independent-full-design-review/HANDOFF.md
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Independent complete design review found four minor defects and retained
    a needs-curation verdict. Its full primary-reading scope, source closure and scientific
    assessments are explicitly reused, with current maintained adoption freshly verified.
  snapshot_sha256: 8252375b482f03482c28c9ed0314cde74a59c92076af4e4216fbb84013ebbd7e
- evidence_id: prior-corrections
  kind: prior_review
  reference: /private/tmp/pathwaymech-next-267-independent-design-successor-review/HANDOFF.md
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: 'Independent bounded correction acceptance resolved external findings R01–R04
    (#600–603): exact abstract attribution, four original titles, 23 displayed prose
    fields and six synthetic-member metadata rows. Original review remains unchanged;
    no fabricated canonical predecessor.'
  snapshot_sha256: 2c0cca359ae8cbcb332003de1946decc16f81d035f3668b61c42c9c14284c6da
- evidence_id: primary-reading-scope
  kind: prior_review
  reference: /private/tmp/pathwaymech-next-267-independent-full-design-review/primary-reading-scope.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Exact prior original reading depths and unavailable material delimit reuse
    for this maintained review.
  snapshot_sha256: 1e8891eaa5fbcd3a6849ed7c418362dcb65820bdc02cab6578da5abfb80a0d3f
- evidence_id: scope-search
  kind: search
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/maintained-scope-and-lineage.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: '264 maintained records: exactly one P321 target and all 263 previous records
    exact. No prior canonical review for this target was found in the bounded review
    inventory.'
  snapshot_sha256: a733043294aeed9c76797155d4ecb2febb9efd6a4e587ae6072c9ee8a4612ba2
  search_scope: Actual worktree data/pathways and reviews/structured recursively traversed
    using os.walk, including hidden and gitignored files; every pathway YAML and canonical
    review.yaml parsed. No global literature/source absence claim.
- evidence_id: imodulondb
  kind: search
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/imodulondb-assessment.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Existing CLAW structured runner successfully returned 28 dataset rows across
    20 organisms; none cover the selected native organisms or the older Magnetospirillum
    name. Expression-host E. coli/P. aeruginosa coverage does not establish target
    native regulation.
  snapshot_sha256: 592438bbad3f184208bb088ea7db2b5ea7280143d3034f401a59b935af46cf9b
  search_scope: Complete successful public GET catalog via kg-microbe-sources imodulondb
    --timeout 30 datasets; compare all selected native taxon names plus older Magnetospirillum
    name. Catalog coverage only, no biological negative inference; normalized runner
    output retained, not a claimed raw HTTP body.
- evidence_id: actual-page
  kind: record_content
  reference: pages/records/MetaCyc_P321-PWY.html
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Actual native rendered page preserves 511 reviewed textual fields, all
    64 reference titles/URLs/source versions and 100 graph edges. Source hashes remain
    in YAML/export; the renderer does not display them as bibliography text.
  snapshot_sha256: 023a4d76d157dc058becdfaca6e1b25dfae33140c89214987d8d25ca8b05c730
- evidence_id: root-exports-visual
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/root-receipt-intake.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Root native export comparisons and browser measurements rebound. Reviewer
    independently parsed all 100 edge/80 context comparison rows, checked output hashes
    and personally viewed three actual-page screenshots. Runtime interaction checks
    are root-owned.
  snapshot_sha256: 5104ae629ba4d4893b93a8e28126ac5dbe9d5715296c71eb24318d5cf39fbf64
- evidence_id: research-draft
  kind: record_content
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/research-draft-assessment.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Separate full research-draft read and formal-net/evidence-count calculation
    agrees with maintained science. Shorter-purification wording recommendation concerns
    clarity, not altered sequence identity. Final maintained report and retention
    not yet bound.
  snapshot_sha256: 7b1a54f5f82edd382a5bbb5a4e6e2f38365ee3d33daceb3d1ee13512a6e72ced
- evidence_id: initial-native-validate
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation/initial-native-validate-receipt.json
  accessed_at: '2026-10-15T20:26:56Z'
  support: supports
  summary: Root full native validate returned zero for all 264 records, 20,651 evidence
    blocks and current pages. Complete 573-byte log and exact terminal receipt were
    rebound. This is the code/corpus cutoff preceding final retention/report adoption.
  snapshot_sha256: e22a793557fb9291e490bfc8aeae9e48ebc9f8975c38100ee5c1d584320af9e7
assessments:
- assessment_id: pathway-identity
  area: identity
  topic: Exact route identity and source boundaries
  outcome: supported
  summary: P321 is the complete selected nine-step saturated-intermediate route; benzoate
    activation and downstream glutaryl-CoA degradation are outside it. Adjacent seven-step
    CENTBENZCOA is distinct. Current inventory contains one P321 and preserves all
    263 earlier records.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - record
  - scope-search
  - native-materials
  dimensions:
  - name: coverage
    value: 9 native reactions; 8 primary-material joins
    definition: Complete selected source route, not only the upper segment.
    evidence_ids:
    - record
    - scope-search
    - native-materials
  - name: source_object
    value: MetaCyc:P321-PWY
    definition: Exact native pathway object; similar names are not equivalence.
    evidence_ids:
    - record
    - scope-search
    - native-materials
- assessment_id: chemistry
  area: grounding
  topic: Exact structures, material states and carrier conventions
  outcome: supported
  summary: All 42 material occurrences/23 frames and 19 core molecular identities
    plus four generic carrier-state classes are accounted for. Charges, unspecified
    stereochemistry, E-specific lower enoyl intermediate and native carrier conventions
    are retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - native-materials
  - authority-ledger
  - ontology-authority
  details: 'Formal net: benzoyl-CoA + 2 reduced ferredoxin cluster units + 2 ATP +
    5 water + reduced ETF + 3 NAD + CoA -> 2 oxidized ferredoxin cluster units + 2
    ADP + 2 phosphate + oxidized ETF + 5 protons + 3 NADH + glutaryl-CoA + acetyl-CoA.
    This is symbolic source accounting, not measured whole-pathway flux or demonstrated
    physiological electron coupling.'
  dimensions:
  - name: evidence_tier
    value: Issuing structured chemistry plus primary assay interpretation
    definition: Source equation assertions are not relabelled as paper quotations.
    evidence_ids:
    - native-materials
    - authority-ledger
    - ontology-authority
  - name: carrier_unit
    value: Native generic redox-state/cluster unit
    definition: Two cluster units are not two whole two-cluster polypeptides.
    evidence_ids:
    - native-materials
    - authority-ledger
    - ontology-authority
- assessment_id: first-step
  area: evidence
  topic: BadDEFG genetics and purified Thauera BCR
  outcome: supported
  summary: BadDEFG enables is genetics-supported; purified Thauera BCR catalyzes is
    a separate preparation/taxon context. Neither means each monomer independently
    catalyzes.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-056
  - source-057
  details: Approximately 2 ATP per two electrons is qualified by uncoupled ATPase
    and a minor four-electron product. Whole donor proteins, donor cluster-state equation
    units, intrinsic BCR clusters and magnesium remain distinct.
  dimensions:
  - name: evidence_tier
    value: Mutant/complementation versus purified biochemical assay
    definition: Predicates preserve the strength and type of support.
    evidence_ids:
    - source-012
    - source-056
    - source-057
  - name: taxon_condition
    value: R. palustris operon genetics; purified T. aromatica BCR/donor reconstitution
    definition: Cross-species enzyme evidence does not prove purified native BadDEFG.
    evidence_ids:
    - source-012
    - source-056
    - source-057
- assessment_id: syntrophus-construct
  area: scope
  topic: Reverse-assay Syntrophus construct and physiological donor limit
  outcome: supported
  summary: Q2LQN9 is the native 414-aa protein; the reported 397-aa downstream-ATG
    segment plus C-terminal His6 is a separate construct. Reverse artificial-reductant
    diene reduction supports qualified enables, not measured physiological ETF coupling.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-015
  details: Expression host BL21 Star(DE3), tag/linker uncertainty and FAD text-versus-table
    occupancy conflict remain explicit. No unique cofactor occupancy or charge is
    asserted.
  dimensions:
  - name: component_role
    value: Native sequence versus experimental assembly/construct
    definition: Exact endpoint qualifiers prevent propagation of assay identity to
      a different native sequence.
    evidence_ids:
    - source-015
  - name: evidence_tier
    value: Recombinant reverse assay with Ti(III)/methyl viologen
    definition: A source generic-ETF equation is not a demonstrated physiological
      coupling experiment.
    evidence_ids:
    - source-015
- assessment_id: upper-enzymes
  area: evidence
  topic: BadK, BadH and BadI preparation-specific catalysis
  outcome: supported
  summary: BadK crude extract, tagged BadH and native purified BadI retain their actual
    preparation scope. BadH NAD-positive/NADP-negative and negative C7-substrate result
    do not fill the eighth step.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-018
  - source-020
  details: BadK crude E. coli DH5alpha/pDP111 activity is not purification or monomer
    proof. Native CPLX-926 omitted component coefficient stays unspecified. BadI four-column
    apparent homogeneity, approximately 90%-pure shorter preparation, and approximately
    5% intended substrate mixture refer to different quantities; no CoASH stimulation/free-acid
    activity or reverse ring closure is invented. Automated modern protein naming
    cannot override the assayed substrate.
- assessment_id: lower-route
  area: evidence
  topic: Pim predictions, whole-operon genetics and unassigned eighth catalyst
  outcome: supported
  summary: All lower native chemistry is retained while PimCD/PimF/PimB use predicted
    enables. The eighth putative reaction has no catalyst. The 772-nt pimE pseudogene
    is not an active protein.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-022
  details: Whole-operon growth/operon evidence, aerobic RNA context, residual growth
    and native wild-type caprylate growth are retained. Possible PimF bifunctionality
    and a formal NAD-versus-predicted-flavin distinction remain unresolved; isolated
    C7 catalysis is not inferred.
  dimensions:
  - name: evidence_tier
    value: Sequence prediction and whole-operon phenotype
    definition: Does not establish each isolated activity or a unique physiological
      route.
    evidence_ids:
    - source-022
  - name: source_object
    value: Native reaction 1.1.1.259-RXN with YES-PUTATIVE status
    definition: Material completion is separate from catalyst completion.
    evidence_ids:
    - source-022
- assessment_id: assemblies-cofactors
  area: graph
  topic: Native component and cofactor roles
  outcome: supported
  summary: All 16 monomer identities, seven assemblies, 14 component associations
    and four cofactor pointers preserve actual source roles, coefficients and assay
    qualification.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - authority-ledger
  - edge-ledger
  - source-058
  - source-015
  - source-034
  details: The corrected e083 spectroscopy assertion is limited to the retained PMID10903310
    abstract. It no longer attributes 1997 nonunique cluster discussion or a three-paper
    chronology to that abstract. AadR Fnr-family analogy is not measured fixed FeS
    occupancy; Syntrophus FAD occupancy conflict is retained.
- assessment_id: regulation
  area: evidence
  topic: BadM, BadR, AadR and genetic BadL/BadM relationships
  outcome: supported
  summary: Direct BadM/BadR promoter-binding and repression results are distinct from
    AadR-dependent expression and the genetic BadL/BadM relation. Historical BadR
    activation interpretation is revised by the later controlled repression evidence.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-032
  - source-033
  - source-034
  - source-035
  details: 23-bp BadM and 18-bp BadR footprints retain actual constructs and assay
    contexts. BadM 2015 tag-position conflict/163-aa reconstruction versus 156/154-aa
    native contexts, and BadR 182-aa tagged reconstruction versus 175-aa native sequence,
    are not silently reconciled. Keto-CoA binding effects provide no physiological
    concentration or Kd. No direct AadR binding, native BadL-BadM binding or BadM
    acetylation is inferred.
  dimensions:
  - name: evidence_tier
    value: Direct binding and promoter assay; genetics where direct evidence absent
    definition: Regulates is bounded by the edge-local preparation and mechanism statement.
    evidence_ids:
    - source-032
    - source-033
    - source-034
    - source-035
  - name: taxon_condition
    value: Native R. palustris biology with heterologous protein expression preparations
    definition: Host identity does not become native pathway taxon.
    evidence_ids:
    - source-032
    - source-033
    - source-034
    - source-035
- assessment_id: three-ligands
  area: grounding
  topic: Three exact assay reagents and BadM effects
  outcome: supported
  summary: Ortho PubChem6971, meta48847 and para19266 are distinct neutral C9H9NO3
    reagents. All measured BadM effects remain represented without treating reagent
    acids as formal anions or depicted zwitterions.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - authority-ledger
  details: Nominal 10 mM EMSA conditions with 72 nM BadM and 12 nM 212-bp probe, no
    effect at 5 mM ortho, and meta/para solubility/precipitation limits are explicit.
    These do not identify a physiological ligand, establish affinity rank or permit
    a Kd inference.
- assessment_id: auxiliary-homologs
  area: scope
  topic: Exact ortho auxiliary chemistry and two homolog preparations
  outcome: supported
  summary: RHEA28551 is the balanced anthranilate + acetyl-CoA(4-) -> N-acetylanthranilate
    + CoA(4-) reaction, with four material and two qualified catalyst edges outside
    native P321 membership/order.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - authority-ledger
  - ontology-authority
  details: Q2W1S9 from current P. magneticum AMB-1 and Q39TU9 from G. metallireducens
    GS-15 retain separate native length/taxon and reported JE9314 expression contexts.
    Both homologs have TLC-supported ortho/meta/para products; only MmBadL meta product
    has reported direct HPLC/MS comparison. Below-background kinetics cannot establish
    preference/constants. Exact meta/para activity identifiers remain gaps; no native
    RpBadL catalysis or tenth P321 step is inferred.
- assessment_id: taxa
  area: scope
  topic: Taxon, strain, expression host and construct specificity
  outcome: supported
  summary: All seven source/assay taxa and exact native sequence mappings are retained;
    they are not a claim that all seven complete the entire pathway.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - authority-ledger
  - edge-ledger
  details: Experimental constructs are qualified endpoints, not new native identity
    assertions. The AMB-1 taxon spelling update is issuing taxonomy identity; older
    Magnetospirillum wording remains the publication context.
  dimensions:
  - name: taxon_condition
    value: R. palustris/CGA009; T. aromatica/K172; S. aciditrophicus SB; P. magneticum
      AMB-1; G. metallireducens GS-15
    definition: Source or experimental contexts with edge-specific evidence.
    evidence_ids:
    - authority-ledger
    - edge-ledger
  - name: component_role
    value: Native protein, assembly, gene, construct, reaction, molecular participant
      and carrier state
    definition: Roles are kept distinct in declared nodes and qualified endpoints.
    evidence_ids:
    - authority-ledger
    - edge-ledger
- assessment_id: claim-accounting
  area: provenance
  topic: Full claim/source coverage and honest primary-reading depth
  outcome: supported
  summary: All 100 edges and 196 evidence items (177 edge + 19 endpoint-qualifier
    items), 64 references, 28 primary claims and 15 design obligations are accounted
    for. Every original reference body was freshly rebound; prior literature interpretations
    retain their explicit read depth.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - edge-ledger
  - science-replay
  - primary-reading-scope
  - prior-science
  - prior-corrections
  details: Previously unavailable full texts/supplements remain unavailable. PMID10903310
    is abstract-only; prior reused claims are not presented as a fresh whole-paper
    read. The 76 source-lead dispositions and finite hidden/ignored/archive context
    are not global literature exhaustion. Original failed probes and corrected executions
    are retained.
- assessment_id: authority-integration
  area: grounding
  topic: Actual 80-node authority reconciliation
  outcome: supported
  summary: Every selected identifier, category and label agrees with the adopted native
    authority union. Existing terms/owners remain preserved and ordinary-source additions
    remain separate from ontology additions.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - authority-ledger
  - source-authority
  - ontology-authority
  details: The source union has 3,221 terms/1,209 owners; ontology has 2,196 terms/five
    owners. Full union rebuild, ordered-owner preservation and code checks are root-owned
    evidence; the current scientific review directly verifies all 80 consumer bindings.
    Identifier agreement alone does not demonstrate catalysis.
- assessment_id: structured-crosscheck
  area: evidence
  topic: Required structured-source route
  outcome: not_applicable
  summary: The successful complete iModulonDB dataset catalog does not cover selected
    native taxa; organism search/module summarization is not applicable.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - imodulondb
  details: Catalog absence is coverage information only. E. coli and P. aeruginosa
    expression-host coverage cannot establish regulation of the native pathway or
    recombinant target. Initial missing dependency and sandbox DNS failures are preserved;
    existing runner succeeded without installation after approved public network access.
- assessment_id: representation
  area: representation
  topic: Actual page, graph and KGX fidelity
  outcome: supported
  summary: Native page fields, 100 relationships and all source qualifiers survive
    actual rendering/export. The 92 graph nodes include qualified endpoint contexts
    beyond 80 declared identities.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - actual-page
  - root-exports-visual
  - science-replay
  details: Reviewer personally viewed root-captured desktop overview, focused desktop
    and focused mobile screenshots. Overview is dense at 15%; selected reaction is
    readable at 100%; graph scrolls inside its viewport. Root browser measures zero
    runtime errors and document-width containment. This is a smoke check, not accessibility
    or cross-browser certification. All 13,689 earlier export edge rows remain exact.
- assessment_id: external-corrections
  area: consistency
  topic: R01–R04 predecessor handling
  outcome: supported
  summary: The actual record is byte-identical to the independently accepted corrected
    successor. Four original external findings remain preserved with their needs-curation
    verdict; their corrected successor has bounded acceptance.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - record
  - prior-science
  - prior-corrections
  details: 'No prior canonical review for this target was found in the hidden/ignored-inclusive
    review inventory. External issues #600–603 are documentary lineage, not fabricated
    structured previous_occurrences. This review creates no scientific status promotion
    or issue-closure action.'
- assessment_id: report
  area: consistency
  topic: Human-readable research report
  outcome: supported
  summary: The separately reviewed external draft agrees with the maintained scientific
    claims, formal net, evidence counts and limitations.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - research-draft
  details: Final report/retention adoption is still pending at this provisional draft
    cutoff; its exact maintained bytes must be inspected and reassessed before completed
    review persistence.
- assessment_id: edge-e001
  area: graph
  topic: e001 MetaCyc:1.3.99.15-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 1 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e002
  area: graph
  topic: e002 CHEBI:57369 consumes MetaCyc:1.3.99.15-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e003
  area: graph
  topic: e003 MetaCyc:Reduced-ferredoxins consumes MetaCyc:1.3.99.15-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 2 in selected R2L traversal. Generic ferredoxin cluster
    units are not whole-protein counts. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[2];
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e004
  area: graph
  topic: e004 CHEBI:30616 consumes MetaCyc:1.3.99.15-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e005
  area: graph
  topic: e005 CHEBI:15377 consumes MetaCyc:1.3.99.15-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[4]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e006
  area: graph
  topic: e006 MetaCyc:1.3.99.15-RXN produces CHEBI:57374
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e007
  area: graph
  topic: e007 MetaCyc:1.3.99.15-RXN produces MetaCyc:Oxidized-ferredoxins
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 2 in selected R2L traversal. Generic ferredoxin cluster
    units are not whole-protein counts. Exact locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[2];
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e008
  area: graph
  topic: e008 MetaCyc:1.3.99.15-RXN produces CHEBI:456216
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e009
  area: graph
  topic: e009 MetaCyc:1.3.99.15-RXN produces CHEBI:43474
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-002
  details: 'Claim: Coefficient 2 in selected R2L traversal. Exact locators: MetaCyc:1.3.99.15-RXN
    /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[4]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-002
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-002
- assessment_id: edge-e010
  area: graph
  topic: e010 MetaCyc:R265-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 2 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e011
  area: graph
  topic: e011 CHEBI:57374 consumes MetaCyc:R265-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-003
  details: 'Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:R265-RXN
    /ptools-xml/Reaction[@frameid=''R265-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-003
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-003
- assessment_id: edge-e012
  area: graph
  topic: e012 MetaCyc:ETF-Reduced consumes MetaCyc:R265-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-003
  details: 'Claim: Coefficient 1 in selected R2L traversal. Generic ETF redox-state
    convention; physiological coupling unresolved. Exact locators: MetaCyc:R265-RXN
    /ptools-xml/Reaction[@frameid=''R265-RXN'']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-003
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-003
- assessment_id: edge-e013
  area: graph
  topic: e013 MetaCyc:R265-RXN produces CHEBI:76270
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-003
  details: 'Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:R265-RXN
    /ptools-xml/Reaction[@frameid=''R265-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-003
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-003
- assessment_id: edge-e014
  area: graph
  topic: e014 MetaCyc:R265-RXN produces MetaCyc:ETF-Oxidized
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-003
  details: 'Claim: Coefficient 1 in selected R2L traversal. Generic ETF redox-state
    convention; physiological coupling unresolved. Exact locators: MetaCyc:R265-RXN
    /ptools-xml/Reaction[@frameid=''R265-RXN'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-003
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-003
- assessment_id: edge-e015
  area: graph
  topic: e015 MetaCyc:R265-RXN produces CHEBI:15378
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-003
  details: 'Claim: Coefficient 1 in selected R2L traversal. Exact locators: MetaCyc:R265-RXN
    /ptools-xml/Reaction[@frameid=''R265-RXN'']/left[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R265-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-003
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-003
- assessment_id: edge-e016
  area: graph
  topic: e016 MetaCyc:R266-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 3 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e017
  area: graph
  topic: e017 CHEBI:76270 consumes MetaCyc:R266-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-004
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R266-RXN
    /ptools-xml/Reaction[@frameid=''R266-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-004
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-004
- assessment_id: edge-e018
  area: graph
  topic: e018 CHEBI:15377 consumes MetaCyc:R266-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-004
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R266-RXN
    /ptools-xml/Reaction[@frameid=''R266-RXN'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-004
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-004
- assessment_id: edge-e019
  area: graph
  topic: e019 MetaCyc:R266-RXN produces PubChem:90657894
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-004
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R266-RXN
    /ptools-xml/Reaction[@frameid=''R266-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R266-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-004
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-004
- assessment_id: edge-e020
  area: graph
  topic: e020 MetaCyc:R267-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 4 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e021
  area: graph
  topic: e021 PubChem:90657894 consumes MetaCyc:R267-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-005
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN
    /ptools-xml/Reaction[@frameid=''R267-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-005
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-005
- assessment_id: edge-e022
  area: graph
  topic: e022 CHEBI:57540 consumes MetaCyc:R267-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-005
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN
    /ptools-xml/Reaction[@frameid=''R267-RXN'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-005
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-005
- assessment_id: edge-e023
  area: graph
  topic: e023 MetaCyc:R267-RXN produces CHEBI:15378
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-005
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN
    /ptools-xml/Reaction[@frameid=''R267-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-005
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-005
- assessment_id: edge-e024
  area: graph
  topic: e024 MetaCyc:R267-RXN produces PubChem:90658738
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-005
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN
    /ptools-xml/Reaction[@frameid=''R267-RXN'']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-005
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-005
- assessment_id: edge-e025
  area: graph
  topic: e025 MetaCyc:R267-RXN produces CHEBI:57945
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-005
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R267-RXN
    /ptools-xml/Reaction[@frameid=''R267-RXN'']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R267-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-005
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-005
- assessment_id: edge-e026
  area: graph
  topic: e026 MetaCyc:R268-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 5 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e027
  area: graph
  topic: e027 PubChem:90658738 consumes MetaCyc:R268-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-006
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN
    /ptools-xml/Reaction[@frameid=''R268-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-006
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-006
- assessment_id: edge-e028
  area: graph
  topic: e028 CHEBI:15377 consumes MetaCyc:R268-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-006
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN
    /ptools-xml/Reaction[@frameid=''R268-RXN'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-006
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-006
- assessment_id: edge-e029
  area: graph
  topic: e029 MetaCyc:R268-RXN produces CHEBI:15378
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-006
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN
    /ptools-xml/Reaction[@frameid=''R268-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-006
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-006
- assessment_id: edge-e030
  area: graph
  topic: e030 MetaCyc:R268-RXN produces CHEBI:57360
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-006
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:R268-RXN
    /ptools-xml/Reaction[@frameid=''R268-RXN'']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''R268-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-006
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-006
- assessment_id: edge-e031
  area: graph
  topic: e031 MetaCyc:1.3.1.62-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 6 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e032
  area: graph
  topic: e032 CHEBI:57360 consumes MetaCyc:1.3.1.62-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-007
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN
    /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-007
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-007
- assessment_id: edge-e033
  area: graph
  topic: e033 CHEBI:57540 consumes MetaCyc:1.3.1.62-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-007
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN
    /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-007
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-007
- assessment_id: edge-e034
  area: graph
  topic: e034 MetaCyc:1.3.1.62-RXN produces CHEBI:15378
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-007
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN
    /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-007
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-007
- assessment_id: edge-e035
  area: graph
  topic: e035 MetaCyc:1.3.1.62-RXN produces CHEBI:57945
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-007
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN
    /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-007
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-007
- assessment_id: edge-e036
  area: graph
  topic: e036 MetaCyc:1.3.1.62-RXN produces PubChem:90657525
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-007
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.3.1.62-RXN
    /ptools-xml/Reaction[@frameid=''1.3.1.62-RXN'']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.3.1.62-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-007
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-007
- assessment_id: edge-e037
  area: graph
  topic: e037 MetaCyc:RXN-8031 part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 7 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e038
  area: graph
  topic: e038 PubChem:90657525 consumes MetaCyc:RXN-8031
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-008
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8031
    /ptools-xml/Reaction[@frameid=''RXN-8031'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-008
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-008
- assessment_id: edge-e039
  area: graph
  topic: e039 CHEBI:15377 consumes MetaCyc:RXN-8031
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-008
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8031
    /ptools-xml/Reaction[@frameid=''RXN-8031'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-008
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-008
- assessment_id: edge-e040
  area: graph
  topic: e040 MetaCyc:RXN-8031 produces CHEBI:57343
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-008
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8031
    /ptools-xml/Reaction[@frameid=''RXN-8031'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8031'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-008
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-008
- assessment_id: edge-e041
  area: graph
  topic: e041 MetaCyc:1.1.1.259-RXN part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-009
  details: 'Claim: Step 8 of the complete selected nine-step route. Native YES-PUTATIVE
    has no assigned activity; no active PimE or substitute catalyst is curated. Exact
    locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN''];
    MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/orphan;
    complete reaction object'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-009
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-009
- assessment_id: edge-e042
  area: graph
  topic: e042 CHEBI:57343 consumes MetaCyc:1.1.1.259-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-009
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN
    /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-009
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-009
- assessment_id: edge-e043
  area: graph
  topic: e043 CHEBI:57540 consumes MetaCyc:1.1.1.259-RXN
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-009
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN
    /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-009
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-009
- assessment_id: edge-e044
  area: graph
  topic: e044 MetaCyc:1.1.1.259-RXN produces CHEBI:15378
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-009
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN
    /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-009
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-009
- assessment_id: edge-e045
  area: graph
  topic: e045 MetaCyc:1.1.1.259-RXN produces CHEBI:57945
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-009
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN
    /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-009
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-009
- assessment_id: edge-e046
  area: graph
  topic: e046 MetaCyc:1.1.1.259-RXN produces CHEBI:57350
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-009
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:1.1.1.259-RXN
    /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[3]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-009
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-009
- assessment_id: edge-e047
  area: graph
  topic: e047 MetaCyc:RXN-8032 part_of MetaCyc:P321-PWY
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Step 9 of the complete selected nine-step source route. Exact locators:
    MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']'
  dimensions:
  - name: component_role
    value: reaction membership
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e048
  area: graph
  topic: e048 CHEBI:57350 consumes MetaCyc:RXN-8032
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-010
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032
    /ptools-xml/Reaction[@frameid=''RXN-8032'']/left[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-010
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-010
- assessment_id: edge-e049
  area: graph
  topic: e049 CHEBI:57287 consumes MetaCyc:RXN-8032
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-010
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032
    /ptools-xml/Reaction[@frameid=''RXN-8032'']/left[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-010
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-010
- assessment_id: edge-e050
  area: graph
  topic: e050 MetaCyc:RXN-8032 produces CHEBI:57378
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-010
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032
    /ptools-xml/Reaction[@frameid=''RXN-8032'']/right[1]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-010
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-010
- assessment_id: edge-e051
  area: graph
  topic: e051 MetaCyc:RXN-8032 produces CHEBI:57288
  outcome: supported
  summary: Original P321 reaction-layout and nine whole native reactions independently
    reconstructed; directions/coefficients/frame identities exact.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  - source-010
  details: 'Claim: Coefficient 1 in selected L2R traversal. Exact locators: MetaCyc:RXN-8032
    /ptools-xml/Reaction[@frameid=''RXN-8032'']/right[2]; MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']'
  dimensions:
  - name: component_role
    value: material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
    - source-010
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
    - source-010
- assessment_id: edge-e052
  area: graph
  topic: e052 MetaCyc:1.3.99.15-RXN provides_input_for MetaCyc:R265-RXN
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material CHEBI:57374; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e053
  area: graph
  topic: e053 MetaCyc:R265-RXN provides_input_for MetaCyc:R266-RXN
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material CHEBI:76270; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e054
  area: graph
  topic: e054 MetaCyc:R266-RXN provides_input_for MetaCyc:R267-RXN
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material PubChem:90657894; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e055
  area: graph
  topic: e055 MetaCyc:R267-RXN provides_input_for MetaCyc:R268-RXN
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material PubChem:90658738; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e056
  area: graph
  topic: e056 MetaCyc:R268-RXN provides_input_for MetaCyc:1.3.1.62-RXN
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material CHEBI:57360; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e057
  area: graph
  topic: e057 MetaCyc:1.3.1.62-RXN provides_input_for MetaCyc:RXN-8031
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material PubChem:90657525; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e058
  area: graph
  topic: e058 MetaCyc:RXN-8031 provides_input_for MetaCyc:1.1.1.259-RXN
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material CHEBI:57343; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e059
  area: graph
  topic: e059 MetaCyc:1.1.1.259-RXN provides_input_for MetaCyc:RXN-8032
  outcome: supported
  summary: Consecutive selected reactions share actual output/input frames; route
    remains complete through glutaryl-CoA+acetyl-CoA.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-001
  details: 'Claim: Exact shared primary material CHEBI:57350; coefficient 1 produced
    and consumed. Exact locators: MetaCyc:P321-PWY /ptools-xml/Pathway[@frameid=''P321-PWY'']/*[self::reaction-layout
    or self::reaction-ordering]'
  dimensions:
  - name: component_role
    value: primary material join
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-001
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-001
- assessment_id: edge-e060
  area: graph
  topic: e060 MetaCyc:CPLX-883 enables MetaCyc:1.3.99.15-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-011
  - source-012
  details: 'Claim: Native R. palustris first-step assignment has mutant and sequence
    evidence. badE/badF mutant/complementation/expression evidence supports a genetic
    contribution; do not claim isolated holoenzyme, each subunit independently catalyzes,
    or fixed donor/cofactor occupancy. Feeding substrate was labelled benzoate, not
    benzoyl-CoA. Exact locators: MetaCyc:ENZRXN-1102 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1102'']/*[self::enzyme
    or self::reaction or self::evidence]; PMID:9177244 PMC21076 Results; Figures2–5;
    badE/badF mutant and complementation paragraphs'
  dimensions:
  - name: component_role
    value: qualified enzyme assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-011
    - source-012
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-011
    - source-012
- assessment_id: edge-e061
  area: graph
  topic: e061 MetaCyc:CPLX-1341 catalyzes MetaCyc:1.3.99.15-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-013
  - source-056
  - source-057
  details: 'Claim: Shared first reaction, experimentally characterized Thauera BCR
    context. Exact four subunit identities established. Intrinsic clusters and Mg2+
    remain separate from donor cluster-state equation units. Purified Thauera evidence
    is not a purified R. palustris BadDEFG preparation. Exact locators: MetaCyc:ENZRXN-1821
    /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/*[self::enzyme or self::reaction
    or self::evidence]; PMID:9108255 pp841–845; Table1; Figures1–5; PMID:12081970
    Methods; Figure3; Tables3–4; Figure5'
  dimensions:
  - name: component_role
    value: qualified enzyme assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-013
    - source-056
    - source-057
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-013
    - source-056
    - source-057
- assessment_id: edge-e062
  area: graph
  topic: e062 MetaCyc:CPLX-8778 enables MetaCyc:R265-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-014
  - source-015
  details: 'Claim: Source assigns the generic ETF reaction; recombinant reverse diene
    reduction uses Ti(III)/methyl viologen. This enables assignment does not assert
    measured physiological ETF catalysis or an exact R. palustris catalyst. Exact
    locators: MetaCyc:ENZRXN-22280 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-22280'']/*[self::enzyme
    or self::reaction or self::evidence]; PMID:23667239 PMC3697644 Results Ch1CoA
    dehydrogenase; Figures3–6; Table2; PMID:23667239 PMC3697644 Methods expression;
    Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods expression;
    Results recombinant enzyme; Table2 Endpoint context: subject experimental_construct:
    Syntrophus SB SYN_02587 downstream-ATG native segment (397 aa) plus C-terminal
    His6 in E. coli BL21 Star(DE3); not the deposited full 414-aa preparation. Linker
    bases unavailable.'
  dimensions:
  - name: component_role
    value: qualified enzyme assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-014
    - source-015
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-014
    - source-015
- assessment_id: edge-e063
  area: graph
  topic: e063 MetaCyc:CPLX-926 catalyzes MetaCyc:R266-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-016
  details: 'Claim: BadK hydration of the native monoene, not hydroxylation. 1997 assay
    used recombinant E. coli crude extract; one-component native complex is not experimental
    oligomeric-state proof. Exact BadK identity differs from BadJ/AliB adjacent entry.
    Exact locators: MetaCyc:ENZRXN-1144 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1144'']/*[self::enzyme
    or self::reaction or self::evidence]; PMID:9177244 PMC21076 sec5, sec6 and sec8
    (BadK assay and characterization paragraphs); PMID:9177244 PMC21076 sec5, sec6
    and sec8 (BadK assay and characterization paragraphs) Endpoint context: subject
    experimental_construct: Recombinant E. coli DH5alpha pDP111 crude extract containing
    BadK; no purified protein or measured native oligomeric state.'
  dimensions:
  - name: component_role
    value: qualified enzyme assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-012
    - source-016
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-012
    - source-016
- assessment_id: edge-e064
  area: graph
  topic: e064 MetaCyc:CPLX-885 catalyzes MetaCyc:R267-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-017
  - source-018
  details: 'Claim: BadH saturated cyclic substrate oxidation is NAD-dependent. Primary
    assay used N-terminal His6/factor Xa construct in E. coli DH5alpha, not purification
    from R. palustris. Apparent tetramer is preparation-specific; negative 3-hydroxypimeloyl-CoA
    activity prevents filling the lower C7 step. Exact locators: MetaCyc:ENZRXN-1104
    /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1104'']/*[self::enzyme or self::reaction
    or self::evidence]; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5;
    PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5 Endpoint context:
    subject experimental_construct: N-terminal His6/factor Xa BadH expressed in E.
    coli DH5alpha. Tagged recombinant apparent tetramer; native 27-kDa immunoblot
    is a different preparation.'
  dimensions:
  - name: component_role
    value: qualified enzyme assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-017
    - source-018
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-017
    - source-018
- assessment_id: edge-e065
  area: graph
  topic: e065 MetaCyc:CPLX-884 catalyzes MetaCyc:R268-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-019
  - source-020
  details: 'Claim: BadI saturated cyclic ring-opening has native purification and
    mutant evidence. Approximately 100-fold/four-column purification to apparent homogeneity
    differs from the shortened 90%-pure preparation and approximately 5% intended
    substrate mixture. Automated UniProt functional name does not override exact source/product
    assay; substrate mixture limits affinity/chemical interpretation, not reported
    protein purity. Exact locators: MetaCyc:ENZRXN-1103 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1103'']/*[self::enzyme
    or self::reaction or self::evidence]; PMID:9573182 PMC107172 sec16–sec18; Table1;
    Figures2–4; PMID:9573182 PMC107172 substrate specificity and Discussion; Figure5'
  dimensions:
  - name: component_role
    value: qualified enzyme assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-019
    - source-020
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-019
    - source-020
- assessment_id: edge-e066
  area: graph
  topic: e066 MetaCyc:CPLX-9349 enables MetaCyc:1.3.1.62-RXN
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-021
  - source-022
  details: 'Claim: PimCD is a predicted lower pimeloyl-CoA dehydrogenase assignment.
    Exact C/D sequences and proposed 1:1 assembly are identifiable; operon deletion/cotranscription
    does not establish purified enzyme, fixed flavin occupancy, or direct NAD usage
    in the native formal equation. Keep biological hypothesis separate from reaction
    chemistry. Exact locators: MetaCyc:ENZRXN-26771 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-26771'']/*[self::enzyme
    or self::reaction or self::evidence]; PMID:15758219 PDF pp728,731,734; Figure1;
    PMID:15758219 PDF pp729–734; Figures2,3; Table2'
  dimensions:
  - name: component_role
    value: predicted catalyst assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-021
    - source-022
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-021
    - source-022
- assessment_id: edge-e067
  area: graph
  topic: e067 UniProtKB:Q6N3H7 enables MetaCyc:RXN-8031
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-022
  - source-023
  details: 'Claim: PimF is a predicted lower enoyl-CoA hydratase assignment. 699-aa
    protein identity is exact; domain composition and 2005 bifunctionality hypothesis
    do not establish C7 hydration/oxidation assays. Do not turn the paper Fig. 1 dual-role
    hypothesis into a measured step 8 catalyst. Exact locators: MetaCyc:ENZRXN-26772
    /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-26772'']/*[self::enzyme or self::reaction
    or self::evidence]; PMID:15758219 PDF pp731,734; Figure1; PMID:15758219 PDF pp729–734;
    Figures2,3; Table2'
  dimensions:
  - name: component_role
    value: predicted catalyst assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-022
    - source-023
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-022
    - source-023
- assessment_id: edge-e068
  area: graph
  topic: e068 UniProtKB:Q6N3H9 enables MetaCyc:RXN-8032
  outcome: supported
  summary: R. palustris BadDEFG genetics distinguished from Thauera purified BCR;
    Syntrophus reverse artificial-donor assay; BadK crude extract; tagged BadH NAD
    specificity/negative C7; native BadI protein purity versus a 5% substrate mixture;
    PimCD/F/B prediction only.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-022
  - source-024
  details: 'Claim: PimB is a predicted lower CoA thiolysis assignment. Exact protein/gene
    identity does not make operon-level evidence a purified 3-oxopimeloyl-CoA thiolase
    assay; separate PimA acid activation is outside the selected boundary. Exact locators:
    MetaCyc:ENZRXN-26773 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-26773'']/*[self::enzyme
    or self::reaction or self::evidence]; PMID:15758219 PDF pp728,731,734; Figure1;
    PMID:15758219 PDF pp729–734; Figures2,3; Table2'
  dimensions:
  - name: component_role
    value: predicted catalyst assignment
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-022
    - source-024
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-022
    - source-024
- assessment_id: edge-e069
  area: graph
  topic: e069 MetaCyc:CPLX-1341 has_part UniProtKB:O87876
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-025
  details: 'Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer
    context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341
    /Protein[@frameid="CPLX-1341"]/component[1]'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-025
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-025
- assessment_id: edge-e070
  area: graph
  topic: e070 MetaCyc:CPLX-1341 has_part UniProtKB:O87875
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-025
  details: 'Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer
    context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341
    /Protein[@frameid="CPLX-1341"]/component[2]'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-025
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-025
- assessment_id: edge-e071
  area: graph
  topic: e071 MetaCyc:CPLX-1341 has_part UniProtKB:O87874
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-025
  details: 'Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer
    context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341
    /Protein[@frameid="CPLX-1341"]/component[3]'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-025
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-025
- assessment_id: edge-e072
  area: graph
  topic: e072 MetaCyc:CPLX-1341 has_part UniProtKB:O87877
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-025
  details: 'Claim: Native component multiplicity 1; Purified shared Thauera BCR heterotetramer
    context. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-1341
    /Protein[@frameid="CPLX-1341"]/component[4]'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-025
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-025
- assessment_id: edge-e073
  area: graph
  topic: e073 MetaCyc:CPLX-8778 has_part UniProtKB:Q2LQN9
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-015
  - source-026
  details: 'Claim: Native component multiplicity 4; Preparation-specific apparent
    homotetramer. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-8778
    /Protein[@frameid="CPLX-8778"]/component[1]; PMID:23667239 PMC3697644 Methods
    expression; Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods
    expression; Results recombinant enzyme; Table2; PMID:23667239 PMC3697644 Methods
    expression; Results recombinant enzyme; Table2 Endpoint context: subject experimental_construct:
    Syntrophus SB SYN_02587 downstream-ATG native segment (397 aa) plus C-terminal
    His6 in E. coli BL21 Star(DE3); not the deposited full 414-aa preparation. Linker
    bases unavailable.; object experimental_construct: Syntrophus SB SYN_02587 downstream-ATG
    native segment (397 aa) plus C-terminal His6 in E. coli BL21 Star(DE3); not the
    deposited full 414-aa preparation. Linker bases unavailable.'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-015
    - source-026
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-015
    - source-026
- assessment_id: edge-e074
  area: graph
  topic: e074 MetaCyc:CPLX-883 has_part UniProtKB:O07460
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-027
  details: 'Claim: Native component multiplicity 1; Genetically inferred R. palustris
    BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted.
    Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[1]; PMID:9177244
    PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-012
    - source-027
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-012
    - source-027
- assessment_id: edge-e075
  area: graph
  topic: e075 MetaCyc:CPLX-883 has_part UniProtKB:O07461
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-027
  details: 'Claim: Native component multiplicity 1; Genetically inferred R. palustris
    BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted.
    Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[2]; PMID:9177244
    PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-012
    - source-027
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-012
    - source-027
- assessment_id: edge-e076
  area: graph
  topic: e076 MetaCyc:CPLX-883 has_part UniProtKB:O07462
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-027
  details: 'Claim: Native component multiplicity 1; Genetically inferred R. palustris
    BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted.
    Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[3]; PMID:9177244
    PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-012
    - source-027
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-012
    - source-027
- assessment_id: edge-e077
  area: graph
  topic: e077 MetaCyc:CPLX-883 has_part UniProtKB:O07463
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-027
  details: 'Claim: Native component multiplicity 1; Genetically inferred R. palustris
    BadDEFG model; no isolated holoenzyme. No isolated-subunit catalysis is asserted.
    Exact locators: MetaCyc:CPLX-883 /Protein[@frameid="CPLX-883"]/component[4]; PMID:9177244
    PMC21076 Results; Figures2–5; badE/badF mutant and complementation paragraphs'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-012
    - source-027
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-012
    - source-027
- assessment_id: edge-e078
  area: graph
  topic: e078 MetaCyc:CPLX-884 has_part UniProtKB:O07456
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-020
  - source-028
  details: 'Claim: Native component multiplicity 4; Preparation-specific apparent
    homotetramer. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-884
    /Protein[@frameid="CPLX-884"]/component[1]; PMID:9573182 PMC107172 substrate specificity
    and Discussion; Figure5'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-020
    - source-028
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-020
    - source-028
- assessment_id: edge-e079
  area: graph
  topic: e079 MetaCyc:CPLX-885 has_part UniProtKB:O07457
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-018
  - source-029
  details: 'Claim: Native component multiplicity 4; Preparation-specific apparent
    homotetramer. No isolated-subunit catalysis is asserted. Exact locators: MetaCyc:CPLX-885
    /Protein[@frameid="CPLX-885"]/component[1]; PMID:10781543 PMC101983 sec17; Figure4
    (purification/SDS-PAGE) and sec17 final paragraph (gel filtration/subunit mass);
    sec18 (CGA720 nonpolar mutant, retained BadI and native BadH immunoblot text;
    immunoblot data not shown); PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1;
    Figures2–5; PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5
    Endpoint context: subject experimental_construct: N-terminal His6/factor Xa BadH
    expressed in E. coli DH5alpha. Tagged recombinant apparent tetramer; native 27-kDa
    immunoblot is a different preparation.; object experimental_construct: N-terminal
    His6/factor Xa BadH expressed in E. coli DH5alpha. Tagged recombinant apparent
    tetramer; native 27-kDa immunoblot is a different preparation.'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-018
    - source-029
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-018
    - source-029
- assessment_id: edge-e080
  area: graph
  topic: e080 MetaCyc:CPLX-926 has_part UniProtKB:O07453
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-012
  - source-030
  details: 'Claim: Native singleton component link with no explicit coefficient; one
    distinct component type is bookkeeping, with unknown multiplicity and no proof
    of monomeric enzyme. Exact locators: MetaCyc:CPLX-926 /Protein[@frameid="CPLX-926"]/component[1];
    PMID:9177244 PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs);
    PMID:9177244 PMC21076 sec5, sec6 and sec8 (BadK assay and characterization paragraphs)
    Endpoint context: subject experimental_construct: Recombinant E. coli DH5alpha
    pDP111 crude extract containing BadK; no purified protein or measured native oligomeric
    state.; object experimental_construct: Recombinant E. coli DH5alpha pDP111 crude
    extract containing BadK; no purified protein or measured native oligomeric state.'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-012
    - source-030
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-012
    - source-030
- assessment_id: edge-e081
  area: graph
  topic: e081 MetaCyc:CPLX-9349 has_part UniProtKB:Q6N3I1
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-022
  - source-031
  details: 'Claim: Native component multiplicity 1; Proposed PimCD heterodimer; no
    purified assembly. No isolated-subunit catalysis is asserted. Exact locators:
    MetaCyc:CPLX-9349 /Protein[@frameid="CPLX-9349"]/component[1]; PMID:15758219 PDF
    pp728,731,734; Figure1'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-022
    - source-031
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-022
    - source-031
- assessment_id: edge-e082
  area: graph
  topic: e082 MetaCyc:CPLX-9349 has_part UniProtKB:Q6N3I0
  outcome: supported
  summary: All seven source assemblies and 16 core monomers crosswalked to exact native
    components/coefficients; apparent/putative/singleton assembly limits retained.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-022
  - source-031
  details: 'Claim: Native component multiplicity 1; Proposed PimCD heterodimer; no
    purified assembly. No isolated-subunit catalysis is asserted. Exact locators:
    MetaCyc:CPLX-9349 /Protein[@frameid="CPLX-9349"]/component[2]; PMID:15758219 PDF
    pp728,731,734; Figure1'
  dimensions:
  - name: component_role
    value: assembly component
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-022
    - source-031
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-022
    - source-031
- assessment_id: edge-e083
  area: graph
  topic: e083 MetaCyc:CPLX-1341 has_cofactor MetaCyc:CPD-7
  outcome: supported
  summary: Actual native cofactor pointer and corrected PMID10903310 abstract-only
    spectroscopy/three-cluster claim are supported. The original R01 chronology attribution
    was independently corrected; no fixed occupancy or donor equivalence is asserted.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-013
  - source-058
  details: 'Claim: Native intrinsic-cluster annotation; no fixed cluster count or
    equality to whole ferredoxin donor. Exact locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/cofactor[Compound/@frameid=''CPD-7''];
    PMID:10903310 Europe PMC CORE JSON $.resultList.result[0].abstractText, sentences
    3–4; indexed abstract only. Complete paper and spectra not examined.'
  dimensions:
  - name: component_role
    value: native cofactor pointer
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-013
    - source-058
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-013
    - source-058
- assessment_id: edge-e084
  area: graph
  topic: e084 MetaCyc:CPLX-1341 has_cofactor CHEBI:18420
  outcome: supported
  summary: Actual native cofactor pointers retained; magnesium has no fixed metal
    occupancy, Syntrophus FAD text/table conflict and construct qualification are
    preserved, and tested BadH NAD is a soluble redox cosubstrate rather than an asserted
    prosthetic group.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-013
  details: 'Claim: Activity-specific magnesium annotation; no fixed metal occupancy.
    Exact locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/cofactor[Compound/@frameid=''MG+2'']'
  dimensions:
  - name: component_role
    value: native cofactor pointer
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-013
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-013
- assessment_id: edge-e085
  area: graph
  topic: e085 MetaCyc:CPLX-8778 has_cofactor CHEBI:57692
  outcome: supported
  summary: Actual native cofactor pointers retained; magnesium has no fixed metal
    occupancy, Syntrophus FAD text/table conflict and construct qualification are
    preserved, and tested BadH NAD is a soluble redox cosubstrate rather than an asserted
    prosthetic group.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-014
  - source-015
  details: 'Claim: Recombinant Syntrophus flavoprotein context. Text 1.05 FAD/monomer
    conflicts with Table 2 values of 0.41/0.67; no fixed occupancy or bound charge.
    Exact locators: MetaCyc:ENZRXN-22280 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-22280'']/cofactor[Compound/@frameid=''FAD''];
    PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2;
    PMID:23667239 PMC3697644 Methods expression; Results recombinant enzyme; Table2
    Endpoint context: subject experimental_construct: Syntrophus SB SYN_02587 downstream-ATG
    native segment (397 aa) plus C-terminal His6 in E. coli BL21 Star(DE3); not the
    deposited full 414-aa preparation. Linker bases unavailable.'
  dimensions:
  - name: component_role
    value: native cofactor pointer
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-014
    - source-015
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-014
    - source-015
- assessment_id: edge-e086
  area: graph
  topic: e086 MetaCyc:CPLX-885 has_cofactor CHEBI:57540
  outcome: supported
  summary: Actual native cofactor pointers retained; magnesium has no fixed metal
    occupancy, Syntrophus FAD text/table conflict and construct qualification are
    preserved, and tested BadH NAD is a soluble redox cosubstrate rather than an asserted
    prosthetic group.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-017
  - source-018
  details: 'Claim: NAD is the tested soluble redox cosubstrate; native cofactor annotation
    does not establish a bound prosthetic group. NADP was negative. Exact locators:
    MetaCyc:ENZRXN-1104 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1104'']/cofactor[Compound/@frameid=''NAD''];
    PMID:10781543 PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5; PMID:10781543
    PMC101983 sec4–sec10, sec15–sec18; Table1; Figures2–5 Endpoint context: subject
    experimental_construct: N-terminal His6/factor Xa BadH expressed in E. coli DH5alpha.
    Tagged recombinant apparent tetramer; native 27-kDa immunoblot is a different
    preparation.'
  dimensions:
  - name: component_role
    value: native cofactor pointer
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-017
    - source-018
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-017
    - source-018
- assessment_id: edge-e087
  area: graph
  topic: e087 UniProtKB:O07465 regulates MetaCyc:G-545
  outcome: supported
  summary: The 2015 BadR repression revises the 1999 cassette interpretation; BadM
    direct footprint versus the 2006 genetics; AadR indirect action possible; BadL
    genetics does not assert direct binding or catalysis.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-032
  - source-033
  details: 'Claim: BadM represses badD promoter/operon transcription. Direct 23-bp
    footprint overlaps promoter/start; no direct inhibition of reductase catalysis.
    Exact locators: PMID:17041049 PMC1698244 main text; Tables1,2; Figures2–4; PMID:25888170
    PMC4475878 sec3-1; Figures2–3 (binding and 23-bp footprint), Figure4 (expression
    context); PMID:25888170 PMC4475878 sec2-3; Table1; Table2 Endpoint context: subject
    experimental_construct: BadM produced in P. aeruginosa PAO1-T7; Methods C-terminal
    versus Table 1 N-terminal His6 labels conflict. Primer-based 163-aa reconstruction
    is not measured clone sequence; legacy 156-aa and current 154-aa sequences are
    distinct.'
  dimensions:
  - name: component_role
    value: regulation
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-032
    - source-033
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-032
    - source-033
- assessment_id: edge-e088
  area: graph
  topic: e088 UniProtKB:O07458 regulates MetaCyc:G-550
  outcome: supported
  summary: The 2015 BadR repression revises the 1999 cassette interpretation; BadM
    direct footprint versus the 2006 genetics; AadR indirect action possible; BadL
    genetics does not assert direct binding or catalysis.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-032
  details: 'Claim: BadR represses badH-associated operon transcription and binds the
    18-bp badH-badR intergenic site. The 2015 in-frame deletion revises old insertion-associated
    activator interpretation. Exact locators: PMID:25888170 PMC4475878 sec3-2,sec3-3,sec4;
    Figure5; reinterpretation of the1999 cassette-insertion phenotype; PMID:25888170
    PMC4475878 sec3-3 (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic
    keto-CoA effector); Figures6–8; PMID:25888170 PMC4475878 sec2-3; Table1; Table2
    Endpoint context: subject experimental_construct: N-terminal His6 BadR from pQF5016b
    expressed in E. coli Rosetta; primer-reconstructed 182-aa construct is distinct
    from untagged 175-aa issuer sequence.'
  dimensions:
  - name: component_role
    value: regulation
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-032
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-032
- assessment_id: edge-e089
  area: graph
  topic: e089 PubChem:90658738 inhibits UniProtKB:O07458
  outcome: supported
  summary: The 2015 BadR repression revises the 1999 cassette interpretation; BadM
    direct footprint versus the 2006 genetics; AadR indirect action possible; BadL
    genetics does not assert direct binding or catalysis.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-032
  details: 'Claim: Cyclic keto-CoA disrupts BadR DNA binding at 40 nmol/10 µL in gel
    shift. This is an assay effect, not a physiological Kd, endogenous concentration
    or structural ligand complex. Exact locators: PMID:25888170 PMC4475878 sec3-3
    (BadR DNA binding), sec3-4 (18-bp footprint), sec3-5 (cyclic keto-CoA effector);
    Figures6–8; PMID:25888170 PMC4475878 sec2-3; Table1; Table2 Endpoint context:
    object experimental_construct: N-terminal His6 BadR from pQF5016b expressed in
    E. coli Rosetta; scope is the purified gel-shift preparation.'
  dimensions:
  - name: component_role
    value: regulation
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-032
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-032
- assessment_id: edge-e090
  area: graph
  topic: e090 UniProtKB:Q01980 regulates MetaCyc:G-545
  outcome: supported
  summary: The 2015 BadR repression revises the 1999 cassette interpretation; BadM
    direct footprint versus the 2006 genetics; AadR indirect action possible; BadL
    genetics does not assert direct binding or catalysis.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-034
  details: 'Claim: AadR-dependent anaerobic badD expression is supported by mutant/reporters.
    Indirect action remains possible; no direct promoter binding or fixed Fe-S occupancy
    is asserted. Exact locators: PMID:10094687 PMC93622 sec10–sec15; Table2; Figures2–4'
  dimensions:
  - name: component_role
    value: regulation
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-034
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-034
- assessment_id: edge-e091
  area: graph
  topic: e091 UniProtKB:G3XCQ2 regulates UniProtKB:O07465
  outcome: supported
  summary: The 2015 BadR repression revises the 1999 cassette interpretation; BadM
    direct footprint versus the 2006 genetics; AadR indirect action possible; BadL
    genetics does not assert direct binding or catalysis.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  details: 'Claim: badL loss reduces badD expression and aromatic growth; badM deletion
    rescues the defect. This genetic BadL–BadM relationship does not establish direct
    binding, exact R. palustris BadL acetyltransferase chemistry or an endogenous
    ligand. Exact locators: PMID:30327443 PMC6191541 s2.1–s2.3; Figures2–6'
  dimensions:
  - name: component_role
    value: regulation
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-035
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-035
- assessment_id: edge-e092
  area: graph
  topic: e092 PubChem:6971 inhibits UniProtKB:O07465
  outcome: supported
  summary: All three neutral free-acid reagents with dose/solubility/preparation limits;
    previous independent whole 2018 original and 14-figure assessment explicitly reused.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - source-059
  details: 'Claim: 2-acetamidobenzoic acid reduces BadM binding to the 212-bp badCD
    promoter probe in EMSA (72 nM BadM, 12 nM probe). The 10 mM 2-acetamido reagent
    disrupted BadM-DNA binding; 5 mM did not. The 2-amino control did not reproduce
    the effect. Nominal 10 mM addition and solubility limits do not establish affinity,
    dissolved concentration, physiological ligand identity or bound protonation. Exact
    locators: PMID:30327443 PMC6191541 s2.5; Figures 8 and 9; reagent s4.1; preparation
    s4.3; PubChem:6971 PropertyTable.Properties[0]; full atom/bond structure and ring-position
    replay bound in regulatory chemistry owner; PMID:30327443 PMC6191541 s4.3; unavailable
    supplementary protocol is not read Endpoint context: object experimental_construct:
    2018 BadM preparation: pRpBadM8 expressed in E. coli C41(lambdaDE3) pka12::kan+
    (JE9314). Exact tag/linker/cleavage and construct sequence are unavailable; no
    transfer from the 2015 PAO1-T7 preparation.'
  dimensions:
  - name: component_role
    value: regulatory ligand effect
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-035
    - source-059
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-035
    - source-059
- assessment_id: edge-e093
  area: graph
  topic: e093 PubChem:48847 inhibits UniProtKB:O07465
  outcome: supported
  summary: All three neutral free-acid reagents with dose/solubility/preparation limits;
    previous independent whole 2018 original and 14-figure assessment explicitly reused.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - source-060
  details: 'Claim: 3-acetamidobenzoic acid reduces BadM binding to the 212-bp badCD
    promoter probe in EMSA (72 nM BadM, 12 nM probe). The 3-acetamido reagent increased
    free probe under the same nominal conditions, with a smaller effect than the 2-isomer.
    Precipitation/limited solubility prevented quantitative ligand comparisons. Nominal
    10 mM addition and solubility limits do not establish affinity, dissolved concentration,
    physiological ligand identity or bound protonation. Exact locators: PMID:30327443
    PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; PubChem:48847 PropertyTable.Properties[0];
    full atom/bond structure and ring-position replay bound in regulatory chemistry
    owner; PMID:30327443 PMC6191541 s4.3; unavailable supplementary protocol is not
    read Endpoint context: object experimental_construct: 2018 BadM preparation: pRpBadM8
    expressed in E. coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage
    and construct sequence are unavailable; no transfer from the 2015 PAO1-T7 preparation.'
  dimensions:
  - name: component_role
    value: regulatory ligand effect
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-035
    - source-060
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-035
    - source-060
- assessment_id: edge-e094
  area: graph
  topic: e094 PubChem:19266 inhibits UniProtKB:O07465
  outcome: supported
  summary: All three neutral free-acid reagents with dose/solubility/preparation limits;
    previous independent whole 2018 original and 14-figure assessment explicitly reused.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - source-061
  details: 'Claim: 4-acetamidobenzoic acid reduces BadM binding to the 212-bp badCD
    promoter probe in EMSA (72 nM BadM, 12 nM probe). The 4-acetamido reagent increased
    free probe under the same nominal conditions, with a smaller effect than the 2-isomer.
    Precipitation/limited solubility prevented quantitative ligand comparisons. Nominal
    10 mM addition and solubility limits do not establish affinity, dissolved concentration,
    physiological ligand identity or bound protonation. Exact locators: PMID:30327443
    PMC6191541 s2.5; Figures 9A-B; reagent s4.1; preparation s4.3; PubChem:19266 PropertyTable.Properties[0];
    full atom/bond structure and ring-position replay bound in regulatory chemistry
    owner; PMID:30327443 PMC6191541 s4.3; unavailable supplementary protocol is not
    read Endpoint context: object experimental_construct: 2018 BadM preparation: pRpBadM8
    expressed in E. coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage
    and construct sequence are unavailable; no transfer from the 2015 PAO1-T7 preparation.'
  dimensions:
  - name: component_role
    value: regulatory ligand effect
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-035
    - source-061
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-035
    - source-061
- assessment_id: edge-e095
  area: graph
  topic: e095 CHEBI:16567 consumes RHEA:28551
  outcome: supported
  summary: Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis,
    no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs
    unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-062
  details: 'Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These
    explicit anionic states are equation normalization, not measured assay protonation.
    This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551
    rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_3530;
    http://rdf.rhea-db.org/Compound_3530'
  dimensions:
  - name: component_role
    value: auxiliary material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-062
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-062
- assessment_id: edge-e096
  area: graph
  topic: e096 CHEBI:57288 consumes RHEA:28551
  outcome: supported
  summary: Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis,
    no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs
    unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-062
  details: 'Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These
    explicit anionic states are equation normalization, not measured assay protonation.
    This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551
    rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4271;
    http://rdf.rhea-db.org/Compound_4271'
  dimensions:
  - name: component_role
    value: auxiliary material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-062
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-062
- assessment_id: edge-e097
  area: graph
  topic: e097 RHEA:28551 produces CHEBI:16803
  outcome: supported
  summary: Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis,
    no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs
    unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-062
  details: 'Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These
    explicit anionic states are equation normalization, not measured assay protonation.
    This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551
    rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_4182;
    http://rdf.rhea-db.org/Compound_4182'
  dimensions:
  - name: component_role
    value: auxiliary material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-062
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-062
- assessment_id: edge-e098
  area: graph
  topic: e098 RHEA:28551 produces CHEBI:57287
  outcome: supported
  summary: Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis,
    no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs
    unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-062
  details: 'Claim: Coefficient 1 in the formal ortho auxiliary acetylation. These
    explicit anionic states are equation normalization, not measured assay protonation.
    This activity is outside the nine selected P321 steps. Exact locators: RHEA:28551
    rdf:Description[@rdf:about="http://rdf.rhea-db.org/28551"]; http://rdf.rhea-db.org/Participant_28550_compound_1264;
    http://rdf.rhea-db.org/Compound_1264'
  dimensions:
  - name: component_role
    value: auxiliary material occurrence
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-062
  - name: evidence_tier
    value: Exact native or issuing database source
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-062
- assessment_id: edge-e099
  area: graph
  topic: e099 UniProtKB:Q2W1S9 catalyzes RHEA:28551
  outcome: supported
  summary: Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis,
    no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs
    unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - source-063
  details: 'Claim: The heterologous homolog preparation transfers acetyl from acetyl-CoA
    to the ortho amino substrate in TLC. Rhea provides the formal anionic equation;
    no native R. palustris BadL catalysis or assay microstate is inferred. Both homologs
    also acetylated meta/para isomers, whose exact activity IDs remain unresolved
    after bounded lookup. Exact locators: PMID:30327443 PMC6191541 s2.3 / Figure 6A-C;
    s2.4 / Figure 7; s4.3; UniProtKB:Q2W1S9 primaryAccession; genes; organism.taxonId;
    sequence; PMID:30327443 PMC6191541 s4.3; complete supplementary construct protocol
    unavailable Endpoint context: subject experimental_construct: pMmBadL2 expressed
    in Escherichia coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage
    and amino-acid construct boundaries are not recoverable from the blocked supplement.
    Reference sequence length is not an assertion of the assayed construct sequence.'
  dimensions:
  - name: component_role
    value: auxiliary homolog catalysis
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-035
    - source-063
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-035
    - source-063
- assessment_id: edge-e100
  area: graph
  topic: e100 UniProtKB:Q39TU9 catalyzes RHEA:28551
  outcome: supported
  summary: Formal ortho RHEA:28551 equation balances; no native RpBadL catalysis,
    no tenth selected step; exact homolog taxon/issuer sequences preserved, constructs
    unresolved; meta/para measured chemistry retained as bounded exact-ID gaps.
  target_ids:
  - MetaCyc:P321-PWY
  evidence_ids:
  - source-035
  - source-064
  details: 'Claim: The heterologous homolog preparation transfers acetyl from acetyl-CoA
    to the ortho amino substrate in TLC. Rhea provides the formal anionic equation;
    no native R. palustris BadL catalysis or assay microstate is inferred. Both homologs
    also acetylated meta/para isomers, whose exact activity IDs remain unresolved
    after bounded lookup. Exact locators: PMID:30327443 PMC6191541 s2.3 / Figure 6A-C;
    s2.4 / Figure 7; s4.3; UniProtKB:Q39TU9 primaryAccession; genes; organism.taxonId;
    sequence; PMID:30327443 PMC6191541 s4.3; complete supplementary construct protocol
    unavailable Endpoint context: subject experimental_construct: pGmBadL1 expressed
    in Escherichia coli C41(lambdaDE3) pka12::kan+ (JE9314). Exact tag/linker/cleavage
    and amino-acid construct boundaries are not recoverable from the blocked supplement.
    Reference sequence length is not an assertion of the assayed construct sequence.'
  dimensions:
  - name: component_role
    value: auxiliary homolog catalysis
    definition: Actual maintained edge role; native membership/material, assembly,
      cofactor, regulation and assay predicates are assessed separately.
    evidence_ids:
    - source-035
    - source-064
  - name: evidence_tier
    value: Primary source plus native database
    definition: Structured source assertions retain their source objects and are not
      treated as direct paper quotations.
    evidence_ids:
    - source-035
    - source-064
findings: []
actions: []
limitations:
- 'Provisional external preparation only: full terminal corpus gate receipts and final
  maintained evidence retention/report bindings remain pending. No completed canonical
  review or publication approval is claimed.'
- Primary literature interpretation explicitly reuses this reviewer’s earlier independent
  original readings at their documented depth. Fresh current work reads the whole
  maintained record and rebinds original bytes; it is not a fabricated new whole-paper
  review.
- PMID10903310 support is the retained complete metadata/abstract, not inaccessible
  full spectroscopy text. Unavailable supplements and exact missing construct/tag/linker
  details remain unknown.
- Unassigned eighth catalyst, isolated lower C7 Pim activities, physiological ETF
  coupling, BadM physiological ligand and exact meta/para acetylation activity identifiers
  remain open scientific gaps already represented in the record.
- Structured-source catalog coverage and finite source/archive searches do not establish
  biological absence or global source/literature exhaustion.
- Visual work is a smoke check of root-captured actual-page screenshots plus root
  browser measurements; no accessibility/cross-browser audit or fresh visual reading
  of every source PDF/image interior.
- Public-release licensing is the separate later decision requested by the user; scientific
  review does not resolve source licensing.
notes:
- 'External original design findings #600–603 have independent correction acceptance.
  They are not invented canonical predecessors or issue closures.'
- No maintained/source/Git/GH/runtime writes, package installs, curation-history actions
  or scientific status promotions performed by this reviewer.
- This timestamp ends the provisional draft assessment pass; final follow-up must
  reinspect changes, use an actual final UTC finish and regenerate the review_id.
links:
- https://github.com/CultureBotAI/PathwayMech/issues/600
- https://github.com/CultureBotAI/PathwayMech/issues/601
- https://github.com/CultureBotAI/PathwayMech/issues/602
- https://github.com/CultureBotAI/PathwayMech/issues/603
```
