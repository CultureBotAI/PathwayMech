# Maintained scientific review preparation — MetaCyc:P321-PWY

The complete actual maintained record has a supported, qualified scientific assessment and **no new actionable scientific findings**. This is frozen **partial preparation**, not a completed canonical review, final maintained-source-retention acceptance, or publication approval. Root explicitly deferred canonical persistence and will supply the final retained-input and gate bindings for a separate extension.

Reviewer `/root/next267_regulatory_acceptance` is independent of the scientific author, correction author, authority implementation and root adoption. Actual assessment start was `2026-10-15T20:11:06Z`; the final provisional governed-content pass finished `2026-10-15T20:26:56Z`. Native inspect preceded assessment. No maintained/source/Git/GH/runtime changes, installs, paid research or child agents were used. Public network access for the existing structured-source runner was approved; no message was sent to an outside person. No old 266 live worktree was read.

## Exact assessed target and coverage

- Worktree: `/private/tmp/pathwaymech-next-267-20261015`, merged base `02bc234143d40e0e825737f27dfdcb5fd358322f`.
- Target: `data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml`, SHA256 `40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51`.
- Entire 2,053-line maintained YAML freshly read: 80 identities, 100 edges, 196 evidence items (177 edge plus 19 endpoint-qualifier items), 64 references, nine native reactions, 42 material occurrences, 23 native frames, eight primary-material joins and separately qualified auxiliary ortho chemistry.
- All 16 core monomers, seven assemblies, 14 component links, four cofactor pointers, five regulatory links, three ligand effects and two auxiliary homolog catalysts accounted for. All 15 prior design obligations and 28 primary claims retain their independently reviewed limitations.
- Actual page: `pages/records/MetaCyc_P321-PWY.html`, SHA256 `023a4d76d157dc058becdfaca6e1b25dfae33140c89214987d8d25ca8b05c730`.

The target is byte-identical to the accepted corrected scientific successor. The original complete design review and its four findings remain immutable; the earlier correction acceptance supplies qualified resolution, not invented canonical history.

## Main review outputs

`governed-review-draft.yaml` and its native-rendered Markdown contain 117 assessments (17 domain assessments plus all 100 edge assessments), 80 evidence entries and 13 checks. The draft has `scientific_review: true`, `completion: partial`, `verdict: pass_with_limitations`, no findings and no actions. Native `record_review.py validate` returned `{"valid_reviews": 1}`; native render returned zero. These are external draft artifacts, not a saved review bundle.

`all-100-maintained-edge-assessments.json`, `all-80-maintained-authority-assessments.json` and `all-64-maintained-reference-bindings.json` account for every current claim/identity/reference. `maintained-scientific-replay.json` records 1,658 successful assertions. The replay independently reconstructed native XML directions, coefficients, joins, enzyme assignments, component relations and cofactor pointers, rebound all original reference bodies, and checked 511 actual rendered text fields. Authority cardinalities are 3,221 source terms/1,209 owners and 2,196 ontology terms/five owners. Selected labels and exact term values were independently checked for all 80 identities.

The scope inventory includes hidden and gitignored files. It finds 264 maintained records, exactly one P321 target, all 263 prior records byte-identical, and no earlier canonical review for this target within the fully traversed `reviews/structured` tree. This does not claim global source or literature exhaustion.

## Required structured route and actual rendering

The already installed CLAW runner successfully queried the public iModulonDB dataset catalog: 28 rows, 20 organisms. No selected native organism, including the older Magnetospirillum spelling, has a dataset. Organism search/module summarization is therefore not applicable. E. coli and P. aeruginosa expression-host coverage is not substituted for native target regulation. The normalized catalog output is retained; it is not mislabelled a raw HTTP response. Failed dependency/DNS probes and the successful exact correction are retained, with no installation or runtime repair.

The actual native page preserves all reviewed evidence, qualifiers and bibliography fields. Root's native KGX comparison covers all 100 new edges, all 80 local node contexts, every evidence/reference/qualifier payload, and exact preservation of 13,689 prior edge rows. Both export file hashes were independently rebound.

Root's browser measurements were read, and this reviewer personally viewed all three exact root-captured screenshots. The 92 displayed nodes include qualified contexts; all 100 relationships remain (73 mechanism, 27 context). The 15% overview is dense; the selected first reaction is readable at 100%; desktop/mobile graph content remains within its scrolling viewport. Runtime-error and interaction measurements are attributed to root's automation. This is a smoke check, not an accessibility or cross-browser audit. The original helper's nonexistent declaration-class counter is explicitly distinguished from the actual context-class count.

## Native gate and report cutoff

Consumed terminal receipts: full native `just validate` (264 records, 20,651 evidence blocks, current pages), native render of all 264 pages, native KGX fidelity, actual browser smoke check, and `just vendored-check` for 22 artifacts. The full 573-byte validation log is retained in `initial-native-validate-receipt.json`.

At this preparation cutoff, full `just test`, `just lint` and `git diff --check` terminal receipts are not consumed. Root owns those gates. Source retention and the final maintained research report are not yet adopted/bound by this reviewer. Required checks remain explicitly unavailable, so the draft remains partial.

The complete external research draft was read, its native net independently recomputed, and its 196 evidence-item count verified. One prose recommendation clarified that BadI's shorter purification procedure produced approximately 90%-pure protein; it did not imply a truncated polypeptide. Root applied the exact single change. Both versions are retained under `root-receipts/`; independent acceptance is `research-wording-correction-acceptance.json`. The original draft SHA `865b2713fe881393016f18c14cdb8eb0fcc262db7ab1e1b1ef599625ede366d0` changed explicitly to `be7a49316b8dd30403fb2181c1fc5f41f248c8f22a85c51777ca8a0b03f7aff5`.

## Evidence depth and limits

The earlier independent original-source readings are reused at the precise depths recorded in the immutable full design review's `primary-reading-scope.json`; no new whole-paper reading is fabricated. Current maintained claims were all freshly read and source bodies rebound. PMID10903310 remains complete retained metadata/abstract only. Previous full 2018 main-text/14-figure regulatory reading is explicitly reused. Unavailable full texts/supplements and exact missing tags/linkers remain unknown.

The eighth catalyst, isolated lower C7 Pim activities, physiological ETF coupling, BadM physiological ligand and exact meta/para homolog-acetylation activity IDs remain represented gaps. No active PimE, native RpBadL catalysis, or tenth native step is inferred. Formal free-acid reagent identities, anionic reaction structures, constructs, taxon/strain/host identities, whole-operon genetics, predicted enzymes and direct assay evidence remain separate. Public-release licensing is the user's later decision.

`review-diagnostics.json` and preserved failed drafts/logs explain reviewer execution failures and corrections. The first page replay incorrectly assumed bibliography source hashes were displayed; actual renderer inspection corrected that assumption. First governed serialization used YAML aliases; the preserved corrected version uses the native permitted plain YAML form. These are reviewer probes, not scientific defects.

## Preservation and continuation

`final-input-preservation.json` records 361 successful checks: all 30 inspected maintained input files unchanged, four prior frozen scientific owners and every manifested file rebound, all 64 reference originals rebound, and root receipts/screenshots/report revisions copied with exact hashes. This bounded proof does not claim a whole runtime/environment inventory. Ten root receipt/report copies are retained.

Root will retain this complete frozen folder as a separate verification artifact, intended path `research/pathway_additions/2026-10-15-next-267/verification/scientific-preparation/files.tar.gz` with original-relative member names and a source-file manifest. Final completion belongs in a **new** scientific-review extension after actual retention/report adoption and terminal gates. That extension must reinspect changed maintained inputs, replace temporary evidence references with exact retained member bindings, verify source-package ownership/cutoffs, and use actual final timestamps before canonical saving. This pending original draft must remain unchanged.
