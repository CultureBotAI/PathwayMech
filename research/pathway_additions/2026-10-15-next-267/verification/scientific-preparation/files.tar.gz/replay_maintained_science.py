import collections,datetime,hashlib,html,json,re,sys,tarfile,xml.etree.ElementTree as E
from pathlib import Path
import yaml
O=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation');W=Path('/private/tmp/pathwaymech-next-267-20261015');D=Path('/private/tmp/pathwaymech-next-267-design');S=Path('/private/tmp/pathwaymech-next-267-design-successor');R=Path('/private/tmp/pathwaymech-next-267-independent-full-design-review');A=Path('/private/tmp/pathwaymech-next-267-independent-design-successor-review')
T=W/'data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def save(n,x):(O/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
checks=[]
def check(name,ok,detail=None):checks.append({'check':name,'passed':bool(ok),'detail':detail});assert ok,(name,detail)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();raw=T.read_bytes();r=yaml.safe_load(raw)
check('Actual maintained record exact accepted successor',raw==(S/'candidate-pathway.yaml').read_bytes() and sha(raw)=='40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51')
for x in read(O/'extended-inspect.json')['source']['inputs']:check('Native inspected input unchanged '+x['path'],sha((W/x['path']).read_bytes())==x['sha256'])
for root,h in [(D,'71222f9a28c44d0a15f65b0657f0ddf4dc80c19be64a94dc763e06c7a7eebf6d'),(S,'b59dd6959c89dbc36890c942ba09cc14dd7f1fe83bc3dd2c3219bc6435dffdae'),(R,'4923b1747cdadc8c880bd9a2429c84e5e767873c69e2c29859b45e2cdf5de74e'),(A,'80b0ef1c4a24202a8276482fc823439b4f46238426f2c7517940175d304a26a1')]:
 check('Exact prior scientific review owner '+str(root),sha((root/'artifact-manifest.json').read_bytes())==h)
 for x in read(root/'artifact-manifest.json')['files']:
  b=(root/x['path']).read_bytes();check('Prior bound file '+str(root)+'/'+x['path'],len(b)==x['bytes'] and sha(b)==x['sha256'])
# All reference originals and participant identity originals rebound, not merely their summaries.
archives={};originals=[]
def bound(b):
 if 'archive' in b:
  ap=Path(b['archive']['path'])
  if str(ap) not in archives:
   check('Retained archive raw hash '+str(ap),sha(ap.read_bytes())==b['archive']['sha256']);archives[str(ap)]=tarfile.open(ap)
  raw=archives[str(ap)].extractfile(b['member']).read()
 else:raw=(Path(b.get('owner',''))/b['path']).read_bytes()
 check('Exact inspected original bytes '+str(b.get('member',b.get('path'))),len(raw)==b['bytes'] and sha(raw)==b['sha256']);return raw
bindings=read(S/'reference-source-bindings.json');body={k:bound(b) for k,b in bindings.items()}
for ref in r['references']:
 check('Actual reference bound '+ref['id'],ref['source_sha256']==sha(body[ref['id']]));originals.append({'reference_id':ref['id'],'source':bindings[ref['id']],'reference':ref})
identity=read(D/'candidate-node-identity-plan.json')
for n in identity:
 for b in n.get('source_bindings',[]):bound(b)
check('62 exact participant identity plans',len(identity)==62 and {x['id'] for x in identity}=={x['id'] for x in r['participants']})
# Actual production authority data, as adopted, must supply all eighty planned terms exactly.
source=read(W/'data/identifier_authorities/sources.json');onto=read(W/'data/identifier_authorities/ontology.json');terms={**source['terms'],**onto['terms']};rows=read(S/'complete-80-node-authority-reconciliation.json')['rows'];actualnodes={n['id']:n for field in ['participants','reactions','taxa'] for n in r[field]};actualnodes[r['id']]={'id':r['id'],'label':r['label']};nodeout=[]
check('80 actual identities',len(actualnodes)==80 and len(rows)==80)
for x in rows:
 n=actualnodes[x['id']];term=terms.get(x['id']);check('Actual authority exact planned term '+x['id'],term==x['authority_term']);check('Actual local node exact approved label/category '+x['id'],n['label']==x['candidate_label'] and n.get('category')==x['category']);nodeout.append({'id':x['id'],'maintained':n,'authority':term,'role':x['role'],'label_disposition':x['label_disposition'],'source_scope':'Issuing identity/name assurance; experimental role is separately assessed on actual edges.'})
check('Whole adopted authority cardinalities',len(source['terms'])==3221 and len(source['sources'])==1209 and len(onto['terms'])==2196 and len(onto['sources'])==5)
# Fresh actual native-object replay of route, chemistry orientation, activity, components and cofactors.
path=E.fromstring(body[r['id']]).find('Pathway');assert path is not None
frame_to_id={x['native_frame']:x['id'] for x in identity if x.get('native_frame')};edges={e['id']:e for e in r['mechanistic_edges']};steps=read(D/'complete-nine-step-design.json');occ=[]
for s in steps:
 rid=s['node_id'];x=E.fromstring(body[rid]).find('Reaction');direction=next(z.findtext('direction') for z in path.findall('reaction-layout') if z.find('Reaction').get('frameid')==s['native_reaction']);check('Actual native selected traversal '+rid,direction==s['pathway_direction'])
 for side in ['left','right']:
  for i,z in enumerate(x.findall(side),1):
   bio=[c for c in z if c.tag in ['Compound','Protein']];assert len(bio)==1;frame=bio[0].get('frameid');cid=frame_to_id[frame];coeff=int(z.findtext('coefficient') or '1');incoming=(side=='left')==(direction=='L2R');triple=(cid,'consumes',rid) if incoming else (rid,'produces',cid);es=[e for e in edges.values() if (e['subject'],e['predicate'],e['object'])==triple];assert len(es)==1;loc=f"/ptools-xml/Reaction[@frameid='{s['native_reaction']}']/{side}[{i}]";check('Actual material statement and nearest native locator '+es[0]['id'],any(v['reference_id']==rid and v['source_locator']==loc and frame in v['source_assertion'] and f'coefficient {coeff}' in v['source_assertion'] for v in es[0]['evidence']));occ.append({'edge_id':es[0]['id'],'reaction':rid,'frame':frame,'coefficient':coeff,'side':'input' if incoming else 'output','locator':loc})
 back=[c.get('frameid') for z in x.findall('enzymatic-reaction') for c in z if c.tag=='Enzymatic-Reaction'];check('Actual native assignment completeness '+rid,back==s['activity_backlinks'])
check('Nine full native reactions,42 occurrences,23 native frames',len(steps)==9 and len(occ)==42 and len({x['frame'] for x in occ})==23)
for left,right in zip(steps,steps[1:]):
 e=next(e for e in edges.values() if e['subject']==left['node_id'] and e['object']==right['node_id'] and e['predicate']=='provides_input_for');common={x['frame'] for x in occ if x['reaction']==left['node_id'] and x['side']=='output'}&{x['frame'] for x in occ if x['reaction']==right['node_id'] and x['side']=='input'};check('Exact actual primary-material join '+e['id'],bool(common) and any(c in e['evidence'][0]['source_assertion'] for c in common))
for e in list(edges.values())[59:68]:
 ev=e['evidence'][0];x=E.fromstring(body[ev['reference_id']]).find('Enzymatic-Reaction');assert x is not None;enz=x.find('enzyme/Protein');rxn=x.find('reaction/Reaction');check('Actual native enzyme/activity '+e['id'],rxn.get('frameid')==e['object'].split(':')[1] and ('MetaCyc:'+enz.get('frameid')==e['subject'] or any(z.get('native_frame')==enz.get('frameid') and z['id']==e['subject'] for z in identity)))
for e in list(edges.values())[68:82]:
 ev=next(v for v in e['evidence'] if v['reference_id']==e['subject']);x=E.fromstring(body[e['subject']]).find('Protein');idx=int(re.search(r'component\[(\d+)\]',ev['source_locator'])[1]);z=x.findall('component')[idx-1];native=z.find('Protein').get('frameid');coeff=z.findtext('coefficient');check('Actual assembly component and multiplicity '+e['id'],native in ev['source_assertion'] and (('omitted' in ev['source_assertion']) if coeff is None else 'coefficient '+coeff in ev['source_assertion']) and any(n['id']==e['object'] and native in json.dumps(n) for n in identity))
for e in list(edges.values())[82:86]:
 ev=e['evidence'][0];x=E.fromstring(body[ev['reference_id']]).find('Enzymatic-Reaction');cs=[c.get('frameid') for z in x.findall('cofactor') for c in z if c.tag=='Compound'];check('Actual native cofactor pointer '+e['id'],any(c in ev['source_assertion'] and "frameid='"+c+"'" in ev['source_locator'] for c in cs))
check('No inferred active step8 or native RpBadL catalysis',not any(e['object']=='MetaCyc:1.1.1.259-RXN' and e['predicate'] in ['enables','catalyzes'] for e in edges.values()) and not any(e['subject']=='UniProtKB:G3XCQ2' and e['predicate']=='catalyzes' for e in edges.values()))
check('Auxiliary reaction outside native membership/joins',not any('RHEA:28551' in [e['subject'],e['object']] and e['predicate'] in ['part_of','has_part','provides_input_for','precedes'] for e in edges.values()))
# Record every actual edge and qualifier/evidence association alongside its declared evidence tier.
plan={x['edge_id']:x for x in read(S/'edge-evidence-plan.json')};prior=read(R/'edge-group-assessments.json');group=lambda eid:prior[0] if int(eid[1:])<=51 else prior[1] if int(eid[1:])<=59 else prior[2] if int(eid[1:])<=68 else prior[3] if int(eid[1:])<=82 else prior[4] if int(eid[1:])<=86 else prior[5] if int(eid[1:])<=91 else prior[6] if int(eid[1:])<=94 else prior[7]
edgeout=[]
for e in edges.values():
 check('Actual local edge endpoints '+e['id'],e['subject'] in actualnodes and e['object'] in actualnodes)
 refs=[]
 for v in e['evidence']+[v for q in e.get('endpoint_qualifiers',[]) for v in q['evidence']]:
  refs.append(v['reference_id']);check('Actual edge-local evidence has bound original and locator '+e['id'],v['reference_id'] in body and bool(v.get('source_locator')) and 0<len(v.get('source_assertion',v.get('quote','')))<=400)
 assessment=group(e['id'])['assessment']
 if e['id']=='e083':assessment='Actual native cofactor pointer and corrected PMID10903310 abstract-only spectroscopy/three-cluster claim are supported. The original R01 chronology attribution was independently corrected; no fixed occupancy or donor equivalence is asserted.'
 edgeout.append({'edge_id':e['id'],'actual_edge':e,'role':plan[e['id']]['role'],'evidence_reference_occurrences':refs,'outcome':'supported','scientific_assessment':assessment,'reading_scope':'Complete actual maintained claim and qualifiers freshly read. Native statements replayed directly where applicable; primary interpretation reuses explicitly bound prior independent original readings and correction review, with all source bodies freshly rebound. No fabricated fresh whole-paper reading.'})
# Actual generated page text/structure: all edge and qualifier evidence, IDs and reference hashes must survive.
p=W/'pages/records/MetaCyc_P321-PWY.html';page=p.read_text();display=[]
for e in edges.values():
 for key in ['description']:
  if key in e:display.append((e['id']+'/'+key,e[key]))
 for i,v in enumerate(e['evidence']):
  for k in ['source_assertion','source_locator','quote']:
   if k in v:display.append((e['id']+'/evidence/'+str(i)+'/'+k,v[k]))
 for q in e.get('endpoint_qualifiers',[]):
  display.append((e['id']+'/qualifier/'+q['endpoint'],q['description']))
  for i,v in enumerate(q['evidence']):
   for k in ['source_assertion','source_locator','quote']:
    if k in v:display.append((e['id']+'/qualifier/'+q['endpoint']+'/'+str(i)+'/'+k,v[k]))
for name,s in display:check('Actual generated page preserves complete field '+name,html.escape(s) in page)
for ref in r['references']:check('Actual generated bibliography exact title and hash '+ref['id'],html.escape(ref['title']) in page and ref['source_sha256'] in page)
check('Actual generated page all 100 graph edges',page.count('class="graph-edge graph-edge-')==100)
save('all-80-maintained-authority-assessments.json',nodeout);save('all-100-maintained-edge-assessments.json',edgeout);save('all-64-maintained-reference-bindings.json',originals);save('actual-native-material-replay.json',occ)
save('maintained-scientific-replay.json',{'status':'pass','started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'check_count':len(checks),'maintained_record':{'path':str(T),'bytes':len(raw),'sha256':sha(raw)},'actual_page':{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())},'actual_page_text_fields_checked':len(display),'page_visual_review':False,'full_native_gates':'Root-owned; this is independent evidence/representation replay, not a substitute for required corpus gates.'})
for t in archives.values():t.close()
print(json.dumps({'status':'pass','checks':len(checks),'edges':len(edgeout),'identities':len(nodeout),'page_fields':len(display)}))
