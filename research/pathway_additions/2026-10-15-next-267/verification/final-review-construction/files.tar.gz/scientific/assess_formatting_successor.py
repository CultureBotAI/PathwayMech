import ast,datetime,difflib,hashlib,json,os
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
B=W/'research/pathway_additions/2026-10-15-next-267'
P=B/'verification/decoder-lint-correction';R=B/'evidence-retention'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def check(label,condition):
    assert condition,label
    checks.append(dict(label=label,passed=True))
inspection=read(O/'formatting-successor-inspect.json')
for x in inspection['source']['inputs']:check('inspected input '+x['path'],sha(W/x['path'])==x['sha256'])
manifest=read(P/'artifact-manifest.json')
physical={str((Path(d)/f).relative_to(P)) for d,ds,fs in os.walk(P) for f in fs}
check('correction package closed inventory includes hidden/ignored',physical=={'artifact-manifest.json'}|{x['path'] for x in manifest['files']})
for x in manifest['files']:
    check('correction member '+x['path'],sha(P/x['path'])==x['sha256'] and (P/x['path']).stat().st_size==x['bytes'])
before=(P/'predecessor-decoder.py.txt').read_text();after=(R/'decode_retained.py').read_text()
old_ast=ast.dump(ast.parse(before),include_attributes=False);new_ast=ast.dump(ast.parse(after),include_attributes=False)
check('entire parsed module AST equal',old_ast==new_ast)
delta=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='accepted-decoder',tofile='formatting-successor-decoder'))
(O/'decoder-formatting.diff').write_text(delta)
check('one original literal replaced by parenthesized two-literal expression',len([x for x in delta.splitlines() if x.startswith('-') and not x.startswith('---')])==1 and len([x for x in delta.splitlines() if x.startswith('+') and not x.startswith('+++')])==4)
check('corrected complete module has no >100 character lines',all(len(x)<=100 for x in after.splitlines()))
old=read(P/'predecessor-artifact-manifest.json');new=read(R/'artifact-manifest.json')
old_rows={x['path']:x for x in old['files']};new_rows={x['path']:x for x in new['files']}
check('payload manifest member names unchanged',set(old_rows)==set(new_rows))
check('payload manifest metadata unchanged',{k:v for k,v in old.items() if k!='files'}=={k:v for k,v in new.items() if k!='files'})
changed=[p for p in old_rows if old_rows[p]!=new_rows[p]]
check('only decoder manifest row changed',changed==['decode_retained.py'])
payload={str((Path(d)/f).relative_to(R)) for d,ds,fs in os.walk(R) for f in fs}
check('all 5969 payload physical paths closed',len(payload)==5969 and payload==set(new_rows)|{'artifact-manifest.json'})
for p,row in new_rows.items():check('payload current member '+p,sha(R/p)==row['sha256'] and (R/p).stat().st_size==row['bytes'])
before_report=(P/'predecessor-research-report.md').read_text();after_report=(B/'README.md').read_text()
report_delta=''.join(difflib.unified_diff(before_report.splitlines(True),after_report.splitlines(True),fromfile='prior-adopted-report',tofile='formatting-successor-report'))
(O/'formatting-report.diff').write_text(report_delta)
check('mechanistic narrative before gaps unchanged',before_report.split('## Gaps')[0]==after_report.split('## Gaps')[0])
receipts=read(P/'failed-native-gates/receipts.json')
check('failed gate sequence is validate then lint only',[x['command'] for x in receipts]==[['just','validate'],['just','lint']])
check('validation passed lint failed',[x['exit_code'] for x in receipts]==[0,1])
for row in receipts:check('failed gate log '+row['log_path'],sha(P/'failed-native-gates'/Path(row['log_path']).name)==row['log_sha256'])
check('lint actually E501','E501 Line too long (108 > 100)' in (P/'failed-native-gates/just-lint.log').read_text())
check('no synthetic diff or preservation receipt after failure',len(receipts)==2)
record=W/'data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml'
check('scientific record unchanged',sha(record)=='40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51')
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='accepted_bounded_formatting',checks=checks,assertions=len(checks),payload_files=5969,unchanged_payload_files=5967,whole_module_ast_equal=True,ast_sha256=hashlib.sha256(new_ast.encode()).hexdigest(),payload_manifest_sha256=sha(R/'artifact-manifest.json'),decoder_sha256=sha(R/'decode_retained.py'),report_sha256=sha(B/'README.md'),correction_manifest_sha256=sha(P/'artifact-manifest.json'),scientific_scope='All scientific originals, source maps, 80 identities and 100 edge objects retain the preceding assessed bytes. This checks a formatting successor, not a fresh technical decoder review or execution.',failed_gate_scope='Complete first attempt preserved: validate passed, lint failed E501; diff and preservation never executed. Documented UPDATE history invocation failed before save and was corrected to native EDIT.',pending='Terminal successor validate/lint/diff gates remain required before completion.',findings=[])
(O/'formatting-successor-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks']}))
