import datetime,hashlib,json,os,tarfile
from pathlib import Path
import yaml
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
B=W/'research/pathway_additions/2026-10-15-next-267'
def load(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def check(n,v):
    assert v,n
    checks.append(dict(check=n,passed=True))
inspection=load(O/'final-input-inspect.json')
for x in inspection['source']['inputs']:check('final actual input '+x['path'],sha(W/x['path'])==x['sha256'])
r=yaml.safe_load((O/'governed-final-review.yaml').read_bytes())
check('exact native inspected source',r['source']==inspection['source'])
check('whole scientific verdict bounds',r['completion']=='completed' and r['verdict']=='pass_with_limitations' and r['scientific_review'] and not r['findings'] and not r['actions'])
check('complete source-free durable evidence references',all(not e['reference'].startswith('/private/') for e in r['evidence']))
old=yaml.safe_load((O/'governed-continuity-draft.yaml').read_bytes())
edges=[a for a in r['assessments'] if a['assessment_id'].startswith('edge-')]
check('all 100 complete edge assessments unchanged',len(edges)==100 and edges==[a for a in old['assessments'] if a['assessment_id'].startswith('edge-')])
check('no unavailable required final checks',all(not c['required'] or c['status'] in ['passed','not_applicable'] for c in r['checks']))
check('native validation terminal result',load(O/'final-native-review-validation.stdout.txt')=={'valid_reviews':1})
md=(O/'governed-final-review.md').read_text()
check('native rendered review identity',r['review_id'] in md and r['title'] in md)
check('native rendered all 119 assessments',all(a['assessment_id'] in md for a in r['assessments']))
check('native rendered all 91 evidence identities',all(e['evidence_id'] in md for e in r['evidence']))
P=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
check('original partial manifest exact',sha(P/'artifact-manifest.json')=='27ae77bb79d4d48ae332f9cc0244aac21726521ea67ef85371833fe3a36d8801')
physical={str((Path(d)/f).relative_to(P)) for d,ds,fs in os.walk(P) for f in fs}
check('original partial closed 80 files',len(physical)==80 and physical=={x['path'] for x in load(P/'artifact-manifest.json')['files']}|{'artifact-manifest.json','freeze.json'})
with tarfile.open(B/'verification/scientific-preparation/files.tar.gz') as tf:
    for p in sorted(physical):check('original partial file exact '+p,(P/p).read_bytes()==tf.extractfile(p).read())
owners=[]
for name,count,manifest_hash in [
    ('independent-full-design-review',60,'4923b1747cdadc8c880bd9a2429c84e5e767873c69e2c29859b45e2cdf5de74e'),
    ('independent-design-successor-review',39,'80b0ef1c4a24202a8276482fc823439b4f46238426f2c7517940175d304a26a1')]:
    owner=Path('/private/tmp/pathwaymech-next-267-'+name)
    rows=load(B/'evidence-retention/packages'/name/'source-map.json')['source_occurrences']
    bound={x['path']:x for x in rows};physical={str((Path(d)/f).relative_to(owner)) for d,ds,fs in os.walk(owner) for f in fs}
    check('frozen owner closed inventory '+name,len(physical)==count and physical==set(bound))
    check('frozen owner pinned manifest '+name,sha(owner/'artifact-manifest.json')==manifest_hash)
    for p,row in bound.items():check('frozen owner body '+name+'/'+p,sha(owner/p)==row['sha256'] and (owner/p).stat().st_size==row['bytes'])
    owners.append(dict(owner=name,files=count,manifest_sha256=manifest_hash,all_exact=True))
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='pass',assertions=len(checks),checks=checks,actual_inputs=len(inspection['source']['inputs']),all_actual_inputs_unchanged=True,original_partial_files=80,original_partial_unchanged=True,other_frozen_reviews=owners,review_id=r['review_id'],review_yaml_sha256=sha(O/'governed-final-review.yaml'),review_markdown_sha256=sha(O/'governed-final-review.md'),assessment_count=len(r['assessments']),evidence_count=len(r['evidence']),check_count=len(r['checks']),canonical_bundle_saved=False)
(O/'final-input-preservation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
