import datetime,difflib,hashlib,json,tarfile
from pathlib import Path,PurePosixPath
import yaml
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
B=W/'research/pathway_additions/2026-10-15-next-267';R=B/'verification/retention-integration'
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(n,ok):checks.append(dict(check=n,passed=bool(ok)));assert ok,n
check('Exact retained integration manifest',sha((R/'artifact-manifest.json').read_bytes())=='fb0c25a0682967e4326bcf57f9e584de414618ec40d89108e6062444ea9d7b2f')
for x in json.loads((R/'artifact-manifest.json').read_bytes())['files']:
 b=(R/x['path']).read_bytes();check('Integration file '+x['path'],len(b)==x['bytes'] and sha(b)==x['sha256'])
manifest=json.loads((R/'source-file-manifest.json').read_bytes());spec={x['member']:x for x in manifest['files']};raw=(R/'files.tar.gz').read_bytes();check('Archive bytes',len(raw)==manifest['archive_bytes'] and sha(raw)==manifest['archive_sha256']);bodies={};mapping=[]
with tarfile.open(R/'files.tar.gz') as t:
 ms=t.getmembers();check('Forty-member exact closure',len(ms)==len(spec)==40 and {m.name for m in ms}==set(spec))
 for m in ms:
  p=PurePosixPath(m.name);check('Regular canonical member '+m.name,m.isfile() and not p.is_absolute() and '..' not in p.parts);b=t.extractfile(m).read();x=spec[m.name];check('Exact member '+m.name,len(b)==x['bytes'] and sha(b)==x['sha256']);bodies[m.name]=b;mapping.append(dict(source_path=x['source'],retained_archive=str((R/'files.tar.gz').relative_to(W)),member=m.name,sha256=sha(b),bytes=len(b)))
adoption=json.loads(bodies['maintained-retention-adoption.json'])
check('Actual accepted payload adoption',adoption['payload_manifest_sha256']=='11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce' and adoption['payload_files']==5969 and adoption['all_file_bytes_exact'] and adoption['old263records_unchanged'])
check('Actual reader receipt hash',sha(bodies['maintained-retention-reader.json'])==adoption['actual_reader_receipt_sha256'])
reader=json.loads(bodies['maintained-retention-reader.json']);command=json.loads(bodies['maintained-retention-reader-command.json'])
check('Actual maintained reader terminal command',command['exit_code']==0 and str(B/'evidence-retention/decode_retained.py') in command['command'] and sha(bodies['maintained-retention-reader.log'])==command['log_sha256'])
check('Actual complete reader outcome',reader['status']=='pass' and reader['physical_occurrences']==13577 and reader['physical_bytes']==1644920637 and reader['compact']=={'compact_only_originals':0,'declared_rows_verified':6175} and reader['historical']['declared_rows']==477 and reader['historical']['distinct_reference_paths']==926)
check('Actual reader is offline verification, not claimed rematerialization',reader['fresh_materialization'] is None and reader['originals_compared'] is False and reader['actual_git_commit']=='02bc234143d40e0e825737f27dfdcb5fd358322f' and reader['actual_git_tree']=='08c04c1808980164ab90512f83e6e1c9bb5f16af')
report=(B/'README.md').read_bytes();check('Actual maintained report exact known final bytes',sha(report)=='4854b7dab85f8a1051408a7b52fd5ed865a30818f8a54515d7301a50b4d9e3e4')
previous=(O/'research-report-observed-terminal-gates.md').read_bytes()
check('Mechanistic narrative unchanged',previous.decode().split('## Evidence table')[0]==report.decode().split('## Evidence table')[0])
(O/'final-report-changes.diff').write_text(''.join(difflib.unified_diff(previous.decode().splitlines(True),report.decode().splitlines(True),fromfile='Reviewed external ac438405 report',tofile='Actual maintained 4854b7da report')))
(O/'maintained-research-report-observed.md').write_bytes(report)
history=json.loads(bodies['native-research-history.json']);boundaries=json.loads((B/'evidence-retention/external-original-boundaries.json').read_bytes())
check('Exactly four explicit external ontology originals',{x['namespace'] for x in boundaries['excluded_database_originals']}=={'GO','CHEBI','NCBITaxon','RHEA'} and len(boundaries['excluded_database_originals'])==4)
check('Retained Rhea142 raw source is distinct',boundaries['retained_rhea142_original']['version'].startswith('Rhea142') and boundaries['retained_rhea142_original']['sha256']=='8ee48d7044cf3eef1001fa730dae2a491902ab25b259b519d6826796bb8acedf')
hp=W/'history/other/benzoyl-coa-degradation-iii-research/2026-10-15T205546Z-Codex-83415a.yaml';h=yaml.safe_load(hp.read_bytes())
check('Actual native history receipt',history['exit_code']==0 and history['path']==str(hp.relative_to(W)) and history['sha256']==sha(hp.read_bytes()))
check('Native research-history target and actor',h['target']['path']==str((B/'README.md').relative_to(W)) and h['session']['actors']==[{'type':'ai_agent','name':'Codex','agent_tool':'codex'}] and h['events'][0]['type']=='CREATE')
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='pass',checks=checks,check_count=len(checks),source_payload_count=5969,actual_reader_command=command,actual_reader_receipt=reader,native_history_receipt=history,maintained_report_sha256=sha(report),new_history_sha256=sha(hp.read_bytes()),scientific_assessment='Complete actual report, new history, all external-database boundary rows and 35 owner-role rows freshly read. Mechanistic text remains exact; process updates accurately distinguish accepted decoder corrections, original pending review cutoffs, initial gates, actual reader and future publication. Exact graph composition is 73 base nodes plus 19 qualified endpoint occurrences, with seven taxa only in the component table. Four original ontology databases remain external; complete raw Rhea142 and all source-assertion originals are retained. No new scientific defect.',scope='Independent exact 40-member transport/receipt intake and final report/history scientific consistency. Full decoder reconstruction and technical negative controls remain attributed to their actual independent/root executions. No whole-suite rerun. Final source-documentation gate receipts still pending.')
(O/'final-integration-assessment.json').write_text(json.dumps(out,indent=2)+'\n')
(O/'durable-final-integration-member-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
print(json.dumps(dict(status='pass',checks=len(checks),reader_keys=list(reader),command=command,history_keys=list(history))))
