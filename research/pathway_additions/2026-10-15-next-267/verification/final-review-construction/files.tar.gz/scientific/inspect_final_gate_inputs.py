import datetime,hashlib,importlib.util,json,sys
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
old=json.loads((O/'formatting-successor-inspect.json').read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for x in old['source']['inputs']:assert sha(W/x['path'])==x['sha256'],x['path']
gate=W/'research/pathway_additions/2026-10-15-next-267/verification/source-documentation'
extra=sorted(str(p.relative_to(W)) for p in gate.iterdir() if p.is_file())
assert len(extra)==4
assert sha(gate/'artifact-manifest.json')=='8dedffe225b17104ecf39f1c7b7c7078ecc4d931d8c0b502fa7b3c3f382e1316'
spec=importlib.util.spec_from_file_location('native_review_final',W/'scripts/record_review.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
result=module.inspect_source(W,old['targets'],[x['path'] for x in old['source']['inputs'] if x['role']!='target']+extra)
(O/'final-input-inspect.json').write_text(json.dumps(result,indent=2)+'\n')
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_entrypoint='scripts/record_review.py inspect_source; same implementation as native inspect CLI',prior_inputs=len(old['source']['inputs']),all_prior_unchanged=True,new_inputs=extra,input_count=len(result['source']['inputs']),scope='Actual last four-file native documentation gate transport captured before final receipt assessment. No earlier inputs silently refreshed.')
(O/'final-input-inspect-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
