"""Independent selected-source recovery from actual maintained content maps; no materialization."""
import datetime,gzip,hashlib,io,json,subprocess,tarfile
from pathlib import Path,PurePosixPath
import yaml
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
R=W/'research/pathway_additions/2026-10-15-next-267/evidence-retention';V=W/'research/pathway_additions/2026-10-15-next-267/verification/scientific-preparation'
BASE='02bc234143d40e0e825737f27dfdcb5fd358322f';TREE='08c04c1808980164ab90512f83e6e1c9bb5f16af'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
checks=[]
def check(n,ok):checks.append(dict(check=n,passed=bool(ok)));assert ok,n
check('Exact current payload manifest',sha((R/'artifact-manifest.json').read_bytes())=='11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce')
check('Actual pinned Git tree',subprocess.check_output(['git','rev-parse',BASE+'^{tree}'],cwd=W).decode().strip()==TREE)
content=read(R/'content-map.json');spec=read(R/'source-specification.json');roles={x['package']:x['role'] for x in read(R/'owner-roles.json')};lookup={}
check('Thirty-five source-owner roles',len(spec['packages'])==len(roles)==35)
for package in spec['packages']:
    mp=R/'packages'/package['name']/'source-map.json';m=read(mp)
    check('Exact package identity '+package['name'],m['name']==package['name'] and m['source_root']==package['source_root'] and m['physical_inventory_includes_hidden_and_ignored'])
    for row in m['source_occurrences']:
        check('Source occurrence belongs to declared owner '+row['source'],str(Path(package['source_root'])/row['path'])==row['source'] and row['source'] not in lookup)
        lookup[row['source']]={**row,'package':package['name'],'owner_role':roles[package['name']],'source_map':str(mp.relative_to(W))}
proofs={(r['git_commit'],r['path']):r for r in read(R/'existing-owner-verification.json')};cache={};decoded=[];inherited=[]
def decode(h):
    if h in cache:return cache[h]
    row=content[h];s=row['storage'];check('Content key '+h,row['source_sha256']==h)
    if s['kind']=='existing_repository':
        check('Pinned inherited source '+h,s['git_commit']==BASE and s['git_tree']==TREE)
        p=proofs[(BASE,s['path'])];check('Inherited source proof '+h,p['git_tree']==TREE and p['sha256']==s['stored_sha256'] and p['bytes']==s['stored_bytes'])
        blob=subprocess.check_output(['git','rev-parse',BASE+':'+s['path']],cwd=W).decode().strip();check('Exact inherited Git blob '+h,blob==p['git_blob'])
        b=subprocess.check_output(['git','cat-file','blob',blob],cwd=W)
        inherited.append(dict(content_sha256=h,path=s['path'],git_commit=BASE,git_tree=TREE,git_blob=blob))
    elif s['kind']=='new_retention_object':
        q=PurePosixPath(s['path']);check('Relative physical endpoint '+h,not q.is_absolute() and '..' not in q.parts);b=(R/s['path']).read_bytes()
    elif s['kind']=='new_retention_chunks':
        pieces=[];offset=0
        for c in s['chunks']:
            check('Chunk order '+h,c['offset']==offset);piece=(R/c['path']).read_bytes();check('Chunk body '+h,len(piece)==c['bytes'] and sha(piece)==c['sha256']);pieces.append(piece);offset+=len(piece)
        b=b''.join(pieces)
    else:raise AssertionError('Unsupported actual retained storage '+s['kind'])
    check('Stored body '+h,len(b)==s['stored_bytes'] and sha(b)==s['stored_sha256'])
    for step in row['decode_steps']:
        check('Exact declared gzip input '+h,step['encoding']=='gzip' and sha(b)==step['input_sha256']);b=gzip.decompress(b);check('Exact decoded layer '+h,len(b)==step['output_bytes'] and sha(b)==step['output_sha256'])
    check('Recovered complete source '+h,len(b)==row['source_bytes'] and sha(b)==h)
    cache[h]=b;decoded.append(dict(source_sha256=h,source_bytes=len(b),storage=s,decode_steps=row['decode_steps']))
    return b
def source(path,expected_hash=None,expected_bytes=None):
    row=lookup[str(path)];h=row['sha256']
    if expected_hash:check('Bound original digest '+str(path),h==expected_hash)
    if expected_bytes is not None:check('Bound original size '+str(path),row['bytes']==expected_bytes)
    b=decode(h);check('Physical source-map body '+str(path),len(b)==row['bytes'])
    return b,row
with tarfile.open(V/'files.tar.gz') as t:
    refs=json.loads(t.extractfile('all-64-maintained-reference-bindings.json').read())
    edgeledger=json.loads(t.extractfile('all-100-maintained-edge-assessments.json').read())
    nodeledger=json.loads(t.extractfile('all-80-maintained-authority-assessments.json').read())
    partial=yaml.safe_load(t.extractfile('governed-review-draft.yaml').read())
record=yaml.safe_load((W/'data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml').read_bytes())
check('Unchanged complete target',sha((W/'data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml').read_bytes())=='40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51')
reference_map=[];archives={}
for x in refs:
    s=x['source'];member=None
    if 'archive' in s:
        a=s['archive'];raw,row=source(a['path'],a['sha256'],a['bytes'])
        if row['sha256'] not in archives:archives[row['sha256']]=tarfile.open(fileobj=io.BytesIO(raw))
        member=s['member'];b=archives[row['sha256']].extractfile(member).read()
    else:b,row=source(s['path'],s['sha256'],s['bytes'])
    check('Exact reference original '+x['reference_id'],sha(b)==s['sha256']==x['reference']['source_sha256'] and len(b)==s['bytes'])
    actual=next(r for r in record['references'] if r['id']==x['reference_id']);check('Complete current reference object '+x['reference_id'],actual==x['reference'])
    reference_map.append(dict(reference_id=x['reference_id'],reference_sha256=s['sha256'],reference_bytes=len(b),package=row['package'],owner_role=row['owner_role'],physical_source_path=row['path'],source_map=row['source_map'],content_map=str((R/'content-map.json').relative_to(W)),physical_content_sha256=row['sha256'],archive_member=member,storage=content[row['sha256']]['storage'],decode_steps=content[row['sha256']]['decode_steps']))
for a in archives.values():a.close()
# Rebind every exact identity-plan original as well as the actual source/ontology term consumer.
planraw,planrow=source('/private/tmp/pathwaymech-next-267-design/candidate-node-identity-plan.json');plan=json.loads(planraw);identity=[]
for n in plan:
    selected=[]
    for s in n.get('source_bindings',[]):
        if 'archive' in s:
            a=s['archive'];raw,row=source(a['path'],a['sha256'],a['bytes'])
            with tarfile.open(fileobj=io.BytesIO(raw)) as t:b=t.extractfile(s['member']).read()
            check('Identity archive member '+n['id'],len(b)==s['bytes'] and sha(b)==s['sha256']);selected.append(dict(package=row['package'],physical_source_path=row['path'],content_sha256=row['sha256'],member=s['member'],sha256=s['sha256']))
        else:
            path=Path(s.get('owner',''))/s['path'];b,row=source(path,s['sha256'],s['bytes']);selected.append(dict(package=row['package'],physical_source_path=row['path'],content_sha256=row['sha256'],sha256=s['sha256']))
    identity.append(dict(id=n['id'],source_bindings=selected))
nodes={x['id']:x for key in ['participants','reactions','taxa'] for x in record[key]};nodes[record['id']]={'id':record['id'],'label':record['label']}
terms={**read(W/'data/identifier_authorities/sources.json')['terms'],**read(W/'data/identifier_authorities/ontology.json')['terms']}
check('Complete participant identity plans',len(plan)==62 and {n['id'] for n in plan}=={n['id'] for n in record['participants']})
for x in nodeledger:check('Complete current identity and authority '+x['id'],nodes[x['id']]==x['maintained'] and terms[x['id']]==x['authority'])
edges={e['id']:e for e in record['mechanistic_edges']};covered={x['reference_id'] for x in reference_map};occ=0
for x in edgeledger:
    e=edges[x['edge_id']];check('Complete unchanged edge and qualifiers '+e['id'],e==x['actual_edge'])
    claims=e['evidence']+[c for q in e.get('endpoint_qualifiers',[]) for c in q['evidence']];occ+=len(claims)
    check('Every edge/qualifier original retained '+e['id'],all(c['reference_id'] in covered for c in claims))
check('Complete 100-edge/80-identity/196-evidence/64-reference closure',len(edges)==len(edgeledger)==100 and len(nodes)==len(nodeledger)==80 and occ==196 and len(covered)==64)
# Prior independent science/control evidence now receives exact retained source-map bindings.
prior=[]
for e in partial['evidence']:
    if e['reference'] in lookup:
        b,row=source(e['reference'],e.get('snapshot_sha256'));prior.append(dict(evidence_id=e['evidence_id'],original_path=e['reference'],package=row['package'],owner_role=row['owner_role'],physical_source_path=row['path'],source_map=row['source_map'],content_map=str((R/'content-map.json').relative_to(W)),content_sha256=row['sha256'],bytes=len(b)))
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='pass',checks=checks,check_count=len(checks),retained_source_owners=len(roles),physical_occurrence_map_rows=len(lookup),reference_count=len(reference_map),identity_plan_count=len(identity),identity_original_binding_count=sum(len(x['source_bindings']) for x in identity),declared_identity_count=len(nodes),edge_count=len(edges),evidence_items=occ,decoded_distinct_originals=len(decoded),pinned_git_originals=len(inherited),scope='Independent selected scientific source decoding from actual maintained content map and exact pinned Git blobs; all 64 reference originals including three nested prior archive members, every identity-plan original, every actual edge/qualifier and 80 authority consumer values verified. Prior primary interpretation is reused at its recorded reading depth. No second complete 13577-file materialization, technical decoder adversarial suite, or fresh whole-paper rereading is claimed.')
for filename,obj in [('maintained-scientific-source-rebinding.json',out),('all-64-durable-reference-bindings.json',reference_map),('all-62-durable-identity-original-bindings.json',identity),('prior-independent-science-durable-bindings.json',prior),('selected-retained-content-replay.json',decoded),('selected-pinned-git-originals.json',inherited)]:
    (O/filename).write_text(json.dumps(obj,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['checks','scope']}))
