"""Prepare governed continuity with durable verification bindings; final source adoption pending."""
import copy, datetime, hashlib, json
from pathlib import Path
import yaml
class PlainDumper(yaml.SafeDumper):
    def ignore_aliases(self,data):return True
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review')
P=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
def read(p):return json.loads(Path(p).read_bytes())
old=yaml.safe_load((P/'governed-review-draft.yaml').read_bytes())
r=copy.deepcopy(old);now=datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0);utc=now.isoformat().replace('+00:00','Z')
r['review_id']=now.strftime('%Y%m%dT%H%M%SZ')+'-benzoyl-coa-iii-scientific-continuity'
r['title']='Scientific continuity draft: benzoyl-CoA degradation III (anaerobic)'
r['started_at']=read(O/'review-start.json')['started_at'];r['finished_at']=utc
r['source']=read(O/'verification-inspect.json')['source']
r['summary']='The prior complete maintained-record scientific assessment remains supported at unchanged target bytes. All 100 edge assessments, 80 identities and primary-reading limits are carried forward explicitly. The original partial review is preserved in the maintained verification archive; all 199 members across four verification packages and terminal native gate receipts were independently rebound. This new supplement remains partial pending actual corrected source-retention/report adoption, final history and documentation gates; it is not a completed canonical review.'
r['reviewer']['independence_basis']='Authored neither maintained scientific data, source-retention implementation, authority implementation nor root adoption. Reuses this reviewer’s explicit earlier independent original readings and full maintained assessment; current continuity checks are independent of source/correction authors.'
mapping=read(O/'durable-verification-member-map.json');by_source={}
for x in mapping:by_source.setdefault(x['source_path'],[]).append(x)
changes=[]
for e in r['evidence']:
    matches=by_source.get(e['reference'],[])
    if matches:
        # Prefer the original scientific preparation archive for its own evidence.
        matches.sort(key=lambda x:('scientific-preparation' not in x['retained_archive'],x['retained_archive'],x['member']))
        x=matches[0];before=e['reference'];e['reference']=x['retained_archive']
        e['locator']='Exact archive member '+x['member']+('. '+e['locator'] if e.get('locator') else '')
        e['accessed_at']=utc
        changes.append(dict(evidence_id=e['evidence_id'],previous_reference=before,archive=x['retained_archive'],member=x['member'],member_sha256=x['sha256']))
        if 'snapshot_sha256' in e:assert e['snapshot_sha256']==x['sha256']
base='research/pathway_additions/2026-10-15-next-267/verification'
def evidence(i,kind,ref,locator,summary,sha=None):
    e=dict(evidence_id=i,kind=kind,reference=ref,locator=locator,accessed_at=utc,support='supports',summary=summary)
    if sha:e['snapshot_sha256']=sha
    r['evidence'].append(e)
evidence('terminal-native-gates','validation',base+'/initial-gates/files.tar.gz','native-gates/receipts.json; native-gates/just-test.log; native-gates/just-validate.log; native-gates/just-lint.log; native-gates/git-diff---check.log; native-gates/tested-core-input-hashes.json; native-gates/final-input-preservation.json','All four native commands terminated zero. Complete log: 5,965 passed, three skipped, seven dependency-deprecation warnings. Declared 29,580-file input inventory remained unchanged within the recorded scope. Root execution and this independent receipt/member intake are distinct; later retained-payload/report additions are outside that initial cutoff.',read(O/'verification-transport-replay.json')['packages']['initial-gates']['archive_sha256'])
evidence('durable-partial-review','prior_review',base+'/scientific-preparation/files.tar.gz','artifact-manifest.json; freeze.json; HANDOFF.md; governed-review-draft.yaml; all-100-maintained-edge-assessments.json','All 80 original partial scientific files are preserved byte-for-byte, plus two explicit inert transport helpers. Original manifest 27ae77bb79d4d48ae332f9cc0244aac21726521ea67ef85371833fe3a36d8801 and partial verdict are unchanged. Primary-reading reuse and original failed probes remain explicit.',read(O/'verification-transport-replay.json')['packages']['scientific-preparation']['archive_sha256'])
evidence('durable-technical-context','prior_review',base+'/technical-preparation/files.tar.gz','HANDOFF.md; artifact-manifest.json','Independent technical preparation is preserved with its original partial cutoff: 57 targets, 80 inputs, 2,230 assertions, zero findings. This scientific supplement verifies transport and reads the handoff; it does not claim a second technical implementation review.',read(O/'verification-transport-replay.json')['packages']['technical-preparation']['archive_sha256'])
for c in r['checks']:
    if c['check_id'] in ['validate','test','lint','diff-check']:
        c.update(status='passed',summary='Complete retained terminal root receipt and log independently read and rebound. Initial 264-record code/corpus gate cutoff precedes final retention/report adoption.',evidence_ids=['terminal-native-gates'],exit_code=0,expected_exit_code=0)
        c['command']={'validate':'just validate','test':'just test','lint':'just lint','diff-check':'git diff --check'}[c['check_id']]+' (root-owned terminal receipt; not rerun by reviewer)'
r['checks'].append(dict(check_id='final-documentation',name='Final retained-source/report/history and documentation gates',status='unavailable',required=True,summary='Root will supply actual accepted/adopted source-retention/report/history inputs and final documentation gate receipts; no completion inferred from earlier code/corpus gates.',target_ids=['MetaCyc:P321-PWY']))
r['assessments'].append(dict(assessment_id='durable-continuity',area='provenance',topic='Immutable partial review and terminal gate continuity',outcome='supported',summary='Four maintained verification packages preserve all 199 exact regular members. Scientific preparation retains its original partial verdict and full edge assessments; terminal native receipts are now available and bound.',target_ids=['MetaCyc:P321-PWY'],evidence_ids=['durable-partial-review','terminal-native-gates','durable-technical-context'],details='Independent replay passed 687 assertions. No source archive/helper is executed during transport verification. Technical decoder successor and final maintained source/report adoption are still separate pending inputs.'))
for a in r['assessments']:
    if a['assessment_id']=='representation':
        a['details']+=' The independent technical preparation resolves display-node composition explicitly: 73 base pathway/participant/reaction nodes plus 19 qualified endpoint occurrences; seven declared taxa remain table context. The net 92-minus-80 difference is not a qualifier count.'
        a['evidence_ids'].append('durable-technical-context')
r['limitations'][0]='Provisional final supplement: terminal initial corpus gates are now bound, but accepted/adopted corrected source retention, final maintained report/history and final documentation gates remain pending. No canonical completion or publication approval is claimed.'
r['notes']=[
    'The original scientific preparation is immutable and partial. This supplement began at the separately recorded actual UTC start and reuses its complete scientific assessment at unchanged maintained record bytes.',
    'Verification evidence references have been rebound to actual maintained archives and exact members. Temporary original-source and earlier external scientific-owner bindings await accepted source-retention adoption; do not save this draft canonically.',
    'Root is the sole canonical saver. No maintained/source/Git/GH/runtime writes, installations or child agents were performed by this reviewer.',
    'Current draft finish is the actual continuity-pass timestamp, not the final review completion. A final accepted version must recheck changed inputs and use its actual final timestamp.'
]
(O/'governed-continuity-draft.yaml').write_text(yaml.dump(r,Dumper=PlainDumper,sort_keys=False,allow_unicode=True,width=100))
(O/'durable-reference-rebindings.json').write_text(json.dumps(changes,indent=2)+'\n')
(O/'continuity-draft-build.json').write_text(json.dumps(dict(utc=utc,completion=r['completion'],assessments=len(r['assessments']),evidence=len(r['evidence']),checks=len(r['checks']),durable_references_rebound=len(changes),record_sha256='40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51'),indent=2)+'\n')
print(json.dumps(dict(status='draft',completion='partial',assessments=len(r['assessments']),evidence=len(r['evidence']),durable_rebindings=len(changes))))
