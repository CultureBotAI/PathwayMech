import datetime,hashlib,json,tarfile
from pathlib import Path,PurePosixPath
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
R=W/'research/pathway_additions/2026-10-15-next-267/verification/retention-successor-review'
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
def check(n,ok):checks.append(dict(check=n,passed=bool(ok)));assert ok,n
root=Path('/private/tmp/pathwaymech-next-267-ci/root-retention-independent-acceptance.json').read_bytes();accept=json.loads(root)
check('Known accepted transport manifest',sha((R/'artifact-manifest.json').read_bytes())=='3cbb516e7cb21da2b19ac6c90ae60e6c6bb34fb6c6b4fa84e001133330b2ebe8')
for row in json.loads((R/'artifact-manifest.json').read_bytes())['files']:
 b=(R/row['path']).read_bytes();check('Package body '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'])
source=json.loads((R/'source-file-manifest.json').read_bytes());raw=(R/'files.tar.gz').read_bytes();check('Archive identity',len(raw)==source['archive_bytes'] and sha(raw)==source['archive_sha256']==accept['archive']['archive_sha256'])
spec={x['member']:x for x in source['files']};bodies={};maprows=[]
with tarfile.open(R/'files.tar.gz') as t:
 members=t.getmembers();check('Complete 79-member declared closure',len(spec)==len(members)==79 and {m.name for m in members}==set(spec))
 for m in members:
  p=PurePosixPath(m.name);check('Regular canonical member '+m.name,m.isfile() and not p.is_absolute() and '..' not in p.parts and str(p)==m.name)
  b=t.extractfile(m).read();row=spec[m.name];check('Complete member bytes '+m.name,len(b)==row['bytes'] and sha(b)==row['sha256']);bodies[m.name]=b;maprows.append(dict(source_path=row['source'],retained_archive=str((R/'files.tar.gz').relative_to(W)),member=m.name,bytes=len(b),sha256=sha(b)))
check('Exact full independent-review manifest',sha(bodies['artifact-manifest.json'])==accept['review_manifest_sha256']=='b876ce237d87ec10f33656d93c36fe7bb42f01fecfdafb283b3df7ae3e39790c')
fm=json.loads(bodies['artifact-manifest.json']);declared={x['path']:x for x in fm['files']}
for n,b in bodies.items():
 if n in declared:
  x=declared[n];check('Preserved frozen review control '+n,len(b)==x['bytes'] and sha(b)==x['sha256'])
findings=json.loads(bodies['findings.json']);check('Bounded accepted dispositions',findings['status']=='accepted-bounded-retention-successor' and findings['findings']==[] and sorted(x['issue'] for x in findings['prior_finding_dispositions'])==[604,605])
check('Exact source-payload acceptance only',findings['source_payload_manifest_sha256']==accept['payload_manifest_sha256']=='11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce')
freeze=json.loads(bodies['freeze-proof.json']);check('Full external reconstruction scope retained',freeze['actual_reconstruction_outputs']==14503 and freeze['physical_files']==14578 and freeze['new_findings']==0)
check('Reconstruction output binding manifest',sha(bodies['verification-output-bindings.json'])==freeze['verification_output_bindings_sha256'])
for n in ['HANDOFF.md','ASSESSMENT.md','findings.json','freeze-proof.json']:(O/('retention-review-'+n.replace('.md','.txt'))).write_bytes(bodies[n])
(O/'root-retention-independent-acceptance.json').write_bytes(root)
(O/'durable-retention-control-member-map.json').write_text(json.dumps(maprows,indent=2)+'\n')
(O/'retention-review-controls-intake.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='pass',checks=checks,check_count=len(checks),archive_members=79,scope='Independent exact transport and explicit review-disposition intake. HANDOFF/ASSESSMENT/findings/freeze read completely. This reviewer does not repeat 78 technical rejection cases or 14503-file reconstruction, and does not claim source payload is maintained until root terminal adoption is separately bound.'),indent=2)+'\n')
print(json.dumps(dict(status='pass',checks=len(checks),members=79)))
