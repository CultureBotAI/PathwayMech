"""Build final governed content only after an independently assessed terminal cutoff."""
import copy
import datetime
import hashlib
import json
from pathlib import Path

import yaml

O = Path('/private/tmp/pathwaymech-next-267-final-scientific-review')
W = Path('/private/tmp/pathwaymech-next-267-20261015')
BASE = 'research/pathway_additions/2026-10-15-next-267'
RETENTION = BASE + '/evidence-retention'


class PlainDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


def load(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


cutoff = load(O / 'final-cutoff-assessment.json')
assert cutoff['status'] == 'accepted' and cutoff['all_required_gates_terminal_zero']
inspection = load(O / 'final-input-inspect.json')
for item in inspection['source']['inputs']:
    assert sha(W / item['path']) == item['sha256'], item['path']
old = yaml.safe_load((O / 'governed-continuity-draft.yaml').read_bytes())
r = copy.deepcopy(old)
now = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
utc = now.isoformat().replace('+00:00', 'Z')
r.update(
    review_id=now.strftime('%Y%m%dT%H%M%SZ') + '-benzoyl-coa-iii-scientific-review',
    title='Scientific review: benzoyl-CoA degradation III (anaerobic)',
    finished_at=utc,
    completion='completed',
    verdict='pass_with_limitations',
    source=inspection['source'],
    summary=(
        'The complete actual maintained MetaCyc:P321-PWY record is supported with its '
        'explicit scientific limitations: all 80 identities, 100 edges, 196 evidence items '
        'and 64 references are accounted for. Nine native steps remain distinct from '
        'auxiliary homolog chemistry. Complete record assessment and prior original '
        'readings are explicitly reused at unchanged target bytes; this supplement '
        'independently verifies adopted source retention, report/history, exact source '
        'recovery, terminal native gates and changed-input successors. No new actionable '
        'scientific findings remain. Original partial reviews and all failed probes/gates '
        'remain preserved; this is not public-release or licensing approval.'
    ),
)
assert r['started_at'] == '2026-10-15T20:45:52Z'
record = yaml.safe_load((W / r['targets'][0]['path']).read_bytes())
bindings = {x['reference_id']: x for x in load(O / 'all-64-durable-reference-bindings.json')}
evidence_by_id = {x['evidence_id']: x for x in r['evidence']}
evidence_by_id['research-draft']['summary'] = (
    'Preserved earlier draft assessment: its complete read and formal-net/evidence-count '
    'calculation agreed with maintained science. The shorter-purification wording '
    'recommendation concerns clarity, not altered sequence identity. At that original '
    'partial cutoff the final maintained report/retention was not yet bound; the '
    'separate current evidence entries now complete those bindings.'
)
rebinding = []
for index, ref in enumerate(record['references'], 1):
    evidence = evidence_by_id[f'source-{index:03d}']
    bound = bindings[ref['id']]
    assert bound['reference_sha256'] == ref['source_sha256'] == evidence['snapshot_sha256']
    assert evidence['reference'] == ref['url']
    evidence['summary'] = evidence['summary'].split(' Original binding: ', 1)[0]
    locator = (
        f" Retained original: {bound['source_map']}, source_occurrences path "
        f"{bound['physical_source_path']}; {bound['content_map']} key "
        f"{bound['physical_content_sha256']}; owner role {bound['owner_role']}."
    )
    if bound['archive_member']:
        locator += (
            f" Exact nested archive member {bound['archive_member']}, decoded member "
            f"SHA256 {bound['reference_sha256']} ({bound['reference_bytes']} bytes)."
        )
    else:
        locator += f" Decoded original {bound['reference_bytes']} bytes."
    evidence['locator'] = evidence.get('locator', '') + locator
    evidence['accessed_at'] = utc
    rebinding.append({'evidence_id': evidence['evidence_id'], **bound})
for bound in load(O / 'prior-independent-science-durable-bindings.json'):
    evidence = evidence_by_id[bound['evidence_id']]
    assert evidence['snapshot_sha256'] == bound['content_sha256']
    evidence['reference'] = bound['source_map']
    evidence['locator'] = (
        f"source_occurrences path {bound['physical_source_path']}; "
        f"{bound['content_map']} key {bound['content_sha256']}; exact decoded "
        f"{bound['bytes']} bytes; owner role {bound['owner_role']}."
    )
    evidence['accessed_at'] = utc
    rebinding.append(bound)


def add_evidence(eid, kind, reference, locator, summary, digest=None):
    assert eid not in evidence_by_id
    row = dict(evidence_id=eid, kind=kind, reference=reference, locator=locator,
               accessed_at=utc, support='supports', summary=summary)
    if digest:
        row['snapshot_sha256'] = digest
    r['evidence'].append(row)
    evidence_by_id[eid] = row


add_evidence(
    'maintained-source-retention', 'record_content', RETENTION + '/artifact-manifest.json',
    'Entire closed physical package; source-specification.json; source-package-inventory.json; '
    'owner-roles.json; content-map.json; all 35 package source-map.json files.',
    'All 5,969 adopted physical files were captured before assessment. Independently parsed '
    'all 13,577 source occurrences and directly decoded 152 distinct scientific originals, '
    'including 120 exact pinned-Git originals, all 64 reference bodies (three nested archive '
    'members) and 122 identity-original bindings for 62 participants. All 80 authority '
    'bindings and all 100 complete edge objects including every qualifier remain exact. '
    '15,739 independent source-rebinding assertions passed. This selected scientific '
    'decoding is distinct from the separately accepted full reconstruction.',
    sha(W / RETENTION / 'artifact-manifest.json'),
)
add_evidence(
    'maintained-research-report', 'record_content', BASE + '/README.md',
    'Entire maintained report, including source-boundary, chemistry, evidence, gaps, '
    'retention, verification and process-cutoff sections.',
    'The actual maintained report was fully read and compared with the independently '
    'reviewed draft. Scientific interpretation remains consistent with the exact record: '
    'nine native steps, auxiliary homolog chemistry, abstract-only spectroscopy source, '
    'construct limitations and finite source gaps. Subsequent process-only changes and '
    'formatting-successor lineage were explicitly reassessed.', sha(W / BASE / 'README.md'),
)
add_evidence(
    'ontology-original-boundaries', 'record_content',
    RETENTION + '/external-original-boundaries.json', 'All four external-original entries.',
    'GO 2026-07-26, ChEBI 255, NCBI Taxonomy 2026-07-12 and Rhea 139 full ontology '
    'databases remain external prerequisites for whole-ontology reconstruction; metadata, '
    'selected derived authorities and build receipts are retained. The separately used '
    'complete Rhea 142 raw gzip is retained and independently decoded for scientific '
    'reaction evidence. Selected science recovery does not claim all four DBs are bundled.',
    sha(W / RETENTION / 'external-original-boundaries.json'),
)
add_evidence(
    'retention-successor-acceptance', 'prior_review',
    BASE + '/verification/retention-successor-review/files.tar.gz',
    'HANDOFF.md; ASSESSMENT.md; findings.json; freeze-proof.json; all exact 79 '
    'members listed in source-file-manifest.json.',
    'Independent decoder review resolves historical-declaration/provenance #604 and '
    'scratch-confinement #605 in the explicit successor, preserving the original review '
    'and failed probes. All 79 transport members were independently replayed (242 checks). '
    'The accepted original review covers 78 negative cases and full reconstruction; '
    'this scientific reviewer did not rerun that full technical review.',
    sha(W / BASE / 'verification/retention-successor-review/files.tar.gz'),
)
add_evidence(
    'actual-retention-integration', 'validation',
    BASE + '/verification/retention-integration/files.tar.gz',
    'All 40 exact members; maintained-retention-adoption.json; '
    'maintained-retention-reader-command.json; maintained-retention-reader.json; '
    'maintained-retention-reader.log; native-research-history.json.',
    'Independent intake passed 97 checks. The actual maintained decoder returned zero '
    'and verified all 13,577 physical occurrences, 6,175 current declarations and 477 '
    'historical declarations over 926 historical reference paths against the pinned base. '
    'Its fresh_materialization is null: this is complete offline verification, not a '
    'second fresh reconstruction. All 263 prior record bytes were preserved. This '
    'archive retains the earlier adoption cutoff; later formatting correction is '
    'separately bound by final gate evidence.',
    sha(W / BASE / 'verification/retention-integration/files.tar.gz'),
)
for item in cutoff['evidence']:
    add_evidence(**item)

assessments = {a['assessment_id']: a for a in r['assessments']}
assessments['report'].update(
    summary='The complete actual maintained report agrees with the record, formal net, '
            'evidence counts and explicit scientific/source-reconstruction limitations.',
    details='Earlier draft readings remain preserved. Maintained adoption and subsequent '
            'process-only formatting-successor updates were explicitly compared; none '
            'alters the mechanism interpretation or native/auxiliary distinction.',
    evidence_ids=['research-draft', 'maintained-research-report', 'ontology-original-boundaries'],
)
assessments['representation']['summary'] = (
    'Native page fields, 100 relationships and every source qualifier survive rendering '
    'and export. The 92 display nodes are 73 base pathway/participant/reaction nodes '
    'plus 19 qualified endpoint occurrences; seven taxa remain table context.'
)
assessments['claim-accounting']['evidence_ids'].append('maintained-source-retention')
assessments['authority-integration']['evidence_ids'].append('maintained-source-retention')
assessments['durable-continuity'].update(
    summary='Immutable partial scientific preparation and all technical/root verification '
            'cutoffs remain preserved with exact members and honest ownership.',
    details='Four original verification packages passed 687 independent assertions for '
            '199 members. Later decoder-review and integration packages independently '
            'passed 242 and 97 checks respectively. Full scientific edge assessments '
            'are carried forward; technical transport checks are not primary science. '
            'The source/report successor and terminal gates are separately bound.',
    evidence_ids=['durable-partial-review', 'terminal-native-gates',
                  'durable-technical-context', 'retention-successor-acceptance',
                  'actual-retention-integration'] + cutoff['evidence_ids'],
)
r['assessments'].append(dict(
    assessment_id='durable-primary-sources', area='provenance',
    topic='Actual retained originals, ownership and external ontology boundaries',
    outcome='supported', target_ids=['MetaCyc:P321-PWY'],
    summary='Every record reference and selected native identity source is recoverable '
            'from the actual maintained mappings at exact original hashes. Source '
            'authors, independent reviewers and root integration cutoffs remain distinct.',
    details='All 64 evidence references now have maintained source-map/content-map '
            'locators; three nested prior-266 originals retain exact archive-member '
            'bindings. 122 identity-source occurrences cover all 62 participants. '
            'Full original literature reading is reused only at its recorded depth. '
            'Four large ontology database originals remain explicitly external; no '
            'global source-completeness or public redistribution conclusion is made.',
    evidence_ids=['maintained-source-retention', 'ontology-original-boundaries',
                  'retention-successor-acceptance', 'actual-retention-integration'],
))
for check in r['checks']:
    if check['check_id'] == 'retention':
        check.update(status='passed', summary='Actual retained scientific originals, '
                     'report, source ownership and native histories independently '
                     'rebound, including explicit changed-input successor reassessment.',
                     evidence_ids=['maintained-source-retention', 'maintained-research-report',
                                   'actual-retention-integration'] + cutoff['evidence_ids'])
    elif check['check_id'] == 'final-documentation':
        check.update(status='passed', summary=cutoff['gate_summary'],
                     evidence_ids=cutoff['evidence_ids'], exit_code=0, expected_exit_code=0,
                     command='Root-owned terminal final documentation gates; complete '
                             'receipts and logs independently inspected, not rerun here.')
r['limitations'][0] = (
    'Completed scientific review of one maintained record at the exact declared working-tree '
    'inputs. Other 263 records were checked for preservation, not freshly reassessed '
    'scientifically. Full tests cover the earlier unchanged code/corpus cutoff; final '
    'source/report changes have their separate terminal validation/lint/diff receipts.'
)
r['limitations'].append(
    'Whole-ontology rebuild still requires the four external original databases listed '
    'in the maintained retention boundary record; all selected scientific originals '
    'were independently recovered. The retained complete Rhea 142 source is distinct '
    'from the external Rhea 139 ontology database.'
)
r['notes'] = [
    'This supplement started at actual UTC 2026-10-15T20:45:52Z. It explicitly reuses '
    'the complete maintained-record reading and source interpretations recorded in '
    'the earlier independent 20:11:06Z–20:26:56Z assessment, then independently checks '
    'new retained evidence and every changed input. No fresh whole-paper reread is fabricated.',
    'Original design needs-curation review, accepted bounded corrections, and original '
    'partial maintained preparation remain immutable. External #600–603 and technical '
    '#604–605 lineage is preserved; this review does not fabricate canonical '
    'previous_occurrences or close issues.',
    'The source-documentation E501 failure is retained with the explicit formatting-only '
    'successor and terminal successful rerun. It is not suppressed or converted into '
    'a scientific finding; original scientific data and source-content objects remain exact.',
    'All evidence has maintained repository references or primary source URLs with '
    'exact retained-original locators. No new report depends solely on temporary owners.',
    'Root is the sole canonical saver. This reviewer made no maintained/source/Git/GH/'
    'runtime changes, installations or child agents. Canonical persistence and its '
    'native check follow this accepted external content.',
]
r['links'] += ['https://github.com/CultureBotAI/PathwayMech/issues/604',
               'https://github.com/CultureBotAI/PathwayMech/issues/605',
               'https://github.com/CultureBotAI/PathwayMech/issues/606']
assert len(bindings) == 64 and len(rebinding) == 67
assert not any(e['reference'].startswith('/private/') for e in r['evidence'])
assert not any(c['required'] and c['status'] in ['unavailable', 'skipped', 'failed']
               for c in r['checks'])
old_edges = [a for a in old['assessments'] if a['assessment_id'].startswith('edge-')]
new_edges = [a for a in r['assessments'] if a['assessment_id'].startswith('edge-')]
assert len(old_edges) == 100 and old_edges == new_edges
assert not r['findings'] and not r['actions']
(O / 'governed-final-review.yaml').write_text(yaml.dump(
    r, Dumper=PlainDumper, sort_keys=False, allow_unicode=True, width=100))
(O / 'final-durable-reference-rebindings.json').write_text(json.dumps(rebinding, indent=2) + '\n')
result = dict(utc=utc, completion=r['completion'], verdict=r['verdict'],
              assessments=len(r['assessments']), edge_assessments=len(new_edges),
              evidence=len(r['evidence']), checks=len(r['checks']),
              inputs=len(r['source']['inputs']), durable_rebindings=len(rebinding),
              scientific_edge_assessments_unchanged=True,
              record_sha256=sha(W / r['targets'][0]['path']))
(O / 'final-review-build.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
