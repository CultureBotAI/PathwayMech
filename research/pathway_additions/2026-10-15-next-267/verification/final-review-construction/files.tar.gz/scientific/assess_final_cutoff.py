import datetime,hashlib,json,tarfile
from pathlib import Path,PurePosixPath
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
B='research/pathway_additions/2026-10-15-next-267'
P=W/B/'verification/source-documentation'
def load(p):return json.loads(Path(p).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
def check(n,v):
    assert v,n
    checks.append(dict(check=n,passed=True))
inspection=load(O/'final-input-inspect.json')
check('native final source inspected',len(inspection['source']['inputs'])==6052)
for x in inspection['source']['inputs']:check('current inspected input '+x['path'],sha((W/x['path']).read_bytes())==x['sha256'])
manifest=load(P/'artifact-manifest.json')
check('final transport manifest binding',sha((P/'artifact-manifest.json').read_bytes())=='8dedffe225b17104ecf39f1c7b7c7078ecc4d931d8c0b502fa7b3c3f382e1316')
for row in manifest['files']:check('package body '+row['path'],sha((P/row['path']).read_bytes())==row['sha256'] and (P/row['path']).stat().st_size==row['bytes'])
source=load(P/'source-file-manifest.json');expected={r['member']:r for r in source['files']}
check('archive original manifest binding',sha((P/'files.tar.gz').read_bytes())==source['archive_sha256'] and (P/'files.tar.gz').stat().st_size==source['archive_bytes'])
bodies={};durable=[]
with tarfile.open(P/'files.tar.gz') as tf:
    members=tf.getmembers();check('closed twelve member archive',len(members)==12 and {m.name for m in members}==set(expected))
    for m in members:
        path=PurePosixPath(m.name);check('canonical regular '+m.name,m.isfile() and not path.is_absolute() and '..' not in path.parts and str(path)==m.name)
        b=tf.extractfile(m).read();row=expected[m.name]
        check('exact full member '+m.name,len(b)==row['bytes'] and sha(b)==row['sha256'])
        bodies[m.name]=b;durable.append(dict(source_path=row['source'],archive=B+'/verification/source-documentation/files.tar.gz',member=m.name,sha256=sha(b),bytes=len(b)))
receipts=json.loads(bodies['checks/receipts.json']);inventory=json.loads(bodies['checks/tested-core-input-hashes.json']);pres=json.loads(bodies['checks/final-input-preservation.json']);delta=json.loads(bodies['checks/delta-accounting.json'])
check('exact three terminal gate commands',[x['command'] for x in receipts]==[['just','validate'],['just','lint'],['git','diff','--check']])
for r in receipts:
    check('terminal gate '+str(r['command']),r['exit_code']==0 and r['cwd']==str(W) and sha(bodies['checks/'+Path(r['log_path']).name])==r['log_sha256'])
check('actual closed-schema/label/page validation',all(x in bodies['checks/just-validate.log'].decode() for x in ['validated 264 records against the closed LinkML schema','verified identifiers and label policies in 264 pathway records','checked 20651 evidence blocks','500 history record(s) valid','pages/ is current with 264 pathway records']))
check('actual lint clean','All checks passed!' in bodies['checks/just-lint.log'].decode())
check('actual diff log empty',bodies['checks/git-diff---check.log']==b'')
check('full gate inventory stable',len(inventory)==35596 and pres['tested_core_files']==35596 and pres['all_unchanged'] and pres['ignored_and_hidden_included'])
with tarfile.open(W/B/'verification/initial-gates/files.tar.gz') as tf:initial=json.loads(tf.extractfile('native-gates/tested-core-input-hashes.json').read())
check('all 29580 prior full-tested inputs exact',len(initial)==29580 and all(inventory.get(p)==h for p,h in initial.items()))
check('gate delta acknowledges unchanged full-test cutoff',delta['original_tested_files']==29580 and delta['all_original_tested_inputs_unchanged'])
gate_covered=[];outside=[]
for x in inspection['source']['inputs']:
    if x['path'] in inventory:
        check('assessed input actually gated '+x['path'],inventory[x['path']]==x['sha256']);gate_covered.append(x['path'])
    else:outside.append(x['path'])
check('honest post-gate/archive and out-of-scope inventory',set(outside)=={'CLAUDE.md'}|{B+'/verification/source-documentation/'+n for n in ['README.md','artifact-manifest.json','files.tar.gz','source-file-manifest.json']})
formatting=load(O/'formatting-successor-assessment.json')
check('independent formatting acceptance',formatting['status']=='accepted_bounded_formatting' and formatting['assertions']==12051 and formatting['whole_module_ast_equal'] and not formatting['findings'])
for name in ['checks/receipts.json','checks/final-input-preservation.json','checks/just-validate.log','checks/just-lint.log']:(O/('final-native-'+Path(name).name)).write_bytes(bodies[name])
evidence=[dict(eid='final-native-doc-gates',kind='validation',reference=B+'/verification/source-documentation/files.tar.gz',locator='checks/receipts.json; complete validate/lint/diff logs; checks/tested-core-input-hashes.json; checks/final-input-preservation.json; checks/delta-accounting.json; all 12 exact members.',summary='Actual successor validate, lint and diff check all terminated zero. The full 35,596-input window was unchanged, including all 29,580 earlier full-tested inputs. Of this review’s 6,052 inputs, 6,047 match that gate inventory; CLAUDE.md is outside its scope and the four self-contained gate transport files were created afterward. These limits are explicit, not retroactive test claims.',digest=source['archive_sha256']),dict(eid='decoder-formatting-successor',kind='validation',reference=B+'/verification/decoder-lint-correction/artifact-manifest.json',locator='All 19 listed members; correction.json; predecessor-decoder.py.txt; predecessor-artifact-manifest.json; predecessor-research-report.md; failed-native-gates/; native-history*.',summary='Issue606 formatting-only successor independently accepted with 12,051 assertions: exact full module AST, unchanged 5,967 other payload files, preserved source-content/record bytes and process-only report delta. The failed validate-then-lint attempt and rejected UPDATE history invocation remain preserved; corrected EDIT history is native. Prior decoder execution is explicitly reused via AST identity, not rerun.',digest=formatting['correction_manifest_sha256']),dict(eid='native-research-history',kind='record_content',reference='history/other/benzoyl-coa-degradation-iii-research/2026-10-15T210509Z-Codex-bf356c.yaml',locator='Entire native EDIT record, linked issue606; prior CREATE report history 2026-10-15T205546Z-Codex-83415a.yaml and original record/infrastructure CREATE histories are separately inspected inputs.',summary='Native history records author adoption and formatting correction with actual actor, timestamps and pending subsequent review/gate cutoffs. It does not claim scientific status promotion, issue closure or publication.',digest=sha((W/'history/other/benzoyl-coa-degradation-iii-research/2026-10-15T210509Z-Codex-bf356c.yaml').read_bytes()))]
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='accepted',all_required_gates_terminal_zero=True,checks=checks,assertions=len(checks),archive_members=12,input_count=6052,gate_inventory_count=35596,prior_full_test_input_count=29580,review_inputs_matching_gate=len(gate_covered),review_inputs_outside_gate=outside,receipts=receipts,evidence=evidence,evidence_ids=[e['eid'] for e in evidence],gate_summary='The explicit source-documentation successor ran just validate, just lint and git diff --check to exit zero; full 35,596-input before/after inventory unchanged, all 29,580 prior full-tested inputs exact. Complete initial E501 failure and formatting-only correction are preserved. Full tests were not unnecessarily repeated for documentary additions.',findings=[],scope='Independent transport, terminal receipt semantics and exact assessed-input matching; root owns execution. Canonical review persistence/publication follow this scientific cutoff.')
(O/'final-cutoff-assessment.json').write_text(json.dumps(result,indent=2)+'\n');(O/'durable-final-gate-member-map.json').write_text(json.dumps(durable,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','evidence','receipts']}))
