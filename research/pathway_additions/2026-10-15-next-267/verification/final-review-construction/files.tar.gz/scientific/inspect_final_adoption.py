import datetime,hashlib,importlib.util,json,os,sys
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review');W=Path('/private/tmp/pathwaymech-next-267-20261015')
old=json.loads((O/'retention-controls-inspect.json').read_bytes());checks=[]
for x in old['source']['inputs']:
 h=hashlib.sha256((W/x['path']).read_bytes()).hexdigest();assert h==x['sha256'],x['path'];checks.append(dict(path=x['path'],sha256=h,unchanged=True))
payload=W/'research/pathway_additions/2026-10-15-next-267/evidence-retention'
manifest=payload/'artifact-manifest.json';assert hashlib.sha256(manifest.read_bytes()).hexdigest()=='11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce'
physical=sorted(str((Path(d)/f).relative_to(W)) for d,ds,fs in os.walk(payload) for f in fs)
assert len(physical)==5969
integration=W/'research/pathway_additions/2026-10-15-next-267/verification/retention-integration'
extra=physical+sorted(str(p.relative_to(W)) for p in integration.iterdir() if p.is_file())+['research/pathway_additions/2026-10-15-next-267/README.md','history/other/benzoyl-coa-degradation-iii-research/2026-10-15T205546Z-Codex-83415a.yaml']
assert hashlib.sha256((integration/'artifact-manifest.json').read_bytes()).hexdigest()=='fb0c25a0682967e4326bcf57f9e584de414618ec40d89108e6062444ea9d7b2f'
assert hashlib.sha256((W/extra[-2]).read_bytes()).hexdigest()=='4854b7dab85f8a1051408a7b52fd5ed865a30818f8a54515d7301a50b4d9e3e4'
# Execute the existing native inspect_source API directly to avoid the host argv byte limit
# for the complete 5,969-file payload. This is the exact function used by the native inspect CLI.
spec=importlib.util.spec_from_file_location('pathway_native_review',W/'scripts/record_review.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
result=module.inspect_source(W,old['targets'],[x['path'] for x in old['source']['inputs'] if x['role']!='target']+extra)
(O/'adopted-source-inspect.json').write_text(json.dumps(result,indent=2)+'\n')
observed={x['path']:x['sha256'] for x in result['source']['inputs']}
for x in json.loads(manifest.read_bytes())['files']:
 p=str((payload/x['path']).relative_to(W));assert observed[p]==x['sha256'],p
(O/'adopted-source-inspect-receipt.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_entrypoint='scripts/record_review.py inspect_source(worktree, targets, extra_inputs); same implementation as inspect CLI',reason='Complete payload input list exceeds a practical host argv budget; no alternate inspector or validator was invented.',previous_inputs=checks,new_inputs=extra,total_inputs=len(observed),payload_files=5969,all_payload_manifest_rows_match=True,scope='Actual maintained accepted source payload, report, new history and retention integration receipts captured before final assessment. Final documentation gates remain running; no completion assumed.'),indent=2)+'\n')
print(json.dumps(dict(status='inspection_only',inputs=len(observed),prior_unchanged=len(checks),payload_files=5969)))
