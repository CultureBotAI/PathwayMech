# Maintained scientific review: final supplement

This supplement began at actual UTC **2026-10-15T20:45:52Z**. The reviewer is
`/root/next267_regulatory_acceptance`, independent of the scientific author,
authority/source implementation authors and root integration. It has made no
maintained, Git, GitHub or runtime changes. Root owns canonical persistence.

The target is the complete maintained
`data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml`, SHA256
`40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51`.
The complete 2,053-line actual record was read in this reviewer's earlier
maintained preparation, whose assessment ran 20:11:06Z–20:26:56Z. That preparation,
manifest `27ae77bb79d4d48ae332f9cc0244aac21726521ea67ef85371833fe3a36d8801`,
remains immutable and **partial** at its original cutoff. Current work reuses
that explicit reading and the reviewer's earlier primary interpretations at
their documented depths; it does not fabricate a new whole-paper reading.

The present supplement independently inspects each subsequent maintained input
cutoff, rechecks every prior hash, reassesses each changed input, recovers the
actual retained scientific originals, and completes the missing provenance and
terminal-gate assessment. The final governed content preserves all 100 individual
edge assessments from the complete maintained preparation. Deterministic replay
is supporting evidence for continuity, not a substitute for the scientific
interpretations below.

## Complete scientific coverage

The 80 identities comprise the pathway, 62 participants, ten reaction identities
and seven taxa. All 100 edges and 196 evidence items (177 edge and 19 endpoint
qualifier items) are accounted for, with 64 reference bodies, 15 design
obligations and 28 corrected primary claims. The nine native reactions retain
all 42 material occurrences, 23 frames and eight consecutive material joins.
The ortho anthranilate acetylation reaction remains auxiliary rather than a
tenth native step. The adjacent seven-step route, upstream benzoate activation
and downstream glutaryl-CoA degradation are not conflated with this record.

The upper enzyme evidence retains its actual preparation and predicate scope.
R. palustris BadDEFG genetic support is distinct from purified Thauera BCR
catalysis. Native Syntrophus sequence, downstream-start recombinant construct,
artificial-reductant reverse assay, unproven physiological ETF coupling and
conflicting FAD occupancy values remain separate. BadK crude extract does not
establish a purified monomer. BadH tag/assembly evidence and its negative C7
substrate result do not fill the lower-route catalyst gap. BadI apparent
homogeneity, approximately 90% purity after shorter purification, and the
approximately 5% intended-substrate mixture are different measured quantities.

The lower native chemistry is complete without claiming isolated lower C7
enzyme activities. PimCD, PimF and PimB retain predicted `enables` roles,
whole-operon phenotype/RNA limits and the possibility of alternative activity.
The eighth putative reaction remains without an assigned catalyst; the pimE
pseudogene is not made into an active protein. Formal NAD chemistry and a
flavin-based sequence prediction remain an unresolved source distinction.

All 16 monomer identities, seven assemblies, 14 component associations and four
cofactor pointers retain their proper roles. Native material redox-state units,
whole donor proteins and intrinsic BCR clusters are not equated. The e083
spectroscopy assertion is supported only by the complete retained PMID10903310
metadata/abstract. The inaccessible full spectroscopy text is not claimed to
have been read, and the corrected assertion does not import a three-paper
chronology from another source.

BadM/BadR direct binding and repression are distinguished from AadR-dependent
expression and BadL/BadM genetics. Footprints, tag-placement conflicts, reported
construct lengths and native lengths remain explicit. Later controlled BadR
repression evidence is not silently reconciled with the older activation
interpretation. Neither native BadL–BadM direct binding nor BadM acetylation is
invented. AadR family analogy does not establish a fixed experimentally measured
FeS occupancy.

The three neutral acid assay reagents are exact ortho, meta and para isomers,
not formal Rhea anions or depicted zwitterions. Nominal 10 mM ligand EMSA,
72 nM BadM, 12 nM 212-bp probe, the negative 5 mM ortho result and meta/para
solubility limitations remain bounded. These data do not identify a physiological
ligand, establish affinity rank or yield a dissociation constant.

Auxiliary Rhea28551 has a balanced four-material equation and separate MmBadL
and GmBadL homolog preparations. Their native taxa/lengths and reported JE9314
expression context remain distinct. Both homologs have TLC-supported products;
only the reported MmBadL meta product has direct HPLC/MS comparison. Below-
background kinetic readout does not establish catalytic preference or constants.
Exact meta/para activity identifiers remain open, and no native RpBadL catalysis
is inferred. Seven declared taxa are source/assay contexts, not a statement that
each organism performs the entire pathway.

## Actual retained sources and scientific continuity

Every one of the 64 reference bodies was independently decoded from the actual
maintained content/source maps, including three exact nested prior-266 archive
members. A further 122 identity-original bindings cover all 62 participants.
The independent scientific recovery parsed all 35 owner maps and all 13,577
physical source occurrences, then decoded 152 distinct selected original bodies,
including 120 pinned-Git originals. It passed 15,739 assertions while confirming
all 80 current authority terms and every complete edge object/qualifier. The
exact durable locators are in `all-64-durable-reference-bindings.json` and
`all-62-durable-identity-original-bindings.json`.

This was selected scientific recovery, not another full materialization of all
13,577 source files. The independent technical successor review separately
performed full reconstruction and 78 negative cases. This reviewer verified its
79-member retained control archive, read its complete handoff/assessment and
retained findings, and passed 242 transport assertions. Issues #604–605 have
bounded accepted corrections; their original failed reviews remain immutable.

The actual maintained decoder's prior terminal receipt reports complete offline
verification of 13,577 physical occurrences, 6,175 current compact declarations
and 477 historical declarations over 926 historical reference paths. Its
`fresh_materialization` is null and `originals_compared` is false. This is not
described as a second fresh reconstruction. Independent intake of all 40 root
integration members and exact reader semantics passed 97 assertions.

All four original verification transports were independently replayed: 199
exact members, 687 assertions, including all 80 immutable scientific preparation
files. Roles remain explicit: source author, independent reviewer and root
integration cutoff are different provenance owners. No original partial verdict
was rewritten into a retrospective completed verdict.

The four full ontology database originals—GO 2026-07-26, ChEBI 255, NCBI
Taxonomy 2026-07-12 and Rhea 139—remain external whole-ontology-rebuild
prerequisites. Their boundaries are explicit. The separately used complete
Rhea 142 raw gzip is retained and recovered. Complete selected scientific source
recovery does not imply that all four external databases were bundled.

The complete actual maintained report was read and compared with the previously
accepted draft. Its scientific narrative, formal net, exact corrected titles,
abstract-only limit, construct distinctions and finite source limits agree with
the record. Subsequent changes document actual retention/gates and explicitly
distinguish 73 base graph nodes, 19 qualified endpoint occurrences and seven
taxa shown as table context.

## Structured source and visual scope

The required iModulonDB route used the existing CLAW runner without installation.
The successful complete returned catalog contained 28 datasets across 20
organisms; none covered the selected native taxa or the older Magnetospirillum
name. Organism search and module summarization were therefore not applicable.
Expression-host coverage was not substituted for native pathway evidence.
Initial dependency/DNS failures and the successful normalized output remain in
the immutable preparation. Catalog absence is not biological negative evidence.

The maintained native page retains all 511 assessed display fields, 64
bibliography entries and 100 relationships. The reviewer previously viewed all
three exact root-captured desktop/mobile screenshots; runtime interaction checks
are root-owned. This is a bounded visual smoke check, not an accessibility or
cross-browser audit. Actual KGX fidelity preserves 100 new edges, 80 local
contexts and 13,689 prior edge rows. These unchanged page/export inputs remain
bound to the original observations.

## Gate and correction lineage

The complete initial native gates terminated zero: validation, 5,965 passed
tests with three skipped and seven warnings, lint and diff check. The declared
29,580-input window remained unchanged. Later source/report additions have a
separate documentation gate cutoff rather than being folded into the earlier
test run.

The first documentation attempt passed validation and failed lint with one E501
at retained decoder line 20. Diff and final preservation were not reached. Issue
#606 and the full failed attempt remain in the maintained correction package.
The explicit successor splits one string literal across a parenthesized pair of
adjacent literals. Independent whole-module AST comparison is exact; all 5,967
other payload files remain identical. Independent successor assessment passed
12,051 assertions. The report clearly distinguishes prior decoder execution
from current AST-equivalent reuse; no fresh execution is invented.

The reviewer's first line-shape probe expected two added lines instead of the
actual four-line expression. Its failed script/stderr are preserved. The exact
diff was inspected, the check corrected and the full bounded assessment rerun
successfully. This reviewer diagnostic does not indicate a decoder defect.

The final successor documentation transport is now independently accepted:
all twelve exact archive members, terminal validate/lint/diff logs and full
35,596-input preservation window were checked. All 29,580 earlier full-tested
inputs remain exact. The final native inspection binds 6,052 review inputs;
6,047 match the documentation gate inventory. `CLAUDE.md` is outside that gate's
declared scope and its four transport files were created afterward. These
boundaries are explicit. Independent final cutoff assessment passed 12,142
assertions. No canonical bundle has been saved by this reviewer; root owns that
subsequent persistence and native review-contract check.

## Limitations and disposition

No new actionable scientific finding was identified in this supplement. The
original four full-design findings (#600–603) remain preserved with their
needs-curation verdict and explicit accepted correction successor. External
review lineage is not fabricated as canonical `previous_occurrences`; this
review does not close issues or promote scientific status.

Unavailable full texts/supplements, missing exact construct details, physiological
electron coupling, isolated lower C7 activities, the eighth catalyst,
physiological BadM ligand and exact meta/para activity identifiers remain stated
scientific limits. The finite source and archive searches do not establish
global literature exhaustion. Other 263 records have preservation checks,
not new scientific reviews. Public-release licensing remains the separate later
decision requested by the user.
