import datetime, hashlib, json, tarfile
from pathlib import Path, PurePosixPath
import yaml
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
C=Path('/private/tmp/pathwaymech-next-267-ci')
P=Path('/private/tmp/pathwaymech-next-267-maintained-scientific-review-preparation')
base=W/'research/pathway_additions/2026-10-15-next-267/verification'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
checks=[]
def check(n,ok):
    checks.append(dict(check=n,passed=bool(ok)))
    assert ok,n
adopt=read(C/'verification-preparations-adoption.json')['packages']
adopt['technical-preparation']=read(C/'technical-preparation-adoption.json')['files']
packages={};durable=[];bodies={}
for name,expected in adopt.items():
    root=base/name
    for filename,spec in expected.items():
        b=(root/filename).read_bytes();check('Adopted package file '+name+'/'+filename,len(b)==spec['bytes'] and sha(b)==spec['sha256'])
    manifest=read(root/'artifact-manifest.json')
    for row in manifest['files']:
        b=(root/row['path']).read_bytes();check('Internal package manifest '+name+'/'+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'])
    source=read(root/'source-file-manifest.json');archive=root/'files.tar.gz';raw=archive.read_bytes()
    check('Source manifest archive binding '+name,len(raw)==source['archive_bytes'] and sha(raw)==source['archive_sha256'])
    spec={x['member']:x for x in source['files']}
    check('Source member names unique '+name,len(spec)==len(source['files']))
    with tarfile.open(archive) as tf:
        members=tf.getmembers();check('Archive exact declared member set '+name,len(members)==len(spec) and {m.name for m in members}==set(spec))
        body={}
        for m in members:
            path=PurePosixPath(m.name)
            check('Canonical regular member '+name+'/'+m.name,m.isfile() and not path.is_absolute() and '..' not in path.parts and str(path)==m.name)
            b=tf.extractfile(m).read();r=spec[m.name]
            check('Complete member hash '+name+'/'+m.name,len(b)==r['bytes'] and sha(b)==r['sha256'])
            body[m.name]=b
            durable.append(dict(source_path=r['source'],retained_archive=str(archive.relative_to(W)),member=m.name,bytes=len(b),sha256=sha(b)))
    packages[name]=dict(archive=str(archive.relative_to(W)),archive_sha256=sha(raw),members=len(body),source_manifest_sha256=sha((root/'source-file-manifest.json').read_bytes()))
    bodies[name]=body
# All eighty original preparation files, including original failed probes and partial verdict, survive.
pm=read(P/'artifact-manifest.json');check('Prior partial manifest unchanged',sha((P/'artifact-manifest.json').read_bytes())=='27ae77bb79d4d48ae332f9cc0244aac21726521ea67ef85371833fe3a36d8801')
prior_names={r['path'] for r in pm['files']}|{'artifact-manifest.json','freeze.json'}
for n in sorted(prior_names):check('Exact archived partial-preparation file '+n,bodies['scientific-preparation'][n]==(P/n).read_bytes())
partial=yaml.safe_load(bodies['scientific-preparation']['governed-review-draft.yaml'])
check('Original partial scientific verdict preserved',partial['completion']=='partial' and len(partial['assessments'])==117 and len(partial['evidence'])==80 and partial['findings']==[])
check('Complete original edge ledger preserved',len(json.loads(bodies['scientific-preparation']['all-100-maintained-edge-assessments.json']))==100)
techmanifest=bodies['technical-preparation']['artifact-manifest.json']
check('Independent technical manifest binding',sha(techmanifest)=='0cf8305599206eb39304aa6492d40f601002ff5b647b20c51dc6a45a1d54ae9d')
for row in json.loads(techmanifest)['files']:
    b=bodies['technical-preparation'][row['path']];check('Archived technical manifested body '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'])
check('Independent technical handoff binding',sha(bodies['technical-preparation']['HANDOFF.md'])=='6dda3d51e90a384b183121e175b7c71be35c7d6cc1aa5dcc5415bd047f1db4a9')
(O/'retained-technical-HANDOFF.txt').write_bytes(bodies['technical-preparation']['HANDOFF.md'])
# Parse complete native terminal receipts and logs without rerunning the suite.
g=bodies['initial-gates'];receipts=json.loads(g['native-gates/receipts.json']);inventory=json.loads(g['native-gates/tested-core-input-hashes.json']);preservation=json.loads(g['native-gates/final-input-preservation.json'])
check('Exactly four required terminal native commands',[r['command'] for r in receipts]==[['just','validate'],['just','test'],['just','lint'],['git','diff','--check']])
for r in receipts:
    log='native-gates/'+Path(r['log_path']).name
    check('Terminal native receipt and log '+str(r['command']),r['exit_code']==0 and sha(g[log])==r['log_sha256'] and r['cwd']==str(W))
check('Native total and preservation scope',len(inventory)==29580 and preservation['tested_core_files']==29580 and preservation['all_unchanged'] and preservation['ignored_and_hidden_included'])
check('Exact maintained target tested',inventory['data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml']=='40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51')
check('Complete test outcome','5965 passed, 3 skipped, 7 warnings' in g['native-gates/just-test.log'].decode())
native=[]
for x in read(O/'verification-inspect.json')['source']['inputs']:
    check('Current native inspection remains exact '+x['path'],sha((W/x['path']).read_bytes())==x['sha256'])
    if x['path'] in inventory:check('Reviewed input matches gate cutoff '+x['path'],inventory[x['path']]==x['sha256'])
    native.append(dict(path=x['path'],included_in_initial_native_gate_inventory=x['path'] in inventory,sha256=x['sha256']))
root=bodies['root-integration'];kgx=json.loads(root['kgx-record-fidelity.json'])
check('All root exported relationships and contexts preserved',len(kgx['record_edges_checked'])==100 and all(x['complete_claim_equal'] for x in kgx['record_edges_checked']) and len(kgx['named_contexts_checked'])==80 and all(x['complete_context_equal'] for x in kgx['named_contexts_checked']))
for r in kgx['outputs']:
    p=W/'pages/downloads'/Path(r['path']).name
    # Actual maintained download names are discovered from root export helper if they differ.
    if not p.is_file():
        candidates=[x for x in (W/'pages/downloads').iterdir() if x.is_file() and x.stat().st_size==r['bytes']]
        matches=[x for x in candidates if sha(x.read_bytes())==r['sha256']]
        check('Exact maintained download hash for '+r['path'],len(matches)==1)
    else:check('Exact maintained download '+str(p),sha(p.read_bytes())==r['sha256'])
check('All original export edge rows preserved',kgx['all_prior_edge_rows_exact']==13689 and kgx['actual_cli_exports_equal_generated_downloads'])
out=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='pass',packages=packages,checks=checks,check_count=len(checks),total_members=sum(x['members'] for x in packages.values()),native_receipts=receipts,reviewed_input_gate_scope=native,scope='Independent raw transport/member replay and complete receipt/log intake. This is not a new whole-suite execution or a full technical implementation review. The earlier scientific primary readings, partial verdict, failed probes and explicit source limits remain unchanged. Final corrected source retention/report/native history/final documentation gates are still pending.')
(O/'verification-transport-replay.json').write_text(json.dumps(out,indent=2)+'\n')
(O/'durable-verification-member-map.json').write_text(json.dumps(durable,indent=2)+'\n')
(O/'terminal-native-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
(O/'terminal-native-test.log').write_bytes(g['native-gates/just-test.log'])
print(json.dumps(dict(status='pass',checks=len(checks),archive_members=out['total_members'],packages={k:v['members'] for k,v in packages.items()})))
