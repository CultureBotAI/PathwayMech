import datetime, hashlib, importlib.util, json, os, sys
from pathlib import Path
O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
B='research/pathway_additions/2026-10-15-next-267/'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((O/'adopted-source-inspect.json').read_bytes())
allowed={B+'evidence-retention/artifact-manifest.json',B+'evidence-retention/decode_retained.py',B+'README.md'}
changed=[];unchanged=[]
for x in old['source']['inputs']:
    h=sha(W/x['path'])
    if h!=x['sha256']:
        assert x['path'] in allowed,x['path'];changed.append(dict(path=x['path'],before=x['sha256'],after=h))
    else:unchanged.append(x)
assert {x['path'] for x in changed}==allowed
proof=W/B/'verification/decoder-lint-correction'
extra=sorted(str((Path(d)/f).relative_to(W)) for d,ds,fs in os.walk(proof) for f in fs)
extra.append('history/other/benzoyl-coa-degradation-iii-research/2026-10-15T210509Z-Codex-bf356c.yaml')
assert sha(proof/'artifact-manifest.json')=='c06a66f6cbe91d1f8f3c4680ea6aa145b6ef1f3edafea1a2c5e6bd52530b5670'
assert sha(W/B/'evidence-retention/artifact-manifest.json')=='e99337264ef70fd72555b4e10928584909e5830c00e41d5566c6b7c5b90f5a4a'
spec=importlib.util.spec_from_file_location('native_review_successor',W/'scripts/record_review.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
result=module.inspect_source(W,old['targets'],[x['path'] for x in old['source']['inputs'] if x['role']!='target']+extra)
(O/'formatting-successor-inspect.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'formatting-successor-inspect-receipt.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_entrypoint='scripts/record_review.py inspect_source; same native inspect implementation',input_count=len(result['source']['inputs']),prior_unchanged=len(unchanged),changed_inputs=changed,new_inputs=extra,scope='Actual formatting successor captured before independent reassessment; final successor gates pending.'),indent=2)+'\n')
print(json.dumps(dict(inputs=len(result['source']['inputs']),unchanged=len(unchanged),changed=len(changed),new=len(extra))))
