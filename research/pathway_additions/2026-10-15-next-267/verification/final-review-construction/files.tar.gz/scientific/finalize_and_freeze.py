"""Freeze completed external review after all child processes have terminated."""
import datetime,hashlib,json,os
from pathlib import Path
import yaml

O=Path('/private/tmp/pathwaymech-next-267-final-scientific-review')
W=Path('/private/tmp/pathwaymech-next-267-20261015')
def load(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (O/'artifact-manifest.json').exists()
assert not (O/'freeze.json').exists()
r=yaml.safe_load((O/'governed-final-review.yaml').read_bytes())
pres=load(O/'final-input-preservation.json')
assert pres['status']=='pass' and pres['review_yaml_sha256']==sha(O/'governed-final-review.yaml')
assert pres['review_markdown_sha256']==sha(O/'governed-final-review.md')
assert load(O/'final-native-review-validation.stdout.txt')=={'valid_reviews':1}
assert r['completion']=='completed' and r['verdict']=='pass_with_limitations'
assert len(r['assessments'])==119 and len(r['evidence'])==91 and len(r['checks'])==14
for item in r['source']['inputs']:assert sha(W/item['path'])==item['sha256'],item['path']
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
findings=dict(status='completed',verdict='pass_with_limitations',scientific_review=True,new_findings=[],proposed_actions=[],scope='One complete actual maintained MetaCyc:P321-PWY record; 80 IDs, 100 edges, 196 evidence items and 64 references. No global source-completeness, other-record scientific review, technical reimplementation review or public-release approval.',preserved_external_lineage=[dict(issues=[600,601,602,603],original='Complete independent design review retains needs-curation verdict.',disposition='Explicit independent bounded correction successor accepted; actual record identical.'),dict(issues=[604,605],original='Independent technical retention review retains original failed cutoff.',disposition='Explicit retention successor independently accepted; transport verified here.'),dict(issues=[606],original='Final source-documentation validation passed, lint E501 failed; later gates not reached.',disposition='Formatting-only successor independently accepted, complete AST identical; terminal successor documentation gates passed.')],unavailable_evidence='Previously unavailable full papers/supplements and exact construct details remain unavailable. PMID10903310 is abstract-only. Native physiological/catalyst/ligand/activity-ID gaps remain represented, not newly resolved.',canonical_saved_by_this_reviewer=False)
(O/'findings.json').write_text(json.dumps(findings,indent=2)+'\n')
handoff=f'''# Completed independent maintained scientific review

**Completed / pass with limitations; zero new findings and zero proposed actions.**
This is the full scientific assessment of one actual maintained MetaCyc:P321-PWY
record, not public-release/licensing approval or a fresh review of other records.
Root remains the sole canonical saver.

## Final governed content

- Input content: `governed-final-review.yaml`
- Native rendered companion: `governed-final-review.md`
- Review ID: `{r['review_id']}`
- Intended canonical bundle:
  `reviews/structured/{r['review_id']}/review.yaml` and `review.md`
- Actual start: `{r['started_at']}`; assessment finish: `{r['finished_at']}`.
- YAML SHA256: `{sha(O/'governed-final-review.yaml')}`
- Native Markdown SHA256: `{sha(O/'governed-final-review.md')}`
- 119 assessments, including all 100 complete unchanged edge assessments;
  91 evidence entries; 14 checks; 6,052 exact native-inspected inputs.
- Native `scripts/record_review.py validate` and `render` both terminated zero.
  The existing dependency emits a `topClass` deprecation warning; no review error.
  No canonical save/check was performed by this reviewer.

The current record SHA256 is
`40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51`.
Git base is `02bc234143d40e0e825737f27dfdcb5fd358322f`, tree
`08c04c1808980164ab90512f83e6e1c9bb5f16af`; the review declares working-tree
inputs rather than claiming these bytes are committed.

## Scientific result and reading ownership

The complete 2,053-line maintained record was read in this reviewer's earlier
20:11:06Z–20:26:56Z scientific preparation. That original 80-file partial
preparation remains immutable (manifest
`27ae77bb79d4d48ae332f9cc0244aac21726521ea67ef85371833fe3a36d8801`).
This separately timed supplement explicitly reuses its whole-record assessment
and this reviewer's earlier original readings at their recorded depths, then
independently assesses actual source/report/history adoption, changed inputs,
durable evidence and terminal gate cutoffs. No new whole-paper reading is
fabricated and deterministic transport assertions are not primary science.

All 80 identities, 100 edges, 196 evidence items, 64 references, nine native
steps, 42 material occurrences, 23 frames, eight joins, 15 obligations and
28 primary claims are accounted for. Preparations/constructs, taxa, predicates,
directions and conflicts retain their exact scope. The eighth catalyst remains
unassigned; predicted lower Pim activities are not isolated enzyme measurements;
no active PimE, native RpBadL catalysis or tenth native step is inferred.
The three BadM ligand observations and auxiliary homolog chemistry retain their
assay, isomer/microstate, solubility, taxon and measurement limitations.

`SCIENTIFIC-ASSESSMENT.md` explains the assessment and limitations in connected
prose; the governed content includes all 100 edge-level assessments. Earlier
source-reading scope and the complete original partial review are retained in
actual maintained archives. Four original full-design issues #600–603 and
their accepted bounded successor remain explicit; technical #604–605 and the
formatting #606 correction do not rewrite their predecessors or close issues.

## Actual retained evidence

- All 64 original reference bodies, including three nested archive members,
  have exact maintained source-map/content-map locators.
- 122 identity-original bindings cover all 62 participants; 152 distinct
  scientific originals were independently decoded, including 120 pinned-Git
  originals. All 80 authorities and every complete edge/qualifier object match.
  The selected scientific recovery passed 15,739 assertions.
- All 35 owner maps/13,577 physical source occurrences were parsed. This reviewer
  did not rerun full 13,577-file reconstruction or 78 decoder-negative cases;
  the separately accepted technical review owns those observations.
- Four original verification transports: 199 members / 687 assertions.
  Decoder-review transport: 79 members / 242 assertions.
  Actual retention integration: 40 members / 97 assertions.
- Actual maintained decoder receipt is complete offline verification, with
  `fresh_materialization: null`; it is not a second fresh materialization.
- Current payload manifest:
  `e99337264ef70fd72555b4e10928584909e5830c00e41d5566c6b7c5b90f5a4a`.
  Formatting successor preserves full module AST and all 5,967 other payload
  files; independent acceptance passed 12,051 assertions.
- Four full ontology database originals remain explicitly external: GO
  2026-07-26, ChEBI255, NCBITaxon2026-07-12 and Rhea139. Complete Rhea142
  scientific source gzip is separately retained. No whole-ontology bundle claim.

## Terminal gates and preservation

The complete initial native validate/test/lint/diff run passed, with 5,965 tests
passed, three skipped and seven warnings. The 29,580-input initial window was
unchanged. The later source-documentation successor ran validate/lint/diff to
terminal zero with all 35,596 declared inputs unchanged, including every
earlier full-tested input. Full tests were not repeated for documentary changes.

The final twelve-member gate transport was independently verified (12,142
assertions). Of 6,052 review inputs, 6,047 match that gate inventory; CLAUDE.md
is outside the declared gate scope and the four gate transport files were
created afterward. These cutoffs are explicit, not retroactively expanded.
The original E501 failure, failed UPDATE history invocation and corrected native
EDIT are preserved. Prior decoder execution is reused through exact AST identity.

Final preservation passed {pres['assertions']:,} assertions: all 6,052 actual
inputs unchanged, original 80-file partial preparation unchanged, and all
60 full-design-review plus 39 correction-review files exact against retained
source maps. All absence/closure inventories include hidden and ignored files
within their explicitly bounded scope.

## Limits, diagnostics and handoff

PMID10903310 is complete metadata/abstract only; unavailable full texts,
supplements and construct details remain unavailable. Physiological coupling,
isolated lower C7 activities, the eighth catalyst, physiological BadM ligand
and exact meta/para activity IDs remain scientific gaps already represented.
The structured iModulonDB catalog route succeeded; no selected native taxon was
covered, so follow-up search/summarization was not applicable. Catalog absence
is not biological negative evidence. The actual page visual observation is a
bounded smoke check of the same three root captures, not a new cross-browser
or accessibility audit.

`supplement-diagnostics.json` preserves exact failed probes and corrected
executions. A first line-count assertion expected two instead of four added
formatting lines; its script/stderr and corrected 12,051-check replay remain.
The `before-historical-cutoff-clarity.*` files preserve the initially valid final
draft/validation/render/preservation before one evidence summary was clarified
as describing its historical partial cutoff. No scientific assertion changed.

All tools used the existing verified runtime with no installation or runtime
repair. This reviewer made no maintained, Git or GitHub writes and spawned no
children. Canonical persistence and final publication checks are root's next
actions. Read `freeze.json` for the exact manifest hash and complete package
counts; manifest excludes only itself and that freeze receipt.
'''
(O/'HANDOFF.md').write_text(handoff)
rows=[]
for d,ds,fs in os.walk(O):
    for f in fs:
        p=Path(d)/f;relative=str(p.relative_to(O))
        assert not p.is_symlink(),relative
        if relative in {'artifact-manifest.json','freeze.json'}:continue
        rows.append(dict(path=relative,bytes=p.stat().st_size,sha256=sha(p)))
rows.sort(key=lambda x:x['path'])
manifest=dict(schema_version='1.0.0',scope='Complete immutable final scientific-review supplement, including all hidden/ignored files, failed probes, previous valid internal draft, exact source bindings and native outputs. Excludes only this manifest and freeze.json.',files=rows)
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze=dict(utc=now,status='completed_pass_with_limitations',review_id=r['review_id'],manifest_sha256=sha(O/'artifact-manifest.json'),manifested_files=len(rows),physical_files=len(rows)+2,handoff_sha256=sha(O/'HANDOFF.md'),review_yaml_sha256=sha(O/'governed-final-review.yaml'),review_markdown_sha256=sha(O/'governed-final-review.md'),input_count=6052,all_inputs_unchanged=True,new_findings=0,canonical_saved=False,scope='One complete maintained scientific record; no publication/licensing approval. Root owns canonical save. All process outputs were terminal before this freeze.')
(O/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({**freeze,'freeze_sha256':sha(O/'freeze.json')}))
