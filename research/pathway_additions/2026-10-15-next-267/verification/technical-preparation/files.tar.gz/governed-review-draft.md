# P321 maintained technical integration: provisional authority, representation and export assessment

- Review: 20261015T204258Z-p321-maintained-technical-preparation
- Repository: CultureBotAI/PathwayMech
- Started UTC: 2026-10-15T20:36:10.892197Z
- Finished UTC: 2026-10-15T20:42:58.010511Z
- Reviewer: Codex independent maintained technical reviewer (independent)
- Completion: partial
- Verdict: pass_with_limitations
- Scientific review: false

## Summary

No new technical finding in the 57 assessed maintained/generated targets. Actual implementation, complete prior authority/record preservation, native histories, complete KGX claims and graph evidence pass the bounded checks. Full terminal test/lint receipt intake, corrected retained-evidence adoption and actual research-report binding remain required before completed technical review.

## Scope And Provenance

Exact maintained P321 implementation, authority, corrected record, two native histories and seven generated outputs.

Selection: All 43 accepted implementation outputs, four authority files, the corrected pathway YAML, both new histories and seven changed generated artifacts.
Coverage: full; 57 reviewed / 57 in the declared population.
Source: working_tree at Git base 02bc234143d40e0e825737f27dfdcb5fd358322f.
Working-tree hashes do not imply those bytes were committed.

| Target | Path / selector | Kind | Label |
| --- | --- | --- | --- |
| docs/IDENTIFIERS.md | docs/IDENTIFIERS.md | maintained | docs/IDENTIFIERS.md |
| scripts/build_source_identifier_snapshot.py | scripts/build_source_identifier_snapshot.py | maintained | scripts/build_source_identifier_snapshot.py |
| src/pathwaymech/biocyc_p321.py | src/pathwaymech/biocyc_p321.py | maintained | src/pathwaymech/biocyc_p321.py |
| src/pathwaymech/biocyc_pathway.py | src/pathwaymech/biocyc_pathway.py | maintained | src/pathwaymech/biocyc_pathway.py |
| src/pathwaymech/identifiers.py | src/pathwaymech/identifiers.py | maintained | src/pathwaymech/identifiers.py |
| tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz | tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz | maintained | tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz |
| tests/fixtures/p321_authority/META-CPLX-8778.xml.gz | tests/fixtures/p321_authority/META-CPLX-8778.xml.gz | maintained | tests/fixtures/p321_authority/META-CPLX-8778.xml.gz |
| tests/fixtures/p321_authority/META-CPLX-884.xml.gz | tests/fixtures/p321_authority/META-CPLX-884.xml.gz | maintained | tests/fixtures/p321_authority/META-CPLX-884.xml.gz |
| tests/fixtures/p321_authority/META-CPLX-885.xml.gz | tests/fixtures/p321_authority/META-CPLX-885.xml.gz | maintained | tests/fixtures/p321_authority/META-CPLX-885.xml.gz |
| tests/fixtures/p321_authority/META-CPLX-926.xml.gz | tests/fixtures/p321_authority/META-CPLX-926.xml.gz | maintained | tests/fixtures/p321_authority/META-CPLX-926.xml.gz |
| tests/fixtures/p321_authority/META-CPLX-9349.xml.gz | tests/fixtures/p321_authority/META-CPLX-9349.xml.gz | maintained | tests/fixtures/p321_authority/META-CPLX-9349.xml.gz |
| tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz | tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz | maintained | tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz |
| tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz | tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz | maintained | tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz |
| tests/fixtures/p321_authority/META-G-545.xml.gz | tests/fixtures/p321_authority/META-G-545.xml.gz | maintained | tests/fixtures/p321_authority/META-G-545.xml.gz |
| tests/fixtures/p321_authority/META-G-550.xml.gz | tests/fixtures/p321_authority/META-G-550.xml.gz | maintained | tests/fixtures/p321_authority/META-G-550.xml.gz |
| tests/fixtures/p321_authority/META-MONOMER-888.xml.gz | tests/fixtures/p321_authority/META-MONOMER-888.xml.gz | maintained | tests/fixtures/p321_authority/META-MONOMER-888.xml.gz |
| tests/fixtures/p321_authority/META-MONOMER-893.xml.gz | tests/fixtures/p321_authority/META-MONOMER-893.xml.gz | maintained | tests/fixtures/p321_authority/META-MONOMER-893.xml.gz |
| tests/fixtures/p321_authority/META-P321-PWY.xml.gz | tests/fixtures/p321_authority/META-P321-PWY.xml.gz | maintained | tests/fixtures/p321_authority/META-P321-PWY.xml.gz |
| tests/fixtures/p321_authority/META-R265-RXN.xml.gz | tests/fixtures/p321_authority/META-R265-RXN.xml.gz | maintained | tests/fixtures/p321_authority/META-R265-RXN.xml.gz |
| tests/fixtures/p321_authority/META-R266-RXN.xml.gz | tests/fixtures/p321_authority/META-R266-RXN.xml.gz | maintained | tests/fixtures/p321_authority/META-R266-RXN.xml.gz |
| tests/fixtures/p321_authority/META-R267-RXN.xml.gz | tests/fixtures/p321_authority/META-R267-RXN.xml.gz | maintained | tests/fixtures/p321_authority/META-R267-RXN.xml.gz |
| tests/fixtures/p321_authority/META-R268-RXN.xml.gz | tests/fixtures/p321_authority/META-R268-RXN.xml.gz | maintained | tests/fixtures/p321_authority/META-R268-RXN.xml.gz |
| tests/fixtures/p321_authority/META-RXN-8031.xml.gz | tests/fixtures/p321_authority/META-RXN-8031.xml.gz | maintained | tests/fixtures/p321_authority/META-RXN-8031.xml.gz |
| tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz | tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz | maintained | tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz |
| tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz | tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz | maintained | tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz |
| tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz | tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz | maintained | tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz |
| tests/fixtures/p321_authority/README.md | tests/fixtures/p321_authority/README.md | maintained | tests/fixtures/p321_authority/README.md |
| tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz | tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz | maintained | tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz |
| tests/fixtures/p321_authority/UniProt-O07453.json.gz | tests/fixtures/p321_authority/UniProt-O07453.json.gz | maintained | tests/fixtures/p321_authority/UniProt-O07453.json.gz |
| tests/fixtures/p321_authority/UniProt-O07456.json.gz | tests/fixtures/p321_authority/UniProt-O07456.json.gz | maintained | tests/fixtures/p321_authority/UniProt-O07456.json.gz |
| tests/fixtures/p321_authority/UniProt-O07457.json.gz | tests/fixtures/p321_authority/UniProt-O07457.json.gz | maintained | tests/fixtures/p321_authority/UniProt-O07457.json.gz |
| tests/fixtures/p321_authority/UniProt-O07458.json.gz | tests/fixtures/p321_authority/UniProt-O07458.json.gz | maintained | tests/fixtures/p321_authority/UniProt-O07458.json.gz |
| tests/fixtures/p321_authority/UniProt-O07465.json.gz | tests/fixtures/p321_authority/UniProt-O07465.json.gz | maintained | tests/fixtures/p321_authority/UniProt-O07465.json.gz |
| tests/fixtures/p321_authority/UniProt-Q01980.json.gz | tests/fixtures/p321_authority/UniProt-Q01980.json.gz | maintained | tests/fixtures/p321_authority/UniProt-Q01980.json.gz |
| tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz | tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz | maintained | tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz |
| tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz | tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz | maintained | tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz |
| tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz | tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz | maintained | tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz |
| tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz | tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz | maintained | tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz |
| tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz | tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz | maintained | tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz |
| tests/fixtures/p321_authority/expected-terms.json | tests/fixtures/p321_authority/expected-terms.json | maintained | tests/fixtures/p321_authority/expected-terms.json |
| tests/fixtures/p321_authority/manifest.json | tests/fixtures/p321_authority/manifest.json | maintained | tests/fixtures/p321_authority/manifest.json |
| tests/fixtures/p321_authority/storage.json | tests/fixtures/p321_authority/storage.json | maintained | tests/fixtures/p321_authority/storage.json |
| tests/test_p321_authority.py | tests/test_p321_authority.py | maintained | tests/test_p321_authority.py |
| conf/identifier_sources.json | conf/identifier_sources.json | maintained | conf/identifier_sources.json |
| conf/rhea_identifier_updates.json | conf/rhea_identifier_updates.json | maintained | conf/rhea_identifier_updates.json |
| data/identifier_authorities/sources.json | data/identifier_authorities/sources.json | maintained | data/identifier_authorities/sources.json |
| data/identifier_authorities/ontology.json | data/identifier_authorities/ontology.json | maintained | data/identifier_authorities/ontology.json |
| data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml | data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml | maintained | data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml |
| pages/browse.html | pages/browse.html | generated | pages/browse.html |
| pages/downloads/edges.tsv | pages/downloads/edges.tsv | generated | pages/downloads/edges.tsv |
| pages/downloads/manifest.json | pages/downloads/manifest.json | generated | pages/downloads/manifest.json |
| pages/downloads/nodes.tsv | pages/downloads/nodes.tsv | generated | pages/downloads/nodes.tsv |
| pages/index.html | pages/index.html | generated | pages/index.html |
| pages/pathway_index.json | pages/pathway_index.json | generated | pages/pathway_index.json |
| pages/records/MetaCyc_P321-PWY.html | pages/records/MetaCyc_P321-PWY.html | generated | pages/records/MetaCyc_P321-PWY.html |
| history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml | history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml | maintained | history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml |
| history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | maintained | history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml |

## Validation

| Check | Status | Required | Targets | Result |
| --- | --- | --- | --- | --- |
| Governed input capture before assessment | passed | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | Actual native inspect succeeded for 57 exact targets and 80 repository input files. |
| Independent maintained integration assertions | passed | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | 2,230 independent assertions passed after two explicitly preserved reviewer-helper corrections. |
| Native whole-corpus validation | passed | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | Root executed just validate successfully for all 264 records; full log and exact current core inputs independently rebound. This is receipt intake, not a duplicate reviewer run. |
| Pinned governed-file synchronization | passed | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | Root just vendored-check exited zero for all 22 artifacts at a5d562962c75a2ad9efd8160b548df5944315422; actual receipt, log and pin verified. |
| Working-tree tracked whitespace | passed | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | Independent git diff --check passed; final staged-index check remains a publication gate. |
| just test | unavailable | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | Root execution is still running or queued at this cutoff; no completed result is claimed and the full suite was not duplicated. |
| just lint | unavailable | True | docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py, tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py, conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json, data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml, pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html, history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml | Root execution is still running or queued at this cutoff; no completed result is claimed and the full suite was not duplicated. |

## Scientific And Domain Assessments

### Native parser and consumer integration

representation: supported. Targets: docs/IDENTIFIERS.md, scripts/build_source_identifier_snapshot.py, src/pathwaymech/biocyc_p321.py, src/pathwaymech/biocyc_pathway.py, src/pathwaymech/identifiers.py.

Actual implementation bytes equal independently accepted code. Complete original encoding/hashes, closed native profiles, preselection conflicts, unknown assembly coefficient and consumer-only exact legacy companion provenance remain intact.

### Original-byte test fixture and regression provenance

provenance: supported. Targets: tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz, tests/fixtures/p321_authority/META-CPLX-8778.xml.gz, tests/fixtures/p321_authority/META-CPLX-884.xml.gz, tests/fixtures/p321_authority/META-CPLX-885.xml.gz, tests/fixtures/p321_authority/META-CPLX-926.xml.gz, tests/fixtures/p321_authority/META-CPLX-9349.xml.gz, tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz, tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz, tests/fixtures/p321_authority/META-G-545.xml.gz, tests/fixtures/p321_authority/META-G-550.xml.gz, tests/fixtures/p321_authority/META-MONOMER-888.xml.gz, tests/fixtures/p321_authority/META-MONOMER-893.xml.gz, tests/fixtures/p321_authority/META-P321-PWY.xml.gz, tests/fixtures/p321_authority/META-R265-RXN.xml.gz, tests/fixtures/p321_authority/META-R266-RXN.xml.gz, tests/fixtures/p321_authority/META-R267-RXN.xml.gz, tests/fixtures/p321_authority/META-R268-RXN.xml.gz, tests/fixtures/p321_authority/META-RXN-8031.xml.gz, tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz, tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz, tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz, tests/fixtures/p321_authority/README.md, tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz, tests/fixtures/p321_authority/UniProt-O07453.json.gz, tests/fixtures/p321_authority/UniProt-O07456.json.gz, tests/fixtures/p321_authority/UniProt-O07457.json.gz, tests/fixtures/p321_authority/UniProt-O07458.json.gz, tests/fixtures/p321_authority/UniProt-O07465.json.gz, tests/fixtures/p321_authority/UniProt-Q01980.json.gz, tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz, tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz, tests/fixtures/p321_authority/expected-terms.json, tests/fixtures/p321_authority/manifest.json, tests/fixtures/p321_authority/storage.json, tests/test_p321_authority.py.

All accepted tests and 33 complete source fixtures are adopted unchanged; every compressed and decoded digest matches. These are implementation regression evidence, not scientific proof.

### Complete ordered authority preservation

grounding: supported. Targets: conf/identifier_sources.json, conf/rhea_identifier_updates.json, data/identifier_authorities/sources.json, data/identifier_authorities/ontology.json.

The actual ordered 1,354-entry prefix is preserved with 36 additions. All 3,185 prior source terms/1,173 owners and 2,190 ontology terms/five owners are unchanged; only the accepted 36 source and six ontology terms are added.

### Accepted record representation

representation: supported. Targets: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml.

Actual candidate SHA256 40fa37e6... equals the independently accepted successor; 80 declared identities, 100 edges and 64 references serialize without claim loss. Scientific interpretation is outside this technical pass.

### Native append-only session provenance

provenance: supported. Targets: history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml, history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml.

Both new histories were natively scaffolded, match exact receipt hashes and describe the record/authority work with then-pending lifecycle gates explicit.

### Generated pages and complete KGX claims

graph: supported. Targets: pages/browse.html, pages/downloads/edges.tsv, pages/downloads/manifest.json, pages/downloads/nodes.tsv, pages/index.html, pages/pathway_index.json, pages/records/MetaCyc_P321-PWY.html.

All seven actual generated artifacts are bound. Native page consistency validation passed; independent export and DOM checks preserve complete claims, and desktop/mobile screenshots retain usable focused labels and scrolling. Dense overview is explicitly scoped as a browsing aid.

## Findings

No findings recorded within this review's declared scope.

## Recommended Actions And Acceptance Checks

## Category Boundaries


## Evidence

| Evidence | Reference / locator | Support | Observation |
| --- | --- | --- | --- |
| e-adoption | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/implementation-owner-bindings.json | supports | All 43 actual maintained implementation outputs match accepted original plus explicit issue 599 successor. |
| e-preservation | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/all263-prior-record-bindings.json | supports | Every complete actual merged record blob remains byte-identical; recursive scope including hidden/ignored files contains exactly 264 records. |
| e-authority | /private/tmp/pathwaymech-next-267-independent-full-authority-review/artifact-manifest.json | supports | Accepted full native authority replay and complete previous-owner/term preservation; actual four maintained files now match the exact accepted serializations. |
| e-fixtures | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/fixture-original-bindings.json | supports | All 33 deterministic gzip fixture originals match both storage layers and exact accepted source bytes. |
| e-exports | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/independent-export-fidelity.json | supports | Every field of all 100 new edge claims, full reference/evidence/qualifier payloads, all 80 local node contexts, and all 13,689 prior edge rows verified. |
| e-graph | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/graph-static-and-visual-review.json | supports | Every directed graph endpoint, qualifier role, static evidence and table link is preserved. Actual 92 display nodes comprise 73 base nodes and 19 qualified occurrences; seven taxa remain table context. All three bound screenshots viewed. |
| e-histories | /private/tmp/pathwaymech-next-267-ci/native-integration-history.json | supports | Two actual histories match native scaffolder receipts, Codex/ai_agent/codex identity, target paths and immutable pending-gate statements. |
| e-validation | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/observed-validation-input-binding.json | supports | Root just validate passed, and its complete core file snapshot was independently rebound; no full-suite pass is inferred from progress. |
| e-vendor | /private/tmp/pathwaymech-next-267-vendored-check/receipt.json | supports | Actual pinned vendored check passed 22 governed artifacts; receipt/log digest/pin verified. |
| e-audit | /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/technical-audit-result.json | supports | Independent maintained audit passed 2,230 assertions, with all 80 inspected repository input hashes unchanged. |
| e-retention-pending | /private/tmp/pathwaymech-next-267-independent-retention-review/HANDOFF.md | context_only | Original evidence payload is recoverable but its standalone decoder has unresolved findings 604 and 605 at this cutoff. Successor acceptance and actual adoption are separate pending work. |
| e-report-draft | /private/tmp/pathwaymech-next-267-ci/research-report-draft.md | context_only | Read the full external report draft. It keeps authority, science, visual, retention and publication scope distinct and explicitly reports 604/605 and unfinished gates. Actual maintained report is not yet assessed. |

## Limits And Additional Notes

- Partial observation; no completed technical or publication verdict.
- The root full suite/lint status is captured honestly at this cutoff; no progress output is treated as a pass.
- Retention findings 604/605 remain open in their original independent review until explicit successor acceptance; absence of findings here does not resolve them.
- Screenshot assessment is a bounded visual smoke check, not accessibility/cross-browser testing or biological flux validation.
- Initial reviewer attempts incorrectly narrowed node context and inferred qualifier count from net node difference. Both failed helper attempts are preserved; corrected comparisons pass without product changes.
- Root alone will save canonical review records after actual adoption and terminal checks. This external validated draft is not a saved canonical review.
- Hidden/ignored files were included for the recursive maintained-record pathset and root core-input inventory; no global absence claim.
- 92 SVG display nodes = 73 base pathway/participant/reaction nodes + 19 qualified endpoint occurrences; seven taxa remain component-table context.

## Complete Structured Record

The sibling review.yaml is authoritative.

```yaml
schema_version: 1.0.0
review_id: 20261015T204258Z-p321-maintained-technical-preparation
kind: repository
repository: CultureBotAI/PathwayMech
title: 'P321 maintained technical integration: provisional authority, representation
  and export assessment'
started_at: '2026-10-15T20:36:10.892197Z'
finished_at: '2026-10-15T20:42:58.010511Z'
reviewer:
  identity: Codex independent maintained technical reviewer
  kind: agent
  independence: independent
  independence_basis: This reviewer authored no maintained implementation, record,
    authority integration, history, export or evidence package; earlier work was independent
    authority acceptance only.
skill: .claude/skills/review-yaml-record/SKILL.md (technical repository scope under
  docs/record-reviews.md; scientific_review false)
completion: partial
verdict: pass_with_limitations
scientific_review: false
summary: No new technical finding in the 57 assessed maintained/generated targets.
  Actual implementation, complete prior authority/record preservation, native histories,
  complete KGX claims and graph evidence pass the bounded checks. Full terminal test/lint
  receipt intake, corrected retained-evidence adoption and actual research-report
  binding remain required before completed technical review.
source:
  git_revision: 02bc234143d40e0e825737f27dfdcb5fd358322f
  state: working_tree
  inputs:
  - path: .claude/skills/add-pathway/SKILL.md
    sha256: f0d394f29cad1a1cd6a004abceb5f59f8e567d6b885cd6c4ff07c629c4d6db7a
    role: context
  - path: .claude/skills/review-yaml-record/SKILL.md
    sha256: 6a57ac6065171e35499578522a38c576e7bf7b6213286487d6cc0947fc477f3f
    role: context
  - path: CLAUDE.md
    sha256: c067d99547f9e9e9a6edb892d71126b6765239348d0021b907f3102907a4cf00
    role: context
  - path: conf/identifier_policy.yaml
    sha256: f57137cbec6ee2ffb4abc1c2e448dd93766e37edac9b07c43cab24c5809d27f7
    role: context
  - path: conf/identifier_sources.json
    sha256: c5b0224296302efea9e11f231d79e254c29df8eb1f8c08f4e0fdcee77d07dc4f
    role: target
  - path: conf/record_review.yaml
    sha256: a2d6578719a7d080eadc9520695ea7203618b0a7b274ee78fb25dbc17794876b
    role: context
  - path: conf/rhea_identifier_updates.json
    sha256: 8502da3089b5df4bc81d5ac6efa51454a2fe785f69cce4dbd4e4193e9484ba0a
    role: target
  - path: data/identifier_authorities/ontology.json
    sha256: 35731826db801575035eb91ad610427790349c3bdbcd0af1dfcbb5234648ee65
    role: target
  - path: data/identifier_authorities/sources.json
    sha256: 6463275f8ee68e5bc55a84e796836a8dd04f441df4e020b939761c267ea5b553
    role: target
  - path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    sha256: 40fa37e63c5be6ec6c9d33bf67f4bf06e597fc4c9b12514d34401379b124ad51
    role: target
  - path: docs/CAUSAL_GRAPHS.md
    sha256: 4f3f46d1f4b8ebafa9b2d04d9700510df18b6ec6f881856fda521879f494d153
    role: context
  - path: docs/CURATION.md
    sha256: 408f7c7705b4e6d667b513920e4c39612162d549e0c2666d85bfd53b2c2687f7
    role: context
  - path: docs/HARMONIZATION.md
    sha256: 072884773d626ea909bd1e4f275901f0a6053f660d5e68a294ee54149b6496b0
    role: context
  - path: docs/IDENTIFIERS.md
    sha256: 6d51dd8cdcc0ee4c0f285bc0769885cfe0444235957b4f3d2312ee646437be60
    role: target
  - path: docs/record-review-profile.md
    sha256: f3f00eebb7841e9d5ac891271e269f45e926995e16856b8e9a885436570c7819
    role: context
  - path: docs/record-reviews.md
    sha256: 452a19ab688276747b7c4308523a14d4d99c1c39ef6909ae8a90b85b7a9b3e9b
    role: context
  - path: history/README.md
    sha256: 478bf99c5e5cf47f9487e16c1fa78baa4bf1a43598f43f66f9e428e156f3c696
    role: context
  - path: history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
    sha256: 49b9894477b77d64f5dd0b7779b6d762af00f30a7cd103d253da2feb8ecd4d68
    role: target
  - path: history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
    sha256: f1cdba73505c7fd5c0dedc4df43a2901299ab7e78df633702f21e2f3508360be
    role: target
  - path: justfile
    sha256: 6d3df7c8fb17835c316a5f37a59c0ff7e61541bbb0781d4dd62ee6ec5fce7df2
    role: context
  - path: pages/browse.html
    sha256: 5143811a607d91abae5987e3d311210958b22d2c30289680faf15f0ceeba7dcd
    role: target
  - path: pages/downloads/edges.tsv
    sha256: 6789af1ec56a93727651135997a596336d346351b091a28e21655cff1f57ecff
    role: target
  - path: pages/downloads/manifest.json
    sha256: 8085b1aef77565b166253d7226d62c312d70ead333e337525068116367850c4e
    role: target
  - path: pages/downloads/nodes.tsv
    sha256: 04c58d1a8e71a3a0610a4f23dcf743b073d265f81bf51dd4680750b8fe8629ce
    role: target
  - path: pages/index.html
    sha256: 061b76be4e61dadf120e95eea166d4fc5a917aac8c4b646c45e3f6a7bc6cac95
    role: target
  - path: pages/pathway_index.json
    sha256: 9a8c12c796f9e073ff57a9dbc948918fed1c97cb08f43fe405e01f9505c8584a
    role: target
  - path: pages/records/MetaCyc_P321-PWY.html
    sha256: 023a4d76d157dc058becdfaca6e1b25dfae33140c89214987d8d25ca8b05c730
    role: target
  - path: schema/record_review.yaml
    sha256: 229baf9b69118a1fe318e4c31085c0820e4e3d1365e7b04d6ace451b7c35f9bb
    role: context
  - path: scripts/.vendored_canon_ref
    sha256: 698af47e96e93fe96e81910bb140593a79c2b92c4688892edeab9b63244ec5bf
    role: context
  - path: scripts/build_source_identifier_snapshot.py
    sha256: 6c6f84960a0ee84d1ba10c3ce859312a7d975c6157e7db62a8675c8c67b7e904
    role: target
  - path: scripts/check_vendored_sync.py
    sha256: 673ecd7ea0b34a29ebef8d1068d8d8973a460680e956237c8e09d97a8a22deb3
    role: context
  - path: scripts/record_review.py
    sha256: 95a4ec41e38ec47ba3578e76838c46a0adbf47e49ad3636524735d08cfcb1c4d
    role: context
  - path: src/pathwaymech/assets/pathway-network.css
    sha256: ffe62865f9ede1d8ae7c361a5576823921c850542cf03d2ca7b3c945d63d7645
    role: context
  - path: src/pathwaymech/assets/pathway-network.js
    sha256: 23b6fc25a1522c945cf61b7c269dadf93a90b8c78c357652e6653a05bcb97eac
    role: context
  - path: src/pathwaymech/biocyc_p321.py
    sha256: e22730d0d4d1c4fa6ee7ed5882ed7bb8f9ea44ec1651703a4ed9a3119d0f438a
    role: target
  - path: src/pathwaymech/biocyc_pathway.py
    sha256: d20868c6c869d414aeb3b8a230a2f5c06e179c100f4759abac1a8d38bbc54ed4
    role: target
  - path: src/pathwaymech/cli.py
    sha256: a170e60e3c398755a21e1304e3bec9e2af743af46ca62de3bbb47ea878ca0b7e
    role: context
  - path: src/pathwaymech/graph_view.py
    sha256: 45bbedd4459f21d4189e3eeb35504ff71ba664e975f4cdde7250a61e9ae3215b
    role: context
  - path: src/pathwaymech/identifiers.py
    sha256: 2dd94bf053c3ed1971de8754448ebebe7b30705f1f8e70335d6aefd69433ff90
    role: target
  - path: src/pathwaymech/kgx.py
    sha256: 4419ba74ee3949ac84a1ca1bb3cde3bf3ce73a5c975ebeab81ec1ef09dcdf3f9
    role: context
  - path: src/pathwaymech/schema.py
    sha256: bd99c1e6ca1f6eec5c82c58aa1ae3f43f696d30be66fbe0977dcace81292e0b8
    role: context
  - path: src/pathwaymech/schema/pathwaymech.yaml
    sha256: c66be7d0ae830e5041608eb6b2ce9755c601ed596ec9df5fb3567d41b202478b
    role: context
  - path: tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
    sha256: f71afffac68ab2d04a9be27a5d215030590c2c1350a5b3226b839eac612f075a
    role: target
  - path: tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
    sha256: 58585e3791da8393fec27c881872b871e9dbf07d766704fc5d3a4296d6a47b68
    role: target
  - path: tests/fixtures/p321_authority/META-CPLX-884.xml.gz
    sha256: f8a12d614c1b5c3575a570d1656570e7db06e049127244cd77d8ddc3dab5b007
    role: target
  - path: tests/fixtures/p321_authority/META-CPLX-885.xml.gz
    sha256: bd76d81a3452c7fd9cc2ec2bc599769b6db103a40845a230e565e7a74eb4a72b
    role: target
  - path: tests/fixtures/p321_authority/META-CPLX-926.xml.gz
    sha256: 59de993db43b5653b6e5a5aa357a18825f0e977d8a653f0cce81c0790b23dbc1
    role: target
  - path: tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
    sha256: b2e7f98073d988b6de911b58bf5495a7add7909e046feadb4f8345b39a81e36c
    role: target
  - path: tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
    sha256: 41e98d88922d315cfb56f2cca08777fc6f18a7a8ce2352b35b7f1ba7545d7faa
    role: target
  - path: tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
    sha256: 1988e3545736537f87b16457c075ec7aa1ddc2e571201636cfcaae969acce205
    role: target
  - path: tests/fixtures/p321_authority/META-G-545.xml.gz
    sha256: 2d4578a92abf8a6b910b0f72ba317def646eb56d285b8281097252efc5da73f5
    role: target
  - path: tests/fixtures/p321_authority/META-G-550.xml.gz
    sha256: 342c5dd4f2ea241dc5d17bbe83b065e67e45c1bd77d12fb94ea52cbe50b3b9a6
    role: target
  - path: tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
    sha256: aaa557057e6fce582e0c4574eb5c7184bee7e6f86fcd9e5926b01bf2a83caffe
    role: target
  - path: tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
    sha256: 29e5db7bca09c6523742885ff859f7e9f5611b2edd3d0f448ebd39ce3c0ca2af
    role: target
  - path: tests/fixtures/p321_authority/META-P321-PWY.xml.gz
    sha256: 0b573e4579c8b78794c9a7f8ef0756a0e7f40a46da5019f2dcef04dc3a17dbd8
    role: target
  - path: tests/fixtures/p321_authority/META-R265-RXN.xml.gz
    sha256: d213ddccbbc30c3c97d00ae876b9e3444aced71f9c2ae0bc5bf9650bea455bc3
    role: target
  - path: tests/fixtures/p321_authority/META-R266-RXN.xml.gz
    sha256: 1d7d238011586fe36a19c4df02e67abfbdb0038da82ea6f14401abf1f0a83143
    role: target
  - path: tests/fixtures/p321_authority/META-R267-RXN.xml.gz
    sha256: c56a0f3e0d97d8d66e4525b9c951357ea5c803f98c11dc96e22ec105a49203cc
    role: target
  - path: tests/fixtures/p321_authority/META-R268-RXN.xml.gz
    sha256: 0eab2881461cb0d10c829006c53940788b6828371a7c8358e406a407cabbc22f
    role: target
  - path: tests/fixtures/p321_authority/META-RXN-8031.xml.gz
    sha256: 3e9a7daea1fa52dff08f8601b3728fa56b3e3429499c1b96528b1b88caf78321
    role: target
  - path: tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
    sha256: 05418ddde411fe5f2cf536fca41691c0f92f831a450107189d37bb6c474e33ca
    role: target
  - path: tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
    sha256: 1f2b3f725417e289d2c9c740bcb924edca5dc69747a5367b4df1ea04a5f2730f
    role: target
  - path: tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
    sha256: cd8bb86c9e1f18fed7ef2c77e3ab2fbadd1a7d20f7fcf6052ed139be5641c929
    role: target
  - path: tests/fixtures/p321_authority/README.md
    sha256: 532c27f15b7ba282b7829e5cb5b84374ed509f4300d3e1046bed0ff91d9298d6
    role: target
  - path: tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
    sha256: 248fc8ba69cc77b5d4716b79a4dd8f953e58ddaef17561c80ddac56ffc787c96
    role: target
  - path: tests/fixtures/p321_authority/UniProt-O07453.json.gz
    sha256: 694f5a8faf5909dd31f186e6eecdb2e70aa656cd6b042a57d95f399e9afe436e
    role: target
  - path: tests/fixtures/p321_authority/UniProt-O07456.json.gz
    sha256: f915f6d370f199c6254ec2973f341cbe8545ba4564b2f22a7a7d8ba96ff61872
    role: target
  - path: tests/fixtures/p321_authority/UniProt-O07457.json.gz
    sha256: 2c7995b4bbbe7b27662e22663ec84f02b61ff03b0391285b624235cbd5de003f
    role: target
  - path: tests/fixtures/p321_authority/UniProt-O07458.json.gz
    sha256: 2d5f2e19d4f19ff462ad8ae9626e7e183103c87414d7c3556a7cacd4238c5df5
    role: target
  - path: tests/fixtures/p321_authority/UniProt-O07465.json.gz
    sha256: 12e0d9a2f1a51c1013cfd3183321c5cc563e598c375a31c6f550a3624025841b
    role: target
  - path: tests/fixtures/p321_authority/UniProt-Q01980.json.gz
    sha256: 829c10ec3ffed249533c605d553f5dc0b7d07f949f7c8bcf02cddf55a9218e1a
    role: target
  - path: tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
    sha256: 491365ec4014ef1bc17cccc9a9d73cf8c7fdd8d5a07a63a9becc54ee7d140e80
    role: target
  - path: tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
    sha256: 2be1a71f72f128f5b03204d02faf5649316b57735e01e5c999c0c890211f3f68
    role: target
  - path: tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
    sha256: 3f278bb64049a3824940bcf66e3a796f8538d2dc38e986d6f82d7ecdae253220
    role: target
  - path: tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
    sha256: 91765958d7f48dd78116cefd541d7b1bf40aa8012fab11b8652b26fceaa6c13f
    role: target
  - path: tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
    sha256: 332337241cdaa6ce4000b6f4d04675369630636be0f4ff4e07156172e87a5e2a
    role: target
  - path: tests/fixtures/p321_authority/expected-terms.json
    sha256: 0447a1ecac937f1d295af1b494569294ef6b885c3de8802073da506568ca230f
    role: target
  - path: tests/fixtures/p321_authority/manifest.json
    sha256: 76073172c1760ff14f11d30c074d88c5d641c88595245349bf478389b1ad86c4
    role: target
  - path: tests/fixtures/p321_authority/storage.json
    sha256: 79af148f3ec716991a3121c9fcf38d1fca9a852fc71f723ae4d8f07de773a286
    role: target
  - path: tests/test_p321_authority.py
    sha256: 72909dfde8a29c9868e3622d32ce95769b7179bd087edcd5b42b13d262937f6d
    role: target
scope:
  description: Exact maintained P321 implementation, authority, corrected record,
    two native histories and seven generated outputs.
  selection: All 43 accepted implementation outputs, four authority files, the corrected
    pathway YAML, both new histories and seven changed generated artifacts.
  coverage: full
  population_size: 57
  reviewed_target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  exclusions:
  - target: retained source payload and decoder
    reason: Not yet maintained; original decoder findings 604/605 require independently
      accepted successor and exact adoption binding.
  - target: final research report and canonical reviews
    reason: External draft read as process context only; actual maintained bytes not
      yet adopted.
  - target: scientific interpretation
    reason: Separate independent scientific review; this assessment does not re-perform
      literature or chemical judgments.
  - target: published PR head/tree and merge
    reason: Not yet committed or published; exact-head review and protected publication
      gates remain future work.
targets:
- target_id: docs/IDENTIFIERS.md
  path: docs/IDENTIFIERS.md
  label: docs/IDENTIFIERS.md
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: docs/IDENTIFIERS.md
    role: maintained source
- target_id: scripts/build_source_identifier_snapshot.py
  path: scripts/build_source_identifier_snapshot.py
  label: scripts/build_source_identifier_snapshot.py
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: scripts/build_source_identifier_snapshot.py
    role: maintained source
- target_id: src/pathwaymech/biocyc_p321.py
  path: src/pathwaymech/biocyc_p321.py
  label: src/pathwaymech/biocyc_p321.py
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/biocyc_p321.py
    role: maintained source
- target_id: src/pathwaymech/biocyc_pathway.py
  path: src/pathwaymech/biocyc_pathway.py
  label: src/pathwaymech/biocyc_pathway.py
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/biocyc_pathway.py
    role: maintained source
- target_id: src/pathwaymech/identifiers.py
  path: src/pathwaymech/identifiers.py
  label: src/pathwaymech/identifiers.py
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/identifiers.py
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  path: tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  label: tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  path: tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  label: tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  path: tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  label: tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-CPLX-884.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  path: tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  label: tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-CPLX-885.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  path: tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  label: tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-CPLX-926.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  path: tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  label: tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  path: tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  label: tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  path: tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  label: tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-G-545.xml.gz
  path: tests/fixtures/p321_authority/META-G-545.xml.gz
  label: tests/fixtures/p321_authority/META-G-545.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-G-545.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-G-550.xml.gz
  path: tests/fixtures/p321_authority/META-G-550.xml.gz
  label: tests/fixtures/p321_authority/META-G-550.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-G-550.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  path: tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  label: tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  path: tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  label: tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  path: tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  label: tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-P321-PWY.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  path: tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  label: tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-R265-RXN.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  path: tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  label: tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-R266-RXN.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  path: tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  label: tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-R267-RXN.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  path: tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  label: tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-R268-RXN.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  path: tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  label: tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/META-RXN-8031.xml.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  path: tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  label: tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  path: tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  label: tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  path: tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  label: tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/README.md
  path: tests/fixtures/p321_authority/README.md
  label: tests/fixtures/p321_authority/README.md
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/README.md
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  path: tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  label: tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-O07453.json.gz
  path: tests/fixtures/p321_authority/UniProt-O07453.json.gz
  label: tests/fixtures/p321_authority/UniProt-O07453.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-O07453.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-O07456.json.gz
  path: tests/fixtures/p321_authority/UniProt-O07456.json.gz
  label: tests/fixtures/p321_authority/UniProt-O07456.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-O07456.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-O07457.json.gz
  path: tests/fixtures/p321_authority/UniProt-O07457.json.gz
  label: tests/fixtures/p321_authority/UniProt-O07457.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-O07457.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-O07458.json.gz
  path: tests/fixtures/p321_authority/UniProt-O07458.json.gz
  label: tests/fixtures/p321_authority/UniProt-O07458.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-O07458.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-O07465.json.gz
  path: tests/fixtures/p321_authority/UniProt-O07465.json.gz
  label: tests/fixtures/p321_authority/UniProt-O07465.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-O07465.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  path: tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  label: tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-Q01980.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  path: tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  label: tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  path: tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  label: tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  path: tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  label: tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  path: tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  label: tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  path: tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  label: tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
    role: maintained source
- target_id: tests/fixtures/p321_authority/expected-terms.json
  path: tests/fixtures/p321_authority/expected-terms.json
  label: tests/fixtures/p321_authority/expected-terms.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/expected-terms.json
    role: maintained source
- target_id: tests/fixtures/p321_authority/manifest.json
  path: tests/fixtures/p321_authority/manifest.json
  label: tests/fixtures/p321_authority/manifest.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/manifest.json
    role: maintained source
- target_id: tests/fixtures/p321_authority/storage.json
  path: tests/fixtures/p321_authority/storage.json
  label: tests/fixtures/p321_authority/storage.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/fixtures/p321_authority/storage.json
    role: maintained source
- target_id: tests/test_p321_authority.py
  path: tests/test_p321_authority.py
  label: tests/test_p321_authority.py
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: tests/test_p321_authority.py
    role: maintained source
- target_id: conf/identifier_sources.json
  path: conf/identifier_sources.json
  label: conf/identifier_sources.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: conf/identifier_sources.json
    role: maintained source
- target_id: conf/rhea_identifier_updates.json
  path: conf/rhea_identifier_updates.json
  label: conf/rhea_identifier_updates.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: conf/rhea_identifier_updates.json
    role: maintained source
- target_id: data/identifier_authorities/sources.json
  path: data/identifier_authorities/sources.json
  label: data/identifier_authorities/sources.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/identifier_authorities/sources.json
    role: maintained source
- target_id: data/identifier_authorities/ontology.json
  path: data/identifier_authorities/ontology.json
  label: data/identifier_authorities/ontology.json
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/identifier_authorities/ontology.json
    role: maintained source
- target_id: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  label: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained source
- target_id: pages/browse.html
  path: pages/browse.html
  label: pages/browse.html
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: pages/downloads/edges.tsv
  path: pages/downloads/edges.tsv
  label: pages/downloads/edges.tsv
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: pages/downloads/manifest.json
  path: pages/downloads/manifest.json
  label: pages/downloads/manifest.json
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: pages/downloads/nodes.tsv
  path: pages/downloads/nodes.tsv
  label: pages/downloads/nodes.tsv
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: pages/index.html
  path: pages/index.html
  label: pages/index.html
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: pages/pathway_index.json
  path: pages/pathway_index.json
  label: pages/pathway_index.json
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: pages/records/MetaCyc_P321-PWY.html
  path: pages/records/MetaCyc_P321-PWY.html
  label: pages/records/MetaCyc_P321-PWY.html
  kind: generated
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
    role: maintained record
  - repository: CultureBotAI/PathwayMech
    path: src/pathwaymech/cli.py
    role: native page/export generator
- target_id: history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  path: history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  label: history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
    role: maintained source
- target_id: history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  path: history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  label: history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  kind: maintained
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
    role: maintained source
checks:
- check_id: c-inspect
  name: Governed input capture before assessment
  status: passed
  required: true
  summary: Actual native inspect succeeded for 57 exact targets and 80 repository
    input files.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  command: python -B scripts/record_review.py inspect --targets <this packet>/targets.yaml
    with 23 explicit context inputs
  exit_code: 0
  evidence_ids:
  - e-audit
- check_id: c-independent
  name: Independent maintained integration assertions
  status: passed
  required: true
  summary: 2,230 independent assertions passed after two explicitly preserved reviewer-helper
    corrections.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  command: python -B <this packet>/audit_maintained.py
  exit_code: 0
  evidence_ids:
  - e-audit
  - e-exports
  - e-graph
- check_id: c-validate
  name: Native whole-corpus validation
  status: passed
  required: true
  summary: Root executed just validate successfully for all 264 records; full log
    and exact current core inputs independently rebound. This is receipt intake, not
    a duplicate reviewer run.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  command: just validate
  exit_code: 0
  evidence_ids:
  - e-validation
  scope_note: Root-owned terminal execution; all core input bytes independently checked
    unchanged.
- check_id: c-vendor
  name: Pinned governed-file synchronization
  status: passed
  required: true
  summary: Root just vendored-check exited zero for all 22 artifacts at a5d562962c75a2ad9efd8160b548df5944315422;
    actual receipt, log and pin verified.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  command: just vendored-check
  exit_code: 0
  evidence_ids:
  - e-vendor
- check_id: c-diff
  name: Working-tree tracked whitespace
  status: passed
  required: true
  summary: Independent git diff --check passed; final staged-index check remains a
    publication gate.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  command: git diff --check
  exit_code: 0
  evidence_ids:
  - e-audit
- check_id: c-test
  name: just test
  status: unavailable
  required: true
  summary: Root execution is still running or queued at this cutoff; no completed
    result is claimed and the full suite was not duplicated.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  evidence_ids:
  - e-validation
- check_id: c-lint
  name: just lint
  status: unavailable
  required: true
  summary: Root execution is still running or queued at this cutoff; no completed
    result is claimed and the full suite was not duplicated.
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  evidence_ids:
  - e-validation
evidence:
- evidence_id: e-adoption
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/implementation-owner-bindings.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: All 43 actual maintained implementation outputs match accepted original
    plus explicit issue 599 successor.
  snapshot_sha256: 39eaba20b26704898c464e135cf3f80edd84f7a97d54ceb315ed0ba7db823164
- evidence_id: e-preservation
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/all263-prior-record-bindings.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Every complete actual merged record blob remains byte-identical; recursive
    scope including hidden/ignored files contains exactly 264 records.
  snapshot_sha256: 5b666bd3d4c967e7dd1e1fd6c5471e691bb651173495098a6695fb636b997434
- evidence_id: e-authority
  kind: prior_review
  reference: /private/tmp/pathwaymech-next-267-independent-full-authority-review/artifact-manifest.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Accepted full native authority replay and complete previous-owner/term
    preservation; actual four maintained files now match the exact accepted serializations.
  snapshot_sha256: 5163ed70c851c3d57cc3863ee4a9452bbc195cbc99a451d5005bbd591c49abd2
- evidence_id: e-fixtures
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/fixture-original-bindings.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: All 33 deterministic gzip fixture originals match both storage layers and
    exact accepted source bytes.
  snapshot_sha256: f8f96915755cecdb074c21d62aa20f4b34a9a4496b581d94f99941fb572b4c1e
- evidence_id: e-exports
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/independent-export-fidelity.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Every field of all 100 new edge claims, full reference/evidence/qualifier
    payloads, all 80 local node contexts, and all 13,689 prior edge rows verified.
  snapshot_sha256: b85f69ccdf3cc126a40053412bac9df60039c34524227ba461d3398522b35067
- evidence_id: e-graph
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/graph-static-and-visual-review.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Every directed graph endpoint, qualifier role, static evidence and table
    link is preserved. Actual 92 display nodes comprise 73 base nodes and 19 qualified
    occurrences; seven taxa remain table context. All three bound screenshots viewed.
  snapshot_sha256: cb9a9caea8c72ee25587075d7e1b8f7c5f287875d10b243501ef1f6a758ad872
- evidence_id: e-histories
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-ci/native-integration-history.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Two actual histories match native scaffolder receipts, Codex/ai_agent/codex
    identity, target paths and immutable pending-gate statements.
  snapshot_sha256: 7a33ad86be0a7caf90cfef498576979ef164484d22f4ebbce1cf2018d7a61992
- evidence_id: e-validation
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/observed-validation-input-binding.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Root just validate passed, and its complete core file snapshot was independently
    rebound; no full-suite pass is inferred from progress.
  snapshot_sha256: 432942c436765a3ac225b52ce5c15f272ad13be2fbf51eae3754eb42ff67f06e
- evidence_id: e-vendor
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-vendored-check/receipt.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Actual pinned vendored check passed 22 governed artifacts; receipt/log
    digest/pin verified.
  snapshot_sha256: 800ae70b9765a0d5782bedba7e8863a0a4c0dc11fd6cd2461795dd7a30615511
- evidence_id: e-audit
  kind: validation
  reference: /private/tmp/pathwaymech-next-267-maintained-technical-review-preparation/technical-audit-result.json
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: supports
  summary: Independent maintained audit passed 2,230 assertions, with all 80 inspected
    repository input hashes unchanged.
  snapshot_sha256: 55eec10714a3c93be299ab9e9dd3f109c688bb4aea373342c243ca0a124b1642
- evidence_id: e-retention-pending
  kind: prior_review
  reference: /private/tmp/pathwaymech-next-267-independent-retention-review/HANDOFF.md
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: context_only
  summary: Original evidence payload is recoverable but its standalone decoder has
    unresolved findings 604 and 605 at this cutoff. Successor acceptance and actual
    adoption are separate pending work.
  snapshot_sha256: 7b61f79add1f0ea5dfb46e4c5cf19f94ed03924455ec8a3bcc7d8509db71e89a
- evidence_id: e-report-draft
  kind: record_content
  reference: /private/tmp/pathwaymech-next-267-ci/research-report-draft.md
  accessed_at: '2026-10-15T20:42:18.949633Z'
  support: context_only
  summary: Read the full external report draft. It keeps authority, science, visual,
    retention and publication scope distinct and explicitly reports 604/605 and unfinished
    gates. Actual maintained report is not yet assessed.
  snapshot_sha256: 3c46f80a6b64a25bc86c8d854577fee6a6a30456e4ddee60174776e8a53cfbc8
assessments:
- assessment_id: a-implementation
  area: representation
  topic: Native parser and consumer integration
  outcome: supported
  target_ids:
  - docs/IDENTIFIERS.md
  - scripts/build_source_identifier_snapshot.py
  - src/pathwaymech/biocyc_p321.py
  - src/pathwaymech/biocyc_pathway.py
  - src/pathwaymech/identifiers.py
  evidence_ids:
  - e-adoption
  - e-audit
  summary: Actual implementation bytes equal independently accepted code. Complete
    original encoding/hashes, closed native profiles, preselection conflicts, unknown
    assembly coefficient and consumer-only exact legacy companion provenance remain
    intact.
- assessment_id: a-fixtures
  area: provenance
  topic: Original-byte test fixture and regression provenance
  outcome: supported
  target_ids:
  - tests/fixtures/p321_authority/META-1.3.1.62-RXN.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-8778.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-884.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-885.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-926.xml.gz
  - tests/fixtures/p321_authority/META-CPLX-9349.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Oxidized.xml.gz
  - tests/fixtures/p321_authority/META-ETF-Reduced.xml.gz
  - tests/fixtures/p321_authority/META-G-545.xml.gz
  - tests/fixtures/p321_authority/META-G-550.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-888.xml.gz
  - tests/fixtures/p321_authority/META-MONOMER-893.xml.gz
  - tests/fixtures/p321_authority/META-P321-PWY.xml.gz
  - tests/fixtures/p321_authority/META-R265-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R266-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R267-RXN.xml.gz
  - tests/fixtures/p321_authority/META-R268-RXN.xml.gz
  - tests/fixtures/p321_authority/META-RXN-8031.xml.gz
  - tests/fixtures/p321_authority/PubChem-90657525-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90657894-properties.json.gz
  - tests/fixtures/p321_authority/PubChem-90658738-properties.json.gz
  - tests/fixtures/p321_authority/README.md
  - tests/fixtures/p321_authority/UniProt-G3XCQ2.json.gz
  - tests/fixtures/p321_authority/UniProt-O07453.json.gz
  - tests/fixtures/p321_authority/UniProt-O07456.json.gz
  - tests/fixtures/p321_authority/UniProt-O07457.json.gz
  - tests/fixtures/p321_authority/UniProt-O07458.json.gz
  - tests/fixtures/p321_authority/UniProt-O07465.json.gz
  - tests/fixtures/p321_authority/UniProt-Q01980.json.gz
  - tests/fixtures/p321_authority/UniProt-Q2LQN9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H7.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3H9.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I0.json.gz
  - tests/fixtures/p321_authority/UniProt-Q6N3I1.json.gz
  - tests/fixtures/p321_authority/expected-terms.json
  - tests/fixtures/p321_authority/manifest.json
  - tests/fixtures/p321_authority/storage.json
  - tests/test_p321_authority.py
  evidence_ids:
  - e-adoption
  - e-fixtures
  summary: All accepted tests and 33 complete source fixtures are adopted unchanged;
    every compressed and decoded digest matches. These are implementation regression
    evidence, not scientific proof.
- assessment_id: a-authorities
  area: grounding
  topic: Complete ordered authority preservation
  outcome: supported
  target_ids:
  - conf/identifier_sources.json
  - conf/rhea_identifier_updates.json
  - data/identifier_authorities/sources.json
  - data/identifier_authorities/ontology.json
  evidence_ids:
  - e-authority
  - e-audit
  summary: The actual ordered 1,354-entry prefix is preserved with 36 additions. All
    3,185 prior source terms/1,173 owners and 2,190 ontology terms/five owners are
    unchanged; only the accepted 36 source and six ontology terms are added.
- assessment_id: a-record
  area: representation
  topic: Accepted record representation
  outcome: supported
  target_ids:
  - data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml
  evidence_ids:
  - e-preservation
  - e-exports
  - e-audit
  summary: Actual candidate SHA256 40fa37e6... equals the independently accepted successor;
    80 declared identities, 100 edges and 64 references serialize without claim loss.
    Scientific interpretation is outside this technical pass.
- assessment_id: a-history
  area: provenance
  topic: Native append-only session provenance
  outcome: supported
  target_ids:
  - history/infrastructure/p321-authority-profiles/2026-10-15T200956Z-Codex-0f559c.yaml
  - history/records/benzoyl-coa-degradation-iii-anaerobic/2026-10-15T200954Z-Codex-7cfd58.yaml
  evidence_ids:
  - e-histories
  - e-validation
  summary: Both new histories were natively scaffolded, match exact receipt hashes
    and describe the record/authority work with then-pending lifecycle gates explicit.
- assessment_id: a-generated
  area: graph
  topic: Generated pages and complete KGX claims
  outcome: supported
  target_ids:
  - pages/browse.html
  - pages/downloads/edges.tsv
  - pages/downloads/manifest.json
  - pages/downloads/nodes.tsv
  - pages/index.html
  - pages/pathway_index.json
  - pages/records/MetaCyc_P321-PWY.html
  evidence_ids:
  - e-exports
  - e-graph
  - e-validation
  summary: All seven actual generated artifacts are bound. Native page consistency
    validation passed; independent export and DOM checks preserve complete claims,
    and desktop/mobile screenshots retain usable focused labels and scrolling. Dense
    overview is explicitly scoped as a browsing aid.
findings: []
actions: []
limitations:
- Partial observation; no completed technical or publication verdict.
- The root full suite/lint status is captured honestly at this cutoff; no progress
  output is treated as a pass.
- Retention findings 604/605 remain open in their original independent review until
  explicit successor acceptance; absence of findings here does not resolve them.
- Screenshot assessment is a bounded visual smoke check, not accessibility/cross-browser
  testing or biological flux validation.
- Initial reviewer attempts incorrectly narrowed node context and inferred qualifier
  count from net node difference. Both failed helper attempts are preserved; corrected
  comparisons pass without product changes.
- Root alone will save canonical review records after actual adoption and terminal
  checks. This external validated draft is not a saved canonical review.
notes:
- Hidden/ignored files were included for the recursive maintained-record pathset and
  root core-input inventory; no global absence claim.
- 92 SVG display nodes = 73 base pathway/participant/reaction nodes + 19 qualified
  endpoint occurrences; seven taxa remain component-table context.
tags:
- technical-review
- p321
- partial-preparation
```
