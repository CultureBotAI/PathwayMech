"""Separate complete review controls from duplicate materialized verification bytes."""
from common import OUT, P, identity, load, dump

audit=load(OUT/'complete-correction-audit.json');assert audit['status']=='pass'
actual=load(OUT/'actual-corrected-materializations.json')
contents=load(P/'content-map.json')
rows=[];used=set()
for package,files in actual['physical'].items():
    source_map=load(P/'packages'/package/'source-map.json')
    source_map_digest=identity(P/'packages'/package/'source-map.json')['sha256']
    source_rows={r['path']:r for r in source_map['source_occurrences']}
    for path,binding in files.items():
        source=source_rows[path]
        assert binding=={'sha256':source['sha256'],'bytes':source['bytes']}
        used.add(binding['sha256'])
        rows.append({'review_path':'reconstruction/physical/'+package+'/'+path,**binding,'verification_role':'Actual independently hashed corrected-decoder physical reconstruction; not a new scientific source owner','original_owner_package':package,'original_owner_path':path,'original_external_source_path':source['source'],'payload_source_map':'packages/'+package+'/source-map.json','payload_source_map_sha256':source_map_digest,'payload_content_key':binding['sha256']})
history=load(P/'historical-compact-references.json')
historical_digest=identity(P/'historical-compact-references.json')['sha256']
index={}
for i,row in enumerate(history['rows']):
    pair=row['original_compact_pair']
    for kind in ['original','stored']:
        relative=row['original_owner_package']+'/'+pair[kind+'_path']
        index.setdefault(relative,[]).append({'historical_row_index':i,'representation':kind,'original_owner_package':row['original_owner_package'],'original_owner_path':pair[kind+'_path']})
assert set(index)==set(actual['historical'])
for path,binding in actual['historical'].items():
    used.add(binding['sha256'])
    rows.append({'review_path':'reconstruction/historical/'+path,**binding,'verification_role':'Actual independently hashed prior266 historical-reference reconstruction; original author/reviewer role retained','historical_declarations':index[path],'payload_historical_control':'historical-compact-references.json','payload_historical_control_sha256':historical_digest,'payload_content_key':binding['sha256']})
assert len(rows)==14503 and len({r['review_path'] for r in rows})==14503
for r in rows:
    assert contents[r['payload_content_key']]['source_bytes']==r['bytes']
dump('verification-output-bindings.json',{'scope':'Complete materialized corrected-recovery output tree; all bytes already recoverable from the exact unchanged source payload content map and pinned Git objects. Preserve paths and reviewer verification roles when deduplicating transport.','successor_payload_manifest_sha256':'11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce','content_map_sha256':identity(P/'content-map.json')['sha256'],'content_map_byte_identical_to_predecessor':True,'outputs':rows,'exact_content_and_storage_bindings':{k:contents[k] for k in sorted(used)},'output_count':len(rows),'physical_output_count':13577,'historical_output_count':926,'physical_source_owner_count':35,'no_scientific_reinterpretation_or_new_owner_inferred':True})
print('Bound',len(rows),'verification output paths to',len(used),'exact payload content rows')
