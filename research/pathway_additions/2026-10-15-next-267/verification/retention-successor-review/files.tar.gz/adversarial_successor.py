"""Independent fault injection against the proposed decoder; inputs stay frozen."""
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
from unittest.mock import patch

ROOT=Path('/private/tmp/pathwaymech-next-267-retention-successor/payload')
OUT=Path('/private/tmp/pathwaymech-next-267-independent-retention-successor-review')
REPO=Path('/private/tmp/pathwaymech-next-267-20261015')
spec=importlib.util.spec_from_file_location('reviewed_decoder',ROOT/'decode_retained.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
FIX=OUT/'adversarial-fixtures';FIX.mkdir()
results=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def reject(name,fn):
    try:fn()
    except (ValueError,KeyError,OSError,EOFError) as e:results.append({'case':name,'status':'rejected','exception':type(e).__name__,'message':str(e)})
    else:raise AssertionError('Expected rejection: '+name)
def observe(name,fn):
    value=fn();results.append({'case':name,'status':'accepted-unexpectedly','result':value});return value

for value in ['../escape','/absolute','x/../../escape','a\\b','./a','a//b','.','']:
    reject('relative source traversal '+repr(value),lambda v=value:mod.safe(FIX,v))
(FIX/'real').mkdir();(FIX/'link').symlink_to(FIX/'real',target_is_directory=True)
reject('symlink inside endpoint relative path',lambda:mod.safe(FIX,'link/file'))
(FIX/'link').unlink()
raw=b'complete exact original\x00\r\n  '*100
compressed=gzip.compress(raw,mtime=0)
assert mod.gunzip(compressed,sha(raw),len(raw))==raw
for name,body,digest,size in [
    ('truncated gzip',compressed[:-3],sha(raw),len(raw)),
    ('gzip bad digest',compressed,'0'*64,len(raw)),
    ('gzip too small output',compressed,sha(raw),1),
    ('gzip extra member',compressed+compressed,sha(raw),len(raw)),
    ('gzip corrupt CRC',compressed[:-8]+b'XXXXXXXX',sha(raw),len(raw)),
]:reject(name,lambda b=body,d=digest,s=size:mod.gunzip(b,d,s))
(FIX/'duplicate.json').write_text('{"same":1,"same":2}')
reject('duplicate JSON key',lambda:mod.load(FIX/'duplicate.json'))
decoder=mod.Decoder(ROOT,REPO)
try:
    fresh=next(r for r in decoder.contents.values() if r['storage']['kind']=='new_retention_object' and r['decode_steps'])
    inherited=next(r for r in decoder.contents.values() if r['storage']['kind']=='existing_repository')
    chunk=next(r for r in decoder.contents.values() if r['storage']['kind']=='new_retention_chunks')
    assert sha(decoder.decode(chunk['source_sha256']))==chunk['source_sha256']
    assert sha(decoder.decode(inherited['source_sha256']))==inherited['source_sha256']
    for field,value in [('git_commit','0'*40),('git_tree','0'*40),('path','../escape'),('stored_sha256','0'*64),('stored_bytes',-1)]:
        changed=copy.deepcopy(inherited['storage']);changed[field]=value
        reject('inherited '+field,lambda s=changed:decoder.endpoint(s))
    proofkey=(mod.BASE,inherited['storage']['path']);proof=decoder.proofs[proofkey]
    decoder.proofs[proofkey]={**proof,'git_tree':'0'*40}
    reject('actual inherited proof tree',lambda:decoder.endpoint(inherited['storage']))
    decoder.proofs[proofkey]=proof
    for field,value in [('path','../escape'),('path','/absolute'),('stored_bytes',mod.LIMIT),('stored_sha256','0'*64),('kind','unknown')]:
        changed=copy.deepcopy(fresh['storage']);changed[field]=value
        reject('new endpoint '+field+' '+str(value),lambda s=changed:decoder.endpoint(s))
    digest=fresh['source_sha256'];decoder.cache.pop(digest,None)
    for field,value in [('encoding','zip'),('input_sha256','0'*64),('output_sha256','0'*64),('output_bytes',0)]:
        changed=copy.deepcopy(fresh);changed['decode_steps'][0][field]=value;decoder.contents[digest]=changed
        reject('decode layer '+field,lambda:decoder.decode(digest))
    decoder.contents[digest]=fresh
    for name,mutation in [
        ('chunk reversal',lambda s:s['chunks'].reverse()),
        ('chunk omission',lambda s:s['chunks'].pop()),
        ('chunk duplicate',lambda s:s['chunks'].append(s['chunks'][0])),
        ('chunk bad hash',lambda s:s['chunks'][0].update(sha256='0'*64)),
        ('chunk bad offset',lambda s:s['chunks'][1].update(offset=0)),
        ('chunk traversal',lambda s:s['chunks'][0].update(path='../escape')),
        ('chunk endpoint limit',lambda s:s['chunks'][0].update(bytes=mod.LIMIT)),
    ]:
        changed=copy.deepcopy(chunk['storage']);mutation(changed)
        reject(name,lambda s=changed:decoder.endpoint(s))
    # Derive history from the exact corrected implementation, then corrupt only
    # independent fixture controls. Original payload and source owners stay frozen.
    original=json.loads((ROOT/'historical-compact-references.json').read_text())
    history=FIX/'history';history.mkdir()
    binding=original['prior_pairs_binding']
    retained=history/binding['retained_gzip'];retained.parent.mkdir(parents=True)
    shutil.copyfile(ROOT/binding['retained_gzip'],retained)
    shutil.copyfile(ROOT/'source-specification.json',history/'source-specification.json')
    for package in json.loads((ROOT/'source-specification.json').read_text())['packages']:
        target=history/'packages'/package['name']/'source-map.json'
        target.parent.mkdir(parents=True);shutil.copyfile(ROOT/'packages'/package['name']/'source-map.json',target)
    def restore_history():
        (history/'historical-compact-references.json').write_text(json.dumps(original))
    restore_history()
    plan=mod.historical_plan(history,decoder)
    assert len(plan['rows'])==477 and len(plan['expected_paths'])==926
    expected=json.loads(Path('/private/tmp/pathwaymech-next-267-independent-retention-review/historical-reconstructed-paths.json').read_text())
    assert plan['expected_paths']==expected
    def historical_case(name,mutation):
        altered=copy.deepcopy(original);mutation(altered)
        (history/'historical-compact-references.json').write_text(json.dumps(altered))
        reject(name,lambda:mod.historical_plan(history,decoder))
    for name,mutation in [
        ('R01 zero historical rows',lambda o:o.update(rows=[])),
        ('R01 one historical row omitted',lambda o:o['rows'].pop()),
        ('R01 duplicate historical row',lambda o:o['rows'].append(o['rows'][0])),
        ('R01 duplicated replacement row',lambda o:o['rows'].__setitem__(1,o['rows'][0])),
        ('R01 original owner relabeled as current independent reviewer',lambda o:o['rows'][0].update(original_owner_package='next267-independent-retention-review')),
        ('R01 copied manifest hash altered',lambda o:o['rows'][0].update(current_manifest_sha256='0'*64)),
        ('R01 copied manifest path altered',lambda o:o['rows'][0].update(current_manifest='missing.json')),
        ('R01 copied current package altered',lambda o:o['rows'][0].update(current_package='design')),
        ('R01 rows reordered',lambda o:o['rows'].reverse()),
        ('R01 historical original hash altered',lambda o:o['rows'][0]['original_compact_pair'].update(original_sha256='0'*64)),
        ('R01 historical original path traversal',lambda o:o['rows'][0]['original_compact_pair'].update(original_path='../escape')),
        ('R01 supplemental content omitted',lambda o:o['additional_content_rows'].pop()),
        ('R01 supplemental content duplicated',lambda o:o['additional_content_rows'].append(o['additional_content_rows'][0])),
        ('R01 supplemental content changed',lambda o:o['additional_content_rows'].__setitem__(0,'0'*64)),
    ]:historical_case(name,mutation)
    for field,value in [('git_commit','0'*40),('git_tree','0'*40),('git_blob','0'*40),('path','missing'),('sha256','0'*64),('bytes',0),('retained_gzip','../escape'),('retained_sha256','0'*64)]:
        historical_case('R01 pinned prior binding '+field,lambda o,f=field,v=value:o['prior_pairs_binding'].__setitem__(f,v))
    restore_history()
    (history/'historical-compact-references.json').unlink()
    reject('R01 historical metadata missing',lambda:mod.historical_plan(history,decoder))
    restore_history()
    map_path=history/'packages/primary/source-map.json'
    source_map=json.loads(map_path.read_text())
    target_name=mod.HISTORICAL_MAPS[0][2]
    for field,value in [('sha256','0'*64),('bytes',0)]:
        altered=copy.deepcopy(source_map)
        next(r for r in altered['source_occurrences'] if r['path']==target_name)[field]=value
        map_path.write_text(json.dumps(altered))
        reject('R01 actual copied source map '+field,lambda:mod.historical_plan(history,decoder))
    map_path.write_text(json.dumps(source_map))
    with patch.object(mod.subprocess,'check_output',return_value=b'wrong prior Git bytes'):
        reject('R01 actual prior Git bytes wrong despite unchanged declared binding',lambda:mod.historical_plan(history,decoder))
    # Verify all source bindings and hashes are carried into the corrected plan.
    plan=mod.historical_plan(history,decoder)
    assert plan['control_sha256']['historical-compact-references.json']==sha((history/'historical-compact-references.json').read_bytes())
    assert len(plan['control_sha256']['physical_source_maps'])==35
    assert [r['declarations'] for r in plan['source_manifest_bindings']]==[408,69]
finally:decoder.close()

# These are real main() calls with creation instrumented. Any attempted mkdir is
# a test failure, and the probe never writes outside the owned fixture directory.
class UnexpectedWrite(Exception):pass
attempts=[]
def intercepted_mkdir(self,*args,**kwargs):
    attempts.append(str(self));raise UnexpectedWrite(str(self))
def reject_main_destination(name,dest):
    attempts.clear()
    with patch.object(sys,'argv',['decode_retained.py','--root',str(ROOT),'--repo',str(REPO),'--materialize',str(dest)]),patch.object(Path,'mkdir',intercepted_mkdir):
        reject(name,mod.main)
    assert attempts==[],('creation attempted before rejection',name,attempts)

for name,dest in [
    ('R02 original parent traversal',Path('/private/tmp/../../Users/marcin/retention-review-must-not-be-created')),
    ('R02 parent traversal remaining within scratch',FIX/'a/../new'),
    ('R02 relative destination',Path('relative-new')),
    ('R02 outside scratch absolute',Path('/Users/marcin/retention-review-must-not-be-created')),
    ('R02 prefix lookalike',Path('/private/tmp-lookalike/new')),
    ('R02 scratch root itself',Path('/private/tmp')),
    ('R02 existing directory',FIX),
    ('R02 existing file',FIX/'duplicate.json'),
    ('R02 existing file parent',FIX/'duplicate.json/new'),
]:reject_main_destination(name,dest)

for name,target,destination_suffix in [
    ('R02 original outside symlink ancestor','/Users/marcin','new'),
    ('R02 in-scratch symlink ancestor',str(FIX/'real'),'new'),
    ('R02 dangling symlink ancestor',str(FIX/'missing'),'new'),
    ('R02 symlink target',str(FIX/'real'),''),
    ('R02 dangling symlink target',str(FIX/'missing'),''),
]:
    alias=FIX/'parent-alias';alias.symlink_to(target,target_is_directory=True)
    try:reject_main_destination(name,alias/destination_suffix if destination_suffix else alias)
    finally:alias.unlink()

fresh=FIX/'fresh-deep/child'
assert mod.validate_destination(fresh)==fresh.resolve() and not fresh.exists()
# Whole CLI missing-history regression: initialization can succeed from copied
# controls, but history must reject before materialization creates anything.
for control in ['content-map.json','existing-owner-verification.json','merged-baseline-binding.json']:
    shutil.copyfile(ROOT/control,history/control)
(history/'historical-compact-references.json').unlink()
attempts.clear()
with patch.object(sys,'argv',['decode_retained.py','--root',str(history),'--repo',str(REPO),'--materialize',str(FIX/'must-remain-absent')]),patch.object(Path,'mkdir',intercepted_mkdir):
    reject('R01 actual main rejects missing historical metadata before creating destination',mod.main)
assert attempts==[] and not (FIX/'must-remain-absent').exists()

(OUT/'independent-adversarial-results.json').write_text(json.dumps({'status':'pass','results':results,'rejected_controls':len(results),'unexpected_acceptances':0,'original_findings_regressed':{'R01':True,'R02':True},'positive_controls':['exact complete gzip','actual inherited Git blob','actual four-chunk Noctua original','correct historical plan exactly 477 pairs/926 paths','fresh ordinary destination validated without creation'],'all_frozen_inputs_read_only':True,'out_of_scope_writes':0,'original_review_source_reused_for_unchanged_37_legacy_controls':True},indent=2)+'\n')
print('PASS',len(results),'independent rejection controls')
