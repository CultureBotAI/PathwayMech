import ast
import datetime
import subprocess
import sys
from common import BASE, OUT, P, PREV, REPO, REVIEW, SRC, TREE, check_manifest, dump, identity, inventory, load, sha

started=datetime.datetime.now(datetime.timezone.utc).isoformat()
print('Hash complete successor, original independent review, and predecessor payload',flush=True)
before={name:inventory(root) for name,root in [('successor',SRC),('original_review',REVIEW),('predecessor_payload',PREV)]}
dump('inputs-before.json',before)
check_manifest(SRC,before['successor'],'7676c4ddfcfed5d6823bee84dd78a1f02790890733450293fe2cdc709b2bbed4',['artifact-manifest.json','freeze-proof.json'])
check_manifest(REVIEW,before['original_review'],'0ac7577c317d8ab7e20a6d4a4334b12cbedaa4c873c4af2e4894bc7529adaa86',['artifact-manifest.json','freeze-proof.json'])
check_manifest(PREV,before['predecessor_payload'],'9a81127803cb3e0688736a1aeab036d118d1e84f4f46a53f3e3a825d3eb5bcd7',['artifact-manifest.json'])
assert sha((SRC/'HANDOFF.md').read_bytes())=='681af39d0cf8b065a9bd003db60137dc643c42d6d037517d9824e0800f94bcd0'
payload={k[len('payload/'):]:v for k,v in before['successor'].items() if k.startswith('payload/')}
check_manifest(P,payload,'11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce',['artifact-manifest.json'])
assert identity(P/'decode_retained.py')['sha256']=='b897526847b44cf43f3e3d3a583775bd3502567719f163c05195826b0d154980'
old=before['predecessor_payload'];assert set(old)<=set(payload)
changed=[k for k in old if old[k]!=payload[k]]
assert set(changed)=={'decode_retained.py','README.md','artifact-manifest.json'}
unchanged=[k for k in old if old[k]==payload[k]];added=sorted(set(payload)-set(old))
assert len(unchanged)==5893 and len(added)==73 and len(payload)==5969
assert all(v['bytes']<100*1024*1024 for v in payload.values())
for name in changed:
    stored_name=name+'.txt' if name.endswith('.py') else name
    assert (P/'predecessor-controls'/stored_name).read_bytes()==(PREV/name).read_bytes()
delta=load(SRC/'proof/exact-payload-delta.json')
assert set(r['path'] for r in delta['changed'])==set(changed)
assert {r['path']:{'sha256':r['sha256'],'bytes':r['bytes']} for r in delta['added']}=={k:payload[k] for k in added}
assert {r['path']:{'sha256':r['sha256'],'bytes':r['bytes']} for r in delta['unchanged']}=={k:payload[k] for k in unchanged}
assert delta['removed']==[]
def definitions(path):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a=definitions(PREV/'decode_retained.py');b=definitions(P/'decode_retained.py')
changed_definitions=sorted(k for k in a if a[k]!=b.get(k))
assert changed_definitions==['load','main','verify_historical']
assert sorted(set(b)-set(a))==['historical_plan','parse_json','validate_destination']
assert not set(a)-set(b)
dump('independent-exact-delta.json',{'status':'pass','changed':changed,'unchanged':len(unchanged),'added':added,'removed':[],'changed_existing_definitions':changed_definitions,'new_definitions':sorted(set(b)-set(a)),'all_source_storage_content_and_owner_maps_byte_identical':True,'source_decoder_sha256':identity(P/'decode_retained.py')['sha256']})
dump('inputs-before.json',before)
print('Verify all 35 original source owners and original reviewer control transport',flush=True)
spec=load(P/'source-specification.json');maps={};owners_before={}
for package in spec['packages']:
    name=package['name'];m=load(P/'packages'/name/'source-map.json')
    maps[name]={r['path']:{'sha256':r['sha256'],'bytes':r['bytes']} for r in m['source_occurrences']}
    actual=inventory(__import__('pathlib').Path(package['source_root']))
    assert actual==maps[name]
    owners_before[name]=actual
assert len(maps)==35
dump('source-owners-before.json',owners_before)
transport=load(P/'successor-proof/original-review-control-storage-map.json')
dump('original-review-control-transport-shape.json',{'type':type(transport).__name__,'keys':list(transport) if isinstance(transport,dict) else None})
assert subprocess.check_output(['git','rev-parse',BASE+'^{tree}'],cwd=REPO).decode().strip()==TREE
print('Run exact corrected standalone CLI with fresh complete materialization',flush=True)
command=[sys.executable,'-B',str(P/'decode_retained.py'),'--repo',str(REPO),'--materialize',str(OUT/'reconstruction'),'--receipt',str(OUT/'corrected-cli-receipt.json')]
with (OUT/'corrected-cli.stdout.txt').open('wb') as stdout,(OUT/'corrected-cli.stderr.txt').open('wb') as stderr:
    process=subprocess.run(command,stdout=stdout,stderr=stderr)
dump('corrected-cli-command.json',{'argv':command,'returncode':process.returncode,'offline':True,'comparison_to_originals':False})
assert process.returncode==0
receipt=load(OUT/'corrected-cli-receipt.json')
assert receipt['status']=='pass' and receipt['physical_occurrences']==13577 and receipt['physical_bytes']==1644920637
assert receipt['compact']=={'declared_rows_verified':6175,'compact_only_originals':0}
assert receipt['historical']['declared_rows']==477 and receipt['historical']['distinct_reference_paths']==926
assert receipt['control_sha256']['historical-compact-references.json']==identity(P/'historical-compact-references.json')['sha256']
assert receipt['historical']['control_sha256']['historical-compact-references.json']==identity(P/'historical-compact-references.json')['sha256']
print('Independently compare actual corrected materializations with original source maps',flush=True)
recon={name:inventory(OUT/'reconstruction/physical'/name) for name in maps}
assert recon==maps
historical=inventory(OUT/'reconstruction/historical')
prior_historical=load(REVIEW/'historical-reconstructed-paths.json')
assert len(historical)==926 and {k:v['sha256'] for k,v in historical.items()}==prior_historical
assert not (OUT/'reconstruction/logical').exists()
assert {p.name for p in (OUT/'reconstruction/physical').iterdir()}==set(maps)
assert {p.name for p in (OUT/'reconstruction').iterdir()}=={'physical','historical'}
dump('actual-corrected-materializations.json',{'physical':recon,'historical':historical,'scope':'Independent hashes and full hidden/ignored pathsets of actual corrected CLI outputs; author receipt is not the sole proof.'})
print('Final full input and original owner preservation check',flush=True)
after={name:inventory(root) for name,root in [('successor',SRC),('original_review',REVIEW),('predecessor_payload',PREV)]}
assert before==after;dump('inputs-after.json',after)
owners_after={p['name']:inventory(__import__('pathlib').Path(p['source_root'])) for p in spec['packages']}
assert owners_after==owners_before;dump('source-owners-after.json',owners_after)
dump('complete-correction-audit.json',{'status':'pass','started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'successor_physical_files':len(before['successor']),'original_review_physical_files':len(before['original_review']),'predecessor_payload_physical_files':len(old),'successor_payload_physical_files':len(payload),'source_owners':35,'physical_occurrences':13577,'current_compact_declarations':6175,'historical_pairs':477,'historical_paths':926,'all_before_after_inventories_unchanged':True,'original_needs_curation_review_preserved':True,'corrected_cli_full_recovery_independently_verified':True,'full_repository_tests_not_repeated':True,'scope':'Technical correction successor only; no scientific, licensing, maintained or publication acceptance.'})
print('COMPLETE corrected recovery and preservation',flush=True)
