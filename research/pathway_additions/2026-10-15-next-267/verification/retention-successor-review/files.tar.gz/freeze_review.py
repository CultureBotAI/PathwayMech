"""Freeze the complete successor review and an explicit deduplicated transport boundary."""
import datetime
from common import OUT, P, identity, inventory, load, dump

audit=load(OUT/'complete-correction-audit.json')
controls=load(OUT/'independent-adversarial-results.json')
bindings=load(OUT/'verification-output-bindings.json')
assert audit['status']=='pass'
assert controls['status']=='pass' and controls['rejected_controls']==78 and controls['unexpected_acceptances']==0
assert load(OUT/'inputs-before.json')==load(OUT/'inputs-after.json')
assert load(OUT/'source-owners-before.json')==load(OUT/'source-owners-after.json')
assert bindings['output_count']==14503
assert load(OUT/'predecessor-review-preservation.json')['status']=='pass'
dispositions=[
    {'id':'R01','issue':604,'prior_severity':'moderate','disposition':'resolved_in_exact_reviewed_successor','evidence':['independent-adversarial-results.json','corrected-cli-receipt.json','actual-corrected-materializations.json'],'basis':'The corrected historical plan requires metadata and derives all 477 declarations, all 926 original/stored paths, exact prior owner roles, and all 388 supplemental contents from pinned actual Git bytes plus both copied original source manifests. Missing, empty, incomplete, duplicate, reordered and altered controls reject. The unchanged plan matches the independent original 926-path inventory, and the full CLI recovers it exactly with historical hashes and source-manifest bindings in its receipt.','historical_record':'The original independent review remains needs_curation with its original findings unchanged.'},
    {'id':'R02','issue':605,'prior_severity':'minor','disposition':'resolved_in_exact_reviewed_successor','evidence':['independent-adversarial-results.json','corrected-cli-command.json','actual-corrected-materializations.json'],'basis':'Resolved destination and all relevant ancestor checks run before creation. Original parent traversal and symlink escape reject, as do in-scratch and dangling symlinks, existing paths, file ancestors, outside and lookalike prefixes, and the scratch root itself. Instrumented actual main calls attempt no mkdir. A fresh ordinary scratch destination successfully materializes all expected files.','historical_record':'No original finding is overwritten or retrospectively relabeled.'},
]
dump('findings.json',{'status':'accepted-bounded-retention-successor','findings':[],'prior_finding_dispositions':dispositions,'source_payload_manifest_sha256':'11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce','source_decoder_sha256':'b897526847b44cf43f3e3d3a583775bd3502567719f163c05195826b0d154980','scope':'Technical retention correction only; no scientific, maintained, licensing, canonical-review or publication acceptance.'})
assessment='''# Independent retention correction acceptance

The exact frozen correction successor resolves both original decoder findings, R01/#604 and R02/#605. No new actionable findings were found in this bounded technical review. The original independent review remains immutable with its original needs-curation verdict, findings and failed reviewer diagnostics.

The reviewed full successor manifest is `7676c4ddfcfed5d6823bee84dd78a1f02790890733450293fe2cdc709b2bbed4` (20,588 physical files). The proposed payload manifest is `11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce` (5,969 physical files), and the exact decoder is `b897526847b44cf43f3e3d3a583775bd3502567719f163c05195826b0d154980`.

## Complete scope and preservation

The independent audit reads and hashes every file in the full successor, the complete 25,707-file original independent review, and the 5,896-file predecessor payload. It checks exact manifest inventories, including hidden and ignored files. All 35 original source owners are independently inventoried against their full retained source maps. All these input pathsets and byte hashes are checked again after the complete recovery run and remain unchanged. The original preparation's additional scratch reconstruction trees are not freshly rehashed in this successor review; they were completely bound and checked by the original independent review. This successor's full exact source-byte delta and original-role preservation are verified independently.

Exactly three predecessor payload files changed: the active decoder, README and payload manifest. All 5,893 other original files remain byte-identical; none is removed. The 73 additions contain bounded correction proofs and preserved prior controls. The exact original decoder, README and manifest are retained. All 31 non-reconstruction files from the original review are copied losslessly under an explicit path map, including every original diagnostic, its original needs-curation findings, and its full manifest and freeze proof. Its duplicate reconstruction trees remain explicitly bound external verification outputs, not new scientific owners.

The content map, source-package maps, all compact declarations, original evidence, owner roles, stored representations, inherited Git provenance and external database exclusions are unchanged. In the decoder, only three existing definitions change (`load`, `main`, `verify_historical`); three helpers are added (`parse_json`, `historical_plan`, `validate_destination`). The existing content decoder, physical-map reader and current-compact verifier are unchanged. Existing BASE/TREE and hosting-size constraints remain in place. Every proposed payload file is below 100 MiB.

## Independent corrected behavior

Seventy-eight independent rejection controls pass with zero unexpected acceptances. They include all original findings and the 37 unchanged legacy malformed-input controls. Historical cases cover missing metadata, zero/omitted/duplicated/reordered declarations, altered original owner roles, copied manifest path/hash/package drift, changed original identities or paths, supplemental-content omissions and duplicates, all pinned prior binding fields, a false actual copied-source map, and wrong actual prior Git bytes. A positive historical derivation independently matches every one of the original review's 926 historical path hashes and preserves the two original author/reviewer owner roles.

Destination cases use actual `main()` calls with filesystem creation instrumented. Parent traversal, symlink ancestors or targets (including dangling and in-scratch aliases), existing targets, file ancestors, relative/outside/lookalike paths, and the scratch root reject before any mkdir. No outside-scratch writes occur. A normal fresh destination is a positive control. A whole-CLI missing-history probe also rejects before creating its otherwise valid destination.

The exact corrected standalone CLI is run offline with a fresh destination and actual pinned Git objects. It succeeds for all 13,577 physical occurrences (1,644,920,637 bytes), all 6,175 current compact declarations, all 477 historical pairs and 926 historical paths. The reviewer then independently enumerates and hashes the actual output trees: all physical files equal the complete original source maps, and all historical files equal the original independently verified path inventory. The receipt includes historical controls, original source-manifest bindings, and exact commit/tree provenance. Successful author tests are supporting history, not the sole basis of this acceptance.

The original record's source-byte and reference coverage checks remain applicable because their complete source content, maps and candidate bytes are unchanged. This correction review does not reinterpret the scientific evidence or repeat full repository tests.

## Review output transport and diagnostics

`verification-output-bindings.json` enumerates all 14,503 actual reconstructed files with their exact review paths, hashes, sizes, original physical or historical owner roles, and precise unchanged payload content/storage bindings. This allows later transport to avoid copying duplicate reconstructed bytes while preserving their verification role and original placement. They are not new authority records. `review-control-inventory.json` enumerates every non-reconstruction control and diagnostic; the full review manifest and freeze proof are additional self-binding records.

The initial independent audit assumed the archived predecessor helper retained a `.py` filename. It is correctly preserved as inert `.py.txt`; the reviewer corrected that transport-name assertion. The original script and failure logs are retained and no source defect is inferred. A preliminary read also used the wrong relative location for the author's delta report before its root-level path was inspected. No frozen input or runtime was repaired.

This is acceptance of the two bounded technical retention corrections only. It changes no maintained file, Git or GitHub state, original review, source owner or shared runtime, and implies no licensing, scientific, canonical-review, merge or publication approval. No child agents or duplicated repository test suite were used.
'''
(OUT/'ASSESSMENT.md').write_text(assessment)
handoff='''# Independent next267 retention successor review

Verdict: **accepted-bounded-retention-successor**, with zero new findings. Both R01/#604 and R02/#605 are resolved in the exact reviewed successor. The original needs-curation review remains unchanged.

- Full successor manifest: `7676c4ddfcfed5d6823bee84dd78a1f02790890733450293fe2cdc709b2bbed4`.
- Proposed payload manifest: `11a6f52cfa2d6afd5ed51d641d4b33eb59220422e5dc251536bb817891a7a1ce`.
- Corrected decoder: `b897526847b44cf43f3e3d3a583775bd3502567719f163c05195826b0d154980`.
- Exact delta: only decoder, README and manifest changed; 5,893 predecessor files unchanged, no removal, 73 additions.
- Independent controls: 78 rejection cases passed, zero unexpected acceptances; all original defects now reject. Unsafe creation probes performed zero outside-scratch writes.
- Fresh complete corrected CLI recovery and independent output comparison passed: 13,577 physical files, 6,175 current compact declarations, 477 historical pairs, 926 historical paths.
- Full successor, complete original review, predecessor payload and all 35 original source owners remain byte- and path-identical before/after review, including hidden/ignored files.
- All 31 original-review non-reconstruction controls and diagnostics are preserved exactly, with original disposition and reviewer role intact.

`ASSESSMENT.md` states scope and limitations; `findings.json` contains the explicit successor dispositions. Complete command receipts, failures, exact delta, malformed-input results and actual output hashes are retained. All verification sessions terminated before freeze.

For lossless transport, retain every entry of `review-control-inventory.json` plus that inventory itself, `artifact-manifest.json`, and `freeze-proof.json`. The separate `verification-output-bindings.json` enumerates all 14,503 actual reconstruction outputs and ties each to exact unchanged payload content and inherited Git storage. Their duplicate bytes may remain external while their paths, hashes, original owner roles and actual verification status remain preserved. The full external review manifest binds both controls and actual reconstruction files.

Only the reviewed successor `payload/` is accepted as the technical retention boundary. This is not approval of scientific interpretation, licensing, maintained integration, canonical reviews or publication. No maintained, Git, GitHub, shared-runtime or original-owner mutations were made.
'''
(OUT/'HANDOFF.md').write_text(handoff)
all_files=inventory(OUT)
excluded={'artifact-manifest.json','freeze-proof.json','review-control-inventory.json'}
control_rows=[{'path':k,**v} for k,v in sorted(all_files.items()) if not k.startswith('reconstruction/') and k not in excluded]
assert all(r['bytes']<100*1024*1024 for r in control_rows)
dump('review-control-inventory.json',{'scope':'Every non-reconstruction review file, including all scripts, attempted checks, fixtures, receipts and diagnostics. Add this inventory and full artifact-manifest/freeze-proof self records to form the complete control transport boundary.','controls':control_rows,'excluded_duplicate_output_prefix':'reconstruction/','duplicate_output_binding':'verification-output-bindings.json','self_records_to_add':['review-control-inventory.json','artifact-manifest.json','freeze-proof.json']})
all_files['review-control-inventory.json']=identity(OUT/'review-control-inventory.json')
manifest_rows=[{'path':k,**v} for k,v in sorted(all_files.items()) if k not in {'artifact-manifest.json','freeze-proof.json'}]
dump('artifact-manifest.json',{'scope':'Complete external independent correction review, including actual reconstructed bytes and all control/diagnostic files.','excluded_self_records':['artifact-manifest.json','freeze-proof.json'],'files':manifest_rows})
for r in manifest_rows:assert identity(OUT/r['path'])=={'sha256':r['sha256'],'bytes':r['bytes']}
proof={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'accepted-bounded-retention-successor','new_findings':0,'resolved_findings':['R01/#604','R02/#605'],'manifest_sha256':identity(OUT/'artifact-manifest.json')['sha256'],'handoff_sha256':identity(OUT/'HANDOFF.md')['sha256'],'control_inventory_sha256':identity(OUT/'review-control-inventory.json')['sha256'],'verification_output_bindings_sha256':identity(OUT/'verification-output-bindings.json')['sha256'],'listed_files':len(manifest_rows),'physical_files':len(manifest_rows)+2,'listed_bytes':sum(r['bytes'] for r in manifest_rows),'non_reconstruction_control_rows':len(control_rows),'actual_reconstruction_outputs':14503,'all_manifested_bytes_reverified':True,'all_review_execution_sessions_terminal_before_freeze':True,'all_before_after_input_inventories_unchanged':True}
dump('freeze-proof.json',proof)
print(__import__('json').dumps(proof))
