import hashlib
import json
import os
from pathlib import Path

OUT=Path(__file__).parent
SRC=Path('/private/tmp/pathwaymech-next-267-retention-successor')
P=SRC/'payload'
PREV=Path('/private/tmp/pathwaymech-next-267-retention-preparation/payload')
REVIEW=Path('/private/tmp/pathwaymech-next-267-independent-retention-review')
REPO=Path('/private/tmp/pathwaymech-next-267-20261015')
BASE='02bc234143d40e0e825737f27dfdcb5fd358322f'
TREE='08c04c1808980164ab90512f83e6e1c9bb5f16af'

def sha(body):return hashlib.sha256(body).hexdigest()
def identity(path):
    h=hashlib.sha256();size=0
    with path.open('rb') as stream:
        while part:=stream.read(1024*1024):h.update(part);size+=len(part)
    return {'sha256':h.hexdigest(),'bytes':size}
def load(path):
    def unique(pairs):
        result={}
        for k,v in pairs:
            assert k not in result,('duplicate JSON key',str(path),k)
            result[k]=v
        return result
    return json.loads(path.read_bytes(),object_pairs_hook=unique)
def dump(name,obj):(OUT/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def inventory(root):
    result={}
    for dirname,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:assert not (Path(dirname)/name).is_symlink(),('input symlink',dirname,name)
        for name in files:
            path=Path(dirname)/name
            assert path.is_file()
            result[str(path.relative_to(root))]=identity(path)
    return result
def check_manifest(root,actual,digest,exclude):
    assert identity(root/'artifact-manifest.json')['sha256']==digest
    rows=load(root/'artifact-manifest.json')['files']
    expected={r['path']:{'sha256':r['sha256'],'bytes':r['bytes']} for r in rows}
    assert len(expected)==len(rows)
    assert set(expected)|set(exclude)==set(actual)
    assert all(actual[k]==v for k,v in expected.items())
