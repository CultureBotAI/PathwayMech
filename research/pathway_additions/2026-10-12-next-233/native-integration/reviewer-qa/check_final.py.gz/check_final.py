"""Read-only current THIO integration verification after actual root final gates."""
import csv
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import yaml

HERE=Path(__file__).parent
ROOT=Path('/private/tmp/pathwaymech-next-233-20261012')
PREP=Path('/private/tmp/pathwaymech-next-233-maintained-integration-successor-20261012')
CORRECTED=Path('/private/tmp/pathwaymech-next-233-history-actor-correction-20261012')
GATES=Path('/private/tmp/pathwaymech-next-233-maintained-final-gates-20261012')
NETWORK=Path('/private/tmp/pathwaymech-next-233-maintained-network-completion-20261012')
ACCEPTED=Path('/private/tmp/pathwaymech-next-233-verification-recovery-run-20261012')

def main():
 spec=importlib.util.spec_from_file_location('integration_primitives',PREP/'common.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 assert c.bind(PREP/'common.py')['sha256']=='e8328237e2df82e39166810de9a753c5f9dffc924cbada6eb92a72bde25af2ed'
 assert c.bind(NETWORK/'gate-completion.json')['sha256']=='3359e820a1ec2e828df6ec0c3e9099c1801cc7761ed845643a84909d09c9b83a'
 assert c.bind(NETWORK/'history-correction-completion.json')['sha256']=='1b3a2c42a2e882e63153236636410b4196c828ec949b9d63dcd67b4e81314bc1'
 gates=c.load(NETWORK/'gate-completion.json');correction=c.load(NETWORK/'history-correction-completion.json')
 assert gates['status']=='all_nine_maintained_gates_passed' and correction['status']=='history_actor_corrected_and_all_final_gates_passed'
 assert [r['name'] for r in gates['commands']]==['render','skills','validate','tests','lint','kgx','vendored','diff-check','site-current']
 for index,row in enumerate(gates['commands']):
  directory=GATES if index<6 else NETWORK
  assert c.load(directory/(row['name']+'.execution.json'))==row
  assert row['exit_code']==0
  c.verify(row['stdout']);c.verify(row['stderr'])
 assert correction['history_validation']['exit_code']==0
 for field in ('stdout','stderr'):c.verify(correction['history_validation'][field])
 c.verify(correction['correction_before_render']);c.verify(correction['final_gates'])
 assert correction['full_tests_repeated_after_export_fix'] is True
 assert correction['final_gates']==c.bind(NETWORK/'gate-completion.json')
 for key in ('input_inventory','initial_failed_suite_retained','failed_network_gate_retained','failed_corrective_wrapper_retained','network_resume_intake'):c.verify(gates[key])
 for key in ('failed_network_gate_retained','failed_corrective_wrapper_retained'):
  assert correction[key]==gates[key]
  failed=c.load(gates[key]['path']);assert failed['exit_code']==1
  c.verify(failed['stdout']);c.verify(failed['stderr'])
 failed_vendored=c.load(gates['failed_network_gate_retained']['path'])
 assert failed_vendored['argv']==gates['commands'][6]['argv']
 assert b'nodename nor servname provided, or not known' in Path(failed_vendored['stderr']['path']).read_bytes()
 resume=c.load(gates['network_resume_intake']['path'])
 assert resume['status']=='resume_remaining_three_checks_after_network_fetch_failure'
 assert resume['no_full_suite_rerun'] is True and gates['network_resume_all_current_files_unchanged'] is True
 assert len(resume['six_passed'])==6
 for index,pin in enumerate(resume['six_passed']):
  c.verify(pin);assert c.load(pin['path'])==gates['commands'][index]
 retry_preservation=c.load(NETWORK/'vendored-preservation.json')
 assert retry_preservation['all_current_files_unchanged'] is True
 c.verify(retry_preservation['intake']);c.verify(retry_preservation['vendored'])
 adoption=c.load('/private/tmp/pathwaymech-next-233-maintained-adoption-20261012.json')
 for row in adoption['written']:c.verify(row)
 assert len(adoption['written'])==97
 before={r['relative_path']:r for r in c.load('/private/tmp/pathwaymech-next-233-native-history-20261012/before.json')['files']}
 final_inputs={r['relative_path']:r for r in c.load(GATES/'input-inventory.json')['files']}
 current={r['relative_path']:r for r in c.inventory(ROOT,exclude_git=True)}
 assert {r['relative_path']:r for r in resume['before']}==current
 plan=c.load(PREP/'stages.json');generated=set(plan['allowed_generated_paths'])
 histories=[]
 for row in correction['new_histories']:
  c.verify(row);p=Path(row['path']);data=yaml.safe_load(p.read_bytes())
  assert data['session']['actors']==[{'type':'ai_agent','name':'codex','model':'gpt-6','agent_tool':'codex'}]
  histories.append(str(p.relative_to(ROOT)))
 assert len(set(histories))==3
 new_generated={'pages/records/MetaCyc_THIOREDOX-PWY.html'}
 assert new_generated<=generated and not(new_generated & set(before))
 assert set(current)-set(before)==set(histories)|new_generated and not(set(before)-set(current))
 changes={name for name in before if before[name]!=current[name]}
 assert changes<=generated|{'output/sssom/source_mappings.sssom.tsv'}
 assert set(final_inputs)==set(current)
 assert all(final_inputs[p]==current[p] for p in current if p not in generated)
 oldreviews={p:r for p,r in before.items() if p.startswith('reviews/structured/')}
 assert {p:r for p,r in current.items() if p.startswith('reviews/structured/')}==oldreviews
 assert sum(p.endswith('/review.yaml') for p in oldreviews)==110
 oldhistory={p:r for p,r in before.items() if p.startswith('history/')}
 assert all(current[p]==r for p,r in oldhistory.items())
 snapshots={}
 for name,digest in (('sources','0363ac60c4048a4729ccf876cd74f0d3a219aed0e5c5f03732366119fba0115d'),('ontology','9338db98d99d724799f3205397e9b26b5e5057d95664a3c229ad5a091969063b')):
  row=c.bind(ROOT/'data/identifier_authorities'/f'{name}.json');assert row['sha256']==digest;snapshots[name]=row
 kgx=[]
 for name,count in (('nodes.tsv',4185),('edges.tsv',11734)):
  expected=ACCEPTED/'actual-kgx'/name
  data=expected.read_bytes()
  assert (ROOT/'output/kgx'/name).read_bytes()==data==(ROOT/'pages/downloads'/name).read_bytes()
  assert len(list(csv.DictReader(io.StringIO(data.decode()),delimiter='\t')))==count
  kgx.append({'expected':c.bind(expected),'actual':c.bind(ROOT/'output/kgx'/name),'download':c.bind(ROOT/'pages/downloads'/name),'rows':count})
 sssom=c.load('/private/tmp/pathwaymech-next-233-sssom-export-finding-20261012/finding.json')
 for name in ('retained_before','retained_expected','expected_actual_test_generated'):c.verify(sssom[name])
 actual=ROOT/'output/sssom/source_mappings.sssom.tsv';assert actual.read_bytes()==Path(sssom['retained_expected']['path']).read_bytes()
 original=Path(sssom['retained_before']['path']).read_bytes().splitlines(keepends=True);new=actual.read_bytes().splitlines(keepends=True);added=[l for l in new if l not in original]
 assert len(added)==3 and [l for l in new if l not in added]==original and all(b'source_pathway_id=MetaCyc:THIOREDOX-PWY;' in l for l in added)
 # Bridge root's actually inspected static SVG to current history-corrected HTML.
 visual=Path('/private/tmp/pathwaymech-next-233-root-visual-qa-20261012')
 rendered=c.load(visual/'render.json');c.verify(rendered['svg']);c.verify(rendered['png'])
 raw=(ROOT/'pages/records/MetaCyc_THIOREDOX-PWY.html').read_text()
 matches=re.findall(r'<svg\b[^>]*class="pathway-network-svg"[\s\S]*?</svg>',raw)
 assert len(matches)==1
 extracted=matches[0]
 original_svg=Path(rendered['svg']['path']).read_text()
 assert original_svg==extracted
 graph={'status':'current_graph_exact_to_root_static_visual_source','actual_page':c.bind(ROOT/'pages/records/MetaCyc_THIOREDOX-PWY.html'),'static_svg':rendered['svg'],'observations':c.bind(visual/'observations.json'),'raw_svg_sha256':hashlib.sha256(extracted.encode()).hexdigest(),'normalization':'None; exact raw SVG bytes equal.','limits':['Root static image observation inherited; this checker did not inspect new images or browser interaction.','Dense edge-label overlap remains the recorded static visual limit.']}
 with (HERE/'graph-bridge.json').open('x') as out:out.write(json.dumps(graph,indent=2)+'\n')
 result={'status':'actual_final_THIO_gates_and_preservation_independently_verified','gates':c.bind(NETWORK/'gate-completion.json'),'correction':c.bind(NETWORK/'history-correction-completion.json'),'actual_checks':gates['commands'],'completion_mode':gates['completion_mode'],'failed_network_gate_retained':gates['failed_network_gate_retained'],'failed_corrective_wrapper_retained':gates['failed_corrective_wrapper_retained'],'network_resume_intake':gates['network_resume_intake'],'network_resume_complete_file_identity_rechecked':True,'all97_adopted_owners_exact':True,'old_native_review_pairs_exact':110,'old_history_files_exact':len(oldhistory),'new_native_Codex_histories':histories,'exact_new_generated_paths':sorted(new_generated),'all_prior_scaffold_input_files_preserved_except_exact_generated_paths_and_SSSOM':True,'actual_changed_existing_paths':sorted(changes),'current_file_count':len(current),'native_snapshots':snapshots,'whole_kgx':kgx,'sssom':{'current':c.bind(actual),'all_old_lines_order_exact':True,'new_THIO_rows':3},'current_graph_bridge':c.bind(HERE/'graph-bridge.json'),'limits':['No native builders, full gates or whole SQL hashing rerun.','Current final gate receipts are actual root execution; no native review save has occurred yet.']}
 # Freeze current bodies through this read-only comparison.
 assert {r['relative_path']:r for r in c.inventory(ROOT,exclude_git=True)}==current
 with (HERE/'final-preservation.json').open('x') as out:out.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'status':result['status'],'files':len(current),'review_pairs':110,'KGX':[4185,11734],'SSSOM_new_rows':3}))
if __name__=='__main__':main()
