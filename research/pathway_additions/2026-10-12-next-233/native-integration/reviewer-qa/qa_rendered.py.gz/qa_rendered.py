"""Read-only complete THIO/DFO rendered graph, table and static geometry QA.

Writes only a new external receipt. No render, native gate, builder or worktree write.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat
import time

from lxml import html
import yaml

HERE=Path(__file__).parent
ROOT=Path('/private/tmp/pathwaymech-next-233-20261012')

def bind(path):
 path=Path(path)
 if not stat.S_ISREG(path.lstat().st_mode):raise ValueError('Regular file required: '+str(path))
 body=path.read_bytes()
 return {'path':str(path),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}

def text(node):return ' '.join(node.text_content().split())
def norm(value):return ' '.join(value.split())
def classes(value):return 'contains(concat(" ",normalize-space(@class)," ")," '+value+' ")'

def evidence_check(nodes,evidence,refs):
 assert len(nodes)==len(evidence)
 for node,e in zip(nodes,evidence):
  links=node.xpath('./a');assert len(links)==1
  assert text(links[0])==e['reference_id'] and links[0].get('href')=='#reference-'+str(refs[e['reference_id']])
  if 'quote' in e:
   q=node.xpath('./blockquote');assert len(q)==1 and text(q[0])==norm(e['quote'])
  if 'source_assertion' in e:
   assertions=node.xpath('./p');assert any(norm(e['source_assertion']) in text(n) for n in assertions)
  if e.get('source_locator'):
   locators=node.xpath('./details/code');assert len(locators)==1 and text(locators[0])==norm(e['source_locator'])

def main():
 started=datetime.now(timezone.utc).isoformat().replace('+00:00','Z');tick=time.monotonic()
 adoption=Path('/private/tmp/pathwaymech-next-233-maintained-adoption-20261012.json')
 adopted=json.loads(adoption.read_bytes())
 assert adopted['status']=='adopted_pending_native_history_render_gates_and_review' and len(adopted['written'])==97
 record_path=ROOT/'data/pathways/thioredoxin-pathway.yaml';page_path=ROOT/'pages/records/MetaCyc_THIOREDOX-PWY.html'
 dfo_path=ROOT/'data/pathways/desferrioxamine-b-biosynthesis.yaml';dfo_page=ROOT/'pages/records/MetaCyc_PWY-6376.html'
 inputs=[bind(p) for p in (record_path,page_path,dfo_path,dfo_page,ROOT/'src/pathwaymech/graph_view.py',Path(__file__),adoption)]
 assert inputs[0]['sha256']=='3b8871de3bab9b88c64d766a79332bb57d96cf95ac0c8dda0226697cef2538cf'
 assert inputs[2]['sha256']=='ab6b7808c564fc2bbddaa1fea159f0927e2ec2f73b9890e7ab360c5e3718a9dd'
 record=yaml.safe_load(record_path.read_bytes());page=html.fromstring(page_path.read_bytes())
 ids=page.xpath('//*[@id]/@id');assert len(ids)==len(set(ids))
 edges=record['mechanistic_edges'];refs={r['id']:i for i,r in enumerate(record['references'],1)}
 assert len(edges)==45 and len(refs)==116
 svg=page.xpath('//svg['+classes('pathway-network-svg')+']');assert len(svg)==1;svg=svg[0]
 graph_edges=svg.xpath('.//a['+classes('graph-edge')+']');assert len(graph_edges)==45
 graph_nodes=svg.xpath('.//a['+classes('graph-node')+']');assert len(graph_nodes)==44
 base={n.get('data-node-id'):n for n in graph_nodes if n.get('data-qualified')!='true'}
 qualified={n.get('data-node-id'):n for n in graph_nodes if n.get('data-qualified')=='true'}
 assert len(base)==40 and len(qualified)==4
 component_rows=page.xpath('//tr[starts-with(@id,"component-")]')
 declared=record['taxa']+record['participants']+record['reactions'];assert len(component_rows)==len(declared)==41
 for row,item in zip(component_rows,declared):
  cells=row.xpath('./td');assert text(cells[0].xpath('./code')[0])==item['id']
  assert norm(item['label']) in text(cells[0])
  assert text(cells[2])==item.get('direction','').replace('_',' ')
 assert text(page.get_element_by_id('pathway-identity'))==record['id']
 assert len({record['id']}|{r['id'] for r in declared})==42
 endpoints={e[role] for e in edges for role in ('subject','object')}
 expected_base={r['id'] for r in record['participants']+record['reactions']}|{r['id'] for r in record['taxa'] if r['id'] in endpoints}|({record['id']} if record['id'] in endpoints else set())
 assert set(base)==expected_base
 edge_results=[];qualifier_results=[]
 for i,(edge,drawn) in enumerate(zip(edges,graph_edges),1):
  anchor='mechanism-edge-'+str(i);assert drawn.get('href')=='#'+anchor
  row=page.get_element_by_id(anchor);cells=row.xpath('./td');assert len(cells)==4
  assert text(cells[0].xpath('./code')[0])==edge['subject']
  assert text(cells[2].xpath('./code')[0])==edge['object']
  assert norm(cells[1].text or '')==edge['predicate']
  assert text(cells[1].xpath('./p')[0])==norm(edge['description'])
  evidence_check(cells[3].xpath('./ul/li'),edge['evidence'],refs)
  qs={q['endpoint']:q for q in edge.get('endpoint_qualifiers',[])}
  for role in ('subject','object'):
   expected='qualified-endpoint-'+str(i)+'-'+role if role in qs else edge[role]
   assert drawn.get('data-'+role)==expected
   if qs:assert drawn.get('data-'+role+'-id')==edge[role]
   if role in qs:
    q=qs[role];qanchor=anchor+'-qualifier-'+role
    node=qualified[expected];assert node.get('data-base-node-id')==edge[role] and node.get('href')=='#'+qanchor
    detail=node.get('aria-label');assert norm(q['description']) in norm(detail)
    tableq=page.get_element_by_id(qanchor)
    assert norm(q['description']) in text(tableq.xpath('./p')[0])
    evidence_check(tableq.xpath('./details/ul/li'),q['evidence'],refs)
    qualifier_results.append({'edge':edge['id'],'endpoint':role,'kind':q['kind'],'table_anchor':qanchor,'base_id':edge[role],'display_id':expected})
  assert drawn.get('data-predicate')==edge['predicate']
  assert edge['subject'] in drawn.get('aria-label') and edge['object'] in drawn.get('aria-label')
  assert len(drawn.xpath('./path[@marker-end]'))==1
  edge_results.append({'edge':edge['id'],'subject':edge['subject'],'predicate':edge['predicate'],'object':edge['object'],'evidence_count':len(edge['evidence']),'table_anchor':anchor})
 assert len(qualifier_results)==4
 for node in graph_nodes:assert node.get('href','')[1:] in ids
 for i,ref in enumerate(record['references'],1):
  row=page.get_element_by_id('reference-'+str(i));link=row.xpath('./code/a');assert len(link)==1
  assert text(link[0])==ref['id'] and link[0].get('href')==ref['url']
  assert norm(ref['title']) in text(row) and norm(ref['source_version']) in text(row)
 assert len(page.xpath('//li[starts-with(@id,"reference-")]'))==116
 # Assert the source projections explicitly; do not infer a third biological event.
 assert {e['object'] for e in edges[:3]}=={'MetaCyc:THIOREDOXIN-REDUCT-NADPH-RXN'}
 assert [e['predicate'] for e in edges[:9]]==['consumes']*3+['produces']*2+['consumes']*2+['produces']*2
 assert all(r['direction']=='right_to_left' for r in record['reactions'])
 dfo=yaml.safe_load(dfo_path.read_bytes());dfopage=html.fromstring(dfo_page.read_bytes())
 dfo_labels=[]
 for ix in (14,19):
  item=dfo['participants'][ix]
  rows=dfopage.xpath('//tr[starts-with(@id,"component-")]')
  found=[row for row in rows if row.xpath('./td[1]/code') and text(row.xpath('./td[1]/code')[0])==item['id']]
  assert len(found)==1 and norm(item['label']) in text(found[0])
  nodes=dfopage.xpath('//a[@data-node-id=$id]',id=item['id']);assert len(nodes)==1
  assert nodes[0].get('data-node-label')==item['label']
  dfo_labels.append({'id':item['id'],'label':item['label'],'table_and_graph_exact':True})
 geometry={'viewbox':[0,0,float(svg.get('width')),float(svg.get('height'))], 'scope':'Font measurement not executed: root actual-CSS static image disproved clipping. See separately bound root visual observations for dense-label limitation; no browser interaction.'}
 for row in inputs:assert bind(row['path'])==row
 result={'status':'all_rendered_graph_table_checks_passed','started_at':started,
         'finished_at':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),'seconds':time.monotonic()-tick,
         'inputs':inputs,'edges':edge_results,'qualifiers':qualifier_results,'references':116,'named_identities':42,
         'component_rows':41,'base_graph_nodes':40,'qualified_display_instances':4,'total_display_nodes':44,
         'native_events':2,'native_side_occurrences':9,'rhea_same_event_projection_sides':5,
         'DFO_labels':dfo_labels,'geometry':geometry,
         'limits':['No browser interaction performed.','No font measurements were executed; root static-image observations are separately bound.','This is rendered-source QA; final full-gate receipts and KGX comparison remain separate.']}
 with (HERE/'rendered-qa.json').open('x') as out:out.write(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('edges','qualifiers','geometry','inputs')},indent=2))

if __name__=='__main__':main()
