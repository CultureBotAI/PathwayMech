"""Execute sealed native history/gate commands and retain actual evidence."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

PREP = Path('/private/tmp/pathwaymech-next-233-maintained-integration-successor-20261012')
sys.path.insert(0, str(PREP))
from common import ROOT, bind, dump, inventory, load, now, verify

STAGES = PREP/'stages.json'
assert bind(STAGES)['sha256'] == '4551b41a318f447b2a40df018226bb425be3dc0f77eb8b98d4b644015c79e2c0'
PLAN = load(STAGES)
ENV = {**os.environ, **PLAN['environment']}

def snapshot():
    return {row['relative_path']: row for row in inventory(ROOT, exclude_git=True)}

def execute(directory, name, argv):
    directory.mkdir(parents=True, exist_ok=True)
    record = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'environment_overrides': PLAN['environment'], 'started_at': now(), 'stages': bind(STAGES), 'wrapper': bind(Path(__file__))}
    dump(directory/(name+'.started.json'), record)
    start = time.monotonic()
    out, err = directory/(name+'.stdout'), directory/(name+'.stderr')
    with out.open('xb') as stdout, err.open('xb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr, check=False)
    record.update(finished_at=now(), seconds=time.monotonic()-start, exit_code=result.returncode, stdout=bind(out), stderr=bind(err))
    dump(directory/(name+'.execution.json'), record)
    print(json.dumps({'name':name, 'exit_code': result.returncode, 'seconds':record['seconds'], 'receipt':str(directory/(name+'.execution.json'))}), flush=True)
    if result.returncode:
        raise RuntimeError(f'{name} failed; retained actual command and both streams')
    return record

def preserve(before, after, allowed):
    removed = sorted(set(before)-set(after))
    changed = sorted(p for p in set(before)&set(after) if before[p]!=after[p] and p not in allowed)
    extra = sorted(set(after)-set(before)-set(allowed))
    if removed or changed or extra:
        raise ValueError({'removed':removed, 'unexpected_changed':changed, 'unexpected_added':extra})

def adoption_check():
    receipt = load('/private/tmp/pathwaymech-next-233-maintained-adoption-20261012.json')
    assert receipt['status']=='adopted_pending_native_history_render_gates_and_review'
    assert receipt['handoff']==bind(PREP/'handoff.json')
    for row in receipt['written']:
        verify(row)
    return receipt

def histories():
    adoption_check()
    directory=Path('/private/tmp/pathwaymech-next-233-native-history-20261012')
    directory.mkdir()
    before=snapshot()
    dump(directory/'before.json', {'files':list(before.values())})
    old_history={p:r for p,r in before.items() if p.startswith('history/')}
    outputs=[]
    for i,argv in enumerate(PLAN['history_commands']):
        execution=execute(directory, f'history-{i+1}', argv)
        path=Path(Path(execution['stdout']['path']).read_text().splitlines()[-1])
        path=path if path.is_absolute() else ROOT/path
        relative=str(path.relative_to(ROOT))
        expected_dir=['history/records/thioredoxin-pathway/', 'history/records/desferrioxamine-b-biosynthesis/', 'history/infrastructure/thioredoxin-carrier-authority/'][i]
        assert relative.startswith(expected_dir) and relative.endswith('.yaml')
        assert relative not in before
        outputs.append(relative)
        current=snapshot()
        preserve(before, current, outputs)
        assert {p:r for p,r in current.items() if p in old_history} == old_history
    assert len(set(outputs))==3
    dump(directory/'completion.json', {'status':'three_native_histories_created_before_first_render','at':now(),'new_history':[bind(ROOT/p) for p in outputs],'old_history_unchanged':True,'all_other_inputs_unchanged':True,'before':bind(directory/'before.json')})

def fetch():
    directory=Path('/private/tmp/pathwaymech-next-233-review-revisions-20261012')
    directory.mkdir()
    execute(directory,'fetch-review-revisions',PLAN['historical_review_preparation'])

def gates():
    adoption_check()
    history=load('/private/tmp/pathwaymech-next-233-native-history-20261012/completion.json')
    for row in history['new_history']:
        verify(row)
    assert load('/private/tmp/pathwaymech-next-233-review-revisions-20261012/fetch-review-revisions.execution.json')['exit_code']==0
    directory=Path(PLAN['proposed_new_gate_output'])
    directory.mkdir()
    before=snapshot()
    dump(directory/'input-inventory.json',{'at':now(),'files':list(before.values()),'hidden_ignored_included':True,'excluded':['.git']})
    old_history={p:r for p,r in before.items() if p.startswith('history/')}
    executions=[]
    for gate in PLAN['gates']:
        current=snapshot()
        preserve(before,current,PLAN['allowed_generated_paths'])
        assert {p:r for p,r in current.items() if p.startswith('history/')}==old_history
        executions.append(execute(directory,gate['name'],gate['argv']))
        current=snapshot()
        preserve(before,current,PLAN['allowed_generated_paths'])
        assert {p:r for p,r in current.items() if p.startswith('history/')}==old_history
    dump(directory/'completion.json',{'status':'all_nine_maintained_gates_passed','at':now(),'commands':executions,'input_inventory':bind(directory/'input-inventory.json'),'history_before_render_and_unchanged':True,'only_allowed_generated_changes':True,'final_generated':[bind(ROOT/p) for p in PLAN['allowed_generated_paths']]})

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['history','fetch','gates'])
    args=parser.parse_args()
    {'history':histories,'fetch':fetch,'gates':gates}[args.stage]()
