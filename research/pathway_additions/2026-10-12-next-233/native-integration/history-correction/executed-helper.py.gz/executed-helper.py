"""Replace only three provisional histories, then recheck changed history/pages."""
import importlib.util
import json
from pathlib import Path
import subprocess
import yaml

SPEC = importlib.util.spec_from_file_location('stages', '/private/tmp/pathwaymech-next-233-maintained-stages-20261012.py')
ST = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ST)
ROOT = ST.ROOT
OUT = Path('/private/tmp/pathwaymech-next-233-history-actor-correction-20261012')
GATES = Path('/private/tmp/pathwaymech-next-233-maintained-final-gates-20261012')
FINDING = Path('/private/tmp/pathwaymech-next-233-history-actor-finding-20261012/finding.json')

def main():
    previous_directory = Path('/private/tmp/pathwaymech-next-233-maintained-gates-20261012')
    previous = ST.load(previous_directory/'tests.execution.json')
    assert previous['exit_code'] == 1
    for name in ['render', 'skills', 'validate']:
        assert ST.load(previous_directory/(name+'.execution.json'))['exit_code'] == 0
    test_summary = Path(previous['stdout']['path']).read_text()
    assert '1 failed, 3209 passed, 3 skipped' in test_summary
    assert 'FAILED tests/test_sssom_export.py::test_committed_sssom_output_is_current' in test_summary
    sssom_path = ROOT/'output/sssom/source_mappings.sssom.tsv'
    expected_sssom = (previous_directory/'pytest-temp/test_committed_sssom_output_is0/source_mappings.sssom.tsv').read_bytes()
    old_sssom = sssom_path.read_bytes()
    finding = ST.load(FINDING)
    originals = finding['originals']
    assert len(originals) == 3
    for row in originals:
        ST.verify(row['original'])
        ST.verify(row['copy'])
        rel = str(Path(row['original']['path']).relative_to(ROOT))
        result = subprocess.run(['git', 'ls-files', '--error-unmatch', '--', rel], cwd=ROOT, capture_output=True)
        assert result.returncode == 1
    OUT.mkdir()
    GATES.mkdir()
    before = ST.snapshot()
    ST.dump(OUT/'before.json', {'files':list(before.values())})
    commands = []
    new_paths = []
    note = (' Corrective provenance scaffold: the actual actor is Codex. The earlier uncommitted scaffold used the CLI default claude-code; its complete bytes and execution receipt are preserved in integration evidence. Initial rendering and validation passed, but the first full test suite found a stale SSSOM export. Export regeneration and final maintained checks remain pending at this event.')
    for i, original in enumerate(ST.PLAN['history_commands']):
        argv = list(original)
        assert '--actor-name' not in argv
        argv[argv.index('--details')+1] += note
        argv += ['--actor-name', 'codex', '--issue', '495']
        result = ST.execute(OUT, f'corrected-history-{i+1}', argv)
        path = Path(Path(result['stdout']['path']).read_text().splitlines()[-1])
        path = path if path.is_absolute() else ROOT/path
        old_path = Path(originals[i]['original']['path'])
        assert path.parent == old_path.parent and path != old_path
        assert '-codex-' in path.name
        document = yaml.safe_load(path.read_bytes())
        assert document['session']['actors'] == [{'type':'ai_agent','name':'codex','model':'gpt-6','agent_tool':'codex'}]
        new_paths.append(str(path.relative_to(ROOT)))
        commands.append(result)
        ST.preserve(before, ST.snapshot(), new_paths)
    assert len(set(new_paths)) == 3
    # Remove only the byte-verified, untracked originals after all replacements exist.
    removed = []
    for row in originals:
        ST.verify(row['original'])
        ST.verify(row['copy'])
        path = Path(row['original']['path'])
        removed.append(str(path.relative_to(ROOT)))
        path.unlink()
    expected = {p:r for p,r in before.items() if p not in removed}
    after = ST.snapshot()
    ST.preserve(expected, after, new_paths)
    ST.dump(OUT/'correction-before-render.json', {'status':'three_provisional_histories_replaced_before_corrective_render','at':ST.now(),'finding':ST.bind(FINDING),'helper':ST.bind(Path(__file__)),'old_histories_retained':originals,'removed_untracked_paths':removed,'new_histories':[ST.bind(ROOT/p) for p in new_paths],'all_other_files_unchanged':True,'previous_failed_full_suite':ST.bind(previous_directory/'tests.execution.json'),'commands':commands})
    export = ST.execute(OUT, 'sssom-export', [ST.PLAN['history_commands'][0][0], '-B', '-c', 'from pathwaymech.cli import export_sssom_main; raise SystemExit(export_sssom_main())'])
    assert sssom_path.read_bytes() == expected_sssom
    old_lines = old_sssom.splitlines(keepends=True)
    new_lines = expected_sssom.splitlines(keepends=True)
    added = [line for line in new_lines if line not in old_lines]
    assert len(added) == 3 and all(b'source_pathway_id=MetaCyc:THIOREDOX-PWY;' in line for line in added)
    assert [line for line in new_lines if line not in added] == old_lines
    ST.preserve(after, ST.snapshot(), ['output/sssom/source_mappings.sssom.tsv'])
    ST.dump(OUT/'sssom-regeneration.json', {'status':'native_export_matches_actual_failed_test_expectation','at':ST.now(),'execution':export,'output':ST.bind(sssom_path),'old_rows_and_order_unchanged':True,'exact_new_THIO_rows':3})
    final_inputs = ST.snapshot()
    ST.dump(GATES/'input-inventory.json', {'at':ST.now(),'files':list(final_inputs.values()),'hidden_ignored_included':True,'excluded':['.git']})
    final_history = {p:r for p,r in final_inputs.items() if p.startswith('history/')}
    history_check = ST.execute(OUT, 'history-validation', [ST.PLAN['history_commands'][0][0], '-B', 'scripts/validate_history.py', 'history'])
    corrective_checks = []
    for gate in ST.PLAN['gates']:
        argv = list(gate['argv'])
        if gate['name'] == 'tests':
            argv[argv.index('--basetemp')+1] = str(GATES/'pytest-temp')
        corrective_checks.append((gate['name'], argv))
    results = []
    for name,argv in corrective_checks:
        observed = ST.snapshot()
        ST.preserve(final_inputs, observed, ST.PLAN['allowed_generated_paths'])
        assert {p:r for p,r in observed.items() if p.startswith('history/')} == final_history
        results.append(ST.execute(GATES, name, argv))
        observed = ST.snapshot()
        ST.preserve(final_inputs, observed, ST.PLAN['allowed_generated_paths'])
        assert {p:r for p,r in observed.items() if p.startswith('history/')} == final_history
    ST.dump(GATES/'completion.json', {'status':'all_nine_maintained_gates_passed','at':ST.now(),'commands':results,'input_inventory':ST.bind(GATES/'input-inventory.json'),'history_before_corrective_render_and_unchanged':True,'only_allowed_generated_changes':True,'sssom_regeneration':ST.bind(OUT/'sssom-regeneration.json'),'initial_failed_suite_retained':ST.bind(previous_directory/'tests.execution.json')})
    ST.dump(OUT/'completion.json', {'status':'history_actor_corrected_and_all_final_gates_passed','at':ST.now(),'correction_before_render':ST.bind(OUT/'correction-before-render.json'),'history_validation':history_check,'final_gates':ST.bind(GATES/'completion.json'),'new_histories':[ST.bind(ROOT/p) for p in new_paths],'previous_full_gate_inputs_preserved_except_documented_history_SSSOM_and_generated_pages':True,'runtime_records_authorities_unchanged':True,'old_committed_histories_unchanged':True,'full_tests_repeated_after_export_fix':True,'issue':495})

if __name__=='__main__':
    main()
