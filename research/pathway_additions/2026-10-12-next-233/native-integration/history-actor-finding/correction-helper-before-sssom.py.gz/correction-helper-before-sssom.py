"""Replace only three provisional histories, then recheck changed history/pages."""
import importlib.util
import json
from pathlib import Path
import subprocess
import yaml

SPEC = importlib.util.spec_from_file_location('stages', '/private/tmp/pathwaymech-next-233-maintained-stages-20261012.py')
ST = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ST)
ROOT = ST.ROOT
OUT = Path('/private/tmp/pathwaymech-next-233-history-actor-correction-20261012')
FINDING = Path('/private/tmp/pathwaymech-next-233-history-actor-finding-20261012/finding.json')

def main():
    previous = ST.load('/private/tmp/pathwaymech-next-233-maintained-gates-20261012/completion.json')
    assert previous['status'] == 'all_nine_maintained_gates_passed'
    finding = ST.load(FINDING)
    originals = finding['originals']
    assert len(originals) == 3
    for row in originals:
        ST.verify(row['original'])
        ST.verify(row['copy'])
        rel = str(Path(row['original']['path']).relative_to(ROOT))
        result = subprocess.run(['git', 'ls-files', '--error-unmatch', '--', rel], cwd=ROOT, capture_output=True)
        assert result.returncode == 1
    OUT.mkdir()
    before = ST.snapshot()
    ST.dump(OUT/'before.json', {'files':list(before.values())})
    commands = []
    new_paths = []
    note = (' Corrective provenance scaffold: the actual actor is Codex. The earlier uncommitted scaffold used the CLI default claude-code; its complete bytes and execution receipt are preserved in integration evidence. Initial maintained gates passed before this corrected history; final history and page checks remain pending at this event.')
    for i, original in enumerate(ST.PLAN['history_commands']):
        argv = list(original)
        assert '--actor-name' not in argv
        argv[argv.index('--details')+1] += note
        argv += ['--actor-name', 'codex', '--issue', '495']
        result = ST.execute(OUT, f'corrected-history-{i+1}', argv)
        path = Path(Path(result['stdout']['path']).read_text().splitlines()[-1])
        path = path if path.is_absolute() else ROOT/path
        old_path = Path(originals[i]['original']['path'])
        assert path.parent == old_path.parent and path != old_path
        assert '-codex-' in path.name
        document = yaml.safe_load(path.read_bytes())
        assert document['session']['actors'] == [{'type':'ai_agent','name':'codex','model':'gpt-6','agent_tool':'codex'}]
        new_paths.append(str(path.relative_to(ROOT)))
        commands.append(result)
        ST.preserve(before, ST.snapshot(), new_paths)
    assert len(set(new_paths)) == 3
    # Remove only the byte-verified, untracked originals after all replacements exist.
    removed = []
    for row in originals:
        ST.verify(row['original'])
        ST.verify(row['copy'])
        path = Path(row['original']['path'])
        removed.append(str(path.relative_to(ROOT)))
        path.unlink()
    expected = {p:r for p,r in before.items() if p not in removed}
    after = ST.snapshot()
    ST.preserve(expected, after, new_paths)
    ST.dump(OUT/'correction-before-render.json', {'status':'three_provisional_histories_replaced_before_corrective_render','at':ST.now(),'finding':ST.bind(FINDING),'old_histories_retained':originals,'removed_untracked_paths':removed,'new_histories':[ST.bind(ROOT/p) for p in new_paths],'all_other_files_unchanged':True,'previous_gates':ST.bind('/private/tmp/pathwaymech-next-233-maintained-gates-20261012/completion.json'),'commands':commands})
    final_inputs = ST.snapshot()
    final_history = {p:r for p,r in final_inputs.items() if p.startswith('history/')}
    corrective_checks = [
        ('history-validation', [ST.PLAN['history_commands'][0][0], '-B', 'scripts/validate_history.py', 'history']),
        ('render', ST.PLAN['gates'][0]['argv']),
        ('site-current', ST.PLAN['gates'][-1]['argv']),
        ('diff-check', ['git', 'diff', '--check']),
    ]
    results = []
    for name,argv in corrective_checks:
        results.append(ST.execute(OUT, name, argv))
        observed = ST.snapshot()
        ST.preserve(final_inputs, observed, ST.PLAN['allowed_generated_paths'])
        assert {p:r for p,r in observed.items() if p.startswith('history/')} == final_history
    ST.dump(OUT/'completion.json', {'status':'history_actor_corrected_and_affected_checks_passed','at':ST.now(),'correction_before_render':ST.bind(OUT/'correction-before-render.json'),'checks':results,'new_histories':[ST.bind(ROOT/p) for p in new_paths],'previous_full_gate_inputs_preserved_except_documented_history_and_generated_pages':True,'runtime_records_authorities_unchanged':True,'old_committed_histories_unchanged':True,'full_tests_not_repeated':'Only provisional provenance changed; prior exact runtime/data test results retained, all current history and generated pages revalidated. CI will test the final commit.','issue':495})

if __name__=='__main__':
    main()
