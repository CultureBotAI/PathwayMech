Issue key: `next265-archive-index-coverage`

Independent finding `NEXT265-ARCHIVE-INDEX-COVERAGE-002` identified 39 evidence logs physically present in the next265 research report but absent from the publication index because `.gitignore:19` ignores `*.log`. The check enumerated every regular report file, including hidden and ignored files, and compared it with the actual index. Fifteen missing logs belong to the two archival packages initially covered by issue #584; the other 24 belong to browser, final-gate, final-documentation and technical-review packages.

The original seven-path storage proposal reconstructed all 416 original package files and all 370 compact logical rows, but its complete physical-view whitespace rehearsal exposed an additional failure: `final-scientific-review/observed-gates-initial/just-test.log:181` contains two trailing spaces. Publishing only the current index would omit declared evidence; simply forcing all logs into the index would expose this whitespace failure. The original proposal was not adopted and is not accepted for publication.

Acceptance:

- Preserve the original proposal, failed verifier, all source bytes, and saved scientific/technical reviews as historical observations.
- Create a separate lossless storage successor for all 39 ignored logs and the seven paths from #584, preserving all six affected packages' original manifests and reconstructing every original file.
- Verify complete compact logical reconstructions, including any existing gzip decoding layers.
- Independently verify the correction and actual adoption.
- Compare every current declared physical inventory with the actual staged index, including object bytes, before publishing; pass the actual staged whitespace check.
- Do not relax ignore, whitespace or lint policies, or normalize evidence text.

The independent finding receipt is `ignored-archive-index-coverage.json`, SHA256 `4e7dd7159667054e04185c76db45af38650a9ab1a75eedff8c560b1addb60c72`. This is a publication evidence-retention defect, not a change to pathway science.
