# Next265 complete seven-step chemistry preparation

This is source-author chemistry and design evidence for **MetaCyc:PWY-1361, benzoyl-CoA degradation I (aerobic)**. It is not a canonical record review, independent acceptance of these newly authored mappings, or permission to publish. No maintained file, Git/GitHub object, frozen input package, or runtime environment was changed. The complete named seven-step route is preserved; upstream benzoate-CoA ligase is outside its native boundary.

The native pathway and all seven full reaction originals were read, including every written material, coefficient, reaction direction, pathway layout direction, orphan flag and activity backlink. Native chemical reading covered all complete structures, formula/charge and identity fields; large reverse-reaction lists in chemical objects are retained but are not claimed as separately curated biological evidence. Frozen discovery inputs were rebound to manifest `9f6fa8bc33e2b685967fdb16ced8ed1eece5aeb3b2d7c11893948a1e9d2e739d` in `discovery-final-selected-input-rebind.json`.

## Exact chemistry result

`chemical-identity-closure.json` verifies **18 exact charged structures** against complete native CML, full native InChI/key, complete live ChEBI API originals and all selected outgoing statements from the pinned ChEBI255 database. CML connectivity/formula/charge checks are separate from full InChI stereochemical checks. RDKit2026.03.5 used the existing package's `RDBASE` data path; no installation or environment mutation occurred.

| Native chemical | Selected exact identity |
|---|---|
| BENZOYLCOA | CHEBI:57369 |
| CYCLOHEX-13-DIENE-56-DIHYDROXY-1-CARBO | CHEBI:88118 |
| CPD-12012 | CHEBI:58787 |
| CIS-34-DEHYDROADIPYL-COA | CHEBI:58786 |
| TRANS-23-DEHYDROADIPYL-COA | CHEBI:195329 |
| 3-HYDROXYADIPYL-COA | CHEBI:132183 |
| 3-KETO-ADIPYL-COA | CHEBI:57348 |
| ACETYL-COA | CHEBI:57288 |
| SUC-COA | CHEBI:57292 |
| CO-A | CHEBI:57287 |
| FORMATE | CHEBI:15740 |
| NADP / NADPH | CHEBI:58349 / CHEBI:57783 |
| NAD / NADH | CHEBI:57540 / CHEBI:57945 |
| WATER / PROTON / OXYGEN-MOLECULE | CHEBI:15377 / CHEBI:15378 / CHEBI:15379 |

The historical epoxide frame spelling is not its current chemistry: its complete native structure is the epoxide, not a dihydrodiol. Both ring-carbon stereocenters remain unspecified. The 2011 primary structure-based prediction of a 2S,3R product must not silently replace this unspecified exact identity.

**Native crosslink limitation:** TRANS-23-DEHYDROADIPYL-COA links to CHEBI:71044, whose complete issuing structure lacks the native E double-bond configuration. Native full InChI has `/b6-4+`, key `ZFXICKRXPZTFPB-KCQRSJHASA-I`; broader71044 has no `/b` layer and key `ZFXICKRXPZTFPB-BIEWRJSYSA-I`. Exact full-structure search found **CHEBI:195329**, confirmed by its live original, pinned SQL, full InChI/key, formula/charge and issuer `is a` relation to71044. Its issuing MetaCyc crosslink names the same native frame. `exact-trans-structure-sql-search.json` and `chemical-identity-closure.json` retain the evidence. Broader71044 is a comparison source, not a selected exact node. This is a native-source limitation, not a defect in a nonexistent maintained265 record.

Seven native SMILES fields are incomplete/unparseable generic representations. Pinned ChEBI SMILES for the cis acid and cis semialdehyde do not reproduce their complete declared InChI. These limits are individually retained. Full native/API/SQL InChI and keys agree for the selected identities; all CML and issuing SMILES connectivity/charges agree. Standard InChI reconstruction can choose a different explicit mobile-hydrogen microstate and is not atom-position evidence. Formal charge normalization is not a claim about assay speciation.

## Complete reaction mapping and balance

`whole-route-chemistry-replay.json` independently reconstructs every native side and compares complete material multisets against the issuing Rhea142 RDF. The six selected families have **24 members**, all approved and chemically balanced in the source. Exact selected-side structures, coefficients, formulae and charges agree. All24 issuing RDF labels also agree with separately bound pinned Rhea139 SQL rows; the two versions are not conflated.

| Step | Native reaction | Path traversal | Proposed exact reaction identity |
|---|---|---|---|
| 1 | RXN-2401 | L2R | RHEA:48313, family48312, left-to-right |
| 2 | RXN-11054 | L2R | RHEA:48309, family48308, left-to-right |
| 3 | RXN-11053 | L2R | RHEA:25392, family25391, left-to-right |
| 4 | RXN-2424 | L2R | Retain MetaCyc:RXN-2424; native YES-PUTATIVE, no assigned catalyst |
| 5 | RXN-2425 | R2L | RHEA:76649, family76647, right-to-left hydration |
| 6 | RXN0-2044 | L2R | RHEA:34852, family34851, left-to-right |
| 7 | RXN-3641 | R2L | RHEA:19483, family19481, right-to-left thiolysis |

Rhea directional family labels describe source-side conventions; the displayed directional equations already run from selected substrate to product. Neither label nor approved/balanced status establishes physiological irreversibility. Native old links25383,25390,34863 are absent from the retained direction table; exact mapping above does not assert their retirement or official replacement.

The comparison parsed all326097 original RDF Description elements and found37222 directional equations. It compared **37068 complete fixed equations** and excluded **154 whole equations** containing unresolved symbolic material. Base `contains` is membership, not a numeric coefficient; any missing/nonunique coefficient or unresolved material also rejects the entire equation. Eight finite parser probes passed. No numeric fragment of a symbolic equation was compared. No exact isomerase match was found in that defined fixed population; no universal reaction absence or polymer-equivalence claim follows.

All **seven equations,32 material-side entries,18 unique materials and six primary joins** pass native elemental/charge bookkeeping. BoxC consumes two waters; BoxD produces two protons. NADP/NADPH cancel between the selected epoxidase and BoxD equations. The formal route sum is:

`benzoyl-CoA(4−) + O2 + 3 H2O + NAD(1−) + CoA(4−) → formate + succinyl-CoA(5−) + acetyl-CoA(4−) + NADH(2−) + 3 H+`

Both sides total C70H100N21O52P8S2, charge−9. This is bookkeeping of the chosen native equations, not a newly observed elementary reaction, measured flux, or proof that all lower enzymes have been characterized.

## Primary evidence and design boundaries

The separately frozen source-author primary package is `/private/tmp/pathwaymech-next-265-chemistry-primary`, manifest `89f927aaa67e3d1f13b5f62c7c9967be4df67e9ab63cc079238062ecea891aad`. Its author read five complete main papers (PMID20452977,16585753,21632537,12399500,21495107),27 main figures and all main tables, and produced36 bounded claims covering all seven steps. `primary-author-package-binding.json` verifies its281 artifacts and140 lossless pairs; selected ledgers are copied under `context/primary-*`. This is coordination and byte integrity, **not independent scientific acceptance of the child's interpretations**. Original bodies/figures remain in that package and require independent acceptance before final curation.

The proposed design must distinguish direct upper-module evidence from the native lower route:

- The 2010 isotope/MS/trapping correction supports epoxide chemistry; older dihydrodiol interpretations are superseded. A proposed oxepin tautomer is not an observed obligatory extra step.
- A. evansii BoxD native-substrate/NMR evidence and tagged preparations are separate from LB400 ALDHC surrogate propionaldehyde assays and paralog identities. NADP specificity must not be transferred to the different lower NAD-dependent reaction.
- RXN-2424 remains native YES-PUTATIVE with incomplete EC5.3.3 and no activity link. Retain it explicitly with uncertainty; do not invent a catalyst or omit it to simplify the route.
- The lower sequence remains incompletely characterized in the reviewed main papers. Hypothesized lower activities, similarity-based ORF14 assignment and possible lactone/preparation artifacts are not purified step-specific enzyme evidence.
- Native lower activity backlinks and PMID20660314 concern adjacent phenylacetate preparations as well. Exact chemical equivalence does not establish an A. evansii, LB400, or Geobacillus protein's pathway role. All15 activity/protein/gene/taxon links still require their own bounded biological closure.
- PMID11306574,15916608 and18462753 remain explicitly abstract-only in this primary package; attempted complete-source retrieval failures are retained. Supplement pages were not full supplements. Access failure is not negative biological evidence.

The complete original 2001 reinvestigation and 2012 regulation article are retained by the primary author but outside its full chemistry reading scope. They are follow-up biological evidence, not automatically accepted regulatory edges. Record authoring remains contingent on root's actual merged-baseline rebind, biological/preparation closure and independent full-record scientific review.

## Reproduction and retention

All exact selected native originals,19 live ChEBI bodies (18 selected plus broader comparator), complete selected SQL subject rows, source retrieval receipts and finite checks are retained. Rhea142 full RDF remains as `originals/rhea.rdf.gz`, SHA256 `8ee48d7044cf3eef1001fa730dae2a491902ab25b259b519d6826796bb8acedf`. Its complete selected closure has84 URIs and119 original Description elements. The full RDF and multi-GB SQL databases are external originals with explicit hashes; compact retention contains complete selected source closures, not a substitute claim to retain the entire databases in the repository.

Inert `.py.txt` helpers retain the executed code. `attempts/native-crosslink-only-comparison` preserves the initial unaccepted71044 signatures. `attempts/rdkit-phosphorus-stereocenter-count` preserves an overly broad initial count assertion: RDKit also enumerates unspecified phosphorus centers, so the successful successor explicitly counts epoxide carbon centers. The original sandbox DNS failure and successful public network retry are both retained. These are disclosed author-work observations, not invented canonical review predecessors.

The compact manifest records original and stored hashes and lossless decoding; the artifact manifest covers every owned file except itself. Future corrections must use separate successor packages. The final handoff does not claim all pathways or sources are exhausted, scientific self-approval, or a postmerge absence result.
