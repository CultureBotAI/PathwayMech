# Next265 discovery: complete aerobic benzoyl-CoA pathway

Recommend **MetaCyc:PWY-1361, benzoyl-CoA degradation I (aerobic)** for the next complete source-preparation and independent design review. This is a source-author discovery handoff, not an authored pathway record, independent scientific review, or permission to publish. No maintained file, Git state or GitHub object was changed.

The exact native boundary contains **seven transformations, 32 material-side entries, 18 distinct material frames and six primary joins**, from benzoyl-CoA to succinyl-CoA plus acetyl-CoA. Preserve the complete route, including its less-characterized lower steps. The upstream benzoate-CoA ligase is outside PWY-1361; the characterized BoxAB/BoxC/BoxD upper module is not an acceptable substitute for the full named pathway.

## Source-native route and evidence limits

The complete MetaCyc PGDB 27.0 pathway original is `originals/META-PWY-1361.xml`, SHA256 `a53f7489463f12d016873a3bb987f5d9d037178d7a01bc6d063fcc84c1f2d013`, 18,211 bytes. Exact issuing URLs, timestamps and returned-byte hashes are in the acquisition receipts. The native parent class has exactly three direct members in this retrieved object: PWY-1361, CENTBENZCOA-PWY and P321-PWY. This is a bounded class follow-up, not a claim about all microbial pathways.

| Step | Native reaction | Path direction | Main transformation and required limit |
|---|---|---|---|
| 1 | RXN-2401 | L2R | Benzoyl-CoA epoxidation; apply the 2010 epoxide correction and distinguish BoxA artificial reductase assays from complete BoxAB catalysis. |
| 2 | RXN-11054 | L2R | Epoxide opening with two waters to the semialdehyde and formate. Older dihydrodiol interpretation is superseded. |
| 3 | RXN-11053 | L2R | NADP-dependent semialdehyde oxidation to cis-3,4-dehydroadipyl-CoA; exact native/recombinant BoxD preparation must be retained. |
| 4 | RXN-2424 | L2R | cis-3,4 to trans-2,3 isomerization; native `orphan` is **YES-PUTATIVE**, EC is incomplete, no activity link or Rhea/KEGG xref occurs in the complete reaction object. Do not fabricate an enzyme. |
| 5 | RXN-2425 | R2L | Hydration toward (3S)-hydroxyadipyl-CoA; source reaction is reversible dehydration, so pathway traversal reverses its written sides. |
| 6 | RXN0-2044 | L2R | Hydroxyadipyl-CoA oxidation; reversible native reaction, with direct PMID:20660314 citation concerning adjacent phenylacetate chemistry. |
| 7 | RXN-3641 | R2L | Thiolysis to succinyl-CoA and acetyl-CoA; reverse of the source's written formation reaction, and shared with existing records. |

`candidate-family-and-connectivity.json` binds every coefficient, source side, pathway side and join. `seven-family-evidence-and-gap-dispositions.json` adds all seven native orphan/EC/publication/activity dispositions. The complete source objects contain **15 activity backlinks** across six reactions; these are leads, not automatic proof that each linked enzyme acts in every Box-pathway organism. In particular, lower linked enzymes include adjacent phenylacetate preparations. All activity/protein/gene/cofactor/taxon context still needs complete source closure.

`native-final-complete-projections.json` preserves all **258 direct slots from 13 native originals**: four pathway definitions, one parent class, seven reaction definitions and the epoxide compound. The earlier `native-complete-projections.json` predates the late compound acquisition and remains unchanged. Source originals remain controlling.

The pathway comment itself says the lower route is less characterized and inferred from observed intermediates. Database membership, calculated Gibbs values, generic EC links and pathway/taxon membership must not be promoted to experimentally proven catalytic or causal assertions. Preserve both the full definition and its uncertainty.

## Epoxide correction and chemical identity gaps

The historical-looking compound frame `CYCLOHEX-13-DIENE-56-DIHYDROXY-1-CARBO` now has the actual native common name **2,3-epoxy-2,3-dihydrobenzoyl-CoA**. Its complete 20,022-byte original has SHA256 `d6232effd97fa1d8848a3db9eeb5508b132f2a043de78ca120a5c297d0d94bd4`. Frame spelling is not evidence for a current dihydrodiol structure. Full native InChI, key, CHEBI:88118 and KEGG:C19684 links are retained as leads; issuing exact structural equivalence has not been established here. The native structure leaves two ring stereocenters unspecified. The 2011 BoxB abstract describes a predicted stereoselective (2S,3R) result; it must not silently replace unspecified native chemistry with an experimentally verified stereochemical claim.

Native Rhea links **25383, 25390 and 34863** are absent from the complete retained direction table (SHA256 `deae1911da372c70ee8fc97992809c7923e63b288a8702fc4396edcb2633fb04`). That does not establish retirement or authorize replacement. Current equation-label families **48312–48315, 48308–48311 and 76647–76650** were used only as conservative duplicate-search aliases. `current-rhea-comparison-leads.json` binds exact SQL rows to a fresh complete 1,025,437,696-byte Rhea 139 owner database hash `dfb4ba7378192eeba99176ced48ab419714bb97e21e5b7c8499bdd2369fb143b`; metadata was unchanged across the read. No atom-level, protonation, charge, coefficient, stereo or whole-family equivalence approval follows from those labels. The first failed helper assumption that all native links would resolve is retained under `attempts/initial-family-assumption/`.

## Primary evidence actually available in this handoff

Ten complete newly acquired Europe PMC indexed metadata/abstract originals were read: **11222587, 11306574, 12399500, 15916608, 16585753, 18462753, 20452977, 9746358, 22303008 and 21632537**. `source-access-and-scope-ledger.json` binds each full response, exact abstract locator, preparation scope, inference limit and next source task.

The strongest immediate source work is the 2010 epoxide correction (PMID:20452977), the 2001 lower intermediate study (11306574), and the BoxC/BoxD/gene studies (15916608, 16585753, 12399500). Distinguish original native enzyme, recombinant fusion/tagged preparations, genetic growth phenotypes, structural predictions and source proposals. The 2001 reinvestigation (11222587) rejected the earlier 3-hydroxybenzoyl-CoA/gentisate interpretation; the 1993 source remains a historical lead requiring its own reading, not current-pathway confirmation. PMID:18462753 concerns LB400 aldehyde-dehydrogenase structure/substrate scope. PMID:22303008 is a BoxR/BzdR regulation lead requiring exact organism/operator/construct closure.

**No complete original primary article body, PDF, supplement or original figure set was acquired/read in this discovery package.** Five Europe PMC fullTextXML requests (PMC2898338, PMC3322966, PMC151953, PMC1446997, PMC95084) returned HTTP500. The two saved PMC HTML responses returned HTTP200 but contain `Checking your browser - reCAPTCHA`, not article bodies. Raw bytes and failed request receipts are preserved. A readable web transformation of the 2010 paper supplied limited introduction/methods/discussion/caption context, not a complete original. Access failures are not biological negative evidence and do not justify dropping lower reactions.

The direct lower-reaction citation **PMID:20660314 / DOI:10.1073/pnas.1005399107** is retained through byte-bound prior research snapshots and was separately searched. The previous next263 sources explicitly label their PNAS capture partial and leave some PaaJ donor/host/construct and supplement details unresolved. Its phenylacetate lower chemistry is relevant for further research but does not assign the entire benzoyl-CoA route or exact A. evansii enzymes. Do not assume a complete paper merely because a retained metadata or transformed-text file exists.

## Bounded duplicate search

All **261 current worktree records** and **258 original-checkout records** were parsed and their complete YAML bytes captured as lossless gzip snapshots. Current comparison is bound to HEAD `3bd67d7cc30513e6b3cddc9b3696af0ef785fbdb`, tree `74fb48676541d0662590ebee793f5222d6a5d0d4`; the unmerged PWY-2503 record SHA256 is `3f8bbb8eceaa4420fa822e87ce01cca6b9d1967908dc117628aba71f54030696`. The original checkout remained at HEAD `fbccbdc027f2a86ad4919e9dbbb16a736cc0746a`, tree `72737d598ca6c7d18861f8c3612f50c265a30e08`, with its captured status unchanged. The final preservation receipt verifies all **519 record occurrences unchanged**; root-owned research/review metadata may progress independently.

The finite ignored/hidden-inclusive searches used **79 distinct patterns**: 61 initial identities/names/native reaction/KEGG/Rhea/publication aliases, 16 additive current-Rhea/new-publication aliases, and two direct lower-reaction publication aliases. Actual commands and times are retained. `rg --no-ignore --hidden` included ignored content; only root `.git` and `.venv` were intentionally excluded. Normal binary handling, compressed archive interiors and directory symlink limits remain explicit.

Initial searches matched 218 current and 115 original files (1,448 and 968 matching lines); the 16-pattern addition had no matches. The two-pattern lower-paper addition matched 57 current and one original file (175 and four lines), including **35 newly matched current files**. The union is **368 file occurrences and 237 unique full-byte snapshots**. Every matching file/context has a disposition in the two `prior-file-dispositions-*` and two `reaction-publication-dispositions-*` ledgers. This is not a claim to reread every unrelated scientific assertion in every large research file.

No exact maintained PWY-1361 or complete seven-family route duplicate was found within these bounds. Existing PWY-2361 and PWY-5417 share **only terminal RXN-3641/RHEA:19483**. PWY-2503 has zero candidate reaction families and retains four alternative-paper leads. Other matches include generated output, historical term/source inventories, compound/cofactor reverse indexes, and longer identifiers such as RXN-36414/RXN-36415 or ENZRXN-2424. The only exact prior PWY-1361 mention is an `in-pathway` backlink on native RXN-3641. It is not a previous authored or rejected pathway record. `complete-corpus-comparison.json`, `additive-record-family-comparison.json`, `prior-native-index-contexts.json` and `final-dedup-assessment.json` make these distinctions explicit.

## Alternative routes and next work

`bounded-shortlist-and-alternative-dispositions.json` retains the complete retrieved alternatives: **CENTBENZCOA-PWY** (seven-step anaerobic Thauera-type route) and **P321-PWY** (nine-step anaerobic R. palustris route). Both are distinct future candidates, not cleared for authoring by this search. Preserve source prose conflicts: reduced ferredoxin is a donor in the primary abstract, while native comments call it an acceptor; initial reductive dearomatization is not the later hydrolytic ring cleavage. For P321 retain the pimE frameshift and residual growth of the pim deletion strain.

PWY-7402 is a mixed superpathway with four pathway children and three individual reactions and is rejected for this addition. Prior next264 dispositions for one-reaction PWY-283 and umbrella PWY-2504/PWY-5430 remain bound to their original evidence. This finite cohort does not exhaust microbial pathway sources.

Before record creation:

1. Wait for next264 to merge, then rebind the full corpus, identifiers, aliases, reactions, citations and new research against the actual merged baseline and unchanged original checkout state.
2. Obtain complete primary articles/figures/supplements and reconstruct all upper and lower source facts with preparation-specific limits; inaccessible originals remain explicit gaps.
3. Verify all 18 material identities and seven reaction families, directions/stoichiometry/charge/stereochemistry, including the unresolved xrefs and putative isomerase. Reuse prior terminal-thiolase chemistry only with exact source-byte bindings.
4. Close all 15 activity backlinks and their finite enzyme/component/gene/cofactor/taxon/regulation scope, without importing adjacent pathway proteins or inferring strain equivalence.
5. Have the complete source-to-graph design independently reviewed before authoring. Preserve the full route and honest database-versus-primary support; do not narrow the named route to make evidence easier.

`candidate-decision.json` explicitly sets authoring readiness false. The package is a reproducible bounded discovery result. Compact retention and artifact manifests, plus an external **discovery-author replay**, establish byte integrity; they do not turn author work into independent scientific review. Original public source licenses are recorded through existing roadmap context; this discovery makes no public-redistribution clearance claim.
