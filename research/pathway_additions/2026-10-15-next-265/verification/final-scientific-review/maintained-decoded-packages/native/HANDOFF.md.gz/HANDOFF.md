# PWY-1361 finite native biological closure

This is source-author preparation for the complete seven-reaction aerobic
benzoyl-CoA pathway. It is not an independent review, a maintained record, or a
post-merge duplicate-search result. The source package preserves every original
byte supplied by root and adds the finite forward biological closure.

The closure contains 76 complete native objects: 15 enzymatic activities,
22 proteins or complexes, 16 genes, eight organisms, six regulations, eight
cofactor or regulator compounds, and one cellular compartment. All 102 followed
forward pointers resolve to complete originals. The eight complete route
originals are separately copied into `context/route-originals`; the pathway
original also contains complete embedded objects for its three named taxa.

`direct-slot-projections.json` retains all 902 direct slots, including complete
nested XML. `route-native-direct-slot-projections.json` retains all 148 route
slots. These are parser projections, not claims that reserialized XML is an
original byte slice. The raw XML remains the evidence owner. Every source slot
has a locator and disposition. All 253 direct database links preserve their
native relationship types; none is silently promoted to exact issuing identity.

`source-to-design-dispositions.json` accounts for all 15 activities, every
protein, gene, organism, cofactor, regulation, and the putative step.
`comment-link-boundary-ledger.json` additionally retains all 146 HTML links in
native comments. `finite-native-primary-lead-dispositions.json` accounts for all
36 PubMed leads in direct citations, embedded evidence, and those comments.
Citation presence is distinguished from an inspected primary article.

## Scope that the design must preserve

The upper pathway has native BoxAB, BoxC, and BoxD assertions. BoxA is stored as
a dimer within a BoxAB assembly containing one BoxA complex and one BoxB
monomer. This membership must not become a claim that the whole BoxAB assembly
was isolated as a stable physiological complex. BoxB's 2011 epoxide absolute
configuration is predicted from structural geometry, not directly measured.
The native BoxC monomer name and its 2005 kinetic attribution retain the older
dihydrodiol interpretation. The 2010 epoxide correction applies to the modern
route but does not create a new epoxide kinetic experiment in the 2005 paper.
BoxC and BoxD recombinant/MBP-fusion preparation limits remain explicit.

The upper sequence leads are BoxA Q9AIX6/G-2241, BoxB Q9AIX7/G-2242, BoxC
Q84HH6/G-11804, and BoxD Q84HH8/G-11807. Native G-2241 links AF220510 as PART-OF;
G-2242 labels the same whole DNA record as unification. The latter is a source
assertion, not proof that an entire DNA accession is one gene. BoxC and BoxD
link AF548005 as PART-OF. Exact issuing sequence and preparation checks remain
separate work. Typed PDB Structure links and protein-family links are not exact
gene or preparation identity.

The lower activities come from several different contexts. Pseudomonas sp. Y2
PaaF/PaaJ and E. coli MG1655 PaaH/PaaJ belong to phenylacetate work. P. putida
and B13 thiolases belong to beta-ketoadipate work. Thermobifida assignments
include engineered reverse-adipate production and heterologous unpurified
evidence. H16 assignments carry EV-EXP-IEP expression evidence. These can
support explicitly scoped source assertions; they do not establish purified
substrate specificity, natural forward Box flux, or all-route participation in
Aromatoleum evansii. All original evidence codes and source directions are
retained, including reversible or physiological R2L annotations.

RXN-2424 has native `orphan: YES-PUTATIVE` and no enzymatic-activity backlink.
It remains part of the seven-step source definition, with no invented catalyst.
Formal chemical balance does not prove that the step was experimentally
characterized. The design must not discard the lower steps merely because the
upper module is better characterized.

## Concrete source conflicts and identity limits

The six native regulations point to B13 thiolase ENZRXN-13636. The complete
original for PMID11741862 is **PMC134768**, retained here from the frozen next263
primary package and verified against its manifest. Its original SHA256 is
`499b5d1506f5715922a53c5ef8181b36ddc0eca4ea76d128b100e977f70e6199`.
The exact re-read paragraphs and locators are in
`primary-regulation-original-extract.json`.

- REG-5831, REG-5832, and REG-5833 attach three organic inhibitors to thiolase.
  The original Results paragraph 90, using the zero-based document p index,
  assigns them to the **transferase** reaction. Exclude these thiolase/Box
  inhibition edges.
- The thiolase assay paragraph 79 used 1 mM CuSO4, NaCN, or ZnCl2. Native HCN is
  not the tested salt. CuSO4 left 10% activity, NaCN left 88%, and ZnCl2 caused
  46% inhibition. Any representation must retain the salt, dose, preparation,
  and adjacent lower-reaction scope.
- The same source describes two minor contaminating protein bands in paragraph
  75 while later using “homogeneous.” Preserve this preparation limit. Its
  tetramer assignment is based on native and subunit molecular masses.
- MONOMER-21977's native narrative calls pcaJ the thiolase, while its direct gene
  is pcaF/H16_B0200. Preserve the conflict instead of silently asserting pcaJ.
  A described quadruple deletion still grows, so it does not establish pcaF
  essentiality.
- Native `NCBI-REFSEQ-PRO` links include AAZ and CAJ accessions. Treat those as
  native type assertions requiring issuing resolution; do not recast them as
  RefSeq merely because of the database label. Old PaaJ modeling links to
  P77525 are not automatically merged with current P0C7L2.
- B13 gene G-9823 and its protein have no external sequence link in their
  complete native objects. Do not assign an accession from the PcaF role.

The CPD-7 cofactor is a generic [4Fe4S] core/class. Its native CHEBI:33725 link
does not by itself establish equality to a protein-ligated cluster or a specific
redox state. Native cofactor slots supply no occupancy. FAD likewise requires
separate exact issuing identity and preparation-specific occupancy evidence.
The other six chemical originals are retained for regulator identity and conflict
assessment; their presence does not create supported Box regulation.

Native pathway taxa are A. evansii (59406), G. stearothermophilus (1422), and
P. xenovorans LB400 (266265). Species rank is not exact strain identity. LB400
chromosomal and megaplasmid paralogs must remain distinct. Root's separate
frozen NCBI taxonomy package is bound as an issuing-source lead, not treated as
experimental whole-pathway evidence. Native bacterial taxonomic range does not
assert that every bacterium has the pathway.

## Finite boundary and acquisition

The acquisition follows activity → enzyme/cofactor/regulation; protein →
components/gene/species/location/cofactor/regulation; regulation → regulator and
regulated activity; gene → product/species; and the engineered custom strain's
immediate species parent. Component recursion and gene-product back-links are
fully closed. We retain, but do not recursively expand, reverse catalysis and
chemical indexes, taxonomy/class ancestry, unrelated regulatory neighborhoods,
protein features and family annotations, comparative organism mentions, or
adjacent engineered genes. All 8,948 native pointer occurrences have explicit
boundary dispositions; the 146 comment links are separately accounted.

All 38 root-acquired originals and four root receipts/seed inventories remain
unchanged. Added acquisitions use the same public issuing XML endpoint and
complete-object validation. The first ZN+2 request failed with a connection
reset; that receipt remains, and the later successful complete original is
separately bound. There was no failed-body substitution. The original XML's
PGDB version is 27.0; retrieval timestamps are in acquisition receipts and are
not silently substituted for database version.

The previous frozen chemistry package binds all 18 formal materials, all seven
equations, 32 material entries and six joins. Its originals and conclusions are
reused without mutation; its independent chemical acceptance is a separate
review package. The new native biological interpretations here still require
independent acceptance. The separate primary package and biological-primary
follow-up retain their own full-text and access limits.

## Reproduction and retention

Helpers under `helpers/` are inert `.py.txt` evidence. The verified next263 Python
environment was used read-only, with no installation or environment changes.
The source-author replay checks all original digests, both complete direct-slot
projections, all seed/activity pairs, closure counts, and exact copied context.
Its log is `native-package-replay.log` and its receipt is
`native-package-replay-receipt.json`.

`compact/` contains deterministic, lossless gzip copies; the storage manifest
binds both decoded/original and stored hashes. Original bytes are never edited
to pass whitespace checks. The artifact manifest inventories every file,
including hidden and ignored files, except the manifest itself. Final freeze
verification rehashes all files and decodes every compact pair. No maintained
files, Git state, GitHub state, runtime environment, or frozen predecessor was
modified.
