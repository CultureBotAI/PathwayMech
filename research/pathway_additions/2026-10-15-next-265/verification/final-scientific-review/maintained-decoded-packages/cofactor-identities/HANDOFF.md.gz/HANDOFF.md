# Box cofactor chemical identities

This is a bounded source-author package for possible BoxA/BoxAB cofactor use in
MetaCyc:PWY-1361. It requires separate independent acceptance. No maintained
record, graph, Git state, GitHub state, frozen package, or runtime environment
was changed.

The proposed selection is **CHEBI:57692 for normalized FAD(3−)** and retention of
**MetaCyc:CPD-7 as the native generic [4Fe4S] class**. CHEBI:64607 is available as
explicitly broader four-iron/four-sulfur class grounding. CHEBI:33725 matches the
native neutral core representation; it is not an unconditional identity for
the whole native class or the actual protein-bound cofactor.

`selection-and-design-dispositions.json` gives the complete choice, rejected
alternatives, evidence placement and limits. `chemical-identity-assessment.json`
contains the executed source comparison. These are chemical identity decisions,
not new occupancy measurements or acceptance of a complete biological graph.

## Original evidence and checks

Four complete issuing ChEBI records were newly retrieved through the public
compound API: 33725, its cubane parent 49883, generic class 64607, and the
cysteinyl-ligated class 26930. All successful response bodies, requested/final
URLs, headers, timestamps and digests are retained in `originals/` and the three
`acquisition-*.json` files. Complete FAD record 57692 and its exact acquisition
receipt are reused from the frozen next264 package. The entire FAD native body
is byte-identical across next264 and next265.

All five complete pinned ChEBI subject records were extracted read-only, after
a fresh full 4,137,340,928-byte database hash. The database SHA256 remains
`26ad4890cdcf6ee357760d815dfee8f5ba81e0873e62cb379369b04205722b0f`.
All 81 selected statements are retained. Each issuing name, definition, full
InChI, key, formula, charge and SMILES agrees with the corresponding pinned
fields where present. No missing formula or structure is invented for a class.

Six complete native originals are retained: CPD-7, FAD, ENZRXN-3327, CPLX-2682,
CPLX-2681 and MONOMER-3142. Their bytes match the frozen native manifest.
`native-relevant-slot-projections.json` retains 35 exact relevant slot
projections with XPath locators. Acquisition and reuse ownership remain explicit
through the full source manifests and receipts.

## FAD

[CHEBI:57692](https://www.ebi.ac.uk/chebi/CHEBI:57692) is the trianion of FAD,
with formula C27H30N9O15P2, charge −3 and InChIKey
`IMGVNJNCCGXBHD-UYBVJOGSSA-K`. The complete native, issuing and pinned InChI
strings agree, including stereochemical layers. The original native generic
SMILES contains an incomplete `[R]` group and is rejected as a full identity
representation.

The previously accepted FAD connectivity proof is reused only after exact
original-byte equality, exact CML equality and equality of every selected pinned
subject row. Its original independent assessment and structure proof are
retained and bound in `prior-FAD-acceptance-reuse.json`. This is reuse of that
specific historical FAD conclusion, not a new RDKit calculation or independent
self-acceptance of this package. The historical report's unrelated Rhea issue
status is not asserted as current here.

The node denotes the normalized native molecular form. It does not establish the
protonation microstate inside BoxA, the assay solution's dominant species,
flavin occupancy, or a particular enzyme redox state. Primary evidence
identifies extracted FAD by chromatography against standards; it does not
measure a protein-bound FAD(3−) microstate.

## Iron–sulfur core, class and ligation

[CHEBI:33725](https://www.ebi.ac.uk/chebi/CHEBI:33725) has formula H4Fe4S4,
overall charge zero, InChI `InChI=1S/4Fe.4S` and key
`LJBDFODJNLIPKO-UHFFFAOYSA-N`. These agree with the native core fields. The native
CML and issuing structure contain four Fe and four S atoms with 12 Fe–S bonds.
A finite comparison tests all 576 element-preserving atom permutations and
finds 24 valid topology/charge mappings. A strictly bounded parser also compares
the native and issuing small Fe/S SMILES, including the represented hydrogens.
Charge-change and missing-bond negative controls fail as expected.

This agreement is limited to a source representation. Native CPD-7 is marked as
a class, and its comment describes multiple redox states and cysteinyl ligation.
The eight-atom core contains none of those protein ligands. Matching its
metal-disconnected standard InChI alone would not prove coordination, ligand
identity, hydrogen placement or a physiological redox state. CML itself does not
explicitly place the four hydrogens; formula and bounded SMILES normalization
provide source-representation agreement only.

The issuing label's `(0)` is overall charge, not an assertion of zero-valent
iron: that same record has an IUPAC synonym using tetrairon(II). Native CPD-7
also has a formula/mass inconsistency: its H4-containing formula and neutral
core structure agree with 33725, but its displayed mass is 351.628, whereas
33725 reports 355.680. We preserve the original bytes and explicitly reject the
native mass as a matching criterion.

[CHEBI:49883](https://www.ebi.ac.uk/chebi/CHEBI:49883) is the issuing cubane
topology parent. Its structure has Fe− and S+ formal atom labels, formula Fe4S4
and a different InChI/key. The heavy topology agrees, while exact charge-labeled
graph equality fails. Those formal atom labels are not experimental metal
oxidation-state measurements.

[CHEBI:64607](https://www.ebi.ac.uk/chebi/CHEBI:64607) defines a generic cluster
containing four iron and four sulfur atoms and has no default structure,
formula or charge in the inspected issuing body. It can ground the broader
concept without imposing a particular redox state.
[CHEBI:26930](https://www.ebi.ac.uk/chebi/CHEBI:26930) names a cysteinyl-ligated
class but likewise supplies no structure or formula in the inspected record.
It is not selected as exact native or BoxA chemical identity solely from motifs.
All three exact issuing `is a` relationships are retained and checked.

## Primary limits and evidence placement

The complete original displayed HTML of
[PMID11222587](https://pmc.ncbi.nlm.nih.gov/articles/PMC95084/) is copied without
change. Six relevant Methods, Results and Discussion paragraphs were re-read
for this bounded representation decision and independently reconstructed from
the original HTML. Their text agrees with the previous reading units. Exact
zero-based paragraph locators, enclosing DOM identifiers, text hashes and short
quote anchors are in `bounded-primary-identity-reading.json`.

The original identifies extracted FAD by HPLC. Its [4Fe4S] interpretation uses
motifs, bulk Fe/S analysis and spectra, with explicit inferential language.
Neither supplies a fully specified ligated center, individual iron oxidation
states, or fixed occupancy. Preparation-dependent amounts and possible flavin
loss remain in the separate biological-primary evidence package; no new count
is assigned here. No new full-paper, figure, or occupancy review is claimed.

Use issuing records for chemical node identity. A native cofactor edge must cite
the actual ENZRXN-3327 cofactor slot, with its source scope. A BoxA-specific edge
must use the actual primary BoxA preparation evidence and retain its inference
and microstate limits. Identity matching alone does not establish biological
cofactor dependence or stoichiometry.

## Execution and retention

The initial RDKit/Descriptors probe failed because `numpy.__config__` was missing
from the existing npmech environment. Its exact helper, empty stdout and stderr
are retained. No cause or actor is inferred. That environment was not repaired
or used again. All successful new calculations used the verified263 Python
standard library. The accepted FAD structural proof was reused with exact input
bindings, rather than relabeled as a successful new RDKit run.

All helpers are inert `.py.txt` evidence. `execution-receipts.json` records the
successful bounded checks and the separate failed operational probe. The final
read-only verification replays raw-body bindings, source locators, whole selected
SQL records, FAD reuse and finite graph evidence without changing originals.

Two preliminary bookkeeping attempts are also retained under `attempts/`.
The first read-only replay compared integer atom-map keys to their JSON string
forms and failed at the final equality check; normalizing the comparison through
JSON fixed it without changing the saved chemical assessment. An initial final
receipt failed to check that replay log's status and is explicitly superseded.
The final helper requires the actual successful replay status before recording
pass. Neither preliminary receipt is presented as independent or successful
scientific acceptance.

`compact/storage-manifest.json` binds deterministic gzip files to exact decoded
originals. `artifact-manifest.json` inventories all regular files, including
hidden or ignored ones, except itself. All compact pairs and inventory entries
are verified at freeze. The resulting package is ready for independent review;
it is not a canonical maintained-record review.
