"""Resume exact read-only gates after the recorded sandbox DNS failure."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/private/tmp/pathwaymech-next-235-local-20261012')
BASE = Path('/private/tmp/pathwaymech-next-235-local-native-execution-20261012')
PLAN = Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012/stages.json')

def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def write(p, d):
    with p.open('x') as f:
        json.dump(d, f, indent=2)
        f.write('\n')

assert pin(PLAN)['sha256'] == '3ad6f8d61250bd233cbc995a894b0dd8fa8aace0e70416e2d8befcd0506f1d9c'
plan = json.loads(PLAN.read_bytes())
failure = json.loads((BASE / 'remaining-gates/failure.json').read_bytes())
assert [(r['name'], r['exit_code']) for r in failure['receipts']] == [('validate', 0), ('tests', 0), ('lint', 0), ('kgx', 0), ('vendored', 1)]
assert 'nodename nor servname provided' in (BASE / 'remaining-gates/vendored.stderr').read_text()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '5ff01d7c59c61fd94b65b907edd50936193f7f17'
out = BASE / 'network-resumption'
out.mkdir(exist_ok=False)
env = {**os.environ, **plan['environment']}
receipts = []
for item in plan['nine_fresh_gates'][6:]:
    name, argv = item['name'], item['argv']
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    with (out / (name + '.stdout')).open('xb') as stdout, (out / (name + '.stderr')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False)
    receipt = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'environment': plan['environment'], 'started_at': start, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'seconds': time.monotonic() - clock, 'exit_code': result.returncode, 'stdout': pin(out / (name + '.stdout')), 'stderr': pin(out / (name + '.stderr'))}
    write(out / (name + '.execution.json'), receipt)
    receipts.append(receipt)
    print(json.dumps({'name': name, 'exit_code': result.returncode, 'seconds': receipt['seconds']}), flush=True)
    if result.returncode:
        write(out / 'failure.json', {'status': 'phase_failed', 'receipts': receipts})
        raise SystemExit(result.returncode)
write(out / 'completion.json', {'status': 'phase_passed', 'receipts': receipts, 'prior_failure': pin(BASE / 'remaining-gates/failure.json'), 'stage_plan': pin(PLAN), 'runner': pin(Path(__file__))})
