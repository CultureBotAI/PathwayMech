import collections
import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/private/tmp/pathwaymech-next-235-local-20261012')
FINAL = Path('/private/tmp/pathwaymech-next-235-final-precommit-20261012')
PRE = Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
QA = Path('/private/tmp/pathwaymech-next-235-maintained-independent-qa-20261012')
OUT = Path(__file__).with_suffix('.json')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def desc(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

scope = json.loads((FINAL / 'staged-whitespace-scope.json').read_text())
raw = (FINAL / 'staged-diff-check.stdout').read_bytes()
lines = raw.decode().splitlines()
assert len(lines) == 168
diagnostics = []
for i in range(0, len(lines), 2):
    match = re.fullmatch(r'(.+):(\d+): (.+\.)', lines[i])
    assert match and lines[i + 1].startswith('+')
    path, line, diagnostic = match.groups()
    row = {'path': path, 'line': int(line), 'diagnostic': diagnostic}
    assert (ROOT / path).read_text().splitlines()[int(line) - 1] == lines[i + 1][1:]
    diagnostics.append(row)
assert diagnostics == scope['diagnostics']
assert collections.Counter(r['diagnostic'] for r in diagnostics) == {'trailing whitespace.': 81, 'space before tab in indent.': 3}
paths = sorted({r['path'] for r in diagnostics})
assert len(paths) == 11
assert paths == [r['path'] for r in scope['exact_excluded_paths']]
assert scope['checks'][0]['exit_code'] == 2 and scope['checks'][1]['exit_code'] == 0
assert scope['checks'][0]['stdout'] == {'bytes': len(raw), 'sha256': sha(raw)}
assert scope['checks'][1]['argv'] == ['git', 'diff', '--cached', '--check', '--', '.', *[':(exclude,literal)' + p for p in paths]]
plan = json.loads((PRE / 'plan.json').read_text())
changes = {r['destination']: r for r in plan['changes']}
runtime = {r['relative_path']: r for r in json.loads((PRE / 'runtime-owner-map.json').read_text())['runtime']}
copy = {r['repository_path']: r for r in json.loads((QA / 'copy-plan.json').read_text())['files']}
fixtures = {r['entry']['path']: r for r in json.loads((ROOT / 'tests/fixtures/nitrate_authority/manifest.json').read_text())}
staged = {r['path']: r for r in json.loads((FINAL / 'git-inputs.json').read_text())}
verified = []
for path in paths:
    body = (ROOT / path).read_bytes()
    digest = sha(body)
    assert staged[path]['sha256'] == digest and staged[path]['bytes'] == len(body)
    blob = subprocess.run(['git', '-C', str(ROOT), 'show', ':' + path], capture_output=True, check=True).stdout
    assert body == blob
    lineage = []
    if path.startswith('tests/fixtures/'):
        assert changes[path]['payload']['sha256'] == digest
        lineage.append(Path(changes[path]['payload']['path']))
        lineage.extend(Path(runtime[path][k]['path']) for k in ['accepted', 'effective_preparation', 'actual_runtime'])
        if Path(path).name.endswith('.xml'):
            original = fixtures[Path(path).name]['original']
            assert original['sha256'] == digest
            lineage.append(Path(original['path']))
        else:
            lineage.append(Path('/private/tmp/pathwaymech-next-235-authority-design-20261012/raw/MetaCyc-PWY0-1352-issuing-retry.html'))
    else:
        row = copy[path]
        assert row['sha256'] == row['decoded_sha256'] == digest and not row['gzip_encoded']
        lineage.extend(Path(row[k]) for k in ['payload_path', 'source_path'])
        lineage.append(Path('/private/tmp/pathwaymech-next-235-local-native-execution-20261012/remaining-gates/tests.stdout'))
    for original in lineage:
        assert original.read_bytes() == body
    verified.append({'path': path, 'sha256': digest, 'bytes': len(body), 'lines': [r['line'] for r in diagnostics if r['path'] == path], 'exact_staged_worktree_original_match': True, 'original_lineage': [str(p) for p in lineage]})
receipt = {
    'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'accept_exact_original_byte_retention_and_individual_whitespace_exclusions',
    'recommendation': 'Retain all 11 exact original-byte files. The additional staged whitespace check may exclude only these literal paths. Preserve the original unscoped exit-2 check and 84 diagnostics; the scoped exit-0 result is not a claim that the full staged check passed. Do not normalize scientific originals or execution streams and do not change repository-wide whitespace settings.',
    'coverage': 'All 84 diagnostics and diagnostic source lines were parsed and matched exactly. All 11 complete staged blobs were freshly compared to worktree bytes, accepted payload/copy-plan hashes, and whole original files. Nine XML originals, one issuer HTML original, and one root execution stdout are unchanged. No newly authored code/data/page whitespace finding was present in the complete diagnostic stream. Existing broader scientific/technical acceptance is inherited, not repeated.',
    'counts': {'paths': 11, 'upstream_fixture_paths': 10, 'upstream_fixture_diagnostics': 83, 'execution_stream_diagnostics': 1, 'trailing_whitespace': 81, 'space_before_tab': 3},
    'verified': verified,
    'inputs': [desc(p) for p in [FINAL / 'staged-whitespace-scope.json', FINAL / 'staged-diff-check.stdout', FINAL / 'staged-diff-check.stderr', FINAL / 'git-inputs.json', PRE / 'plan.json', PRE / 'runtime-owner-map.json', QA / 'copy-plan.json', Path(__file__)]],
    'execution': 'Read-only Git show :path for each exact diagnostic path; no Git mutation, maintained write, native builder, test rerun, or settings change. Explicit paths include ignored files; no absence inferred from Git-filtered search.',
    'process_notes': ['Initial metadata inspection assumed git-inputs was an object; it is a 331-row list. That tool-only AttributeError was corrected before checks.', 'A guessed source-original-mapping.json did not exist in the nitrate preparation; issuer HTML origin was instead read from accepted-inputs.json. No evidence file was changed.', 'Two verbose tool reads were truncated; the complete structures and all diagnostic lines were then parsed programmatically. No fresh whole-paper read is claimed.'],
}
OUT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], **desc(OUT)}))
