"""Capture actual maintained native inputs before integration assessment."""
from pathlib import Path
import json,subprocess,os,datetime
out=Path(__file__).parent
root=Path('/private/tmp/pathwaymech-next-235-local-20261012')
prep=Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
plan=json.loads((prep/'plan.json').read_bytes())
record='data/pathways/nitrate-reduction-viii.yaml'
primary=[row['destination'] for row in plan['changes'] if not row['destination'].startswith('research/')]
assert len(primary)==30
science={'targets':[{'target_id':'MetaCyc:PWY0-1352','path':record,'label':'nitrate reduction VIII','kind':'maintained','ownership_note':'This maintained YAML owns scientific claims; pages and KGX are derived. Whole original science is inherited from the accepted independent review and exact corrected successor.'}]}
tech={'targets':[{'target_id':p,'path':p,'label':p,'kind':'maintained','ownership_note':'Maintained authority, runtime, configuration, documentation or test owner adopted byte-for-byte from accepted actual output and independently reviewed runtime.'} for p in primary if p!=record]}
for name,obj in [('scientific',science),('technical',tech)]:
 p=out/(name+'-targets.json')
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
 cmd=['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(p)]
 for item in ['src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','docs/record-review-profile.md','pages/records/MetaCyc_PWY0-1352.html']:cmd+=['--input',item]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'-inspection.stdout')).open('xb') as stdout,(out/(name+'-inspection.stderr')).open('xb') as stderr:
  r=subprocess.run(cmd,cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONPATH':str(root/'src')+':'+str(root)},stdout=stdout,stderr=stderr)
 receipt={'command':cmd,'cwd':str(root),'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode}
 with (out/(name+'-inspection.execution.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
