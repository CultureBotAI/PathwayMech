"""Execute the inspected native local integration stages and retain actual receipts."""
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

PREP = Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
ROOT = Path('/private/tmp/pathwaymech-next-235-local-20261012')
OUT = Path('/private/tmp/pathwaymech-next-235-local-native-execution-20261012')
EXPECTED_STAGE = '3ad6f8d61250bd233cbc995a894b0dd8fa8aace0e70416e2d8befcd0506f1d9c'


def pin(path):
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    assert pin(PREP / 'stages.json')['sha256'] == EXPECTED_STAGE
    stages = json.loads((PREP / 'stages.json').read_bytes())
    adoption = Path('/private/tmp/pathwaymech-next-235-local-adoption-root-20261012/receipt.json')
    state = json.loads(adoption.read_bytes())
    assert state['status'] == 'local_adoption_complete_no_history_gates_or_publication'
    assert state['target'] == str(ROOT) and state['publication_performed'] is False
    assert len(state['changes']) == 39
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == '5ff01d7c59c61fd94b65b907edd50936193f7f17'
    phase = sys.argv[1]
    OUT.mkdir(exist_ok=True)
    folder = OUT / phase
    folder.mkdir(exist_ok=False)
    env = {**os.environ, **stages['environment']}
    if phase == 'history-and-generation':
        commands = [{'name': 'history-' + str(i + 1), 'argv': argv} for i, argv in enumerate(stages['history_commands'])]
        commands += stages['before_first_render_after_history']
        commands += stages['nine_fresh_gates'][:2]
    elif phase == 'remaining-gates':
        prior = json.loads((OUT / 'history-and-generation/completion.json').read_bytes())
        assert prior['status'] == 'phase_passed'
        commands = stages['nine_fresh_gates'][2:]
    else:
        raise ValueError('Unknown explicit phase')
    receipts = []
    for item in commands:
        name, argv = item['name'], item['argv']
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        clock = time.monotonic()
        with (folder / (name + '.stdout')).open('xb') as stdout, (folder / (name + '.stderr')).open('xb') as stderr:
            proc = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False)
        receipt = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'environment': stages['environment'],
                   'started_at': start, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   'seconds': time.monotonic() - clock, 'exit_code': proc.returncode,
                   'stdout': pin(folder / (name + '.stdout')), 'stderr': pin(folder / (name + '.stderr'))}
        write(folder / (name + '.execution.json'), receipt)
        receipts.append(receipt)
        print(json.dumps({'name': name, 'exit_code': proc.returncode, 'seconds': receipt['seconds']}), flush=True)
        if proc.returncode:
            write(folder / 'failure.json', {'status': 'phase_failed', 'receipts': receipts, 'remaining_not_run': True})
            raise SystemExit(proc.returncode)
        if name == 'sssom':
            import csv
            from collections import Counter
            semantic = json.loads((PREP / 'semantic-preservation.json').read_bytes())['SSSOM']
            actual = (ROOT / 'output/sssom/source_mappings.sssom.tsv').read_text().splitlines()
            old_body = subprocess.check_output(['git', 'show', 'HEAD:output/sssom/source_mappings.sssom.tsv'], cwd=ROOT)
            assert hashlib.sha256(old_body).hexdigest() == semantic['before']['sha256']
            old_lines = old_body.decode().splitlines()
            assert [line for line in actual if line.startswith('#')] == semantic['exact_header_lines']
            def rows(lines):
                reader = csv.DictReader([line for line in lines if not line.startswith('#')], delimiter='\t')
                result = list(reader)
                return reader.fieldnames, Counter(tuple(row[k] for k in reader.fieldnames) for row in result)
            keys, before = rows(old_lines)
            new_keys, after = rows(actual)
            expected = Counter(tuple(row[k] for k in keys) for row in semantic['expected_added_rows'])
            assert keys == new_keys and after == before + expected
            assert sum(before.values()) == 21 and sum(expected.values()) == 6 and sum(after.values()) == 27
            write(folder / 'sssom-preservation.json', {'actual': pin(ROOT / 'output/sssom/source_mappings.sssom.tsv'), 'old_rows':21, 'added_rows':6, 'total_rows':27, 'all_headers_cells_multiplicities_exact':True})
    write(folder / 'completion.json', {'status': 'phase_passed', 'phase': phase, 'receipts': receipts,
                                      'adoption': pin(adoption), 'stage_plan': pin(PREP / 'stages.json'), 'runner': pin(Path(__file__))})


if __name__ == '__main__':
    main()
