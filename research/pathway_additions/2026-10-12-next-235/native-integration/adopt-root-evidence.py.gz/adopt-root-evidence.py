"""Copy completed local evidence with lossless transport and exact path mapping."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/pathwaymech-next-235-local-20261012')
REL = Path('research/pathway_additions/2026-10-12-next-235/native-integration')
DEST = ROOT / REL
GATES = Path('/private/tmp/pathwaymech-next-235-local-native-execution-20261012')

def body_pin(body):
    return {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

assert json.loads((GATES / 'history-and-generation/completion.json').read_bytes())['status'] == 'phase_passed'
assert json.loads((GATES / 'network-resumption/completion.json').read_bytes())['status'] == 'phase_passed'
assert not DEST.exists()
groups = [
    (GATES, Path('gates')),
    (Path('/private/tmp/pathwaymech-next-235-graph-preview-20261012'), Path('visual')),
    (Path('/private/tmp/pathwaymech-next-235-root-maintained-qa-20261012'), Path('root-review')),
    (Path('/private/tmp/pathwaymech-next-235-local-adoption-root-20261012'), Path('root-adoption')),
    (Path('/private/tmp/pathwaymech-next-235-local-integration-independent-review-20261012'), Path('preparation-independent-review')),
]
sources = []
for source, target in groups:
    for p in sorted(source.rglob('*')):
        assert not p.is_symlink()
        if p.is_file():
            sources.append((p, target / p.relative_to(source)))
sources += [
    (Path('/private/tmp/pathwaymech-next-235-root-local-adoption-acceptance-20261012.json'), Path('adoption-acceptance.json')),
    (Path('/private/tmp/pathwaymech-next-235-root-run-native-20261012.py'), Path('native-stage-runner.py')),
    (Path('/private/tmp/pathwaymech-next-235-resume-gates-20261012.py'), Path('network-resumption-runner.py')),
    (Path(__file__), Path('adopt-root-evidence.py')),
]
planned = []
for source, relative in sources:
    raw = source.read_bytes()
    compress = source.suffix in {'.py', '.stdout', '.stderr', '.svg'} or len(raw) > 100000 and source.suffix == '.json'
    body = gzip.compress(raw, mtime=0) if compress else raw
    relative = Path(str(relative) + '.gz') if compress else relative
    planned.append((source, relative, raw, body, compress))
assert len({str(x[1]) for x in planned}) == len(planned)
DEST.mkdir()
entries = []
for source, relative, raw, body, compressed in planned:
    p = DEST / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(body)
    stored = p.read_bytes()
    assert stored == body and (gzip.decompress(stored) if compressed else stored) == raw
    entries.append({'source': str(source), 'original': body_pin(raw), 'owner': str(REL / relative), 'encoding': 'gzip' if compressed else 'identity', 'stored': body_pin(stored)})
manifest = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'entries': entries, 'purpose': 'Lossless durable root execution/review evidence; paths inside unchanged originals are historical and resolve through this map.', 'hidden_and_ignored_files_included': True, 'public_publication': False}
with (DEST / 'root-storage-map.json').open('x') as f:
    json.dump(manifest, f, indent=2)
    f.write('\n')
readme = """# Actual local nitrate integration evidence

Root adopted the exact accepted nitrate reduction VIII proposal on local PWY commit 5ff01d7c59c61fd94b65b907edd50936193f7f17. Two native histories preceded the SSSOM refresh and first maintained render.

All nine native gates passed: rendering, skills, validation, 3,977 tests (three skips and three dependency warnings), lint, KGX, vendored sync, whitespace and page freshness. The initial vendored attempt failed on sandbox DNS; its full streams remain. The approved public-read retry and remaining checks passed. Successful tests were not repeated for that network failure.

root-storage-map.json maps each original execution/review/visual artifact to its durable owner, with exact original and stored hashes. Gzip is lossless transport. Historical absolute paths inside receipts resolve through this map; they are not operational instructions. The preparation-independent-review contains the exact accepted review and its 42 reused guard controls.

Root target QA verifies the complete current narrative/edge objects against inherited scientific assessments and the full maintained graph/table/evidence rendering. The graph has 67 visual nodes and 100 arrows, including four qualified endpoint states; all 107 references and local anchors resolve. Its exact SVG agrees with the statically inspected preview. Dense labels can overlap; complete assertions remain in the evidence table. Browser interaction was unavailable.

The prior 235 records/pages, 114 review pairs and 398 history YAMLs remain exact. Whole checkout preservation covers hidden and ignored files, with Git administrative metadata excluded. All 800 shared-cache identities remain unchanged. Current scientific corpus size is 236. Maintained snapshots and both graph export surfaces match the accepted actual native output; SSSOM adds exactly six mappings to 21 old rows.

Independent maintained QA and native structured reviews are separate later artifacts. Full scientific interpretation is inherited from the accepted complete-source review and exact issue498 successor, with original paper/construct/access limits; technical gates are not a new primary-literature review. Whole scientific original bodies remain available through the parent portable index. Reproducible test fixtures and full SQL databases have the explicitly documented external/inherited scope.

This is a local integration. No public push, PR, merge, issue closure, unrestricted redistribution or source exhaustion is asserted.
"""
with (DEST / 'README.md').open('x') as f:
    f.write(readme)
print(json.dumps({'status': 'root_evidence_adopted', 'root': str(DEST), 'artifacts': len(entries), 'stored_bytes': sum(x['stored']['bytes'] for x in entries), 'storage_map': body_pin((DEST / 'root-storage-map.json').read_bytes())}))
