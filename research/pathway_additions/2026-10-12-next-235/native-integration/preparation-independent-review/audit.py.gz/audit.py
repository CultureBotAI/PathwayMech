"""Independent bounded integration audit; no Git calls, adoption, native gates or SQL reads."""
import ast,csv,gzip,hashlib,io,json,os,sys,zipfile
from collections import Counter
from dataclasses import asdict
from pathlib import Path
import yaml
import common as c
import verify_portable as portable
R=Path(__file__).resolve().parent;P=c.HERE;T=c.ROOT;D=P/'payload'/c.DOSSIER
B=Path('/private/tmp/pathwaymech-next-235-canonical-build-20261012')
OLD=Path('/private/tmp/pathwaymech-next-234-local-integration-preparation-20261012')
def stable(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def readrows(path):return list(csv.DictReader(io.StringIO(Path(path).read_text()),delimiter='\t'))
def check(row):return c.verify(row)
assert c.pin(P/'handoff.json')['sha256']=='477777caf47c4b649ecbeb8e38c421f6ac549c043caf7493c1705a1f667aaa65'
assert c.pin(P/'artifact-manifest.json')['sha256']=='4c02e9ef886be2c24a8dfe4a19ddcebf856a6a0c97edafdc83fcde89fb0e2ba6'
c.sealed_check();m=c.load(P/'artifact-manifest.json');assert len(m['artifacts'])==103
assert c.inventory(P)[1]==m['directories']
plan=c.load(P/'plan.json');assert len(c.scope_check(plan))==39 and len(c.PRIMARY)==30
for row in plan['accepted_inputs']:check(row)
assert c.inventory(T,exclude_git=True)==(c.load(P/'baseline-files.json'),c.load(P/'baseline-directories.json'))
c.cache_check()
for row in plan['changes']:c.destination_check(row)
baseline=c.load(P/'baseline-receipt.json');assert baseline['commit']==c.BASE and baseline['tree']==c.TREE and baseline['branch']==c.BRANCH
assert baseline['files']==11469 and baseline['directories']==1884
owner=c.load(P/'runtime-owner-map.json');assert len(owner['runtime'])==253
changed=[]
for row in owner['runtime']:
    for name in ['accepted','effective_preparation','actual_runtime']:check(row[name])
    assert row['actual_runtime']['sha256']==row['effective_preparation']['sha256']
    source=B/'runtime'/row['relative_path'];assert c.pin(source)==row['actual_runtime']
    dest=T/row['relative_path'];before=c.pin(dest) if dest.exists() else None
    assert before==row['before']
    assert row['changed']==(before is None or before['sha256']!=row['actual_runtime']['sha256'])
    if row['changed']:
        changed.append(row['relative_path']);assert (P/'payload'/row['relative_path']).read_bytes()==source.read_bytes()
assert len(changed)==27 and c.PRIMARY==set(changed)|{'data/pathways/nitrate-reduction-viii.yaml','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json'}
target=P/'payload/data/pathways/nitrate-reduction-viii.yaml'
assert c.pin(target)['sha256']=='019deb06b1b58ae9c378b209a9e3815b6357685e13e6e3345b8be01aaf13f5de'
assert target.read_bytes()==(B/'corpus/nitrate-reduction-viii.yaml').read_bytes()
sem=c.load(P/'semantic-preservation.json');comparison=c.load(B/'comparison.json')
for kind in ['sources','ontology']:
    old=c.load(T/f'data/identifier_authorities/{kind}.json');new=c.load(P/f'payload/data/identifier_authorities/{kind}.json')
    assert (P/f'payload/data/identifier_authorities/{kind}.json').read_bytes()==(B/(kind+'.json')).read_bytes()
    assert list(old)==list(new)
    for section in ['sources','terms']:
        assert [k for k in new[section] if k in old[section]]==list(old[section])
        for ident,value in old[section].items():
            if (kind,section,ident)==('sources','sources','pwy234-rhea-polymer-142'):
                ex=comparison['only_old_owner_addition'];assert stable(value)==stable(ex['before']) and stable(new[section][ident])==stable(ex['expected_after'])
            else:assert stable(value)==stable(new[section][ident])
    assert old['version']==new['version']
oldmanifest=c.load(T/'conf/identifier_sources.json');newmanifest=c.load(P/'payload/conf/identifier_sources.json')
assert len(oldmanifest)==831 and len(newmanifest)==844 and stable(newmanifest[:831])==stable(oldmanifest)
graph_changes=[];context_count=0
for name in ['nodes.tsv','edges.tsv']:
    before=readrows(T/'output/kgx'/name);after=readrows(B/'actual-kgx'/name);old={r['id']:r for r in before};new={r['id']:r for r in after}
    assert len(old)==len(before) and len(new)==len(after) and set(old)<=set(new)
    if name=='edges.tsv':assert [r for r in after if r['id'] in old]==before
    else:
        for ident,row in old.items():
            bc=json.loads(row['source_contexts']);ac=json.loads(new[ident]['source_contexts'])
            assert [v for v in ac if v['record_id']!='MetaCyc:PWY0-1352']==bc;context_count+=len(bc)
            diff={k:{'before':v,'after':new[ident][k]} for k,v in row.items() if k!='source_contexts' and v!=new[ident][k]}
            if diff:graph_changes.append({'id':ident,'fields':diff})
assert context_count==7877
assert graph_changes==[{'id':'CHEBI:18407','fields':{'category':{'before':'biolink:ChemicalEntity','after':'biolink:ChemicalEntity|biolink:SmallMolecule'},'source_category':{'before':'chemical_entity','after':'chemical_entity|small_molecule'}}}]
# Real native row/normalization functions only, without writing/exporting a maintained SSSOM file.
sys.path[:0]=[str(T/'src'),str(T)]
from pathwaymech.schema import validate_record
from pathwaymech.sssom import sssom_rows,_cell,SSSOM_HEADER,SSSOM_COLUMNS
record=validate_record(yaml.safe_load(target.read_bytes()))
rows=[{k:_cell(asdict(row)[k]) for k in SSSOM_COLUMNS} for row in sssom_rows([record])]
ss=sem['SSSOM'];assert len(rows)==6 and Counter(stable(row) for row in rows)==Counter(stable(row) for row in ss['expected_added_rows'])
oldtext=(T/'output/sssom/source_mappings.sssom.tsv').read_text();header=[v for v in oldtext.splitlines() if v.startswith('#')]
assert header==list(SSSOM_HEADER)==ss['exact_header_lines']
oldss=list(csv.DictReader(io.StringIO('\n'.join(v for v in oldtext.splitlines() if not v.startswith('#'))),delimiter='\t'))
assert len(oldss)==ss['old_rows'] and ss['expected_total_rows']==len(oldss)+6
assert not (set(stable(v) for v in rows)&set(stable(v) for v in oldss))
stages=c.load(P/'stages.json');assert stages['cwd']==str(T)
assert [v['name'] for v in stages['nine_fresh_gates']]==['render','skills','validate','tests','lint','kgx','vendored','diff-check','site-current']
assert len(stages['history_commands'])==2 and all(cmd[cmd.index('--actor-name')+1]=='codex' for cmd in stages['history_commands'])
assert [cmd[cmd.index('--event')+1] for cmd in stages['history_commands']]==['CREATE','EDIT']
assert stages['before_first_render_after_history'][0]['name']=='sssom'
assert plan['history_before_first_render'] is True and stages['native_review_interfaces']['do_not_fabricate_review_content_or_completion_time'] is True
for command in stages['history_commands']+ [v['argv'] for v in stages['nine_fresh_gates']+stages['before_first_render_after_history']]:
    if command[0].endswith('/python'):assert command[:2]==['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B']
replacements={'/pathwaymech-next-234-local-20261012':'/pathwaymech-next-235-local-20261012','8c871a5808c73b0f21a397a2561269d068ee7368':c.BASE,'9e89d6330371d2d2834fec966af7e3e3edc35dca':c.TREE,'feat/pathway-next-234-local-20261012':c.BRANCH,'2026-10-12-next-234':'2026-10-12-next-235','PWY7545':'nitrate235','pwy234-local-adoption':'nitrate235-local-adoption','pathwaymech-next-234-local-adoption-':'pathwaymech-next-235-local-adoption-'}
for row in c.load(P/'helper-lineage.json'):
    check(row['original']);check(row['successor']);text=(OLD/row['helper']).read_text()
    for a,b in replacements.items():text=text.replace(a,b)
    a=ast.parse(text);b=ast.parse((P/row['helper']).read_text())
    if row['helper']=='common.py':
        def primary(t):return next(n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='PRIMARY' for x in n.targets))
        primary(a).value=primary(b).value
    assert ast.dump(a)==ast.dump(b)
# All portable bodies retrieved through actual payload/baseline resolver; no historical file access.
replay=portable.verify(T,P/'payload')
assert replay==c.load(P/'portable-replay.stdout') and replay['unique_bodies']==2907
proof=c.load(P/'preparation-archive-proof.json');check(proof['archive'])
with zipfile.ZipFile(proof['archive']['path']) as z:
    assert set(z.namelist())=={r['archive_member'] for r in proof['members']}
    for row in proof['members']:
        check(row);body=z.read(row['archive_member']);assert len(body)==row['bytes'] and hashlib.sha256(body).hexdigest()==row['sha256']
for name in ['common.py','verify_portable.py']:assert gzip.decompress((D/(name+'.gz')).read_bytes())==(P/name).read_bytes()
assert (D/'README.md').read_bytes()==(P/'REPORT.md').read_bytes()
closures=json.loads(gzip.decompress((D/'external-packet-closures.json.gz').read_bytes()))
assert len(closures)==19 and sum(len(v['external_fixture_owners']) for v in closures)==42015
for row in closures:check(row['handoff']);check(row['manifest'])
# Do not rehash excluded synthetic fixture bodies; their explicit inherited scope is retained.
c.cache_check();assert c.inventory(T,exclude_git=True)==(c.load(P/'baseline-files.json'),c.load(P/'baseline-directories.json'))
c.sealed_check()
out={'status':'passed','subject_artifacts':103,'seals':2,'physical_directories':len(m['directories']),'baseline_files':11469,'baseline_directories':1884,
 'baseline_commit_tree_branch':'inherited from bound clean capture; no fresh Git command','complete_hidden_ignored_baseline_pre_post_exact':True,'cache_entries':800,'cache_pre_post_exact':True,
 'runtime_checked':253,'runtime_differences':27,'primary_owners':30,'dossier_owners':9,'actual_native_outputs_byte_exact':True,'whole_old_objects_order_preserved_with_exact_approved_polymer_exception':True,
 'old_KGX_contexts':7877,'old_edges_payload_and_order_exact':True,'aggregate_changes':graph_changes,'SSSOM_added_rows':rows,'SSSOM_native_row_normalizer_replayed_without_export':True,
 'history_before_render_and_SSSOM_before_gates':True,'gates_planned':9,'helper_AST_rebase_exact':True,'portable_replay':replay,'preparation_archive_members':len(proof['members']),
 'external_fixture_physical_files':42015,'external_fixture_whole_hashes':'inherited; not rehashed','SQL_databases_read':False,'adoption_native_gates_history_Git_GitHub_performed':False,'science':'inherited exact accepted record and prior actual-output audit'}
(R/'audit-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':'passed','primary':30,'dossier':9,'portable_bodies':2907,'SSSOM_added':6,'baseline_cache_unchanged':True}))
