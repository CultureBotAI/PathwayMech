"""Persist successful native review save/verification evidence, losslessly."""
from pathlib import Path
import datetime,gzip,hashlib,json,os
R=Path('/private/tmp/pathwaymech-next-235-local-20261012');REL=Path('research/pathway_additions/2026-10-12-next-235/native-integration/finalization');D=R/REL
assert json.loads(Path('/private/tmp/pathwaymech-next-235-native-review-save-20261012/completion.json').read_bytes())['status']=='all_native_review_save_and_checks_passed'
assert not D.exists()
def pin(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
for source,sub in [(Path('/private/tmp/pathwaymech-next-235-root-native-finalized-20261012'),'native-inputs'),(Path('/private/tmp/pathwaymech-next-235-root-native-finalization-execution-20261012'),'finalize-execution'),(Path('/private/tmp/pathwaymech-next-235-native-review-save-20261012'),'save-and-check')]:
 for base,dirs,files in os.walk(source,followlinks=False):
  assert all(not (Path(base)/n).is_symlink() for n in dirs)
  for n in files:
   p=Path(base)/n;assert p.is_file() and not p.is_symlink();rows.append((p,Path(sub)/p.relative_to(source)))
for name in ['save-native-reviews','adopt-qa-initial','adopt-qa-second','adopt-finalization']:
 p=Path('/private/tmp/pathwaymech-next-235-'+name+'-20261012.py');rows.append((p,Path(name+'.py')))
entries=[];payload=[]
for p,rel in rows:
 b=p.read_bytes();enc=p.suffix in ['.py','.yaml','.stdout','.stderr'] or p.name in ['stdout','stderr'];stored=gzip.compress(b,mtime=0) if enc else b
 dest=Path(str(rel)+'.gz') if enc else rel
 payload.append((D/dest,stored));entries.append({'source':str(p),'owner':str(REL/dest),'encoding':'gzip' if enc else 'identity','original':pin(b),'stored':pin(stored)})
assert len({p for p,b in payload})==len(payload)
D.mkdir()
for p,b in payload:
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 assert p.read_bytes()==b
m={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual native source inspection/validation, two saves, append-only review check, lint and diff-check; original root adoption helper failures retained. No publication.','entries':entries}
(D/'storage-map.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'artifacts':len(entries),'storage_map':pin((D/'storage-map.json').read_bytes())}))
