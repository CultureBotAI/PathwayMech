"""Verify the sealed QA packet, then adopt exact preloaded evidence bodies."""
from pathlib import Path
import os,json,gzip,hashlib,datetime
r=Path('/private/tmp/pathwaymech-next-235-maintained-independent-qa-20261012')
root=Path('/private/tmp/pathwaymech-next-235-local-20261012')
dest=root/'research/pathway_additions/2026-10-12-next-235/native-integration/independent-qa'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
hp=pin(r/'handoff.json');assert hp['sha256']=='1d5499f96a7d061803f7bc575a1aad59607389b38e6117ce211d732f5eea8f88'
h=json.loads((r/'handoff.json').read_bytes());m=json.loads((r/'artifact-manifest.json').read_bytes());assert pin(r/'artifact-manifest.json')==h['manifest']
seen=set()
for a in m['artifacts']:
 p=r/a['relative_path'];assert p.is_relative_to(r) and not p.is_symlink();v=pin(p);assert v['sha256']==a['sha256'] and v['bytes']==a['bytes'];seen.add(a['relative_path'])
actual=set();actual_dirs=set()
for base,ds,fs in os.walk(r,followlinks=False):
 assert all(not (Path(base)/n).is_symlink() for n in ds)
 actual_dirs.add(str(Path(base).relative_to(r)))
 actual.update(str((Path(base)/n).relative_to(r)) for n in fs)
assert actual_dirs==set(m['directories']) and len(actual_dirs)==11
assert actual==seen|{'artifact-manifest.json','handoff.json'} and len(seen)==266
plan=json.loads((r/'copy-plan.json').read_bytes());assert pin(r/'copy-plan.json')==h['copy_plan'];payload=[]
for x in plan['files']:
 p=Path(x['payload_path']);b=p.read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
 if 'source_path' in x:
  raw=gzip.decompress(b) if x['gzip_encoded'] else b
  assert len(raw)==x['decoded_bytes'] and hashlib.sha256(raw).hexdigest()==x['decoded_sha256'];assert raw==Path(x['source_path']).read_bytes()
 else:
  assert p==r/'payload/package-index.json' and x['gzip_encoded'] is False
  index=json.loads(b);assert index['durable_root']==plan['durable_root'] and len(index['files'])==132
 dst=root/x['repository_path'];assert dst.is_relative_to(dest) and not dst.exists();payload.append((dst,b))
assert len(payload)==133 and not dest.exists();dest.mkdir()
for p,b in payload:
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(b)
 assert p.read_bytes()==b
for name in ['artifact-manifest.json','handoff.json','copy-plan.json']:
 p=dest/('external-'+name)
 with p.open('xb') as f:f.write((r/name).read_bytes())
accept={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'independent_maintained_integration_qa_accepted_evidence_adopted','review_handoff':hp,'manifest':h['manifest'],'copy_plan':h['copy_plan'],'closed_artifacts':266,'seals':2,'adopted_payloads':133,'extra_seal_map_files':3,'root_assessment':'Read full independent report, native draft identities/scopes/checks/evidence/limitations and additional scientific/technical assessment summaries; prior full48paragraph100edge disposition assessment inherited unchanged. Full actual-tree adversarial integration assessment has no new findings. All required current gates passed; initial DNS failure preserved. Optional missing assignment shorthand retained only in workflow notes; exact f088 acceptance and current target establish science. Every external packet/payload byte verified including ignored/hidden membership.','findings':[],'harness_correction':'Root37e6f6/1 reused prior manifest path key; current packet uses relative_path. Failure occurred before maintained writes. Changed only manifest-row access and added exact directory comparison; original root helper retained externally.', 'initial_root_helper':pin(Path('/private/tmp/pathwaymech-next-235-adopt-qa-initial-20261012.py')),'next':'Execute inspected finalize_native_inputs.py and native saver/check; no public action implied.'}
p=Path('/private/tmp/pathwaymech-next-235-root-maintained-qa-acceptance-20261012.json')
with p.open('x') as f:json.dump(accept,f,indent=2);f.write('\n')
with (dest.parent/'qa-acceptance.json').open('xb') as f:f.write(p.read_bytes())
with (dest.parent/'adopt-qa.py.gz').open('xb') as f:f.write(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print(json.dumps(pin(p)))
