"""Closed final tree and durable root provenance followed by actual native inspect."""
import datetime,gzip,hashlib,json,os,subprocess,sys
from pathlib import Path
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-235-local-20261012')
P=Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
D='research/pathway_additions/2026-10-12-next-235/native-integration';Q=R/D
sys.path.insert(0,str(P));import common as c
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(p.read_bytes())
assert pin(Q/'root-storage-map.json')['sha256']=='3983020585478463feef35499a2db12e1be60d32f694a02e35d92019a9285e22'
storage=load(Q/'root-storage-map.json');entries=storage['entries'];assert len(entries)==100
for row in entries:
 p=R/row['owner'];stored=c.regular_bytes(p);assert (len(stored),sha(stored))==(row['stored']['bytes'],row['stored']['sha256'])
 body=gzip.decompress(stored) if row['encoding']=='gzip' else stored
 assert row['encoding'] in ('identity','gzip') and (len(body),sha(body))==(row['original']['bytes'],row['original']['sha256'])
 assert body==Path(row['source']).read_bytes()
baseline=load(P/'baseline-files.json');before={r['path']:r for r in baseline};plan=load(P/'plan.json');stages=load(P/'stages.json')
changes={r['destination']:r for r in plan['changes']};generated=set(stages['allowed_generated_paths'])
after,dirs=c.inventory(R,exclude_git=True);by={r['path']:r for r in after}
histories={p for p in by if p.startswith('history/') and p.endswith('.yaml') and p not in before};assert len(histories)==2
durable={row['owner'] for row in entries}|{D+'/README.md',D+'/root-storage-map.json'}
assert set(by)==set(before)|set(changes)|generated|histories|durable
for p,row in before.items():
 if p not in changes and p not in generated:assert by[p]==row,p
for p,row in changes.items():assert by[p]=={'path':p,'type':'regular','bytes':row['payload']['bytes'],'sha256':row['payload']['sha256'],'executable':row['executable']}
expected_dirs=set(load(P/'baseline-directories.json'))
for path in set(changes)|generated|histories|durable:expected_dirs.update(str(p) for p in Path(path).parents if str(p)!='.')
assert set(dirs)==expected_dirs;c.cache_check()
result={'status':'full_actual_tree_and_durable_root_map_verified','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_files':len(before),'actual_files':len(by),'actual_directories':len(dirs),'mapped_root_artifacts':100,'root_storage_map':pin(Q/'root-storage-map.json'),'new_histories':[by[p] for p in sorted(histories)],'all_800_cache_identities_unchanged':True,'ignored_hidden_inclusive':True,'git_administrative_metadata_excluded':True,'no_unexplained_files_directories_or_changes':True,'source_originals_and_stored_or_decoded_bodies_identical':True}
(O/'full-tree-check.json').write_text(json.dumps(result,indent=2)+'\n')
targetroot=Path('/private/tmp/pathwaymech-next-235-root-maintained-qa-20261012')
inputs=sorted(durable|{x['destination'] for x in plan['changes'] if x['destination'].startswith('research/')}|generated|histories|{'docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','docs/record-review-profile.md','schema/record_review.yaml','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml','src/pathwaymech/kgx.py','src/pathwaymech/graph_view.py','.claude/skills/review-yaml-record/SKILL.md'})
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(R/'src')+':'+str(R)}
for typ in ('scientific','technical'):
 targets=load(targetroot/(typ+'-targets.json'))
 if typ=='scientific':targets['targets'][0]['label']='nitrate reduction VIII (dissimilatory)'
 targetfile=O/(typ+'-targets.json');targetfile.write_text(json.dumps(targets,indent=2)+'\n')
 argv=[sys.executable,'-B','scripts/record_review.py','inspect','--targets',str(targetfile)]
 extras=['data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json'] if typ=='scientific' else ['data/pathways/nitrate-reduction-viii.yaml']
 for p in sorted(set(inputs+extras)):argv+=['--input',p]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=R,env=env,capture_output=True)
 (O/(typ+'-inspect.json')).write_bytes(r.stdout);(O/(typ+'-inspect.stderr')).write_bytes(r.stderr)
 receipt={'argv':argv,'cwd':str(R),'environment':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','PYTHONNOUSERSITE','UV_NO_SYNC','PYTHONPATH')},'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':pin(O/(typ+'-inspect.json')),'stderr':pin(O/(typ+'-inspect.stderr'))}
 (O/(typ+'-inspect.execution.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 assert r.returncode==0
 data=json.loads(r.stdout);assert data['source']['git_revision']==c.BASE
 for x in data['source']['inputs']:assert sha((R/x['path']).read_bytes())==x['sha256']
 print(typ,'actual native inspection',len(data['targets']),'targets',len(data['source']['inputs']),'inputs')
print(json.dumps(result))
