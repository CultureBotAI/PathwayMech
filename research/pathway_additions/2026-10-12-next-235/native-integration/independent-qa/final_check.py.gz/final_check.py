import gzip,hashlib,json
from pathlib import Path
import yaml
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-235-local-20261012');D='research/pathway_additions/2026-10-12-next-235/native-integration/independent-qa'
def sha(b):return hashlib.sha256(b).hexdigest()
idx=json.loads(gzip.decompress((R/'research/pathway_additions/2026-10-12-next-235/evidence-index.json.gz').read_bytes()))
result={}
for kind in ['scientific','technical']:
 doc=yaml.safe_load((O/(kind+'-review.yaml')).read_bytes());count=0
 for item in doc['source']['inputs']:assert sha((R/item['path']).read_bytes())==item['sha256']
 for e in doc['evidence']:
  if e.get('locator','').startswith('body_lookup'):assert e['snapshot_sha256'] in idx['body_lookup']
  elif e['reference'].startswith(D+'/'):assert sha((O/e['reference'][len(D)+1:]).read_bytes())==e['snapshot_sha256']
  elif e.get('snapshot_sha256'):assert sha((R/e['reference']).read_bytes())==e['snapshot_sha256']
  count+=1
 assert not doc['findings'] and doc['completion']=='completed'
 assert all(c['status']=='passed' for c in doc['checks'] if c['required'])
 assert len(doc['targets'])==(1 if kind=='scientific' else 29)
 result[kind]={'inputs_unchanged':len(doc['source']['inputs']),'evidence_bindings_resolved':count,'assessments':len(doc['assessments']),'findings':0,'draft_sha256':sha((O/(kind+'-review.yaml')).read_bytes())}
out={'status':'both_final_native_drafts_all_input_and_evidence_bindings_passed','results':result,'native_reviews_saved':False}
(O/'final-draft-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
