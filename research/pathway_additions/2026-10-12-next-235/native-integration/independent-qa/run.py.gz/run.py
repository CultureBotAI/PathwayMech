import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-235-local-20261012')
name=sys.argv[1];argv=[sys.executable,'-B',*sys.argv[2:]]
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(R/'src')+':'+str(R)}
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (O/(name+'.stdout')).open('xb') as out,(O/(name+'.stderr')).open('xb') as err:r=subprocess.run(argv,cwd=R,env=env,stdout=out,stderr=err)
receipt={'argv':argv,'cwd':str(R),'env_overrides':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','PYTHONNOUSERSITE','UV_NO_SYNC','PYTHONPATH')},'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':pin(O/(name+'.stdout')),'stderr':pin(O/(name+'.stderr'))}
with (O/(name+'.execution.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt));raise SystemExit(r.returncode)
