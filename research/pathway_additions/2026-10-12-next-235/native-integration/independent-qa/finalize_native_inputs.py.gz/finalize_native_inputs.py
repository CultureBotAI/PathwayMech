"""After exact evidence adoption, extend native input attestations without altering judgments.

This helper does not save a maintained review. It verifies every originally inspected
input, hashes each newly adopted evidence file against the sealed copy plan, and uses
the native inspect and validate CLI. Finished times, identity, assessments, findings,
checks and all other review contents remain unchanged.
"""
import argparse,hashlib,json,os,subprocess,yaml
from pathlib import Path
class NoAliasDumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
def dump_yaml(data,**kwargs):return yaml.dump(data,Dumper=NoAliasDumper,**kwargs)

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--draft-directory',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
R=a.root;D=a.draft_directory;O=a.output
if O.exists():raise SystemExit('New output directory required')
plan=json.loads((D/'copy-plan.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for row in plan['files']:
 path=R/row['repository_path'];b=path.read_bytes()
 if (len(b),sha(b))!=(row['bytes'],row['sha256']):raise SystemExit('Adopted evidence mismatch: '+str(path))
core=['audit.json','evidence-bindings.json','portable.stdout','full-tree-check.json','static-visual.json','REPORT.md','package-index.json']
extra=[plan['durable_root']+'/'+x for x in core]
extra += [row['repository_path'] for row in plan['root_evidence']]
# Gate/visual bodies were reviewed before the packet seal; each is separately bound here.
for row in plan['root_evidence']:
 b=(R/row['repository_path']).read_bytes()
 if (len(b),sha(b))!=(row['bytes'],row['sha256']):raise SystemExit('Root evidence mismatch')
py='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python';env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(R/'src')+':'+str(R)}
O.mkdir()
for kind in ('scientific','technical'):
 doc=yaml.safe_load((D/(kind+'-review.yaml')).read_bytes());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
 if doc['source']['git_revision']!=head:raise SystemExit('Git base changed; independent reassessment needed')
 for item in doc['source']['inputs']:
  if sha((R/item['path']).read_bytes())!=item['sha256']:raise SystemExit('Original reviewed input changed')
 targetfile=O/(kind+'-targets.yaml');targetfile.write_text(dump_yaml({'targets':doc['targets']},sort_keys=False))
 args=[py,'-B','scripts/record_review.py','inspect','--targets',str(targetfile)]
 for name in sorted({x['path'] for x in doc['source']['inputs']}|set(extra)):args+=['--input',name]
 r=subprocess.run(args,cwd=R,env=env,capture_output=True);(O/(kind+'-inspect.stdout')).write_bytes(r.stdout);(O/(kind+'-inspect.stderr')).write_bytes(r.stderr)
 if r.returncode:raise SystemExit(r.returncode)
 native=json.loads(r.stdout)
 # Preserved existing input roles are supplied by the same native target specification.
 old={x['path']:x for x in doc['source']['inputs']};new={x['path']:x for x in native['source']['inputs']};assert all(new[k]==v for k,v in old.items())
 doc['source']=native['source'];output=O/(kind+'-review.yaml');output.write_text(dump_yaml(doc,sort_keys=False,allow_unicode=True,width=100))
 r=subprocess.run([py,'-B','scripts/record_review.py','validate',str(output)],cwd=R,env=env,capture_output=True);(O/(kind+'-validate.stdout')).write_bytes(r.stdout);(O/(kind+'-validate.stderr')).write_bytes(r.stderr)
 if r.returncode:raise SystemExit(r.returncode)
 print(str(output))
print('Fresh native inspect/validation complete; saving remains a separate root action.')
