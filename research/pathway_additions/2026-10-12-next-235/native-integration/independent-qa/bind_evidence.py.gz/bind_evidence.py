"""Fresh review closure and actual root command provenance; no maintained writes."""
import datetime,hashlib,json,os,stat
from pathlib import Path
from lxml import html
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-235-local-20261012')
S=Path('/private/tmp/pathwaymech-next-235-science-review-20261012')
G=Path('/private/tmp/pathwaymech-next-235-local-native-execution-20261012')
P=Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(p.read_bytes())
def verify(row,p=None):
 a=pin(Path(p or row['path']));assert (a['bytes'],a['sha256'])==(row['bytes'],row['sha256']);return a
def close(root,h,m):
 assert pin(root/'handoff.json')['sha256']==h and pin(root/'artifact-manifest.json')['sha256']==m
 manifest=load(root/'artifact-manifest.json');expected=set();links=0
 for row in manifest['artifacts']:
  p=root/row['relative_path'] if 'relative_path' in row else Path(row['path'])
  rel=str(p.relative_to(root));assert rel not in expected;expected.add(rel);mode=p.lstat().st_mode
  if stat.S_ISLNK(mode):
   links+=1;assert os.readlink(p)==row['link_text'];assert str(p.resolve())==row['resolved_path']
  else:assert stat.S_ISREG(mode)
  verify(row,p)
 actual=set();dirs=[]
 for base,ds,fs in os.walk(root,followlinks=False):
  for n in list(ds):
   p=Path(base)/n
   if p.is_symlink():actual.add(str(p.relative_to(root)));ds.remove(n)
   else:dirs.append(str(p.relative_to(root)))
  actual.update(str((Path(base)/n).relative_to(root)) for n in fs)
 assert actual==expected|{'handoff.json','artifact-manifest.json'}
 if 'directories' in manifest:assert sorted(dirs+(['.'] if '.' in manifest['directories'] else []))==sorted(manifest['directories'])
 return dict(root=str(root),handoff=pin(root/'handoff.json'),manifest=pin(root/'artifact-manifest.json'),artifacts=len(expected),seals=2,literal_links=links,hidden_ignored_included=True)
closures=[close(S,'8123d4488e39a7590ec5dadad81989aac22ffecd32d22d1c1723222345887f4f','1c2e3b402cf45385fe0e59a29919bdb2bfd174f27b58bf8a8cb712cb2977740b'),close(Path('/private/tmp/pathwaymech-next-235-local-integration-independent-review-20261012'),'545b245573896d24efa0e0ad29ca5adea44ab59f6aa559fd2525dcd393ea9606','c2a93d3e4fa95654456400987685a92631efcfc44477e181463018ba3417d732')]
receipts=[];copies=[]
for phase,name in [('history-and-generation','completion.json'),('remaining-gates','failure.json'),('network-resumption','completion.json')]:
 doc=load(G/phase/name);assert doc['status']==('phase_failed' if phase=='remaining-gates' else 'phase_passed')
 out=O/'actual-root-execution'/phase;out.mkdir(parents=True)
 for ex in doc['receipts']:
  receipt=G/phase/(ex['name']+'.execution.json');assert load(receipt)==ex
  for key in ('stdout','stderr'):verify(ex[key])
  for p in (receipt,Path(ex['stdout']['path']),Path(ex['stderr']['path'])):
   q=out/p.name;q.write_bytes(p.read_bytes());copies.append({'original':pin(p),'copy':pin(q)})
  receipts.append(dict(phase=phase,receipt=ex))
 q=out/name;q.write_bytes((G/phase/name).read_bytes());copies.append({'original':pin(G/phase/name),'copy':pin(q)})
passed=[x for x in receipts if x['receipt']['exit_code']==0];failed=[x for x in receipts if x['receipt']['exit_code']!=0]
assert len(passed)==12 and len(failed)==1 and failed[0]['receipt']['name']=='vendored'
assert 'nodename nor servname provided' in Path(failed[0]['receipt']['stderr']['path']).read_text()
names={x['receipt']['name']:x['receipt'] for x in passed}
stages=load(P/'stages.json')
assert set(x['name'] for x in stages['nine_fresh_gates'])<=names.keys()
for x in stages['nine_fresh_gates']:assert names[x['name']]['argv']==x['argv']
assert names['vendored']['argv']==failed[0]['receipt']['argv']
assert names['history-1']['finished_at']<names['history-2']['started_at']<names['sssom']['started_at']<names['render']['started_at']
assert '3977 passed, 3 skipped, 3 warnings' in Path(names['tests']['stdout']['path']).read_text()
visual=Path('/private/tmp/pathwaymech-next-235-graph-preview-20261012');v=load(visual/'visual-assessment.json')
for row in v['inputs']:verify(row)
a=html.fromstring((R/'pages/records/MetaCyc_PWY0-1352.html').read_bytes()).xpath('//svg[@class="pathway-network-svg"]')[0]
b=html.fromstring((visual/'records/MetaCyc_PWY0-1352.html').read_bytes()).xpath('//svg[@class="pathway-network-svg"]')[0]
assert html.tostring(a)==html.tostring(b)
visual_result={'status':'fresh_static_preview_view_and_actual_SVG_identity_checked','view_tool':'functions.exec view_image graph.png, tool result a6ad12-associated image','image':pin(visual/'graph.png'),'actual_page':pin(R/'pages/records/MetaCyc_PWY0-1352.html'),'preview_page':pin(visual/'records/MetaCyc_PWY0-1352.html'),'actual_and_preview_SVG_equal':True,'observations':'Full graph extent and colored protein/complex, compound, reaction and pathway nodes visible. Dense shared edge junctions and overlapping labels limit readability; individual claims remain fully available in the checked table. Four construct nodes remain distinct.','limitations':['Static raster from earlier root rendering, freshly viewed here; whole actual SVG equals preview SVG. No fresh raster rendering or interactive browser/keyboard/JavaScript execution.','View image downscales the full raster; exact text completeness is established by DOM correspondence, not visual resolution.']}
(O/'static-visual.json').write_text(json.dumps(visual_result,indent=2)+'\n')
prior={}
for key,name in [('scientific-review','REPORT.md'),('paragraph-assessments','paragraph-assessments.json'),('edge-assessments','edge-assessments.json'),('scientific-dispositions','finding-dispositions.json')]:prior[key]=pin(S/name)
for key,root in [('integration-preparation-review','/private/tmp/pathwaymech-next-235-local-integration-independent-review-20261012'),('actual-output-review','/private/tmp/pathwaymech-next-235-canonical-output-independent-review-20261012')]:prior[key]=pin(Path(root)/'REPORT.md')
acceptances=[pin(Path('/private/tmp')/f'pathwaymech-next-235-root-{x}-acceptance-20261012.json') for x in ('scientific','implementation','canonical-output','local-adoption')]
result={'status':'prior_review_closures_and_actual_root_receipts_verified','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'closures':closures,'prior_reviews':prior,'root_acceptances':acceptances,'root_passed_commands':12,'root_required_gates':9,'root_historical_failed_attempts':1,'history_before_render':True,'fullsuite':{'passed':3977,'skipped':3,'warnings':3},'receipts':receipts,'copies':copies,'visual':pin(O/'static-visual.json'),'scientific_source_interpretation':'Inherited explicitly from complete accepted independent review, not fresh whole-paper reading.'}
(O/'evidence-bindings.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'closure_artifacts':[x['artifacts'] for x in closures],'root_passed_commands':12,'root_required_gates':9}))
