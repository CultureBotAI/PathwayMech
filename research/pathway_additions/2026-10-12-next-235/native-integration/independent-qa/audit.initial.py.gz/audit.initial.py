"""Independent maintained nitrate audit. Read-only outside this packet."""
import csv,datetime,gzip,hashlib,io,json,os,stat,subprocess,sys
from collections import Counter
from pathlib import Path
from lxml import html
import yaml
R=Path('/private/tmp/pathwaymech-next-235-local-20261012');O=Path(__file__).parent
P=Path('/private/tmp/pathwaymech-next-235-local-integration-preparation-20261012')
B=Path('/private/tmp/pathwaymech-next-235-canonical-build-20261012')
S=Path('/private/tmp/pathwaymech-next-235-science-review-20261012')
BASE='5ff01d7c59c61fd94b65b907edd50936193f7f17';RID='MetaCyc:PWY0-1352'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(p.read_bytes())
def stable(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def canonical(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def gitbody(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
def rows(b):return list(csv.DictReader(io.StringIO('\n'.join(s for s in b.decode().splitlines() if not s.startswith('#'))),delimiter='\t'))
def texts(e):return ''.join(e.itertext())
checks=[]
def check(name,value):
 checks.append(dict(name=name,passed=bool(value)))
 if not value:raise AssertionError(name)
def main():
 check('base HEAD',subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE)
 check('task branch',subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='feat/pathway-next-235-local-20261012')
 target=R/'data/pathways/nitrate-reduction-viii.yaml';d=yaml.safe_load(target.read_bytes())
 check('exact accepted science',sha(target.read_bytes())=='019deb06b1b58ae9c378b209a9e3815b6357685e13e6e3345b8be01aaf13f5de')
 ps=load(S/'paragraph-assessments.json');es=load(S/'edge-assessments.json');pars=d['description'].split('\n\n')
 check('48 complete paragraphs',len(ps)==len(pars)==48)
 for p,a in zip(pars,ps):check(a['id'],sha(p.encode())==a['successor_text_sha256'])
 check('100 complete edges',len(es)==len(d['mechanistic_edges'])==100)
 for e,a in zip(d['mechanistic_edges'],es):check(a['edge_id'],e['id']==a['edge_id'] and sha(canonical(e).encode())==a['whole_edge_sha256'])
 sys.path[:0]=[str(R/'src'),str(R)]
 from pathwaymech.schema import validate_record
 validate_record(d)
 page=R/'pages/records/MetaCyc_PWY0-1352.html';dom=html.fromstring(page.read_bytes());alltext=texts(dom)
 ids=dom.xpath('//*[@id]/@id');check('unique page IDs',len(ids)==len(set(ids)))
 for link in dom.xpath('//@href'):
  if link.startswith('#'):check('anchor '+link,link[1:] in ids)
 check('whole description retained',d['description'] in alltext)
 graph=dom.xpath('//a[contains(concat(" ",@class," ")," graph-edge ")]')
 nodes=dom.xpath('//a[contains(concat(" ",@class," ")," graph-node ")]')
 check('67 nodes and 100 arrows',len(nodes)==67 and len(graph)==100)
 refids=[r['id'] for r in d['references']];qualifiers=0
 for i,(e,g) in enumerate(zip(d['mechanistic_edges'],graph),1):
  anchor=f'mechanism-edge-{i}';row=dom.get_element_by_id(anchor);cells=row.findall('td')
  check(e['id']+' table',len(cells)==4 and cells[0].find('code').text==e['subject'] and cells[2].find('code').text==e['object'] and cells[1].text==e['predicate'] and cells[1].find('p').text==e['description'])
  check(e['id']+' arrow',g.get('href')=='#'+anchor and g.get('data-predicate')==e['predicate'])
  endpoints={k:e[k] for k in ('subject','object')}
  for q in e.get('endpoint_qualifiers',[]):
   qualifiers+=1;role=q['endpoint'];endpoints[role]=f'qualified-endpoint-{i}-{role}'
   qt=texts(dom.get_element_by_id(anchor+'-qualifier-'+role))
   check(e['id']+' qualifier',q['description'] in qt and g.get('data-'+role+'-id')==e[role])
   for ev in q['evidence']:
    for key in ('reference_id','quote','source_assertion','source_locator'):
     if key in ev:check(e['id']+' qualifier '+key,ev[key] in qt)
  for role,value in endpoints.items():check(e['id']+' endpoint '+role,g.get('data-'+role)==value)
  evidence=cells[3].xpath('./ul/li');check(e['id']+' evidence count',len(evidence)==len(e['evidence']))
  for ev,li in zip(e['evidence'],evidence):
   check(e['id']+' reference link',li.find('a').text==ev['reference_id'] and li.find('a').get('href')=='#reference-'+str(refids.index(ev['reference_id'])+1))
   for key in ('quote','source_assertion','source_locator'):
    if key in ev:check(e['id']+' evidence '+key,ev[key] in texts(li))
 check('4 endpoint qualifiers',qualifiers==4)
 named=[{'id':d['id'],'label':d['label']}]+[n for k in ('taxa','participants','reactions') for n in d[k]]
 check('64 named IDs',len(named)==64)
 for n in named:
  if n['id']=='NCBITaxon:562':check('unconnected taxon table',n['id'] in alltext);continue
  matches=[x for x in nodes if x.get('data-node-id')==n['id']]
  check('node '+n['id'],len(matches)==1 and matches[0].get('data-node-label')==n['label'])
 index=load_gz(R/'research/pathway_additions/2026-10-12-next-235/evidence-index.json.gz')
 for i,ref in enumerate(d['references'],1):
  el=dom.get_element_by_id('reference-'+str(i));t=texts(el)
  check('rendered reference '+ref['id'],all(ref[k] in t for k in ('id','title','source_version')) and ref['url'] in el.xpath('.//a/@href'))
  check('portable reference '+ref['id'],ref['source_sha256'] in index['body_lookup'])
 plan=load(P/'plan.json');stages=load(P/'stages.json');changed={r['destination']:r for r in plan['changes']};generated=set(stages['allowed_generated_paths'])
 baseline=load(P/'baseline-files.json');groups=Counter()
 for row in baseline:
  rel=row['path']
  if rel in changed or rel in generated:continue
  q=R/rel
  if row['type']=='regular':check('old file '+rel,q.is_file() and not q.is_symlink() and pin(q)['sha256']==row['sha256'] and bool(q.stat().st_mode&0o111)==row['executable'])
  elif row['type']=='symlink':check('old link '+rel,q.is_symlink() and os.readlink(q)==row['link_text'])
  for group in ('data/pathways/','pages/records/','history/','reviews/structured/'):
   if rel.startswith(group) and rel.endswith(('.yaml','.md','.html')):groups[group]+=1
 for rel,row in changed.items():check('exact owner '+rel,pin(R/rel)['sha256']==row['payload']['sha256'])
 comp=load(B/'comparison.json');authority={}
 for name in ('sources','ontology'):
  rel=f'data/identifier_authorities/{name}.json';new=load(R/rel);old=json.loads(gitbody(rel));check('native '+name,(R/rel).read_bytes()==(B/(name+'.json')).read_bytes());check(name+' outer order',list(new)==list(old))
  for section in ('sources','terms'):
   check(name+section+' order',[k for k in new[section] if k in old[section]]==list(old[section]))
   for k,v in old[section].items():
    expected=comp['only_old_owner_addition']['expected_after'] if (name,section,k)==('sources','sources','pwy234-rhea-polymer-142') else v
    check(name+section+k,stable(new[section][k])==stable(expected))
  authority[name]={k:len(new[k]) for k in ('sources','terms')}
 oldmanifest=json.loads(gitbody('conf/identifier_sources.json'));newmanifest=load(R/'conf/identifier_sources.json')
 check('manifest831 ordered prefix of844',len(oldmanifest)==831 and len(newmanifest)==844 and stable(newmanifest[:831])==stable(oldmanifest))
 contexts=0;aggregate=[];kgx={}
 for name in ('nodes','edges'):
  after=(R/f'pages/downloads/{name}.tsv').read_bytes();check(name+' full actual parity',after==(B/f'actual-kgx/{name}.tsv').read_bytes()==(R/f'output/kgx/{name}.tsv').read_bytes())
  old=rows(gitbody(f'pages/downloads/{name}.tsv'));new=rows(after);before={r['id']:r for r in old};by={r['id']:r for r in new};kgx[name]=len(new)
  check(name+' identity membership',len(before)==len(old) and len(by)==len(new) and set(before)<=set(by))
  if name=='edges':check('11803 old whole edges and order',[r for r in new if r['id'] in before]==old and len(old)==11803)
  else:
   for k,row in before.items():
    prior=json.loads(row['source_contexts']);current=json.loads(by[k]['source_contexts']);contexts+=len(prior)
    check('whole old contexts '+k,[c for c in current if c['record_id']!=RID]==prior)
    delta={a:{'before':v,'after':by[k][a]} for a,v in row.items() if a!='source_contexts' and v!=by[k][a]}
    if delta:aggregate.append({'id':k,'fields':delta})
 check('7877 old contexts',contexts==7877)
 check('only approved HCN aggregate delta',aggregate==[{'id':'CHEBI:18407','fields':{'category':{'before':'biolink:ChemicalEntity','after':'biolink:ChemicalEntity|biolink:SmallMolecule'},'source_category':{'before':'chemical_entity','after':'chemical_entity|small_molecule'}}}])
 oldss=rows(gitbody('output/sssom/source_mappings.sssom.tsv'));newss=rows((R/'output/sssom/source_mappings.sssom.tsv').read_bytes());added=[r for r in newss if r['source_pathway_id']==RID]
 check('old SSSOM order preserved',[r for r in newss if r['source_pathway_id']!=RID]==oldss)
 check('six exact new SSSOM rows',len(added)==6 and Counter(stable(r) for r in added)==Counter(stable(r) for r in load(P/'semantic-preservation.json')['SSSOM']['expected_added_rows']))
 return dict(status='all_fresh_maintained_checks_passed',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),target=pin(target),page=pin(page),paragraphs=48,edges=100,qualifiers=4,references=107,named_ids=64,graph_nodes=67,baseline_files_checked=len(baseline),old_groups=dict(groups),exact_owners=len(changed),authority=authority,manifest_rows=844,KGX=kgx,old_contexts=contexts,aggregate_delta=aggregate,SSSOM_added=6,checks=checks)
def load_gz(p):return json.loads(gzip.decompress(p.read_bytes()))
try:
 result=main();(O/'audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False))
except BaseException as e:
 (O/'audit-failure.json').write_text(json.dumps(dict(error=repr(e),checks=checks),indent=2)+'\n');raise
