"""Validate final external drafts, create a portable copy plan, and seal this packet."""
import datetime,gzip,hashlib,json,os,stat,subprocess,sys
from pathlib import Path
import yaml
O=Path(__file__).parent;R=Path('/private/tmp/pathwaymech-next-235-local-20261012');D='research/pathway_additions/2026-10-12-next-235/native-integration/independent-qa'
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(p.read_bytes())
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,ensure_ascii=False);f.write('\n')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(R/'src')+':'+str(R)}
# The pre-final process-note edit changed no scientific judgments, but receives fresh validation.
validations=[]
for typ in ('scientific','technical'):
 p=O/(typ+'-review.yaml');doc=yaml.safe_load(p.read_bytes())
 for row in doc['source']['inputs']:assert sha((R/row['path']).read_bytes())==row['sha256']
 argv=[sys.executable,'-B','scripts/record_review.py','validate',str(p)];start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,cwd=R,env=env,capture_output=True)
 out=O/(typ+'-sealed-validate.stdout');err=O/(typ+'-sealed-validate.stderr');out.write_bytes(r.stdout);err.write_bytes(r.stderr)
 receipt={'argv':argv,'cwd':str(R),'environment':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','PYTHONNOUSERSITE','UV_NO_SYNC','PYTHONPATH')},'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'draft':pin(p),'stdout':pin(out),'stderr':pin(err)}
 write(O/(typ+'-sealed-validate.execution.json'),receipt);validations.append(receipt);assert r.returncode==0
old=O/'final-draft-check.json';(O/'final-draft-check.binding-corrected.json').write_bytes(old.read_bytes())
argv=[sys.executable,'-B',str(O/'final_check.py')];r=subprocess.run(argv,cwd=R,env=env,capture_output=True)
(O/'sealed-final-check.stdout').write_bytes(r.stdout);(O/'sealed-final-check.stderr').write_bytes(r.stderr);assert r.returncode==0
write(O/'sealed-final-check.execution.json',{'argv':argv,'cwd':str(R),'exit_code':r.returncode,'stdout':pin(O/'sealed-final-check.stdout'),'stderr':pin(O/'sealed-final-check.stderr'),'result':pin(O/'final-draft-check.json')})
audit=load(O/'audit.json');tree=load(O/'full-tree-check.json');replay=load(O/'portable.stdout')
report=f'''Recommend accepting the actual maintained nitrate integration with no new actionable finding. Both external native review drafts validate. This review includes the complete actual-tree adversarial integration assessment before native review saves; root owns later evidence adoption, append-only save/check and local commit.

The maintained target is SHA256 019deb06b1b58ae9c378b209a9e3815b6357685e13e6e3345b8be01aaf13f5de (145,409 bytes). I freshly read all 2,550 YAML lines, the complete earlier independent scientific report/disposition, all 48 paragraph judgments and all 100 edge judgments. Exact current paragraph and whole-edge hashes match every accepted assessment. Full scientific interpretation remains inherited from the accepted review: six complete main bodies, two original spreadsheets, native/UniProt source objects and bounded older abstracts. No new full-paper or source-exhaustion claim is made. The issue498 phrase correction, native/Rhea/composite boundaries, generic carriers, nested assemblies, conflicting Nar stoichiometries, cofactor evidence tiers, constructs and assay limits all remain explicit. e083's shortened source excerpt remains the already documented presentation limit, with its complete source body preserved.

Fresh content/preservation audit passes {len(audit['checks']):,} checks. Every rendered graph arrow/table row and its complete evidence, every reference and qualifier, every named incident node, unique HTML IDs and local anchor targets match the current YAML. Whole description text survives rendering. There are 67 visual nodes, 100 arrows, four distinct qualified construct states, 64 named identities and 107 references; the unconnected taxon remains in the component table. I freshly viewed the complete earlier static graph raster and proved the actual maintained SVG equals its preview SVG. Dense junction labels overlap; the complete table retains all assertions. No interactive browser or fresh raster-generation execution is claimed.

Every unchanged baseline file was compared to the accepted hidden/ignored-inclusive inventory. The fresh final physical census after root evidence adoption contains {tree['actual_files']:,} files and {tree['actual_directories']:,} directories, with exactly the baseline, 39 planned owner replacements/additions, permitted generated paths, two histories and 100 mapped root artifacts plus README/map. No unexplained path, type, executable mode or directory change remains. All 800 shared-cache identities are unchanged. All 235 previous records/pages, 398 old history YAMLs and 114 old structured review pairs remain exact. Git administrative metadata is excluded from the physical contract; read-only Git confirmed base 5ff01d7c59c61fd94b65b907edd50936193f7f17 and the task branch.

Both complete native authority bodies equal the accepted actual outputs: sources 2,603 terms/667 owners, ontology 2,004 terms/five owners. Every old object and nested/outer relative order remains exact, except the already approved addition of polymer9537/9539 to the existing owner map. Old UniProt objects and first-owner provenance remain unchanged. The old831 manifest rows remain an exact ordered prefix of844. Adapter implementation interpretation is inherited from accepted independent runtime/output reviews; no new line-by-line production review is claimed here.

Both maintained KGX surfaces exactly equal the accepted actual native files: 4,260 nodes and 11,903 edges. All 11,803 old edge payloads and relative order and all 7,877 old whole node contexts, their order and multiplicity survive. Only the approved hydrogen-cyanide aggregate category/source-category union changes. Expected node first-encounter ordering is not confused with authority or edge-order preservation. All21 old SSSOM rows/order remain, with exactly six expected nitrate rows.

Fresh adopted portable replay retrieves all2,907 whole bodies (360,050,720 decoded bytes) through six archives and repository owners, covering11,373 path views and4,192 inert literal-link views. No external original retrieval, extraction or link recreation occurs. All107 record reference hashes resolve. Root's durable storage map has100 entries, each checked against its original and exact stored/decoded bytes. Fresh independent closure of the earlier science340+2 and preparation-review19+2 packets passes. Large excluded reproducible fixtures and full SQL remain the stated external/inherited requirements; no22GB SQL rehash was repeated.

All nine required root-owned gates passed. Actual execution reports3,977 tests passed, three skipped and three dependency warnings. Both native histories preceded SSSOM and first rendering. I checked all13 original command receipts and streams, including the original sandbox-DNS vendored failure, and its successful exact-command public-read retry. The failure remains distinct; no successful full-suite run was repeated or invented. Copies of all command receipts/streams are retained here, and the maintained storage map provides durable resolution.

Scientific and technical native inspect ran freshly against actual durable inputs and real Git state. The scientific draft has152 positive assessments:48paragraphs,100edges and four boundary/representation assessments. The technical draft has34 assessments across29 individual owners and five integration topics. Every target/input/evidence binding is checked; no fabricated predecessor occurrence or native save is present. The captured review interval begins after earlier context reads; actual inspection/drafting times are retained. Native schema validation emits only the existing topClass deprecation notice.

Reviewer harness history is retained. Initial audit incorrectly expected a dedicated source_pathway_id TSV column instead of native comment metadata; corrected check passed without product change. Initial closure checker excluded the literal root '.' used by the earlier packet's directory list; corrected convention passed. Intermediate drafts pointed the later preparation-review report at the earlier portable index; final drafts correctly cite its durable mapped owner. Initial and corrected scripts/drafts/streams remain. Other tool-only diagnostics include a stopped overbroad inventory, nonexistent guessed helper paths, an unrelated protected temporary path in a top-level probe and truncated reads subsequently completed in smaller calls. No diagnostic is represented as a product failure or full persisted stream when only tool output exists.

One assignment shorthand, a019… scientific acceptance, was not found among35 matching nitrate top-level JSON candidates using an ignored-independent nonrecursive inventory. This is a workflow clarification, not a scientific limitation: exact root scientific acceptance f088637b19006dd3a2b9cca2594c814db7ec7a75aee7b59b28fef18d46d9fd0d, current-target SHA019deb06…, actual-output acceptance and local-adoption acceptance establish the lineage. No missing acceptance was invented.

Only this external packet was written. The copy plan preserves original bodies or lossless gzip encodings. Root can adopt it, run finalize_native_inputs.py with a fresh output directory to add the adopted QA evidence to native source.inputs without changing judgments, then save/check both native reviews and verify append-only changes. Public push/PR/merge and issue closure are outside this review.
'''
(O/'REPORT.md').write_text(report)
write(O/'execution-notes.json',{'actual_commands':'See each execution.json and exact stdout/stderr; early read diagnostics below are tool-only, not invented streams.','harness_failures':[{'command':'audit','failure':'KeyError source_pathway_id; native SSSOM provenance is in comment','retained_script':'audit.initial.py','corrected_receipt':'audit-corrected.execution.json'},{'command':'binding','failure':'Earlier manifest directories includes literal root dot','retained_script':'bind_evidence.initial.py','corrected_receipt':'binding-corrected.execution.json'},{'tool':'db4b22','failure':'Intermediate native draft preparation-review evidence used earlier index; not an indexed body','retained':'*.initial.yaml and *.binding-corrected.yaml; final resolves durable root owner'}],'read_diagnostics':[{'tool':'13048 / f44d74','description':'Overbroad /private/tmp rg inventory stopped; not used as complete absence proof.'},{'tool':'2add91','description':'Combined read truncated; full needed reports and serializer later reread.'},{'tools':['052930','434d5d'],'description':'Guessed fresh_gates.py and scripts/validate_identifiers.py did not exist; actual functions discovered with ignored-inclusive exact-directory reads.'},{'tool':'7650bb','description':'No matching optional visual directory glob; real graph-preview path discovered and read.'},{'tool':'836a01','description':'Top-level candidate probe tested unrelated protected daemon before filtering; corrected filename-first probe checked35 matching JSONs and found no a019 shorthand.'}],'process_clarification':'Optional a019 shorthand absent; exact accepted f088/current-target/output/adoption lineage used, with no fabricated predecessor.','full_source_reading':'Inherited; complete current record and inherited per-item judgments freshly read.','native_validation_deprecation':'topClass is deprecated - use top_class','no_maintained_or_cache_mutations':True})
write(O/'package-execution.json',{'argv':[sys.executable,'-B',str(Path(__file__))],'cwd':str(Path.cwd()),'started_at':started,'finished_validation_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validations':[x['draft'] for x in validations],'notes':'Sealing follows immediately; outer tool completion is authoritative for final process exit.'})
# Same compact portable copy-plan contract as the previously accepted234 QA packet.
files=sorted(p for p in O.rglob('*') if p.is_file() and 'payload' not in p.relative_to(O).parts and p.name not in {'copy-plan.json','artifact-manifest.json','handoff.json'})
payload=O/'payload';payload.mkdir();rows=[]
for p in files:
 rel=p.relative_to(O).as_posix();raw=p.read_bytes();encoded=p.suffix=='.py';dest=rel+'.gz' if encoded else rel;body=gzip.compress(raw,mtime=0) if encoded else raw
 q=payload/dest;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(body)
 assert (gzip.decompress(body) if encoded else body)==raw
 rows.append({'repository_path':D+'/'+dest,'payload_path':str(q),'bytes':len(body),'sha256':sha(body),'source_path':str(p),'decoded_sha256':sha(raw),'decoded_bytes':len(raw),'gzip_encoded':encoded})
index={'status':'ready_for_exact_root_adoption','durable_root':D,'files':[{k:v for k,v in x.items() if k not in ('payload_path','source_path')} for x in rows]};q=payload/'package-index.json';write(q,index);row=pin(q);rows.append({'repository_path':D+'/package-index.json','payload_path':str(q),'bytes':row['bytes'],'sha256':row['sha256'],'gzip_encoded':False})
root_evidence=[]
for rel in ['research/pathway_additions/2026-10-12-next-235/native-integration/root-storage-map.json','research/pathway_additions/2026-10-12-next-235/native-integration/README.md']:
 x=pin(R/rel);root_evidence.append({'repository_path':rel,'source_path':x['path'],'bytes':x['bytes'],'sha256':x['sha256']})
write(O/'copy-plan.json',{'durable_root':D,'files':rows,'root_evidence':root_evidence,'native_save_performed':False,'maintained_writes_performed':False})
artifacts=[];dirs=[]
for base,ds,fs in os.walk(O,followlinks=False):
 for n in ds:
  p=Path(base)/n;assert not p.is_symlink();dirs.append(str(p.relative_to(O)))
 for n in fs:
  p=Path(base)/n;assert stat.S_ISREG(p.lstat().st_mode)
  if n not in {'artifact-manifest.json','handoff.json'}:
   row=pin(p);artifacts.append({'relative_path':str(p.relative_to(O)),'type':'regular','bytes':row['bytes'],'sha256':row['sha256']})
write(O/'artifact-manifest.json',{'artifacts':sorted(artifacts,key=lambda x:x['relative_path']),'count':len(artifacts),'directories':sorted(dirs),'hidden_ignored_included':True,'aliases':0})
hand={'status':'accepted_actual_nitrate_local_integration_external_native_drafts_validated','reviewer':'Codex /root/aceto236_design_acceptance_review','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'findings':[],'artifact_count':len(artifacts),'seals':2,'manifest':pin(O/'artifact-manifest.json'),'copy_plan':pin(O/'copy-plan.json'),'report':pin(O/'REPORT.md'),'native_drafts':[pin(O/(t+'-review.yaml')) for t in ('scientific','technical')],'actual_tree_check':pin(O/'full-tree-check.json'),'next':'Root adopts exact copy-plan owners, runs finalizer native inspect/validate, saves reviews and verifies append-only/current-input preservation. No new broad review needed absent changed product inputs.'}
write(O/'handoff.json',hand)
print(json.dumps({'handoff':pin(O/'handoff.json'),'manifest':pin(O/'artifact-manifest.json'),'artifacts':len(artifacts),'payload_files':len(rows),'status':hand['status']},indent=2))
