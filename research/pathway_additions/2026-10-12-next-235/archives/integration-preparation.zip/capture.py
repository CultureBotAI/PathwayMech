"""Read-only physical baseline capture and exact accepted primary payload copies."""

import datetime
import json
from pathlib import Path

import common as c

H = c.HERE
BUILD = Path("/private/tmp/pathwaymech-next-235-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-235-canonical-preparation-20261012")
SCI = Path(
    "/private/tmp/pathwaymech-next-235-nuoc4-successor-20261012/draft/nitrate-reduction-viii.yaml"
)
ROOT_ACCEPT = Path(
    "/private/tmp/pathwaymech-next-235-root-canonical-output-acceptance-20261012.json"
)
c.verify(
    {
        "path": str(ROOT_ACCEPT),
        "bytes": 4410,
        "sha256": "bd5ea36c3b78614fcc400488ffedf3b8d0abbb8e872b5a653ca15e160c7a2ca8",
    }
)
c.git_check(True)
files, dirs = c.inventory(c.ROOT, exclude_git=True)
c.write_new(H / "baseline-files.json", files)
c.write_new(H / "baseline-directories.json", dirs)
closure = c.load(PRE / "source-closure.json")
c.write_new(H / "cache-baseline.json", closure["shared_cache"])
c.cache_check()
by = {r["path"]: r for r in files}
owners = c.load(H / "runtime-owner-map.json")
payload = H / "payload"
for row in owners["runtime"]:
    c.verify(row["actual_runtime"])
    c.verify(row["effective_preparation"])
    c.verify(row["accepted"])
    if row["changed"]:
        target = payload / row["relative_path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(c.regular_bytes(row["actual_runtime"]["path"]))
        target.chmod(0o755 if by.get(row["relative_path"], {}).get("executable") else 0o644)
for src, rel, sha in [
    (
        SCI,
        "data/pathways/nitrate-reduction-viii.yaml",
        "019deb06b1b58ae9c378b209a9e3815b6357685e13e6e3345b8be01aaf13f5de",
    ),
    (
        BUILD / "sources.json",
        "data/identifier_authorities/sources.json",
        "856d8eb32df1a73ebc9cc28c5d533b992f29649b45063d4e340f1f727a7ce754",
    ),
    (
        BUILD / "ontology.json",
        "data/identifier_authorities/ontology.json",
        "32934d18cc23ca0d26199640888507df3635593024b944e5dd211fde3deb5cc1",
    ),
]:
    assert c.pin(src)["sha256"] == sha
    dest = payload / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(c.regular_bytes(src))
    dest.chmod(0o644)
assert {r["path"] for r in c.inventory(payload)[0]} == c.PRIMARY
inputs = [
    ROOT_ACCEPT,
    Path("/private/tmp/pathwaymech-next-235-root-scientific-acceptance-20261012.json"),
    Path("/private/tmp/pathwaymech-next-235-root-implementation-acceptance-20261012.json"),
    Path(
        "/private/tmp/pathwaymech-next-235-root-canonical-execution-successor-acceptance-20261012.json"
    ),
]
c.write_new(H / "accepted-inputs.json", [c.pin(p) for p in inputs])
c.write_new(
    H / "baseline-receipt.json",
    {
        "at": datetime.datetime.now(datetime.UTC).isoformat(),
        "target": str(c.ROOT),
        "commit": c.BASE,
        "tree": c.TREE,
        "branch": c.BRANCH,
        "git_clean": True,
        "files": len(files),
        "directories": len(dirs),
        "hidden_ignored_included": True,
        "cache_entries": len(closure["shared_cache"]),
        "exact_primary_owners": 30,
        "actual_native_acceptance": c.pin(ROOT_ACCEPT),
    },
)
print(json.dumps(c.load(H / "baseline-receipt.json"), indent=2))
