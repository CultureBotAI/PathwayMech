"""Rebase reviewed 234 helpers and derive exact accepted runtime ownership."""

import ast
import difflib
import hashlib
import json
from pathlib import Path

H = Path(__file__).parent
OLD = Path("/private/tmp/pathwaymech-next-234-local-integration-preparation-20261012")
ROOT = Path("/private/tmp/pathwaymech-next-235-local-20261012")
BUILD = Path("/private/tmp/pathwaymech-next-235-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-235-canonical-preparation-20261012")


def pin(p):
    b = p.read_bytes()
    return {"path": str(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}


rows = []
for row in json.loads((PRE / "accepted-runtime-bridge.json").read_text())["all_runtime_files"]:
    rel = row["relative_path"]
    p = BUILD / "runtime" / rel
    b = pin(p)
    assert b["sha256"] == row["effective"]["sha256"]
    before = pin(ROOT / rel) if (ROOT / rel).exists() else None
    rows.append(
        {
            "relative_path": rel,
            "accepted": row["accepted_successor"],
            "effective_preparation": row["effective"],
            "actual_runtime": b,
            "before": before,
            "changed": before is None or before["sha256"] != b["sha256"],
        }
    )
changes = [r["relative_path"] for r in rows if r["changed"]]
assert len(changes) == 27
primary = sorted(
    changes
    + [
        "data/pathways/nitrate-reduction-viii.yaml",
        "data/identifier_authorities/sources.json",
        "data/identifier_authorities/ontology.json",
    ]
)
(H / "runtime-owner-map.json").write_text(
    json.dumps(
        {"runtime": rows, "runtime_count": len(rows), "changed_runtime": 27, "primary": primary},
        indent=2,
    )
    + "\n"
)
replacements = {
    "/pathwaymech-next-234-local-20261012": "/pathwaymech-next-235-local-20261012",
    "8c871a5808c73b0f21a397a2561269d068ee7368": "5ff01d7c59c61fd94b65b907edd50936193f7f17",
    "9e89d6330371d2d2834fec966af7e3e3edc35dca": "ead071a5b2a2a3bebcc54006b3cebbeec4f994ac",
    "feat/pathway-next-234-local-20261012": "feat/pathway-next-235-local-20261012",
    "2026-10-12-next-234": "2026-10-12-next-235",
    "PWY7545": "nitrate235",
    "pwy234-local-adoption": "nitrate235-local-adoption",
    "pathwaymech-next-234-local-adoption-": "pathwaymech-next-235-local-adoption-",
}
lineage = []
patch = []
for name in ["common.py", "adopt.py", "verify_portable.py", "split_archive.py"]:
    original = (OLD / name).read_text()
    text = original
    for a, b in replacements.items():
        text = text.replace(a, b)
    if name == "common.py":
        tree = ast.parse(text)
        node = next(
            n
            for n in tree.body
            if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == "PRIMARY" for t in n.targets)
        )
        lines = text.splitlines(keepends=True)
        lines[node.lineno - 1 : node.end_lineno] = ["PRIMARY = frozenset(" + repr(primary) + ")\n"]
        text = "".join(lines)
    (H / name).write_text(text)
    lineage.append(
        {
            "helper": name,
            "original": pin(OLD / name),
            "successor": pin(H / name),
            "change_scope": (
                "Explicit task paths/commit/tree/branch/status token rebasing; com"
                "mon PRIMARY replaced by exact 30-owner list. No guard logic chang"
                "es."
            ),
        }
    )
    patch.extend(
        difflib.unified_diff(
            original.splitlines(True),
            text.splitlines(True),
            fromfile="234/" + name,
            tofile="235/" + name,
        )
    )
(H / "helper-rebase.patch").write_text("".join(patch))
(H / "helper-lineage.json").write_text(json.dumps(lineage, indent=2) + "\n")
print(json.dumps({"runtime": len(rows), "changes": changes, "primary": len(primary)}, indent=2))
