"""Bounded preservation comparisons and root-owned native stage plan, no gates."""

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import yaml

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-235-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-235-canonical-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"


def stable(x):
    return json.dumps(x, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    comparison = c.load(BUILD / "comparison.json")
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before = c.load(c.ROOT / rel)
        after = c.load(PAY / rel)
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [x for x in new if x in old] == list(old)
                for identity in old:
                    if (
                        name == "sources"
                        and key == "sources"
                        and identity == "pwy234-rhea-polymer-142"
                    ):
                        exception = comparison["only_old_owner_addition"]
                        assert stable(old[identity]) == stable(exception["before"])
                        assert stable(new[identity]) == stable(exception["expected_after"])
                    else:
                        assert stable(old[identity]) == stable(new[identity]), (name, key, identity)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [x for x in new if x not in old],
                    "old_whole_objects_and_nested_order_exact_except_named_polymer_map": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(PAY / rel),
            "sections": sections,
        }
    old_manifest = c.load(c.ROOT / "conf/identifier_sources.json")
    new_manifest = c.load(PAY / "conf/identifier_sources.json")
    assert new_manifest[: len(old_manifest)] == old_manifest
    assert len(old_manifest) == 831 and len(new_manifest) == 844
    bn = rows(c.ROOT / "output/kgx/nodes.tsv")
    an = rows(BUILD / "actual-kgx/nodes.tsv")
    be = rows(c.ROOT / "output/kgx/edges.tsv")
    ae = rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = Counter(stable(x) for x in be)
    assert not oldedges - Counter(stable(x) for x in ae)
    assert [r for r in ae if r["id"] in {x["id"] for x in be}] == be
    oldnodes = {x["id"]: x for x in bn}
    newnodes = {x["id"]: x for x in an}
    changes = []
    contexts = additions = 0
    for identity, old in oldnodes.items():
        new = newnodes[identity]
        if old != new:
            changes.append({"id": identity, "before": old, "after": new})
        for key in old:
            if key == "source_contexts":
                oc = Counter(stable(x) for x in json.loads(old[key]))
                nc = Counter(stable(x) for x in json.loads(new[key]))
                assert not oc - nc
                contexts += sum(oc.values())
                additions += sum((nc - oc).values())
                assert all(json.loads(x)["record_id"] == "MetaCyc:PWY0-1352" for x in nc - oc)
            elif identity == "CHEBI:18407" and key in ["category", "source_category"]:
                assert set(new[key].split("|")) >= set(old[key].split("|"))
            else:
                assert old[key] == new[key], (identity, key)
    assert (len(bn), len(be), len(an), len(ae)) == (4217, 11803, 4260, 11903)
    assert len(changes) == 21
    # Expected new SSSOM rows use the native exporter cell normalization; no maintained export runs.
    record = yaml.safe_load(c.regular_bytes(PAY / "data/pathways/nitrate-reduction-viii.yaml"))
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for m in record["source_mappings"]:
        r = {k: m[k] for k in cols if k != "comment"}
        r["comment"] = (
            f"source_pathway_id={m['source_pathway_id']}; "
            f"source_element_id={m['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(r[k])).strip() for k in cols})
    unique = {stable(r): r for r in newss}
    existing = Counter(stable(r) for r in oldss)
    assert all(n == 1 for n in existing.values())
    added = [r for key, r in unique.items() if key not in existing]
    files = c.load(H / "baseline-files.json")
    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": len(list((c.ROOT / "data/pathways").glob("*.yaml"))),
        "old_review_yaml": len(list((c.ROOT / "reviews").rglob("*.yaml"))),
        "old_review_markdown": len(list((c.ROOT / "reviews").rglob("*.md"))),
        "old_history_yaml": len(list((c.ROOT / "history").rglob("*.yaml"))),
        "native_authorities": native,
        "manifest_prefix_rows": len(old_manifest),
        "manifest_after_rows": len(new_manifest),
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_category_exception": (
            "CHEBI:18407; preserve hydrogen cyanide label and old THIO chemica"
            "l_entity context, append nitrate small_molecule context; exact fu"
            "ll accepted after-KGX remains required"
        ),
        "polymer_exception": comparison["only_old_owner_addition"],
        "planning_decisions": [
            c.pin(PRE / p)
            for p in ["graph-planning-decision.json", "polymer-planning-decision.json"]
        ],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = c.load(
        "/private/tmp/pathwaymech-next-234-local-integration-preparation-20261012/stages.json"
    )
    stages = json.loads(
        json.dumps(stages)
        .replace("pathwaymech-next-234-local", "pathwaymech-next-235-local")
        .replace("pyruvate-to-cytochrome-bd-oxidase-electron-transfer", "nitrate-reduction-viii")
        .replace("PWY-7545", "PWY0-1352")
    )
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="scripts/build_source_identifier_snapshot.py",
        description=(
            "Exact 27 nitrate runtime/configuration/documentation/test owners "
            "plus accepted actual authority snapshots; typed Pathway, complete"
            " partial-EC/complex/chemical/literal-plus context, first-owner pr"
            "eservation and complete named-complex conflict checks."
        ),
        issue_lineage=[499, 500, 501],
    )
    stages["history_commands"] = [
        [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            "record",
            "--slug",
            "nitrate-reduction-viii",
            "--target-root",
            "data/pathways",
            "--event",
            "CREATE",
            "--outcome",
            "changed",
            "--summary",
            "Add the complete evidence-backed nitrate reduction VIII record.",
            "--details",
            (
                "Adopted exact accepted MetaCyc:PWY0-1352 science: 48 paragraphs, "
                "100 edges, 64 named identities, four endpoint qualifiers and 107 "
                "references. Preserve complete event and constituent sides, named "
                "assemblies, chemical/polymer scope, constructs, assays, evidence "
                "tiers, source conflicts and access limits in research/pathway_add"
                "itions/2026-10-12-next-235. Actual native outputs independently r"
                "eviewed and root accepted. Local integration only; fresh maintain"
                "ed gates and saved integrator review remain pending."
            ),
            "--actor-name",
            "codex",
            "--agent-tool",
            "codex",
            "--model",
            "gpt-6",
        ],
        [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            "infrastructure",
            "--slug",
            "nitrate-native-authority",
            "--path",
            "scripts/build_source_identifier_snapshot.py",
            "--event",
            "EDIT",
            "--outcome",
            "changed",
            "--summary",
            "Integrate complete typed nitrate authority contexts and accepted native snapshots.",
            "--details",
            (
                "Adopted exactly 27 accepted runtime/configuration/documentation/t"
                "est owners and two actual native snapshots. Typed Pathway and par"
                "tial EC context, whole named assemblies and conflict registry, fo"
                "ur chemical profiles and literal-plus context preserve all old co"
                "ntracts and all 265 UniProt first-owner objects. Polymer addition"
                "s follow native order 9537,9539,9565,9566. Issue501 receipt corre"
                "ction and actual execution lineage are retained as external evide"
                "nce. All prior owners and cache identities preserved; no publicat"
                "ion. Fresh maintained gates and native saved review remain pendin"
                "g."
            ),
            "--issue",
            "499",
            "--issue",
            "500",
            "--issue",
            "501",
            "--actor-name",
            "codex",
            "--agent-tool",
            "codex",
            "--model",
            "gpt-6",
        ],
    ]
    stages["after_gates"] = [
        (
            "Inspect actual whole nitrate page/graph, descriptions, source/pro"
            "venance links, every edge and qualifier; compare exact accepted s"
            "cience."
        ),
        (
            "Capture current maintained input hashes with scripts/record_revie"
            "w.py inspect; then author truthful completed integrator review us"
            "ing native schema/serializer. Name inherited independent science "
            "and actual-output review distinctly; do not call this a fresh ful"
            "l-paper review."
        ),
        (
            "Save with scripts/record_review.py --repo-root <target> save --co"
            "ntent <root-authored-completed-review>. Native save must bind act"
            "ual maintained bytes and actual inspection timing."
        ),
        (
            "Verify all old 235 record bytes/pages, old review pairs and histo"
            "ries, whole authority objects/order with explicit polymer excepti"
            "on, old KGX edge payload/order and node context multiplicity; exa"
            "ct accepted new KGX."
        ),
        (
            "SSSOM: old header and all old rows/cells/multiplicity exact; adde"
            "d rows exactly semantic-preservation.json expected_added_rows."
        ),
        (
            "Replay all 800 cache identities and full hidden/ignored checkout "
            "inventory outside exact primary/dossier/native generated addition"
            "s."
        ),
        (
            "Fresh final adversarial review of actual maintained tree; issues "
            "remain open until the authorized lifecycle reaches their closure "
            "requirements."
        ),
    ]
    stages["native_review_interfaces"] = {
        "inspect_help": [PY, "-B", "scripts/record_review.py", "inspect", "--help"],
        "save_template": [
            PY,
            "-B",
            "scripts/record_review.py",
            "--repo-root",
            str(c.ROOT),
            "save",
            "--content",
            "<root-authored-completed-review.json>",
        ],
        "check_after_save": [
            PY,
            "-B",
            "scripts/record_review.py",
            "--repo-root",
            str(c.ROOT),
            "check",
            "--require-reviews",
        ],
        "inherited_science_handoff": c.pin(
            "/private/tmp/pathwaymech-next-235-science-review-20261012/handoff.json"
        ),
        "actual_native_review_handoff": c.pin(
            
                "/private/tmp/pathwaymech-next-235-canonical-output-independent-re"
                "view-20261012/handoff.json"
            
        ),
        "do_not_fabricate_review_content_or_completion_time": True,
    }
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    stages["before_first_render_after_history"][0]["preservation"] = (
        "Keep complete old SSSOM header and all old rows/cells/multiplicities; add exactly the "
        + str(len(added))
        + " rows in semantic-preservation.json. This is planned, not an executed export."
    )
    c.write_new(H / "stages.json", stages)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Committed accepted PWY local branch; not merged main",
            "primary_owners": 30,
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(PAY / "data/pathways/nitrate-reduction-viii.yaml"),
            "actual_native_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-235-root-canonical-output-acceptance-20261012.json"
            ),
            "remaining": [
                "independent preparation review",
                "root exact acceptance",
                "local adoption",
                "native histories before first render",
                "native SSSOM export before render/tests",
                "nine maintained gates",
                "actual page/graph QA",
                "native integrator review",
                "final preservation and adversarial review",
            ],
            "source_exhaustion": False,
            "licensing": (
                "Public-release licensing remains deferred; existing publication b"
                "lock is unchanged."
            ),
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_files",
                    "old_records",
                    "old_review_yaml",
                    "old_review_markdown",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
