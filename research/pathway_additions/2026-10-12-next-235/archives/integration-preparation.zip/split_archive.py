"""Lossless bounded-file representation of the already verified CAS archive."""

import gzip
import hashlib
import json

import common as c


def main():
    dossier = c.HERE / "payload" / c.DOSSIER
    source = dossier / "archives/evidence-bodies.zip"
    before = c.pin(source)
    parts = []
    digest = hashlib.sha256()
    with source.open("rb") as stream:
        while body := stream.read(32 * 1024 * 1024):
            dest = source.with_name(source.name + f".part-{len(parts) + 1:03d}")
            with dest.open("xb") as target:
                target.write(body)
            bound = c.pin(dest)
            assert bound["sha256"] == hashlib.sha256(body).hexdigest()
            digest.update(c.regular_bytes(dest))
            parts.append(
                {k: v for k, v in bound.items() if k != "path"}
                | {"repository_relative_path": dest.relative_to(c.HERE / "payload").as_posix()}
            )
    assert digest.hexdigest() == before["sha256"]
    assert sum(x["bytes"] for x in parts) == before["bytes"]
    index = json.loads(gzip.decompress((dossier / "evidence-index.json.gz").read_bytes()))
    for loc in index["body_lookup"].values():
        if loc["repository_relative_path"] == c.DOSSIER + "/archives/evidence-bodies.zip":
            loc["kind"] = "repository_chunked_zip_member"
            loc["archive_parts"] = parts
    raw = json.dumps(index, sort_keys=True, ensure_ascii=False, indent=2).encode() + b"\n"
    (dossier / "evidence-index.json.gz").write_bytes(gzip.compress(raw, mtime=0))
    c.write_new(
        c.HERE / "archive-split-proof.json",
        {
            "status": "lossless_ordered_parts_equal_prior_verified_archive",
            "virtual_archive": before,
            "parts": parts,
            "uncompressed_index_bytes": len(raw),
            "part_size_limit": 32 * 1024 * 1024,
            "raw_script_bodies_remain_compressed": True,
        },
    )
    # The exact same bytes now have a verified lossless representation, not a discarded attempt.
    source.unlink()


if __name__ == "__main__":
    main()
