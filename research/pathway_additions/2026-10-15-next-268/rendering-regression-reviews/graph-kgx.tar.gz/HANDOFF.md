# Confirmed graph-test and KGX compatibility regressions

Two additional failures from the parent's terminal full-suite run were independently reproduced on captured next268 originals. This packet supplements the earlier issue 618 review; earlier frozen packets remain immutable. The findings are open pending correction and independent successor acceptance.

- [Issue 619](https://github.com/CultureBotAI/PathwayMech/issues/619): `kgx_nodes` eagerly accesses absent optional extension attributes on the existing navigation fixture.
- [Issue 620](https://github.com/CultureBotAI/PathwayMech/issues/620): the whole-corpus graph-test helper assumes exactly one graph per page despite the new detail graphs.

## Exact reproduction

From `/private/tmp/pathwaymech-next-268-20261015`:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONPATH=src:. /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m pytest tests/test_graph_pages.py::test_every_published_graph_preserves_directed_edges_and_evidence_targets tests/test_html_navigation.py::test_browse_keeps_all_records_and_source_path_association -q
```

Both tests failed in 14.01 seconds, exit 1. Complete stdout/stderr and six original owner copies/hashes are retained. The parent reported its separate full run as three failures, 6,523 passes and three skips; this packet does not relabel that run as passing.

For issue 619, `kgx_nodes` first raises `AttributeError` on `record.detail_only_participant_ids` at `kgx.py:147`. Supplying only that empty list exposes the second `AttributeError` on `record.reaction_mechanisms` at line 161. Supplying only mechanisms still fails at the first access. Supplying both empty lists produces exactly the HEAD baseline node/edge TSV hashes. The unmodified baseline navigation fixture also passes every original browse/source-path assertion. The four current cases and original tracebacks are retained in `kgx-optional-attribute-probes.json`.

For issue 620, `tests/test_graph_pages.py:50` finds 12 network SVGs on the new pathway page and asserts they equal one. The page legitimately has one source graph and 11 detail graphs. This is an obsolete test scope, not evidence of duplicate source graphs. Merely ignoring extra SVGs, skipping the new record or deleting the assertion would weaken coverage.

## Bounded corrections and required checks

For KGX, read each optional extension through `getattr(record, field, [])`. Preserve present detail payloads and their reference metadata. Keep the existing legacy fixture unchanged, and add an explicit-empty variant/equivalence check. Do not default or fabricate biological identifiers or required record fields.

For graph integration, select the unique SVG in the section whose exact ID is `pathway-network` for source checks. Preserve the existing directed-edge multiset, edge count, qualified display endpoints, per-edge evidence targets, source assertions/locators, and whole-page unique-ID checks for all 265 records. Add per-mechanism checks scoped to the exact detail section identity, verifying all local triples, qualifications, target rows and evidence. Require each expected section and its single SVG; do not rely on whichever SVG happens to occur first. Retain the independent detail rendering/control tests.

The issue 618 early-return guards remain a separate prerequisite: absent/empty details should not read undeclared participant data; source-empty and detail-empty rendering should return its existing empty-state HTML before reading identity. Detail-bearing source graphs must retain isolated source declarations.

`corpus_render_hashes.py` imports the captured pre-correction render/export implementations and hashes the entire site using the production source-path and history inputs. `pre-correction-output-hashes.json` provides the later byte-preservation target for all 265 record pages plus site/export products. Its import sentinel binds the exact four original code hashes before the parent began mutation. It never writes maintained pages.

## Scope and release

Maintained source/tests were not edited by this reviewer. No Git/GitHub mutation or installation occurred. Original owner reads were released after both exact failing tests and direct KGX probes completed. The parent then began corrections, so this packet binds captured originals and does not claim the live owners remain unchanged after release. The prior integration review's scientific/A01/A02 exclusions remain applicable.

Baseline source is retained in a byte-verified archive with a member inventory. All local jobs are terminal at freeze; the parent's fixes require a new successor packet and are not accepted by this original-failure review.
