# Confirmed rendering regression — issue 618

The existing `tests/test_render_pages.py::test_record_page_uses_parent_stylesheet` independently fails on the next268 worktree. The same minimal record passes against immutable HEAD `2c27fc819bac17ef05e191830346d7a32248c97c`. This is a new confirmed finding after the earlier integration review, which did not exercise the minimal `SimpleNamespace` fixture. The earlier frozen packet remains unchanged; it does not establish acceptance of this newly identified case.

Issue: https://github.com/CultureBotAI/PathwayMech/issues/618

## Reproduction

From `/private/tmp/pathwaymech-next-268-20261015`, the exact requested command was:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONPATH=src:. /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m pytest tests/test_render_pages.py::test_record_page_uses_parent_stylesheet -q
```

Result: exit 1, one failure in 0.89 seconds. Complete stdout/stderr are retained. Root's full suite was left running and was not interrupted or duplicated. No maintained source/test, Git/GitHub or runtime/install mutation was performed by this reviewer. Exact original owners are bound in `owner-bindings.json` and copied under `inputs/`.

The fixture supplies only `label`, `description` and an empty `mechanistic_edges` list. The old `_record_page` contract renders the page title and parent stylesheet for that object. The new call to `mechanism_views` unconditionally accesses `record.participants` at `mechanism_view.py:34`, before discovering there are no detailed mechanisms. It raises `AttributeError` before returning HTML.

`empty-helper-probes.json` independently exposes the next failure as well: `graph_html` now calls `_declared_nodes` even for an empty graph. `_declared_nodes` accesses `record.id` at `graph_view.py:81`; the call also requires `record.id` as its identity argument. Baseline returned its empty-state section before reading any of those fields. Correcting only the first exception would leave the test failing.

## Bounded recommendation and acceptance

1. In `mechanism_views`, return `''` before reading participants whenever `reaction_mechanisms` is absent or empty.
2. In `graph_html`, return `display_graph_html({}, [], title='Pathway network', identity='')` before reading declarations/identity only when both `mechanistic_edges` and `reaction_mechanisms` are absent/empty in the applicable existing contract. Keep detail-bearing, source-edge-free records on the normal rendering path so their declared source components remain visible.
3. Preserve the existing minimal fixture. Verify missing and explicit-empty detail lists, the exact original test, and existing detailed-rendering/independent-control tests. Do not add synthetic record fields to hide the regression.

Root's proposed two early guards match this recommendation. This packet contains the original failing state, not a correction or successor acceptance. The finding remains open until the maintained successor is independently replayed. Baseline reproduction passed the original stylesheet/title assertions; all local review jobs are terminal.
