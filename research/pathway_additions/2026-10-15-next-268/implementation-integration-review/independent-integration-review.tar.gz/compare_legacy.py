"""Check legacy transport plus the deliberately changed readable edge tooltip."""
from pathlib import Path
import copy
import hashlib
import json
import subprocess

p=Path(__file__).resolve().parent
root=Path('/private/tmp/pathwaymech-next-268-20261015')
a=json.loads((p/'legacy-baseline.json').read_text())
b=json.loads((p/'legacy-current.json').read_text())
result={'records':a['records'],'raw_projection_equal':a==b,'kgx_byte_hashes_equal':a['kgx_sha256']==b['kgx_sha256'],'graph_nodes':sum(len(x['nodes']) for x in a['pages']),'graph_edges':sum(len(x['edges']) for x in a['pages']),'duplicate_id_pages':[x['id'] for x in b['pages'] if x['duplicate_ids']],'broken_fragment_pages':[x['id'] for x in b['pages'] if x['broken_hrefs']]}
changed=0
for old,new in zip(a['pages'],b['pages'],strict=True):
    labels={n['data-node-id']:n['data-node-label'] for n in new['nodes']}
    for before,after in zip(old['edges'],new['edges'],strict=True):
        old_prefix=before.get('data-subject-id',before['data-subject'])+' — '+before['data-predicate']+' → '+before.get('data-object-id',before['data-object'])
        new_prefix=labels[after['data-subject']]+' — '+after['data-predicate'].replace('_',' ')+' → '+labels[after['data-object']]
        assert before['aria-label'].startswith(old_prefix)
        assert after['aria-label']==new_prefix+before['aria-label'][len(old_prefix):]
        changed+=before['aria-label']!=after['aria-label']
        before.pop('aria-label');after.pop('aria-label')
assert a==b
assert result['kgx_byte_hashes_equal']
assert not result['duplicate_id_pages'] and not result['broken_fragment_pages']
result['only_edge_tooltip_prefix_changed']=True
result['readable_tooltip_changes_verified']=changed
result['all_other_graph_node_edge_attributes_and_evidence_suffixes_equal']=True
bindings=json.loads((p/'input-bindings.json').read_text())
result['owner_byte_changes']=[r['path'] for r in bindings['owners'] if hashlib.sha256((root/r['path']).read_bytes()).hexdigest()!=r['sha256']]
assert not result['owner_byte_changes']
(p/'legacy-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
scenarios=['multiple_graphs_are_independent','zoom_and_fit','zoom_limits','directed_selection_preserves_graph','clear_and_escape','absent_or_invalid_graph','qualified_endpoint_selection']
receipts=[]
for s in scenarios:
    r=subprocess.run(['node',str(p/'inputs/tests/graph_interaction_harness.cjs'),str(p/'inputs/src/pathwaymech/assets/pathway-network.js'),s],text=True,capture_output=True,timeout=30)
    receipts.append({'scenario':s,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    assert r.returncode==0,receipts[-1]
(p/'javascript-interaction-results.json').write_text(json.dumps(receipts,indent=2)+'\n')
print('7 shipped JavaScript interaction scenarios passed')
