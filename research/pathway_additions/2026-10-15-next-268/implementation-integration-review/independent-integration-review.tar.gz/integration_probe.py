"""Reviewer-authored integration probes; synthetic IDs are not biological curation."""
import copy
import csv
import hashlib
import io
import json
from collections import Counter
from dataclasses import asdict
from html.parser import HTMLParser
from pathlib import Path

from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx
from pathwaymech.reaction_mechanisms import mechanism_equation
from pathwaymech.schema import ValidationError, validate_record
from pathwaymech.strict import json_schema
from jsonschema import Draft7Validator

OUT = Path(__file__).resolve().parent
checks = []


def check(name, condition):
    checks.append({"check": name, "passed": bool(condition)})
    assert condition, name


class HTML(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.elements = []
        self.text = []
        self.graphs = []
        self.current = None
        self.feed(source)

    def handle_starttag(self, tag, pairs):
        a = dict(pairs)
        self.elements.append((tag, a))
        if tag == "svg" and a.get("class") == "pathway-network-svg":
            self.current = []
            self.graphs.append(self.current)
        if self.current is not None:
            self.current.append((tag, a))

    def handle_endtag(self, tag):
        if tag == "svg":
            self.current = None

    def handle_data(self, data):
        self.text.append(data)


raw = json.loads((OUT / 'inputs/tests/fixtures/reaction_mechanism.json').read_text())
first = raw['reaction_mechanisms'][0]
first['key'] = 'a-' + 'x' * 62
first['steps'][0]['label'] = first['steps'][1]['label'] = 'Identical labels & β'
first['steps'][0]['hypotheses'] = [{'description': 'Unobserved β state <script>not executable</script>', 'status': 'proposed', 'evidence': copy.deepcopy(first['evidence'])}]
first['edges'][4]['endpoint_qualifiers'] = [{'endpoint': 'subject', 'kind': 'experimental_construct', 'description': 'His6-tag; β construct\nsecond line', 'evidence': copy.deepcopy(first['evidence'])}]
second = copy.deepcopy(first)
second['key'] = 'a_' + 'x' * 62
second['relation_to_source'] = 'alternative_interpretation'
second['edges'][0]['subject']['node_id'] = 'CHEBI:4'
second['source_conflicts'] = [{'source_participant_id': 'CHEBI:1', 'interpreted_participant_id': 'CHEBI:4', 'side': 'inputs', 'coefficient': 1, 'kind': 'constitution', 'status': 'unresolved', 'rationale': 'Distinct constitution; no equivalence', 'evidence': copy.deepcopy(first['evidence'])}]
second['source_equation']['inputs'], second['source_equation']['outputs'] = second['source_equation']['outputs'], second['source_equation']['inputs']
second['source_equation']['orientation'] = 'reversed'
raw['reaction_mechanisms'].append(second)
raw['detail_only_participant_ids'].append('CHEBI:4')
raw['mechanistic_edges'] = [dict(id='source-'+predicate, subject='RHEA:1', predicate=predicate, object=identifier, evidence=copy.deepcopy(first['evidence'])) for predicate, identifier in [('has_input', 'CHEBI:1'), ('has_output', 'CHEBI:2')]]

# Assign a distinct citation to every evidence-bearing assertion, with complete
# metadata and escaped JSON-sensitive characters, including evidence-only refs.
raw['references'] = []
proofs = []
def unique_evidence(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'evidence':
                token = 'evidence_token_' + str(len(proofs))
                text = token + ': β & "quotation"\ncontinuation\tsegment'
                child[:] = [{'reference_id': 'DOI:' + token, 'source_assertion': text, 'source_locator': 'Table '+token+'; rows 1–2'}]
                raw['references'].append({'id':'DOI:'+token, 'title':'Title '+token, 'citation': 'Full metadata β\n'+token, 'url':'https://example.org/'+token, 'source_sha256':hashlib.sha256(token.encode()).hexdigest(), 'source_version':'frozen-test'})
                proofs.append(copy.deepcopy(child[0]))
            else:
                unique_evidence(child)
    elif isinstance(value, list):
        for item in value:
            unique_evidence(item)
unique_evidence(raw['mechanistic_edges'])
unique_evidence(raw['reaction_mechanisms'])
(OUT/'synthetic-record.json').write_text(json.dumps(raw, indent=2, ensure_ascii=False)+'\n')
schema = json.loads(json_schema())
closed = Draft7Validator(schema)
(OUT/'closed-schema.json').write_text(json.dumps(schema, indent=2)+'\n')
record = validate_record(raw)
check('rich fixture passes closed schema', not list(closed.iter_errors(raw)))
before = copy.deepcopy(asdict(record))
page = _record_page(record)
(OUT/'synthetic-page.html').write_text(page)
parsed = HTML(page)
check('render does not mutate validated payload', asdict(record) == before)
ids = [a['id'] for _,a in parsed.elements if 'id' in a]
check('all HTML/SVG IDs unique', len(ids) == len(set(ids)))
for tag,a in parsed.elements:
    if a.get('href','').startswith('#'):
        check('fragment target '+a['href'], a['href'][1:] in ids)
    for name in ['aria-labelledby','aria-describedby','for']:
        for target in a.get(name,'').split():
            check(name+' target '+target, target in ids)
check('source plus two detailed graphs', len(parsed.graphs)==3)
source_edges=[a for t,a in parsed.graphs[0] if t=='a' and 'graph-edge' in a.get('class','').split()]
check('source asserted triple multiset retained', Counter((a['data-subject'],a['data-predicate'],a['data-object']) for a in source_edges)==Counter((e['subject'],e['predicate'],e['object']) for e in raw['mechanistic_edges']))
source_nodes={a['data-node-id'] for t,a in parsed.graphs[0] if t=='a' and 'graph-node' in a.get('class','').split()}
check('only explicit detail-only participants excluded', source_nodes == {n['id'] for n in raw['participants']+raw['reactions']}-set(raw['detail_only_participant_ids']))
check('all source competing assertions labeled', all('source-reported' in a['aria-label'] for a in source_edges))
for n,graph in enumerate(parsed.graphs[1:]):
    edges=[a for t,a in graph if t=='a' and 'graph-edge' in a.get('class','').split()]
    check('detail edge count '+str(n), len(edges)==len(raw['reaction_mechanisms'][n]['edges']))
    check('local step keys are displayed only as claims '+str(n), sum(t=='a' and a.get('data-kind')=='step' for t,a in graph)==2)
    check('construct edge uses qualified display instance '+str(n), any(a.get('data-subject-id')=='UniProtKB:FIXTURE' and a['data-subject']!='UniProtKB:FIXTURE' for a in edges))
text=''.join(parsed.text)
for proof in proofs:
    check('complete evidence text '+proof['reference_id'], proof['source_assertion'] in text)
    check('evidence locator '+proof['reference_id'], proof['source_locator'] in text)
check('unobserved prose safe and complete', '<script>not executable</script>' in text and '<script>not executable</script>' not in page)
check('qualified description complete', first['edges'][4]['endpoint_qualifiers'][0]['description'] in text)
for c in ['graph-node-picker','graph-native-size','graph-viewport']:
    check('separate controls '+c, len([a for _,a in parsed.elements if c in a.get('class','').split()])==3)

# Two records share parent/public IDs and every local key, but metadata and
# descriptions differ. TSV+JSON roundtrip must retain exact record-specific values.
raw2=copy.deepcopy(raw)
raw2['id']='MetaCyc:SECOND-REVIEW'
raw2['reaction_mechanisms'][0]['description']='Second record\nindependent β interpretation'
raw2['references'][2]['title']='Second-record distinct title for same reference ID'
raw2['detail_only_participant_ids']=['CHEBI:3']
records=[record,validate_record(raw2)]
for order in (records,records[::-1]):
    tsv=render_kgx(order)
    nodes=list(csv.DictReader(io.StringIO(tsv['nodes.tsv']),delimiter='\t'))
    edges=list(csv.DictReader(io.StringIO(tsv['edges.tsv']),delimiter='\t'))
    check('no invented public step IDs', {r['id'] for r in nodes}=={r.id for r in records}|{n['id'] for n in raw['participants']+raw['reactions']})
    check('only source triples in KGX edges', len(edges)==4 and all(e['subject']=='RHEA:1' for e in edges))
    contexts=json.loads(next(n['source_contexts'] for n in nodes if n['id']=='RHEA:1'))
    check('distinct shared reaction contexts', {c['record_id'] for c in contexts}=={r.id for r in records})
    for context in contexts:
        r=next(r for r in records if r.id==context['record_id'])
        expected_refs={ref['id']:ref for ref in r.references}
        check('complete nested mechanism roundtrip '+r.id, [x['mechanism'] for x in context['reaction_mechanisms']]==r.reaction_mechanisms)
        for m in context['reaction_mechanisms']:
            for ref in m['references']:
                check('record-specific reference payload '+r.id+ref['id'], ref==expected_refs[ref['id']])
            expected_ids=set()
            def collect(x):
                if isinstance(x,dict):
                    if 'reference_id' in x:expected_ids.add(x['reference_id'])
                    for v in x.values():collect(v)
                elif isinstance(x,list):
                    for v in x:collect(v)
            collect(m['mechanism'])
            check('every nested-only reference retained '+r.id+m['mechanism']['key'], {x['id'] for x in m['references']}==expected_ids)
    zcontexts=json.loads(next(n['source_contexts'] for n in nodes if n['id']=='CHEBI:4'))
    check('detail-only scope remains record specific', {c['record_id']:c.get('graph_scope') for c in zcontexts}=={record.id:'mechanism_detail_only',raw2['id']:None})

# Exact arithmetic, reversed alternatives, and closure under malformed nested
# payloads; independent cases are bounded to the newly added contract.
for scale in (1,2,101,10**18):
    case=copy.deepcopy(raw)
    for m in case['reaction_mechanisms']:
        for side in ('inputs','outputs'):
            for term in m['source_equation'][side]:term['coefficient']*=scale
        for edge in m['edges']:
            if 'coefficient' in edge:edge['coefficient']*=scale
        for conflict in m.get('source_conflicts',[]):conflict['coefficient']*=scale
    validate_record(case)
    check('exact integer/reversed reconciliation '+str(scale), mechanism_equation(case['reaction_mechanisms'][1])['inputs']==[{'participant_id':'CHEBI:4','coefficient':scale}])
    case['reaction_mechanisms'][1]['source_conflicts'][0]['coefficient']+=1
    try:validate_record(case)
    except ValidationError:check('one-unit conflict mismatch rejected '+str(scale),True)
    else:check('one-unit conflict mismatch rejected '+str(scale),False)

paths=[]
def collect_paths(v,path):
    if isinstance(v,dict):
        paths.append(path)
        for k,x in v.items():collect_paths(x,path+[k])
    elif isinstance(v,list):
        for i,x in enumerate(v):collect_paths(x,path+[i])
collect_paths(raw['reaction_mechanisms'],['reaction_mechanisms'])
for path in paths:
    case=copy.deepcopy(raw)
    target=case
    for k in path:target=target[k]
    target['reviewer_unknown_field']=True
    check('closed nested object '+str(path),bool(list(closed.iter_errors(case))))
    try:validate_record(case)
    except ValidationError:check('semantic closure '+str(path),True)
    else:check('semantic closure '+str(path),False)

(OUT/'integration-probe-results.json').write_text(json.dumps({'checks':len(checks),'failed':sum(not c['passed'] for c in checks),'evidence_items':len(proofs),'closed_objects_probed':len(paths),'synthetic_only':True,'results':checks},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'checks':len(checks),'failures':0,'evidence_items':len(proofs),'closed_objects_probed':len(paths)}))
