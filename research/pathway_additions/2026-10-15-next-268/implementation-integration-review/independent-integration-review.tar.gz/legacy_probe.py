"""Independent transport/diagram comparison against immutable HEAD records."""
import hashlib
import json
from html.parser import HTMLParser
from pathlib import Path
import sys

from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx
from pathwaymech.yaml_io import load_pathway_records


class Page(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.nodes = []
        self.edges = []
        self.ids = []
        self.hrefs = []
        self.feed(source)

    def handle_starttag(self, tag, pairs):
        attrs = dict(pairs)
        if "id" in attrs:
            self.ids.append(attrs["id"])
        if attrs.get("href", "").startswith("#"):
            self.hrefs.append(attrs["href"][1:])
        classes = attrs.get("class", "").split()
        if tag == "a" and "graph-node" in classes:
            self.nodes.append({k: v for k, v in attrs.items() if k.startswith("data-") or k in {"href", "aria-label"}})
        if tag == "a" and "graph-edge" in classes:
            self.edges.append({k: v for k, v in attrs.items() if k.startswith("data-") or k in {"href", "aria-label"}})


records = load_pathway_records(Path(sys.argv[1]))
outputs = render_kgx(records)
result = {"records": len(records), "kgx_sha256": {k: hashlib.sha256(v.encode()).hexdigest() for k, v in outputs.items()}, "pages": []}
for record in records:
    page = Page(_record_page(record))
    result["pages"].append({"id": record.id, "nodes": page.nodes, "edges": page.edges, "duplicate_ids": sorted({i for i in page.ids if page.ids.count(i)>1}), "broken_hrefs": sorted(set(page.hrefs)-set(page.ids))})
Path(sys.argv[2]).write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"records":len(records), "kgx_sha256":result["kgx_sha256"], "pages":len(result["pages"]), "graph_nodes":sum(len(p["nodes"]) for p in result["pages"]), "graph_edges":sum(len(p["edges"]) for p in result["pages"])}))
