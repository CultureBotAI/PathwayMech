"""Transport-only inspection; does not accept this reviewer's biological claims."""
import csv
import hashlib
import io
import json
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
import yaml
from pathwaymech.cli import _record_page
from pathwaymech.kgx import render_kgx
from pathwaymech.schema import validate_record

out=Path(__file__).resolve().parent
path=Path('/private/tmp/pathwaymech-next-268-20261015/data/pathways/phenylacetate-degradation-i-aerobic.yaml')
data=path.read_bytes()
raw=yaml.safe_load(data)
record=validate_record(raw)

class Page(HTMLParser):
    def __init__(self,source):
        super().__init__();self.ids=[];self.targets=[];self.graphs=[];self.current=None
        self.feed(source)
    def handle_starttag(self,tag,pairs):
        a=dict(pairs)
        if 'id' in a:self.ids.append(a['id'])
        if a.get('href','').startswith('#'):self.targets.append(a['href'][1:])
        for key in ('for','aria-labelledby','aria-describedby'):self.targets.extend(a.get(key,'').split())
        if tag=='svg' and a.get('class')=='pathway-network-svg':self.current=[];self.graphs.append(self.current)
        if self.current is not None and tag=='a' and 'graph-edge' in a.get('class','').split():self.current.append(a)
    def handle_endtag(self,tag):
        if tag=='svg':self.current=None

page=Page(_record_page(record))
assert len(page.ids)==len(set(page.ids))
assert not set(page.targets)-set(page.ids)
assert len(page.graphs)==1+len(record.reaction_mechanisms)
def triple(e):return e.get('data-subject-id',e['data-subject']),e['data-predicate'],e.get('data-object-id',e['data-object'])
assert Counter(map(triple,page.graphs[0]))==Counter((e['subject'],e['predicate'],e['object']) for e in record.mechanistic_edges)
def endpoint(e):return e['node_id'] if 'node_id' in e else json.dumps(['step',e['step_key']],separators=(',',':'))
for graph,m in zip(page.graphs[1:],record.reaction_mechanisms,strict=True):
    assert Counter(map(triple,graph))==Counter((endpoint(e['subject']),e['predicate'],endpoint(e['object'])) for e in m['edges'])
exports=render_kgx([record]); nodes=list(csv.DictReader(io.StringIO(exports['nodes.tsv']),delimiter='\t')); edges=list(csv.DictReader(io.StringIO(exports['edges.tsv']),delimiter='\t'))
assert len(edges)==len(record.mechanistic_edges)
roundtrip=[]
for n in nodes:
    for context in json.loads(n['source_contexts']):
        for entry in context.get('reaction_mechanisms',[]):
            roundtrip.append(entry['mechanism'])
assert sorted(roundtrip,key=lambda m:m['key'])==sorted(record.reaction_mechanisms,key=lambda m:m['key'])
result={'scope':'Generic rendering/export transport only; reviewer-authored primary science and authority patches explicitly excluded','record_sha256':hashlib.sha256(data).hexdigest(),'source_graph_edges':len(page.graphs[0]),'detail_graphs':len(page.graphs)-1,'detail_edge_counts':[len(g) for g in page.graphs[1:]],'source_and_detail_exact_endpoint_multisets_preserved':True,'unique_html_ids':len(page.ids),'fragment_and_accessibility_targets_resolved':len(page.targets),'kgx_top_level_edges':len(edges),'complete_nested_payloads_roundtripped':len(roundtrip),'findings':[]}
(out/'integrated-transport-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
