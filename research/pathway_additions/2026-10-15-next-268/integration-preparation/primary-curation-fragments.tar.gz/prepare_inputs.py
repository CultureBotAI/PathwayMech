import json,hashlib,shutil,html,re
from pathlib import Path
from html.parser import HTMLParser
OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def put(name,obj):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
roots={k:Path('/private/tmp/pathwaymech-next-268-'+v) for k,v in {
 'primary':'primary','corrected':'primary-corrections','correction_review':'independent-primary-corrections-review','primary_review':'independent-primary-review',
 'native':'native','native_review':'independent-native-review','chemistry':'chemistry','chemistry_review':'independent-chemistry-review',
 'slya':'root-regulatory-followup','slya_review':'independent-regulatory-followup-review','nature':'root-primary-access-continuation','nature_review':'independent-nature2012-main-review','native_draft':'native-record-draft'}.items()}
paths=[]
for root in roots.values():
 names=['HANDOFF.md','artifact-manifest.json']+([] if root==roots['native_draft'] else ['freeze-proof.json'])
 for n in names:
  p=root/n;paths.append(p)
  dest=OUT/'inputs'/root.name/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
ledger_paths={'primary':roots['corrected']/'primary-claim-ledger.corrected.json','native':roots['native']/'biological-claim-ledger.json','slya':roots['slya']/'slya2017-claim-ledger.json','nature':roots['nature']/'nature2012-claim-ledger.json'}
ledgers={k:json.loads(p.read_text()) for k,p in ledger_paths.items()};ledgers['nature']=ledgers['nature']['claims']
assert [len(ledgers[k]) for k in ['primary','native','slya','nature']]==[31,19,6,12]
assert sha(ledger_paths['primary'])=='c5a4858ea8c2c8a2982df9675383b3cf7bf9dd91c63c0eb281eadd47c43cfa0b'
paths+=list(ledger_paths.values())
for group,rows in ledgers.items():
 put('inputs/'+group+'-claims.json',rows)
 for row in rows:
  for source in row.get('sources',row.get('source_owners',[])):
   p=Path(source['path']); assert sha(p)==source['sha256'],p;paths.append(p)
extra={
 'native_draft':['phenylacetate-degradation-i-aerobic.native-draft.yaml','core-native-to-issuing-identity-crosswalk.json'],
 'native':['all14-core-biological-identity-ledger.json','claim-proof-bindings.json','scientific-conflicts-and-open-gaps.json'],
 'primary':['all-new-native-full-slots.json','finite-regulatory-closure.json'],
 'chemistry':['all-reaction-dispositions.json','all-material-dispositions.json','additional-chemistry-and-ccd-replay.json','mechanistic-state-ledger.json'],
 'nature_review':['all12-claim-dispositions.json'], 'slya_review':['all6-claim-dispositions.json'], 'native_review':['claim-dispositions.json'],
 'primary_review':['all31-claim-dispositions.json'], 'correction_review':['all3-correction-dispositions.json']}
for k,names in extra.items():
 for name in names:
  p=roots[k]/name;paths.append(p);dest=OUT/'inputs'/roots[k].name/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
api=Path('/private/tmp/pathwaymech-next-268-ci/reaction-mechanism-api.md');paths.append(api);shutil.copy2(api,OUT/'inputs/reaction-mechanism-api.md')
source_specs={
 'PNAS2010':('PMID:20660314',Path('/private/tmp/pathwaymech-next-268-discovery/originals/full-PMC2922514.html'),roots['native_review']/'primary-full-PMC2922514.html.txt'),
 'PaaK2000':('PMID:10629172',Path('/private/tmp/pathwaymech-next-268-discovery/originals/full-PMC94275.html'),roots['native_review']/'primary-full-PMC94275.html.txt'),
 'PaaZ2011':('PMID:21296885',Path('/private/tmp/pathwaymech-next-268-discovery/originals/full-PMC3064157.html'),roots['native_review']/'primary-full-PMC3064157.html.txt'),
 'PaaAC2011':('PMID:21247899',Path('/private/tmp/pathwaymech-next-268-discovery/originals/NRC-PMID21247899.pdf'),roots['native']/'reading/NRC2011-full/complete-text.txt'),
 'PaaFG2012':('PMID:22961985',Path('/private/tmp/pathwaymech-next-268-root-access-followup/semantic-PaaFG.pdf'),roots['chemistry']/'reading/PaaFG2012/complete-text.txt'),
 'PaaZ2019':('DOI:10.1038/s41467-019-11931-3',roots['native']/'originals/publisher-PaaZ-2019.html',roots['native']/'reading/publisher-PaaZ-2019-main.txt'),
 'Nature2012':('PMID:22398448',roots['nature']/'originals/nature10862-publisher-cookie.pdf',roots['nature']/'reading/Nature2012-main/complete-text.txt'),
 'Nature2012SI':('DOI:10.1038/nature10862',roots['primary']/'originals/nature10862-SI.pdf',roots['primary_review']/'pdf-reproduction/nature10862-SI/complete-text.txt'),
 'PaaI2006':('PMID:16464851',roots['primary']/'originals/primary-PaaI2006.pdf',roots['primary_review']/'pdf-reproduction/PaaI2006/complete-text.txt'),
 'PaaX2000':('DOI:10.1074/jbc.275.16.12214',roots['primary']/'originals/PaaX2000-CSIC.pdf',roots['primary_review']/'pdf-reproduction/PaaX2000/complete-text.txt'),
 'PaaD2006':('DOI:10.1128/AEM.01550-06',roots['primary']/'originals/primary-PaaD2006.html',roots['primary']/'reading/primary-PaaD2006.html.txt'),
 'PaaX2004':('DOI:10.1128/JB.186.7.2215-2220.2004',roots['primary']/'originals/primary-PaaX2004.html',roots['primary']/'reading/primary-PaaX2004.html.txt'),
 'PaaX2006':('DOI:10.1128/JB.00176-06',roots['primary']/'originals/primary-PaaX2006.html',roots['primary']/'reading/primary-PaaX2006.html.txt'),
 'SlyA2020':('DOI:10.3389/fmicb.2020.01856',roots['primary']/'originals/SlyA2020-publisher.pdf',roots['primary_review']/'pdf-reproduction/SlyA2020/complete-text.txt'),
 'SrsR2022':('DOI:10.3390/ijms23116055',roots['primary']/'originals/SrsR2022-ncbi.html',roots['primary']/'reading/SrsR2022-ncbi.html.txt'),
 'SlyA2017':('DOI:10.1099/mic.0.000423',roots['slya']/'originals/SlyA2017-Semantic.pdf',roots['slya']/'reading/SlyA2017-Semantic/complete-text.txt')}
# The source owner spelling is checked rather than guessed from a metadata lead.
if not source_specs['SlyA2017'][1].exists():
 candidates=[p for p in (roots['slya']/'originals').glob('*.pdf') if sha(p)=='46f9bbc4f1f0cc8fbd08cb0c795c658c9f44b2b9bf36ec83031cd7cbd0ff8c33']
 assert len(candidates)==1;old=source_specs['SlyA2017'];source_specs['SlyA2017']=(old[0],candidates[0],old[2])
sources={}
for key,(rid,original,projection) in source_specs.items():
 assert original.exists() and projection.exists(),(key,original,projection)
 paths.extend([original,projection]);dest=OUT/'reading'/f'{key}.txt';dest.parent.mkdir(exist_ok=True);shutil.copy2(projection,dest)
 sources[key]={'reference_id':rid,'original':rec(original),'projection':rec(projection),'owned_text':str(dest)}
put('source-proof-bindings.json',sources)
put('input-bindings-before.json',{'scope':'Selected immutable accepted ledgers, independent acceptance owners, used originals and reading projections; no claim of a new whole-corpus inventory','hidden_ignored_included_for_selected_file_inventories':True,'files':[rec(p) for p in sorted(set(paths))]})
put('all68-accepted-input-claims.json',ledgers)
print(json.dumps({'bound_inputs':len(set(paths)),'claims':68,'source_texts':len(sources)}))
