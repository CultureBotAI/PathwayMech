from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
excluded={'artifact-manifest.json','freeze-proof.json'}
files=sorted(p for p in root.rglob('*') if p.is_file() and p.relative_to(root).as_posix() not in excluded)
assert not any(p.is_symlink() for p in files)
entries=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]
manifest=root/'artifact-manifest.json'
manifest.write_text(json.dumps({'scope':'All regular files recursively, including hidden and ignored; only manifest and freeze proof excluded to avoid circular hashes.',
 'files':entries},indent=2)+'\n')
proof={'status':'frozen_author_packet_for_independent_review','manifest_sha256':digest(manifest),'handoff_sha256':digest(root/'HANDOFF.md'),
 'listed_files':len(entries),'physical_files':len(entries)+2,'all_local_jobs_terminal':True,
 'frozen_inputs_unchanged':104,'final_checks_passed':1041,'claims_disposed':68,
 'not_final_record_acceptance':True}
(root/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert len([p for p in root.rglob('*') if p.is_file()])==proof['physical_files']
assert all(digest(root/e['path'])==e['sha256'] for e in entries)
print(json.dumps(dict(proof,freeze_sha256=digest(root/'freeze-proof.json'),merged_review_yaml_sha256=digest(root/'review-merged-record.yaml')),indent=2))
