"""Reproduce the owned review draft. Never writes the input record."""
from pathlib import Path
import argparse, copy, hashlib, json, yaml

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--native',type=Path,default=HERE/'inputs/pathwaymech-next-268-native-record-draft/phenylacetate-degradation-i-aerobic.native-draft.yaml')
parser.add_argument('--output',type=Path,default=HERE/'review-merged-record.yaml')
args=parser.parse_args()
assert args.output.resolve()!=args.native.resolve(), 'Never overwrite the native input'
native=yaml.safe_load(args.native.read_text())
add=yaml.safe_load((HERE/'fragments/primary-additions.yaml').read_text())
description=yaml.safe_load((HERE/'fragments/description.yaml').read_text())
assert native['id']=='MetaCyc:PWY0-321'
assert len(native['reactions'])==9
result=copy.deepcopy(native)
for field,values in add.items():
    assert field in ['participants','reactions','references','mechanistic_edges','reaction_mechanisms','detail_only_participant_ids'],field
    existing=result.setdefault(field,[])
    key='key' if field=='reaction_mechanisms' else 'id'
    ids=set(existing if field=='detail_only_participant_ids' else [v[key] for v in existing])
    for value in values:
        ident=value if field=='detail_only_participant_ids' else value[key]
        assert ident not in ids,(field,ident)
        ids.add(ident);existing.append(copy.deepcopy(value))
result['description']=description['description']
for field in ['participants','reactions','references','mechanistic_edges']:
    assert result[field][:len(native[field])]==native[field],field
# Add the required semantic category; source labels, directions and all other
# native reaction values are unchanged. This addition is explicit and additive.
category_additions=[]
for reaction in result['reactions']:
    if 'category' not in reaction:
        reaction['category']='molecular_activity'
        category_additions.append(reaction['id'])
members=[e for e in result['mechanistic_edges'] if e['id'].startswith('native-member-')]
assert len(members)==9
assert all(not e['id'].startswith('primary-') for e in members)
assert not any(e['object']==native['id'] and e['predicate']=='part_of' for e in add['mechanistic_edges'])
args.output.parent.mkdir(parents=True,exist_ok=True)
args.output.write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=100))
print(json.dumps({'output':str(args.output),'sha256':hashlib.sha256(args.output.read_bytes()).hexdigest(),
 'native_members_unchanged':len(members),'reactions_including_context':len(result['reactions']),
 'participants':len(result['participants']),'top_edges':len(result['mechanistic_edges']),
 'mechanism_details':len(result['reaction_mechanisms']),'additive_native_reaction_categories':category_additions,
 'not_final_whole_record_acceptance':True}))
