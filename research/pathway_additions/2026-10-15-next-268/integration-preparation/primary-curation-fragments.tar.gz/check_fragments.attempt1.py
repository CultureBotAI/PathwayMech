"""Finite curation checks only: not final corpus, publication, or authority acceptance."""
from pathlib import Path
from collections import Counter
import copy, hashlib, json, re, shutil, sys, yaml

ROOT=Path(__file__).resolve().parent
WORK=Path('/private/tmp/pathwaymech-next-268-20261015')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,obj):(ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
checks=[]
def check(name,value):
 checks.append({'name':name,'passed':bool(value)})
 if not value:raise AssertionError(name)
binding_paths=[WORK/'src/pathwaymech/schema.py',WORK/'src/pathwaymech/reaction_mechanisms.py',
 WORK/'data/identifier_authorities/sources.json',WORK/'data/identifier_authorities/ontology.json']
before={str(p):sha(p) for p in binding_paths}
native=yaml.safe_load((ROOT/'inputs/pathwaymech-next-268-native-record-draft/phenylacetate-degradation-i-aerobic.native-draft.yaml').read_text())
record=yaml.safe_load((ROOT/'review-merged-record.yaml').read_text())
add=yaml.safe_load((ROOT/'fragments/primary-additions.yaml').read_text())
sources=json.loads((ROOT/'source-proof-bindings.json').read_text())
quotes=json.loads((ROOT/'quote-proof.json').read_text())
for key,b in sources.items():
 for role in ['original','projection']:
  check(f'{key} {role} exact SHA',sha(b[role]['path'])==b[role]['sha256'])
 check(f'{key} copied reading text exact',sha(b['owned_text'])==b['projection']['sha256'])
for key,q in quotes.items():
 text=re.sub(r'\s+',' ',Path(sources[q['source_key']]['owned_text']).read_text()).strip()
 check(f'{key} quote literal',re.sub(r'\s+',' ',q['evidence']['quote']).strip() in text)
 check(f'{key} quote bounded',len(q['evidence']['quote'])<=400)

for field in ['participants','references','mechanistic_edges']:
 check(f'native {field} objects retained',record[field][:len(native[field])]==native[field])
for before_rx,after_rx in zip(native['reactions'],record['reactions']):
 check('native reaction retained '+before_rx['id'],all(after_rx[k]==v for k,v in before_rx.items()) and after_rx['category']=='molecular_activity')
check('nine native member edges',len([e for e in record['mechanistic_edges'] if e['id'].startswith('native-member-')])==9)
check('no new pathway membership assertions',not any(e['predicate']=='part_of' and e['object']==record['id'] for e in add['mechanistic_edges']))
check('all nine source members have details',{m['source_reaction_id'] for m in record['reaction_mechanisms']} >= {r['id'] for r in native['reactions']})
check('no direct PaaJ net-catalysis addition',not any(e['subject']=='MetaCyc:MONOMER-15952' and e['object']=='MetaCyc:RXN0-6512' and e['predicate']=='catalyzes' for e in add['mechanistic_edges']))
ids={x['id'] for f in ['participants','reactions'] for x in record[f]}
refs={x['id'] for x in record['references']}
def evidence_walk(x,path='root'):
 if isinstance(x,dict):
  if 'reference_id' in x:
   check(path+' declared reference',x['reference_id'] in refs)
   check(path+' evidence exclusive quote/assertion',('quote' in x)!=('source_assertion' in x))
   check(path+' locator',bool(x.get('source_locator')))
  for k,v in x.items():evidence_walk(v,path+'/'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):evidence_walk(v,path+f'/{i}')
evidence_walk(add)
equations=[]
for m in record['reaction_mechanisms']:
 expected={side:Counter({t['participant_id']:t['coefficient'] for t in m['source_equation'][side]}) for side in ['inputs','outputs']}
 if m['source_equation']['orientation']=='reversed':expected={'inputs':expected['outputs'],'outputs':expected['inputs']}
 for conflict in m.get('source_conflicts',[]):
  side=conflict['side'];a=conflict['source_participant_id'];b=conflict['interpreted_participant_id'];q=conflict['coefficient']
  check(m['key']+' whole term substitution',expected[side][a]==q)
  del expected[side][a];expected[side][b]+=q
 actual={'inputs':Counter(),'outputs':Counter()}
 for e in m['edges']:
  for ep in ['subject','object']:
   if 'node_id' in e[ep]:check(m['key']+'/'+e['key']+'/'+ep+' declared',e[ep]['node_id'] in ids)
  if e['predicate'] in ['consumes','produces']:
   side='inputs' if e['predicate']=='consumes' else 'outputs'
   ep='subject' if side=='inputs' else 'object'
   actual[side][e[ep]['node_id']]+=e['coefficient']
 cancel=actual['inputs'] & actual['outputs']
 actual={side:actual[side]-cancel for side in actual}
 check(m['key']+' exact net',actual==expected)
 if m['relation_to_source']=='alternative_interpretation':
  changed=m['source_conflicts'][0]['interpreted_participant_id']
  for e in m['edges']:
   if any(e[ep].get('node_id')==changed for ep in ['subject','object']):
    check(m['key']+' substitution described', 'source_conflicts' in e.get('description',''))
 equations.append({'key':m['key'],'source_reaction_id':m['source_reaction_id'],'orientation':m['source_equation']['orientation'],
  'source_equation':m['source_equation'],'source_conflicts':m.get('source_conflicts',[]),'computed_net':{side:dict(c) for side,c in actual.items()}})
save('all11-detail-net-replay.json',equations)

# Compare additions to the exact snapshot now released to independent authority review.
authority={}
for fn in ['sources.json','ontology.json']:
 data=json.loads((WORK/'data/identifier_authorities'/fn).read_text());authority.update(data['terms'])
selected=[]
for field in ['participants','reactions']:
 for x in add[field]:
  check('authority contains '+x['id'],x['id'] in authority)
  a=authority[x['id']]
  check('canonical added label '+x['id'],x['label']==a['label'])
  selected.append({'field':field,'declaration':x,'snapshot_entry':a})
save('new-declaration-authority-label-check.json',{'snapshot_bindings':before,'selected':selected,
 'scope':'Direct label/existence check only; not a replacement for the authority owners adapter tests or final whole-record gate.'})

claim_groups=json.loads((ROOT/'all68-accepted-input-claims.json').read_text())
dispositions=json.loads((ROOT/'claim-to-output-dispositions.json').read_text())
claim_ids={c.get('id') or c.get('claim_id') for cs in claim_groups.values() for c in cs}
check('all 68 exact claim IDs',len(dispositions)==len(claim_ids)==68 and {d['claim_id'] for d in dispositions}==claim_ids)
check('every claim has output',all(d['outputs'] for d in dispositions))
check('all disposition inputs preserved',all(d['accepted_claim'] in claim_groups[d['accepted_input_group']] for d in dispositions))
for cid in ['N268-P16','N268-P20','N268-P23']:
 check(cid+' correction retained',any(d['claim_id']==cid and any('accepted correction' in n for n in d['successor_scope_notes']) for d in dispositions))

# Reuse the now implemented schema only for this draft's shape/API. This is not
# the root's eventual closed-schema, corpus, graph, KGX or scientific acceptance.
sys.path.insert(0,str(WORK/'src'))
from pathwaymech.schema import validate_record
validated=validate_record(record)
check('current semantic shape/API',validated.id=='MetaCyc:PWY0-321')
after={str(p):sha(p) for p in binding_paths}
check('validation code and authority files unchanged during replay',before==after)
save('implementation-input-bindings.json',{'before':before,'after':after,'unchanged':before==after})

# Copy the 16 authentic originals required for primary retention, plus the two
# issuing originals directly used in the targeted PaaZ construct proof.
retained=[]
for key,b in sources.items():
 original=Path(b['original']['path']);target=ROOT/'source-originals'/f'{key}{original.suffix}'
 target.parent.mkdir(exist_ok=True);shutil.copyfile(original,target)
 check(key+' retained original',sha(target)==b['original']['sha256'])
 retained.append({'source_key':key,'reference_id':b['reference_id'],'original':b['original'],
  'owned_path':str(target.relative_to(ROOT)),'sha256':sha(target),'reading_scope':'Reuse of accepted source reading plus targeted quote checks; no claim of fresh complete reading.'})
construct=json.loads((ROOT/'paaz-construct-direct-replay.json').read_text())
for key in ['pdb_original','reference_original']:
 p=Path(construct[key]['path']);target=ROOT/'source-originals'/p.name;shutil.copyfile(p,target)
 check(key+' retained construct original',sha(target)==construct[key]['sha256'])
 retained.append({'source_key':key,'original':construct[key],'owned_path':str(target.relative_to(ROOT)),'sha256':sha(target),
  'reading_scope':'Fresh targeted exact polymer/alignment replay; not a repeat all-structure review.'})
save('retained-source-originals.json',retained)

old=json.loads((ROOT/'input-bindings-before.json').read_text())
check('input binding shape',isinstance(old,list))
unchanged=[]
for b in old:
 a=sha(b['path']);check('frozen input unchanged '+b['path'],a==b['sha256']);unchanged.append(dict(b,after_sha256=a))
save('input-bindings-after.json',unchanged)
save('fragment-checks.json',{'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':0,
 'scope':'Finite source/quote, added-label, complete claim-disposition, exact material-net and current semantic API checks; no final whole-record acceptance asserted.'})
print(json.dumps({'passed':len(checks),'failed':0,'retained_originals':len(retained),'detail_nets':len(equations),'claims':len(claim_ids)}))
