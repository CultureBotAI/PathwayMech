# Independent primary-review handoff

Owner: `/root/next268_chemistry_acceptance`. Review target: the frozen `/private/tmp/pathwaymech-next-268-primary`, manifest SHA256 e8ff939c1f2e6eb77d651445efd248932dd80201d2e491a855af14b3d8a7f0f6, HANDOFF SHA256 8fd3ff54255d98230007fb40b52971d5048e9c350e9150596775f75b2760e187, freeze SHA256 d571f879296b8846363284cf6187d51cc861f341019edabea3b44bcbf77eaa60; 500 manifested / 502 physical files. Full original HANDOFF and all claim/reading/action ledgers were read.

Decision: corrections required, with bounded scientific acceptance for unaffected claims. `findings.json` has three supported findings: N268-PR01 (P16, medium), N268-PR02 (P20, medium), N268-PR03 (P23, low). Each includes exact source hash, locators, interpretation, required correction and visual evidence. Parent should file supported findings and commission a separate author successor. The immutable author package must not be edited in place. Parent's targeted confirmations are external corroboration, not substituted for this independent full review.

Review owners:

- `ASSESSMENT.md` and `fresh-reading-notes.md`: scientific assessment and reading detail.
- `all31-claim-dispositions.json`: 27 bounded acceptances, three corrections, one partial lead.
- `all25-reading-scope-dispositions.json`: exact fresh/partial/reused original and figure scopes; prior independent owners bound by hash.
- `all9-member-and25-activity-dispositions.json`: every native member/activity retained; nine core contexts, three supporting contexts and thirteen exclusions remain distinct.
- `all11-regulatory-dispositions.json`: correct finite native closure, individual primary limits and nested accessory context.
- `all-open-action-dispositions.json`: all ten primary actions and seven chemistry actions; O02/O03 not closed.
- `source-access-dispositions.json`, `acquisition-assessment.json`, `literature-screen-replay.json`, `imodulondb-replay.json`: complete finite source accounting and honest access roles.
- `all-native-slot-replay.json`: exact replay of all 33 full native objects/slots; `native-reading-projection.txt` plus documented selected nested reading distinguish computational completeness from primary scientific reading.
- `adversarial-assessments.json`: targeted counterinterpretation tests and surviving limitations.
- `machine-checks.json`, `pdf-reproduction-results.json`, `closing-verification.json`: 1,314 replay checks, 60 text/page matches, 20 closing checks, all passing.
- `execution-failures-and-limits.json`, `terminal-receipts.json`: failed initial assertion, retained exact failing script/checks/output, nonfatal PDFKit diagnostic and source failures.
- `input-integrity-before.json`, `input-integrity-after.json`, `governing-input-release.json`: all 2,201 binding events / 2,153 unique original paths, eight exact frozen inventories; eleven released historical worktree files checked/copy-bound, other 2,142 unique originals unchanged.

Fresh whole Nature SI now has independent acceptance within its own scope, including PaaZ cofactor correction, but Nature main and full I/Y tag bodies remain missing. Authentic PaaG2019 main, PaaFG2012 SI, canonical E/Z oxepin choice, isolated PaaJ cis-product issuer, Price attribution and actual267 merged rebind are unresolved. New root SlyA2017/reaction follow-ups are outside this cutoff. No canonical or maintained268 approval is supplied.

The earlier independent chemistry review remains unchanged: manifest 6e6335c28e7d554355af659434963ba4a6d8fb70dd5017a17bdeac989f0dad85, HANDOFF 9b4112b2c045546c4517832bd94f57b5b01f3198ad16d0c3263aa4d0fa800ec9, freeze 37df37817a09cac3347fee993e60b42df2094e68ebe4311dd69a7ffc73a28f41; 85 listed / 87 physical files. Its bounded chemistry acceptance and seven open actions are preserved, not overridden by primary review.

All writes are within this newly owned directory. Existing verified263 Python -B/no user site/no bytecode and existing source PDFKit helper were used; no installs, repairs, children or maintained/Git/GitHub changes. No job remains active. The artifact manifest excludes only itself and `freeze-proof.json`; the proof binds the manifest and HANDOFF and gives final exact physical counts. Freeze does not create a self-hash claim.
