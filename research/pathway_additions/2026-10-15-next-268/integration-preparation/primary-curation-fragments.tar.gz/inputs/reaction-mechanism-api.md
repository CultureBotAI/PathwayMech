# Mechanism API version 1

Implementation worktree: `/private/tmp/pathwaymech-next-268-20261015`.
Root owns semantic/closed schemas, `reaction_mechanisms.py`, KGX and provenance counts.
Rendering worker owns graph/page rendering and graph assets/tests. Do not regenerate pages yet.

`PathwayRecord.reaction_mechanisms` is a list, default `[]`. Each object has:

- `version: 1`, local ASCII `key`, `source_reaction_id`, `relation_to_source`
  (`decomposition` or `alternative_interpretation`), `description`, `evidence`.
- `source_equation`: `orientation` (`as_reported` or `reversed`), `inputs`, `outputs`.
  Each term has declared `participant_id` and exact positive integer `coefficient`.
  Inputs/outputs store the original source's equation. `reversed` selects its inverse
  for comparison to the detail, without changing the issued reaction's direction.
- `steps`: `key`, `label`, `description`, `assertion_status`
  (`supported`, `inferred`, `proposed`), `evidence` and optional `hypotheses`.
- Each hypothesis has `description`, `status: proposed`, `evidence`; no chemical node.
- `edges`: local `key`, typed `subject` and `object`, `predicate`, `assertion_status`,
  `evidence`, optional `description`, material-only `coefficient`, and optional
  `endpoint_qualifiers` with the existing payload. Endpoint is exactly one of
  `{node_id: <declared participant CURIE>}` or `{step_key: <local step key>}`.
- Predicates: `consumes` participant to step, `produces` step to participant,
  `catalyzes`/`enables` protein or complex to step, `precedes`/`provides_input_for`
  between distinct steps, `occurs_in` step to cellular component.
- All nested evidence uses the existing EvidenceItem grammar and local references.
  Qualifiers apply only to the specified declared protein/complex endpoint.
- Alternative interpretation requires `source_conflicts`: each has
  `source_participant_id`, `interpreted_participant_id`, `side` (`inputs` or `outputs`),
  exact positive `coefficient`, `kind` (`stereo`, `constitution`, `microstate`),
  `status` (`unresolved`, `proposed_revision`, `supported_revision`), `rationale`,
  `evidence`. Equal-quantity whole-term substitutions on the same selected equation
  side only; no unexplained residual or coefficient change. This is not equivalence.

Every mechanism is all-unlocated (location unspecified) or all steps explicitly
in one identical location. No implicit transport. The detail net is computed from
material edges with exact ID-based cancellation by
`pathwaymech.reaction_mechanisms.mechanism_equation(mechanism)`, which returns
`{inputs: [...terms...], outputs: [...terms...]}` for validated input. It is not a
claim of formula balance or an independent scientific validation.

`PathwayRecord.detail_only_participant_ids` is an explicit optional list, default
`[]`. Filter exactly these declarations out of the first/source graph. Never infer
this scope from isolation or usage. They must be used by a nested endpoint and may
not appear in top-level edges, source equations or source-side conflicts. Every
other declared node, including isolated source components, remains. Complete
component tables/export retain all declarations, with detail-only scope visible.
Source-specific validation additionally proves no native source member is hidden.

The nested graph is rendered through an explicit display-graph API with scoped
IDs, not a fabricated PathwayRecord or public CURIE. Every evidence/qualifier,
hypothesis and conflict must remain readable without JavaScript. Local claim keys
are navigation coordinates; show step labels to users. All graph controls must
work independently on a page containing the source graph and multiple details.
Use source representation labeling and affected-edge source-reporting notices
where alternatives conflict. References include qualifier/hypothesis/conflict-only
citations. KGX preserves the complete detail payload and all cited reference
metadata under the parent reaction's record-specific source_contexts; it never
flattens local steps into biological nodes or rewrites edges onto the parent net.
