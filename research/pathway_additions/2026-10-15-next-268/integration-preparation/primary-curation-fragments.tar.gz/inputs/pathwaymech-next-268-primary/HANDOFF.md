# next268 primary and regulatory dossier

Author preparation for MetaCyc:PWY0-321, phenylacetate degradation I (aerobic).
This packet is not independent acceptance and makes no maintained changes.
The actual merged267 baseline must be rebound before268 curation.

## Review entry points

- `primary-claim-ledger.json`: 31 proposed claims, each with exact source hash,
  locator, experiment, taxon/strain, construct, controls, caveats and reading IDs.
- `source-reading-scope-ledger.json`: 25 scopes distinguish fresh complete or
  partial reading, reused accepted native readings, frozen chemistry author
  readings, and native annotations. No fresh whole reading is implied by reuse.
- `nine-member-coverage.json`: all nine native members remain in scope.
  Ten transformations is a planning decomposition, not an established exhaustive
  elementary count. The detailed upper spontaneous intermediate remains a gap.
- `all25-activity-successor-dispositions.json`: every native activity context is
  retained, including excluded alternatives and source-only leads.
- `reused-native-claims-with-successor-dispositions.json`: all19 earlier claims
  remain visible, with explicit successor corrections for count, cofactor,
  accessory/regulation and newly accessible2012 main evidence.
- `open-actions.json`: ten explicit review, baseline, source, identity and
  interpretation obligations. None is silently resolved by this author packet.

## Material findings

Nature2012 DOI10.1038/nature10862 has an authentic 24-page SI. I read its entire
text and inspected all11 figures/all4 tables, plus the correction on page22.
It corrects the2011 PaaZ NAD+ result: absorption from the cyclic side derivative
was mistaken for NADH. At3mM NAD+, only residual ALDH activity remained and more
than95% substrate became derivative. The NADP+ Km was remeasured as17±3µM with
excess PaaY. Retain the earlier50%NAD+ and56±4µM claims only as historical,
superseded statements. This is not proof of absolute zero NAD+ turnover.

The chemistry reviewer separately bound and reproduced the original, full text
and page22 image and independently read that correction. That review does not
constitute acceptance of the entire SI or this mutable-then-frozen dossier.
The Nature main article remains unavailable. Exact PaaI/PaaY full tag bodies
are therefore not invented from this SI alone.

The same SI supplies oxygenase deoxygenation/cycling, PaaI/PaaY substrate panels,
and PaaY rescue of derivative-associated slowing. The inhibition interpretation
has time-course support, not a binding Kd. Its ABCE stoichiometry differs between
Table1 and discussion; no exact universal assembly coefficient is selected.
Table3 prints E56Q whereas the established2011 construct is E256Q; preserve this
source difference rather than creating a new verified mutant.

Fresh complete primary readings cover PaaI2006, PaaX2000/2004/2006 and PaaD2006.
PaaX2000 used crude extracts, despite native database evidence labels suggesting
purified protein. Its functional effector assay is not an isolated ligand-binding
constant. CRP and IHF have different binding/activation supports; the proposed
IHF bridge is a model. Ppac and Y2 styrene regulation are peripheral contexts.
PaaD whole-cell deletion/complementation and purified-complex dispensability are
different experiments. No direct D catalysis or universal in-vivo dispensability
is inferred.

Fresh scientific-main readings of SlyA2020 and SrsR2022 include all main figures
and tables. SlyA overproduction activates a PpaaA reporter in the tested LB
conditions; that paper does not perform a PpaaA EMSA. SrsR binds the paaZ/paaA
spacer in vitro, and qRT-PCR shows effects on paaZ, paaA and paaK after24h in LB.
W3110-derived in-vitro material and BW25113 in-vivo assays remain distinct. The
footprint is on yfdO/yfdP, not paaA/paaZ. Neither study proves phenylacetate flux
under those conditions. SrsR native RNA-seq labeling must not replace the actual
qRT-PCR method. Only Methods/early Results of SlyA2017 were accessible; do not
upgrade that partial reading to its later paa-specific results.

The complete core-route source reading is reused explicitly where already
performed by accepted native readers. Newly authenticated PaaFG2012 main reading
belongs to the frozen chemistry author; all11 text pages and all5 figures/2tables
were read there. Its SI remains unavailable. The2019 PaaG14-page SI is fully
read in the reused packets, but its authentic main remains inaccessible. Its
trans3,4 surrogate assays cannot become native cis3,4 kinetics.

The native E oxepin/PubChem representation, ChEBI Z representation and the
different CCD LHQ constitution stay separate. Isolated PaaJ cis-producing
reaction identity remains under a separate root follow-up; RXN0-6512 remains a
coupled net. Price2022 actually concerns P.bryophila376MFSha3.1 and Burkholderia
OAS925, whereas the native alternative accession is P.caledonica PHRS4. Author
code explains the mapping provenance but does not solve the sequence/strain
mismatch. Fitness is not purified catalysis. ECH-Aa weak oxepin activity, PacL
preparation-specific cofactor use and BoxD assay-versus-comparison taxa remain
qualified, without reducing the nine-member pathway scope.

## Finite regulatory and source search bounds

The new native acquisition has33 full native objects, including an intentionally
retained class object. The final direct promoter/TU closure has11 actual
regulation instances and no missing full object within that finite boundary.
Use `audit-verification/finite-regulatory-closure.json`. The original root-level
closure counted the parent class as a12th regulator and is retained only as a
superseded diagnostic. The final replay excludes `class=true`. G6721 is PaaY;
G6720 is PaaX. Exact DNA sequences for every referenced site and every regulator
protein were not recursively expanded, and no such unacquired exact-sequence
claim is proposed.

The targeted EuropePMC query returned37/37 records, each dispositioned in
`targeted-literature-dispositions.json`. The broad initial query returned only
1000 of11083 and is a lead search, not an exhaustively screened review. PaaX2014,
PaaX2024, additional taxon-specific PaaR/KDPG and accessory-enzyme leads remain
explicit. No general absence conclusion follows from these bounds.

All five E.coli iModulon dataset keys were searched for paaX and phenylacetate
(ten successful commands). Three PaaX module summaries were fully read. These
are expression/source-label contexts, not binding, catalysis or complete-route
proof; unrelated member regulators do not become pathway edges.

Root separately attempted the ACS main in a browser; the tool returned “No
browser is available”. The separately bound three-file receipt is tool-access
provenance only: no page was opened, no publisher response obtained.

## Preservation and reproducibility

- `acquired-original-manifest.json` retains136 original response bodies with
  paired receipts, including empty,403, challenge and unsuccessful responses.
  HTTP200 or a `.pdf` filename alone is not scientific full-text authentication.
- `reused-original-manifest.json` binds529 available prior originals at immutable
  source paths. Availability is not a claim that all529 were scientifically read.
- `inputs-before.json` and `chemistry-inputs-before.json` bind1178 and383 files.
  The complete selected sets were unchanged in both after-checks. This does not
  claim the entire evolving267 worktree was unchanged.
- `audit-verification/reproduction-and-binding-checks.json`:2202 passing checks
  for receipt hashes/lengths, native full-object selection, finite closure,
  selected input preservation, HTML projection reproduction and claim fields.
- `pdf-reproduction-proof.json`: complete Nature SI text and all24 rendered pages
  reproduce byte-identically with the retained existing PDFKit helper (25 checks).
- `final-source-binding-checks.json`:77 source binding checks pass after adding
  six explicit native-object source bindings to the claim ledger.
- `execution-and-correction-dispositions.json` retains author errors, bad guessed
  link probes, partial access, parser corrections and scientific supersessions.
  An unverified guessed link returning403 is not authentic source access proof.

No installation, runtime repair, Git/GitHub mutation, maintained corpus change,
or child-agent work was performed. All writes are under this owned directory.
The package manifest excludes only itself and `freeze-proof.json`; the latter
binds the manifest and records the exact self-exclusion and final counts.
