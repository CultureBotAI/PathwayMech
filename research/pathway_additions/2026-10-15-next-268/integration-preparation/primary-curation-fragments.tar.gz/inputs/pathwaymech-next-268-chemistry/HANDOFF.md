# PWY0-321 chemistry and reaction preparation

Author: `/root/next268_chemistry_preparation`. This is a source-preparation handoff for O02/O03, **not independent acceptance or permission to curate**. All nine native members, 40 material occurrences and 22 native material IDs are covered, together with the missing lower-route cis3,4 intermediate, relevant side products, cofactor candidates and explicitly unresolved mechanistic states. Exact oxepin identity, an isolated upper PaaJ reaction identity and authentic 2019 main-paper mechanism verification remain open. A separate chemistry reviewer and actual merged267 baseline rebind are mandatory before curation.

The five immutable input packets remain unchanged in every path, byte count and SHA256: **1,208 physical files**, including hidden/ignored files. `input-integrity-before.json` and `input-integrity-after.json` give every binding. All 100 copied source/reading/parser artifacts match their original owners; six read-only governing files are separately bound. The 77 previously bound runtime files also remain unchanged. No maintained worktree, source owner, Git, GitHub or runtime change, installation, child agent or whole-corpus test occurred.

## Complete chemical and reaction evidence

`native-complete-material-structure-replay.json` retains every native chemical slot, complete InChI/key, CML atom/bond graph, source SMILES, formula, charge, stereochemistry and checked cross-reference. `all-material-dispositions.json` supplies all 23 native-plus-cis decisions. Complete issuing records cover 37 ChEBI candidates, 25 PubChem compounds, two CCD components and additional native chemistry. Four unrelated ChEBI comparison leads are explicitly excluded. `all-new-acquisition-dispositions.json` accounts for all **87** new public requests, including nine failed/empty/login responses; the three initial PubChem 503 bodies are retained alongside successful retries. There is no successful authentic 2019 main-paper acquisition hidden among these requests.

The native atom/bond graphs independently match all 23 expected constitutions, formulae and charges. Nine native display-SMILES fields contain generic/template notation; they are not complete usable molecular structures. Oxepin's literal SMILES parses but does not specify its exocyclic geometry, whereas its native InChI specifies E. `native-cml-constitution-and-literal-smiles-replay.json` preserves those results. Standard InChI also normalizes mobile hydrogen: derived SMILES are analytical representations, not replacements for source literal graphs or proof of an enzyme-bound tautomer.

`all-native-equations-and-formal-net.json` preserves every reaction's original sides, coefficients, native direction and pathway flux direction. All nine equations, two proposed lower-route split equations and two contextual side-reaction equations balance atoms and charge. The complete Rhea142 original RDF, directions and release files are retained. A fresh replay covered 326,097 descriptions and 37,068 fixed directional equations, recording 154 symbolic exclusions; 19 relevant directional context equations independently balance. The two exact selected identifier sets for isolated C8→cis3,4 thiolysis and cis3,4→E2,3 isomerization did not match. This is a finite identifier-bound result, **not global reaction absence**.

Under the explicitly retained native ionic states, the formal net is:

```
phenylacetate + ATP + 3 CoA + O2 + NAD+ + 2 H2O
    → 2 acetyl-CoA + succinyl-CoA + AMP + diphosphate(3−) + NADH + 2 H+
```

NADP/NADPH cancel between oxygenation and aldehyde oxidation in this formal sum. Native `NAD+` and `NADP+` labels describe redox forms, not total molecular charges; exact total charges are −1 and −3 respectively. Catalytic Mg, flavin and iron do not become consumed formal-net reagents. The paper's neutral-acid proton convention is distinct from the native ionic convention.

## Conflicts that must remain visible

| Material or reaction | Supported disposition |
|---|---|
| Diphosphate | Native `/p-3`, HO7P2/−3 matches CHEBI:33019. Native CHEBI:29888 and PubChem:1023 refer to neutral H4O7P2 and are not exact aliases. |
| E2,3 didehydroadipoyl-CoA | Native explicit E matches CHEBI:195329 and PubChem:70679154. CHEBI:71044 is unspecified alkene stereo. |
| C8 3oxo5,6 didehydrosuberyl-CoA | Native/PubChem:46926111 is 5Z/−5. CHEBI:63253 is neutral and unspecified stereo; CHEBI:63255 corrects charge but still omits stereo. |
| C8 semialdehyde | Native/PubChem:90659275 is 5Z/−4. Rhea CHEBI:63257 omits alkene stereo. |
| Final oxepin-CoA | Native InChI/PubChem:122706391 is E; CHEBI:63252 is Z. The native literal SMILES is less specified. The authentic 2010 Fig3 drawing places carbonyl C1 and ring O on the same side, consistent with Z by manual CIP interpretation; it does not settle all experimental assignment issues. The vendor transcript's 2019 Z assignment awaits authentic main verification. |
| PDB CCD LHQ / 6SLA | Deposited neutral C29H44N7O18P3S differs in bonding and has two more H than neutral oxepin-CoA C29H42N7O18P3S. It cannot serve as an exact identity witness for either E or Z oxepin. Authors' intended ligand, deposited component and assay evidence are separate. |
| PDB CCD T3D / 6SLB | Deposited neutral trans3,4 didehydroadipoyl-CoA is distinct from native cis3,4 and trans2,3 product. The SI's `10/12` label does not make its single CCD molecular graph an exact mixture identity. |
| Native epoxide | Exact source structures agree, but two epoxide stereocentres remain undefined. Do not infer a single enantiomer. |
| RXN0-6512 / EC2.3.1.223 | Lumped PaaJ thiolysis plus PaaG isomerization chemistry. IUBMB still gives a net with double-bond migration. It is not an exact isolated PaaJ→cis3,4 identity. |
| Rhea34441 | Obsolete, with explicit replacement comment pointing to generic master34799; physiological34801 retains unspecified stereo and the lumped net. |
| Rhea34863 | Obsolete literal comment names25249, which actually describes acetolactate synthesis. Reject automatic biological replacement. Separately verified76649 is exact E/S hydration, not a declared successor. |
| RXN-2424 | Exact cis3,4→E2,3 native chemistry, YES-PUTATIVE and PWY-1361 membership; not a PWY0-321 member and no Box catalyst transfer. |

`all-reaction-dispositions.json`, `additional-chemistry-and-ccd-replay.json` and `rhea-complete-selected-replay.json` retain full evidence and source statements for these decisions. Every lower-route reaction is included; no reduced easy-substrate route substitutes for the full route.

## Primary reading and mechanistic limits

`primary-reading-and-claim-scopes.json` records precise fresh reading, original hashes, claims and reuse limits. The complete 2010 main and 2011 PaaZ main were freshly read, with all ten main figure images personally inspected. The newly root-acquired **11-page 2012 PaaFG main PDF** was read in full as text; pages2,5–9 were visually inspected, covering all five main figures and both tables. This extends root's explicitly first-page-only reading and awaits independent acceptance. It supports a six-PaaF/six-PaaG four-layer assembly under specified E.coli constructs and conditions; docking, catalytic-residue assignments and channeling advantages remain proposals. No connecting tunnel is reported. Its missing supplemental TablesS1/S2 and FigsS1–S8 are not claimed read.

All 14 pages of the authentic 2019 PaaG supplement were read as text and visually inspected. The issuing indexed author abstract was read in full. The abstract supports PaaG's second cis3,4→trans2,3 role. The SI supports trans3,4 **surrogate** kinetics, epoxide assays and specified variants/structures; it does not supply the full native-cis coupled assay, oxepin assignment rationale or upper spontaneous valence-tautomer mechanism. Thermus JL-18, Y2, native cis and synthetic trans remain distinct. Full-authentic-main access attempts via ACS, repository/metadata and Semantic Scholar did not succeed; Semantic Scholar's advertised open file was the supplement, and its hash-path PDF attempt was empty. The vendor transcription remains a lead.

The upper route is closed only to the extent primary evidence permits: the authentic 2010 study establishes a PaaG-dependent **epoxide-to-final-oxepin net** and proposes elementary steps. The more specific spontaneous reversible epoxide↔2-(oxepinyl)acetyl-CoA valence tautomer, followed by PaaG proton shuttling to the conjugated final oxepin, is a documented 2019-main lead. It is not silently turned into an accepted elementary edge or assigned an invented molecular ID. The primary2011 hydrolysis mechanism likewise contains proposed oxonium/enolate, hydrated cyclic and open-chain enol states. These are retained in `mechanistic-state-ledger.json`; resonance drawings are not automatically separate metabolites. **Nine native members and ten planning transformations are not an exhaustive elementary-mechanism count.**

The 2011 main supports an unstable semialdehyde and a structurally characterized cyclic dead-end CoA derivative; it does not claim isolation/trapping of that semialdehyde. Newly acquired CPD0-2558/PubChem122706490 and spontaneous RXN-17752 exactly represent the derivative plus water. The source's putative status is retained. Contextual RXN0-7103 hydrolysis and CPD0-2559/PubChem90657133 are retained and balanced, but their enzyme/primary scope is not promoted from a low-detail backlink. The derivative remains a side product, not native catabolic flux.

Targeted new reads of the full retained 2000 PaaK and 2011 PaaABCE originals support Mg2+ dependence and the cofactor distinctions, with exact passages recorded. Earlier complete reading by separate accepted reviewers is not represented as this author's fresh reading. Bound Fe oxidation/occupancy and FAD microstate are not fixed by bulk assays. An additional replay limitation is explicit: RDKit imports the issuing FAD3− InChI as FAD2−, while the issuer's literal FAD3− SMILES correctly reproduces its −3 charge/formula/InChI. This is not a reason to silently change source chemistry or select a physiological state.

## Next actions and freeze

`open-actions.json` names seven concrete obligations: oxepin conflict disposition; exact isolated PaaJ reaction identity; authentic2019 main acquisition/verification; precise native/Rhea microstate and stereo identity design; transient/cofactor/sidebranch evidence limits; missing2012 supplemental claims; and independent chemistry acceptance plus actual merged267 rebind. Other discovery, regulatory/accessory and native biological obligations remain open at their owners. This packet neither declares the route ready nor treats source-access gaps as resolved.

`author-verification.json` gives the passed checks; `execution-failures-and-limits.json` preserves failed author attempts, corrected helper assumptions and library limits. Full acquisition bodies, headers, hashes, failures and source-copy provenance remain available. `artifact-manifest.json` binds every retained output except itself and `freeze-proof.json`; the freeze proof binds the manifest and this handoff with the physical inventory count. All inventories include hidden/ignored files. **Do not modify the frozen packet; use an explicit successor for new evidence or corrections.**
