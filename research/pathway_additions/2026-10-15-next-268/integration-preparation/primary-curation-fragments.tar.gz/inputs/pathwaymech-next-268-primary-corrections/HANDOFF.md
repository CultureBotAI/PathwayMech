# Primary-claim correction successor

Root author successor addressing independently confirmed findings N268-PR01/#609, N268-PR02/#610 and N268-PR03/#611. Independent acceptance is still required. Frozen primary502-file and review124-file packages remain unchanged.

`primary-claim-ledger.corrected.json` supersedes the three defective claim entries only. P16 now separates unchanged A.evansii before/after purification activity, suspected E.coli D61A host contamination, and undetectable A.evansii D75A activity. P20 separates TableII AF15PZ/Pz ligase-dependent induction from TableIII AF15/Pa operator-mutant reporter results, retaining the unreported TableIII PA condition as unreported. P23 qualifies indirect IHF action as inferred and preserves the negative binding assay with its positive control.

The other28 claims and all52 original source byte bindings are unchanged. The original historical generator retains the old wording as immutable provenance; `apply_corrections.py` is the reproducible successor owner. `exact-field-changes.json` records every before/after field. Source locators were made precise without changing originals. Both complete frozen packages were rehashed before/after, including hidden and ignored files; semantic acceptance is not inferred from these checks.

Read the correction ledger, exact changes, verification, issue dispositions, original independent findings and root confirmations. Three GitHub issues remain open pending independent acceptance and retention in a verified merged tree. No maintained record, Git state, runtime or source original was changed. This does not close the SlyA2017 follow-up or remaining chemistry/source/baseline obligations. Root correction/reproduction jobs are terminal exit0; no process uses this packet.
