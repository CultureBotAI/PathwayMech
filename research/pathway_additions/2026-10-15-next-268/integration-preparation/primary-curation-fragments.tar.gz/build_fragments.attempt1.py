"""Author reproducible, reviewable fragments; no maintained input writes."""
from pathlib import Path
from collections import Counter
import copy, hashlib, json, re, yaml

ROOT = Path('/private/tmp/pathwaymech-next-268-primary-curation-fragments')
def dump(name, obj):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
def ydump(name, obj):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(obj, allow_unicode=True, sort_keys=False, width=100))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def norm(value): return re.sub(r'\s+', ' ', value).strip()

bindings = json.loads((ROOT/'source-proof-bindings.json').read_text())
if bindings['PaaZ2019']['reference_id'].endswith('11931-3'):
    dump('source-proof-bindings.attempt1.json', bindings)
    bindings['PaaZ2019']['reference_id'] = 'DOI:10.1038/s41467-019-11931-1'
    dump('source-proof-bindings.json', bindings)
    dump('staging-reference-correction.json', {
        'scope':'Owned staging metadata only; no accepted input changed',
        'before':'DOI:10.1038/s41467-019-11931-3',
        'after':bindings['PaaZ2019']['reference_id'],
        'proof':bindings['PaaZ2019']['original'],
        'locator':'publisher article citation_doi / dc.identifier metadata',
        'reason':'Author transcription error detected by direct original metadata check before output generation'})
sources = {k:norm(Path(v['owned_text']).read_text()) for k,v in bindings.items()}
quotes = {}
def q(key, source, quote, locator):
    assert norm(quote) in sources[source], (key, source, quote)
    assert len(quote) <= 400, key
    item = {'reference_id':bindings[source]['reference_id'], 'quote':quote, 'source_locator':locator}
    quotes[key] = {'evidence':item, 'source_key':source, 'original':bindings[source]['original'],
                   'projection':bindings[source]['projection'], 'check':'literal after whitespace normalization only'}
    return item

q('ligase','PaaK2000','The PA-CoA ligase reaction was dependent on PA, ATP, Mg2+, and CoA.','Results, Catalytic properties of PA-CoA ligase; original HTML paragraph preceding Fig. 4')
q('mg','PaaK2000','The activity was absolutely dependent on the cocatalyst Mg2+ (5 mM);','Results, Inhibitors and metal dependence')
q('epoxide','PNAS2010','13C-NMR analysis substantiated ring 1,2-epoxyphenylacetyl-CoA','Results, Phenylacetyl-CoA Oxygenase; Table 2 and Fig. 2B')
q('abceprep','PNAS2010','The genes for all subunits were expressed simultaneously with PaaA as a maltose-binding protein (mbp)-tagged protein.','Results, Phenylacetyl-CoA Oxygenase, first paragraph')
q('assembly','PNAS2010','Subunits PaaB, PaaC, and PaaE copurified with PaaA, whereas PaaD, a suspected subunit of this complex, eluted separately.','Results, Phenylacetyl-CoA Oxygenase, first paragraph')
q('upperg','PNAS2010','We purified his-tagged PaaG and found that it catalyzed a reversible conversion of the epoxide to a new product','Results, Ring Expansion; Fig. 2C and Table 2')
q('z','PNAS2010','PaaZ thus functioned as an oxepin-CoA hydrolase/ 3-oxo-5,6-dehydrosuberyl-CoA semialdehyde dehydrogenase','Results, Hydrolytic Ring Opening; Fig. 2D and Table 2')
q('zprep','PaaZ2011','purified recombinant MBP-tagged PaaZ','Results, Hydrolytic Ring Cleavage of Oxepin-CoA; first paragraph')
q('aldehyde','PaaZ2011','the proposed open-chain aldehyde (V) rapidly forms a seven-membered carbon ring through Knoevenagel-type condensation.','Results, Identification of the cyclic derivative; Fig. 4 and Table 1')
q('zproposal','PNAS2010','The resulting ring-opened C8 alcohol rearranges through keto-enol tautomerism to the aldehyde','Discussion, Mechanism of the Ring Expansion and Hydrolytic Ring Cleavage; Fig. 3B')
q('gproposal','PNAS2010','PaaG mediates the formation and stabilization of the enolate form by abstracting a proton from the side chain at C2','Discussion, proposed PaaG mechanism; Fig. 3A')
q('jnet','PNAS2010','we added purified PaaJ to an enzymatic assay containing PaaABC(D)E, PaaG, and PaaZ.','Results, β-Oxidation of the Ring-Opened Intermediates; Fig. 2E')
q('jcis','PNAS2010','the expected product of a thiolytic cleavage of 3-oxo-5,6-dehydrosuberyl-CoA by PaaJ ought to be 3,4-dehydroadipyl-CoA','Discussion, paragraph beginning The next β-oxidation steps')
q('glower','PNAS2010','This 3,4–2,3 isomerization reaction probably was catalyzed by enoyl-CoA isomerase PaaG, which was present in the assay.','Discussion, paragraph beginning The next β-oxidation steps')
q('f','PNAS2010','catalyzed the reversible conversion of enzymatically produced 2,3-dehydroadipyl-CoA into 3-hydroxyadipyl-CoA','Results, β-Oxidation of the Ring-Opened Intermediates; Fig. 2F')
q('h','PNAS2010','We observed the formation of NADH, succinyl-CoA, and acetyl-CoA in the presence of CoA, NAD+, and PaaJ','Results, β-Oxidation of the Ring-Opened Intermediates; Fig. 2G')
q('hprep','PNAS2010','we added purified mbp-tagged PaaH to enzymatically produced 3-hydroxyadipyl-CoA.','Results, β-Oxidation of the Ring-Opened Intermediates; Fig. 2G')
q('jterminal','PNAS2010','PaaJ finally cleaved 3-oxoadipyl-CoA into the central metabolites succinyl-CoA','Results, β-Oxidation of the Ring-Opened Intermediates; Fig. 2G')
q('tag','Nature2012','which adds a maltose-binding protein (mbp) to the amino terminus of the expressed proteins.','PDF p. 5, Methods, Molecular biological techniques, pMAL-c2X paragraph')
q('mass','Nature2012','For PaaI and PaaY, the activities were corrected for the size of untagged protein.','PDF p. 5, Methods, Enzyme measurements')
q('i','Nature2012','reasonable activity exclusively for pa-CoA','PDF p. 3, main text, paragraph introducing PaaI; Supplementary Table 4 for tested panel')
q('y','Nature2012','specifically hydrolyses inhibitory 2-hydroxycyclohepta-1,4,6-triene-1- carboxyl-CoA','PDF p. 3, main text, paragraph introducing PaaY; line wrap retained as a space')
q('hexamer','PaaZ2019','The PaaZ structure containing six monomers can be described as a tri-lobed architecture','Results, PaaZ cryoEM structure; Fig. 2a,b')
q('x','PaaX2000','indicated a PaaX-mediated repression effect on the expression of Pa-lacZ and Pz-lacZ reporter fusions.','PDF p. 1, abstract; experimental distinction in Tables II and III')
q('pac','PaaX2004','PaaX and the cyclic AMP receptor protein (CRP) bind in vitro to the Ppac promoter region.','Abstract; Figs. 2 and 4, E. coli W context')
q('ihfnegative','PaaX2004','IHF was not able to retard the migration of the PPAC probe, whereas it was able to retard our control IHF probe, PR-PG','Results, In vitro analysis of CRP and IHF binding; Fig. 4B')

claims = json.loads((ROOT/'all68-accepted-input-claims.json').read_text())
native = yaml.safe_load((ROOT/'inputs/pathwaymech-next-268-native-record-draft/phenylacetate-degradation-i-aerobic.native-draft.yaml').read_text())
rxns = {x['id']:x for x in json.loads((ROOT/'inputs/pathwaymech-next-268-chemistry/all-reaction-dispositions.json').read_text())}
def E(*keys): return [copy.deepcopy(quotes[k]['evidence']) for k in keys]
def structured(ref, assertion, locator):
    assert len(assertion)<=400
    return {'reference_id':ref,'source_assertion':assertion,'source_locator':locator}
def qualifier(description, *keys, endpoint='subject'):
    assert len(description)<=400, description
    return [{'endpoint':endpoint,'kind':'experimental_construct','description':description,'evidence':E(*keys)}]
def node(i,label,category='small_molecule'): return {'id':i,'label':label,'category':category}
def n(i): return {'node_id':i}
def s(i): return {'step_key':i}
def terms(xs): return [{'participant_id':i,'coefficient':c} for i,c in xs]

M='MetaCyc:'
I='EcoCyc:G6717-MONOMER'; Y='EcoCyc:G6721-MONOMER'
cis=M+'CIS-34-DEHYDROADIPYL-COA'; zox='CHEBI:63252'; mg='CHEBI:18420'
add = {'participants':[
 node(zox,'(2Z)-oxepin-2(3H)-ylideneacetyl-CoA(4−); evidence interpretation'),
 node(cis,'cis-3,4-dehydroadipyl-CoA'),node(mg,'magnesium(2+)','cofactor'),
 node(I,'PaaI thioesterase; E. coli K-12 reference','protein'),node(Y,'PaaY thioesterase; E. coli K-12 reference','protein'),
 node('EcoCyc:ENZRXN0-7862','phenylacetyl-CoA thioesterase activity','molecular_activity'),
 node(M+'CPD0-2558','2-hydroxycyclohepta-1,4,6-triene-1-carboxyl-CoA'),
 node(M+'CPD0-2559','2-hydroxycyclohepta-1,4,6-triene-1-carboxylate')],
 'reactions':[{'id':M+'RXN-17752','label':'putative spontaneous cyclic dead-end formation; contextual side branch','direction':'left_to_right'},
 {'id':M+'RXN0-7103','label':'PaaY cyclic CoA-derivative hydrolysis; contextual salvage','direction':'left_to_right'}],
 'references':[], 'mechanistic_edges':[], 'reaction_mechanisms':[],
 'detail_only_participant_ids':[zox,cis]}

used_refids=set()
for key,b in bindings.items():
    # Original body, not a rendered extraction, anchors each primary reference.
    rid=b['reference_id']; assert rid not in used_refids
    used_refids.add(rid)
    add['references'].append({'id':rid,'citation':f'{key}: retained authentic primary original; see claim and quote proof ledgers for exact scope.',
      'url':('https://pubmed.ncbi.nlm.nih.gov/'+rid.split(':',1)[1]+'/' if rid.startswith('PMID:') else 'https://doi.org/'+rid.split(':',1)[1]),
      'source_sha256':b['original']['sha256'],'source_version':'Retained original read in accepted next268 evidence packets'})

authority_paths={
 zox:'/private/tmp/pathwaymech-next-268-chemistry/originals/initial/ChEBI-63252.json',
 mg:'/private/tmp/pathwaymech-next-268-chemistry/originals/mechanism/ChEBI-18420.json',
 cis:'/private/tmp/pathwaymech-next-268-chemistry/originals/initial/MetaCyc-CIS-34-DEHYDROADIPYL-COA.xml',
 M+'CPD0-2558':'/private/tmp/pathwaymech-next-268-chemistry/originals/derivative-native/MetaCyc-CPD0-2558.xml',
 M+'CPD0-2559':'/private/tmp/pathwaymech-next-268-chemistry/originals/sideproduct/MetaCyc-CPD0-2559.xml',
 M+'RXN-17752':'/private/tmp/pathwaymech-next-268-chemistry/originals/mechanism/MetaCyc-RXN-17752.xml',
 M+'RXN0-7103':'/private/tmp/pathwaymech-next-268-chemistry/originals/mechanism/MetaCyc-RXN0-7103.xml',
 I:'/private/tmp/pathwaymech-next-268-primary/originals/native-ECOLI-G6717-MONOMER.xml',
 Y:'/private/tmp/pathwaymech-next-268-primary/originals/native-ECOLI-G6721-MONOMER.xml',
 'EcoCyc:ENZRXN0-7862':'/private/tmp/pathwaymech-next-268-primary/originals/native-regulation-ECOLI-ENZRXN0-7862-retry.xml'}
for rid,path in authority_paths.items():
    if rid in [x['id'] for x in native['references']]: continue
    add['references'].append({'id':rid,'title':f'Issuing authority original for {rid}', 'source_sha256':sha(path),
      'source_version':'Retained issuer response; exact object and scope independently reviewed',
      'url':('https://www.ebi.ac.uk/chebi/searchId.do?chebiId='+rid if rid.startswith('CHEBI:') else 'https://biocyc.org/'+('META' if rid.startswith('MetaCyc:') else 'ECOLI')+'/NEW-IMAGE?object='+rid.split(':',1)[1])})
dump('additional-public-id-proof-ledger.json',[{'id':rid,'original_path':path,'sha256':sha(path),
 'role':'detail chemical' if rid in [cis,zox] else 'cofactor' if rid==mg else 'contextual salvage',
 'limitations':'No equivalence to the conflicted native E oxepin' if rid==zox else 'Issued reference identity; experimental construct and taxon qualifications remain separate'} for rid,path in authority_paths.items()])

def edge(key,subject,predicate,obj,ev,description,quals=None):
    x={'id':key,'subject':subject,'predicate':predicate,'object':obj,'description':description,'evidence':ev}
    if quals: x['endpoint_qualifiers']=quals
    add['mechanistic_edges'].append(x)
edge('primary-paak-magnesium',M+'MONOMER-12132','has_cofactor',mg,E('mg'),
 'Purified native aerobic Azoarcus evansii KB740 (DSM 6898) PaaK required 5 mM Mg2+ in the assay. Mn2+ replaced it at 36% activity; no consumed magnesium term is added to the reaction.')
tagI=qualifier('E. coli K-12 PaaI expressed from pMAL-c2X with N-terminal MBP; Nature 2012 reports NP_415914.1. Activities are corrected for untagged-protein mass, not measured after documented tag removal. Complete fusion sequence is not established.','tag','mass')
tagY=qualifier('E. coli K-12 PaaY expressed from pMAL-c2X with N-terminal MBP; Nature 2012 reports NP_415918.1. Activities are corrected for untagged-protein mass, not measured after documented tag removal. Complete fusion sequence is not established.','tag','mass')
edge('primary-paai-thioesterase',I,'enables','EcoCyc:ENZRXN0-7862',E('i','tag'),
 'Tagged PaaI hydrolyzed phenylacetyl-CoA at 1.6±0.1 U/mg at 22°C in the tested panel. Assay: 0.15 ml, 0.08 mg protein, 0.25–0.5 mM substrate, 2 min; CoA/product quantified by HPLC. Cellular epoxide protection is a hypothesis. The approximately 10 µM Km cited in 2012 belongs to the 2006 study.',tagI)
edge('primary-paay-cyclic-hydrolysis',Y,'catalyzes',M+'RXN0-7103',E('y','tag'),
 'Tagged PaaY hydrolyzed the cyclic CoA derivative: 7.6±0.6 U/mg and apparent Km 35±15 µM at 22°C, pH 8. Assay: 0.1 ml, 6 µg protein, 0.5 mM substrate, 2 min. This is contextual salvage, not an additional native PWY0-321 member.',tagY)
edge('primary-paaz-assembly',M+'G6708-MONOMER','part_of',M+'CPLX0-8538',E('hexamer'),
 'The 2019 cryoEM preparation forms six monomers arranged as three domain-swapped dimers. Distinct apo, NADPH, NADP+/octanoyl-CoA and NADP+/crotonyl-CoA structures are not direct observations of natural pathway intermediates.',
 qualifier('E. coli PaaZ structural preparation: 688-aa construct comprising MGHHHHHH plus reference residues 2–681, as verified separately against PDB entities. Growth-assay ASKA constructs and the MBP-tagged 2011 preparation are distinct.','hexamer'))

def mechanism(key,rid,label,description,status,evkeys,catalyst=None,qual=None,hypotheses=None):
    rx=rxns[rid]
    m={'version':1,'key':key,'source_reaction_id':rid,'relation_to_source':'decomposition',
       'description':description,'evidence':E(*evkeys),
       'source_equation':{'orientation':'reversed' if rx['pathway_flux_direction']=='R2L' else 'as_reported',
          'inputs':terms(rx['source_sides']['left']),'outputs':terms(rx['source_sides']['right'])},
       'steps':[{'key':'transform','label':label,'description':description,'assertion_status':status,'evidence':E(*evkeys)}], 'edges':[]}
    if hypotheses: m['steps'][0]['hypotheses']=hypotheses
    for side,pred in [('physiological_substrates','consumes'),('physiological_products','produces')]:
        for idx,(pid,count) in enumerate(rx[side],1):
            m['edges'].append({'key':f'{pred}-{idx}','subject':n(pid) if pred=='consumes' else s('transform'),
             'object':s('transform') if pred=='consumes' else n(pid),'predicate':pred,'coefficient':count,
             'assertion_status':status,'description':'Material identity and coefficient follow the retained source equation; experimental scope is stated on the local step.',
             'evidence':E(*evkeys)+[structured(rid,'Source left/right participants and coefficients; orientation follows the retained reaction-layout.',f'Reaction {rid.split(":",1)[1]} / left, right; Pathway PWY0-321 / reaction-layout')]})
    if catalyst:
        e={'key':'catalyst','subject':n(catalyst),'object':s('transform'),'predicate':'catalyzes','assertion_status':status,'evidence':E(*evkeys)}
        if qual:e['endpoint_qualifiers']=qual
        m['edges'].append(e)
    add['reaction_mechanisms'].append(m)
    return m
def hypothesis(description,*keys): return {'description':description,'status':'proposed','evidence':E(*keys)}

mechanism('primary-paak-activation',M+'RXN-10819','ATP-dependent phenylacetate activation',
 'Native untagged A. evansii KB740 aerobic PaaK catalyzes phenylacetate + ATP + CoA to phenylacetyl-CoA + AMP + diphosphate. The 440-aa reference and measured N terminus MPVKTPSPG were independently matched. This separate ligase assay is not proof of all nine reactions in KB740. Native diphosphate(3−) is retained; no silent microstate normalization.',
 'supported',['ligase'],M+'MONOMER-12132')
abcequal=qualifier('Pseudomonas sp. Y2 PaaABCE recombinant preparation with N-terminal MBP on PaaA; PaaB/C/E copurify. PaaD elutes separately. Exact full tag/linker sequence and a single integer complex stoichiometry are not established.','abceprep','assembly')
mechanism('primary-abce-epoxidation',M+'RXN0-2042','Phenylacetyl-CoA ring epoxidation',
 'The Y2 MBP-PaaA-containing preparation yields ring-1,2-epoxyphenylacetyl-CoA by HPLC/MS/NMR; 18O2, not H2-18O, supplies the oxygen. At 30°C, pH 8, NADPH activity is approximately 1 U/mg, NADH approximately 0.05 U/mg; apparent Km values are 23±3 µM NADPH, 6±1 µM phenylacetyl-CoA and 3±1 µM O2 (the oxygen measurement is coupled). PaaG/PaaZ increase substrate consumption approximately 1.5-fold. These kinetics do not establish cellular flux. The epoxide stereo unspecified issuer identity is retained. The 2010 apparent inactivation is qualified by the 2012 competing deoxygenation cycle.',
 'supported',['epoxide','abceprep'],M+'CPLX-8168',abcequal,
 [hypothesis('Bulk composition supports a di-iron PaaA and FAD/[2Fe-2S] PaaE model. Specific iron redox intermediates in Nature 2012 Fig. 3 are proposed by analogy, not directly observed states. No invented chemical-state node or exact FAD microstate is asserted. PaaD-mediated maturation remains proposed.','assembly')])
upper=mechanism('primary-paag-upper',M+'RXN0-6510','Epoxide-to-oxepin net conversion',
 'His-tagged Y2 PaaG supports reversible epoxide-to-final-oxepin conversion. This is a net observation, not proof that every ring expansion/tautomerization elementary event is catalyzed. The source native/PubChem oxepin has E geometry, whereas the interpreted primary 2010 drawing and ChEBI:63252 specify Z. The local detail explicitly proposes that revision without declaring the two issued structures equivalent. A separately drawn spontaneous tautomer remains a bounded primary-main access gap.',
 'inferred',['upperg'],M+'MONOMER-15951',qualifier('Pseudomonas sp. Y2 recombinant His-tagged PaaG in the 2010 sequential assay. Exact full tag body is not established. The Thermus thermophilus JL-18 2019 structures and E. coli 2012 assembly are separate ortholog/construct contexts.','upperg'),
 [hypothesis('The 2010 Fig. 3A proton-relay/enolate mechanism is proposed. An unobserved unconjugated oxepin tautomer and its spontaneous conversion are not asserted as isolated molecules or separately observed steps.','gproposal')])
hydro=mechanism('primary-paaz-hydrolysis',M+'RXNMETA-12671','PaaZ hydrolytic ring opening',
 'E. coli K-12 MBP-PaaZ supports hydrolytic oxepin ring opening coupled to aldehyde oxidation. The open-chain semialdehyde is inferred, not isolated in the 2011 experiments: ALDH impairment (E256Q or absent oxidized cofactor) yields the cyclic derivative characterized by NMR/MS. The Z oxepin interpretation is an explicit alternative to the native E structure; native 5Z semialdehyde remains a source-resolved identity rather than generic Rhea stereo equivalence.',
 'inferred',['z','aldehyde'],M+'G6708-MONOMER',qualifier('E. coli K-12 recombinant MBP-PaaZ in 2010/2011; the E256Q ALDH mutant is a distinct preparation used to separate domain functions. No complete MBP fusion body is established.','zprep'),
 [hypothesis('The 2010/2011 drawings propose an oxonium/enolate-assisted water attack, hydrated cyclic state, cleavage, and ring-opened enol-to-aldehyde tautomerization. These transient states have no independently established exact issuer IDs here and remain a hypothesis attached to this step.','zproposal')])
for mech,side in [(upper,'outputs'),(hydro,'inputs')]:
    mech['relation_to_source']='alternative_interpretation'
    mech['source_conflicts']=[{'source_participant_id':M+'CPD0-2363','interpreted_participant_id':zox,
       'side':side,'coefficient':1,'kind':'stereo','status':'proposed_revision',
       'rationale':'The exact native/PubChem E oxepin and ChEBI Z oxepin are distinct stereoisomers. The primary 2010 drawing supports the Z interpretation, but the product experiment does not independently establish every geometric descriptor. CCD LHQ additionally differs in constitution and is not an equivalence bridge.',
       'evidence':E('upperg')+[structured(zox,'Issuer structure encodes the Z oxepin anion, charge −4.','ChEBI exact entry 63252 / structure and charge')]}]
    for e in mech['edges']:
        for field in ['subject','object']:
            if e[field]==n(M+'CPD0-2363'): e[field]=n(zox)

mechanism('primary-paaz-aldehyde-oxidation',M+'RXNMETA-12672','PaaZ aldehyde oxidation',
 'The N-terminal ALDH domain oxidizes the inferred ring-opened semialdehyde to the NMR/MS-characterized C8 acid using NADP+. Nature 2012 corrects the 2011 NAD+ activity estimate: NAD+ gives less than 5% of NADP+ activity; apparent NADP+ Km is 17±3 µM with excess PaaY and absorbance controls, superseding 56±4 µM and approximately 50% NAD+ activity. This is specific to the E. coli PaaZ preparation; the distinct A. aromaticum PacL preference is not a cofactor substitution. Native NADP+/NADPH, water and two protons follow the exact source microstates.',
 'inferred',['z'],M+'G6708-MONOMER',qualifier('E. coli K-12 MBP-PaaZ; corrected 2012 apparent NADP+ kinetics use excess PaaY to prevent derivative-related inhibition. This differs from the His-tagged 2019 cryoEM construct.','zprep'))
j=mechanism('primary-c8-thiolysis-isomerization',M+'RXN0-6512','C8 thiolysis and C6 isomerization',
 'Native RXN0-6512 is a coupled net, retained in its source orientation and inverted for pathway flux. The 2010 assay already contained PaaG when PaaJ was added and therefore did not isolate PaaJ-only chemistry. A mechanistically inferred cis-3,4-dehydroadipyl-CoA intermediate separates thiolysis from isomerization to the source E-2,3 product. Current exact isolated PaaJ reaction authority remains CHEM02 open; local step keys are curatorial coordinates, not biological CURIEs. Ten planning steps across nine source members are not an exhaustive elementary count.',
 'inferred',['jnet','jcis','glower'])
j['steps']=[{'key':'thiolysis','label':'PaaJ C8 thiolysis','description':'Inferred cleavage of 5Z C8 β-ketoacyl-CoA with CoA to acetyl-CoA and cis-3,4-dehydroadipyl-CoA. The 2010 coupled assay measures the downstream 2,3 product, not isolated cis product.','assertion_status':'inferred','evidence':E('jnet','jcis')},
 {'key':'isomerization','label':'PaaG C6 double-bond isomerization','description':'Inferred Y2 PaaG assignment of cis-3,4 to E-2,3 isomerization; the 2010 discussion also considered intrinsic thiolase isomerization. Later E. coli PaaFG and Thermus PaaG evidence is ortholog/construct specific and is not a Y2 isolated kinetic measurement.','assertion_status':'inferred','evidence':E('glower'),
 'hypotheses':[hypothesis('The original 2010 authors also allowed PaaJ-intrinsic isomerization. The primary 2010 drawn cis-2,3 configuration was explicitly hypothetical; the retained source product is E-2,3.','glower')]}]
j['edges']=[]
def detail_edge(mech,key,sub,pred,obj,status,evkeys,coefficient=None,description=None,quals=None):
    e={'key':key,'subject':sub,'predicate':pred,'object':obj,'assertion_status':status,'evidence':E(*evkeys)}
    if coefficient is not None:e['coefficient']=coefficient
    if description:e['description']=description
    if quals:e['endpoint_qualifiers']=quals
    mech['edges'].append(e)
for key,sub,pred,obj in [
 ('j-c8',n(M+'CPD0-2364'),'consumes',s('thiolysis')),('j-coa',n(M+'CO-A'),'consumes',s('thiolysis')),
 ('j-cis',s('thiolysis'),'produces',n(cis)),('j-acetyl',s('thiolysis'),'produces',n(M+'ACETYL-COA')),
 ('g-cis',n(cis),'consumes',s('isomerization')),('g-e23',s('isomerization'),'produces',n(M+'TRANS-23-DEHYDROADIPYL-COA'))]:
    detail_edge(j,key,sub,pred,obj,'inferred',['jcis','glower'],1)
detail_edge(j,'j-catalyst',n(M+'MONOMER-15952'),'catalyzes',s('thiolysis'),'inferred',['jnet','jcis'],description='Purified recombinant Y2 PaaJ was added to an assay already containing PaaG; the isolated step is inferred. No exact full fusion sequence is asserted.')
detail_edge(j,'g-catalyst',n(M+'MONOMER-15951'),'catalyzes',s('isomerization'),'inferred',['glower'],description='Y2 PaaG assignment remains inferred in the 2010 mixed assay.',quals=qualifier('Pseudomonas sp. Y2 His-tagged PaaG already present in the 2010 coupled assay; separate E. coli and Thermus studies are not the identical preparation.','upperg'))
detail_edge(j,'sequence',s('thiolysis'),'provides_input_for',s('isomerization'),'inferred',['jcis','glower'])
mechanism('primary-paaf-hydration',M+'RXN-2425','PaaF C6 enoyl-CoA hydration',
 'Purified Y2 PaaF reversibly hydrates enzymatically generated 2,3-dehydroadipyl-CoA. The source equation is dehydration and is inverted explicitly for route flux. The exact source E substrate and S-3-hydroxy product are retained, while the 2010 study called the S specificity probable and its drawn cis-2,3 substrate hypothetical. The isolated 2010 assay therefore supports conversion more strongly than these exact stereochemical assignments.',
 'inferred',['f'],M+'MONOMER-15953')
mechanism('primary-paah-oxidation',M+'RXN0-2044','PaaH hydroxyacyl-CoA oxidation',
 'E. coli K-12 MBP-PaaH in the sequential mixed-organism assay supports NAD+-dependent conversion of hydroxyadipyl-CoA with NADH and terminal succinyl-CoA/acetyl-CoA formation. PaaJ was already present, so the C6 keto intermediate was inferred rather than isolated. Source S-3-hydroxy identity is retained with the 2010 probable stereochemical assignment.',
 'inferred',['h'],M+'G6716-MONOMER',qualifier('E. coli K-12 recombinant MBP-PaaH added to enzymatically generated hydroxyadipyl-CoA in a coupled assay containing Y2 PaaJ. No complete fusion sequence is established.','hprep'))
mechanism('primary-paaj-terminal',M+'RXN-3641','Terminal PaaJ C6 thiolysis',
 'Y2 PaaJ cleaves 3-oxoadipyl-CoA with CoA to succinyl-CoA and acetyl-CoA in the reported terminal pathway assignment. The 2010 reconstruction detects terminal products after PaaH addition with PaaJ already present; it does not independently isolate the keto intermediate. Source right-to-left layout is explicitly selected. This reaction is distinct from the unresolved isolated C8 PaaJ reaction.',
 'inferred',['jterminal','h'],M+'MONOMER-15952')

# Contextual side reactions are not added to the nine native pathway-member edges.
for rid,left,right in [(M+'RXN-17752',[(M+'CPDMETA-13650',1)],[(M+'CPD0-2558',1),(M+'WATER',1)]),
 (M+'RXN0-7103',[(M+'CPD0-2558',1),(M+'WATER',1)],[(M+'CPD0-2559',1),(M+'CO-A',1),(M+'PROTON',1)])]:
    for side,pred,items in [('left','consumes',left),('right','produces',right)]:
        for index,(pid,count) in enumerate(items,1):
            edge(f'primary-context-{rid.split(":")[1].lower()}-{pred}-{index}',pid if pred=='consumes' else rid,pred,rid if pred=='consumes' else pid,
                 [structured(rid,f'Issuing Reaction {side} participant {pid.split(":",1)[1]}, coefficient {count}.',f'Reaction {rid.split(":",1)[1]} / {side}')],
                 'Contextual side-reaction source representation; not a native PWY0-321 member. '+('The source labels this spontaneous and YES-PUTATIVE; this edge does not prove an isolated semialdehyde observation.' if rid.endswith('17752') else 'Exact source microstates and reaction sides; measured tagged PaaY activity is scoped separately.'))
    rxns[rid]={'pathway_flux_direction':'L2R','source_sides':{'left':left,'right':right},'physiological_substrates':left,'physiological_products':right}
mechanism('primary-cyclic-deadend',M+'RXN-17752','Putative cyclic dead-end formation',
 'When the ALDH domain is impaired, the 2011 experiments identify a cyclic derivative by NMR/MS. Its formation by spontaneous Knoevenagel-type condensation of the unisolated semialdehyde, followed by keto-enol rearrangement, is proposed. The source independently labels RXN-17752 spontaneous and YES-PUTATIVE. Rate slowing with product accumulation supports an inhibition inference, not a measured binding constant or a direct molecular inhibition edge.',
 'proposed',['aldehyde'],hypotheses=[hypothesis('C2 deprotonation, intramolecular attack at the C8 aldehyde, water elimination and enol stabilization constitute the proposed condensation mechanism; none is asserted as an isolated chemical state.','aldehyde')])
mechanism('primary-paay-salvage',M+'RXN0-7103','PaaY cyclic derivative hydrolysis',
 'N-terminal MBP-PaaY from E. coli K-12 hydrolyzes the cyclic CoA derivative and releases CoA. At 22°C, pH 8, activity is 7.6±0.6 U/mg and apparent Km is 35±15 µM. PaaY at 44 µg/ml supports continued ring cleavage with 4.1 µg/ml PaaZ and 0.5 mM oxepin in the 2012 experiment. Main Methods says absent NADPH for one condition whereas SI Fig. 11 says absent NADP+; the SI is the condition-specific source. Intracellular rescue and epoxide control are physiological proposals, not directly measured cellular flux.',
 'supported',['y','tag'],Y,tagY)

description = '''Aerobic phenylacetate degradation retains all nine native MetaCyc members and the full CoA-linked route to two acetyl-CoA and one succinyl-CoA. The sequential biochemical reconstruction used Pseudomonas sp. Y2 PaaABCE/PaaG/PaaJ/PaaF and E. coli K-12 PaaZ/PaaH; native Azoarcus evansii KB740 PaaK was a separate preparation. A list of source taxa does not establish the entire route in every listed organism. The nested details split the native C8 thiolysis/isomerization net into local claims with an inferred cis-3,4 intermediate; these coordinates are not new reaction identifiers, and ten planning steps are not an exhaustive elementary count. Native source structures and directions remain visible. In the upper route, native/PubChem E oxepin conflicts with the Z interpretation of the primary drawing and ChEBI entry; explicit alternative detail preserves that unresolved stereochemical distinction. CCD LHQ also differs in constitution and is not used to join these structures.

Y2 PaaABCE uses an MBP-PaaA-containing recombinant preparation; PaaD does not copurify. Nature 2012 reports approximately A2B3–4C2E1, while its SI Table 1 gives A2B2–3C2E1. Neither is imposed as universal integer stoichiometry. Bulk iron (6.3±0.1 per A2E1), acid-labile sulfur (1.9±0.2 per E), FAD (0.73 per E), spectroscopy and analogy support a di-iron/PaaA and FAD/[2Fe-2S]/PaaE model. They do not establish each catalytic oxidation state or a physiological FAD microstate. The 2011 E. coli structural preparations and artificial cytochrome-c reduction assay are distinct. Lack of deposited Fe/Zn/Mg/Mn in the reviewed structures is not absence of functional metal; the 5.8 Å Fe-soaked data are not a refined di-iron atomic structure. PaaD maturation is proposed; its 2006 W14 deletion/rescue readout was extracellular 2-hydroxyphenylacetate (700 to less than 1, rescued to 210 µM) after 24 h at 37°C in M63/glycerol plus 1 mM phenylacetate, not direct hydroxylation or pathway flux.

The same Y2 oxygenase can consume NADPH to deoxygenate the epoxide. Oxygen readdition restarts epoxidation; this is not the simple reverse of the oxygenation equation. Nature 2012 Fig. 2 used 0.25 mg/ml enzyme, 0.1 mM phenylacetyl-CoA and 1 mM NADPH at 30°C with shaking. Approximately 0.4 U/mg deoxygenation and 17±2 µM epoxide Km are indirect estimates; approximately 1.8 NADPH per O2 is compatible with the two-reductant cycling model plus decay. The cellular detoxification role is proposed. Benzoyl-CoA instead causes transient NADPH oxidation and inhibition without a detected HPLC product at 0.05–0.3 mM; this does not establish another catalytic pathway input.

The lower Y2 PaaG assignment is inferred from the 2010 coupled assay, while later E. coli PaaFG and Thermus thermophilus JL-18 PaaG studies have distinct sequence/construct scopes. E. coli PaaFG forms an assembly of six PaaF and six PaaG chains (4FZW; distinct 258/274-aa constructs), with no demonstrated connecting tunnel; improved intermediate transfer is a proposal. The related 4II4 E49Q/K68Q construct is not wild type. The available 2019 Thermus SI uses trans-3,4 substrate as a surrogate and has construct/caption distinctions; it does not establish the natural cis substrate or close the unavailable primary-main claim about a spontaneous upper-route tautomer.

PaaZ domain separation supports hydrolysis and NADP+-dependent aldehyde oxidation, with an inferred unstable semialdehyde. The 2011 E256Q construct and the 2012 SI E56Q text are a source discrepancy, not two established mutants. Nature 2012 corrects the earlier NAD+ activity and NADP+ Km as described in the local detail. The 2019 six-subunit cryoEM architecture is three domain-swapped dimers; apo, NADPH, and NADP+ plus octanoyl/crotonyl surrogate structures have distinct ligand states and sometimes partial density. Proposed electrostatic substrate pivoting is not direct visualization of natural intermediate transfer. Growth mutants K69A, R613A, K636A and C295A use a separate ASKA context; Methods K631A conflicts with the R613A account. SEC comparison concerns wild type and K69A, not every mutant.

The cyclic side product and PaaY hydrolysis are contextual salvage, not additional native route members. PaaI and PaaY in Nature 2012 are N-terminal MBP fusions; native-mass activity correction does not demonstrate tag removal. Assays use pH 8, 22°C for these thioesterases and 30°C for PaaABCE/PaaZ, at least two independent measurements, and 1% formic-acid stop to pH 4.5–5. The PaaI/PaaY tested relative activities (I/Y) were phenylacetyl-CoA 100/19, epoxide 10/30, oxepin less than 1/3, cyclic derivative 9/100, C8 acid less than 1/3, 3,4-dehydroadipyl-CoA 18/less than 1, and acetyl-/succinyl-CoA less than 1. This finite panel is not universal substrate exclusion. Phenylacetate/glucose-grown extracts had PaaI 100/60 and PaaY 13/1.5 mU/mg at 30°C, compatible with induction but not transcript or flux measurements. In 2006, E. coli ATCC 11105/W PaaI kinetics and A. evansii DSM 6898 kinetics differed: phenylacetyl-CoA kcat/Km were 0.41 s−1/9.6±0.9 µM and 3.7 s−1/390 µM, respectively; the E. coli 3,4-dihydroxy substrate gave 100 s−1/16 µM. These pET23b/BL21 kinetic preparations are separate from the C-terminally tagged crystallographic proteins. Residual E. coli D61A activity was suspected host contamination; A. evansii D75A was undetectable, and the A. evansii mutant activities did not change after gel filtration. A general-base versus covalent mechanism remains unresolved; the 2FS2/1PSU discrepancy remains source-specific.

Regulation is retained as qualified evidence and pending endpoint-specific edges. PaaX repression of Pa/Pz and phenylacetyl-CoA relief were measured using E. coli W-derived crude preparations and distinct reporters. Table II of the 2000 paper uses AF15PZ chromosomal Pz-lacZ, pAFX2 and optional pAFK5 with 0/1 mM phenylacetate at 30°C in M63/glycerol; Table III uses Pa-lacZ plasmids in AF15 with optional pAFX2 and does not state phenylacetate supplementation. The wild-type Pa repression ratio was 30.4, versus 1.1/4.3/1.8/4.7 for mutants. ORA and ORZ footprints span −1:+51 and −30:+17, with a bounded 15-base motif. Approximate 7/150 µg total protein/ml apparent DNA-binding quantities are not molar PaaX affinities; approximately 30 µM phenylacetyl-CoA half-release is not ligand Kd. Phenylacetate/benzoyl-CoA at 2.5 mM were negative. CRP (250 nM, 200 µM cAMP) bound Pa/full Pz-Pa, not isolated Pz, while IHF (250 nM) bound the full spacer, not Pa; a bridging model remains proposed. The peripheral E. coli W Ppac and Pseudomonas Y2 styA claims are distinct from core Pa/Pz: Ppac assays used crude PaaX and 125 µM phenylacetyl-CoA relief; CRP bound directly, whereas IHF did not shift PPAC despite a positive control. The 2006 Y2 MBP-PaaX1 styA result does not establish purified PaaX2 function or exact open-complex blocking.

SlyA 2017 provides direct binding of tagged SlyA to the 257-bp paaA/paaZ region and increased paaA–K expression (2.8-fold) in MG1655 with multicopy slyA under aerobic glucose-limited chemostat conditions (37°C, pH 6.9, dilution 0.2 h−1; two biological and two technical replicates). Binding used 1 nM DNA and 0–500 nM His6-SlyA at 25°C for 30 min; the roughly 50–100 nM affinity estimate spans several fragments. The three sequence motifs at −239/−136/−81 are candidates, not independently footprinted or mutated sites. No significant deletion effect at tested dilution rates is bounded by the twofold/P≤0.05 threshold; H-NS antagonism was not established at paa. SlyA 2020 reporter activation used MG1655 derivatives, plasmid overexpression and 16 h at 30°C in LB/0.05% arabinose; ppGpp was dispensable in that reporter condition, with no PpaaA EMSA in that paper. SrsR 2022 used W3110 type-A gSELEX/C-terminally His-tagged protein and separate BW25113/JW5476/ASKA expression experiments. The paa spacer peak was 170 against threshold 150; EMSA used 0.1 pmol DNA/0–2 pmol SrsR. RT-qPCR at 24 h, 37°C, LB/0.5 mM IPTG and 16S normalization gave signed deletion/overexpression changes paaZ −69.9/+31, paaA −28.4/+5.7 and paaK −10.1/+10.5. These are transcript measurements, not RNA-seq or metabolic flux; footprinting was at yfdP/yfdO, not paa.

Alternative ring-opening systems remain distinct context: A. aromaticum ECH-Aa and PacL have independently bound insert sequences but incomplete full MBP fusion bodies. ECH-Aa oxepin activity was 1.2±0.1 U/mg versus crotonyl-CoA 2300±340 U/mg; PacL gave 5.8±0.1 U/mg and preferred NAD+ with NADP+ at 60%, without a reported Km. A. evansii assayed BoxD is not identical to the A. aromaticum comparison sequence. CAI09349.1 negative activity is not a positive hydratase edge. The Price P. bryophila strain attribution and OAS925 sequence gap prevent transferring its fitness evidence onto the native P. caledonica reference; fitness is not direct catalysis. T. fusca and C. necator alternatives are retained in the source coverage ledger as adipate contexts, not silent replacements for the native aerobic route. Complete tag sequences and unissued isolated chemistry remain explicit gaps rather than fabricated identifiers.'''
ydump('fragments/description.yaml',{'description':description})
ydump('fragments/primary-additions.yaml',add)
dump('quote-proof.json',quotes)

# Draft regulator endpoints are explicitly not merged into primary-additions.yaml.
pending=[]
for key,reg,target,pred,ev,reason in [
 ('primary-paax-pa','EcoCyc:G6720-MONOMER','EcoCyc:PM5','inhibits',E('x'),'Full reference objects exist, but the primary W crude preparation and K-12 catalog protein are not an exact assay-sequence match; native regulatory complex is a separate endpoint. Resolve representation scope before asserting the primary edge.'),
 ('primary-paax-pz','EcoCyc:G6720-MONOMER','EcoCyc:PM4','inhibits',E('x'),'Same W/K-12 and crude-preparation boundary; keep Table II Pz and Table III Pa distinct.'),
 ('primary-slya-pa','EcoCyc:CPLX0-8563','EcoCyc:PM5','activates',[], 'Full SlyA complex authority original not independently closed; candidate reference occurs in source regulation, not a full verified endpoint.'),
 ('primary-srsr-paa','EcoCyc:G7518-MONOMER','EcoCyc:TU5','activates',[], 'Full SrsR authority original not independently closed; W3110 tagged in-vitro and BW25113 in-vivo contexts must stay separate.'),
 ('primary-crp-pa','EcoCyc:CPLX0-226','EcoCyc:PM5','activates',[], 'Full CRP complex authority original not independently closed; cAMP and exact promoter fragment context required.'),
 ('primary-ihf-pa','EcoCyc:PC00027','EcoCyc:PM5','activates',[], 'Full IHF complex authority original not independently closed; full spacer binding does not establish binding to isolated Pa.')]:
    pending.append({'key':key,'status':'withheld_from_merge_ready_fragment','candidate_edge':{'subject':reg,'predicate':pred,'object':target,'evidence':ev},'unclosed_requirement':reason})
ydump('fragments/pending-regulatory-proposals.yaml',{'not_a_PathwayRecord_patch':True,'pending_proposals':pending,
 'negative_claims_not_edges':['IHF direct Ppac binding was negative despite positive PR-PG control.','No established paa-specific H-NS antagonism.','No purified Y2 PaaX2 result.','No equivalence between PaaX ligand response in crude extract and a measured isolated ligand-binding constant.']})

# Every accepted input claim has explicit output coordinates and scope corrections.
mapping={
 'N268-P01':['primary-c8-thiolysis-isomerization'], 'N268-P02':['primary-paak-activation','primary-paak-magnesium'],
 'N268-P03':['primary-abce-epoxidation'],'N268-P04':['description paragraph 3'], 'N268-P05':['primary-paag-upper','primary-c8-thiolysis-isomerization'],
 'N268-P06':['primary-paaz-hydrolysis','primary-paaz-aldehyde-oxidation'], 'N268-P07':['primary-paaz-aldehyde-oxidation'],
 'N268-P08':['primary-c8-thiolysis-isomerization'],'N268-P09':['primary-paaf-hydration','primary-paah-oxidation','primary-paaj-terminal'],
 'N268-P10':['description paragraph 4'], 'N268-P11':['primary-paaz-assembly','description paragraph 5'],
 'N268-P12':['description paragraph 9'], 'N268-P13':['description paragraph 9'], 'N268-P14':['description paragraph 2'],
 'N268-P15':['description paragraph 6'], 'N268-P16':['description paragraph 6'], 'N268-P17':['primary-paay-salvage'],
 'N268-P18':['description paragraph 6'], 'N268-P19':['pending:primary-paax-pa','pending:primary-paax-pz','description paragraph 7'],
 'N268-P20':['description paragraph 7'], 'N268-P21':['pending:primary-crp-pa','pending:primary-ihf-pa','description paragraph 7'],
 'N268-P22':['description paragraph 7'],'N268-P23':['description paragraph 7'], 'N268-P24':['description paragraph 7'],
 'N268-P25':['pending:primary-slya-pa','description paragraph 8'], 'N268-P26':['pending:primary-srsr-paa','description paragraph 8'],
 'N268-P27':['description paragraph 8'], 'N268-P28':['primary-paay-cyclic-hydrolysis','pending:primary-paax-pa'],
 'N268-P29':['primary-cyclic-deadend'], 'N268-P30':['description paragraph 3'], 'N268-P31':['primary-abce-epoxidation','description paragraph 2'],
 'N268-B01':['primary-c8-thiolysis-isomerization'], 'N268-B02':['description paragraph 1'], 'N268-B03':['primary-paak-activation'],
 'N268-B04':['native frozen identity crosswalk'],'N268-B05':['native frozen identity crosswalk'],
 'N268-B06':['primary-abce-epoxidation','description paragraph 2'], 'N268-B07':['description paragraph 2'],
 'N268-B08':['description paragraph 2'],'N268-B09':['primary-paaz-hydrolysis'], 'N268-B10':['primary-paaz-assembly','description paragraph 5'],
 'N268-B11':['description paragraph 5'], 'N268-B12':['description paragraph 4'], 'N268-B13':['primary-c8-thiolysis-isomerization'],
 'N268-B14':['description paragraph 9'],'N268-B15':['description paragraph 9'],'N268-B16':['description paragraph 9'],
 'N268-B17':['description paragraph 9'],'N268-B18':['description paragraphs 6–8'],'N268-B19':['description paragraph 4']}
for k in range(1,13):
    mapping[f'N2012-{k:02}']=[{1:'primary-paai-thioesterase',2:'description paragraph 6',3:'description paragraph 2',4:'primary-abce-epoxidation',5:'description paragraph 3',6:'primary-abce-epoxidation',7:'primary-paai-thioesterase',8:'primary-paay-salvage',9:'primary-paay-salvage',10:'primary-paaz-aldehyde-oxidation',11:'description paragraph 6',12:'description paragraph 5'}[k]]
dispositions=[]
for group,items in claims.items():
    for c in items:
        cid=c.get('id') or c.get('claim_id')
        if group=='slya':mapping[cid]=['description paragraph 8','pending:primary-slya-pa']
        assert cid in mapping,cid
        changes=[]
        if cid in ['N268-B01','N268-P01']:changes.append('Ten is a planning decomposition, not a proven exhaustive elementary count.')
        if cid in ['N268-P04','N268-B18','N268-P27','N268-B19']:changes.append('Earlier partial-access caveat is superseded only for accepted Nature 2012 main, SlyA 2017 complete materials, or PaaFG 2012 main. Missing PaaG 2019 main/PaaFG SI/full fusion sequences stay open.')
        if cid in ['N268-P16','N268-P20','N268-P23']:changes.append('Uses accepted correction; do not resurrect the pre-correction claim.')
        if cid in ['N268-P05','N268-P08','N268-B12','N268-B13']:changes.append('No exact isolated reaction identifier, automatic ortholog transfer or surrogate-to-natural-substrate equivalence.')
        dispositions.append({'claim_id':cid,'accepted_input_group':group,'accepted_claim':c,
          'outputs':mapping[cid],'disposition':'qualified narrative and pending endpoint closure' if any(x.startswith('pending:') for x in mapping[cid]) else 'qualified representation or explicit exclusion',
          'successor_scope_notes':changes,
          'positive_edge_guard':'Negative assays, comparisons, incomplete mappings and proposed physiology are not converted to unconditional positive edges.'})
dump('claim-to-output-dispositions.json',dispositions)
assert len(dispositions)==68

gaps=[
 {'id':'CHEM02','requirement':'Exact issued isolated PaaJ C8-to-cis3,4 reaction remains unclosed after the bounded accepted authority search.','effect':'Local inferred steps represent the mechanism without fabricating a reaction ID; do not mark CHEM02 solved.'},
 {'id':'OXEPIN-STEREO','requirement':'Native E vs primary drawing/ChEBI Z conflict, and CCD LHQ constitution conflict.','effect':'Alternative interpretation and explicit source conflict; no equivalence or source replacement.'},
 {'id':'PRIMARY-UPPER-TAUTOMER','requirement':'Accepted 2019 PaaG SI is not the unavailable primary main for the additional spontaneous tautomer claim.','effect':'Bounded proposed hypothesis only; no new species node or full-main reading assertion.'},
 {'id':'CONSTRUCT-BODIES','requirement':'Complete MBP/His linker/fusion bodies absent for specified preparations.','effect':'Reference sequences and constructs are qualified, not declared identical full experimental proteins.'},
 {'id':'REGULATORY-AUTHORITY','requirement':'SlyA/SrsR/CRP/IHF full endpoint authority originals and exact assay scope are not closed.','effect':'Concrete pending proposals plus evidence narrative; no positive merge-ready edge for these endpoints.'},
 {'id':'PAAX-SCOPE','requirement':'E. coli W crude primary assays vs K-12 catalog endpoint and source regulatory complex need explicit representation decision.','effect':'PaaX evidence retained; candidate edges pending instead of silent assay-sequence transfer.'},
 {'id':'FINAL-INTEGRATION','requirement':'Independent scientific review, evolving schema/authority integration, whole-record validation and generated artifact review belong to root.','effect':'This frozen packet is curation fragments, not acceptance of a final maintained record.'}]
dump('unclosed-requirements.json',gaps)
print(json.dumps({'mechanisms':len(add['reaction_mechanisms']),'native_members':9,'local_steps':sum(len(x['steps']) for x in add['reaction_mechanisms']),
 'primary_top_edges':len(add['mechanistic_edges']),'additional_participants':len(add['participants']),'claims':len(dispositions),'quotes':len(quotes)}))
