# Primary curation fragments for MetaCyc:PWY0-321

Status: frozen author packet, ready for independent scientific review. This is not a final accepted record, an issue-closure receipt, or permission to bypass final record/graph/export gates. No maintained input, Git/GitHub object, installed runtime, author evidence packet, or prior review packet was modified. All work used the existing verified Python with bytecode disabled; all local jobs returned terminal results.

## Concrete outputs

- `fragments/primary-additions.yaml`: eight new participants, two contextual reactions, 27 reference declarations, 12 top-level edges, 11 mechanism objects and 12 local steps. Nine mechanisms attach to the complete native nine-member route. The other two attach to contextual cyclic side-product formation and PaaY hydrolysis. The latter are **not added as native pathway members**.
- `fragments/description.yaml`: nine evidence-qualified paragraphs for the final record description, including source/construct differences, corrected scientific claims, regulation, salvage, and excluded transfers.
- `review-merged-record.yaml`: reproducible review draft made by `merge_fragments.py` from the immutable native draft plus these fragments. It contains 48 participants, 11 reactions including the two contextual reactions, 80 top-level edges and 11 nested mechanisms. All 68 native edges and nine native membership assertions remain unchanged. The script explicitly adds `category: molecular_activity` to nine native reaction declarations; source labels, directions and every preexisting value remain unchanged.
- `fragments/pending-regulatory-proposals.yaml`: six concrete candidate edge payloads, explicitly excluded from the merge-ready fragment. SlyA/SrsR/CRP/IHF complete endpoint authority originals are unclosed. The PaaX W/crude-assay versus K-12 catalog/complex scope requires an explicit representation decision. This file is not a `PathwayRecord` patch and must not be appended automatically.
- `claim-to-output-dispositions.json`: all 68 accepted input claims (31 corrected primary, 19 native biology, six SlyA 2017, 12 Nature 2012 main), their full input statements/scopes, output coordinates, exclusions and successor scope corrections.
- `quote-proof.json`: 33 short literal primary quotes, exact original/projection SHA bindings and precise locators. Whitespace is normalized solely to compare PDF/HTML text extraction; no numeric OCR substitution was used to invent quotations.
- `all11-detail-net-replay.json`: source equation, orientation, explicit substitutions and independently counted detail net for every mechanism.
- `additional-public-id-proof-ledger.json`, `new-declaration-authority-label-check.json`: exact issuing objects and canonical snapshot label checks for the added biological/material identifiers.
- `paaz-construct-direct-replay.json`: fresh targeted PDB 6JQL polymer/alignment replay against the authentic P77455 issuer sequence. The 688-residue construct exactly equals MGHHHHHH plus reference residues 2–681. The qualifier now cites the actual issuing mmCIF under its issuer-declared DOI, `DOI:10.2210/pdb6jql/pdb`, with structured sequence/alignment evidence, in addition to the primary architecture quote. This is not a claim of a new full reading or replay of all four PaaZ structures.

## Reproducible merge

Run the following with the established runtime, writing to an owned output first:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B /private/tmp/pathwaymech-next-268-primary-curation-fragments/merge_fragments.py --output /private/tmp/pathwaymech-next-268-primary-curation-fragments/review-merged-record.yaml
```

The default input is the copied frozen native draft. Its authoritative owner is `/private/tmp/pathwaymech-next-268-native-record-draft`, manifest SHA `84d98faed9b186baae1ada62406526202f036cdccdd2970f4741eb1da309b854`; native YAML SHA `f0830b3ec026215f92d581c05519f52e36d83ffec0cdfe87b04577809d1cdffb`. The merge rejects duplicate identifiers, never writes its input, appends only the specified schema arrays, replaces only the provisional description, and explicitly enriches the native reaction category. Root may supply a copied native source with `--native`; it must still have exactly nine native reactions and the same source material before integration adjustments.

After acceptance, root owns final integration, curation history, scientific review persistence, final authority/closed-schema checks, generated graphs/pages/KGX and repository workflow. Do not rerun author scripts inside this frozen directory; reproduce in a successor copy if needed.

## Chemistry and assertion boundaries

RXN0-6512 and RXN-3641 use `orientation: reversed` because their stored left/right equations are opposite route flux. RXN-2425 also uses `reversed` for hydration. All other native equations use `as_reported`. Original equation inputs and outputs remain literal source sides, not already inverted sides. `all11-detail-net-replay.json` exposes each choice.

The C8 mechanism separates an **inferred** PaaJ cis-3,4 intermediate and an **inferred** Y2 PaaG lower isomerization. The 2010 coupled assay had PaaG present before PaaJ addition, and the original authors allowed an alternative intrinsic thiolase isomerization. Local keys are navigation coordinates, not new biological identifiers. CHEM02 remains open under the finite accepted search boundary. No unsupported isolated reaction ID is manufactured, and the native net is never relabeled as PaaJ-only chemistry.

The upper PaaG and PaaZ-hydrolysis details are alternative interpretations: the selected Z ChEBI:63252 replaces native E MetaCyc:CPD0-2363 only through explicit equal-quantity `source_conflicts`. Material-edge descriptions identify the interpretation and retain source-reported E. No equivalence is claimed; CCD LHQ's constitution conflict is not used as a bridge. Proposed unobserved transient states remain hypotheses rather than invented chemical nodes. Exact net agreement is not a new formula-balance or chemical-identity proof.

The unstable semialdehyde and coupled terminal keto intermediate remain inferred, not isolated observations. Physiological detoxification, iron-cycle models, PaaD maturation, proposed channeling and negative assays are preserved as qualified narrative/hypotheses, not unconditional positive edges. In particular, IHF direct Ppac binding and paa-specific H-NS antagonism are not asserted.

## Reading and retained evidence

`retained-source-originals.json` inventories 18 exact originals copied into `source-originals/`: the 16 strongest authentic primary sources in `source-proof-bindings.json`, plus the two exact PaaZ construct/sequence issuing originals. The 16 primary readings reuse the accepted original and independent-review scopes; this authoring stage performed targeted quotation checks, not a fabricated repeated complete reading. The accepted Nature 2012 main review covers all seven pages, all figures and Methods; earlier SI coverage is reused at its stated scope. Prior partial-access statements are superseded only where the accepted later packets actually close them. PaaG 2019 main, PaaFG SI and specified full experimental fusion bodies are still bounded gaps.

`inputs/` retains accepted ledgers, acceptance handoffs/manifests and the frozen native draft/crosswalk. `input-bindings-before.json` and `input-bindings-after.json` show all 104 selected frozen inputs unchanged. This is a selected input audit including hidden/ignored paths where selected; it is not a fresh exhaustive inventory of every earlier raw-search archive. Additional chemical issuing originals are bound by path/SHA in the added-ID ledger and are already owned by the accepted chemistry/native authority retention workflow; they are not replaced by primary-paper prose.

The record description retains the corrections underlying issues 609–611: the PaaI mutant/gel-filtration finding, the distinct 2000 Table II Pz versus Table III Pa experiments, and the negative direct IHF–Ppac binding result. This packet does not close those issues; root must retain the accepted successors in the actual maintained work and complete its merge workflow.

## Verification and preserved attempts

`fragment-checks.json` records **1,041 passing checks, zero failed checks** for the final replay: exact source/quote bindings, full 68-claim coverage, declared endpoints/references, canonical new labels against the current reviewed snapshot, exact detail/source equation agreement, native preservation and current semantic API shape. The current semantic validator accepts the merged review draft. These checks are deliberately not a claim that final corpus/closed-schema, authority, rendered graph or KGX gates have been completed. The exact code/snapshot inputs were unchanged during the replay and are bound in `implementation-input-bindings.json`.

Preserved failures/corrections:

- Initial setup assumed a native-draft `freeze-proof.json`; the native owner actually freezes through its manifest. The original attempt and explanatory receipt remain.
- An exploratory record read asked for `name` instead of `label`; it failed without changing any file.
- The staging-only PaaZ2019 reference DOI was mistyped as `11931-3`. Direct publisher metadata established `11931-1`; both prior staging metadata and the correction record remain. No accepted input was changed.
- Checker attempt 1 expected a root list instead of the documented metadata object containing `files`. Its script, stderr and disposition remain; final attempt 2 replays all checks successfully. The failure is not counted as a pass.
- The environment emits the preexisting benign pyenv rehash warning; no runtime repair was attempted.

`unclosed-requirements.json` is the complete finite handoff for remaining representation/evidence/integration obligations. None calls for an unbounded new source hunt.
