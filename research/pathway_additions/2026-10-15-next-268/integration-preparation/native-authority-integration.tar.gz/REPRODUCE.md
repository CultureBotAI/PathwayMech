# Authority increment reproduction

Commands use the existing verified runtime; no install, runtime repair or network
is needed. Run from `/private/tmp/pathwaymech-next-268-20261015`.

## Rebuild the bounded new-source delta

```bash
PYTHONPATH=src:. /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/build_source_identifier_snapshot.py \
  --manifest /private/tmp/pathwaymech-next-268-native-authority-integration/new-source-manifest.json \
  --cache-dir /private/tmp/pathwaymech-next-268-native-authority-integration/source-cache \
  --records /private/tmp/pathwaymech-next-268-native-authority-integration/selection \
  --output /private/tmp/phenylacetate-authority-reproduced.json
```

The selection contains only source IDs, no labels or biological claims. The normal
builder derives all 65 labels/synonyms/types from the complete originals. Output
must equal packet `new-native-snapshot.json`; `reproduced-native-snapshot.json`
is the independently repeated CLI output and is byte-identical.

To stage this bounded build from maintained files alone, run the following in a
fresh scratch directory (replace only `cache` with that scratch path):

```python
from pathlib import Path
import hashlib, json, shutil
root = Path('/private/tmp/pathwaymech-next-268-20261015')
cache = Path('/private/tmp/phenylacetate-authority-clean-reproduction')
cache.mkdir(exist_ok=False)
owner = root / 'research/pathway_additions/2026-10-15-next-268/authority-source-originals'
rows = json.loads((owner / 'source-provenance.json').read_text())
entries = []
for row in rows:
    entry = row['manifest_entry']
    body = (root / row['maintained_original']).read_bytes()
    assert hashlib.sha256(body).hexdigest() == entry['sha256']
    target = cache / entry['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(body)
    entries.append(entry)
(cache / 'manifest.json').write_text(json.dumps(entries, indent=2) + '\n')
selection = cache / 'selection'
selection.mkdir()
(selection / 'all-source-identities.yaml').write_text(json.dumps({
    'id': rows[0]['id'], 'participants': [{'id': r['id']} for r in rows[1:]]
}, indent=2) + '\n')
```

Run the same builder with that staged manifest/cache/selection and a fresh output.
The original `conf/identifier_sources.json` is the full corpus manifest; a full
historical-source rebuild additionally needs every older manifest cache body.
Do not mistake this 65-source replay for a complete historic-source rebuild.

## Snapshot integration and preservation

Packet `integrate_snapshots.py` reads immutable `before/` baselines and the new
source delta, verifies no ID/source-key collision, adds terms with the existing
ordering preserved, replays the consumer, and writes `candidate-*.json` plus
`snapshot-preservation-proof.json`. Default mode writes only this packet's
candidate outputs; `--publish` was used by the author to write the 3 owned
maintained targets after an exact previous-byte check. Do not run it inside the
frozen packet: copy the packet into a new owned directory before reproduction.

The ontology additions use existing `extract_terms` against the read-only pinned
NCBI Taxonomy SQL cache; CHEBI:63252 is re-extracted from the read-only pinned ChEBI cache with the
same helper and compared with the earlier verified extraction. Cache proofs bind exact whole-file
hashes, sizes, release metadata, ontology URL/license and returned terms. To repeat
all ontology source verification, use the existing `read_source` and
`extract_terms` helpers in `scripts/build_ontology_identifier_snapshot.py`, with
`sqlite3.connect(resolved_path.as_uri() + '?mode=ro', uri=True)`. Hash the complete
SQL file and compare the proof before reusing it. No auto-download is appropriate.

NCBI Taxonomy cache: `/private/tmp/pathwaymech-curation-authorities/ncbitaxon.db`
(SHA-256 89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d,
14,115,225,600 bytes; pinned 2026-07-12).
ChEBI cache: `/private/tmp/pathwaymech-curation-authorities/chebi.db`
(SHA-256 26ad4890cdcf6ee357760d815dfee8f5ba81e0873e62cb379369b04205722b0f,
4,137,340,928 bytes; pinned 255).

## Relevant tests

```bash
PYTHONPATH=src:. /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m pytest -q -p no:cacheprovider \
  tests/test_p321_authority.py tests/test_typed_authority_consumer_integrity.py \
  tests/test_source_identifier_snapshot.py tests/test_identifiers.py \
  tests/test_phenylacetate_authority.py
```

Result: 836 passed in 40.49 s. The new targeted module alone: 186 passed in 5.71 s.
Ruff on the 4 changed/new code and test files passed. Owned tracked diff whitespace
check passed. Full existing 264-record identifier gate: 0 errors in 52.582 s. Complete
native draft copy (only adding required explicit category to 9 reaction nodes):
0 identifier errors in 7.365 s. No source record or final graph integration is claimed.
