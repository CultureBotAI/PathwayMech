"""Whole issuing originals and adversarial checks for bounded Paa identities."""
from __future__ import annotations

import base64
import copy
import gzip
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree as ET

import pytest
import yaml

from pathwaymech.biocyc_phenylacetate import (
    FIELD,
    META_KIND,
    NODE_ROLES,
    phenylacetate_metadata,
    phenylacetate_term,
    validate_phenylacetate_metadata,
)
from pathwaymech.identifiers import _load_authority, identifier_errors
from scripts.build_source_identifier_snapshot import build_snapshot

FIXTURES = Path(__file__).parent / "fixtures/phenylacetate_authority"
ENTRIES = json.loads((FIXTURES / "manifest.json").read_text())
STORAGE = json.loads((FIXTURES / "storage.json").read_text())
BY_FRAME = {e["url"].split(":")[-1]: e for e in ENTRIES}
REPRESENTATIVES = ["AMP", "G6716-MONOMER", "CPLX0-8538", "RXN0-6512",
                   "ENZRXN-18273", "PWY0-321", "PM5", "TU5", "ENZRXN0-7862"]


def stage(tmp_path, frame):
    entry = copy.deepcopy(BY_FRAME[frame])
    stored = STORAGE[entry["path"]]
    packed = (FIXTURES / stored["path"]).read_bytes()
    assert len(packed) == stored["compressed_bytes"]
    assert hashlib.sha256(packed).hexdigest() == stored["compressed_sha256"]
    raw = gzip.decompress(packed)
    assert len(raw) == stored["bytes"] and hashlib.sha256(raw).hexdigest() == stored["sha256"]
    path = tmp_path / entry["path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    return entry


def metadata(tmp_path, frame):
    return phenylacetate_metadata(stage(tmp_path, frame), tmp_path)


def snapshot(meta, key="original"):
    ident, term = phenylacetate_term(meta, key)
    return {"version": 1, "sources": {key: meta}, "terms": {ident: term}}


def consume(tmp_path, value):
    file = tmp_path / "authority.json"
    file.write_text(json.dumps(value))
    return _load_authority(file)


def rewrite(tmp_path, entry, root):
    raw = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    (tmp_path / entry["path"]).write_bytes(raw)
    entry["sha256"] = hashlib.sha256(raw).hexdigest()


@pytest.mark.parametrize("frame", list(BY_FRAME))
def test_complete_original_roundtrip(tmp_path, frame):
    entry = stage(tmp_path, frame)
    meta = phenylacetate_metadata(entry, tmp_path)
    raw = base64.b64decode(meta[FIELD]["original_base64"], validate=True)
    assert raw == (tmp_path / entry["path"]).read_bytes()
    assert len(meta[FIELD]["projection"]["slots"]) == len(ET.fromstring(raw)[1])
    assert consume(tmp_path, snapshot(meta)) == snapshot(meta)["terms"]


def test_native_scope_is_preserved(tmp_path):
    pathway = metadata(tmp_path, "PWY0-321")[FIELD]["projection"]
    assert len(pathway["reaction_list"]) == 9
    assert "MetaCyc:RXN0-6512" in pathway["reaction_list"]
    net = metadata(tmp_path, "RXN0-6512")[FIELD]["projection"]
    assert net["reaction_direction"] == "PHYSIOL-RIGHT-TO-LEFT"
    assert net["sides"]["left"][0]["material"] == "MetaCyc:TRANS-23-DEHYDROADIPYL-COA"
    abce = metadata(tmp_path, "CPLX-8168")[FIELD]["projection"]
    assert len(abce["components"]) == 4
    assert all(c["coefficient"] is None for c in abce["components"])
    paaz = metadata(tmp_path, "CPLX0-8538")[FIELD]["projection"]
    assert paaz["components"] == [{"id": "MetaCyc:G6708-MONOMER", "coefficient": 6}]
    assert phenylacetate_term(metadata(tmp_path, "AMP"), "s")[1]["label"] == "AMP"
    unnamed = phenylacetate_term(metadata(tmp_path, "G6716-MONOMER"), "s")[1]
    assert unnamed["label"] == "G6716-MONOMER" and unnamed["label_kind"] == "source_context"
    assert metadata(tmp_path, "ENZRXN0-7862")[FIELD]["projection"]["reaction"] == "EcoCyc:RXN0-7104"


@pytest.mark.parametrize("frame", REPRESENTATIVES)
@pytest.mark.parametrize(
    "mutation", ["query", "version", "frame", "type", "class", "slot", "extra"]
)
def test_producer_rejects_wrong_complete_original(tmp_path, frame, mutation):
    entry = stage(tmp_path, frame)
    root = ET.fromstring((tmp_path / entry["path"]).read_bytes())
    if mutation == "query":
        root.find("metadata/query").text = "META:WRONG"
    elif mutation == "version":
        root.find("metadata/PGDB").set("version", "26.5")
    elif mutation == "frame":
        root[1].set("frameid", "WRONG")
    elif mutation == "type":
        root[1].tag = "Gene"
    elif mutation == "class":
        root[1].set("class", "true")
    elif mutation == "slot":
        root[1].remove(root[1][0])
    else:
        ET.SubElement(root[1], "unexpected-native-slot").text = "not supported"
    rewrite(tmp_path, entry, root)
    with pytest.raises(ValueError):
        phenylacetate_metadata(entry, tmp_path)


@pytest.mark.parametrize("mutation", ["hash", "url", "release", "projection", "base64", "kind"])
def test_consumer_reparses_original_and_source(tmp_path, mutation):
    meta = metadata(tmp_path, "PWY0-321")
    if mutation == "hash":
        meta["sha256"] = "0" * 64
    elif mutation == "url":
        meta["url"] = meta["url"].replace("PWY0-321", "P321-PWY")
    elif mutation == "release":
        meta["version"] = "28.0"
    elif mutation == "projection":
        meta[FIELD]["projection"]["label"] = "invented name"
    elif mutation == "base64":
        meta[FIELD]["original_base64"] += "\n"
    else:
        meta["kind"] = "metacyc-html"
    with pytest.raises(ValueError):
        validate_phenylacetate_metadata(meta)


@pytest.mark.parametrize("frame", REPRESENTATIVES)
@pytest.mark.parametrize("field", ["label", "synonyms", "entity_type", "label_kind"])
def test_consumer_rejects_curated_term_overrides(tmp_path, frame, field):
    value = snapshot(metadata(tmp_path, frame))
    term = next(iter(value["terms"].values()))
    term[field] = ["invented alias"] if field == "synonyms" else "invented value"
    with pytest.raises(ValueError):
        consume(tmp_path, value)


def test_unselected_wrong_frame_is_rejected_before_selection(tmp_path):
    good = stage(tmp_path, "AMP")
    bad = stage(tmp_path, "RXN0-6512")
    root = ET.fromstring((tmp_path / bad["path"]).read_bytes())
    root[1].set("frameid", "RXN-2425")
    rewrite(tmp_path, bad, root)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps([good, bad]))
    corpus = tmp_path / "records"
    corpus.mkdir()
    (corpus / "record.yaml").write_text("id: MetaCyc:AMP\n")
    with pytest.raises(ValueError):
        build_snapshot(manifest, corpus, tmp_path)


def test_unselected_request_downgrade_is_rejected(tmp_path):
    good = stage(tmp_path, "AMP")
    bad = stage(tmp_path, "PWY0-321")
    bad["kind"] = "metacyc-html"
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps([good, bad]))
    corpus = tmp_path / "records"
    corpus.mkdir()
    (corpus / "record.yaml").write_text("id: MetaCyc:AMP\n")
    with pytest.raises(ValueError, match="typed source"):
        build_snapshot(manifest, corpus, tmp_path)


def test_body_identity_and_source_cannot_choose_different_owner(tmp_path):
    a = metadata(tmp_path, "AMP")
    b = metadata(tmp_path, "ATP")
    value = snapshot(a)
    value["sources"]["other"] = b
    value["terms"]["MetaCyc:AMP"]["source"] = "other"
    with pytest.raises(ValueError):
        consume(tmp_path, value)


@pytest.mark.parametrize("frame", ["AMP", "CPLX0-8538", "G6716-MONOMER", "RXN0-6512", "PM5"])
@pytest.mark.parametrize("bad", ["label", "category"])
def test_namespace_context_rule_cannot_override_exact_profile(tmp_path, frame, bad):
    meta = metadata(tmp_path, frame)
    value = snapshot(meta)
    ident, term = next(iter(value["terms"].items()))
    section, categories = NODE_ROLES[term["entity_type"]]
    node = {"id": ident, "label": term["label"], "category": sorted(categories)[0]}
    if bad == "label":
        node["label"] = "invented source context"
    else:
        node["category"] = "gene"
    (tmp_path / "data/pathways").mkdir(parents=True)
    record = {"id": ident, "label": term["label"], "taxa": [], "participants": [], "reactions": []}
    # Use a known pathway identity; test the target in its actual section.
    anchor = metadata(tmp_path, "PWY0-321")
    anchor_id, anchor_term = phenylacetate_term(anchor, "pathway")
    value["sources"]["pathway"] = anchor
    value["terms"][anchor_id] = anchor_term
    record.update(id=anchor_id, label=anchor_term["label"])
    record[section] = [node]
    (tmp_path / "data/pathways/draft.yaml").write_text(yaml.safe_dump(record))
    (tmp_path / "authority.json").write_text(json.dumps(value))
    namespaces = {i.split(":")[0]: {"snapshot": "authority.json", "policy": "canonical_or_synonym"}
                  for i in value["terms"]}
    (tmp_path / "conf").mkdir()
    (tmp_path / "conf/identifier_policy.yaml").write_text(yaml.safe_dump({
        "version": 1, "namespaces": namespaces,
        "contextual_labels": [{"namespace": ident.split(":")[0],
                               "sections": [section], "record_prefixes": ["MetaCyc"],
                               "reason": "adversarial broad namespace rule"}],
    }))
    errors = identifier_errors(tmp_path)
    assert any(("LABEL_MISMATCH" if bad == "label" else "ENTITY_TYPE_MISMATCH") in e
               for e in errors)


def test_unreviewed_frame_and_entity_links_fail(tmp_path):
    entry = stage(tmp_path, "AMP")
    entry["url"] = entry["url"].replace("AMP", "UNREVIEWED")
    with pytest.raises(ValueError, match="outside"):
        phenylacetate_metadata(entry, tmp_path)
    entry = stage(tmp_path, "ENZRXN-18273")
    root = ET.fromstring((tmp_path / entry["path"]).read_bytes())
    root.find("Enzymatic-Reaction/enzyme/Protein").set("frameid", "WRONG")
    rewrite(tmp_path, entry, root)
    with pytest.raises(ValueError, match="resource/frame"):
        phenylacetate_metadata(entry, tmp_path)


def test_profile_does_not_accept_other_p321_scope(tmp_path):
    entry = stage(tmp_path, "PWY0-321")
    entry["url"] = entry["url"].replace("PWY0-321", "P321-PWY")
    entry["kind"] = META_KIND
    with pytest.raises(ValueError, match="outside"):
        phenylacetate_metadata(entry, tmp_path)
