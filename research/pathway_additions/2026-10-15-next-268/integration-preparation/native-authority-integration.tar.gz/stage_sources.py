import pathlib,json,hashlib,shutil,gzip,xml.etree.ElementTree as ET
P=pathlib.Path(__file__).resolve().parent;W=pathlib.Path('/private/tmp/pathwaymech-next-268-20261015');R=W/'research/pathway_additions/2026-10-15-next-268/authority-source-originals';T=W/'tests/fixtures/phenylacetate_authority'
R.mkdir(parents=True,exist_ok=True);T.mkdir(parents=True,exist_ok=True)
rows=sum([json.loads((P/f).read_text()) for f in ['initial-native-profile-inputs.json','additional-ecocyc-profile-inputs.json','additional-metacyc-profile-inputs.json']],[]);entries=[];proof=[];storage={}
old=json.loads((P/'before/data/identifier_authorities/sources.json').read_text())['terms']
for r in rows:
 assert r['id'] not in old,r['id']
 source=pathlib.Path(r['file']);b=source.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256'];prefix,frame=r['id'].split(':');pgdb='META' if prefix=='MetaCyc' else 'ECOLI';path=f'{pgdb}-{frame}.xml';(R/path).write_bytes(b)
 receipt=source.with_name(source.name+'.receipt.json')
 if receipt.exists():shutil.copyfile(receipt,R/(path+'.receipt.json'))
 e={'key':f'phenyl268-{pgdb}-{frame}','kind':'metacyc-phenylacetate-xml' if pgdb=='META' else 'ecocyc-phenylacetate-xml','path':'phenyl268/'+path,'url':f'https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?id={pgdb}:{frame}','version':'27.0','license':'BioCyc license; redistribution review deferred until public release','sha256':r['sha256']};entries.append(e)
 dest=P/'source-cache'/e['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 zipped=gzip.compress(b,mtime=0);zpath=path+'.gz';(T/zpath).write_bytes(zipped);storage[e['path']]={'path':zpath,'bytes':len(b),'sha256':r['sha256'],'compressed_bytes':len(zipped),'compressed_sha256':hashlib.sha256(zipped).hexdigest()}
 proof.append({**r,'maintained_original':str((R/path).relative_to(W)),'manifest_entry':e,'receipt':str(receipt) if receipt.exists() else None})
(P/'new-source-manifest.json').write_text(json.dumps(entries,indent=2)+'\n');(R/'source-provenance.json').write_text(json.dumps(proof,indent=2)+'\n');(T/'manifest.json').write_text(json.dumps(entries,indent=2)+'\n');(T/'storage.json').write_text(json.dumps(storage,indent=2)+'\n')
# All selected source/reference identities; not a biological record or generated labels.
(P/'selection').mkdir(exist_ok=True);(P/'selection/all-source-identities.yaml').write_text(json.dumps({'id':rows[0]['id'],'participants':[{'id':r['id']} for r in rows[1:]]},indent=2)+'\n')
print('staged',len(entries))
