# Native authority integration — ready for independent review

The maintained authority increment is complete and quiescent in
`/private/tmp/pathwaymech-next-268-20261015`, HEAD
`2c27fc819bac17ef05e191830346d7a32248c97c`. This packet freezes the author result;
it is not an independent acceptance or final record-curation claim.

## Maintained owner scope

Only these owners were changed by this task:

- `src/pathwaymech/biocyc_phenylacetate.py` (new bounded source parser/profile)
- `src/pathwaymech/identifiers.py` (typed producer/consumer identity and node checks)
- `scripts/build_source_identifier_snapshot.py` (new exact source kinds and preselection checks)
- `conf/identifier_sources.json`
- `data/identifier_authorities/sources.json` and `ontology.json`
- `tests/test_phenylacetate_authority.py`
- `tests/fixtures/phenylacetate_authority/` (65 complete compressed originals with verified storage metadata)
- `research/pathway_additions/2026-10-15-next-268/authority-source-originals/`
  (65 complete XML bodies, all 65 acquisition receipts, source-provenance inventory).

`maintained-owner-inventory.json` binds all 205 owned files by exact path, byte
count and SHA-256. `after/` preserves the exact reviewed result; `before/` preserves
the prior owned files. No record, schema, graph/KGX/renderer, governed skill or
documentation owner was edited. No Git/GH operations, environment mutation,
installation/repair, downloads or child agents were used for this integration.

## Result and source boundary

The new profile accepts only 65 independently inspected complete instance frames,
with exact frame/type/direct-slot inventory, source envelope, request/PGDB/version
and original-body identity. It derives names and synonyms from XML, never curated
labels. It retains every source direct slot plus complete original bytes and
replays their projection at consumer load. Embedded frame/ID/resource identities,
native sides/directions, activity links, complex components and nine-member native
pathway membership are checked. A no-common-name frame uses its native ID exactly.
Typed source downgrades are rejected before record selection. META and ECOLI remain
separate and ECOLI's MG1655 catalog identity is not an E. coli W construct claim.
The existing P321-PWY implementation/profile was not widened or edited.

65 new source terms comprise the 53 missing MetaCyc terms from the native draft,
5 additional complete MetaCyc chemistry objects (CIS-34-DEHYDROADIPYL-COA,
CPD0-2558, CPD0-2559, RXN-17752, RXN0-7103), and 7 complete EcoCyc objects
(G6717-MONOMER, G6720-MONOMER, G6721-MONOMER, PM4, PM5, TU5, ENZRXN0-7862).
The chemistry context is not added to the native nine-reaction pathway membership.
`added-identifiers.tsv` supplies every exact added ID, source-derived label/type,
owner, URL, whole-body/source checksum and retained original path.

Four ontology additions use the existing pinned sources: NCBITaxon:134536
(Paraburkholderia caledonica), NCBITaxon:198931 (Pseudomonas sp. Y2),
NCBITaxon:566546 (Escherichia coli W), CHEBI:63252
(2-oxepin-2(3H)-ylideneacetyl-CoA(4-)). CHEBI:18420 was already present unchanged.
Both read-only SQL databases were hashed in full and their source version, URL
and license metadata verified before extraction:

- NCBI Taxonomy 2026-07-12, SHA-256
  `89998447813e3151d1116222a3ec4b74959ccfb492114db134acee753f63548d`,
  14,115,225,600 bytes.
- ChEBI 255, SHA-256
  `26ad4890cdcf6ee357760d815dfee8f5ba81e0873e62cb379369b04205722b0f`,
  4,137,340,928 bytes.

These are the already-pinned SQL sources, not release updates. Complete checks
and exact returned labels/synonyms are in the two cache-verification JSON files.

## Preservation and reproduction

Source terms: 3221→3286. Source owners: 1209→1274. Every earlier term, metadata
object, ontology source and manifest entry is exactly equal to its baseline
semantic value; earlier JSON insertion order is preserved too. The native draft's
six pre-existing MetaCyc terms retain their earlier owners. Source and ontology
snapshots therefore show additions rather than unrelated reorder/removal churn.

The 65 newly retained originals reproduce byte-for-byte through the normal
source snapshot CLI. A separate additive integration replay re-extracts the four
ontology additions and produces all final maintained snapshot/manifest bytes
exactly; see `final-maintained-reproduction.json`. Existing historical source
bodies were not all rebuilt: they are explicitly reused unchanged and passed
through the complete authority consumer. `REPRODUCE.md` gives exact commands,
fresh-cache staging from maintained originals and that scope boundary.

Final maintained hashes:

- `sources.json`: `aa7c977d4e8b71f4264592999b4524dd2b340eaff23f7189ca13f6fc63fc92d9`
- `ontology.json`: `952248437d7970aa374f1ea6ae3946aded314a33481a1e66d565081ee83ea974`
- `conf/identifier_sources.json`: `c794c9a526ed911bd51ee5ee045646ec87f4093aa198889b4af70f8fc42f3a75`

An intermediate ordering attempt is retained under `attempts/`; final snapshots
preserve prior insertion order. No failed attempt is presented as final output.

## Checks

- New targeted module: 186 passed in 5.71 s.
- New module plus existing P321, typed consumer integrity, source snapshot and
  identifier regressions: 836 passed in 40.49 s; stderr empty, terminal exit 0.
- All 264 maintained records: 0 identifier errors in 52.582 s.
- Frozen native draft copied into an owned isolated gate root: all 66 identifiers
  pass, 0 errors in 7.365 s. The only draft adjustment is explicit
  `category: molecular_activity` on the 9 native reactions, required for their
  typed authority. Native material/biological coverage remains intact; frozen
  draft itself was not modified.
- Ruff on all four owned code/test modules and owned tracked whitespace diff:
  pass. Test logs and structured gate/static receipts are retained.

Meaningful adversarial cases include complete source query/frame/version/type
mismatch, class instances, missing/surplus direct slots, original-body/hash/base64
or projection mismatch, source-owner substitution, curated label/synonym/type
replacement, broad contextual-label bypass, unselected bad source or downgrade,
embedded frame/resource mismatch and cross-profile bleed. Source-native omission
of component coefficients and explicit PaaZ coefficient 6 are distinguished.

## Remaining work

Root owns the final record, primary interpretation integration and schema/renderer
contracts. This is source-faithful authority support, not complete final curation.
`IDENTIFIERS-fragment.md` is ready for root's documentation owner.

The supplied complete originals do not close SlyA EcoCyc:CPLX0-8563, SrsR
EcoCyc:G7518-MONOMER, CRP EcoCyc:CPLX0-226 or IHF EcoCyc:PC00027. Their positive
native regulator edges must remain explicitly pending unless complete issuing
endpoint originals are acquired and independently reviewed. This is a bounded
input statement, not a global claim those resources do not exist. The primary
fragment agent was informed directly.

PaaI's complete EcoCyc:ENZRXN0-7862 activity is supported; its RXN0-7104 backlink
is not an independently acquired reaction owner in this increment. PaaX2000
E. coli W crude extract evidence cannot silently become a sequence-resolved
MG1655 construct. Z-oxepin is an alternative interpretation with the recorded
E-source identity conflict, not an exact alias. CHEM-02 remains open for an exact
isolated PaaJ C8-to-cis-3,4-C6 reaction issuer; the native net reaction and BiGG
2,3-hydration context do not close it. Authority integration narrows none of the
native source/material/biological coverage obligations.
