from pathlib import Path
W=Path('/private/tmp/pathwaymech-next-268-20261015')
def change(s,old,new,count=1):
 assert s.count(old)==count,(old[:70],s.count(old),count)
 return s.replace(old,new)
imp='''from pathwaymech.biocyc_phenylacetate import (
    FIELD as PHENYLACETATE_FIELD,
)
from pathwaymech.biocyc_phenylacetate import (
    NODE_ROLES as PHENYLACETATE_NODE_ROLES,
)
from pathwaymech.biocyc_phenylacetate import (
    PHENYLACETATE_KINDS,
    phenylacetate_term,
    validate_phenylacetate_assertions,
    validate_phenylacetate_metadata,
)
'''
p=W/'src/pathwaymech/identifiers.py';s=p.read_text();s=change(s,'from pathwaymech.biocyc_pathway import PATHWAY_KIND, pathway_term, validate_pathway_metadata\n','from pathwaymech.biocyc_pathway import PATHWAY_KIND, pathway_term, validate_pathway_metadata\n'+imp)
s=change(s,'    fields.update(P321_FIELDS)\n','    fields.update(P321_FIELDS)\n    fields.update({kind: PHENYLACETATE_FIELD for kind in PHENYLACETATE_KINDS})\n')
s=change(s,'                "native_p321",\n','                "native_p321",\n                PHENYLACETATE_FIELD,\n',2)
s=change(s,'ACETO_KINDS | BENZOYL_KINDS | P321_KINDS | {','ACETO_KINDS | BENZOYL_KINDS | P321_KINDS | PHENYLACETATE_KINDS | {')
s=change(s,'        if metadata.get("kind") in P321_KINDS:\n','        if metadata.get("kind") in PHENYLACETATE_KINDS:\n            validate_phenylacetate_metadata(metadata)\n        elif PHENYLACETATE_FIELD in metadata:\n            raise ValueError("phenylacetate metadata requires its matching source kind")\n        if metadata.get("kind") in P321_KINDS:\n')
s=change(s,'    validate_p321_assertions(data["sources"], [], allow_legacy_products=True)\n','    validate_p321_assertions(data["sources"], [], allow_legacy_products=True)\n    validate_phenylacetate_assertions(data["sources"], [])\n')
s=change(s,'        if source_kind in P321_KINDS:\n','        if source_kind in PHENYLACETATE_KINDS:\n            expected_id, expected_term = phenylacetate_term(\n                data["sources"][term["source"]], term["source"]\n            )\n            if identifier != expected_id or term != expected_term:\n                raise ValueError(f"{identifier}: invalid complete phenylacetate projection")\n        elif source_kind in P321_KINDS:\n')
s=change(s,'    return data["terms"]\n','    validate_phenylacetate_assertions(\n        data["sources"], [(ident, term["source"]) for ident, term in data["terms"].items()]\n    )\n    return data["terms"]\n')
needle='            if term.get("entity_type") == "native_pathway":\n'
code='''            if term.get("entity_type") in PHENYLACETATE_NODE_ROLES:
                required_section, categories = PHENYLACETATE_NODE_ROLES[term["entity_type"]]
                if section != required_section or node.get("category") not in categories:
                    errors.append(
                        f"{where}: ENTITY_TYPE_MISMATCH {identifier!r}; "
                        f"complete native identity requires {required_section} "
                        f"with category in {sorted(categories)!r}"
                    )
                else:
                    labels = [term["label"]]
                    if entry["policy"] == "canonical_or_synonym":
                        labels += term["synonyms"]
                    if _normalize(label) not in {_normalize(value) for value in labels}:
                        errors.append(
                            f"{where}: LABEL_MISMATCH {identifier!r}: {label!r}; "
                            f"authority label is {term['label']!r}"
                        )
                # Source-derived names and explicit frame-only fallbacks cannot
                # be overridden by a namespace's broad contextual-label rule.
                continue
'''
s=change(s,needle,code+needle);p.write_text(s)
p=W/'scripts/build_source_identifier_snapshot.py';s=p.read_text()
imp='''from pathwaymech.biocyc_phenylacetate import (
    PHENYLACETATE_KINDS,
    phenylacetate_metadata,
    phenylacetate_term,
    validate_phenylacetate_assertions,
)
'''
s=change(s,'from pathwaymech.biocyc_pathway import PATHWAY_KIND, pathway_metadata, pathway_term\n','from pathwaymech.biocyc_pathway import PATHWAY_KIND, pathway_metadata, pathway_term\n'+imp)
s=change(s,'    validate_p321_assertions(p321_sources, [])\n','''    validate_p321_assertions(p321_sources, [])
    phenylacetate_sources = {
        index: phenylacetate_metadata(entry, cache_dir)
        if entry["kind"] in PHENYLACETATE_KINDS else entry
        for index, entry in enumerate(entries)
    }
    validate_phenylacetate_assertions(phenylacetate_sources, [])
''')
s=change(s,'ACETO_KINDS | BENZOYL_KINDS | P321_KINDS | {','ACETO_KINDS | BENZOYL_KINDS | P321_KINDS | PHENYLACETATE_KINDS | {')
s=change(s,'        elif entry["kind"] in P321_KINDS:\n','''        elif entry["kind"] in PHENYLACETATE_KINDS:
            metadata = phenylacetate_sources[entry_index]
            identifier, typed_term = phenylacetate_term(metadata, key)
            parsed_terms = [(identifier, typed_term["label"], typed_term["synonyms"])]
        elif entry["kind"] in P321_KINDS:
''')
s=change(s,'                not in {ECOCYC_COMPLEX_KIND, ECOCYC_STATE_KIND, NAMED_COMPLEX_KIND, NESTED_KIND}\n','                not in {ECOCYC_COMPLEX_KIND, ECOCYC_STATE_KIND, NAMED_COMPLEX_KIND, NESTED_KIND}\n                and entry["kind"] not in PHENYLACETATE_KINDS\n')
s=change(s,'            if entry["kind"] in P321_KINDS:\n','''            if entry["kind"] in PHENYLACETATE_KINDS:
                terms[identifier] = phenylacetate_term(metadata, key)[1]
            if entry["kind"] in P321_KINDS:
''')
s=change(s,'    validate_benzoyl_assertions(all_aceto_sources, all_aceto_claims)\n','''    validate_phenylacetate_assertions(all_aceto_sources, all_aceto_claims)
    validate_benzoyl_assertions(all_aceto_sources, all_aceto_claims)
''')
s=s.replace('metacyc-gene-xml (separate product_source original),','metacyc-gene-xml (separate product_source original),\nmetacyc-phenylacetate-xml, ecocyc-phenylacetate-xml (complete bounded originals),')
p.write_text(s)
