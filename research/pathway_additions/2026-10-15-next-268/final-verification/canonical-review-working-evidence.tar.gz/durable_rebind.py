from pathlib import Path
import tarfile,hashlib,json
P=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-268-20261015');D=W/'research/pathway_additions/2026-10-15-next-268/review-preparation';inv=json.loads((D/'inventory.json').read_text());out=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for x in inv['packets']:
 if x['archive'] not in ['primary-scientific-review.tar.gz','S01-correction.tar.gz']:continue
 p=D/x['archive'];assert sha(p)==x['archive_sha256'];rows={f['path']:f for f in x['files']};names=[]
 with tarfile.open(p) as t:
  mem={m.name:m for m in t.getmembers() if m.isfile()};assert set(mem)==set(rows)
  for n,m in mem.items():
   b=t.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==rows[n]['sha256']
   orig=Path(x['source_path'])/n;assert sha(orig)==rows[n]['sha256'];names.append(n)
 out.append({'path':str(p.relative_to(W)),'sha256':sha(p),'member_count':len(names),'every_member_matches_original_and_inventory':True})
(P/'durable-rebind.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
