from pathlib import Path
import json,hashlib,yaml
P=Path(__file__).resolve().parent;r=json.loads((P/'canonical-save-receipt.json').read_text());assert r['save_exit_code']==r['check_exit_code']==0
review=yaml.safe_load((P/'saved-review.yaml').read_text());target=r['source_target_sha256'];root=json.loads((P/'final-gates.json').read_text())
files='\n'.join('- `'+x['repo_path']+'`: SHA-256 `'+x['sha256']+'`.' for x in r['files'])
text=f'''# Canonical scientific successor review — frozen handoff

The canonical review is saved and checked: **completed, pass with limitations**, zero findings in its declared scope. The reviewed maintained target is `MetaCyc:PWY0-321`, `data/pathways/phenylacetate-degradation-i-aerobic.yaml`, SHA-256 `{target}`. No maintained writes were made except the canonical saver-produced YAML/Markdown bundle.

{files}

`canonical-save-receipt.json` binds the actual validate/save/check commands and exit codes. All three exited 0. The repository-wide saved-review result is `{json.dumps(r['check_result'],sort_keys=True)}`. The source captures {r['input_count']} exact inputs, {len(review['checks'])} checks ({r['required_gate_count']} required), and {len(review['evidence'])} evidence entries. Every required current check passed. The initial three-failure full suite remains explicitly retained as a superseded diagnostic rather than rewritten as success.

## Scientific bounds and corrections

Eight contextual evidence assertion/locator pairs now cite the authentic full Reaction left/right/reaction-direction slots; exactly sixteen scalar strings changed. The target otherwise retains its reviewed primary assertions and native structure. Fresh XML/delta replay passed 1,898 scoped assertions. The 614-check peer-primary predecessor and authentic original bindings are retained; no fresh global source search or full literature rereading is claimed.

This reviewer authored the native draft and authority integration. Global independence is conservatively `self_review`. Root-authored S01 and peer-authored primary assertions were reviewed independently; native science relies on the previously accepted separate independent dossier and is checked here for structural preservation only. This is not self-acceptance of native science or authority implementation.

Native nine reactions, forty material occurrences, twenty-two native materials and sixty-eight native edges remain preserved. CHEM02 remains open; inferred isolated PaaJ chemistry has no invented issuer ID. E/Z and CCD distinctions, missing full construct/source bodies and six pending regulator proposals retain their explicit limits. Corrections 609–611 remain in the description and ledgers. No native status, history, issue closure, Git/GitHub or release/licensing action follows from this review.

## Current implementation and gates

The three rendering/KGX compatibility corrections were canonically re-inspected and compared to exact accepted preimages. Independent successor acceptance was read and all 32 archive members replayed: six current owners match, ten focused tests and 68 independent assertions pass, all 273 production outputs remain byte-identical. The historical implementation predecessor is not treated as acceptance of unseen successor code.

Root's terminal `final-gates.json` SHA-256 is `{root['root_receipt_sha256']}`. All fourteen current log members and all 542 listed prepublication inputs were independently rehashed here. The full suite exited 0 with 6,528 passed, three skipped and seven warnings in 1,196.04 seconds. Current validate, lint, render, vendored and diff gates passed. These root-executed receipts are reused, not duplicate full test execution. Canonical validate/save/check covers the newly added review bundle; final publication/staging remains the parent's scope.

## Retention scope

Exactly five selected preparation archives were replayed (390 members): `integration-preparation/primary-curation-fragments.tar.gz` (144), `integration-preparation/bound-claim-support.tar.gz` (41), `accepted-preparation/native-record-draft.tar.gz` (167), `accepted-preparation/primary-corrections.tar.gz` (23), and `accepted-preparation/independent-primary-corrections-review.tar.gz` (15). Separately, `review-preparation/primary-scientific-review.tar.gz` (240) and `review-preparation/S01-correction.tar.gz` (8) were replayed, plus `rendering-correction-acceptance/independent-rendering-acceptance.tar.gz` (32). This does not claim replay of all 1,100 members in the parent's broader five-archive review-preparation set.

Final-verification evidence references identify exact archive member destinations. Their source bytes were inspected at CI/working locations before parent retention; member hashes are not presented as hashes of an unseen container. The parent must retain and verify the entire frozen working packet and selected root receipts under the planned durable owner. `artifact-manifest.json` and `freeze-proof.json` will bind the complete scratch packet; only those two exact root-relative names are excluded from the member manifest. No further writes after freeze.
'''
(P/'HANDOFF.md').write_text(text)
print(json.dumps({'handoff_sha256':hashlib.sha256((P/'HANDOFF.md').read_bytes()).hexdigest(),'review_id':r['review_id']}))
