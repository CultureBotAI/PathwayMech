from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,yaml
P=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-268-20261015')
content=P/'completed-review.yaml';review=yaml.safe_load(content.read_text())
assert review['completion']=='completed', 'Do not save a completed review before gates are real'
assert all(c['status']=='passed' for c in review['checks'] if c['required'])
assert not (P/'canonical-save-receipt.json').exists()
for entry in review['source']['inputs']:
 assert hashlib.sha256((W/entry['path']).read_bytes()).hexdigest()==entry['sha256'],entry['path']
base=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py']
commands=[]
def run(name,args):
 command=base+args;r=subprocess.run(command,cwd=W,capture_output=True)
 (P/(name+'.stdout')).write_bytes(r.stdout);(P/(name+'.stderr')).write_bytes(r.stderr)
 commands.append({'name':name,'command':command,'exit_code':r.returncode})
 if r.returncode!=0:
  (P/'canonical-failed-command.json').write_text(json.dumps(commands,indent=2)+'\n')
  raise AssertionError((name,r.returncode,r.stderr.decode(),r.stdout.decode()))
 return r
run('canonical-final-validate',['validate',str(content)])
save=run('canonical-save',['save','--content',str(content)])
paths=json.loads(save.stdout)
check=run('canonical-check',['check'])
files=[]
for name in ['review','markdown']:
 path=Path(paths[name]);raw=path.read_bytes();(P/('saved-'+path.name)).write_bytes(raw)
 files.append({'path':str(path),'repo_path':path.relative_to(W).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
receipt={'completed_utc':datetime.now(timezone.utc).isoformat(),'review_id':review['review_id'],'verdict':review['verdict'],'completion':review['completion'],'source_target_sha256':next(x['sha256'] for x in review['source']['inputs'] if x['path']=='data/pathways/phenylacetate-degradation-i-aerobic.yaml'),'input_count':len(review['source']['inputs']),'required_gate_count':sum(c['required'] for c in review['checks']),'files':files,'commands':commands,'save_exit_code':save.returncode,'check_exit_code':check.returncode,'check_result':json.loads(check.stdout),'maintained_writes':'Canonical saver bundle only; no code, target, source, history, Git or GitHub mutation.'}
(P/'canonical-save-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
