from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
P=Path(__file__).resolve().parent
assert (P/'canonical-save-receipt.json').exists(), 'Canonical saver must complete first'
assert not (P/'artifact-manifest.json').exists() and not (P/'freeze-proof.json').exists(), 'Do not overwrite a frozen packet'
receipt=json.loads((P/'canonical-save-receipt.json').read_text())
assert receipt['save_exit_code']==0 and receipt['check_exit_code']==0
excluded={'artifact-manifest.json','freeze-proof.json'}
files=[x for x in sorted(P.rglob('*')) if x.is_file() and x.relative_to(P).as_posix() not in excluded]
assert all(not x.is_symlink() for x in files)
entries=[{'path':x.relative_to(P).as_posix(),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in files]
manifest={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Canonical bounded scientific successor review with source/record preservation, current rendering acceptance and actual terminal gates; scratch attempts and historical failures preserved. No maintained changes except the canonical saved review bundle.','hidden_ignored_included':True,'files':entries}
(P/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof={'frozen_utc':datetime.now(timezone.utc).isoformat(),'listed_files':len(entries),'physical_files':len(entries)+2,'artifact_manifest_sha256':hashlib.sha256((P/'artifact-manifest.json').read_bytes()).hexdigest(),'canonical_review':receipt,'all_local_jobs_terminal':True,'no_further_writes':True}
(P/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'listed_files':len(entries),'physical_files':len(entries)+2,'artifact_manifest_sha256':proof['artifact_manifest_sha256'],'freeze_proof_sha256':hashlib.sha256((P/'freeze-proof.json').read_bytes()).hexdigest()},indent=2))
