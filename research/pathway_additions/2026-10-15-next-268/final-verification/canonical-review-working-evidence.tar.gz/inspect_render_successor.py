from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess
P=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-268-20261015');C=Path('/private/tmp/pathwaymech-next-268-ci')
old=json.loads((P/'inspect-final.json').read_text()); release=json.loads((C/'render-fix-owner-release.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
oldhash={x['path']:x['sha256'] for x in old['source']['inputs']}
changes=[{'path':p,'before_sha256':h,'after_sha256':sha(W/p)} for p,h in oldhash.items() if sha(W/p)!=h]
assert [x['path'] for x in changes]==['src/pathwaymech/kgx.py'],changes
for entry in release['owners']:assert sha(W/entry['path'])==entry['sha256'],entry
paths=sorted(set(oldhash)|{x['path'] for x in release['owners']})
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(P/'targets.yaml')]
for path in paths:cmd+=['--input',path]
result=subprocess.run(cmd,cwd=W,capture_output=True)
(P/'inspect-render-successor.json').write_bytes(result.stdout);(P/'inspect-render-successor.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode()
new=json.loads(result.stdout)
receipt={'accessed_at':datetime.now(timezone.utc).isoformat(),'command':cmd,'exit_code':result.returncode,'prior_inspection_sha256':sha(P/'inspect-final.json'),'successor_inspection_sha256':sha(P/'inspect-render-successor.json'),'release_receipt_sha256':sha(C/'render-fix-owner-release.json'),'changed_previously_inspected_inputs':changes,'new_inputs':[x for x in new['source']['inputs'] if x['path'] not in oldhash],'all_other_previously_inspected_inputs_unchanged':True,'scope':'Canonical successor inspection before assessment of released rendering compatibility correction; no scientific record or source authority bytes changed.'}
(P/'render-successor-inspection-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'inputs':len(new['source']['inputs']),'changes':changes,'new_inputs':len(receipt['new_inputs'])},indent=2))
