from pathlib import Path
from xml.etree import ElementTree as E
import json,hashlib,yaml,sys,tarfile
P=Path(__file__).resolve().parent;W=Path('/private/tmp/pathwaymech-next-268-20261015');C=Path('/private/tmp/pathwaymech-next-268-context-locator-correction');V=Path('/private/tmp/pathwaymech-next-268-primary-fragments-independent-review-v2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text())
checks=[]
def ck(name,truth,details=None):
 checks.append({'check':name,'passed':bool(truth),'details':details});assert truth,(name,details)
# Inspect receipt precedes this assessment.
ck('canonical inspect available before assessment',j(P/'inspect-before.json')['status']=='inspection_only')
for root in [C,V]:
 rows=j(root/'artifact-manifest.json')['files'];expected=set()
 for x in rows:
  rel=x.get('relative_path',x['path']);f=root/rel;expected.add(rel);ck('frozen byte '+str(f),sha(f)==x['sha256'])
 actual={str(x.relative_to(root)) for x in root.rglob('*') if x.is_file()}
 ck('full physical inventory '+root.name,actual==expected|{'artifact-manifest.json','freeze-proof.json'})
 ck('manifest freeze binding '+root.name,sha(root/'artifact-manifest.json')==j(root/'freeze-proof.json')['manifest_sha256'])
old=yaml.safe_load((C/'before.yaml').read_text());new=yaml.safe_load((C/'after.yaml').read_text());target=W/'data/pathways/phenylacetate-degradation-i-aerobic.yaml'
ck('maintained exact successor',target.read_bytes()==(C/'after.yaml').read_bytes())
ck('before exact previously assessed bytes',(C/'before.yaml').read_bytes()==(V/'target/review-merged-record.yaml').read_bytes())
diffs=[]
def diff(a,b,path=''):
 if type(a)!=type(b):diffs.append({'path':path,'before':a,'after':b});return
 if isinstance(a,dict):
  ck('mapping keys invariant '+path,set(a)==set(b))
  for k in a:diff(a[k],b[k],path+'/'+k)
 elif isinstance(a,list):
  ck('list length invariant '+path,len(a)==len(b))
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+'/'+str(i))
 elif a!=b:diffs.append({'path':path,'before':a,'after':b})
diff(old,new)
ck('exactly16 leaf edits',len(diffs)==16)
source_root=W/'research/pathway_additions/2026-10-15-next-268/authority-source-originals'
pwy=E.fromstring((source_root/'META-PWY0-321.xml').read_bytes());pn=next(x for x in pwy if x.tag=='Pathway' and x.get('frameid')=='PWY0-321');layouts={x.find('Reaction').get('frameid') for x in pn.findall('reaction-layout')};ck('nine source layouts',len(layouts)==9)
allowed=[];sourceproof=[]
for mi,m in enumerate(new['reaction_mechanisms']):
 if m['key'] not in ['primary-cyclic-deadend','primary-paay-salvage']:continue
 rid=m['source_reaction_id'];frame=rid.split(':',1)[1];src=source_root/f'META-{frame}.xml';xml=E.fromstring(src.read_bytes());rn=next(x for x in xml if x.tag=='Reaction' and x.get('frameid')==frame and x.get('orgid')=='META' and x.get('detail')=='full');direction=rn.findtext('reaction-direction');ck('actual contextual direction '+rid,direction=='PHYSIOL-LEFT-TO-RIGHT');ck('context outside native layouts '+rid,frame not in layouts)
 sides={}
 for side in ['left','right']:
  sides[side]=[(x.find('Compound').get('frameid'),int(x.findtext('coefficient') or 1)) for x in rn.findall(side)]
 ck('actual source equation '+rid,sides['left']==[(x['participant_id'].split(':',1)[1],x['coefficient']) for x in m['source_equation']['inputs']] and sides['right']==[(x['participant_id'].split(':',1)[1],x['coefficient']) for x in m['source_equation']['outputs']])
 for ei,e in enumerate(m['edges']):
  if e['predicate'] not in ['consumes','produces']:continue
  found=[(n,v) for n,v in enumerate(e['evidence']) if v['reference_id']==rid];ck('one native source evidence '+m['key']+'/'+e['key'],len(found)==1)
  vi,v=found[0]
  ck('corrected assertion '+e['key'],v['source_assertion']=='Source left/right participants and coefficients; reaction-direction is PHYSIOL-LEFT-TO-RIGHT.')
  ck('corrected locator '+e['key'],v['source_locator']==f'Reaction {frame} / left, right, reaction-direction')
  for field in ['source_assertion','source_locator']:allowed.append(f'/reaction_mechanisms/{mi}/edges/{ei}/evidence/{vi}/{field}')
 sourceproof.append({'reaction':rid,'source':str(src),'sha256':sha(src),'direction':direction,'sides':sides})
ck('all16 edits exactly allowed scalars',set(allowed)=={x['path'] for x in diffs})
# Archive identity verification, without extraction or executing archived code.
archives=[]
for parent,names in [('integration-preparation',['primary-curation-fragments.tar.gz','bound-claim-support.tar.gz']),('accepted-preparation',['native-record-draft.tar.gz','primary-corrections.tar.gz','independent-primary-corrections-review.tar.gz'])]:
 root=W/'research/pathway_additions/2026-10-15-next-268'/parent;inv=j(root/'inventory.json')
 for row in inv['packets']:
  if row['archive'] not in names:continue
  path=root/row['archive'];ck('archive hash '+row['archive'],sha(path)==row['archive_sha256']);expected={x['path']:x for x in row['files']};count=0
  with tarfile.open(path,'r:gz') as t:
   members={m.name:m for m in t.getmembers() if m.isfile()}
   ck('archive complete inventory '+row['archive'],set(members)==set(expected))
   for name,m in members.items():
    b=t.extractfile(m).read();ck('archive member '+row['archive']+' '+name,hashlib.sha256(b).hexdigest()==expected[name]['sha256']);count+=1
    orig=expected[name].get('original_path')
    if orig:ck('original archive binding '+name,sha(Path(orig))==expected[name]['sha256'])
  archives.append({'archive':str(path.relative_to(W)),'sha256':sha(path),'member_count':count,'all_members_bound':True})
sys.path.insert(0,str(W/'src'));from pathwaymech.schema import validate_record
v=validate_record(new);ck('semantic validator successor',v.id=='MetaCyc:PWY0-321')
(P/'successor-assessment.json').write_text(json.dumps({'maintained':{'path':str(target),'sha256':sha(target)},'diffs':diffs,'sourceproof':sourceproof,'archives':archives,'checks':checks,'passed':len(checks),'findings':[],'conclusion':'All eight corrected source evidence entries are supported by actual Reaction slots. Exactly16 scalar edits; all other assertions, material equations, statuses, quotations and native structural content unchanged. N268-S01 no longer reproduces.'},indent=2)+'\n')
print(json.dumps({'passed':len(checks),'diffs':len(diffs),'archives':archives,'finding':'none'}))
