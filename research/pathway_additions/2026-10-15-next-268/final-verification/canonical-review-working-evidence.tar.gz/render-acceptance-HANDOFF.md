# Independent successor acceptance — issues 618, 619 and 620

Accepted at the six exact released owner hashes in `owner-release.json`. No remaining defect was found in these bounded corrections. All 273 generated production-input outputs are byte-identical before and after, including every one of the 265 pathway pages and the KGX downloads. This is code/render/export acceptance; it does not independently approve reviewer-authored primary science, authority patches or the representation proposal's scientific motivation.

The parent owns whole-repository gates, commit binding and later GitHub dispositions. This packet does not claim the pending full-suite rerun passed and does not close issues itself.

## Correction assessment

- [618](https://github.com/CultureBotAI/PathwayMech/issues/618): `mechanism_views` returns before accessing participants when optional detail is absent/empty. `graph_html` returns the existing empty-state graph before reading declarations/identity only when both top-level edges and detail are empty. Detailed records without source edges still retain their source isolates. The original minimal fixture remains intact; omitted and explicit-empty variants both pass.
- [619](https://github.com/CultureBotAI/PathwayMech/issues/619): both new optional KGX attributes now use `getattr(..., [])`. All four omitted/empty combinations produce the exact baseline TSV hashes. Present detail payloads and context remain unchanged. No identifier, required record attribute or chemical identity is defaulted.
- [620](https://github.com/CultureBotAI/PathwayMech/issues/620): the helper selects a unique named graph section and requires its single network SVG. All prior source directed-edge, qualifier, evidence-row and whole-page uniqueness assertions remain. The corpus test also checks every expected detail graph, local edge triple, target and evidence statement. It does not skip the new pathway or simply choose the first SVG.

The three production diffs are retained under `diffs/`: only the two early returns and the two optional-attribute reads changed. The three updated tests are copied with release hashes under `inputs/`. No maintained edits, Git/GitHub mutation, runtime changes or installation were performed by this reviewer.

## Verification

`focused-tests.stdout` records **10 passes in 24.22 seconds**: both original stylesheet variants, the original navigation regression, the source/detail corpus integration test across all 265 records, and all six detailed-rendering tests, including source-isolate preservation without source edges.

`independent-probe-results.json` records **68 reviewer-authored assertions**, with no failures in the final attempt:

- Four combinations of omitted/empty `reaction_mechanisms` and `detail_only_participant_ids`; original minimal rendering and both direct helper paths succeed, all minimal outputs match and all KGX exports match the immutable baseline hashes.
- Eight deliberately corrupted outputs are detected: missing source/detail edges, wrong source predicate, wrong detail endpoint, missing detail graph, duplicated source section, and erased source/detail evidence rows.
- Reordering intact source and detail graph sections still passes, proving selection is based on the named scope rather than document order.
- Complete descriptions and evidence for all seven actual nested qualifiers remain visible in the detailed rows. This verifies transport only, not the scientific truth of those assertions.

`all-output-comparison.json` compares every filename, exact UTF-8 byte length and SHA256 from the pre-correction and successor production-input renders: **273 of 273 outputs unchanged**, with **265 record pages** on both sides. Source paths and history were supplied through the same production inputs; the comparison covers more than isolated rendering fixtures. Code import sentinels bind the before and after implementations. No generated maintained page was written during this check.

## Preserved history and limits

The earlier integration, issue 618 original-failure and issues 619/620 original-failure packets remain unchanged and are hash-verified by `predecessor-integrity.json`. Their failures are historical evidence, not rewritten as successes. The parent's release receipt also preserves its initial focused run's frozen-dataclass test setup mistake and subsequent `replace` correction.

This review's first corruption-probe attempt expected a `has_part` source predicate. The explicit check that a mutation changed bytes stopped it when that predicate was absent. The original script/stdout/stderr and disposition are retained. The corrected probe changes the first actual source predicate generically and then demonstrates detection; no production fix resulted from that reviewer setup error.

All reviewed owner bytes still match the release receipt at freeze. All local jobs are terminal. Whole-suite, browser pixel-level, new scientific evidence and licensing reviews are outside this bounded acceptance. Further owner changes require reassessment; the parent can bind this packet to the final published commit.
