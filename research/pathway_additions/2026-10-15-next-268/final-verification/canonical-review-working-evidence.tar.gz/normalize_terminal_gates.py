from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
P=Path(__file__).resolve().parent;C=Path('/private/tmp/pathwaymech-next-268-ci');W=Path('/private/tmp/pathwaymech-next-268-20261015');T='MetaCyc:PWY0-321'
raw=(C/'final-gates.json').read_bytes();g=json.loads(raw);assert g['all_required_checks_passed']
(P/'root-final-gates.json').write_bytes(raw)
now=datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ');reference='research/pathway_additions/2026-10-15-next-268/final-verification/root-verification.tar.gz'
checks=[];evidence=[];logs=[]
ids=['root-render','full-qc','lint','root-render-regressions','vendored','full-tests','diff-check']
for id,check in zip(ids,g['checks'],strict=True):
 assert check['exit_code']==0
 evidence_ids=[]
 for channel,f in check['logs'].items():
  path=Path(f['path']);assert path.parent==C;data=path.read_bytes();assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'],f
  eid=id+'-'+channel;evidence_ids.append(eid)
  evidence.append({'evidence_id':eid,'kind':'validation','reference':reference,'locator':path.name+' / complete terminal '+channel+'; snapshot_sha256 identifies this inspected member, not the later archive container','accessed_at':now,'snapshot_sha256':f['sha256'],'support':'supports','summary':'Inspected original CI log bytes and terminal root receipt for '+check['command']+'. '+(' '.join(check['summary'].split()) if channel=='stdout' else 'The exact stderr member is retained, including empty output or observed command invocation; root reports terminal exit 0.')})
  logs.append({'path':str(path),'bytes':len(data),'sha256':f['sha256']})
  print(path.name+': '+(data.decode()[-180:] if len(data)>1500 else data.decode()))
 value={'check_id':id,'name':check['command'],'status':'passed','required':check['required'],'summary':'Inspected root-executed terminal receipt: '+' '.join(check['summary'].split()),'target_ids':[T],'exit_code':0,'evidence_ids':evidence_ids,'scope_note':'Executed by root on the corrected current owners; inspected receipts reused here, not duplicate execution. Gate predates addition of the canonical bundle and final evidence archives; canonical saver/check and final staging cover those additive artifacts.'}
 if check['command'].startswith('just '):value['command']=check['command'].split(' (')[0]
 elif check['command']=='git diff --check':value['command']=check['command']
 checks.append(value)
old=json.loads((P/'initial-full-suite-failure.json').read_text());assert g['historical_failed_full_suite']['exit_code']==1
for f in g['historical_failed_full_suite']['logs'].values():assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256'];assert any(x['path']==f['path'] and x['sha256']==f['sha256'] for x in old['files'])
for x in g['unchanged_prepublication_inputs']:assert hashlib.sha256((W/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
evidence.append({'evidence_id':'root-terminal-receipt','kind':'validation','reference':reference,'locator':'final-gates.json / seven terminal current checks, historical failed suite, 542 prepublication input bindings, runtime and scope; SHA-256 identifies this inspected member','accessed_at':now,'snapshot_sha256':hashlib.sha256(raw).hexdigest(),'support':'supports','summary':'All seven current checks exited 0; six are required. The full suite records 6528 passed, three skipped and seven warnings. All 542 listed prepublication input hashes were independently rechecked here. The original three-failure suite is retained unchanged. This validates the recorded gates and bytes, not scientific correctness by count.'})
assert len(g['unchanged_prepublication_inputs'])==542
normalized={'checks':checks,'evidence':evidence,'root_receipt_sha256':hashlib.sha256(raw).hexdigest(),'all542prepublication_inputs_rehashed':True,'all_terminal_log_hashes_verified':True,'observed_utc':now}
(P/'final-gates.json').write_text(json.dumps(normalized,indent=2)+'\n');(P/'final-gates-log-bindings.json').write_text(json.dumps(logs,indent=2)+'\n');print(json.dumps({'checks':len(checks),'required_checks':sum(x['required'] for x in checks),'evidence':len(evidence),'root_receipt_sha256':normalized['root_receipt_sha256'],'input_bindings_verified':542}))
