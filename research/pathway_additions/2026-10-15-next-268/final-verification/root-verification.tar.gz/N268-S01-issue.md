Eight material edges in the new phenylacetate record's contextual `primary-cyclic-deadend` and `primary-paay-salvage` mechanisms cite `Pathway PWY0-321 / reaction-layout` and claim that their orientations follow that layout. Neither contextual reaction is a native member of PWY0-321 or has such a layout in its complete retained XML.

Independent scientific review found this provenance defect; root confirmed all nine native layouts from the checksum-bound original. The contextual reaction equations and directions themselves remain supported: the complete RXN-17752 and RXN0-7103 originals declare their left/right sides and `PHYSIOL-LEFT-TO-RIGHT` direction.

Acceptance:

- Correct exactly these eight material-edge source assertions and locators to the respective Reaction left/right and reaction-direction slots.
- Preserve the source equations, native membership, experimental scope, and other evidence.
- Retain the original author packet and record the maintained successor independently.
- Verify the corrected record and generated page, then independently review the correction before closing after merge.

Review identifier: N268-S01. This is a minor evidence-locator defect, not an unsupported equation or a request to add the contextual reactions to native pathway membership.
