The first full local suite for the phenylacetate/mechanism increment fails `tests/test_html_navigation.py::test_browse_keeps_all_records_and_source_path_association`. `kgx_nodes` reads the new optional `detail_only_participant_ids` attribute directly on the existing record-like interface, causing AttributeError. A second direct access to optional `reaction_mechanisms` also needs the same compatibility treatment.

Treat absent optional extension lists as empty, preserving all prior node contexts and complete detail-bearing KGX payloads. Do not change the legacy fixture to conceal the failure. Acceptance: exact existing regression and KGX tests pass, all 265 current exports remain byte-identical to the pre-fix outputs, and independently reviewed successor passes required gates. Preserve the first failed full-suite log (3 failed, 6523 passed, 3 skipped).

Keep open until corrected merged tree verification.
