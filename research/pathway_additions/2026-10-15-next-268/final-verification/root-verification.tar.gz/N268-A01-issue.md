The new phenylacetate authority adapter skips every nested XML element without a `frameid` attribute. An identity-bearing reference can therefore bypass its PGDB/resource consistency checks by omitting that attribute.

Independent review reproduced this with the complete AMP original: at `/ptools-xml/Compound/parent/Compound`, remove `frameid` and change the reference to `resource="getxml?ECOLI:WRONG"` while retaining `orgid="META"`. With the deliberately mutated body's checksum recalculated, `_envelope()` and the document parser accept the inconsistent reference. Root independently confirmed the envelope result. This tests semantic identity validation, not a bypass of an unchanged body checksum.

Affected owner: `src/pathwaymech/biocyc_phenylacetate.py`, `_envelope()` descendant loop. Every identity-bearing descendant in the 65 genuine original bodies has a frame ID.

Acceptance:

- Reject incomplete identity-bearing nested references before projection, including missing frame IDs with contradictory resource, ID or database fields.
- Preserve the separately validated PGDB metadata envelope and all genuine original bodies.
- Cover producer and consumer rejection, plus normal-source regression checks.
- Keep this issue open until the corrected implementation is independently reviewed and retained in the verified merged tree.

Review identifier: N268-A01. The unchanged author snapshot and mutation evidence are retained separately from any correction successor.
