# N268-S01 / issue 617 correction

Only eight structured source assertions and their locators changed, across the two contextual reaction mechanisms. They now cite Reaction left/right and reaction-direction PHYSIOL-LEFT-TO-RIGHT. Native membership, all equations, quantities, statuses, quotations, and all other record content remain unchanged. The sixteen-leaf semantic diff is retained. Source confirmation reads the complete checksum-bound native Pathway and both Reaction originals. Independent successor acceptance and full repository gates are pending.

The maintained successor SHA-256 is `e99722d1ee920cf64aaeae7b00f1de9b59f939bd96a03a7ac5f2885933a72227`.
