from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent
NAMES=['primary','primary-corrections','independent-primary-corrections-review','independent-primary-review','root-regulatory-followup','independent-regulatory-followup-review','root-primary-access-continuation','independent-nature2012-main-review','native','independent-native-review','chemistry','independent-chemistry-review']
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':sha(b)}
proof=[];allfiles=[]
for name in NAMES:
 root=Path('/private/tmp/pathwaymech-next-268-'+name);mf=root/'artifact-manifest.json';m=json.loads(mf.read_text());listed=m['files'];expected=set()
 for r in listed:
  raw=Path(r.get('relative_path',r['path']));q=raw if raw.is_absolute() else root/raw;actual=bind(q);assert actual['bytes']==r['bytes'] and actual['sha256']==r['sha256'],str(q);expected.add(str(q.relative_to(root)))
 actual_files={str(q.relative_to(root)) for q in root.rglob('*') if q.is_file()}
 excluded=actual_files-expected;assert excluded <= {'artifact-manifest.json','freeze-proof.json','FREEZE.json'},(root,excluded)
 allfiles.extend(bind(root/r) for r in sorted(actual_files));proof.append({'root':str(root),'manifest':bind(mf),'listed_count':len(listed),'physical_count':len(actual_files),'excluded':sorted(excluded),'all_listed_match':True})
 for filename in ['artifact-manifest.json','freeze-proof.json','FREEZE.json','HANDOFF.md','ASSESSMENT.md']:
  s=root/filename
  if s.is_file():
   d=P/'accepted-inputs'/name/filename;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(s.read_bytes())
files={'corrected_primary':'/private/tmp/pathwaymech-next-268-primary-corrections/primary-claim-ledger.corrected.json','slya':'/private/tmp/pathwaymech-next-268-root-regulatory-followup/slya2017-claim-ledger.json','nature':'/private/tmp/pathwaymech-next-268-root-primary-access-continuation/nature2012-claim-ledger.json','native':'/private/tmp/pathwaymech-next-268-native/biological-claim-ledger.json'}
claims=[];claimfiles=[];source_events=[]
for category,path in files.items():
 s=Path(path);x=json.loads(s.read_text());items=x['claims'] if isinstance(x,dict) else x
 d=P/'accepted-inputs'/(category+'-claims.json');d.write_bytes(s.read_bytes());claimfiles.append({'scope':category,**bind(s)})
 for r in items:
  claims.append({'scope':category,'claim':r})
  for source in r.get('sources',r.get('source_owners',[])):
   q=Path(source['path']);actual=bind(q);assert actual['sha256']==source['sha256'];source_events.append({'claim':r['id'],**actual,'locator':source.get('locator')})
assert len(claims)==68
(P/'stable-packet-verification-before.json').write_text(json.dumps({'packets':proof,'all_physical_files':allfiles,'hidden_and_ignored_included':True},indent=2)+'\n')
(P/'accepted68-claim-scope.json').write_text(json.dumps({'claim_files':claimfiles,'claims':claims,'source_events':source_events},indent=2)+'\n')
print(json.dumps({'packets':len(proof),'physical_files':len(allfiles),'claim_count':len(claims),'source_binding_events':len(source_events)}))
