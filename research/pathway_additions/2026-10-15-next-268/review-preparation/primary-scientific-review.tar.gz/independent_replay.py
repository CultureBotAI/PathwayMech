from pathlib import Path
from collections import Counter
from xml.etree import ElementTree as ET
from html.parser import HTMLParser
import json,yaml,re,hashlib
P=Path(__file__).resolve().parent;T=P/'target';W=Path('/private/tmp/pathwaymech-next-268-20261015')
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(s):return ' '.join(s.split())
checks=[]
def check(name,truth,details=None):
 checks.append({'check':name,'passed':bool(truth),'details':details})
 return truth
claims={x['claim']['id']:x['claim'] for x in j(P/'accepted68-claim-scope.json')['claims']}
placements=j(T/'claim-to-output-dispositions.json')
check('all68 accepted exact claims copied once',len(placements)==len(claims)==68 and len({r['claim_id'] for r in placements})==68)
for x in placements:check('exact accepted claim '+x['claim_id'],x['accepted_claim']==claims[x['claim_id']])
originals=j(T/'retained-source-originals.json');sources=j(T/'source-proof-bindings.json')
for x in originals:
 check('retained original '+x['source_key'],sha(T/x['owned_path'])==x['sha256']==sha(Path(x['original']['path'])))
for k,x in sources.items():
 for typ in ['original','projection']:
  check(k+' '+typ+' original hash',sha(Path(x[typ]['path']))==x[typ]['sha256'])
 check(k+' reading copy byte-equal',sha(T/'reading'/f'{k}.txt')==x['projection']['sha256'])
class H(HTMLParser):
 def __init__(self):super().__init__();self.parts=[];self.skip=0
 def handle_starttag(self,t,a):
  if t in ['script','style']:self.skip+=1
  if not self.skip and t in ['p','div','section','li','tr','td','h1','h2','h3','h4','br']:self.parts.append(' ')
 def handle_endtag(self,t):
  if t in ['script','style']:self.skip=max(self.skip-1,0)
  if not self.skip and t in ['p','div','section','li','tr','td','h1','h2','h3','h4','br']:self.parts.append(' ')
 def handle_data(self,s):
  if not self.skip:self.parts.append(s)
quoted=[]
for k,x in j(T/'quote-proof.json').items():
 q=x['evidence']['quote'];n=norm(q);s=norm((T/'reading'/f"{x['source_key']}.txt").read_text());i=s.find(n)
 check('quote literal '+k,i>=0)
 original=Path(x['original']['path']);fresh=None
 if original.suffix=='.html':
  h=H();h.feed(original.read_text());s2=norm(''.join(h.parts));fresh=n in s2
  check('HTML source independently extracted quote '+k,fresh)
 quoted.append({'key':k,'source':x['source_key'],'reference':x['evidence']['reference_id'],'locator':x['evidence']['source_locator'],'quote':q,'projection_sha256':x['projection']['sha256'],'context':s[max(i-250,0):i+len(n)+350],'literal':i>=0,'fresh_html_literal':fresh})
(P/'independent-quote-contexts.json').write_text(json.dumps(quoted,indent=2,ensure_ascii=False)+'\n')
add=yaml.safe_load((T/'fragments/primary-additions.yaml').read_text());record=yaml.safe_load((T/'review-merged-record.yaml').read_text());native=yaml.safe_load((T/'inputs/pathwaymech-next-268-native-record-draft/phenylacetate-degradation-i-aerobic.native-draft.yaml').read_text())
check('maintained target byte equal',sha(W/'data/pathways/phenylacetate-degradation-i-aerobic.yaml')==sha(T/'review-merged-record.yaml'))
for field in ['id','label','pathway_type','taxa']:
 check('native structural field '+field,record.get(field)==native.get(field))
for field in ['participants','reactions','mechanistic_edges']:
 d={x['id']:x for x in record[field]}
 for x in native[field]:
  z=dict(d[x['id']]);enriched=field=='reactions' and z.pop('category',None)=='molecular_activity'
  check('native preserved '+field+' '+x['id'],z==x if enriched else d[x['id']]==x)
material={x['id']:x for x in j(P/'accepted-materials-rebound.json')}
chebi=Path('/private/tmp/pathwaymech-next-268-chemistry/originals/initial/ChEBI-63252.json');c=j(chebi)
check('ChEBI63252 original binding',sha(chebi)=='f751d1547473f6f1c504c6a17d8cb5b27debd6d44146608c68c9914851188bcf')
material['CHEBI:63252']={'elements':{a:int(b or 1) for a,b in re.findall(r'([A-Z][a-z]?)(\d*)',c['chemical_data']['formula'])},'charge':c['chemical_data']['charge']}
eq={x['id']:x for x in j(P/'fresh-native-equations.json')}
def vector(rows):return Counter({x['participant_id']:x['coefficient'] for x in rows})
def delta(inputs,outputs):
 d=Counter(outputs);d.subtract(inputs);return {k:v for k,v in d.items() if v}
def balance(d):
 a=Counter();q=0
 for mid,n in d.items():
  for e,v in material[mid]['elements'].items():a[e]+=v*n
  q+=material[mid]['charge']*n
 return {'elements':{e:n for e,n in a.items() if n},'charge':q}
replays=[];locator_findings=[]
pwy=Path('/private/tmp/pathwaymech-next-268-discovery/originals/public-META-PWY0-321.xml');root=ET.fromstring(pwy.read_bytes());p=next(x for x in root if x.tag=='Pathway' and x.get('frameid')=='PWY0-321');layouts={x.find('Reaction').get('frameid'):x.findtext('direction') for x in p.findall('reaction-layout')}
for m in add['reaction_mechanisms']:
 src=eq[m['source_reaction_id']];e=m['source_equation'];raw={k:[[x['participant_id'],x['coefficient']] for x in e[side]] for k,side in [('left','inputs'),('right','outputs')]}
 check('source equation exact '+m['key'],raw==src['source_sides'])
 iv,ov=vector(e['inputs']),vector(e['outputs'])
 if e['orientation']=='reversed':iv,ov=ov,iv
 oriented=delta(iv,ov);detail=Counter();steps=[]
 for s in m['steps']:
  ins,outs=Counter(),Counter()
  for edge in m['edges']:
   if edge['predicate']=='consumes' and edge['object'].get('step_key')==s['key']:ins[edge['subject']['node_id']]+=edge['coefficient']
   if edge['predicate']=='produces' and edge['subject'].get('step_key')==s['key']:outs[edge['object']['node_id']]+=edge['coefficient']
  d=delta(ins,outs);detail.update(d);b=balance(d)
  check('step element+charge balance '+m['key']+'/'+s['key'],not b['elements'] and b['charge']==0,b)
  steps.append({'key':s['key'],'inputs':dict(ins),'outputs':dict(outs),'balance':b,'status':s['assertion_status']})
 expected=Counter(oriented)
 for conflict in m.get('source_conflicts',[]):
  sign=-1 if conflict['side']=='inputs' else 1
  expected[conflict['source_participant_id']]-=sign*conflict['coefficient'];expected[conflict['interpreted_participant_id']]+=sign*conflict['coefficient']
 check('detail net explains source and explicit conflicts '+m['key'],{k:v for k,v in expected.items() if v}=={k:v for k,v in detail.items() if v})
 for edge in m['edges']:
  for ev in edge.get('evidence',[]):
   if 'Pathway PWY0-321 / reaction-layout' in ev.get('source_locator','') and m['source_reaction_id'].split(':',1)[1] not in layouts:
    locator_findings.append({'mechanism':m['key'],'edge':edge['key'],'evidence':ev,'actual_reaction_direction':src['direction'],'actual_layout_ids':list(layouts)})
 replays.append({'key':m['key'],'source_reaction_id':m['source_reaction_id'],'source_equation_literal':raw,'orientation':e['orientation'],'steps':steps,'oriented_source_net':oriented,'detail_net':{k:v for k,v in detail.items() if v}})
(P/'all11-independent-material-replay.json').write_text(json.dumps(replays,indent=2)+'\n')
(P/'context-layout-locator-findings.json').write_text(json.dumps({'pathway_original':str(pwy),'sha256':sha(pwy),'method':'Complete XML parse, not an ignored-aware partial search','findings':locator_findings},indent=2)+'\n')
for f in ['sources','ontology']:
 a=j(W/f'data/identifier_authorities/{f}.json');print('SNAPSHOT',f,list(a)[:8])
(P/'independent-replay-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']],'locator_findings':len(locator_findings)},indent=2))
