from pathlib import Path
import json,hashlib,yaml,sys
P=Path(__file__).resolve().parent;T=P/'target';W=Path('/private/tmp/pathwaymech-next-268-20261015')
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results=[]
def check(name,value,details=None):results.append({'check':name,'passed':bool(value),'details':details})
a=yaml.safe_load((T/'fragments/primary-additions.yaml').read_text());r=yaml.safe_load((T/'review-merged-record.yaml').read_text())
snapshots={f:j(W/f'data/identifier_authorities/{f}.json') for f in ['sources','ontology']}
terms={k:v for s in snapshots.values() for k,v in s['terms'].items()}
for node in a['participants']+a['reactions']:
 check('canonical label '+node['id'],terms[node['id']]['label']==node['label'],{'declared':node['label'],'authority':terms[node['id']]['label'],'category':node['category']})
refs={x['id']:x for x in a['references']}
for k,s in j(T/'source-proof-bindings.json').items():check('primary reference hash '+k,refs[s['reference_id']]['source_sha256']==s['original']['sha256'])
for x in j(T/'additional-public-id-proof-ledger.json'):
 check('additional issuer reference '+x['id'],sha(Path(x['original_path']))==x['sha256']==refs[x['id']]['source_sha256'])
check('PDB6JQL reference hash',refs['DOI:10.2210/pdb6jql/pdb']['source_sha256']==sha(T/'source-originals/pdb-6JQL.cif'))
sys.path.insert(0,str(W/'src'))
from pathwaymech.schema import validate_record
v=validate_record(r);check('existing repository semantic validator',v.id=='MetaCyc:PWY0-321')
# This checks only copied peer-primary additions; native science was independently reviewed elsewhere.
seen=set();locations=[]
def walk(x,path):
 if isinstance(x,dict):
  if 'reference_id' in x:
   check('declared evidence reference '+path,x['reference_id'] in {z['id'] for z in r['references']})
   if 'quote' in x:seen.add((x['reference_id'],x['quote'],x['source_locator']))
  for k,z in x.items():walk(z,path+'/'+k)
 elif isinstance(x,list):
  for n,z in enumerate(x):walk(z,path+'/'+str(n))
walk(a,'primary-additions')
proof={(x['evidence']['reference_id'],x['evidence']['quote'],x['evidence']['source_locator']) for x in j(T/'quote-proof.json').values()}
check('all unique promoted quotes covered by checked proof',seen<=proof,{'unique_promoted_quotes':len(seen),'quote_proof_count':len(proof),'missing':list(seen-proof)})
checks=j(P/'independent-replay-checks.json')+results
(P/'final-checks.json').write_text(json.dumps({'checks':checks,'count':len(checks),'passed':sum(x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']]},indent=2)+'\n')
(P/'validation-inputs.json').write_text(json.dumps({'snapshots':[{'path':str(W/f'data/identifier_authorities/{f}.json'),'sha256':sha(W/f'data/identifier_authorities/{f}.json')} for f in snapshots],'semantic_validator':{'path':str(W/'src/pathwaymech/schema.py'),'sha256':sha(W/'src/pathwaymech/schema.py')},'scope':'Existing validate_record only; root owns full-corpus/schema/authority/renderer/KGX/publication gates. Snapshot label comparison is not independent acceptance of reviewer-authored authority implementation.'},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'passed':sum(x['passed'] for x in checks),'failures':[x for x in checks if not x['passed']]}))
