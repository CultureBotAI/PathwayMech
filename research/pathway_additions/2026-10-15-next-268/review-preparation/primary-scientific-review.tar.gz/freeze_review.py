from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
P=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def j(p):return json.loads(p.read_text())
def item(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
checks=[]
for source,key in [('stable-packet-verification-before.json','all_physical_files'),('target-bindings-before.json','files')]:
 before=j(P/source);after=[]
 for x in before[key]:
  n=item(Path(x['path']));assert n==x,(x,n);after.append(n)
 roots=[Path(x['root']) for x in before['packets']] if 'packets' in before else [Path(before['source_root'])]
 physical={str(p) for root in roots for p in root.rglob('*') if p.is_file()}
 assert physical=={x['path'] for x in before[key]}
 checks.append({'source':source,'files':len(after),'unchanged':True,'hidden_and_ignored_included':True})
start=j(P/'review-start.json');gov=[]
for g in start['governance']:
 n=item(Path(g['path']));gov.append({'path':g['path'],'before_sha256':g['sha256'],'after_sha256':n['sha256'],'unchanged':g['sha256']==n['sha256']})
# Changes are recorded for assessment, never silently refreshed.
assert all(x['unchanged'] for x in gov),gov
maint=Path(j(P/'review.json')['maintained_target']['path']);assert sha(maint)==j(P/'review.json')['maintained_target']['sha256']
(P/'input-verification-after.json').write_text(json.dumps({'checks':checks,'governance':gov,'maintained':item(maint),'all_input_checks_pass':True},indent=2)+'\n')
(P/'terminal-receipts.json').write_text(json.dumps({'jobs_running':False,'completed_commands':[{'script':'replay_native_equations.py','exit':0,'outcome':'12 native/context equations fresh XML replay; 25 accepted material states byte-rebound'},{'script':'independent_replay.py.attempt1','exit':0,'outcome':'341/347; six fresh-HTML extraction misses caused by inserted inline-tag spaces; original result preserved'},{'script':'independent_replay.py','exit':0,'outcome':'347/347; block-only whitespace parser correction; no record mutation'},{'script':'final_checks.py','exit':0,'outcome':'614 total / 614 passed; known eight provenance-locator defects separately documented'},{'script':'write_review.py','exit':0,'outcome':'review/claims/corrections/findings written'}],'non_mutating_diagnostics':[{'command':'command -v pdftotext','exit':1,'outcome':'not on this shell PATH; no global absence claim or installation'},{'command':'existing Python importlib PDF packages','exit':0,'outcome':'pypdf/fitz/pdfplumber unavailable in pinned runtime; reused independently accepted exact-bound PDF extractions'}]},indent=2)+'\n')
files=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name not in ['artifact-manifest.json','freeze-proof.json']:
  x=item(p);x['relative_path']=str(p.relative_to(P));files.append(x)
(P/'artifact-manifest.json').write_text(json.dumps({'files':files,'hidden_and_ignored_included':True},indent=2)+'\n')
freeze={'frozen_at':datetime.now(timezone.utc).isoformat(),'owner':'/root/next268_current_bigg_completion','packet':str(P),'listed_files':len(files),'physical_files':len(files)+2,'listed_bytes':sum(x['bytes'] for x in files),'manifest_sha256':sha(P/'artifact-manifest.json'),'handoff_sha256':sha(P/'HANDOFF.md'),'review_sha256':sha(P/'REVIEW.md'),'all_jobs_terminal':True,'all_inputs_unchanged':True,'immutable_after_this_receipt':True}
(P/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps({**freeze,'freeze_sha256':sha(P/'freeze-proof.json')},indent=2))
