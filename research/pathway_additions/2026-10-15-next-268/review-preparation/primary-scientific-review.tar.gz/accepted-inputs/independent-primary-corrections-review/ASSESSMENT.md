# Independent primary-correction acceptance

All three corrections are accepted within the preparation scope. N268-P16 accurately separates the PaaI purification control, suspected E. coli D61A contamination and A. evansii D75A null activity. N268-P20 accurately separates the Table II Pz induction experiment from Table III Pa operator mutants, with their own strains, reporter constructs and PA-condition bounds. N268-P23 now treats indirect IHF action as an inference while preserving the negative PPAC/positive PR-PG control.

Original source evidence was freshly rechecked in the relevant text and five visual files. Exact prior complete-paper reading scopes are bound and reused, rather than represented as new whole-paper reading. Root confirmations corroborate the findings but are not the basis of independent acceptance.

Only P16/P20/P23 changed; all other28 entries are semantically identical. All52 original source paths, hashes, byte counts and source identifiers are unchanged; only the three locators are refined. The full exact field delta was independently reconstructed. The audited successor build() function reproduces the corrected ledger and delta byte-for-byte without running its write-bearing main block. The original historical generator remains unchanged and superseded for these fields.

All23 correction-source files,502 primary files and124 original-review files remained unchanged (649 total), with complete hidden/ignored-aware inventories before and after. All52 claim-source binding events were rechecked, including originals outside those packet directories. No new defect was found. Issues609–611 are remediation-accepted in preparation, but closure still requires correction/disposition retention in a verified merged tree. No GitHub action or maintained record change was performed.

This acceptance does not close other original scientific gaps, O02/O03, or maintained curation gates. The separately accepted SlyA2017 reading successor is not silently inserted into the historical31-claim correction ledger. Original and review packets remain immutable.
