from pathlib import Path
from xml.etree import ElementTree as ET
import json,hashlib,re
P=Path(__file__).resolve().parent;C=Path('/private/tmp/pathwaymech-next-268-chemistry');R=Path('/private/tmp/pathwaymech-next-268-independent-chemistry-review')
rows=json.loads((R/'all-native-and-context-reaction-dispositions.json').read_text());out=[]
for row in rows:
 expected=row['independent_replay'];path=C/expected['source'];body=path.read_bytes();assert hashlib.sha256(body).hexdigest()==expected['sha256']
 root=ET.fromstring(body);frame=expected['id'].split(':',1)[1];n=next(x for x in root if x.tag=='Reaction' and x.get('frameid')==frame and x.get('detail')=='full')
 sides={}
 for side in ['left','right']:
  sides[side]=[]
  for wrapper in n.findall(side):
   compound=wrapper.find('Compound');assert compound is not None
   coefficient=wrapper.findtext('coefficient');value=1 if coefficient is None else int(coefficient)
   assert compound.get('orgid')=='META';sides[side].append(['MetaCyc:'+compound.get('frameid'),value])
 assert sides==expected['source_sides'];assert n.findtext('reaction-direction')==expected['source_direction']
 out.append({'id':expected['id'],'source':str(path),'sha256':expected['sha256'],'source_sides':sides,'direction':n.findtext('reaction-direction'),'source_membership':expected['pathway_member'],'fresh_replayed':True})
materials=[]
for row in json.loads((R/'all25-material-review-dispositions.json').read_text()):
 src=Path(row['source']['path']);assert hashlib.sha256(src.read_bytes()).hexdigest()==row['source']['sha256']
 x=row['reviewed_identity'];formula=x['formula'];m=re.fullmatch(r'((?:[A-Z][a-z]?\d*)+)(?:[+-]\d*)?',formula);assert m,formula
 elements={a:int(b or 1) for a,b in re.findall(r'([A-Z][a-z]?)(\d*)',m.group(1))}
 materials.append({'id':row['id'],'elements':elements,'charge':x['charge'],'source':row['source'],'formula':formula,'assessment':row['assessment'],'status':'Exact formula/charge and stereochemical assessment reused from separately accepted chemistry; original bytes freshly rebound, not a fresh whole structure review.'})
(P/'fresh-native-equations.json').write_text(json.dumps(out,indent=2)+'\n');(P/'accepted-materials-rebound.json').write_text(json.dumps(materials,indent=2)+'\n');print(len(out),'native/context equations freshly replayed;',len(materials),'accepted formula/state materials rebound')
