from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
P=Path(__file__).resolve().parent;T=P/'target';W=Path('/private/tmp/pathwaymech-next-268-20261015')
def j(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,x):(P/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
start=j(P/'review-start.json');target=W/'data/pathways/phenylacetate-degradation-i-aerobic.yaml'
finding={'id':'N268-S01','issue':617,'severity':'minor','status':'open','title':'Contextual mechanism material edges cite a nonexistent native pathway layout','target':str(target),'target_sha256':sha(target),'coordinates':[{'mechanism':x['mechanism'],'edge':x['edge']} for x in j(P/'context-layout-locator-findings.json')['findings']],'observed':'Three cyclic-dead-end and five PaaY salvage material edges cite Pathway PWY0-321 / reaction-layout and assert orientation follows that layout. Complete source XML has exactly nine layouts and neither contextual reaction.','evidence':'context-layout-locator-findings.json; fresh-native-equations.json; all11-independent-material-replay.json','impact':'The actual equations, biological context and directions are supported. This is a non-blocking provenance defect, not incorrect pathway membership or chemistry.','action':'Change only these eight structured evidence assertions/locators to the actual Reaction left, right, reaction-direction slots. Both issuer Reaction objects say PHYSIOL-LEFT-TO-RIGHT. Preserve their contextual status, actual equations, author packet and original review.','acceptance':'Exact eight structured evidence edits, no unsupported PWY layout claim on these edges; XML source supports participant coefficients and direction; semantic validation and focused source-preservation test pass. Review a new maintained successor hash.'}
dump('findings.json',[finding])
rows=[]
for x in j(T/'claim-to-output-dispositions.json'):
 cid=x['claim_id'];native=cid.startswith('N268-B')
 rows.append({'claim_id':cid,'accepted_claim_preserved_exactly':True,'reviewed_output_coordinates':x['outputs'],'review_disposition':'structural preservation only; native scientific acceptance belongs to the pre-existing independent native review' if native else 'qualified placement accepted within the inspected experimental/source bounds','review_notes':x['successor_scope_notes'],'coverage_limit':'The source ledger retains the complete accepted claim and controls. Mapping is qualified narrative/mechanism placement or explicit deferral, not a claim that every source sentence is repeated in maintained YAML.'})
dump('all68-independent-placement-dispositions.json',rows)
dump('corrections609-611-reassessment.json',[
 {'issue':609,'claim':'N268-P16','outcome':'retained and accepted','target':'description paragraph 6; claim-to-output-dispositions N268-P16','source':'PaaI2006 PDF pages 2–3 Materials and Methods, page 7 Asp discussion; target/reading/PaaI2006.txt lines185–207 and580–592','assessment':'Separates E. coli D61A suspected host contamination from A. evansii D75A undetectable activity and the A. evansii before/after gel-filtration control. Does not claim chromatography demonstrated contamination in E. coli D61A. General-base versus covalent interpretation remains unresolved.'},
 {'issue':610,'claim':'N268-P20','outcome':'retained and accepted','target':'description paragraph 7; claim-to-output-dispositions N268-P20','source':'PaaX2000 PDF page4 TableII and page6 TableIII, inspected accepted extraction and original byte binding','assessment':'AF15PZ chromosomal Pz-lacZ ±1mM PA with PaaK induction is distinct from AF15 Pa-lacZ plasmid operator experiments. TableIII PA supplementation remains unreported; no shared induction-condition claim.'},
 {'issue':611,'claim':'N268-P23','outcome':'retained and accepted','target':'description paragraph 7; claim-to-output-dispositions N268-P23; pending proposals negative_claims_not_edges','source':'PaaX2004 Results In vitro analysis of CRP and IHF binding, Fig4B; original HTML freshly parsed and exact quote rebound','assessment':'Maintained description retains negative PPAC shift despite PR-PG positive control. Full claim ledger additionally retains indirect IHF effect as inference, not an established mechanism. No positive IHF→Ppac binding edge.'}])
limits=[
 'Reviewer authored the native intermediate draft and the authority integration. This review independently judges peer-authored primary additions/interpretations and checks native structural preservation only; it does not self-accept native science or authority implementation.',
 'Accepted source packets were reused only after unchanged-byte verification: 12 packets, 1,969 physical files including hidden/ignored. The frozen fragment packet independently binds all 144 physical files. This is not a new internet survey or complete rereading of every page of every original.',
 'All 33 proof quotations were checked literally after whitespace normalization against hash-bound accepted text, and HTML quotations were independently extracted from originals. PDF source originals were hash-rebound; accepted complete projections and cited passages were inspected. No PDF extraction runtime installation/repair was performed.',
 'Accepted chemistry identity/stereo/formula assessments were reused after original byte binding; new independent equation/element/charge replay is not a second complete constitutional/stereochemical source audit.',
 'Structured iModulonDB reconnaissance is reused from accepted primary evidence (10 commands across five datasets); no new source hunt was requested. Expression-module context is not direct catalysis or regulation proof.',
 'CHEM02 remains open: no exact issued isolated PaaJ C8→cis-3,4 reaction is asserted. Native E versus proposed Z oxepin and CCD LHQ constitution distinctions remain unresolved explicit conflicts. PaaG2019 main, full fusion bodies, and the four regulator endpoint originals remain declared limitations.',
 'Six regulator proposals stay outside the maintained positive edge set. PaaX W crude-preparation versus K-12 endpoint scope remains an explicit representation decision, despite full catalog endpoint originals.',
 'Root owns full-corpus QC/tests/lint, closed schema, authority implementation acceptance, generated page/KGX checks, history and canonical structured review persistence. This parent-directed temporary review is not a final whole-record/publication acceptance or a canonical saver bundle.'
]
dump('review.json',{'kind':'parent-directed-independent-scientific-fragment-review','started_at':start['started_at'],'finished_at':datetime.now(timezone.utc).isoformat(),'reviewer':start['reviewer'],'author':start['author'],'maintained_target':{'id':'MetaCyc:PWY0-321','path':str(target),'sha256':sha(target),'base':start['base']},'frozen_author_packet':{'path':'/private/tmp/pathwaymech-next-268-primary-curation-fragments','manifest_sha256':'05f62b301df1d8b6ebb56f2efb936d53377ee13dcd429e2e2d65f54824785793','physical_files':144},'verdict':'bounded scientific acceptance with one minor provenance correction required before final acceptance','findings':['N268-S01'],'checks':{'count':614,'passed':614,'known_provenance_defects':1,'bad_evidence_occurrences':8},'limitations':limits})
(P/'REVIEW.md').write_text('''# Independent primary-fragment scientific review

The released primary additions are scientifically supportable within their stated bounds. One minor provenance defect, **N268-S01 / issue 617**, must be corrected: eight nested contextual material edges cite a native pathway reaction-layout that does not contain those reactions. Their equations and direction are correct.

This review binds maintained `data/pathways/phenylacetate-degradation-i-aerobic.yaml` at SHA-256 `047837353de6c68109117d22a16ee09eaa4b7182bc4a03263ccd7334300fad97`, byte-identical to the released peer candidate. The reviewer authored the native draft and authority integration; native scientific content is not self-accepted here. Native preservation is checked structurally against the separately reviewed original.

## Checks and scientific assessment

- All 68 accepted claims are copied exactly into the claim ledger and have qualified placement or explicit deferral. This includes all three corrected claims (issues 609–611), six full-access SlyA claims and twelve full-access Nature 2012 claims. The ledger retains fuller source details than the maintained prose; mapping is not a claim that every experimental detail appears verbatim in YAML.
- Native identity/taxa, 40 original participants, nine source reactions and all 68 native edges are preserved semantically. The nine source reaction categories are explicitly enriched as molecular activities. No contextual salvage reaction is promoted to native pathway membership.
- All eleven detailed source equations match actual Reaction XML left/right coefficients and directions after explicit orientation. All twelve local material steps balance elements and charge. Cancellation reproduces the source net with exactly the two declared E-to-Z interpretation conflicts; C8 thiolysis and lower isomerization remain distinct inferred steps. No isolated PaaJ reaction identifier is invented.
- The upper isotope result remains oxygen from O2 rather than water. Magnesium is a cofactor, not a consumed term. The proposed iron cycle and upper tautomer mechanism remain hypotheses. Native and proposed oxepin stereoisomers are not aliases; the semialdehyde, lower cis-3,4 intermediate, 3-keto intermediate and probable S assignment retain appropriate inference limits.
- Y2 reconstruction, E. coli K-12 enzymes, native KB740 ligase, alternate ECH/PacL preparations and later structural constructs remain distinct. The 6JQL/M/N/O 688-residue PaaZ declared constructs were freshly checked against MGHHHHHH plus P77455 residues 2–681. Separate ASKA growth mutants are not represented as the structural construct. MBP/His preparations remain qualified and complete fusion bodies are not fabricated.
- PaaY activity and cyclic side chemistry are contextual salvage. PaaI uses its verified molecular activity endpoint without fabricating an unacquired reaction identity. Panel-bounded specificity, mass correction, temperatures, cofactor corrections, and main/SI wording discrepancies are retained. Proposed intracellular protection is not a measured cellular flux assertion.
- Regulatory statements retain negative controls and assay/strain scope. Six endpoint-limited proposals remain outside the maintained positive graph. Binding is not promoted into an unsupported universal promoter mechanism. The Ppac IHF result stays negative; SlyA paa-specific H-NS antagonism is not established; SrsR expression evidence is RT-qPCR rather than RNA-seq.
- All 33 proof quotations match the bound accepted extraction after whitespace normalization. Every promoted unique quote is covered. HTML quotation text was independently extracted from original bytes; complete PDF extraction/proof is reused after source identity binding. All 18 retained original copies, 16 primary reading projections, 27 added reference hashes, ten added canonical labels and every added evidence reference were checked.
- **614 deterministic checks passed**, including the existing repository `validate_record` function. These checks complement the scientific reading; they are not a replacement for it. The first HTML extraction attempt inserted spaces inside superscript/italic markup and produced six extraction-only misses; the preserved corrected parser respects inline text and all six match. No record change was needed for those misses.

## Required correction

For `primary-cyclic-deadend` edges consumes-1, produces-1, produces-2 and `primary-paay-salvage` edges consumes-1, consumes-2, produces-1, produces-2, produces-3, replace the structured source assertion and locator that mention PWY0-321 reaction-layout. Cite each actual Reaction `left`, `right`, and `reaction-direction` instead. Both source Reaction objects specify `PHYSIOL-LEFT-TO-RIGHT`. Preserve all coefficients, directions, statuses and contextual membership. `findings.json` and `context-layout-locator-findings.json` provide exact coordinates and source proof.

## Limits and next acceptance

'''+''.join('- '+x+'\n' for x in limits)+'''\nRoot should make a maintained successor, preserve this review and the frozen author packet, and request a narrow successor check of the eight edits plus affected source/semantic checks. No other primary-science change is requested by this bounded review.
''')
(P/'HANDOFF.md').write_text('''Frozen independent review of the released primary fragments and byte-identical maintained record. Read `REVIEW.md`, `review.json`, `findings.json`, and `corrections609-611-reassessment.json` first.

One minor required fix: N268-S01 / issue 617, eight contextual material-edge source assertions/locators. All equations and biological scopes remain supportable; 614 independent checks pass. All 68 accepted claims and corrections 609–611 retained. Reviewer authored native/authority work and only checks its structural preservation here.

Replay (existing runtime, no installs):
```
/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B replay_native_equations.py
/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B independent_replay.py
/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B final_checks.py
```
These commands write into their current review-owner directory; reproduce in a new copy after freeze. Root owns the maintained successor and full publication gates. No maintained, Git, GitHub, runtime or original packet edits were performed by this review.
''')
print('wrote focused review and all68 dispositions')
