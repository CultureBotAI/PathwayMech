from pathlib import Path
import base64,copy,hashlib,json,sys,itertools,collections
from xml.etree import ElementTree as ET
O=Path(__file__).parent;B=Path('/private/tmp/pathwaymech-next-268-independent-native-authority-implementation-review');A=Path('/private/tmp/pathwaymech-next-268-native-authority-integration')
sys.path[:0]=[str(O/'isolated/src'),str(O/'isolated')]
from pathwaymech.biocyc_phenylacetate import FIELD,_NATIVE_OBJECT_TAGS,document,validate_phenylacetate_metadata,phenylacetate_metadata
from pathwaymech.identifiers import _load_authority
from scripts.build_source_identifier_snapshot import build_snapshot
S=json.loads((A/'new-native-snapshot.json').read_text());examples={};counts=collections.Counter()
for key,meta in S['sources'].items():
 r=ET.fromstring(base64.b64decode(meta[FIELD]['original_base64']));e=r[1]
 for node in e.iter():
  if set(node.attrib)&{'ID','orgid','frameid','resource'}:
   counts[node.tag]+=1
   if node is not e:examples.setdefault(node.tag,(key,copy.deepcopy(meta)))
assert set(counts)==_NATIVE_OBJECT_TAGS==set(examples)
results=[]
attrs=['frameid','orgid','ID','resource']
for tag,(key,meta) in sorted(examples.items()):
 for keep in itertools.chain.from_iterable(itertools.combinations(attrs,n)for n in range(5)):
  # These are complete locator forms, not the incomplete-identity attack surface.
  if set(keep) in ({'frameid','orgid','ID'},{'frameid','orgid','resource'}):continue
  r=ET.fromstring(base64.b64decode(meta[FIELD]['original_base64']));node=next(n for n in r[1].iter(tag)if n is not r[1]);native=node.get('orgid')+':'+node.get('frameid');allvals={'frameid':node.get('frameid'),'orgid':node.get('orgid'),'ID':native,'resource':'getxml?'+native}
  for a in attrs:node.attrib.pop(a,None)
  node.attrib.update({a:allvals[a]for a in keep});body=ET.tostring(r,encoding='utf-8',xml_declaration=True);mut=copy.deepcopy(meta);mut['sha256']=hashlib.sha256(body).hexdigest();n=mut[FIELD];n['original_base64']=base64.b64encode(body).decode('ascii');n['root_attributes']=dict(r.attrib);n['metadata_xml']=ET.tostring(r.find('metadata'),encoding='unicode');n['projection']['slots']=[{'ordinal':i,'name':s.tag,'xml':ET.tostring(s,encoding='unicode')}for i,s in enumerate(r[1],1)]
  source={k:mut[k]for k in ['license','url','version','sha256']};rec={'tag':tag,'kept_identity_attributes':list(keep)}
  for boundary,func in [('document',lambda:document(body,source,mut['kind'])),('consumer_reparse',lambda:validate_phenylacetate_metadata(mut))]:
   try:func();raise AssertionError('Unexpected accepted malformed identity '+tag+str(keep))
   except ValueError as exc:
    assert 'incomplete or ambiguous embedded native identity'in str(exc);rec[boundary]=str(exc)
  results.append(rec)
(O/'all-subset-adversarial-results.json').write_text(json.dumps({'native_tags':counts,'case_count':len(results),'boundaries_per_case':2,'rejections':2*len(results),'cases':results},indent=2)+'\n')
full=[]
for dirname in ['probe-missing_frameid','probe-missing_frameid_and_wrong_resource','probe-all_identity_attributes_removed']:
 d=B/dirname;entry=json.loads((d/'manifest.json').read_text())[0];r={'case':dirname}
 for boundary,func in [('producer',lambda:phenylacetate_metadata(entry,d)),('builder',lambda:build_snapshot(d/'manifest.json',d/'records',d)),('consumer',lambda:_load_authority(d/'authority.json'))]:
  try:func();raise AssertionError('Original bypass still accepted '+dirname)
  except ValueError as exc:assert 'incomplete or ambiguous embedded native identity'in str(exc);r[boundary]={'rejected':True,'error':str(exc)}
 full.append(r)
(O/'original-bypasses-replay.json').write_text(json.dumps(full,indent=2)+'\n')
# Verify A02 remains an explicit separate open finding at this cutoff.
a02=[]
for style,accepted in [('canonical_id',False),('native_legacy',True)]:
 d=B/('request-probe-'+style);r={'case':style}
 for boundary,func in [('builder',lambda:build_snapshot(d/'manifest.json',d/'records',d)),('consumer',lambda:_load_authority(d/'authority.json'))]:
  try:func();ok=True;error=None
  except ValueError as exc:ok=False;error=str(exc)
  assert ok==accepted;r[boundary]={'accepted':ok,'error':error}
 a02.append(r)
(O/'A02-not-closed.json').write_text(json.dumps(a02,indent=2)+'\n')
print(json.dumps({'native_tag_count':len(counts),'native_identity_count':sum(counts.values()),'subset_cases':len(results),'subset_semantic_rejections':2*len(results),'full_original_bypass_rejections':9,'A02_remains_open':True}))
