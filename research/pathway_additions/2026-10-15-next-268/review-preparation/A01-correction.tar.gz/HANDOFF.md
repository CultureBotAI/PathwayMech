# A01 / issue 615: reject incomplete embedded native identities

Status: frozen correction for independent acceptance. Only `src/pathwaymech/biocyc_phenylacetate.py` and `tests/test_phenylacetate_authority.py` were changed in the actual268 worktree. Source snapshots, original XML fixtures, manifests, documentation, primary record, Git/GitHub and installed runtime were not changed by this task. All local test processes are terminal. A02 request-alias handling is a separate pending task and was not modified here.

The previous `_envelope` loop skipped every element without `frameid`, allowing a recognizable embedded native object to lose its identity entirely or retain a contradictory foreign resource. The corrected guard recognizes all 19 native object tags found in the 65 reviewed originals, even after every identity attribute is removed. Any other element carrying `frameid`, `orgid`, `ID` or `resource` also receives the identity checks. A complete identity requires nonempty frame and database identifiers plus exactly one of `ID` or `resource`; existing database/frame and locator consistency checks then apply. CML elements and scalar slots without native identity attributes are unaffected. The separate metadata PGDB validation remains intact outside the entity-tree loop.

`original65-identity-inventory.json` independently records all genuine fixture body hashes, 19 object tags and 15,604 identities: 1,457 with ID/frameid/orgid and 14,147 with resource/frameid/orgid. No genuine identity was partial or ambiguous. All 65 original bodies and their compressed fixture bytes remain unchanged.

The new regressions exercise producer and consumer boundaries, including:

- missing frame, database, locator or all identity attributes across all 19 object types;
- the reproduced AMP parent/Compound missing frame plus `getxml?ECOLI:WRONG` with META orgid;
- complete attribute removal and simultaneous ID/resource ambiguity;
- incomplete native identity attributes on an otherwise uninterpreted tag;
- the separate metadata PGDB guard.

Consumer cases recalculate the altered body's SHA and base64 and coherently update retained root/metadata/slot projections. They reject for the semantic identity guard, not an incidental stale hash or projection mismatch. Six focused producer/consumer regressions were run **before** the adapter change and all failed because the malformed documents were accepted; their output is retained as the expected red baseline.

Final verification:

- `354 passed` in the complete targeted phenylacetate suite, including all 65 genuine original round-trips.
- `1,897 passed` in relevant source-snapshot, identifier, EcoCyc, carrier, P321 and nitrate regressions.
- Total final passing tests: **2,251**. This does not claim unrelated corpus/rendering/KGX gates or independent scientific acceptance.

The first broader regression command omitted `PYTHONPATH` for the isolated runtime: 1,890 tests passed and seven CLI/subprocess tests failed with `ModuleNotFoundError: pathwaymech`. That failed command and stderr/stdout are preserved. The complete same scope passed after setting `PYTHONPATH=/private/tmp/pathwaymech-next-268-20261015/src`; no installation or runtime repair was performed. `validation-results.json` records both attempts and exact commands.

The before/after copies and two unified diffs are in this packet. `change-bindings.json` binds the exact maintained result:

- adapter SHA `af23c0924c0ca6f426dd2527255b6beddb2ac253366b7a6096f899710cbb47c6`
- tests SHA `8ce3785719cf9993a64ff06913d65fa47c4edd66f54f334fdaedc3e5e06a1b1c`

The independent review's original two accepted-bypass probes are copied read-only under `before/embedded-identity-probes.json`. Earlier author/reviewer packets remain untouched. This correction is ready for reviewer replay; it does not close issue 615 or self-accept its own change.
