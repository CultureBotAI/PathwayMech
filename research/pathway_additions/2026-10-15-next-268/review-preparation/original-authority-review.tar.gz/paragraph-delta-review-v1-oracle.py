from pathlib import Path
import ast,hashlib,html,json,re,sys
from types import SimpleNamespace
O=Path(__file__).parent;old=Path('/private/tmp/pathwaymech-next-268-independent-core-implementation-review/inputs/src/pathwaymech/cli.py');new=O/'isolated/src/pathwaymech/cli.py'
sys.path[:0]=[str(O/'isolated/src'),str(O/'isolated')]
from pathwaymech.cli import _record_page
from html.parser import HTMLParser
class Reader(HTMLParser):
 def __init__(self):super().__init__();self.ps=[];self.in_p=False;self.tags=[]
 def handle_starttag(self,t,a):
  self.tags.append(t)
  if t=='p':self.in_p=True;self.ps.append('')
 def handle_endtag(self,t):
  if t=='p':self.in_p=False
 def handle_data(self,s):
  if self.in_p:self.ps[-1]+=s
base={'id':'MetaCyc:SYNTHETIC','label':'Synthetic description only','pathway_type':'test','taxa':[],'participants':[],'reactions':[],'mechanistic_edges':[],'references':[],'gene_clusters':[],'reaction_mechanisms':[],'detail_only_participant_ids':[]}
cases=[('blank-line','First paragraph\n\nSecond paragraph',['First paragraph','Second paragraph']),('spaced-blank','First\n \t\nSecond',['First','Second']),('crlf','First\r\n\r\nSecond',['First','Second']),('single-newline','First\ncontinued',['First\ncontinued']),('escape','<script>alert(1)</script> & next\n\n"quoted"',['<script>alert(1)</script> & next','"quoted"'])]
results=[]
for key,description,expected in cases:
 record=SimpleNamespace(**base,description=description);page=_record_page(record);parser=Reader();parser.feed(page)
 assert parser.ps[1:1+len(expected)]==expected,(key,parser.ps)
 assert 'script' not in parser.tags or key!='escape'
 if key=='escape':assert '<script>alert(1)</script>' not in page
 (O/('paragraph-'+key+'.html')).write_text(page)
 results.append({'case':key,'expected_description_paragraphs':expected,'actual_description_paragraphs':parser.ps[1:1+len(expected)],'passed':True})
# _record_page changed only its description expression from prior independent core binding.
def function_text(path,name):
 s=path.read_text();t=ast.parse(s);n=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name==name);return '\n'.join(s.splitlines()[n.lineno-1:n.end_lineno])
a=function_text(old,'_record_page');b=function_text(new,'_record_page')
import difflib
(O/'root-paragraph-function.diff').write_text('\n'.join(difflib.unified_diff(a.splitlines(),b.splitlines(),fromfile=str(old),tofile=str(new)))+'\n')
(O/'paragraph-delta-review.json').write_text(json.dumps({'scope':'Root-authored paragraph split only; not a self-review of existing renderer','prior_cli_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'reviewed_cli_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'cases':results},indent=2)+'\n')
print('paragraph cases',len(results))
