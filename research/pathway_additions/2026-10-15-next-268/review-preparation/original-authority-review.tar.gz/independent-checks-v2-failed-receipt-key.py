from pathlib import Path
import base64, collections, copy, gzip, hashlib, html, json, re, shutil, sqlite3, sys, time
from xml.etree import ElementTree as ET
OUT=Path(__file__).parent
W=Path('/private/tmp/pathwaymech-next-268-20261015')
P=Path('/private/tmp/pathwaymech-next-268-native-authority-integration')
def save(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
if sys.argv[1]=='stage':
    isolated=OUT/'isolated'
    isolated.mkdir(exist_ok=False)
    for directory in ('src','scripts'):
        shutil.copytree(W/directory,isolated/directory,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    copied=[]
    for p in isolated.rglob('*'):
        if p.is_file():
            original=W/p.relative_to(isolated)
            assert sha(p)==sha(original)
            copied.append({'source':str(original),'copy':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
    save('isolated-code-bindings.json',copied)
    save('regression-test-result.json',{'command':'pytest -p no:cacheprovider tests/test_p321_authority.py tests/test_typed_authority_consumer_integrity.py tests/test_source_identifier_snapshot.py tests/test_identifiers.py tests/test_phenylacetate_authority.py -q --tb=short','result':'836 passed in 32.85s','exit_code':0,'tool_session':64341})
    print('isolated',len(copied)); sys.exit()
sys.path[:0]=[str(OUT/'isolated/src'),str(OUT/'isolated')]
from pathwaymech.biocyc_phenylacetate import FIELD,PROFILES,phenylacetate_metadata,phenylacetate_term,validate_phenylacetate_assertions
from pathwaymech.identifiers import _load_authority
from scripts.build_source_identifier_snapshot import build_snapshot
if sys.argv[1]=='probes':
    rows=json.loads((P/'new-source-manifest.json').read_text()); amp=next(x for x in rows if x['url'].endswith('META:AMP'))
    results=[]
    for probe in json.loads((OUT/'embedded-identity-probes.json').read_text()):
        dest=OUT/('probe-'+probe['case']);dest.mkdir(exist_ok=False)
        entry=copy.deepcopy(amp);entry['sha256']=probe['source']['sha256'];entry['path']='mutant.xml'
        shutil.copyfile(OUT/probe['input'],dest/'mutant.xml')
        meta=phenylacetate_metadata(entry,dest)
        ident,term=phenylacetate_term(meta,entry['key'])
        value={'version':1,'sources':{entry['key']:meta},'terms':{ident:term}}
        (dest/'authority.json').write_text(json.dumps(value,indent=2)+'\n')
        consumed=_load_authority(dest/'authority.json');assert consumed==value['terms']
        (dest/'manifest.json').write_text(json.dumps([entry],indent=2)+'\n')
        (dest/'records').mkdir();(dest/'records/selection.yaml').write_text('id: MetaCyc:AMP\n')
        built=build_snapshot(dest/'manifest.json',dest/'records',dest)
        assert built==value
        results.append({'case':probe['case'],'metadata_producer_accepted':True,'full_builder_accepted':True,'full_consumer_accepted':True,'authority':str(dest/'authority.json'),'mutant_sha256':sha(dest/'mutant.xml')})
    save('A01-full-path-reproduction.json',results);print(json.dumps(results,indent=2));sys.exit()
if sys.argv[1]=='native':
    owner=W/'research/pathway_additions/2026-10-15-next-268/authority-source-originals'
    rows=json.loads((owner/'source-provenance.json').read_text());snapshot=json.loads((P/'new-native-snapshot.json').read_text())
    fixture=W/'tests/fixtures/phenylacetate_authority';storage=json.loads((fixture/'storage.json').read_text())
    cache=OUT/'clean-native';cache.mkdir(exist_ok=False);entries=[];audit=[];patterns=collections.Counter()
    def label(s): return ' '.join(html.unescape(re.sub(r'</?(?:b|i|em|strong|sub|sup)>','',s,flags=re.I)).split())
    for row in rows:
        entry=row['manifest_entry'];body=(W/row['maintained_original']).read_bytes();assert sha(W/row['maintained_original'])==entry['sha256']==row['sha256']
        target=cache/entry['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body);entries.append(entry)
        raw=ET.fromstring(body);entity=raw[1];ident=row['id'];native=snapshot['sources'][entry['key']][FIELD];term=snapshot['terms'][ident]
        assert base64.b64decode(native['original_base64'])==body
        assert entity.tag==row['tag']==PROFILES[ident]['tag'];assert dict(collections.Counter(n.tag for n in entity))==row['slots']==PROFILES[ident]['slots']
        name=entity.find('common-name');canonical=label(name.text) if name is not None else entity.get('frameid')
        aliases=sorted({label(n.text) for n in entity.findall('synonym')}-{canonical})
        assert term['label']==canonical and term['synonyms']==aliases
        assert term['label_kind']==('canonical' if name is not None else 'source_context')
        assert [(x['name'],x['xml']) for x in native['projection']['slots']]==[(n.tag,ET.tostring(n,encoding='unicode')) for n in entity]
        stored=storage[entry['path']];packed=(fixture/stored['path']).read_bytes();assert hashlib.sha256(packed).hexdigest()==stored['compressed_sha256'];assert gzip.decompress(packed)==body
        receipts=list(owner.glob(Path(row['maintained_original']).name+'*.json'));assert len(receipts)==1
        receipt=json.loads(receipts[0].read_text())
        assert receipt['sha256']==entry['sha256'] and receipt['bytes']==len(body)
        assert receipt['requested_url']==entry['url'] and receipt['status']==200
        identities=0
        for n in entity.iter():
            if set(n.attrib)&{'ID','resource','orgid','frameid'}:
                identities+=1;patterns[tuple(sorted(n.attrib))]+=1
                assert n.get('frameid') and n.get('orgid')==entity.get('orgid')
                identstr=n.get('orgid')+':'+n.get('frameid')
                assert 'ID' not in n.attrib or n.get('ID')==identstr
                assert 'resource' not in n.attrib or n.get('resource') in {'getxml?'+identstr,'#'+identstr}
        audit.append({'id':ident,'source_sha256':entry['sha256'],'label':canonical,'synonyms':aliases,'label_kind':term['label_kind'],'entity_type':term['entity_type'],'tag':entity.tag,'slots':row['slots'],'embedded_identity_count':identities,'receipt':str(receipts[0]),'receipt_keys':list(receipt),'complete_bytes_in_snapshot_and_fixture':True})
    (cache/'manifest.json').write_text(json.dumps(entries,indent=2)+'\n');(cache/'selection').mkdir();(cache/'selection/all.yaml').write_text(json.dumps({'id':rows[0]['id'],'participants':[{'id':r['id']} for r in rows[1:]]},indent=2)+'\n')
    built=build_snapshot(cache/'manifest.json',cache/'selection',cache)
    (OUT/'independently-rebuilt-native.json').write_text(json.dumps(built,indent=2,sort_keys=True)+'\n')
    assert built==snapshot
    save('all-65-original-audit.json',audit);save('embedded-attribute-inventory.json',[{'attributes':k,'count':v}for k,v in patterns.items()]);save('native-reproduction.json',{'ids':len(rows),'complete_original_bytes':sum((W/r['maintained_original']).stat().st_size for r in rows),'semantic_exact':True,'serialized_sha':sha(OUT/'independently-rebuilt-native.json'),'author_sha':sha(P/'new-native-snapshot.json'),'byte_exact':(OUT/'independently-rebuilt-native.json').read_bytes()==(P/'new-native-snapshot.json').read_bytes()})
    print('native passed',len(rows));sys.exit()
if sys.argv[1]=='ontology':
    from scripts.build_ontology_identifier_snapshot import read_source,extract_terms
    after=json.loads((P/'candidate-ontology.json').read_text());results=[]
    for name,ids,key in [('ncbitaxon',['NCBITaxon:134536','NCBITaxon:198931','NCBITaxon:566546'],'ncbitaxon-2026-07-12'),('chebi',['CHEBI:63252'],'chebi-255')]:
        path=Path('/private/tmp/pathwaymech-curation-authorities')/(name+'.db');start=time.monotonic()
        with sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True) as con:
            source=read_source(con,path);assert source==after['sources'][key]
            terms,missing=extract_terms(con,ids,key);assert not missing
            assert terms=={i:after['terms'][i] for i in ids}
        results.append({'path':str(path),'bytes':path.stat().st_size,'source':source,'terms':terms,'missing':missing,'elapsed_seconds':time.monotonic()-start,'whole_file_hash_fresh':True,'read_only_sql':True})
        print(name,'passed',flush=True)
    save('ontology-reproduction.json',results);sys.exit()
