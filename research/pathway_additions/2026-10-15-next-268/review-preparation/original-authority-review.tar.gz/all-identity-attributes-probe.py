"""Reproduce third A01 variant in a NEW directory passed as argv[1]."""
from pathlib import Path
import hashlib,json,sys
from xml.etree import ElementTree as ET
O=Path(__file__).parent;P=Path('/private/tmp/pathwaymech-next-268-native-authority-integration')
sys.path[:0]=[str(O/'isolated/src'),str(O/'isolated')]
from pathwaymech.biocyc_phenylacetate import phenylacetate_metadata,phenylacetate_term
from pathwaymech.identifiers import _load_authority
from scripts.build_source_identifier_snapshot import build_snapshot
d=Path(sys.argv[1]);d.mkdir(exist_ok=False)
e=next(x for x in json.loads((P/'new-source-manifest.json').read_text())if x['url'].endswith('META:AMP'))
r=ET.fromstring((P/'source-cache'/e['path']).read_bytes());r.find('Compound/parent/Compound').attrib.clear()
b=ET.tostring(r,encoding='utf-8',xml_declaration=True);(d/'mutant.xml').write_bytes(b);e={**e,'path':'mutant.xml','sha256':hashlib.sha256(b).hexdigest()}
m=phenylacetate_metadata(e,d);i,t=phenylacetate_term(m,e['key']);v={'version':1,'sources':{e['key']:m},'terms':{i:t}}
(d/'authority.json').write_text(json.dumps(v,indent=2)+'\n');assert _load_authority(d/'authority.json')==v['terms']
(d/'records').mkdir();(d/'records/one.yaml').write_text('id: MetaCyc:AMP\n');(d/'manifest.json').write_text(json.dumps([e],indent=2)+'\n');assert build_snapshot(d/'manifest.json',d/'records',d)==v
print(json.dumps({'accepted_by_full_builder_and_consumer':True,'mutant_sha256':e['sha256']}))
