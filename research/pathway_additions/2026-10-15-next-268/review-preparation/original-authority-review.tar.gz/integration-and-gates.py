from pathlib import Path
import copy,hashlib,json,shutil,sys,time
O=Path(__file__).parent;P=Path('/private/tmp/pathwaymech-next-268-native-authority-integration');W=Path('/private/tmp/pathwaymech-next-268-20261015')
sys.path[:0]=[str(O/'isolated/src'),str(O/'isolated')]
from pathwaymech.identifiers import _load_authority,identifier_errors
J=lambda p:json.loads(p.read_text())
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=J(P/'before/data/identifier_authorities/sources.json');new=J(P/'new-native-snapshot.json');after=J(P/'candidate-sources.json');expected=copy.deepcopy(old)
checks={}
for field in ['sources','terms']:
 assert not old[field].keys()&new[field].keys()
 expected[field].update(dict(sorted(new[field].items())))
 assert list(after[field])==list(expected[field])
 assert all(after[field][k]==v for k,v in old[field].items())
 checks[field]={'before':len(old[field]),'added':len(new[field]),'after':len(after[field]),'prior_content_exact':True,'prior_order_exact':True}
assert expected==after
assert (json.dumps(expected,indent=2,ensure_ascii=False)+'\n').encode()==(P/'candidate-sources.json').read_bytes()
oldmanifest=J(P/'before/conf/identifier_sources.json');newmanifest=J(P/'new-source-manifest.json');manifest=J(P/'candidate-identifier-sources.json');assert manifest==oldmanifest+newmanifest
assert (json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode()==(P/'candidate-identifier-sources.json').read_bytes()
oldonto=J(P/'before/data/identifier_authorities/ontology.json');onto=J(P/'candidate-ontology.json');added={'NCBITaxon:134536','NCBITaxon:198931','NCBITaxon:566546','CHEBI:63252'}
assert onto['sources']==oldonto['sources'];assert set(onto['terms'])-set(oldonto['terms'])==added;assert all(onto['terms'][k]==v for k,v in oldonto['terms'].items());assert list(onto['terms'])==list(oldonto['terms'])+sorted(added)
assert _load_authority(P/'candidate-sources.json')==after['terms'];assert _load_authority(P/'candidate-ontology.json')==onto['terms']
save('additive-reproduction.json',{'source_checks':checks,'old_manifest_entries_exact':True,'new_manifest_entries':len(newmanifest),'manifest_bytes_exact':True,'source_snapshot_bytes_exact':True,'old_ontology_terms_sources_order_exact':True,'ontology_added_ids':sorted(added),'whole_consumers_pass':True})
# Copy only the existing 264-record corpus. Candidate268 is separately owned and excluded.
gate=O/'existing-264-gate';gate.mkdir();(gate/'data/pathways').mkdir(parents=True);(gate/'data/identifier_authorities').mkdir();(gate/'conf').mkdir()
bindings=[]
for p in sorted((W/'data/pathways').rglob('*.yaml')):
 if p.name=='phenylacetate-degradation-i-aerobic.yaml':continue
 target=gate/p.relative_to(W);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);bindings.append({'source':str(p),'copy':str(target),'sha256':h(p)})
assert len(bindings)==264
shutil.copyfile(W/'conf/identifier_policy.yaml',gate/'conf/identifier_policy.yaml')
for name in ['sources','ontology']:shutil.copyfile(P/('candidate-'+name+'.json'),gate/('data/identifier_authorities/'+name+'.json'))
# All authority snapshots referred to by unchanged policy must be available.
import yaml
policy=yaml.safe_load((gate/'conf/identifier_policy.yaml').read_text())
for row in policy['namespaces'].values():
 target=gate/row['snapshot']
 if not target.exists():target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/row['snapshot'],target)
save('existing-record-bindings.json',bindings)
start=time.monotonic();errors=identifier_errors(gate);save('existing-264-independent-gate.json',{'record_count':264,'errors':errors,'elapsed_seconds':time.monotonic()-start,'excluded_current_candidate':'data/pathways/phenylacetate-degradation-i-aerobic.yaml'});assert not errors;print('264 gate pass',flush=True)
native=O/'native-66-gate';shutil.copytree(P/'native-integration-gate',native);start=time.monotonic();errors=identifier_errors(native);save('native-independent-gate.json',{'errors':errors,'elapsed_seconds':time.monotonic()-start,'input':'author frozen isolated gate; native reaction category adjustment retained'});assert not errors;print('native gate pass',flush=True)
