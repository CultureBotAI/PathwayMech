"""Create the bounded successor without mutating frozen primary or review inputs."""
from pathlib import Path
import copy
import datetime
import hashlib
import json

ROOT = Path('/private/tmp/pathwaymech-next-268-primary-corrections')
AUTHOR = Path('/private/tmp/pathwaymech-next-268-primary')
REVIEW = Path('/private/tmp/pathwaymech-next-268-independent-primary-review')
CI = Path('/private/tmp/pathwaymech-next-268-ci')


def digest(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def verify_package(root, expected_manifest):
    manifest_path = root / 'artifact-manifest.json'
    assert digest(manifest_path)['sha256'] == expected_manifest
    manifest = json.loads(manifest_path.read_bytes())
    rows = manifest['files']
    names = set()
    for row in rows:
        path = Path(row['path'])
        if not path.is_absolute():
            path = root / path
        assert path.is_relative_to(root)
        names.add(str(path.relative_to(root)))
        actual = digest(path)
        assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
    physical = {str(path.relative_to(root)) for path in root.rglob('*') if path.is_file()}
    assert physical == names | {'artifact-manifest.json', 'freeze-proof.json'}
    return {'root': str(root), 'manifest': digest(manifest_path), 'physical_files': len(physical),
            'hidden_ignored_included': True}


def build():
    raw = (AUTHOR / 'primary-claim-ledger.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == '03d3703207e57387190387a2f1d0684c4de461a82b3bcd1a22b20664929c2933'
    before = json.loads(raw)
    after = copy.deepcopy(before)
    claims = {claim['id']: claim for claim in after}
    claims['N268-P16']['controls'] = (
        'A. evansii mutant activities were identical before and after gel filtration. '
        'Residual E. coli D61A activity was suspected to reflect host PaaI contamination; '
        'A. evansii D75A had no detectable activity. These are separate observations, '
        'not an activity-disappearance experiment.')
    claims['N268-P16']['sources'][0]['locator'] = (
        'PDF p3/journal11030 purification control; p7/journal11034 catalytic-site Results; '
        'Tables1-2 on PDF pp4-5; broader mechanism Tables1-3/Figs3-6')

    p20 = claims['N268-P20']
    p20['statement'] = (
        'Separate reporter experiments support operator-dependent PaaX repression at Pa '
        'and PaaK-dependent phenylacetate induction at Pz.')
    p20['experiment'] = 'Two separately scoped reporter experiments, with distinct strains and constructs.'
    p20['taxon_strain'] = (
        'Table II: E. coli AF15PZ, the AF15 derivative with chromosomal Pz-lacZ. '
        'Table III: E. coli AF15 with Pa-lacZ reporter plasmids.')
    p20['construct_preparation'] = (
        'Table II: pAFX2 with or without pAFK5, plus vector/ligase controls; '
        'M63 glycerol with or without 1 mM PA, A600 1.0 (minimal-medium Methods: 30 C). '
        'Table III: pAFPA2 or pAFPA2-M reporters with pAFX2 versus pCK01; '
        'glycerol minimal medium, 30 C, A600 1.0. PA induction is not stated for Table III.')
    p20['controls'] = (
        'Table II: Pz-lacZ induction requires both the ligase construct and added PA '
        'when PaaX is present. Table III only: WT Pa repression 30.4-fold; '
        'PaM1/PaM5/PaM9/PaM16 repression 1.1/4.3/1.8/4.7-fold, respectively; '
        'matched reporters without PaaX establish baseline activities.')
    p20['experimental_contexts'] = [
        {'id': 'P20-Table-II', 'type': 'Pz effector induction', 'strain': 'AF15PZ',
         'reporter': 'chromosomal Pz-lacZ', 'plasmids': 'pAFX2 +/- pAFK5; pUC19 and pAFK5 controls',
         'PA': '0 or 1 mM', 'source_locator': 'Table II, PDF p4/journal12217; Methods pp2-3'},
        {'id': 'P20-Table-III', 'type': 'Pa operator mutagenesis', 'strain': 'AF15',
         'reporter': 'pAFPA2 and pAFPA2-M Pa-lacZ plasmids',
         'plasmids': 'reporter plus pAFX2 versus pCK01', 'PA': 'not stated for this experiment',
         'source_locator': 'Table III, PDF p6/journal12219; Table I p2; Figure5'}]
    p20['sources'][0]['locator'] = (
        'Table I PDF p2/journal12215; Table II PDF p4/journal12217; '
        'Table III and Figure5 PDF p6/journal12219; reporter Methods PDF pp2-3')

    p23 = claims['N268-P23']
    p23['statement'] = (
        'At Ppac, CRP/cAMP binding is direct in the tested assays. No IHF shift was '
        'detected under the tested conditions; an indirect IHF effect is inferred, not established.')
    p23['controls'] = (
        'IHF at 100-300 nM did not shift the 1 nM PPAC probe but shifted the '
        '1 nM PR-PG positive-control probe; CRP formed two complexes.')
    p23['sources'][0]['locator'] = (
        'In vitro analysis of CRP and IHF binding to the Ppac promoter; '
        'Figure4B/caption and following paragraph; exact text projection lines98-99')

    expected = {'N268-P16', 'N268-P20', 'N268-P23'}
    for claim in after:
        if claim['id'] in expected:
            claim['disposition'] = 'Corrected author successor; independent acceptance pending.'
    changed = []
    for old, new in zip(before, after, strict=True):
        assert old['id'] == new['id']
        if old != new:
            changed.append({'id': old['id'], 'changed_fields': sorted(
                key for key in old.keys() | new.keys() if old.get(key) != new.get(key)),
                'before': old, 'after': new})
    assert {row['id'] for row in changed} == expected
    assert len(before) == len(after) == 31
    return raw, after, changed


if __name__ == '__main__':
    output = ROOT / 'primary-claim-ledger.corrected.json'
    assert not output.exists(), 'Do not overwrite a produced successor.'
    package_specs = [
        (AUTHOR, 'e8ff939c1f2e6eb77d651445efd248932dd80201d2e491a855af14b3d8a7f0f6'),
        (REVIEW, '39296913278720a6687f2383aed312cb22e67cfa8c1151964e7d7b4c2460aea4')]
    before_checks = [verify_package(*spec) for spec in package_specs]
    raw, corrected, changed = build()
    (ROOT / 'primary-claim-ledger.original.json').write_bytes(raw)
    output.write_text(json.dumps(corrected, indent=2) + '\n')
    (ROOT / 'exact-field-changes.json').write_text(json.dumps(changed, indent=2) + '\n')
    after_checks = [verify_package(*spec) for spec in package_specs]
    assert before_checks == after_checks
    sources = []
    for claim in corrected:
        for source in claim['sources']:
            actual = digest(Path(source['path']))
            assert actual['bytes'] == source['bytes'] and actual['sha256'] == source['sha256']
            sources.append(actual)
    receipt = {
        'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'before_packages': before_checks, 'after_packages': after_checks,
        'claims_total': 31, 'claims_changed': [row['id'] for row in changed],
        'claims_unchanged': 28, 'source_binding_events_verified': len(sources),
        'source_bindings': sources, 'output': digest(output),
        'historical_builder': digest(AUTHOR / 'build_dossier.py'),
        'historical_builder_disposition': 'Immutable historical generator; this successor is authoritative for corrected claims. Do not regenerate and accept the historical defective claims.',
        'semantic_acceptance': 'Pending independent review; these are preservation/reproduction checks.'}
    (ROOT / 'correction-verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k not in {'source_bindings'}}))
