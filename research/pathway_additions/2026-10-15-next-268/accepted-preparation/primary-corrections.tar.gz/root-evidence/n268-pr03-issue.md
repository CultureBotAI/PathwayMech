Independent primary-source review found this defect in the phenylacetate degradation I (`MetaCyc:PWY0-321`) research preparation. No maintained pathway record has been authored from this claim yet.

Stable finding: `N268-PR03`; severity: low; claim: `N268-P23`.

Affected artifact: frozen `next-268-primary/primary-claim-ledger.json` (SHA-256 `03d3703207e57387190387a2f1d0684c4de461a82b3bcd1a22b20664929c2933`). The historical `build_dossier.py` contains the same wording and must remain an explicitly superseded snapshot.

Primary source: https://doi.org/10.1128/JB.186.7.2215-2220.2004 (retained SHA-256 `44c5b45fb5c6b1a43f5668d4abf1f8a780a1678b7e9036cf933d192b36a049e7`).

- Original article, In vitro analysis of CRP and IHF binding to the Ppac promoter, paragraph after Figure 4; exact reproduced text line 99: IHF did not shift PPAC at tested concentrations while it shifted the PR-PG control. The authors infer that the in-vivo response is most likely an indirect effect; the assay does not identify an indirect mechanism.
- Figure 4B and caption; reproduced text line 98: The tested protein range is 100–300 nM with 1 nM PPAC and PR-PG probes.

Required correction: State that an indirect IHF effect is inferred or most likely. Preserve the observed negative binding result and positive-control conditions; retain the prohibition on a direct IHF-to-Ppac binding edge.

Preserve the frozen original and independent review; save a separate reproducible successor, obtain independent acceptance, and carry the corrected evidence into the maintained curation. Close only after the correction and its disposition are retained in a verified merged tree.

Independent review manifest: `39296913278720a6687f2383aed312cb22e67cfa8c1151964e7d7b4c2460aea4`. Root separately confirmed the original-source finding. The complete 341-issue all-state queue was checked for duplicates before filing.
