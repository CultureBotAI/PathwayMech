Independent primary-source review found this defect in the phenylacetate degradation I (`MetaCyc:PWY0-321`) research preparation. No maintained pathway record has been authored from this claim yet.

Stable finding: `N268-PR01`; severity: medium; claim: `N268-P16`.

Affected artifact: frozen `next-268-primary/primary-claim-ledger.json` (SHA-256 `03d3703207e57387190387a2f1d0684c4de461a82b3bcd1a22b20664929c2933`). The historical `build_dossier.py` contains the same wording and must remain an explicitly superseded snapshot.

Primary source: https://doi.org/10.1074/jbc.M513896200 (retained SHA-256 `98c9d86596c9b28460e81054c7d88e343734cf8620fbbd92759a384fe6a5c87d`).

- PDF page 3, journal page 11030, Methods continuation: The A. evansii mutant activities were identical before and after gel filtration; this supports removal of host E. coli PaaI by the purification protocol. It does not report activity disappearing.
- PDF page 7, journal page 11034, catalytic-site Results continuation: Residual E. coli D61A activity was suspected to reflect host contamination. A. evansii D75A, chosen because it can be separated from host PaaI, had no detectable activity.
- PDF page 4, Table 1; PDF page 5, Table 2: A. evansii D75A kcat is bounded below the detection limit, while E. coli D61A retains a small apparent value. These are distinct results, not a before/after disappearance experiment.

Required correction: State the unchanged before/after gel-filtration control, suspected E. coli D61A host contamination, and undetectable A. evansii D75A activity as separate observations. Retain uncertainty between general-base and covalent-nucleophile mechanisms.

Preserve the frozen original and independent review; save a separate reproducible successor, obtain independent acceptance, and carry the corrected evidence into the maintained curation. Close only after the correction and its disposition are retained in a verified merged tree.

Independent review manifest: `39296913278720a6687f2383aed312cb22e67cfa8c1151964e7d7b4c2460aea4`. Root separately confirmed the original-source finding. The complete 341-issue all-state queue was checked for duplicates before filing.
