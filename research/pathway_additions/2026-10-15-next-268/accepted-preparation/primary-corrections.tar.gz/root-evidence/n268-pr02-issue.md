Independent primary-source review found this defect in the phenylacetate degradation I (`MetaCyc:PWY0-321`) research preparation. No maintained pathway record has been authored from this claim yet.

Stable finding: `N268-PR02`; severity: medium; claim: `N268-P20`.

Affected artifact: frozen `next-268-primary/primary-claim-ledger.json` (SHA-256 `03d3703207e57387190387a2f1d0684c4de461a82b3bcd1a22b20664929c2933`). The historical `build_dossier.py` contains the same wording and must remain an explicitly superseded snapshot.

Primary source: https://doi.org/10.1074/jbc.275.16.12214 (retained SHA-256 `4961491d0dfdb498deeda9dbe0b5578c94ccb2512028a83433fb4b0914c0b529`).

- PDF page 4, journal 12217, Table II and caption: AF15PZ carries chromosomal Pz-lacZ. pAFX2 ± pAFK5 and ±1 mM PA test ligase-dependent induction.
- PDF page 6, journal 12219, Table III and caption: The 30.4, 1.1, 4.3, 1.8 and 4.7 repression values are from AF15 carrying pAFPA2/pAFPA2-M Pa-lacZ plasmids with pAFX2 versus pCK01. The caption specifies M63 glycerol, 30 °C, OD600 1; it does not specify PA induction.
- PDF page 2, journal 12215, Table I; page 3, reporter Methods: The strain and plasmid definitions distinguish AF15 from AF15PZ and Pa reporter plasmids from the Pz chromosomal reporter.

Required correction: Split the two experiments and their preparations/controls. Attach the fold values only to Table III AF15/Pa reporter mutants. Attach ligase-dependent PA induction only to Table II AF15PZ/Pz reporters. Do not infer unreported PA conditions for Table III.

Preserve the frozen original and independent review; save a separate reproducible successor, obtain independent acceptance, and carry the corrected evidence into the maintained curation. Close only after the correction and its disposition are retained in a verified merged tree.

Independent review manifest: `39296913278720a6687f2383aed312cb22e67cfa8c1151964e7d7b4c2460aea4`. Root separately confirmed the original-source finding. The complete 341-issue all-state queue was checked for duplicates before filing.
