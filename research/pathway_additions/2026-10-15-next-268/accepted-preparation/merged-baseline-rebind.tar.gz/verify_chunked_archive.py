from pathlib import Path
import hashlib,json

O=Path(__file__).resolve().parent
B=Path('/private/tmp/pathwaymech-next-268-20261015')
R=B/'research/pathway_additions/2026-10-15-next-267/evidence-retention'
D=Path('/private/tmp/pathwaymech-next-268-discovery')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
manifest=load(R/'content-map.json');chunked={k:v for k,v in manifest.items() if 'chunks' in v['storage']}
assert len(chunked)==1
proof=[]
for raw_hash,row in chunked.items():
    storage=row['storage'];digest=hashlib.sha256();offset=0;parts=[]
    for chunk in storage['chunks']:
        rel=Path(chunk['path']);assert not rel.is_absolute() and '..' not in rel.parts
        p=R/rel;assert p.is_file() and not p.is_symlink();b=p.read_bytes()
        assert len(b)==chunk['bytes'] and sha(b)==chunk['sha256'] and offset==chunk['offset']
        digest.update(b);offset+=len(b);parts.append({**chunk,'actual_sha256':sha(b),'verified':True})
    assert offset==storage['stored_bytes']==row['source_bytes']==104854732
    assert digest.hexdigest()==storage['stored_sha256']==row['source_sha256']==raw_hash
    assert row['decode_steps']==[]
    reuse=[]
    for stem in ['candidate-context','candidate-accession-context']:
        rows=load(D/(stem+'-inventory.json'));canonical=next(x for x in rows if x['sha256']==raw_hash and 'hits' in x)
        descendants=[x for x in rows if x['owner'].startswith(canonical['owner']+'!')]
        meta=load(D/(stem+'-scan.json'));limits=load(D/(stem+'-limits.json'))
        reuse.append({'prior_scan':stem,'archive_owner':canonical['owner'],'archive_sha256':raw_hash,'archive_bytes':canonical['bytes'],'prior_decoded_descendant_owners':len(descendants),'descendant_direct_matching_contents':sum(bool(x.get('hits')) for x in descendants),'subtree_decode_errors':[x for x in meta['decode_errors'] if x['owner'].startswith(canonical['owner']+'!')],'subtree_limits':[x for x in limits if x['owner'].startswith(canonical['owner']+'!')]})
        assert canonical['bytes']==offset and descendants
    proof.append({'source':'authority-preparation/source-cache/noctua-models-json.tgz','source_sha256':raw_hash,'source_bytes':offset,'parts':parts,'reuse':reuse,'disposition':'The individual first storage chunk is not a complete gzip stream. Complete ordered assembly is verified byte-identical to both prior recursively decoded candidate scans. No residual decoding gap for this archive; no source corruption found.'})
inputs=[]
for p in [R/'content-map.json',R/'packages/authority-preparation/source-map.json']:
    b=p.read_bytes();inputs.append({'path':str(p),'sha256':sha(b),'bytes':len(b)})
(O/'chunked-archive-closure.json').write_text(json.dumps({'status':'passed','inputs':inputs,'proof':proof},indent=2)+'\n')
print(json.dumps({'status':'passed','archives':len(proof),'parts':len(proof[0]['parts']),'source_sha256':proof[0]['source_sha256'],'reuse':proof[0]['reuse']},indent=2))
