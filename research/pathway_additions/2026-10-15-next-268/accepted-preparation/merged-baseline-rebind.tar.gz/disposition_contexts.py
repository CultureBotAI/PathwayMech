#!/usr/bin/env python3
"""Produce finite match dispositions from bound scan and retained logical-source map."""
import json, pathlib, collections
P=pathlib.Path(__file__).resolve().parent
read=lambda f:json.loads((P/f).read_text())
write=lambda f,x:(P/f).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
contexts=read('fresh-context-logical-source-map.json'); by_hash={r['sha256']:(i,r) for i,r in enumerate(contexts)}
special={
34:('adjacent-primary-boundary','BadI expression in R. palustris CGA009 under the reported phenylacetate condition is adjacent anaerobic-pathway context; it is not absence evidence for the aerobic candidate.'),
63:('bibliographic-context','Cycloheptanecarboxylic acid/phenylacetic acid bibliography context does not establish candidate membership.'),
75:('compressed-byte-coincidence','6SLB is a raw compressed-byte match in a storage chunk, not a PDB claim. Ordered complete assembly is resolved in chunked-archive-closure.json.'),
79:('adjacent-pathway-citation','PWY-2361 source cites shared terminal-thiolase literature. Existing terminal chemistry does not duplicate the complete aerobic route.'),
85:('adjacent-primary-boundary','Reported BadI phenylacetate-expression condition in R. palustris CGA009 belongs to the adjacent anaerobic route; no candidate-wide absence conclusion.'),
86:('other-chemical-search-result','Phenylacetamido-containing synonym in chemical search context is not phenylacetate pathway evidence.'),
95:('adjacent-source-and-token-boundary','Source-owner inventory includes adjacent phenylacetaldehyde oxidoreductase context; ENZRXN-24254 substring must not be treated as exact RXN-2425 identity.'),
96:('family-label-not-pathway-proof','UniProt search context contains 4-hydroxyphenylacetate catabolism family labeling; this alone does not identify a candidate enzyme.'),
120:('family-label-not-pathway-proof','UniProt regulator-search context contains a 4-hydroxyphenylacetate catabolism family label, not exact candidate-regulator evidence.'),
127:('candidate-relevant-primary-lead','Retained Price 2022 PLOS paper 1010156 contains candidate phenylacetate/PaaG/PaaZ material. This is an evidence lead, not a duplicate record or catalytic/organism mapping newly adjudicated here. Use the current independently reviewed 268 primary dossier; preserve fitness and P. bryophila versus P. caledonica identity limitations.'),
141:('other-chemical-search-result','Aminobenzoate search contains a phenylacetamidopenicillin synonym; outside candidate route identity.'),
142:('family-label-not-pathway-proof','UniProt C4TP01 family label refers to 4-hydroxyphenylacetate catabolism; cannot transfer catalytic membership to PWY0-321.'),
143:('encoded-byte-coincidence','paaZ substring occurs in encoded/base64 search-wrapper payload, not a protein assertion.'),
175:('substring-boundary','Actual enzyme-activity frame ENZRXN-3641 / reaction RXN-2464 is not reaction RXN-3641; substring hit cannot supply exact identity.'),
177:('shared-cofactor-reverse-context','Broad ATP/CoA and terminal-thiolase reverse backlinks are shared context. ENZRXN0-6510 substring is not exact reaction RXN0-6510. Do not transfer pathway membership or regulation.'),
196:('family-label-not-pathway-proof','Later regulatory identity dispositions preserve the 4-hydroxyphenylacetate family-name boundary; not candidate regulation evidence.'),
229:('distinct-anaerobic-boundary','PWY-1341 anaerobic route/interface reconstruction is distinct from the selected aerobic PWY0-321 route.')}
rows=[]
for r in read('fresh-content-scan.json'):
 if not r['hits']:continue
 item=by_hash.get(r['sha256']); idx,c=(item if item else (None,None)); sources=c.get('retained_logical_sources',[]) if c else []
 joined=' '.join(sources+[r['owner']]); pats=[h['pattern'] for h in r['hits']]
 if idx in special:cat,dis=special[idx]
 elif 'PWY0-321' in pats:
  cat,dis='historical-progress-checkpoint','Historical next-267 root continuation checkpoint mentions the candidate as staged follow-up. It is neither a maintained candidate record nor current 268 scientific acceptance. Current accepted successors and this actual-merge rebind govern.'
 elif not c:
  if r['owner'].endswith('!gzip'):cat,dis='archive-container-context','Uncompressed tar container duplicates member evidence/inventory text; recursive member scan is recorded. Container bytes are not an additional scientific source.'
  else:cat,dis='compressed-byte-coincidence','Raw compressed-stream substring is not scientific evidence; decoded content is separately inventoried.'
 elif 'discovery/searches/' in joined or 'discovery/source-snapshots/' in joined:
  cat,dis='retained-search-wrapper','Prior next-267 finite searches or source snapshots retained as search context. These hits supply leads/owning context, not newly curated candidate identity; current maintained full-record comparison controls deduplication.'
 elif r['owner'].startswith('pages/'):
  cat,dis='generated-existing-corpus','Generated browse/index/KGX material reflects existing records and shared lower-route or neighboring context; all maintained record identities were compared separately.'
 elif 'native/all-native-direct-slots' in joined or 'native-material-complete-projection' in joined or 'selected-native-direct-slot' in joined:
  cat,dis='prior-native-adjacent-context','Retained prior-route native projections contain shared compounds/reactions and reverse backlinks. Preserve full source boundary; occurrence of candidate reactions in adjacency is not a complete candidate record.'
 elif 'related-record-dispositions' in joined or 'all-record-comparison-dispositions' in joined or 'complete-context-dispositions' in joined:
  cat,dis='prior-dedup-disposition','Earlier related-record/shared-lower-route dispositions are historical context; current 264-record byte/identity comparison rebinds the prior 263 and separately evaluates added P321-PWY.'
 elif 'source-cache/' in joined:
  cat,dis='authority-source-context','Identifier source bytes or cache context. A token match does not establish exact candidate membership; issuing identity and reaction/material scope require current candidate-specific evidence.'
 elif '1010156' in pats:
  cat,dis='primary-acquisition-or-review-metadata','Price 2022 source acquisition, receipt, manifest or review lead metadata. The actual retained HTML is separately dispositioned; these are not independent evidence or new acceptance.'
 else:
  cat,dis='inventory-authority-review-or-test-context','Maintained authority metadata, source/review inventories, previous record comparisons, provisional selectors or verification artifacts. Matches preserve adjacent identifiers/evidence, not a new maintained PWY0-321 record. Source semantics are not newly adjudicated from metadata.'
 rows.append({'owner':r['owner'],'sha256':r['sha256'],'bytes':r['bytes'],'context_row':idx,'retained_logical_sources':sources,'matching_patterns':pats,'category':cat,'disposition':dis,'assessment_basis':'Bound owning role and saved first-match windows; exact record identity checked separately. Not an exhaustive scientific reread of every content occurrence.'})
assert len(rows)==275 and len({r['sha256'] for r in rows})==275
write('fresh-match-dispositions.json',rows)
write('fresh-match-disposition-summary.json',{'matching_contents':len(rows),'mapped_noncontainer_contexts':len(contexts),'categories':dict(collections.Counter(r['category'] for r in rows)),'exact_candidate_checkpoint_mentions':sum('PWY0-321' in r['matching_patterns'] for r in rows),'all_matching_hashes_dispositioned':True,'bounds':'First occurrence per pattern; source roles and bounded contexts, not a universal semantic search or new scientific review.'})
