"""Read-only merged-baseline rebind with byte-identified scan reuse."""
from pathlib import Path
import collections, datetime, gzip, hashlib, io, json, os, re, subprocess, tarfile, zipfile
import yaml

O = Path(__file__).resolve().parent
B = Path('/private/tmp/pathwaymech-next-268-20261015')
D = Path('/private/tmp/pathwaymech-next-268-discovery')
HEAD = '2c27fc819bac17ef05e191830346d7a32248c97c'
TREE = '8de7191ed69ec355c6442cb45179f5effc9ee137'

def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_text())
def save(n, x): (O/n).write_text(json.dumps(x, indent=2, ensure_ascii=False)+'\n')
def git(*args):
    p=subprocess.run(['git','-C',str(B),*args],capture_output=True,text=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
    assert p.returncode==0,(args,p.stderr)
    return p.stdout.strip()
def state(): return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1','--untracked-files=all')}

start=state();assert start=={'head':HEAD,'tree':TREE,'status':''},start
save('git-state-before.json',start)
prior=[];patterns=[]
for prefix in ['candidate-context','candidate-accession-context']:
    meta=read(D/(prefix+'-scan.json'));patterns+=meta['patterns']
    rows=read(D/(prefix+'-inventory.json'))
    primary={x['sha256']:x for x in rows if 'hits' in x}
    assert all(x['sha256'] in primary for x in rows)
    prior.append(primary)
patterns=list(dict.fromkeys(patterns));needles=[x.lower().encode() for x in patterns]
save('finite-search-patterns.json',patterns)
oldphysical={x['path']:x for x in read(D/'candidate-accession-context-physical-inventory.json')}
physical=[];reused=[];fresh=[];errors=[];limits=[];parts=[];seen={};groups={};savedtexts=[]

def scan(name,b):
    h=sha(b)
    if h in seen:
        return
    seen[h]=name
    if all(h in x for x in prior):
        reused.append({'current_owner':name,'sha256':h,'bytes':len(b),'prior_owners':[x[h]['owner'] for x in prior], 'direct_hits':[z for x in prior for z in x[h]['hits']], 'scope':'Exact bytes match both prior finite-pattern scans; recursively decoded scope and its recorded errors/PDF-image limits inherited, not enlarged.'})
        return
    lo=b.lower();hits=[]
    for pat,needle in zip(patterns,needles):
        if needle in lo:
            i=lo.index(needle);hits.append({'pattern':pat,'offset':i,'snippet':b[max(0,i-100):i+len(needle)+230].decode('utf8',errors='replace')})
    row={'owner':name,'sha256':h,'bytes':len(b),'hits':hits};fresh.append(row)
    if hits and not b.startswith((b'\x1f\x8b',b'PK\x03\x04',b'%PDF',b'\x89PNG',b'\xff\xd8')) and not (len(b)>262 and b[257:262]==b'ustar'):
        # Preserve bounded context windows for human triage; complete originals remain at the bound owners.
        savedtexts.append(row)
    def members(items):
        pending={}
        for n,v in items:
            m=re.fullmatch(r'(.*\.zip)\.part-(\d+)',n)
            if m:pending.setdefault(m[1],[]).append((int(m[2]),n,v))
            else:scan(name+'!'+n,v)
        for stem,group in pending.items():assemble(name+'!'+stem,group)
    try:
        if b.startswith(b'\x1f\x8b'):scan(name+'!gzip',gzip.decompress(b))
        elif b.startswith(b'PK\x03\x04'):
            with zipfile.ZipFile(io.BytesIO(b)) as z:members((x.filename,z.read(x)) for x in z.infolist() if not x.is_dir())
        elif len(b)>262 and b[257:262]==b'ustar':
            with tarfile.open(fileobj=io.BytesIO(b),mode='r:') as t:members((x.name,t.extractfile(x).read()) for x in t.getmembers() if x.isfile())
        elif b.startswith((b'%PDF',b'\x89PNG',b'\xff\xd8')):limits.append({'owner':name,'sha256':h,'limit':'Literal bytes only; compressed PDF text and image semantic content not extracted/OCRed.'})
    except (OSError,EOFError,ValueError,RuntimeError,tarfile.TarError,zipfile.BadZipFile) as exc:errors.append({'owner':name,'sha256':h,'error':str(exc)})
def assemble(stem,group):
    group.sort();joined=b''.join(x[2] for x in group)
    parts.append({'owner':stem,'numbers':[x[0] for x in group],'contiguous_from_one':[x[0] for x in group]==list(range(1,len(group)+1)),'parts':[{'name':x[1],'bytes':len(x[2]),'sha256':sha(x[2])} for x in group],'assembled_sha256':sha(joined)})
    scan(stem+'!assembled',joined)

for p in sorted(B.rglob('*')):
    rel=p.relative_to(B)
    if '.git' in rel.parts:continue
    if p.is_symlink():limits.append({'owner':str(rel),'limit':'symlink not followed','target':os.readlink(p)});continue
    if not p.is_file():continue
    b=p.read_bytes();h=sha(b);name=str(rel);old=oldphysical.get(name)
    physical.append({'path':name,'bytes':len(b),'sha256':h,'prior_physical_disposition':'unchanged' if old and old['sha256']==h else 'changed' if old else 'new'})
    m=re.fullmatch(r'(.*\.zip)\.part-(\d+)',name)
    if m:groups.setdefault(m[1],[]).append((int(m[2]),name,b))
    else:scan(name,b)
    if len(physical)%1000==0:print(json.dumps({'physical':len(physical),'reused':len(reused),'fresh':len(fresh)}),flush=True)
for stem,group in groups.items():assemble(stem,group)
save('current-physical-inventory.json',physical);save('reused-content-proofs.json',reused);save('fresh-content-scan.json',fresh);save('fresh-candidate-contexts.json',savedtexts);save('fresh-scan-limits.json',limits);save('fresh-decode-errors.json',errors);save('split-archive-parts.json',parts)
save('removed-physical-paths.json',sorted(set(oldphysical)-{x['path'] for x in physical}))

prior_records={x['path']:x for x in read(D/'complete-current-record-comparison.json')}
root_baseline=read(Path('/private/tmp/pathwaymech-next-268-ci/actual-merged-baseline.json'))
root_rows={x['path']:x for x in root_baseline['records']}
assert root_baseline['head']==HEAD and root_baseline['tree']==TREE
records=[];overlaps=[]
for p in sorted((B/'data/pathways').rglob('*.yaml')):
    rel=str(p.relative_to(B));b=p.read_bytes();record=yaml.safe_load(b);h=sha(b)
    assert root_rows[rel]['sha256']==h
    old=prior_records.get(rel)
    assert old is None or old['sha256']==h
    reaction_ids={x['id'] for x in record.get('reactions',[])}
    refs={x['id'] for x in record.get('references',[])}
    hits=[pat for pat in patterns if pat.lower().encode() in b.lower()]
    row={'path':rel,'sha256':h,'id':record['id'],'label':record['label'],'prior_record_unchanged':old is not None,'candidate_pathway_id':record['id']=='MetaCyc:PWY0-321','candidate_exact_label':record['label'].casefold()=='phenylacetate degradation i (aerobic)','candidate_patterns':hits,'reaction_ids':sorted(reaction_ids),'reference_ids':sorted(refs)}
    records.append(row)
    if hits:overlaps.append(row)
assert len(records)==264 and len(prior_records)==263
added=[x for x in records if not x['prior_record_unchanged']]
assert len(added)==1 and added[0]['id']=='MetaCyc:P321-PWY'
assert not any(x['candidate_pathway_id'] or x['candidate_exact_label'] for x in records)
save('all-current-record-comparisons.json',records);save('current-record-candidate-overlaps.json',overlaps)

dispositions=[]
for x in read(D/'prior-candidate-context-dispositions.json'):
    owner=x['owner'];segments=owner.split('!');p=B/segments[0];b=p.read_bytes()
    for segment in segments[1:]:
        assert segment=='gzip',owner
        b=gzip.decompress(b)
    assert sha(b)==x['sha256'],owner
    dispositions.append({**x,'current_decoded_sha256':sha(b),'rebound_to_actual_merge':True,'current_action':'Retain original adjacent-context/roadmap disposition. It is not a complete maintained candidate record.'})
save('all-prior-mention-dispositions-rebound.json',dispositions)

end=state();assert end==start
save('git-state-after.json',end)
for row in physical:
    p=B/row['path'];assert sha(p.read_bytes())==row['sha256'],str(p)
summary={'head':HEAD,'tree':TREE,'record_count':len(records),'prior_records_byte_unchanged':len(prior_records),'new_record':added,'candidate_maintained_record_found':False,'prior_mentions_rebound':len(dispositions),'patterns':len(patterns),'physical_count':len(physical),'physical_dispositions':dict(collections.Counter(x['prior_physical_disposition'] for x in physical)),'prior_decoded_content_reused':len(reused),'fresh_distinct_contents':len(fresh),'fresh_matching_contents':sum(bool(x['hits']) for x in fresh),'fresh_decode_errors':len(errors),'fresh_binary_or_symlink_limits':len(limits),'all_physical_bytes_rechecked_unchanged':True,'git_state_unchanged':True,'scope':'Hidden and ignored physical files included except Git administrative metadata. Exact-hash reuse of both prior finite-pattern scans. New gzip/zip/ustar decoded recursively; split ZIPs assembled. Prior 18 malformed fixture decode errors and 526 PDF/image semantic limits per prior pass remain explicit. Other binary formats, PDF/image semantics, and external worktrees are not globally searched.'}
save('summary.json',summary);print(json.dumps(summary,indent=2),flush=True)
