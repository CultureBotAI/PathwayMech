"""Independent finite adversarial probes of the root's mechanism contract."""
from __future__ import annotations

import copy
import csv
import io
import itertools
import json
from contextlib import redirect_stdout
from pathlib import Path

from pathwaymech import cli
from pathwaymech.kgx import kgx_edges, kgx_nodes, render_kgx
from pathwaymech.reaction_mechanisms import iter_mechanism_evidence, mechanism_equation
from pathwaymech.schema import ValidationError, validate_record
from pathwaymech.strict import TARGET_CLASS, validator

HERE = Path(__file__).resolve().parent
BASE = json.loads((HERE / "inputs/tests/fixtures/reaction_mechanism.json").read_text())
results = []


def evidence(role="fixture"):
    return [{"reference_id": "DOI:" + role, "quote": "Bounded synthetic evidence."}]


def check(label, raw, expected, closed=False):
    try:
        validate_record(raw)
        accepted, messages = True, []
    except ValidationError as error:
        accepted, messages = False, error.errors
    except Exception as error:
        results.append(dict(label=label, expected=expected, exception=repr(error), passed=False))
        return
    result = dict(label=label, expected=expected, accepted=accepted,
                  passed=accepted == expected, errors=messages)
    if closed:
        result["closed_accepted"] = not bool(CLOSED.validate(raw, TARGET_CLASS).results)
        # Semantic constraints exceed the closed schema, but valid examples must pass both.
        if expected:
            result["passed"] &= result["closed_accepted"]
    results.append(result)


def note(label, actual):
    results.append(dict(label=label, passed=bool(actual)))


CLOSED = validator()
for orientation in ("as_reported", "reversed"):
    for a, b, x, y, t1, t2 in itertools.product((1, 2), repeat=6):
        raw = copy.deepcopy(BASE)
        m = raw["reaction_mechanisms"][0]
        m["source_equation"]["inputs"][0]["coefficient"] = a
        m["source_equation"]["outputs"][0]["coefficient"] = b
        m["source_equation"]["orientation"] = orientation
        if orientation == "reversed":
            m["source_equation"]["inputs"], m["source_equation"]["outputs"] = (
                m["source_equation"]["outputs"], m["source_equation"]["inputs"])
        for edge, coefficient in zip(m["edges"][:4], (x, t1, t2, y), strict=True):
            edge["coefficient"] = coefficient
        check(f"decomposition:{orientation}:{a,b,x,y,t1,t2}", raw,
              a == x and b == y and t1 == t2)
        for c in (1, 2):
            alternative = copy.deepcopy(raw)
            detail = alternative["reaction_mechanisms"][0]
            detail["relation_to_source"] = "alternative_interpretation"
            detail["edges"][0]["subject"] = {"node_id": "CHEBI:4"}
            detail["source_conflicts"] = [{
                "source_participant_id": "CHEBI:1", "interpreted_participant_id": "CHEBI:4",
                "side": "inputs", "coefficient": c, "kind": "constitution", "status": "unresolved",
                "rationale": "Distinct source and interpreted substances", "evidence": evidence(),
            }]
            check(f"alternative:{orientation}:{a,b,x,y,t1,t2,c}", alternative,
                  a == x == c and b == y and t1 == t2)

# Whole-side substitutions are independent on both input and output boundaries.
two = copy.deepcopy(BASE)
two["participants"].append({"id": "CHEBI:6", "label": "Distinct output", "category": "small_molecule"})
two_m = two["reaction_mechanisms"][0]
two_m["relation_to_source"] = "alternative_interpretation"
two_m["edges"][0]["subject"] = {"node_id": "CHEBI:4"}
two_m["edges"][3]["object"] = {"node_id": "CHEBI:6"}
two_m["source_conflicts"] = [{
    "source_participant_id": source, "interpreted_participant_id": target,
    "side": side, "coefficient": 1, "kind": "stereo", "status": "proposed_revision",
    "rationale": "Separate bounded identity conflict", "evidence": evidence(),
} for source, target, side in [("CHEBI:1", "CHEBI:4", "inputs"), ("CHEBI:2", "CHEBI:6", "outputs")]]
check("two-side-substitution", two, True, closed=True)
for index in (0, 1):
    raw = copy.deepcopy(two)
    raw["reaction_mechanisms"][0]["source_conflicts"][index]["side"] = (
        "outputs" if index == 0 else "inputs")
    check(f"two-side-wrong-side-{index}", raw, False)
    raw = copy.deepcopy(two)
    raw["reaction_mechanisms"][0]["source_conflicts"].pop(index)
    check(f"two-side-partial-{index}", raw, False)

# Malformed values at every new nested location must fail gracefully, not crash.
def paths(value, prefix):
    yield prefix
    if isinstance(value, dict):
        for key, child in value.items():
            yield from paths(child, prefix + [key])
    elif isinstance(value, list):
        for i, child in enumerate(value):
            yield from paths(child, prefix + [i])

shape_base = copy.deepcopy(two)
shape_base["reaction_mechanisms"][0]["steps"][0]["hypotheses"] = [{
    "description": "Unobserved state", "status": "proposed", "evidence": evidence()}]
shape_base["reaction_mechanisms"][0]["edges"][4]["endpoint_qualifiers"] = [{
    "endpoint": "subject", "kind": "molecular_state", "description": "Bound state",
    "evidence": evidence()}]
shape_paths = list(paths(shape_base["reaction_mechanisms"], ["reaction_mechanisms"]))
for path in shape_paths:
    for bad in (None, {}, {"unknown": None}, [None], False, 0):
        raw = copy.deepcopy(shape_base)
        parent = raw
        for part in path[:-1]:
            parent = parent[part]
        parent[path[-1]] = bad
        check("malformed:" + repr(path) + ":" + repr(bad), raw, False)

# Every step location is either unspecified together or exactly the same declaration.
for first, second in itertools.product((None, "GO:1", "GO:2"), repeat=2):
    raw = copy.deepcopy(BASE)
    for step, location in (("first", first), ("second", second)):
        if location is not None:
            raw["reaction_mechanisms"][0]["edges"].append({
                "key": "location_" + step, "subject": {"step_key": step}, "predicate": "occurs_in",
                "object": {"node_id": location}, "assertion_status": "supported", "evidence": evidence()})
    check(f"location:{first}:{second}", raw, first == second, closed=True)

# Scope is global across mechanisms and declarations, not a per-mechanism degree heuristic.
for role in ("taxa", "reactions"):
    raw = copy.deepcopy(BASE)
    raw[role].append(copy.deepcopy(raw["participants"][2]))
    check("detail-only-duplicate-role-" + role, raw, False)
raw = copy.deepcopy(BASE)
raw["id"] = "CHEBI:3"
check("detail-only-root-role", raw, False)
raw = copy.deepcopy(BASE)
other = copy.deepcopy(raw["reaction_mechanisms"][0])
other["key"] = "another"
other["steps"] = [other["steps"][1]]
other["edges"] = other["edges"][2:4]
other["source_equation"]["inputs"][0]["participant_id"] = "CHEBI:3"
raw["reaction_mechanisms"].append(other)
check("detail-only-other-source-equation", raw, False)
raw["detail_only_participant_ids"] = []
check("shared-local-step-key-across-mechanisms", raw, True, closed=True)

# Complete export, including evidence appearing only on non-edge assertions.
export_raw = copy.deepcopy(two)
m = export_raw["reaction_mechanisms"][0]
roles = ["association", "step", "edge", "hypothesis", "qualifier", "conflict", "source"]
export_raw["references"] = [{"id": "DOI:" + role, "title": role + " title",
    "citation": role + " citation", "url": "https://example.org/" + role,
    "source_version": "fixture-v1", "source_sha256": "a" * 64} for role in roles]
m["evidence"] = evidence("association")
for step in m["steps"]:
    step["evidence"] = evidence("step")
for edge in m["edges"]:
    edge["evidence"] = evidence("edge")
for conflict in m["source_conflicts"]:
    conflict["evidence"] = evidence("conflict")
m["steps"][0]["hypotheses"] = [{"description": "Unobserved α-state\nwith a tab\tretained",
                                      "status": "proposed", "evidence": evidence("hypothesis")}]
m["edges"][4]["endpoint_qualifiers"] = [{"endpoint": "subject", "kind": "experimental_construct",
    "description": "Tagged enzyme", "evidence": evidence("qualifier")}]
export_raw["mechanistic_edges"] = [{"id": "source", "subject": "UniProtKB:FIXTURE",
    "predicate": "catalyzes", "object": "RHEA:1", "evidence": evidence("source") * 2,
    "endpoint_qualifiers": [{"endpoint": "subject", "kind": "experimental_construct",
                            "description": "Native source construct", "evidence": evidence("source")}]}]
export_raw["reactions"][0]["direction"] = "left_to_right"
first = validate_record(export_raw)
other_raw = copy.deepcopy(export_raw)
other_raw["id"] = "MetaCyc:SECOND"
other_raw["reactions"][0]["direction"] = "right_to_left"
other_raw["reaction_mechanisms"][0]["key"] = "independent"
other_raw["references"][0]["title"] = "Different record-local reference metadata"
second = validate_record(other_raw)
nodes = kgx_nodes([first, second])
parents = [n for n in nodes if n.id == "RHEA:1"]
note("one-issued-reaction-node", len(parents) == 1)
note("no-global-direction-flattening", parents[0].direction == "")
contexts = json.loads(parents[0].source_contexts)
for raw in (export_raw, other_raw):
    context = next(c for c in contexts if c["record_id"] == raw["id"])
    detail = context["reaction_mechanisms"][0]
    expected_refs = [r for r in raw["references"] if r["id"] != "DOI:source"]
    note("full-payload:" + raw["id"], detail["mechanism"] == raw["reaction_mechanisms"][0])
    note("full-citation-metadata:" + raw["id"], sorted(detail["references"], key=lambda x:x["id"])
         == sorted(expected_refs, key=lambda x:x["id"]))
note("only-issued-node-ids", {n.id for n in nodes} == {
    export_raw["id"], other_raw["id"], "RHEA:1", *(n["id"] for n in export_raw["participants"])})
note("only-top-level-edges", len(kgx_edges([first, second])) == 2)
tsv = render_kgx([first, second])["nodes.tsv"]
roundtrip = list(csv.DictReader(io.StringIO(tsv), delimiter="\t"))
note("tsv-retains-full-json", json.loads(next(n for n in roundtrip if n["id"] == "RHEA:1")["source_contexts"])
     == contexts)
note("all-nested-evidence-counted-once", len(list(iter_mechanism_evidence(m))) == 12)
original_loader = cli.load_pathway_records
try:
    cli.load_pathway_records = lambda unused: [first]
    output = io.StringIO()
    with redirect_stdout(output):
        code = cli.check_provenance_main()
    note("provenance-cli-count", code == 0 and output.getvalue() == "checked 15 evidence blocks\n")
finally:
    cli.load_pathway_records = original_loader

(HERE / "adversarial-results.json").write_text(json.dumps(results, indent=2) + "\n")
failed = [r for r in results if not r["passed"]]
print(json.dumps({"cases": len(results), "passed": len(results) - len(failed), "failures": failed}, indent=2))
raise SystemExit(bool(failed))
