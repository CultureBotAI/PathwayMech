"""Read-only probes of current owners plus symbolic design counterexamples.
No proposed schema is implemented or claimed validated by these probes.
"""
from pathlib import Path
from copy import deepcopy
from collections import Counter
from html.parser import HTMLParser
import json,yaml,hashlib
from pathwaymech.schema import validate_record,ValidationError
from pathwaymech.strict import validator,TARGET_CLASS
from pathwaymech.graph_view import graph_html
from pathwaymech.kgx import kgx_nodes,kgx_edges
O=Path(__file__).resolve().parent
S=Path('/private/tmp/pathwaymech-next-268-reaction-mechanism-design')
record=yaml.safe_load((S/'inputs/worktree/data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml').read_text())
checks=[]
def check(name,condition,detail=None):
 checks.append({'check':name,'passed':bool(condition),'detail':detail});assert condition,(name,detail)
def save(name,obj):
 p=O/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
try:
 strict=validator();checked=validate_record(record)
 check('unchanged real baseline passes strict shape',not list(strict.validate(record,TARGET_CLASS).results))
 x=deepcopy(record);x['reaction_mechanisms']=[];loose=validate_record(x)
 check('current dataclass drops unsupported field',not hasattr(loose,'reaction_mechanisms'))
 check('closed schema rejects unsupported field',bool(list(strict.validate(x,TARGET_CLASS).results)))
 x=deepcopy(record);prior=x['reactions'][0]['id'];x['reactions'][0]['id']='pathwaymech:unissued-step'
 for e in x['mechanistic_edges']:
  for k in ['subject','object']:
   if e[k]==prior:e[k]='pathwaymech:unissued-step'
 try:validate_record(x);failed=False
 except ValidationError as e:failed='unsupported prefix' in str(e)
 check('semantic rejects invented reaction CURIE',failed)
 check('closed schema rejects invented reaction CURIE',bool(list(strict.validate(x,TARGET_CLASS).results)))
 x=deepcopy(record);rids={n['id'] for n in x['reactions']};e=next(e for e in x['mechanistic_edges'] if e['subject'] in rids)
 e['endpoint_qualifiers']=[{'endpoint':'subject','kind':'molecular_state','description':'Synthetic shape probe only.','evidence':deepcopy(e['evidence'][:1])}]
 try:validate_record(x);failed=False
 except ValidationError as e:failed='protein or complex participant' in str(e)
 check('reaction cannot use protein endpoint qualifier',failed)
 # Verify that public-reference multiplicity is a real implementation consideration.
 x=deepcopy(record);x['participants'].append(deepcopy(x['participants'][0]));dup=validate_record(x)
 check('existing semantic validator permits repeated identical participant declaration',len(dup.participants)==len(checked.participants)+1)
 check('existing closed schema permits repeated identical participant declaration',not list(strict.validate(x,TARGET_CLASS).results))
 labels={n['id']:n['label'] for field in ['participants','reactions','taxa'] for n in record[field]}
 anchors={i:'synthetic-component-'+str(n) for n,i in enumerate(labels)}
 one=graph_html(checked,labels,anchors)
 class IDs(HTMLParser):
  def __init__(self):super().__init__();self.ids=[]
  def handle_starttag(self,tag,attrs):self.ids += [v for k,v in attrs if k=='id']
 parser=IDs();parser.feed(one+one);duplicates=sorted(k for k,v in Counter(parser.ids).items() if v>1)
 check('reusing current graph renderer creates duplicate control anchors',all(x in duplicates for x in ['pathway-network','graph-node-picker','graph-native-size','graph-viewport']))
 save('current-renderer-duplicate-anchor-control.json',{'duplicates':duplicates,'meaning':'Confirms the proposal correctly requires scoped multi-graph rendering; this is not a new design defect.'})
 base_nodes={n.id:n for n in kgx_nodes([checked])};base_edges=kgx_edges([checked])
 check('source contexts retain record identifiers',all(all(c['record_id']==checked.id for c in json.loads(n.source_contexts)) for n in base_nodes.values()))
 check('current KGX exports exactly top-level edge count',len(base_edges)==len(checked.mechanistic_edges))
 def residual(steps,scoped):
  c=Counter()
  for step in steps:
   for sign,key in [(-1,'inputs'),(1,'outputs')]:
    for n,q in step[key]:c[(n,step['location']) if scoped else n]+=sign*q
  return {str(k):v for k,v in c.items() if v}
 steps=[{'key':'s1','location':'compartment_A','inputs':[['A',1]],'outputs':[['X',1]]},{'key':'s2','location':'compartment_B','inputs':[['X',1]],'outputs':[['B',1]]}]
 unscoped=residual(steps,False);scoped=residual(steps,True)
 check('unscoped design counterexample falsely removes cross-compartment X',unscoped=={'A':-1,'B':1} and len(scoped)==4)
 # X/A/B here are algebra symbols, never claimed issuing identifiers or YAML nodes.
 conflicts=[{'case':'coefficient_only','source_signed_terms':{'A':-2,'B':1},'interpreted_signed_terms':{'A':-1,'B':1},'required_delta':{'A':1}}, {'case':'extra_hydron','source_signed_terms':{'A':-1,'B':1},'interpreted_signed_terms':{'A':-1,'B':1,'H':1},'required_delta':{'H':1}}]
 for case in conflicts:
  keys=set(case['source_signed_terms'])|set(case['interpreted_signed_terms']);delta={k:case['interpreted_signed_terms'].get(k,0)-case['source_signed_terms'].get(k,0) for k in keys};delta={k:v for k,v in delta.items() if v}
  check('exact boundary delta '+case['case'],delta==case['required_delta'])
 save('design-counterexamples.json',{'scope':'Algebraic design review, not a validator for the unimplemented proposal and not biological curation. A/B/X/H are symbolic placeholders only.','D01':{'steps':steps,'ID_only_residual':unscoped,'location_preserving_residual':scoped,'required_policy':'Reject heterogeneous/unresolved locations in the initial profile or make location part of both source and step material term identity. No transport may be inferred from cancellation.'},'D02':{'cases':conflicts,'required_policy':'Make conflict coverage refer to exact signed quantities or bounded source/interpreted term arrays with empty one side permitted; alternatively prohibit all but equal-coefficient1:1 substitutions. Require disjoint, exhaustive delta coverage without null or invented counterpart.'}})
 save('probe-summary.json',{'checks_passed':len(checks),'author_three_contract_limits_confirmed':True,'existing_renderer_limitation_confirmed':True,'two_design_counterexamples_retained':True,'new_schema_implemented_or_executed':False,'corpus_tests_run':False})
finally:save('probe-checks.json',checks)
print(json.dumps({'checks_passed':len(checks)}))
