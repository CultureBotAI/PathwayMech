"""Symbolic controls for root's bounded D01/D02 proposed dispositions.
This is a review oracle, not an implementation of the new schema.
"""
from pathlib import Path
import json
O=Path(__file__).resolve().parent
checks=[]
def check(name,result,wanted):checks.append({'case':name,'actual':result,'expected':wanted,'passed':result==wanted});assert result==wanted,name
def locations(step_locations):
 if any(len(x)>1 for x in step_locations):return False
 if not any(step_locations):return True
 return all(len(x)==1 for x in step_locations) and len({x[0] for x in step_locations})==1
def substitutes(source,interpreted,conflicts):
 if not conflicts:return False
 differences={}
 for side in ['inputs','outputs']:
  a=source[side];b=interpreted[side]
  # Same identifier with a changed coefficient is not a substitution.
  if any(a[k]!=b[k] for k in a.keys()&b.keys()):return False
  differences[side]=({'source':{k:v for k,v in a.items() if k not in b},'interpreted':{k:v for k,v in b.items() if k not in a}})
 seen_s=set();seen_i=set()
 for c in conflicts:
  side=c['side'];a=c['source_participant_id'];b=c['interpreted_participant_id'];q=c['coefficient']
  if side not in differences or type(q) is not int or q<=0:return False
  ks=(side,a);ki=(side,b)
  if ks in seen_s or ki in seen_i:return False
  if differences[side]['source'].get(a)!=q or differences[side]['interpreted'].get(b)!=q:return False
  seen_s.add(ks);seen_i.add(ki)
 return seen_s=={(s,k) for s,d in differences.items() for k in d['source']} and seen_i=={(s,k) for s,d in differences.items() for k in d['interpreted']}
def eq(inputs,outputs=None):return {'inputs':inputs,'outputs':outputs or {'P':1}}
def conflict(a='E',b='Z',q=1,side='inputs'):return {'source_participant_id':a,'interpreted_participant_id':b,'coefficient':q,'side':side}
for name,data,want in [('all_unlocated',[[],[]],True),('one_shared_location',[['C'],['C']],True),('different_locations',[['C'],['P']],False),('partial_location',[[],['C']],False),('multiple_locations_on_step',[['C','P'],['C']],False)]:check(name,locations(data),want)
check('one same-side exact substitution',substitutes(eq({'E':1}),eq({'Z':1}),[conflict()]),True)
check('coefficient2 exact substitution',substitutes(eq({'E':2}),eq({'Z':2}),[conflict(q=2)]),True)
check('output-side substitution',substitutes(eq({'A':1},{'E':1}),eq({'A':1},{'Z':1}),[conflict(side='outputs')]),True)
check('mismatched coefficient',substitutes(eq({'E':2}),eq({'Z':1}),[conflict()]),False)
check('addition cannot use fake source',substitutes(eq({'E':1}),eq({'E':1,'Z':1}),[conflict()]),False)
check('deletion cannot use fake counterpart',substitutes(eq({'E':1,'Z':1}),eq({'Z':1}),[conflict()]),False)
check('partial surviving quantity cannot be disguised as substitution',substitutes(eq({'E':2}),eq({'E':1,'Z':1}),[conflict()]),False)
check('wrong side',substitutes(eq({'E':1}),eq({'Z':1}),[conflict(side='outputs')]),False)
check('duplicate conflict',substitutes(eq({'E':1}),eq({'Z':1}),[conflict(),conflict()]),False)
check('extra unevidenced residual',substitutes(eq({'E':1,'A':1}),eq({'Z':1,'B':1}),[conflict()]),False)
check('spurious conflict no actual difference',substitutes(eq({'E':1}),eq({'E':1}),[conflict()]),False)
check('bool coefficient invalid integer',substitutes(eq({'E':1}),eq({'Z':1}),[conflict(q=True)]),False)
check('net-neutral boundary changes still need both side dispositions',substitutes(eq({'E':1},{'E':1}),eq({'Z':1},{'Z':1}),[conflict()]),False)
check('both sides fully covered without net cancellation',substitutes(eq({'E':1},{'E':1}),eq({'Z':1},{'Z':1}),[conflict(),conflict(side='outputs')]),True)
p=O/'root-disposition-control-results.json';assert not p.exists();p.write_text(json.dumps({'scope':'Algebraic review of root proposed bounds, not implemented schema validation. Symbols are not issued identifiers.','checks':checks,'passed':len(checks)},indent=2)+'\n');print({'checks':len(checks),'all_passed':True})
