"""Independent bounded successor review. All writes are under OUT."""
from pathlib import Path
import json,hashlib,datetime,runpy,sys
OUT=Path(__file__).resolve().parent
SRC=Path('/private/tmp/pathwaymech-next-268-primary-corrections')
AUTHOR=Path('/private/tmp/pathwaymech-next-268-primary')
PRIOR=Path('/private/tmp/pathwaymech-next-268-independent-primary-review')
assert OUT==Path('/private/tmp/pathwaymech-next-268-independent-primary-corrections-review')
assert sys.dont_write_bytecode
def read(p):return json.loads(Path(p).read_text())
def write(n,x):(OUT/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def bind(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def same(a,b):return a['sha256']==b['sha256'] and a['bytes']==b['bytes']
checks=[]
def check(n,v,detail=None):checks.append({'check':n,'passed':bool(v),'detail':detail});assert v,n
original_raw=(AUTHOR/'primary-claim-ledger.json').read_bytes();original=json.loads(original_raw);corrected=read(SRC/'primary-claim-ledger.corrected.json')
check('original copy byte exact',original_raw==(SRC/'primary-claim-ledger.original.json').read_bytes())
check('31 original/corrected unique same-order IDs',len(original)==len(corrected)==31 and len({c['id'] for c in corrected})==31 and [c['id'] for c in original]==[c['id'] for c in corrected])
changed=[];unchanged=[];bindings=[]
expected_fields={'N268-P16':['controls','disposition','sources'],'N268-P20':['construct_preparation','controls','disposition','experiment','experimental_contexts','sources','statement','taxon_strain'],'N268-P23':['controls','disposition','sources','statement']}
for a,b in zip(original,corrected):
 fields=sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
 if fields:
  check('exact allowed changed fields '+a['id'],fields==expected_fields[a['id']]);changed.append({'id':a['id'],'changed_fields':fields,'before':a,'after':b})
 else:unchanged.append(a['id'])
 check('all source bindings retained '+a['id'],[{k:v for k,v in s.items() if k!='locator'} for s in a['sources']]==[{k:v for k,v in s.items() if k!='locator'} for s in b['sources']])
 for s in b['sources']:
  actual=bind(s['path']);check('source bytes and hash '+a['id']+'/'+s['source_id'],same(actual,s));bindings.append({'claim':a['id'],**actual})
check('only three specified claims changed',{r['id'] for r in changed}==set(expected_fields))
check('other28 claims unchanged',len(unchanged)==28)
check('independent field delta equals authored delta',changed==read(SRC/'exact-field-changes.json'))
check('52 source bindings preserved',len(bindings)==52)
for n in ['artifact-manifest.json','freeze-proof.json','HANDOFF.md','findings.json']:
 check('copied original review exact '+n,(SRC/'independent-review'/n).read_bytes()==(PRIOR/n).read_bytes())

# The entire source script was read before execution. Its top level only imports
# stdlib and defines functions/constants; its mutation block is under __main__.
# Import with a non-main name and call the read-only build() function only.
namespace=runpy.run_path(str(SRC/'apply_corrections.py'),run_name='independent_read_only_import')
raw,built,delta=namespace['build']()
out_raw=(json.dumps(built,indent=2)+'\n').encode();delta_raw=(json.dumps(delta,indent=2)+'\n').encode()
check('build function original bytes exact',raw==original_raw)
check('corrected ledger reproduction byte exact',out_raw==(SRC/'primary-claim-ledger.corrected.json').read_bytes())
check('field-change reproduction byte exact',delta_raw==(SRC/'exact-field-changes.json').read_bytes())
(OUT/'reproduced-primary-claim-ledger.json').write_bytes(out_raw)
(OUT/'reproduced-exact-field-changes.json').write_bytes(delta_raw)
write('independent-delta.json',{'changed':changed,'unchanged_claims':unchanged,'source_bindings':bindings,'rule':'Only locator text may change within source descriptors; original paths, sizes, hashes and source IDs are identical.'})

prior_scopes=read(PRIOR/'all25-reading-scope-dispositions.json')
source_scope={r['id']:r for r in prior_scopes['scopes']}
source_ids=['PaaI2006','PaaX2000','PaaX2004']
views={
 'PaaI2006':[AUTHOR/'reading/PaaI2006/page-003.png',AUTHOR/'reading/PaaI2006/page-007.png'],
 'PaaX2000':[AUTHOR/'reading/PaaX2000/page-004.png',AUTHOR/'reading/PaaX2000/page-006.png'],
 'PaaX2004':[AUTHOR/'originals/PaaX2004-figure-4-retry.jpg']}
fresh_text={
 'PaaI2006':'Fresh purification Methods continuation PDFp3/journal11030, catalytic-Asp Results PDFp7/journal11034 and kinetic table text context; full prior independent paper reading reused explicitly.',
 'PaaX2000':'Fresh Table I strain/plasmid definitions in extracted text; reporter Results, Table II/III complete captions/rows and relevant Methods references. Fresh full rendered pages4/6. Full prior independent paper reading reused explicitly.',
 'PaaX2004':'Fresh exact independently reproduced original HTML lines94–100, Figure4 caption and original Figure4 image. Full prior independent paper reading reused explicitly.'}
write('source-reading-and-evidence.json',{'prior_scope_owner':bind(PRIOR/'all25-reading-scope-dispositions.json'),'original_findings':bind(PRIOR/'findings.json'),'fresh_and_reused':[{'id':s,'original':source_scope[s]['original'],'fresh_text':fresh_text[s],'fresh_visuals':[bind(p) for p in views[s]],'bounded_prior_scope':source_scope[s]} for s in source_ids],'new_remote_access':False,'root_confirmations_role':'All three root confirmation receipts were read as corroboration. They do not replace this reviewer original-source assessment.','old267_worktree_read':False})

dispositions=[
 {'finding':'N268-PR01','issue':609,'claim':'N268-P16','disposition':'correction independently accepted in preparation successor','rationale':'The successor correctly separates unchanged A. evansii mutant activity before/after gel filtration, suspected host contamination of the small E. coli D61A signal, and undetectable A. evansii D75A activity. The unsupported disappearance experiment is removed. Essential-Asp support and uncertainty between general-base/covalent mechanisms remain intact.','original_locator':'PaaI2006 PDFp3/journal11030 and PDFp7/journal11034; Tables1–2 in prior complete reading.','remaining':'No new proof of a catalytic intermediate, full kinetic tag identity, or universal physiological effect.'},
 {'finding':'N268-PR02','issue':610,'claim':'N268-P20','disposition':'correction independently accepted in preparation successor','rationale':'Table II is AF15PZ chromosomal Pz-lacZ with pAFX2±pAFK5 and ±1 mM PA. Table III is AF15 with pAFPA2/pAFPA2-M and pAFX2 versus pCK01. The 30.4/1.1/4.3/1.8/4.7 values now belong only to the Pa operator-mutant experiment, with correct PaM1/5/9/16 mapping. Table III PA condition is accurately unreported rather than assumed absent or present.','original_locator':'PaaX2000 Table I PDFp2, reporter Methods/Results PDFp3, Table II PDFp4/journal12217, Table III/Figure5 PDFp6/journal12219.','remaining':'Representative experiment repeated three times is not an invented larger biological N; crude PaaX/functional effector response remain distinct from purified ligand affinity.'},
 {'finding':'N268-PR03','issue':611,'claim':'N268-P23','disposition':'correction independently accepted in preparation successor','rationale':'The successor preserves direct tested CRP/cAMP binding, no IHF shift at 100–300 nM on1 nM PPAC and shifted1 nM PR-PG control, and labels indirect action as an inference. It no longer presents an unmeasured indirect mechanism as established.','original_locator':'PaaX2004 In vitro analysis of CRP and IHF binding section, Figure4B/caption and following paragraph; exact reproduced lines98–99.','remaining':'Negative assay is condition-bounded and does not prove universal absence of IHF binding; no direct IHF→Ppac edge is added.'}
]
write('all3-correction-dispositions.json',{'corrected_ledger':bind(SRC/'primary-claim-ledger.corrected.json'),'dispositions':dispositions,'new_defects':[],'github_boundary':'No GitHub query or mutation in this review. Saved source issues609–611 remain pending retention of correction and disposition in a verified merged tree; independent preparation acceptance alone is not issue closure.','prior_review_status':'The original review remains immutable and historically correction-required. This accepted successor resolves its three preparation defects while all unaffected claim/source limitations remain governed by the original review.','other_successors':'SlyA2017 is separately accepted under independent-regulatory-followup-review; it is not silently folded into this corrected historical31-claim ledger.'})
write('findings.json',{'new_supported_defects':[],'count':0,'prior_findings_remediated_in_preparation':['N268-PR01','N268-PR02','N268-PR03'],'not_issue_closure':True})

# All package and external claim-source bindings checked again after replay.
before=read(OUT/'input-integrity-before.json');after=[];inventory=[]
for g in before['groups']:
 root=Path(g['root']);physical={str(p) for p in root.rglob('*') if p.is_file() or p.is_symlink()};expected={r['path'] for r in g['files']}
 check('complete frozen inventory unchanged '+root.name,physical==expected)
 inventory.append({'root':str(root),'physical_files':len(physical),'hidden_ignored_included':True,'exact':True})
 for r in g['files']:
  actual=bind(r['path']);assert same(actual,r);after.append(actual)
check('649 packet files unchanged',len(after)==649)
for r in before['claim_source_bindings']:assert same(bind(r['path']),r)
write('input-integrity-after.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'packet_files':after,'packet_file_count':649,'inventories':inventory,'additional_claim_source_binding_events':52,'claim_source_bindings':before['claim_source_bindings'],'all_unchanged':True})
write('verification-results.json',{'checks':checks,'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'corrected_ledger':bind(SRC/'primary-claim-ledger.corrected.json'),'script':bind(SRC/'apply_corrections.py'),'reproduction':'Read-only build() import; mutation __main__ not executed. Byte-identical ledger/delta retained in owned directory. Independent semantic review uses original evidence and exact diff; it is not inferred from reproduction alone.','all_jobs_terminal':True})
write('execution-and-scope.json',{'execution':'All source script read before importing its definitions with non-main name; only read-only build() called. Existing verified263 Python -B/no bytecode/no user site; no installs, runtime repair, children or source/maintained/Git/GitHub writes.','new_execution_failures':[],'historical_generator':'Original build_dossier.py remains byte-bound historical provenance and is explicitly superseded for P16/P20/P23. This review does not run that historical generator or rewrite it.','source_scope':'Fresh targeted original text and five visual files plus exact bounded reuse of previously accepted whole-paper readings; not a fresh complete scientific reread of all31claims. All28 unaffected entries compared exactly.','issue_status_scope':'Saved issue creation/disposition receipts read; no live GH status claim or issue closure performed.','broader_limits':'Other source/identity/construct/curation obligations remain open. Actual267 merge/rebind is parent-owned; no removed267worktree access.'})
(OUT/'ASSESSMENT.md').write_text('''# Independent primary-correction acceptance

All three corrections are accepted within the preparation scope. N268-P16 accurately separates the PaaI purification control, suspected E. coli D61A contamination and A. evansii D75A null activity. N268-P20 accurately separates the Table II Pz induction experiment from Table III Pa operator mutants, with their own strains, reporter constructs and PA-condition bounds. N268-P23 now treats indirect IHF action as an inference while preserving the negative PPAC/positive PR-PG control.

Original source evidence was freshly rechecked in the relevant text and five visual files. Exact prior complete-paper reading scopes are bound and reused, rather than represented as new whole-paper reading. Root confirmations corroborate the findings but are not the basis of independent acceptance.

Only P16/P20/P23 changed; all other28 entries are semantically identical. All52 original source paths, hashes, byte counts and source identifiers are unchanged; only the three locators are refined. The full exact field delta was independently reconstructed. The audited successor build() function reproduces the corrected ledger and delta byte-for-byte without running its write-bearing main block. The original historical generator remains unchanged and superseded for these fields.

All23 correction-source files,502 primary files and124 original-review files remained unchanged (649 total), with complete hidden/ignored-aware inventories before and after. All52 claim-source binding events were rechecked, including originals outside those packet directories. No new defect was found. Issues609–611 are remediation-accepted in preparation, but closure still requires correction/disposition retention in a verified merged tree. No GitHub action or maintained record change was performed.

This acceptance does not close other original scientific gaps, O02/O03, or maintained curation gates. The separately accepted SlyA2017 reading successor is not silently inserted into the historical31-claim correction ledger. Original and review packets remain immutable.
''')
(OUT/'HANDOFF.md').write_text('''# Independent primary-correction review handoff

Target `/private/tmp/pathwaymech-next-268-primary-corrections`:21listed/23physical; manifest9576dc6819fa46540cc36ad12c31a5f5adc6555db674c4c7cf722977fe0ec73f; HANDOFFaa1d88a329e188d5261176a2d125d4f74d9f07afd1de619d5c609ea3540f0f63. Corrected ledgerc5a4858ea8c2c8a2982df9675383b3cf7bf9dd91c63c0eb281eadd47c43cfa0b. Complete author HANDOFF, all three corrected entries and exact delta, source-script, verification/disposition records, original findings, root confirmations and issue texts were read.

Decision: all three corrections independently accepted in preparation; zero new defects. `all3-correction-dispositions.json` resolves N268-PR01/P16/#609, N268-PR02/P20/#610 and N268-PR03/P23/#611 at that bounded level. Keep issues open until correction and disposition are retained in a verified merged tree; this review does not close them.

`source-reading-and-evidence.json` binds fresh targeted original reading and five visual files plus exact prior independent whole-paper scopes. `independent-delta.json` accounts for all fields,28 unchanged claims and52 preserved original source bindings. `verification-results.json` records exact independent comparison and byte reproduction via audited read-only build(), with the write-bearing main block unexecuted. Reproduced ledger and delta are owned artifacts, not source overwrites.

`input-integrity-before.json`/`input-integrity-after.json` verify649 unchanged packet files across exact23/502/124 inventories and all52 claim-source binding events. `execution-and-scope.json` states limits. No removed267worktree reads, no installs/repairs/children, no maintained/Git/GitHub mutations. Other source/identity/curation obligations remain open; SlyA2017 is its own separately accepted successor.

Manifest excludes only itself and freeze-proof.json. Freeze binds manifest/HANDOFF and exact counts; no self-hash claim. All jobs terminal before freeze.
''')
assert not (OUT/'artifact-manifest.json').exists() and not (OUT/'freeze-proof.json').exists()
ex={'artifact-manifest.json','freeze-proof.json'};rows=[{**bind(p),'relative_path':str(p.relative_to(OUT))} for p in sorted(OUT.rglob('*')) if p.is_file()]
write('artifact-manifest.json',{'files':rows,'listed_files':len(rows),'excluded':sorted(ex),'hidden_ignored_included':True})
write('freeze-proof.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':bind(OUT/'artifact-manifest.json'),'handoff':bind(OUT/'HANDOFF.md'),'listed_files':len(rows),'physical_files':len(rows)+2,'self_excluded':sorted(ex),'decision':'all three corrections accepted in preparation; no new defects; issue closure pending retained merged disposition'})
assert {str(p.relative_to(OUT)) for p in OUT.rglob('*') if p.is_file()}=={r['relative_path'] for r in rows}|ex
assert all(same(r,bind(r['path'])) for r in rows)
print(json.dumps({'listed':len(rows),'physical':len(rows)+2,'passed_checks':len(checks),'manifest':bind(OUT/'artifact-manifest.json'),'handoff':bind(OUT/'HANDOFF.md'),'freeze':bind(OUT/'freeze-proof.json')}))
