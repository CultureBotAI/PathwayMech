# D03 design disposition addendum

Accept root’s explicit `detail_only_participant_ids` policy as the bounded correction for N268-D03. It separates display provenance from biological identity and preserves isolated or shared source components. All declarations remain in component tables and export; detail-only scope must remain visible and record-specific.

Generic validation checks the named exclusions and nested use. Source-specific coverage still must reject classifying any native member as detail-only. This does not approve implemented behavior or scientific curation. The original25-file independent design review remains unchanged, including its historical pending disposition.
