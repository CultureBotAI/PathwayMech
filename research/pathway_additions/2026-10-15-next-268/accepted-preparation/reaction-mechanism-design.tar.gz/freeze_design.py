from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os

O = Path(__file__).parent

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def save(name, obj):
    with (O / name).open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')

def inventory(root):
    rows = []
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            assert not (Path(parent) / name).is_symlink()
        for name in files:
            p = Path(parent) / name
            rows.append({'path': str(p.relative_to(root)), 'bytes': p.stat().st_size, 'sha256': sha(p)})
    return sorted(rows, key=lambda r: r['path'])

bindings = json.loads((O / 'input-bindings-before.json').read_text())
for row in bindings['files']:
    assert sha(Path(row['source'])) == sha(O / row['copy']) == row['sha256']
    assert Path(row['source']).stat().st_size == row['bytes']
source_review = Path('/private/tmp/pathwaymech-next-268-reaction-review-completion')
manifest = json.loads((source_review / 'artifact-manifest.json').read_text())
actual = {r['path']: r for r in inventory(source_review)}
assert len(actual) == 70
assert set(actual) == {r['path'] for r in manifest['files']} | {'artifact-manifest.json', 'freeze-proof.json'}
for row in manifest['files']:
    assert actual[row['path']] == row
assert sha(source_review / 'artifact-manifest.json') == '56062cf4f38e9c9373326e1ed4b03d8c380b4206fd5062005ab6724b693b73be'
base = json.loads((O / 'inputs/external/00-actual-merged-baseline.json').read_text())
W = Path(bindings['worktree'])
expected_records = {r['path'] for r in base['records']}
assert {str(p.relative_to(W)) for p in (W / 'data/pathways').rglob('*.yaml')} == expected_records
for row in base['records']:
    assert sha(W / row['path']) == row['sha256']
assert json.loads((O / 'current-contract-probes.json').read_text())['status'] == 'passed'
assert (O / 'contract-probes.stderr.log').read_bytes() == b''
save('verification.json', {'utc': datetime.now(timezone.utc).isoformat(), 'status': 'passed', 'input_bindings_unchanged': len(bindings['files']), 'source_review_physical_files_unchanged': len(actual), 'baseline_pathway_records_unchanged': len(base['records']), 'probe_exit_code': 0, 'hidden_and_ignored_included': True, 'design_only': True, 'CHEM02': 'open', 'maintained_changes': False, 'scientific_review': False})
rows = inventory(O)
save('artifact-manifest.json', {'files': rows, 'listed_files': len(rows), 'hidden_and_ignored_included': True})
save('freeze-proof.json', {'frozen_utc': datetime.now(timezone.utc).isoformat(), 'listed_files': len(rows), 'physical_files': len(rows) + 2, 'manifest_sha256': sha(O / 'artifact-manifest.json'), 'handoff_sha256': sha(O / 'HANDOFF.md'), 'design_sha256': sha(O / 'DESIGN.md'), 'status': 'proposal_for_independent_design_review'})
assert len(inventory(O)) == len(rows) + 2
print((O / 'freeze-proof.json').read_text())
