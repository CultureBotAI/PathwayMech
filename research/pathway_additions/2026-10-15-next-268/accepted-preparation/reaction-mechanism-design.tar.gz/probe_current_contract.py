"""Read-only current-contract probes; synthetic mutations stay outside the repo."""
from copy import deepcopy
from pathlib import Path
import json
import yaml
from pathwaymech.schema import validate_record, ValidationError
from pathwaymech.strict import validator, TARGET_CLASS

O = Path(__file__).parent
record = yaml.safe_load((O / 'inputs/worktree/data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml').read_text())
checker = validator()
assert not list(checker.validate(record, TARGET_CLASS).results)
validate_record(record)
results = []

candidate = deepcopy(record)
candidate['reaction_mechanisms'] = []
checked = validate_record(candidate)
closed = [r.message for r in checker.validate(candidate, TARGET_CLASS).results]
assert closed and not hasattr(checked, 'reaction_mechanisms')
results.append({'case': 'new_root_field', 'strict_rejected': True, 'semantic_validator_currently_discards_unknown_root_field': True, 'messages': closed, 'implication': 'Both LinkML and semantic/dataclass code need explicit support; merely adding YAML silently loses the content on the non-strict path.'})

candidate = deepcopy(record)
old = candidate['reactions'][0]['id']
candidate['reactions'][0]['id'] = 'pathwaymech:unissued-step'
for edge in candidate['mechanistic_edges']:
    for field in ('subject', 'object'):
        if edge[field] == old:
            edge[field] = 'pathwaymech:unissued-step'
try:
    validate_record(candidate)
except ValidationError as e:
    errors = str(e)
else:
    raise AssertionError('Unexpected made-up reaction CURIE acceptance')
closed = [r.message for r in checker.validate(candidate, TARGET_CLASS).results]
assert closed
results.append({'case': 'invented_reaction_curie', 'both_validators_rejected': True, 'semantic_error': errors, 'strict_messages': closed, 'implication': 'A new biological CURIE or namespace exemption is not an existing legitimate representation.'})

candidate = deepcopy(record)
reactions = {r['id'] for r in candidate['reactions']}
edge = next(e for e in candidate['mechanistic_edges'] if e['subject'] in reactions)
edge['endpoint_qualifiers'] = [{'endpoint': 'subject', 'kind': 'molecular_state', 'description': 'Synthetic probe only: an isolated substep.', 'evidence': deepcopy(edge['evidence'][:1])}]
try:
    validate_record(candidate)
except ValidationError as e:
    errors = str(e)
else:
    raise AssertionError('Unexpected reaction endpoint qualification acceptance')
assert 'protein or complex participant' in errors
results.append({'case': 'reaction_endpoint_qualifier', 'semantic_rejected': True, 'semantic_error': errors, 'implication': 'Existing qualified protein display nodes cannot be reused as an activity identity workaround.'})

with (O / 'current-contract-probes.json').open('x') as f:
    json.dump({'status': 'passed', 'scope': 'Three synthetic read-only shape probes against unchanged actual baseline; not scientific validation or whole-corpus tests.', 'results': results}, f, indent=2)
    f.write('\n')
print('Three current-contract shape probes confirmed the representation limits.')
