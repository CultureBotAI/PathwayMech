# Reaction mechanism representation design

Recommend a new nested, evidence-bearing `reaction_mechanisms` field. Local typed step keys are curatorial claim coordinates; all biological participants and the parent reaction retain independently verified external IDs. Preserve the full nine-member native graph, then display and export the detailed two-step PaaJ/PaaG mechanism without relabelling the issued net or inventing a reaction CURIE.

`DESIGN.md` specifies the closed shape, exact net reconciliation, protein-construct qualifiers, proposal status, source conflicts, multiple graph rendering, KGX preservation, implementation owners and adversarial acceptance cases. Source/chemical disagreement has a separate `alternative_interpretation` profile: E/Z oxepin and constitutionally different LHQ cannot be normalized into equality. Every differing boundary term needs a reviewed evidence-backed disposition; unissued/unobserved material states remain explicit hypothesis prose, not invented chemical nodes.

KGX keeps the complete detail graph and all reference metadata in the parent reaction’s record-specific `source_contexts`. It never rewrites nested edges onto the native net. Consumers seeking the detailed mechanism must parse that context; ordinary KGX endpoints alone do not contain the additional local statement graph.

Bound baseline: commit `2c27fc819bac17ef05e191830346d7a32248c97c`, tree `8de7191ed69ec355c6442cb45179f5effc9ee137`, `/private/tmp/pathwaymech-next-268-20261015`. The 35 exact input copies and hashes are in `input-bindings-before.json`. Three read-only synthetic shape probes document why current schema/validators do not already supply this representation. No maintained edits, runtime changes, installation, Git/GitHub mutation or scientific curation occurred.

This is a design proposal for root adjudication and independent adversarial design review. CHEM02 and unresolved primary/chemical evidence remain open; representation support does not settle biology. The preceding independent source review is separately frozen at `/private/tmp/pathwaymech-next-268-reaction-review-completion` and remains unchanged.
