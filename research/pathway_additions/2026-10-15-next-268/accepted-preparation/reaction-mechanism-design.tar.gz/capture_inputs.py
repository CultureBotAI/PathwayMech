from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil

O = Path(__file__).parent
W = Path('/private/tmp/pathwaymech-next-268-20261015')
paths = [
    'CLAUDE.md', '.claude/skills/add-pathway/SKILL.md',
    'docs/CURATION.md', 'docs/HARMONIZATION.md', 'docs/CAUSAL_GRAPHS.md',
    'docs/IDENTIFIERS.md', 'docs/record-review-profile.md', 'docs/record-reviews.md',
    'src/pathwaymech/schema/pathwaymech.yaml', 'src/pathwaymech/schema.py',
    'src/pathwaymech/strict.py', 'src/pathwaymech/identifiers.py',
    'src/pathwaymech/kgx.py', 'src/pathwaymech/graph_view.py', 'src/pathwaymech/cli.py',
    'src/pathwaymech/edge_identity.py', 'src/pathwaymech/curation.py',
    'src/pathwaymech/assets/pathway-network.js', 'src/pathwaymech/assets/pathway-network.css',
    'tests/test_graph_context.py', 'tests/test_linkml_schema.py', 'tests/test_graph_view.py',
    'tests/test_graph_pages.py', 'tests/test_graph_interaction.py',
    'tests/graph_interaction_harness.cjs', 'tests/test_kgx_export.py',
    'data/pathways/benzoyl-coa-degradation-iii-anaerobic.yaml', 'justfile',
]
rows = []
for name in paths:
    source, copy = W / name, O / 'inputs/worktree' / name
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, copy)
    raw = source.read_bytes()
    assert raw == copy.read_bytes()
    rows.append({'source': str(source), 'copy': str(copy.relative_to(O)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
external = [
    '/private/tmp/pathwaymech-next-268-ci/actual-merged-baseline.json',
    '/private/tmp/pathwaymech-next-268-reaction-review-completion/ASSESSMENT.md',
    '/private/tmp/pathwaymech-next-268-reaction-review-completion/review-dispositions.json',
    '/private/tmp/pathwaymech-next-268-reaction-review-completion/artifact-manifest.json',
    '/private/tmp/pathwaymech-next-268-reaction-review-completion/freeze-proof.json',
    '/private/tmp/pathwaymech-next-268-chemistry/ASSESSMENT.md',
    '/private/tmp/pathwaymech-next-268-independent-chemistry-review/HANDOFF.md',
]
for i, name in enumerate(external):
    source = Path(name)
    copy = O / 'inputs/external' / f'{i:02d}-{source.name}'
    copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, copy)
    raw = source.read_bytes()
    assert raw == copy.read_bytes()
    rows.append({'source': str(source), 'copy': str(copy.relative_to(O)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
result = {'captured_utc': datetime.now(timezone.utc).isoformat(), 'worktree': str(W), 'head': '2c27fc819bac17ef05e191830346d7a32248c97c', 'tree': '8de7191ed69ec355c6442cb45179f5effc9ee137', 'git_observation': 'Direct git rev-parse HEAD HEAD^{tree} and git status --short --untracked-files=all returned these hashes and clean status before capture.', 'files': rows}
with (O / 'input-bindings-before.json').open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(f'Captured {len(rows)} exact design inputs; no worktree writes.')
