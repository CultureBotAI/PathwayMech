#!/usr/bin/env python3
"""Check the YAML directly against retained XML, not only generated coverage counts."""
import pathlib,json,yaml,hashlib,xml.etree.ElementTree as ET,collections
P=pathlib.Path(__file__).resolve().parent; read=lambda n:json.loads((P/n).read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
r=yaml.safe_load((P/'phenylacetate-degradation-i-aerobic.native-draft.yaml').read_text());sources={s['frameid']:s for s in read('native-original-provenance.json')};checks=[]
def ck(name,ok):checks.append({'check':name,'passed':bool(ok)});assert ok,name
roots={}
for f,s in sources.items():
 b=(P/s['retained_path']).read_bytes();ck('original-sha:'+f,sha(b)==s['original']['sha256']);root=ET.fromstring(b);target=next(e for e in root if e.get('frameid')==f);ck('original-full:'+f,target.get('detail')=='full');roots[f]=target
native_members=[e.get('frameid') for s in roots['PWY0-321'].findall('reaction-list') for e in s];ck('all9exactmembers',set(native_members)=={n['id'].split(':',1)[1] for n in r['reactions']} and len(native_members)==9)
byid={e['id']:e for e in r['mechanistic_edges']};coverage=read('source-to-draft-material-membership-component-coverage.json');seen=[]
for c in coverage:
 if not c['source_key'].startswith('material-occurrence:'):continue
 _,f,side,index=c['source_key'].split(':');slot=roots[f].findall(side)[int(index)-1];compound=slot.find('Compound').get('frameid');coeff=slot.findtext('coefficient');e=byid[c['draft_edges'][0]];direction=next(n['direction'] for n in r['reactions'] if n['id']=='MetaCyc:'+f);inp=(side=='left')==(direction=='left_to_right')
 ck(c['source_key']+':material',compound==c['native_material']);ck(c['source_key']+':coefficient',coeff==c['raw_coefficient']);ck(c['source_key']+':edge',(e['subject'],e['predicate'],e['object'])==(('MetaCyc:'+compound,'consumes','MetaCyc:'+f) if inp else ('MetaCyc:'+f,'produces','MetaCyc:'+compound)));seen.append(compound)
ck('40occurrences22materials',len(seen)==40 and len(set(seen))==22)
for a in read('all25-activity-source-to-draft-coverage.json'):
 f=a['id'].split(':',1)[1]
 # Excluded originals remain manifest-bound via input packet; included source references are local.
 source=pathlib.Path(a['owner']['path']);b=source.read_bytes();ck('activity-sha:'+f,sha(b)==a['owner']['sha256']);target=next(e for e in ET.fromstring(b) if e.get('frameid')==f)
 ck('activity-enzyme:'+f,[e.get('frameid') for s in target.findall('enzyme') for e in s]==a['enzyme']);ck('activity-reaction:'+f,[e.get('frameid') for s in target.findall('reaction') for e in s]==a['reaction'])
for e in r['mechanistic_edges']:
 for ev in e['evidence']:ck('edge-evidence:'+e['id'],ev['reference_id'] in {q['id'] for q in r['references']} and len(ev['source_assertion'])<=400 and 'source_locator' in ev)
for ref in r['references']:
 f=ref['id'].split(':',1)[1];ck('reference-sha:'+f,ref['source_sha256']==sources[f]['original']['sha256'])
ck('no-bare-net-catalysis',not any(e['predicate']=='catalyzes' and e['object']=='MetaCyc:RXN0-6512' for e in r['mechanistic_edges']))
ck('all94sourceobjects',len(read('all94-native-source-object-dispositions.json'))==94)
ck('all1731directslots',sum(x['slots'] for x in read('all94-native-source-object-dispositions.json'))==1731)
# Recheck full frozen packet manifests after all draft production.
integrity=[]
for initial in read('input-integrity-before.json'):
 mpath=pathlib.Path(initial['manifest']['path']);mbytes=mpath.read_bytes();ck('manifest-unchanged:'+str(mpath),sha(mbytes)==initial['manifest']['sha256']);m=json.loads(mbytes);root=pathlib.Path(initial['root'])
 for item in m['files']:
  b=(root/item['path']).read_bytes();ck('input:'+str(root/item['path']),len(b)==item['bytes'] and sha(b)==item['sha256'])
 integrity.append({'root':str(root),'manifest_sha256':sha(mbytes),'files_verified':len(m['files']),'all_unchanged':True})
(P/'original-replay-checks.json').write_text(json.dumps({'checks':checks,'passed':len(checks),'failed':0,'input_integrity_after':integrity},indent=2)+'\n');print('passed',len(checks))
