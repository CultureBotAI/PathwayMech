#!/usr/bin/env python3
"""Build a source-faithful native intermediate; no maintained writes or new identities."""
import pathlib,json,hashlib,html,re,shutil,xml.etree.ElementTree as ET,collections,yaml,sys,importlib.util
P=pathlib.Path(__file__).resolve().parent
D=pathlib.Path('/private/tmp/pathwaymech-next-268-discovery'); N=pathlib.Path('/private/tmp/pathwaymech-next-268-native'); I=pathlib.Path('/private/tmp/pathwaymech-next-268-independent-native-review'); B=pathlib.Path('/private/tmp/pathwaymech-next-268-merged-baseline-rebind')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
def save(f,x): (P/f).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def bind(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def clean(s):return html.unescape(re.sub('<[^>]*>','',s)).strip()
# Bind every manifested input before use, including hidden and ignored paths.
integrity=[]
for root in (D,N,I,B):
 manifest=root/('manifest.json' if root==D else 'artifact-manifest.json'); m=load(manifest); files=m['files']
 for r in files:
  f=root/r['path']; b=f.read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],str(f)
 integrity.append({'root':str(root),'manifest':bind(manifest),'verified_listed_files':len(files),'all_passed':True})
save('input-integrity-before.json',integrity)
objects=load(D/'native-all-original-full-objects.json'); O={r['frameid']:r for r in objects}
route=load(N/'complete-route-material-activity-replay.json'); activity=load(N/'all25-activity-biological-dispositions.json'); core=load(N/'all14-core-biological-identity-ledger.json'); assemblies=load(N/'all3-core-assemblies.json'); tax=load(N/'complete-issuing-taxonomy-ledger.json')['all_full_issuing_records']
(P/'inputs').mkdir(exist_ok=True); (P/'originals').mkdir(exist_ok=True)
for root,names in [(N,['complete-route-material-activity-replay.json','all25-activity-biological-dispositions.json','all14-core-biological-identity-ledger.json','all3-core-assemblies.json','all32-discovery-biological-lead-dispositions.json','native-gene-identity-ledger.json','scientific-conflicts-and-open-gaps.json','complete-issuing-taxonomy-ledger.json']),(I,['claim-dispositions.json','preserved-conflicts-and-gaps.json','review-summary.json']),(D,['native-all-original-full-objects.json'])]:
 for name in names:shutil.copyfile(root/name,P/'inputs'/name)
for rel in ['src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml']:
 out=P/'contracts'/pathlib.Path(rel).name;out.parent.mkdir(exist_ok=True);shutil.copyfile(B/'implementation-current'/rel,out)
refs={};coverage=[];nodeproof=[];edgeproof=[];sourcebind={}
curie=lambda f:'MetaCyc:'+f
def owner(frame):
 r=O[frame];f=D/r['file'];b=f.read_bytes();assert sha(b)==r['sha256'];out=P/'originals'/f.name;out.write_bytes(b)
 receipt=f.with_name(f.name+'.receipt.json');u=None
 if receipt.exists():
  rr=load(receipt);u=rr.get('url') or rr.get('requested_url');shutil.copyfile(receipt,out.with_name(out.name+'.receipt.json'))
 sourcebind[frame]={'frameid':frame,'type':r['type'],'original':bind(f),'retained_path':str(out.relative_to(P)),'retrieval_url':u,'xml_base':ET.fromstring(b).attrib.get('{http://www.w3.org/XML/1998/namespace}base'),'version':'27.0'}
 return sourcebind[frame]
def label(frame):
 r=O[frame];return clean(next((s['text'] for s in r['slots'] if s['name']=='common-name'),frame)) or frame
def ref(frame):
 if frame not in refs:
  ob=owner(frame);refs[frame]={'id':curie(frame),'title':f'MetaCyc 27.0 native {O[frame]["type"]}: {frame}','source_sha256':ob['original']['sha256'],'source_version':'MetaCyc 27.0; retained issuing XML','url':'https://biocyc.org/META/NEW-IMAGE?object='+frame}
 return curie(frame)
def loc(frame,slots):return f"ptools-xml/{O[frame]['type']}[@frameid='{frame}']/{slots}"
def evidence(frame,assertion,slots):
 assert len(assertion)<=400,(frame,len(assertion));return {'reference_id':ref(frame),'source_assertion':assertion,'source_locator':loc(frame,slots)}
record={'id':curie('PWY0-321'),'label':label('PWY0-321'),'description':('Intermediate source-faithful projection of the nine native MetaCyc members of aerobic phenylacetate degradation. Native material identities, reaction sides and route direction are retained without cross-authority chemical normalization. Native RXN0-6512 is a coupled/net representation; isolated PaaJ thiolysis and subsequent PaaG isomerization must be integrated separately. Source catalytic annotations are not claims about every assay construct or elementary mechanism. Listed taxa are source/reference contexts, not whole-route demonstrations in each taxon. The native Paraburkholderia caledonica activity attribution conflicts with the cited Price strain and is excluded from core catalysis. Native regulation and omitted or excluded activity contexts are preserved in the companion coverage ledger. This is not complete final curation: primary corrections, constructs, regulation, detailed mechanism and identifier authority integration remain required.'),'pathway_type':'degradation','taxa':[],'participants':[],'reactions':[],'mechanistic_edges':[],'references':[]}
ref('PWY0-321')
def node(field,frame,category=None,extra=None):
 n={'id':curie(frame),'label':label(frame)}
 if category:n['category']=category
 if extra:n.update(extra)
 record[field].append(n);ob=owner(frame);nodeproof.append({'draft_path':f'{field}[id={curie(frame)}]','source':ob,'source_locator':loc(frame,'common-name'),'label_rule':'Exact native common-name with presentation HTML removed; frame ID fallback if omitted.'});return n

def edge(kind,subject,predicate,obj,ev,source_key):
 eid=f'native-{kind}-{len(record["mechanistic_edges"])+1:03d}';e={'id':eid,'subject':subject,'predicate':predicate,'object':obj,'evidence':[ev]};record['mechanistic_edges'].append(e);edgeproof.append({'draft_path':f'mechanistic_edges[id={eid}]','source_key':source_key,'evidence':ev,'interpretation_scope':'native structured-source assertion; no newly inferred primary experimental result'});return eid
# The seven taxa are scoped in the description and ledger; no whole-pathway taxon assertion is emitted.
for t in tax:
 if t['id'] in {'NCBITaxon:134536','NCBITaxon:59406','NCBITaxon:511145','NCBITaxon:566546','NCBITaxon:198931','NCBITaxon:303','NCBITaxon:83333'}:
  record['taxa'].append({'id':t['id'],'label':t['name']});nodeproof.append({'draft_path':f'taxa[id={t["id"]}]','source':t['owner'],'source_locator':f'TaxaSet/Taxon[TaxId="{t["id"].split(":")[1]}"]/ScientificName','scope':'native species or reference taxon; NCBITaxon:303 is parent only for native P. putida U; 83333 is K-12 reference, not inferred assay stock'})
for r in route['all22_materials']:node('participants',r['native_material'],'small_molecule')
for r in core:node('participants',r['native_id'].split(':',1)[1],'protein')
for r in assemblies:node('participants',r['native_id'].split(':',1)[1],'complex')
for r in route['all9_reactions']:
 f=r['native_reaction'];node('reactions',f,None,{'direction':r['physiology'].replace('-','_')})
 ev=evidence('PWY0-321',f'The native reaction-list explicitly includes {f}.',f"reaction-list/Reaction[@frameid='{f}']")
 eid=edge('member',curie(f),'part_of',record['id'],ev,'native-member:'+f);coverage.append({'source_key':'native-member:'+f,'draft_edges':[eid],'status':'represented'})
 for side,occurrences in r['all_sides'].items():
  for k,m in enumerate(occurrences):
   fmat=m['native_material'];raw=m['raw_coefficient'];unit=m['equation_unit_coefficient'];inp=(side=='left')==(r['physiology']=='left-to-right');pred='consumes' if inp else 'produces'
   assertion=f'The native {side} slot contains {fmat}; coefficient '+(f'is {raw}.' if raw else 'is omitted (unit in equation replay).')+f' Pathway direction is {r["physiology"]}; this occurrence is '+('input.' if inp else 'output.')
   if f=='RXN0-6512':assertion+=' This is the native coupled/net equation, not isolated PaaJ chemistry.'
   ev=evidence(f,assertion,f"{side}[{k+1}]/Compound[@frameid='{fmat}']; reaction-direction; PWY0-321/reaction-layout")
   key=f'material-occurrence:{f}:{side}:{k+1}';eid=edge('material',curie(fmat) if inp else curie(f),pred,curie(f) if inp else curie(fmat),ev,key)
   coverage.append({'source_key':key,'native_material':fmat,'native_side':side,'raw_coefficient':raw,'equation_unit_coefficient':unit,'draft_edges':[eid],'status':'represented'})
# Native enzyme annotations; preserve the known net attribution outside bare catalysis.
activity_coverage=[]
for a in activity:
 f=a['id'].split(':',1)[1];enz=a['enzyme'][0];rxn=a['reaction'][0];ids=[]
 if a['disposition'].startswith('core') or a['disposition']=='supporting alternate preparation':
  if rxn=='RXN0-6512':
   node('participants',f,'molecular_activity');ev=evidence(f,'The native activity enzyme slot identifies MONOMER-15952. Its reaction pointer is the coupled/net RXN0-6512; this edge preserves the protein/activity annotation without asserting isolated PaaJ forms the net E-2,3 product.',"enzyme/Protein[@frameid='MONOMER-15952']; reaction")
   ids=[edge('activity',curie(enz),'enables',curie(f),ev,'native-activity:'+f)];status='qualified activity preserved; net catalytic assertion withheld for primary integration'
  else:
   assertion=f'The native enzyme slot assigns {enz} to {rxn} in activity {f}. This is the catalog annotation; preparation and elementary-mechanism qualifications remain in the coverage ledger.'
   ev=evidence(f,assertion,'enzyme/Protein; reaction/Reaction; evidence; citation');ids=[edge('catalysis',curie(enz),'catalyzes',curie(rxn),ev,'native-activity:'+f)];status='native catalytic annotation represented'
 else:status='retained excluded or identity-only context; no catalytic edge'
 activity_coverage.append({**a,'draft_edges':ids,'draft_disposition':status})
for a in assemblies:
 f=a['native_id'].split(':',1)[1]
 for k,c in enumerate(a['components']):
  m=c['native_monomer'].split(':',1)[1];mult=f'Explicit coefficient is {c["coefficient"]}.' if c['coefficient'] else 'Coefficient is omitted; copy number remains unknown.'
  ev=evidence(f,f'The native complex component slot identifies {m}. {mult} This source assembly is distinct from preparation-specific stable complexes.',f"component[{k+1}]/Protein[@frameid='{m}']; coefficient")
  key=f'component:{f}:{m}';eid=edge('component',curie(m),'part_of',curie(f),ev,key);coverage.append({'source_key':key,'draft_edges':[eid],'coefficient':c['coefficient'],'status':'represented; multiplicity in evidence, not invented edge field'})
# Source regulation is fully retained but unclosed regulator identity is not fabricated.
reg=O['REG0-12033'];owner('REG0-12033')
regcoverage={'source':reg,'disposition':'Native negative regulation statement retained in source ledger; no graph edge in this intermediate. CPD0-2558 is only a pointer in this accepted native corpus, without a complete issuing Compound body. Integrate the separately accepted regulatory/chemistry successor before selecting its exact ID. Rates/data-not-shown proposal is not a measured binding constant.','draft_edges':[]}
record['references']=list(refs.values())
(P/'phenylacetate-degradation-i-aerobic.native-draft.yaml').write_text('# Intermediate native source projection; not final curated record. See HANDOFF.md and coverage ledgers.\n'+yaml.safe_dump(record,sort_keys=False,allow_unicode=True,width=100))
save('source-to-draft-material-membership-component-coverage.json',coverage);save('all25-activity-source-to-draft-coverage.json',activity_coverage);save('native-regulatory-coverage.json',regcoverage);save('draft-to-source-nodes.json',nodeproof);save('draft-to-source-edges.json',edgeproof);save('native-original-provenance.json',list(sourcebind.values()))
# Every discovery source object is accounted for; retained full slots avoid reducing exclusions to token matches.
represented={r['id'].split(':',1)[1] for field in ('participants','reactions') for r in record[field]}|{'PWY0-321'}
save('all94-native-source-object-dispositions.json',[{'frameid':r['frameid'],'type':r['type'],'sha256':r['sha256'],'slots':len(r['slots']),'disposition':'draft node/member with full native original retained' if r['frameid'] in represented else ('activity disposition ledger' if r['type']=='Enzymatic-Reaction' else 'retained source context; not automatically added to route'),'full_slot_owner':'inputs/native-all-original-full-objects.json','draft_node_present':r['frameid'] in represented} for r in objects])
# Exact node authority inventory is intentionally separate from local schema validity.
authority=[]
for field in ('taxa','participants','reactions'):
 for n in record[field]:authority.append({'id':n['id'],'label':n['label'],'collection':field,'issuing_identity':'verified full original in accepted native/discovery or issuing taxonomy packet','maintained_authority_support':'must assess and add exact scoped source support before integration; native frame identity alone does not create a production adapter','normalization':'not performed in this native draft; preserve raw chemical/source scope'})
authority.append({'id':record['id'],'label':record['label'],'collection':'pathway','issuing_identity':'full MetaCyc 27.0 PWY0-321 original verified','maintained_authority_support':'candidate-specific pathway/source support required'})
save('identifier-authority-needs.json',authority)
# Reuse frozen merged Python contract, never import concurrently edited maintained schema.
spec=importlib.util.spec_from_file_location('native_draft_baseline_schema',P/'contracts/schema.py');module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);module.validate_record(record)
assert len(route['all9_reactions'])==len(record['reactions'])==9
assert sum(k['source_key'].startswith('material-occurrence:') for k in coverage)==40
assert len(route['all22_materials'])==22 and len(core)==14 and len(assemblies)==3 and sum(len(a['components']) for a in assemblies)==9
assert len(activity_coverage)==25 and all(a['draft_disposition'] for a in activity_coverage)
assert len({e['id'] for e in record['mechanistic_edges']})==len(record['mechanistic_edges'])
assert all(not(e['predicate']=='catalyzes' and e['object']=='MetaCyc:RXN0-6512') for e in record['mechanistic_edges'])
assert set(record)=={'id','label','description','pathway_type','taxa','participants','reactions','mechanistic_edges','references'}
save('local-validation.json',{'python_merged_contract_passed':True,'nine_native_members':9,'native_material_occurrences':40,'native_materials':22,'core_monomers':14,'core_assemblies':3,'component_rows':9,'activity_dispositions':25,'participants':len(record['participants']),'taxa':len(record['taxa']),'edges':len(record['mechanistic_edges']),'references':len(record['references']),'bare_net_PaaJ_catalysis_edges':0,'authority_gate':'not run; source adapters are integration work','scope':'intermediate native projection, not complete scientific curation or maintained validation'})
print(json.dumps(load(P/'local-validation.json')))
