#!/usr/bin/env python3
import pathlib,json,yaml,hashlib,collections
from linkml.generators.jsonschemagen import JsonSchemaGenerator
from jsonschema import Draft7Validator
P=pathlib.Path(__file__).resolve().parent; W=pathlib.Path('/private/tmp/pathwaymech-next-268-20261015'); B=pathlib.Path('/private/tmp/pathwaymech-next-268-merged-baseline-rebind')
load=lambda p:json.loads(p.read_text()); sha=lambda b:hashlib.sha256(b).hexdigest()
def save(f,x):(P/f).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
r=yaml.safe_load((P/'phenylacetate-degradation-i-aerobic.native-draft.yaml').read_text())
schema=JsonSchemaGenerator(str(P/'contracts/pathwaymech.yaml'),top_class='PathwayRecord',include_null=False,not_closed=False).serialize();(P/'contracts/pathwaymech.schema.json').write_text(schema)
errors=[{'path':list(e.absolute_path),'message':e.message} for e in Draft7Validator(json.loads(schema)).iter_errors(r)]
assert not errors,errors
save('closed-schema-validation.json',{'passed':True,'errors':errors,'source_contract_sha256':sha((P/'contracts/pathwaymech.yaml').read_bytes()),'generated_schema_sha256':sha(schema.encode()),'closed':True,'include_null':False,'runtime':'existing /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B; no install/repair'})
baseinv={x['path']:x for x in load(B/'current-physical-inventory.json')}
auth=[];inputs=[]
for fn in ('sources','ontology'):
 rel=f'data/identifier_authorities/{fn}.json';f=W/rel;b=f.read_bytes();assert sha(b)==baseinv[rel]['sha256'];x=json.loads(b);auth.append((fn,x));inputs.append({'path':str(f),'sha256':sha(b),'bytes':len(b),'same_as_actual_merged_baseline':True})
existing=load(P/'identifier-authority-needs.json'); grouped={a['id']:a for a in existing}
for ref in r['references']:
 if ref['id'] not in grouped:grouped[ref['id']]={'id':ref['id'],'collection':'references','label':ref['title'],'issuing_identity':'full issuing XML verified; source_sha256 retained','maintained_authority_support':'exact native reference/provenance source required for integration'}
for a in grouped.values():
 matches=[]
 for fn,x in auth:
  if a['id'] in x['terms']:
   t=x['terms'][a['id']];matches.append({'snapshot':fn,'term':t,'source_metadata':x['sources'].get(t.get('source'))})
 a['baseline_snapshot_exact_term_entries']=matches
 a['required_action']='Assess existing exact term label/type/source envelope against this draft and preserve already maintained records; existing term presence alone is not final validation.' if matches else 'Add exact issuing-source support and scoped parser/selection policy, or integrate a separately verified equivalent authority identity; never fabricate CURIEs.'
save('identifier-authority-needs.json',list(grouped.values()));save('baseline-authority-input-bindings.json',inputs)
core=load(P/'inputs/all14-core-biological-identity-ledger.json')
save('core-native-to-issuing-identity-crosswalk.json',[{'draft_node':x['native_id'],'contextual_name':x['contextual_name'],'issuing_reference':'UniProtKB:'+x['UniProtKB'],'native_gene_ids':x['native_gene_ids'],'native_original':x['native_original'],'issuing_UniProt_original':x['issuing_UniProt_original'],'reference_sequence_sha256':x['reference_sequence_sha256'],'reference_length':x['reference_length'],'issuing_taxon':x['issuing_taxon'],'historical_differences':x['historical_differences'],'assay_construct_scope':x['assay_construct_scope'],'qualification':'Contextual native/reference linkage from accepted identity ledger; not a claim that every historical or tagged assay construct has the reference sequence.'} for x in core])
# All six native species rows and all pathway-level metadata remain explicit.
objs=load(P/'inputs/native-all-original-full-objects.json');pwy=next(o for o in objs if o['frameid']=='PWY0-321')
save('native-pathway-scope-and-slot-dispositions.json',[{'ordinal':s['ordinal'],'slot':s['name'],'complete_source_slot':s,'disposition':('Nine members represented as reaction nodes/membership edges; source ordering/layout retained here and directions/material edges follow reviewed route projection.' if s['name'] in ('reaction-list','reaction-layout','reaction-ordering') else 'Identity or source context retained here; description/taxon context does not upgrade source range/species annotations to whole-route experimental demonstrations.')} for s in pwy['slots']])
save('authority-inventory-summary.json',{'distinct_used_ids':len(grouped),'with_exact_baseline_snapshot_entry':sum(bool(a['baseline_snapshot_exact_term_entries']) for a in grouped.values()),'without_exact_baseline_snapshot_entry':sum(not a['baseline_snapshot_exact_term_entries'] for a in grouped.values()),'all_used_ids_accounted':True,'core_reference_crosswalk':14,'native_only_material_identity_policy':'All 22 native chemical frames retained; canonical microstate normalization is separate accepted-chemistry integration work.'})
print(json.dumps(load(P/'authority-inventory-summary.json')))
