"""Hash every full site output without writing into the maintained site."""
import hashlib
import json
import sys
from pathlib import Path
import yaml
from pathwaymech.cli import render_site, load_site_history
from pathwaymech.yaml_io import load_pathway_records, pathway_files

root=Path('/private/tmp/pathwaymech-next-268-20261015')
out=Path(sys.argv[1])
bound={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in ['src/pathwaymech/graph_view.py','src/pathwaymech/mechanism_view.py','src/pathwaymech/kgx.py','src/pathwaymech/cli.py']}
out.with_suffix('.imported.json').write_text(json.dumps(bound,indent=2)+'\n')
records=load_pathway_records(root/'data/pathways')
paths={yaml.load(p.read_text(),Loader=yaml.CSafeLoader)['id']:p.relative_to(root).as_posix() for p in pathway_files(root/'data/pathways')}
outputs=render_site(records,paths,load_site_history(root))
result={'records':len(records),'files':{p:{'sha256':hashlib.sha256(v.encode()).hexdigest(),'bytes':len(v.encode())} for p,v in sorted(outputs.items())},'bound_code':bound}
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'records':len(records),'files':len(outputs),'record_pages':sum(p.startswith('records/') for p in outputs)}))
