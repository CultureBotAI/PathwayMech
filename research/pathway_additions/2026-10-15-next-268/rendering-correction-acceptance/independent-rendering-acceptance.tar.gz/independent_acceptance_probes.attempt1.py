"""Compatibility and corruption-detection probes, independent of author tests."""
import copy
import hashlib
import importlib.util
import json
import re
import runpy
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import yaml
from pathwaymech.cli import _record_page
from pathwaymech.graph_view import graph_html
from pathwaymech.kgx import render_kgx
from pathwaymech.mechanism_view import mechanism_views, mechanism_anchor
from pathwaymech.schema import validate_record

OUT=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/pathwaymech-next-268-20261015')
OLD=Path('/private/tmp/pathwaymech-next-268-graph-kgx-regression-review')
checks=[]
def check(name,value):
    checks.append({'check':name,'passed':bool(value)})
    assert value,name

legacy_factory=runpy.run_path(str(OLD/'inputs/tests/test_html_navigation.py'))['record']
expected={'nodes.tsv':'a8831c4d15c89f0af01b8449f5b148a4a0967f7640a139425b66145e96785c56','edges.tsv':'23443a2124a9730402318890eca6c6ad4c85913566dadea9bec979a52dd0cc81'}
minimal_pages=[]
for details_present in (False,True):
    for scope_present in (False,True):
        label=f'details={details_present}, scope={scope_present}'
        legacy=legacy_factory()
        minimal=SimpleNamespace(label='<Pathway>',description='ok',mechanistic_edges=[])
        for obj in (legacy,minimal):
            if details_present:obj.reaction_mechanisms=[]
            if scope_present:obj.detail_only_participant_ids=[]
        actual=render_kgx([legacy])
        check('baseline KGX bytes '+label,{k:hashlib.sha256(v.encode()).hexdigest() for k,v in actual.items()}==expected)
        page=_record_page(minimal)
        minimal_pages.append(page)
        check('minimal stylesheet and escaped title '+label,'href="../style.css"' in page and '<title>&lt;Pathway&gt;</title>' in page)
        check('no-details helper avoids participant/ID reads '+label,mechanism_views(minimal,{},{},lambda items:'')=='')
        check('no-graph helper retains empty state '+label,'No supported network is recorded' in graph_html(minimal,{},{}))
check('all absent/empty minimal outputs byte-identical',len(set(minimal_pages))==1)

spec=importlib.util.spec_from_file_location('reviewed_graph_page_tests',OUT/'inputs/tests/test_graph_pages.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
record=validate_record(yaml.safe_load((ROOT/'data/pathways/phenylacetate-degradation-i-aerobic.yaml').read_text()))
records={'transport-only-candidate':record}
page=_record_page(record)
source_match=re.search(r'<section\b[^>]*\bid="pathway-network"[^>]*>.*?</section>',page,re.S)
source=source_match.group(0)
detail_id=mechanism_anchor(record.id,record.reaction_mechanisms[0]['key'],'graph')+'-pathway-network'
detail_match=re.search(r'<section\b[^>]*\bid="'+re.escape(detail_id)+r'"[^>]*>.*?</section>',page,re.S)
detail=detail_match.group(0)
edge_pattern=r'<a class="graph-edge\b.*?</a>'
source_edge=re.search(edge_pattern,source,re.S).group(0)
detail_edge=re.search(edge_pattern,detail,re.S).group(0)
detail_row=mechanism_anchor(record.id,record.reaction_mechanisms[0]['key'],'edge',record.reaction_mechanisms[0]['edges'][0]['key'])
mutations={
 'remove_source_edge':page.replace(source,source.replace(source_edge,'',1),1),
 'remove_detail_edge':page.replace(detail,detail.replace(detail_edge,'',1),1),
 'wrong_source_predicate':page.replace(source,source.replace('data-predicate="has_part"','data-predicate="produces"',1),1),
 'wrong_detail_endpoint':page.replace(detail,detail.replace('data-object="','data-object="not-declared-',1),1),
 'remove_detail_graph_section':page.replace(detail,'',1),
 'duplicate_source_section':page.replace(source,source+source,1),
 'erase_source_evidence_row':re.sub(r'<tr id="mechanism-edge-1">.*?</tr>','<tr id="mechanism-edge-1"></tr>',page,count=1,flags=re.S),
 'erase_detail_evidence_row':re.sub(r'<tr id="'+re.escape(detail_row)+r'">.*?</tr>','<tr id="'+detail_row+'"></tr>',page,count=1,flags=re.S),
}
for name,mutant in mutations.items():
    check('probe changed intended output '+name,mutant!=page)
    caught=False
    try:
        with patch.object(module,'_record_page',return_value=mutant):
            module.test_every_published_graph_preserves_directed_edges_and_evidence_targets(records)
    except (AssertionError,KeyError):caught=True
    check('corpus checks detect '+name,caught)

# Moving intact graph sections proves named scopes, not order, select assertions.
reordered=page.replace(source,'REVIEW_SOURCE_SLOT',1).replace(detail,source,1).replace('REVIEW_SOURCE_SLOT',detail,1)
with patch.object(module,'_record_page',return_value=reordered):
    module.test_every_published_graph_preserves_directed_edges_and_evidence_targets(records)
check('source/detail checks survive graph order change',True)

# Verify complete qualifier evidence in actual detail rows, beyond the native
# triple checks; this is transport only, not scientific acceptance of these claims.
parsed=module.Page(page)
qualifiers=0
for mechanism in record.reaction_mechanisms:
    for edge in mechanism['edges']:
        row_id=mechanism_anchor(record.id,mechanism['key'],'edge',edge['key'])
        row=' '.join(parsed.rows[row_id])
        for qualifier in edge.get('endpoint_qualifiers',[]):
            qualifiers+=1
            check('qualifier description '+row_id,qualifier['description'] in row)
            for evidence in qualifier['evidence']:
                check('qualifier reference '+row_id,evidence['reference_id'] in row)
                for field in ('quote','source_assertion','source_locator'):
                    if field in evidence:check('qualifier '+field+' '+row_id,evidence[field] in row)

result={'checks':len(checks),'failed':sum(not x['passed'] for x in checks),'optional_attribute_combinations':4,'negative_render_mutants':len(mutations),'positive_graph_reordering':True,'actual_nested_qualifiers_checked':qualifiers,'results':checks}
(OUT/'independent-probe-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='results'}))
