from pathlib import Path
import json,hashlib,subprocess,os,re
P=Path(__file__).resolve().parent
W=Path('/private/tmp/pathwaymech-next-268-20261015')
REL=Path('research/pathway_additions/2026-10-15-next-268/authority-source-originals')
D=W/REL
F=Path('/private/tmp/pathwaymech-next-268-independent-native-authority-implementation-review')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env['GIT_OPTIONAL_LOCKS']='0'
def git(root,*args,input=None):
 r=subprocess.run(['git','-C',str(root),*args],input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 return {'args':list(args),'returncode':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()}
attribute=(D/'.gitattributes').read_bytes();assert attribute==b'# Preserve exact upstream XML bytes, including end-of-line spaces.\n*.xml -text whitespace=-blank-at-eol\n'
(P/'reviewed.gitattributes').write_bytes(attribute)
manifest=json.loads((F/'artifact-manifest.json').read_text())
bound={r['path']:r for r in manifest['files']};rows=[]
provenance=json.loads((D/'source-provenance.json').read_text());assert len(provenance)==65
for p in sorted(D.glob('*.xml')):
 original=F/'clean-native/phenyl268'/p.name;r=bound[str(original.relative_to(F))]
 assert sha(original)==r['sha256'] and original.stat().st_size==r['bytes']
 assert p.read_bytes()==original.read_bytes()
 prov,=[x for x in provenance if x['maintained_original']==str(REL/p.name)]
 assert sha(p)==prov['sha256']==prov['manifest_entry']['sha256']
 staged=git(W,'show',':'+str(REL/p.name));assert staged['returncode']==0
 assert hashlib.sha256(staged['stdout'].encode()).hexdigest()==sha(p)
 rows.append({'path':str(REL/p.name),'bytes':p.stat().st_size,'sha256':sha(p),'frozen_review_path':str(original),'staged_bytes_exact':True,'trailing_space_lines':[i+1 for i,line in enumerate(p.read_bytes().splitlines()) if re.search(rb'[ \t]+$',line)]})
assert len(rows)==65
ls=git(W,'ls-files','-z');assert ls['returncode']==0
paths=sorted(set(ls['stdout'].split('\0'))-{''})
# Check tracked source/data/code paths plus negative hypothetical examples. check-attr is read only.
paths+= [str(REL/'nested/example.xml'),str(REL/'example.txt'),str(REL/'example.xml.receipt.json'),'src/example.xml','data/example.xml','research/pathway_additions/2026-10-15-next-268/other.xml']
r=git(W,'check-attr','-z','--stdin','text','whitespace','diff',input=('\0'.join(paths)+'\0').encode());assert r['returncode']==0
raw=r['stdout'].split('\0');assert raw[-1]=='';raw=raw[:-1]
attrs={}
for i in range(0,len(raw),3):attrs.setdefault(raw[i],{})[raw[i+1]]=raw[i+2]
matched=[]
for path,v in attrs.items():
 intended=path.startswith(str(REL)+'/') and path.endswith('.xml')
 if intended:
  assert v=={'text':'unset','whitespace':'-blank-at-eol','diff':'unspecified'},(path,v);matched.append(path)
 else:assert v=={'text':'unspecified','whitespace':'unspecified','diff':'unspecified'},(path,v)
# Isolated scratch repository; no maintained Git mutations. Every probe is retained.
Q=P/'scratch-repository';Q.mkdir();init=git(Q,'init','--quiet');assert init['returncode']==0
qd=Q/REL;qd.mkdir(parents=True);(qd/'.gitattributes').write_bytes(attribute)
assert git(Q,'add','--',str(REL/'.gitattributes'))['returncode']==0
cases=[
 ('source-trailing',str(REL/'source-trailing.xml'),b'<value>upstream</value> \t\n',False,'trailing whitespace'),
 ('outside-code-trailing','src/code.py',b'value = 1 \t\n',True,'trailing whitespace'),
 ('outside-data-trailing','data/example.xml',b'<value/> \n',True,'trailing whitespace'),
 ('sibling-xml-trailing',str(REL.parent/'outside.xml'),b'<value/> \n',True,'trailing whitespace'),
 ('source-receipt-trailing',str(REL/'example.xml.receipt.json'),b'{} \n',True,'trailing whitespace'),
 ('source-text-trailing',str(REL/'example.txt'),b'upstream \n',True,'trailing whitespace'),
 ('source-conflict',str(REL/'source-conflict.xml'),b'<<<<<<< ours\n<one/>\n=======\n<two/>\n>>>>>>> theirs\n',True,'leftover conflict marker'),
 ('outside-conflict','src/conflict.py',b'<<<<<<< ours\nvalue = 1\n=======\nvalue = 2\n>>>>>>> theirs\n',True,'leftover conflict marker'),
 ('source-space-before-tab',str(REL/'source-indent.xml'),b' \t<value/>\n',True,'space before tab in indent'),
 ('source-empty-eof',str(REL/'source-eof.xml'),b'<value/>\n\n',True,'new blank line at EOF'),
 ('source-crlf-bytes',str(REL/'source-crlf.xml'),b'<value/> \r\n',False,'trailing whitespace')]
probes=[]
for name,path,body,rejected,diagnostic in cases:
 p=Q/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
 assert git(Q,'-c','core.autocrlf=true','add','--',path)['returncode']==0
 result=git(Q,'diff','--cached','--check','--',path)
 assert (result['returncode']!=0)==rejected,(name,result)
 if rejected:assert diagnostic in result['stdout'],(name,result)
 else:assert result['stdout']==''
 show=subprocess.run(['git','-C',str(Q),'show',':'+path],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);assert show.returncode==0
 if path.startswith(str(REL)+'/') and path.endswith('.xml'):assert show.stdout==body
 probes.append({'name':name,'path':path,'body_sha256':hashlib.sha256(body).hexdigest(),'expected_rejection':rejected,'result':result})
diff=git(Q,'diff','--cached','--',str(REL/'source-trailing.xml'));assert '@@' in diff['stdout'] and '+<value>upstream</value>' in diff['stdout'] and 'Binary files' not in diff['stdout']
original_log=Path('/private/tmp/pathwaymech-next-268-ci/staging-original-whitespace.stdout')
log=original_log.read_text();assert log.count('trailing whitespace.')==89
assert sum(len(r['trailing_space_lines']) for r in rows)==89 and sum(bool(r['trailing_space_lines']) for r in rows)==34
(P/'source-hash-bindings.json').write_text(json.dumps({'frozen_review_manifest_sha256':sha(F/'artifact-manifest.json'),'all65':rows},indent=2)+'\n')
(P/'attribute-scope.json').write_text(json.dumps({'reviewed_attribute_sha256':sha(D/'.gitattributes'),'tracked_and_negative_probe_paths_checked':len(attrs),'all_outside_attributes_unspecified':True,'matched_paths':matched,'scope':'XML files anywhere in this source-originals directory tree; includes future nested XML. No receipt JSON, sibling XML, source code or data exception. diff stays unspecified, so text hunks remain.'},indent=2)+'\n')
(P/'probe-results.json').write_text(json.dumps({'git_version':git(Q,'--version'),'cases':probes,'source_text_diff':diff,'maintained_git_mutations':False,'scratch_git_mutations':'init and add within scratch-repository only; no commits or remotes'},indent=2)+'\n')
(P/'staging-original-whitespace.stdout').write_bytes(original_log.read_bytes())
(P/'staging-original-whitespace.json').write_bytes(Path('/private/tmp/pathwaymech-next-268-ci/staging-original-whitespace.json').read_bytes())
print(json.dumps({'result':'PASS','unchanged_source_originals':65,'unchanged_staged_source_originals':65,'upstream_trailing_diagnostics':89,'affected_originals':34,'attribute_paths_checked':len(attrs),'probe_cases':len(cases),'normal_text_diff':True},indent=2))
