"""Stage only the exact retained and reviewed next268 candidate."""
from datetime import datetime, timezone
import hashlib, json, subprocess
from pathlib import Path

ROOT = Path('/private/tmp/pathwaymech-next-268-20261015')
CI = Path('/private/tmp/pathwaymech-next-268-ci')
REVIEW = Path('/private/tmp/pathwaymech-next-268-canonical-successor-review')
BASE = '2c27fc819bac17ef05e191830346d7a32248c97c'
BRANCH = 'feat/pathway-next-268-20261015'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    result = subprocess.run(['git', *args], cwd=ROOT, capture_output=True)
    assert result.returncode == 0, (args, result.stdout, result.stderr)
    return result.stdout

def paths(raw):
    return {value.decode() for value in raw.split(b'\0') if value}

def main():
    assert not (CI / 'reviewed-candidate-stage.json').exists()
    assert json.loads((CI / 'final-gates.json').read_text())['all_required_checks_passed']
    receipt = json.loads((REVIEW / 'canonical-save-receipt.json').read_text())
    assert receipt['save_exit_code'] == receipt['check_exit_code'] == 0
    assert (REVIEW / 'freeze-proof.json').is_file()
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert git('branch', '--show-current').decode().strip() == BRANCH
    assert not git('diff', '--cached', '--name-only', '-z')
    predecessor = json.loads((CI / 'prepublication-candidate-inventory.json').read_text())
    approved = {entry['path']: entry for entry in predecessor['files']}
    readme = 'research/pathway_additions/2026-10-15-next-268/README.md'
    for relative, row in approved.items():
        if relative != readme:
            assert sha(ROOT / relative) == row['sha256'], ('changed predecessor', relative)
    added = {
        'research/pathway_additions/2026-10-15-next-268/rendering-correction-acceptance/README.md',
        'research/pathway_additions/2026-10-15-next-268/rendering-correction-acceptance/inventory.json',
        'research/pathway_additions/2026-10-15-next-268/rendering-correction-acceptance/independent-rendering-acceptance.tar.gz',
        'research/pathway_additions/2026-10-15-next-268/final-verification/README.md',
        'research/pathway_additions/2026-10-15-next-268/final-verification/inventory.json',
        'research/pathway_additions/2026-10-15-next-268/final-verification/root-verification.tar.gz',
        'research/pathway_additions/2026-10-15-next-268/final-verification/canonical-review-working-evidence.tar.gz',
    }
    for row in receipt['files']:
        assert sha(ROOT / row['repo_path']) == row['sha256']
        added.add(row['repo_path'])
    expected = set(approved) | added
    observed = paths(git('diff', '--name-only', '-z')) | paths(git('ls-files', '--others', '--exclude-standard', '-z'))
    assert observed == expected, {'unexpected': sorted(observed - expected), 'missing': sorted(expected - observed)}
    rows = []
    for relative in sorted(expected):
        path = ROOT / relative
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size < 100 * 1024 * 1024, relative
        rows.append({'path': relative, 'bytes': path.stat().st_size, 'sha256': sha(path)})
    pathspec = CI / 'reviewed-candidate-paths.nul'
    pathspec.write_bytes(b'\0'.join(row['path'].encode() for row in rows) + b'\0')
    git('add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul')
    assert paths(git('diff', '--cached', '--name-only', '-z')) == expected
    git('diff', '--cached', '--check')
    git('diff', '--quiet')
    assert not git('ls-files', '--others', '--exclude-standard')
    tree = git('write-tree').decode().strip()
    result = {'staged_utc': datetime.now(timezone.utc).isoformat(), 'base': BASE, 'branch': BRANCH,
              'index_tree': tree, 'staged_whitespace_exit_code': 0, 'files': rows,
              'file_count': len(rows), 'scope': 'Exact reviewed commit candidates. Ignored untracked files excluded intentionally; this is not an absence search.'}
    (CI / 'reviewed-candidate-stage.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'files'}))

if __name__ == '__main__':
    main()
