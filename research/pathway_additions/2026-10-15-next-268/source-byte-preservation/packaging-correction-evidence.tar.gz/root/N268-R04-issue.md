Staging the phenylacetate increment with `git diff --cached --check` reports 89 trailing-whitespace diagnostics across 34 of the 65 preserved MetaCyc/EcoCyc XML originals. The earlier unstaged check did not include these newly added files.

The XML is source evidence bound by exact hashes. Trimming it would alter the issuer originals and break provenance. The packaging needs a directory-local rule that preserves byte content while retaining ordinary text diffs and normal whitespace/conflict checking elsewhere.

Proposed owner: `research/pathway_additions/2026-10-15-next-268/authority-source-originals/.gitattributes`, with explicit documentation and retained original diagnostics.

Acceptance:
- All 65 source XML bodies retain their exact pre-review hashes.
- Only XML in the authority-original directory permits original end-of-line spaces; code and curated YAML retain normal checks.
- Conflict markers and unrelated whitespace errors remain detectable.
- The final staged candidate passes `git diff --cached --check`, and the narrow packaging change receives independent review.

This is a packaging defect, not a finding against the scientific source content. Close only after the merged tree is verified.
