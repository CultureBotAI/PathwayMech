from pathlib import Path
import copy,json,hashlib,sys
O=Path(__file__).parent;P=Path('/private/tmp/pathwaymech-next-268-native-authority-integration');sys.path[:0]=[str(O/'isolated/src'),str(O/'isolated')]
from scripts.build_source_identifier_snapshot import build_snapshot
from pathwaymech.identifiers import _load_authority
base=json.loads((P/'new-native-snapshot.json').read_text());ampkey=base['terms']['MetaCyc:AMP']['source'];entries=json.loads((P/'new-source-manifest.json').read_text());amp=next(e for e in entries if e['key']==ampkey)
body=b"<html><TITLE>MetaCyc Unrelated context title</TITLE><script>typeObjectPage={object:'UNREVIEWED-FRAME',orgid:'META'}</script></html>"
results=[]
for style in ['canonical_id','native_legacy']:
 d=O/('request-probe-'+style);d.mkdir();(d/'records').mkdir();(d/'records/one.yaml').write_text('id: MetaCyc:AMP\n');target=d/amp['path'];target.parent.mkdir(parents=True);target.write_bytes((P/'source-cache'/amp['path']).read_bytes());(d/'unrelated.html').write_bytes(body)
 url='https://bf2i-artsymbiocyc.insa-lyon.fr/getxml?'+('id=' if style=='canonical_id' else '')+'META:PWY0-321'
 entry={'key':'downgraded-unselected-native-request','kind':'metacyc-html','path':'unrelated.html','url':url,'version':'27.0','license':'test fixture','sha256':hashlib.sha256(body).hexdigest()}
 (d/'manifest.json').write_text(json.dumps([amp,entry],indent=2)+'\n')
 value={'version':1,'sources':{ampkey:base['sources'][ampkey],entry['key']:{k:entry[k]for k in ['url','version','license','sha256']}},'terms':{'MetaCyc:AMP':base['terms']['MetaCyc:AMP']}}
 (d/'authority.json').write_text(json.dumps(value,indent=2)+'\n');r={'case':style,'url':url}
 for name,call in [('builder',lambda:build_snapshot(d/'manifest.json',d/'records',d)),('consumer',lambda:_load_authority(d/'authority.json'))]:
  try:call();r[name]={'accepted':True}
  except Exception as e:r[name]={'accepted':False,'error':type(e).__name__+': '+str(e)}
 results.append(r)
(O/'request-downgrade-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
