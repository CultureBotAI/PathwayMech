The phenylacetate authority adapter's preselection downgrade check detects known native identities in `?id=META:PWY0-321`, but overlooks the genuine native `getxml?META:PWY0-321` request form. Five retained source receipts use bare native query syntax.

Independent review and root reproduction show that both `build_snapshot()` and `_load_authority()` reject a generic HTML source claiming the canonical request, yet accept the otherwise identical unselected source owner using the bare request form. The selected AMP source remains valid in both probes. The selected-term guard still rejects downgrades of a selected native term; this finding concerns conflicting or downgraded assertions before selection and on load.

Affected owner: `src/pathwaymech/biocyc_phenylacetate.py`, `validate_phenylacetate_assertions()`. It currently extracts only parsed `id` and `object` query values.

Acceptance:

- Detect exact recognized native request identities in supported bare `getxml` queries, including META and ECOLI scopes.
- Reject a known native identity whose source metadata lacks the required complete typed owner, even when that source is unselected.
- Do not reinterpret arbitrary query strings or unrelated hosts as native identity assertions.
- Cover producer and consumer regressions and preserve all genuine source replay results.
- Keep this issue open until the correction is independently reviewed and retained in the verified merged tree.

Review identifier: N268-A02. Original review probes and immutable predecessor are retained separately from corrections.
