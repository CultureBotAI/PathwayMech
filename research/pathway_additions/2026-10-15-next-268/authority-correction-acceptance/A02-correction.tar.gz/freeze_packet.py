from pathlib import Path
import hashlib,json,shutil

p=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for changed in json.loads((p/'change-bindings.json').read_text())['changed_files']:
 assert sha(Path(changed['path']))==changed['after_sha256']
for b in json.loads((p/'before-input-bindings.json').read_text())[2:]:
 assert sha(Path(b['path']))==b['sha256']
receipt_inventory=json.loads((p/'genuine-bare-request-receipts.json').read_text())
assert len(receipt_inventory['bare_request_receipts'])==5
(p/'source-receipts').mkdir(exist_ok=True)
for receipt in receipt_inventory['bare_request_receipts']:
 original=Path(receipt['path']);assert sha(original)==receipt['sha256']
 shutil.copyfile(original,p/'source-receipts'/original.name)
prefix='PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1 PYTHONPATH=/private/tmp/pathwaymech-next-268-20261015/src '
runtime='/private/tmp/pathwaymech-next-263-verified-venv/bin/python -B -m pytest '
target='tests/test_phenylacetate_authority.py -q -p no:cacheprovider'
regression='tests/test_source_identifier_snapshot.py tests/test_identifier_snapshot_builders.py tests/test_identifiers.py tests/test_ecocyc_identifier_authority.py tests/test_biocyc_carrier_authority.py tests/test_p321_authority.py tests/test_nitrate_native_authority.py tests/test_protein_carrier_preselection.py tests/test_protein_carrier_reaction_authority.py -q -p no:cacheprovider'
results={'workdir':'/private/tmp/pathwaymech-next-268-20261015','all_jobs_terminal':True,'attempts':[
 {'name':'before-fix-regressions','command':prefix+runtime+'tests/test_phenylacetate_authority.py -k unselected_legacy_native_request -q -p no:cacheprovider','exit_code':1,'expected_red':True,'failed':4},
 {'name':'targeted-attempt1','command':prefix+runtime+target,'exit_code':1,'passed':449,'failed':1,'reason':'Incorrect FTP whole-consumer acceptance expectation; failed test source and run preserved.'},
 {'name':'targeted-attempt2','command':prefix+runtime+target,'exit_code':0,'passed':449},
 {'name':'regression-attempt1','command':prefix+runtime+regression,'exit_code':0,'passed':1897}],
 'final_passing_tests':2346,'all65_original_roundtrips_passed':True,'A01_predecessor_unchanged':True,'issue616_independent_acceptance_pending':True}
assert '449 passed' in (p/'targeted-attempt2.stdout').read_text()
assert '1897 passed' in (p/'regression-attempt1.stdout').read_text()
(p/'validation-results.json').write_text(json.dumps(results,indent=2)+'\n')
files=sorted(q for q in p.rglob('*') if q.is_file() and q.name not in ['artifact-manifest.json','freeze-proof.json'])
# The predecessor's identically named manifest/freeze are retained under before/
# and belong in this manifest; exclude only this packet's two root documents.
files=sorted(q for q in p.rglob('*') if q.is_file() and q.relative_to(p).as_posix() not in ['artifact-manifest.json','freeze-proof.json'])
assert not any(q.is_symlink() for q in files)
entries=[{'path':q.relative_to(p).as_posix(),'bytes':q.stat().st_size,'sha256':sha(q)} for q in files]
(p/'artifact-manifest.json').write_text(json.dumps({'scope':'All files recursively including hidden/ignored; excludes only root manifest and freeze proof.','files':entries},indent=2)+'\n')
proof={'status':'frozen_A02_correction_for_independent_review','manifest_sha256':sha(p/'artifact-manifest.json'),'handoff_sha256':sha(p/'HANDOFF.md'),'listed_files':len(entries),'physical_files':len(entries)+2,'all_local_jobs_terminal':True,'final_passing_tests':2346}
(p/'freeze-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
assert len([q for q in p.rglob('*') if q.is_file()])==proof['physical_files']
assert all(sha(p/e['path'])==e['sha256'] for e in entries)
print(json.dumps(dict(proof,freeze_sha256=sha(p/'freeze-proof.json')),indent=2))
