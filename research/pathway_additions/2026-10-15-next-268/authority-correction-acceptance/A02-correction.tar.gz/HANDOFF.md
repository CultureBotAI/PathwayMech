# A02 / issue 616: recognize bare native getxml request identities

Status: frozen correction for independent acceptance, based on the separately frozen A01 correction. Only `src/pathwaymech/biocyc_phenylacetate.py` and `tests/test_phenylacetate_authority.py` were changed in the actual268 worktree. No authority snapshot, original fixture, documentation, primary record, Git/GitHub object or installed runtime was changed by this task. All local test processes are terminal.

The request-only downgrade check previously recognized `id` and `object` query values but skipped the native literal request form `/getxml?META:FRAME` (and ECOLI). The seven-line addition appends the complete literal query as a candidate token only when the URL uses HTTP(S), an already recognized issuer host, the exact `/getxml` path and a `META:` or `ECOLI:` prefix. The existing exact known-profile lookup and required typed-owner check then apply before selection and on consumer load. Existing canonical query behavior is unchanged.

This is a bounded interpretation of actual native syntax, not extraction of identity-like strings from arbitrary URLs. Unrelated hosts/paths, parameter values, unprefixed queries and query suffixes do not become bare native identities. FTP is not a native HTTP request, and the existing general consumer public-URL guard still rejects it. `genuine-bare-request-receipts.json` independently inventories the 65 frozen authority receipts and binds the five authentic receipts that use this literal syntax; copies of those five receipt originals are retained under `source-receipts/`.

Tests cover unselected downgraded owners through both `build_snapshot()` and `_load_authority()`, for META and ECOLI, all five existing issuer hostnames, canonical `id`/`object` queries, the bare query, and the legacy HTTP port-443 form. The valid selected AMP owner and unrelated HTML response are retained in each end-to-end case, so the new failures arise from the unselected request assertion. Negative cases cover unrelated URLs/query forms, and all A01 identity tests remain in the suite.

Verification:

- Four focused legacy producer/consumer cases were run before the production change and failed because the downgraded source was accepted. The expected red baseline is preserved.
- The final complete targeted suite passed **449 tests**, including all 65 genuine source round-trips and the A01 regressions.
- Relevant source-snapshot, identifier, EcoCyc, carrier, P321 and nitrate regressions passed **1,897 tests**.
- Total final passing tests: **2,346**. This is not a claim that unrelated corpus/rendering/KGX gates or independent acceptance have completed.

One author test error is preserved: the first targeted run had 449 passes and one failure because it incorrectly expected an FTP source to pass the whole consumer. The native assertion guard correctly ignored the non-HTTP query, while the preexisting provenance guard rejected its protocol. The corrected dedicated test checks both boundaries; the failed test source, stdout/stderr and disposition remain. No production change was needed for that test correction. All commands used the verified existing Python, bytecode disabled and explicit current-worktree `PYTHONPATH`; no install or runtime repair occurred.

`change-bindings.json`, before/after copies and two unified diffs bind the exact result:

- adapter SHA `36653b6d37c2ccfa551adb42bf4b28af7ce9394b8d4aa7d126d1e6636b338f4b`
- tests SHA `6586a80d895bb36f4aeb9f3966e41c94874d8abe23e57e71979830e505e9ab7c`

All 65 compressed source fixtures remain byte-identical. The fixture manifest/storage, root and reviewer A02 reproductions, A01 freeze metadata and all 24 A01 manifest-listed files remain unchanged. The immutable A01 packet at `/private/tmp/pathwaymech-next-268-native-identity-correction` was independently reviewed separately; its maintained after-hashes are this packet's before-hashes. Root owns issue retention and closure after independent acceptance and the verified merge; this author packet does not close issue 616.
