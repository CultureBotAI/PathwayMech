from pathlib import Path
import copy,hashlib,json,sys,collections
O=Path(__file__).parent;P=Path('/private/tmp/pathwaymech-next-268-native-request-correction');A=Path('/private/tmp/pathwaymech-next-268-native-authority-integration');B=Path('/private/tmp/pathwaymech-next-268-independent-native-authority-implementation-review')
sys.path[:0]=[str(O/'isolated/src'),str(O/'isolated')]
import pathwaymech.biocyc_phenylacetate as p
import pathwaymech.identifiers as consumer
import scripts.build_source_identifier_snapshot as builder
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
mods={x.__name__:{'path':x.__file__,'sha256':h(Path(x.__file__))}for x in [p,consumer,builder]};assert all(str(O/'isolated')in v['path']for v in mods.values());save('module-paths.json',mods)
def guards(url):
 try:p.validate_phenylacetate_assertions({'unselected':{'url':url}},[]);return {'rejected':False}
 except ValueError as e:return {'rejected':True,'error':str(e)}
hosts=['bf2i-artsymbiocyc.insa-lyon.fr','biocyc.org','www.biocyc.org','metacyc.org','www.metacyc.org']
positive=[]
for ident in sorted(p.PROFILES):
 token=ident.replace('MetaCyc:','META:',1).replace('EcoCyc:','ECOLI:',1)
 for host in hosts:
  for scheme in ['http','https']:
   for prefix in ['','id=','object=']:
    url=f'{scheme}://{host}/getxml?{prefix}{token}';r=guards(url);assert r['rejected'] and 'requires its typed source'in r['error'];positive.append({'url':url,**r})
  url=f'http://{host}:443/getxml?{token}';r=guards(url);assert r['rejected'];positive.append({'url':url,**r})
negative=[]
for token in ['META:PWY0-321','ECOLI:PM5']:
 for url in [
  f'https://example.org/getxml?{token}',f'https://biocyc.org.example/getxml?{token}',f'https://biocyc.org@other.example/getxml?{token}',
  f'https://biocyc.org/getxmlish?{token}',f'https://biocyc.org/search?{token}',f'https://biocyc.org/getxml/?{token}',f'https://biocyc.org/GETXML?{token}',
  f'https://biocyc.org/getxml?note={token}',f'https://biocyc.org/getxml?next=https%3A%2F%2Fbiocyc.org%2Fgetxml%3F{token}',
  f'https://biocyc.org/getxml?{token}&view=full',f'https://biocyc.org/getxml?{token}=',f'https://biocyc.org/getxml?prefix{token}',
  f'https://biocyc.org/getxml?{token.lower()}',f'https://biocyc.org/getxml?{token.replace(":","%3A")}',f'ftp://biocyc.org/getxml?{token}',f'file://biocyc.org/getxml?{token}',
  'https://biocyc.org/getxml?META:UNREVIEWED-FRAME','https://biocyc.org/getxml?ECOLI:UNREVIEWED-FRAME','https://biocyc.org/getxml?PWY0-321']:
  r=guards(url);assert not r['rejected'];negative.append({'url':url,**r})
save('request-guard-matrix.json',{'positive_count':len(positive),'negative_count':len(negative),'positive':positive,'negative':negative,'scope':'literal bare-query recognition only; excluded forms are not claimed to have been empirically tested at issuing server'})
full=[]
for style in ['canonical_id','native_legacy']:
 d=B/('request-probe-'+style);r={'case':style}
 for boundary,func in [('builder',lambda:builder.build_snapshot(d/'manifest.json',d/'records',d)),('consumer',lambda:consumer._load_authority(d/'authority.json'))]:
  try:func();raise AssertionError('Original A02 bypass still accepted')
  except ValueError as e:assert 'requires its typed source'in str(e);r[boundary]={'rejected':True,'error':str(e)}
 full.append(r)
save('original-A02-replays.json',full)
# Genuine acquisition requests agree with retained full original body hashes.
receipts=[]
for f in sorted((P/'source-receipts').glob('*.json')):
 original=A/'after/research/pathway_additions/2026-10-15-next-268/authority-source-originals'/f.name;assert f.read_bytes()==original.read_bytes();receipt=json.loads(f.read_text());body=original.with_name(original.name.removesuffix('.receipt.json'));assert h(body)==receipt['sha256'];assert body.stat().st_size==receipt['bytes'];url=receipt.get('requested_url',receipt.get('url'));assert guards(url)['rejected'];receipts.append({'receipt':str(f),'receipt_sha256':h(f),'body_sha256':h(body),'actual_url':url,'http_status':receipt['status'],'native_guard_rejects_generic_owner':True})
assert len(receipts)==5;save('genuine-receipt-checks.json',receipts)
# Keep typed canonical request provenance strict even though detection handles aliases.
snapshot=json.loads((A/'new-native-snapshot.json').read_text());key=snapshot['terms']['MetaCyc:AMP']['source'];meta=copy.deepcopy(snapshot['sources'][key]);meta['url']=meta['url'].replace('?id=','?')
try:p.validate_phenylacetate_metadata(meta);raise AssertionError('Typed request widened')
except ValueError as e:save('typed-request-boundary.json',{'bare_url_rejected_by_typed_metadata':True,'error':str(e)})
# A01 protections remain at full entry points.
a01=[]
for name in ['probe-missing_frameid','probe-missing_frameid_and_wrong_resource','probe-all_identity_attributes_removed']:
 d=B/name;r={'case':name}
 for boundary,func in [('builder',lambda:builder.build_snapshot(d/'manifest.json',d/'records',d)),('consumer',lambda:consumer._load_authority(d/'authority.json'))]:
  try:func();raise AssertionError('A01 regressed')
  except ValueError as e:assert 'incomplete or ambiguous embedded native identity'in str(e);r[boundary]={'rejected':True,'error':str(e)}
 a01.append(r)
save('A01-regression-replay.json',a01)
value=builder.build_snapshot(B/'clean-native/manifest.json',B/'clean-native/selection',B/'clean-native');raw=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode();assert raw==(A/'new-native-snapshot.json').read_bytes();assert consumer._load_authority(A/'candidate-sources.json')==json.loads((A/'candidate-sources.json').read_text())['terms'];save('positive-replay.json',{'all65_native_builder_byte_exact':True,'sha256':hashlib.sha256(raw).hexdigest(),'whole3286_term_consumer_pass':True})
print(json.dumps({'positive_request_cases':len(positive),'negative_request_cases':len(negative),'full_original_A02_rejections':4,'full_A01_rejections':6,'genuine_receipts_bound':5,'typed_request_not_widened':True,'original65_replay_exact':True,'whole_source_consumer_pass':True}))
