# Independent A02 / issue 616 successor acceptance

Disposition: **accept the bounded A02 correction**, with no new actionable defect found. N268-A02 is addressed in this frozen successor. Parent-owned issue closure still requires the retained disposition and verified merge. This is implementation acceptance, not final scientific-record approval.

All 36 manifested / 38 physical author files, manifest/HANDOFF/freeze hashes and A01-to-A02 before/after continuity were independently verified. The full HANDOFF, seven-line adapter delta and all added tests were read. The correction only recognizes the complete literal query on HTTP(S) `/getxml` requests to the five already recognized issuer hosts, then reuses exact known-profile lookup and typed-owner enforcement. Existing canonical id/object handling is unchanged. Typed original metadata still requires its original strict canonical request form; alias detection does not widen valid snapshot provenance.

Fresh isolated checks:

- 449 targeted tests passed in 25.53 seconds, including all genuine original roundtrips and A01 tests.
- Independent guard matrix exercised all 65 profile identities across five hosts, HTTP/HTTPS, bare/id/object forms, plus legacy HTTP port443 forms: 2,275 known-profile request cases rejected as untyped owners. Thirty-eight negative cases were left outside bare-query identity detection, covering unrelated/suffix hosts, user-info host confusion, wrong/case-changed/trailing-slash paths, nested query values, suffixes, unreviewed tokens, case variants, encoded separators and non-HTTP schemes. These are parser-boundary checks; no claim is made that excluded forms were empirically queried at the issuer or could never resolve there.
- The exact original canonical control and legacy bypass fixtures are now rejected through both full builder and consumer (four checks). Three original A01 malformed originals remain rejected through full builder and consumer (six checks).
- All five authentic bare-query receipts are byte-identical to the retained acquisition originals; their body hashes and sizes match the issuing XML. All five actual request URLs trigger mandatory typed ownership. Canonicalizing a manifest request did not replace or falsify the retained acquisition request.
- A known typed metadata object changed to a bare URL still fails the strict typed request validation. The new detector recognizes unsafe downgrades rather than admitting generic owners or new provenance shapes.
- Rebuilt all 65 native sources with the isolated A02 implementation; output is byte-identical to the original accepted snapshot (`3134f9de7ee823dc66f4fe29280985d1066bdafecc77799d9824b775f641c151`). The full 3,286-term source authority consumer passes. Canonical issuing labels, original bytes, node roles, equations and pathway membership are unchanged.

Successful module paths/hashes are in module-paths.json. This review uses an isolated frozen implementation and never requires mutable maintained files to stand still. Complete prior authority review, A01 author correction and independent A01 acceptance are reused with exact frozen manifest bindings; their source/ontology/whole-corpus results are not claimed as fresh broad scientific or corpus checks here. The author's additional 1,897 regression tests were reviewed as retained reported validation, not independently rerun; the independently fresh suite is 449 tests plus the recorded probes.

The author accurately preserved four expected pre-fix failures and a failed FTP test expectation. The native bare-query detector ignores non-HTTP schemes while the general consumer rejects unsupported public URL schemes; the final dedicated FTP test distinguishes these layers. Production code did not change to satisfy that mistaken expectation. There were no failed independent test runs in this A02 review.

## Root formatting successor

Accepted separately: the root successor wraps one long A01 test decorator over three lines. Full exact diff was inspected and Python ASTs are equal excluding locations. Frozen A02 test SHA `6586a80d895bb36f4aeb9f3966e41c94874d8abe23e57e71979830e505e9ab7c` becomes `23761de2bbacf7b9f64da5e63ca13f0bf0aac429b7c7f0257cecd25cd81f93fe`; production adapter remains `36653b6d37c2ccfa551adb42bf4b28af7ce9394b8d4aa7d126d1e6636b338f4b`. Evidence and a copied formatted successor are retained. The 449-run used frozen A02 tests; AST equivalence supports this behavior-neutral formatting acceptance without implying a separate full rerun.

No maintained code/data, frozen input, runtime, Git, GitHub or network changes were made by this reviewer. No renderer self-review. Scientific identity conflicts and CHEM02/O02/O03 are unaffected. All retained review inputs remain unchanged; later full final gates belong to root.
