Independent review found inconsistent inherited-storage provenance in the pending complete CENTBENZCOA evidence archive (finding **N266-RET-PROV-01**, low severity).

The frozen `payload/content-map.json` (SHA256 `71e02c8b0d02533a84b4863e71b9e651faedc0def66c72ca14989707b03e2313`) contains 586 mappings across 301 stored paths whose `storage.git_commit` is `dd780ef273323efd638eacd63625963062e0b105` but whose `storage.git_tree` remains `e5c455667499283021774a6c3d5138cc8293f28e`. The actual tree of that commit is `93edcbf621df2ca0551830151be39eed5ce21232`. Root independently reproduced the complete affected set against Git. The separate 502-owner verification binds the correct tree; no byte loss or pathway-science defect is established by this finding.

The generator copies inherited storage fields and updates the commit without updating the optional tree, including indirect compact reuse. Source preparation manifest: `85aba0de3c3702eefc5f48d46f5e9b2ca6f0e3297ebcca9ae0c56b524bcf5d02`; payload manifest: `7240d8b0ea50e77018330a3ff67c3d7acda65878c23d33b034fe6ff7aaaa49ae`. These are pending publication artifacts, not claimed merged files.

Acceptance criteria:

- Preserve the immutable original report, maps, manifests and all original source bytes in an explicit successor.
- Correct every affected commit/tree pair and the generating logic; preserve valid optional omissions.
- Verify all 7,337 physical and 1,334 compact-only source occurrences, complete compact declarations and inherited endpoint bytes remain recoverable unchanged.
- Independently review the successor, integrate it, pass required gates and verify publication before closure.
