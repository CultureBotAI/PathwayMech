# Complete seven-step chemistry

All source material entries and coefficients are replayed from complete native XML in [complete-route-chemical-accounting.json](complete-route-chemical-accounting.json). Directions below are selected pathway traversal. They do not assert irreversibility or measured complete pathway flux.

## 1. 1.3.99.15-RXN

`BENZOYLCOA + 2 Reduced-ferredoxins + 2 ATP + 2 WATER → CYCLOHEXA-15-DIENE-1-CARBONYL-COA + 2 Oxidized-ferredoxins + 2 ADP + 2 Pi`

Native direction: PHYSIOL-RIGHT-TO-LEFT; pathway traversal: R2L. Native orphan annotation: NO.

Current exact Rhea directional match: none in the retained finite fixed-equation comparison.

## 2. 4.2.1.100-RXN

`CYCLOHEXA-15-DIENE-1-CARBONYL-COA + WATER → 6-HYDROXYCYCLOHEX-1-ENE-1-CARBONYL-COA`

Native direction: REVERSIBLE; pathway traversal: R2L. Native orphan annotation: NO.

Current exact Rhea directional match: http://rdf.rhea-db.org/21857.

## 3. HADTHAUERA-RXN

`6-HYDROXYCYCLOHEX-1-ENE-1-CARBONYL-COA + NAD → PROTON + 6-OXOCYCLOHEX-1-ENE-1-CARBONYL-COA + NADH`

Native direction: REVERSIBLE; pathway traversal: L2R. Native orphan annotation: NO.

Current exact Rhea directional match: http://rdf.rhea-db.org/18266.

## 4. RXN-15012

`6-OXOCYCLOHEX-1-ENE-1-CARBONYL-COA + WATER → CPD-15900`

Native direction: REVERSIBLE; pathway traversal: L2R. Native orphan annotation: NO.

Current exact Rhea directional match: http://rdf.rhea-db.org/40064.

## 5. RXN-15013

`CPD-15900 + WATER → 3-HYDROXYPIMELYL-COA + PROTON`

Native direction: REVERSIBLE; pathway traversal: L2R. Native orphan annotation: NO.

Current exact Rhea directional match: http://rdf.rhea-db.org/40068.

## 6. 1.1.1.259-RXN

`3-HYDROXYPIMELYL-COA + NAD → PROTON + NADH + 3-OXOPIMELOYL-COA`

Native direction: REVERSIBLE; pathway traversal: L2R. Native orphan annotation: YES-PUTATIVE.

Current exact Rhea directional match: http://rdf.rhea-db.org/11169.

## 7. RXN-8032

`3-OXOPIMELOYL-COA + CO-A → GLUTARYL-COA + ACETYL-COA`

Native direction: REVERSIBLE; pathway traversal: L2R. Native orphan annotation: NO.

Current exact Rhea directional match: none in the retained finite fixed-equation comparison.

## Whole-route net

`2 ATP + BENZOYLCOA + CO-A + 2 NAD + 2 Reduced-ferredoxins + 5 WATER → ACETYL-COA + 2 ADP + GLUTARYL-COA + 2 NADH + 2 Oxidized-ferredoxins + 3 PROTON + 2 Pi`

All small-molecule elements balance for every step. Steps2–7 also balance charge directly. Step 1 and the whole route have a small-molecule product-minus-substrate charge difference of −2; oxidation of two native one-electron cluster units supplies +2. No fixed generic-carrier formula or whole-protein count is inferred.

The Oah substeps 4 and 5 cancel CPD-15900 exactly to the native composite OAHTHAUERA-RXN. Rhea 39651 explicitly identifies the composite as 40063 plus 40067. Composite activity is not evidence that CPD15900 was isolated or released. Step 6 remains YES-PUTATIVE without an assigned catalyst. The lower thiolysis retains native RXN-8032; a glutaryl/ACP condensation is chemically different.

All six primary-material joins retain coefficient 1 on both sides. They are source connectivity, not physical channeling. Distinct P321-PWY retains its complete nine-step sequence in the copied discovery originals and accounting context; it is not a substitute or an eighth selected step.
