# Selected material identities

Source-author chemical preparation. Full structures, exact native/API/SQL comparisons and representation limits are retained in [chemical-identity-closure.json](chemical-identity-closure.json). Seventeen compounds resolve exactly; the two carrier classes retain native identities. Identifier charge states are source normalizations, not measured physiological distributions.

| Native frame | Issuing identity and label | Formula | Charge | Additional unspecified carbon centers |
|---|---|---|---:|---:|
| 3-HYDROXYPIMELYL-COA | [CHEBI:57343](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57343) 3-hydroxypimeloyl-CoA(5-) | C28H41N7O20P3S | -5 | 1 |
| 3-OXOPIMELOYL-COA | [CHEBI:57350](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57350) 3-oxopimeloyl-CoA(5-) | C28H39N7O20P3S | -5 | 0 |
| 6-HYDROXYCYCLOHEX-1-ENE-1-CARBONYL-COA | [CHEBI:57361](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57361) 6-hydroxycyclohex-1-ene-1-carbonyl-CoA(4-) | C28H40N7O18P3S | -4 | 1 |
| 6-OXOCYCLOHEX-1-ENE-1-CARBONYL-COA | [CHEBI:76526](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:76526) 6-oxocyclohex-1-ene-1-carbonyl-CoA(4-) | C28H38N7O18P3S | -4 | 0 |
| ACETYL-COA | [CHEBI:57288](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57288) acetyl-CoA(4-) | C23H34N7O17P3S | -4 | 0 |
| ADP | [CHEBI:456216](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:456216) ADP(3-) | C10H12N5O10P2 | -3 | 0 |
| ATP | [CHEBI:30616](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:30616) ATP(4-) | C10H12N5O13P3 | -4 | 0 |
| BENZOYLCOA | [CHEBI:57369](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57369) benzoyl-CoA(4-) | C28H36N7O17P3S | -4 | 0 |
| CO-A | [CHEBI:57287](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57287) coenzyme A(4-) | C21H32N7O16P3S | -4 | 0 |
| CPD-15900 | [CHEBI:76527](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:76527) 2-hydroxy-6-oxocyclohexane-1-carbonyl-CoA(4-) | C28H40N7O19P3S | -4 | 2 |
| CYCLOHEXA-15-DIENE-1-CARBONYL-COA | [CHEBI:57374](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57374) cyclohexa-1,5-diene-1-carbonyl-CoA(4-) | C28H38N7O17P3S | -4 | 0 |
| GLUTARYL-COA | [CHEBI:57378](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57378) glutaryl-CoA(5-) | C26H37N7O19P3S | -5 | 0 |
| NAD | [CHEBI:57540](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57540) NAD(1-) | C21H26N7O14P2 | -1 | 0 |
| NADH | [CHEBI:57945](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:57945) NADH(2-) | C21H27N7O14P2 | -2 | 0 |
| PROTON | [CHEBI:15378](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:15378) hydron | H | 1 | 0 |
| Pi | [CHEBI:43474](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:43474) hydrogenphosphate | HO4P | -2 | 0 |
| WATER | [CHEBI:15377](https://www.ebi.ac.uk/chebi/searchId.do?chebiId=CHEBI:15377) water | H2O | 0 | 0 |
| Oxidized-ferredoxins | MetaCyc:Oxidized-ferredoxins; CHEBI:17908 is an unaccepted whole-carrier identity lead | Generic class; no fixed formula | Unassigned | Not applicable |
| Reduced-ferredoxins | MetaCyc:Reduced-ferredoxins; CHEBI:17513 is an unaccepted whole-carrier identity lead | Generic class; no fixed formula | Unassigned | Not applicable |

Native carrier illustrations are explicitly illustrative [2Fe-2S] structures. Each class unit represents a one-electron cluster state; two units do not assert two whole ferredoxin polypeptides. Rhea142 uses one whole two-[4Fe-4S] carrier with two reactive parts. Current issuing ChEBI33722/33723 and ChEBI255 describe H4Fe4S4, whereas Rhea142 reactive parts use Fe4S4. This source-convention difference is retained; only the within-source one-charge transition is used in redox accounting.

Five native SMILES fields (ATP, benzoyl-CoA, glutaryl-CoA, NAD and NADH) are generalized or do not regenerate the complete identity. Twelve InChI reconstructions change explicit mobile-hydrogen/bond graphs. These are17 representation-limit rows, not17failed identities. Exact native/API/SQL InChI and keys, formula/charge, and native CML versus issuing/pinned SMILES connectivity and charge all pass. CML is not used to invent stereochemistry.
