"""Preserve exact baseline JSON ordering while adding the accepted identities."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

W = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
A = Path('/private/tmp/pathwaymech-next-266-authority/complete-proposal-v2/proposed')
OUT = Path('/private/tmp/pathwaymech-next-266-registry-formatting-successor')
BASE = 'dd780ef273323efd638eacd63625963062e0b105'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def strict(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def emit(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


def main():
    OUT.mkdir(exist_ok=False)
    rows = []
    bodies = []
    for name in ['conf/identifier_sources.json', 'data/identifier_authorities/sources.json', 'data/identifier_authorities/ontology.json']:
        baseline = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=W)
        accepted = (A / name).read_bytes()
        assert (W / name).read_bytes() == accepted
        old, proposal = json.loads(baseline), json.loads(accepted)
        assert (json.dumps(old, indent=2, ensure_ascii=False) + '\n').encode() == baseline
        if isinstance(old, list):
            assert proposal[:len(old)] == old
            merged = old + proposal[len(old):]
        else:
            merged = json.loads(baseline)
            assert set(merged) == set(proposal)
            for key in merged:
                if key in ['sources', 'terms']:
                    for identifier, value in proposal[key].items():
                        if identifier in merged[key]:
                            assert strict(merged[key][identifier]) == strict(value)
                        else:
                            merged[key][identifier] = value
                else:
                    assert strict(merged[key]) == strict(proposal[key])
        assert strict(merged) == strict(proposal)
        body = (json.dumps(merged, indent=2, ensure_ascii=False) + '\n').encode()
        target = OUT / 'proposed' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
        rows.append({'path': name, 'baseline_sha256': sha(baseline), 'accepted_proposal_sha256': sha(accepted), 'successor_sha256': sha(body), 'successor_bytes': len(body), 'strict_complete_json_equal': True, 'baseline_serialization_roundtrip_exact': True, 'all_existing_values_preserved': True})
        bodies.append((name, body))
    emit(OUT / 'proof.json', {'observed_at': datetime.now(timezone.utc).isoformat(), 'base': BASE, 'scope': 'Formatting-only successor to three accepted authority proposals; preserves baseline insertion order and literal Unicode. Whole decoded JSON objects strictly equal accepted proposals. No record, source metadata, identity, owner, source order or scientific claim changes.', 'files': rows, 'original_proposals_immutable': True})
    (OUT / 'preserve_registry_formatting.py.txt').write_bytes(Path(__file__).read_bytes())
    for name, body in bodies:
        assert (W / name).read_bytes() == (A / name).read_bytes()
        (W / name).write_bytes(body)
        assert (W / name).read_bytes() == body
    emit(OUT / 'adoption.json', {'observed_at': datetime.now(timezone.utc).isoformat(), 'actual_maintained_files_equal_proposed_successors': True, 'previous_integration_receipt_preserved': str(CI / 'maintained-record-integration.json'), 'proof_sha256': sha((OUT / 'proof.json').read_bytes()), 'files': rows})
    entries = [{'path': str(p.relative_to(OUT)), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file()]
    emit(OUT / 'artifact-manifest.json', {'scope': 'All regular files including hidden/ignored, except this manifest and terminal freeze-proof.json.', 'files': entries})
    emit(OUT / 'freeze-proof.json', {'manifest_sha256': sha((OUT / 'artifact-manifest.json').read_bytes()), 'listed_files': len(entries), 'physical_files': len(entries) + 2})
    print(json.dumps({'manifest_sha256': sha((OUT / 'artifact-manifest.json').read_bytes()), 'proof_sha256': sha((OUT / 'proof.json').read_bytes()), 'files': rows}, indent=2))


if __name__ == '__main__':
    main()
