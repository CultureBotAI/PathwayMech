"""Use the repository's native scaffolder for the two integrated changes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

W = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'


def main():
    assert (CI / 'maintained-record-integration.json').is_file()
    assert not (CI / 'native-integration-history.json').exists()
    environment = dict(os.environ)
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH=str(W / 'src') + ':' + str(W))
    jobs = [
        {
            'name': 'record',
            'args': ['--kind', 'record', '--slug', 'benzoyl-coa-degradation-ii-anaerobic', '--target-root', 'data/pathways', '--event', 'CREATE', '--outcome', 'changed'],
            'summary': 'Add the complete reviewed anaerobic benzoyl-CoA degradation II pathway',
            'details': 'Add MetaCyc:CENTBENZCOA-PWY as the complete seven-step route with 43 participants, four taxon contexts, seven selected reactions plus auxiliary Oah composite context, 76 edges and 25 references. All 117 evidence items, exact source locators and experimental construct qualifications match the independently accepted design. Preserve generic ferredoxin cluster-unit coefficients, unspecified stereochemistry, Oah intermediate and composite limits, the putative sixth step and the native predicted PimB assignment without unsupported catalytic edges. Actual merged-baseline duplicate/source-follow review and its issue590 provenance successor were independently accepted before integration. The conventional YAML is strictly object-equal to the accepted design and passed the closed schema preflight. All 262 previous records remain byte-identical. Source/review evidence retention, final generated artifacts, complete production gates and canonical maintained-record review are separate subsequent steps.',
        },
        {
            'name': 'authority',
            'args': ['--kind', 'infrastructure', '--slug', 'benzoyl-authority-profiles', '--path', 'src/pathwaymech/biocyc_benzoyl.py', '--event', 'CREATE', '--outcome', 'changed'],
            'summary': 'Add scoped benzoyl-pathway identifier profiles and preserve existing authority owners',
            'details': 'Implement five bounded native source profiles for a four-component heteromer, a ferredoxin-unit reaction, generic ferredoxin classes, hydrolytic composite cancellation and a directly named reaction. Producer and consumer retain and reconstruct complete source XML with exact metadata, original hashes, canonical JSON type comparison, companion provenance, preselection conflict guards, category and label checks. Existing profiles remain unchanged. Add the independently verified union of 32 source terms/owners, 11 ontology terms and 32 source-manifest rows while preserving every existing value and the 1322-row manifest prefix. Independent review passed 2077 regression tests, 66 additional negative probes, all 33 selected source owners, 23 ontology terms and 551 complete selected SQL rows, and the full 263-record identifier consumer. Complete scientific-record and production approval remain separately required.',
        },
    ]
    receipts = []
    for job in jobs:
        argv = [PYTHON, '-B', 'scripts/new_history_record.py', *job['args'], '--actor-name', 'Codex', '--actor-type', 'ai_agent', '--agent-tool', 'codex', '--summary', job['summary'], '--details', job['details']]
        result = subprocess.run(argv, cwd=W, env=environment, capture_output=True, text=True)
        log = CI / ('native-history-' + job['name'] + '.log')
        with log.open('x') as stream:
            stream.write(result.stdout)
            stream.write(result.stderr)
        assert result.returncode == 0, result.stderr
        path = Path(result.stdout.strip().splitlines()[-1])
        if not path.is_absolute():
            path = W / path
        assert path.is_relative_to(W / 'history') and path.is_file()
        receipts.append({'name': job['name'], 'argv': argv, 'exit_code': result.returncode, 'path': str(path.relative_to(W)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'log': str(log)})
    with (CI / 'native-integration-history.json').open('x') as stream:
        json.dump({'observed_at': datetime.now(timezone.utc).isoformat(), 'native_scaffolder': 'scripts/new_history_record.py', 'actor': 'Codex', 'records': receipts}, stream, indent=2)
        stream.write('\n')
    print(json.dumps(receipts, indent=2))


if __name__ == '__main__':
    main()
