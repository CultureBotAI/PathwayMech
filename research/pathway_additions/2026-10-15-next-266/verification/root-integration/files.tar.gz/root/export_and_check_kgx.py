"""Export the actual corpus and compare complete record claims and old edges."""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import io
import json
import os
import re
import subprocess

import yaml

W = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
OUT = CI / 'kgx-export'
BASE = 'dd780ef273323efd638eacd63625963062e0b105'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def rows(body):
    return list(csv.DictReader(io.StringIO(body.decode()), delimiter='\t'))


def emit(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    assert not OUT.exists()
    record_path = W / 'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'
    original = record_path.read_bytes()
    assert sha(original) == 'e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9'
    record = yaml.safe_load(original)
    environment = dict(os.environ)
    environment.update(PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH=str(W / 'src') + ':' + str(W), UV_NO_SYNC='1', UV_PROJECT_ENVIRONMENT='/private/tmp/pathwaymech-next-263-verified-venv', UV_CACHE_DIR='/private/tmp/pathwaymech-next-266-uv-cache')
    command = ['just', 'kgx-export', '--output-dir', str(OUT)]
    start = datetime.now(timezone.utc).isoformat()
    with (CI / 'kgx-export.log').open('x') as stream:
        result = subprocess.run(command, cwd=W, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    receipt = {'command': command, 'started_utc': start, 'finished_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode, 'record_sha256': sha(original), 'record_unchanged': record_path.read_bytes() == original, 'log_sha256': sha((CI / 'kgx-export.log').read_bytes())}
    emit(CI / 'kgx-export-receipt.json', receipt)
    assert result.returncode == 0 and receipt['record_unchanged']
    edges_body = (OUT / 'edges.tsv').read_bytes()
    nodes_body = (OUT / 'nodes.tsv').read_bytes()
    assert edges_body == (W / 'pages/downloads/edges.tsv').read_bytes()
    assert nodes_body == (W / 'pages/downloads/nodes.tsv').read_bytes()
    edges = rows(edges_body)
    nodes = {r['id']: r for r in rows(nodes_body)}
    prefix = 'pathwaymech:MetaCyc_CENTBENZCOA-PWY_'
    selected = [r for r in edges if r['id'].startswith(prefix)]
    assert len(selected) == len(record['mechanistic_edges']) == 76
    predicates = {'provides_input_for': 'RO:0002413', 'part_of': 'BFO:0000050', 'has_part': 'BFO:0000051', 'occurs_in': 'BFO:0000066', 'located_in': 'RO:0001025', 'has_input': 'RO:0002233', 'has_output': 'RO:0002234', 'causally_upstream_of': 'RO:0002411'}
    references = {r['id']: r for r in record['references']}
    checked = []
    for edge in record['mechanistic_edges']:
        safe_id = re.sub(r'[^A-Za-z0-9._-]+', '_', edge['id'])
        matches = [r for r in selected if r['id'].startswith(prefix + safe_id + '_')]
        assert len(matches) == 1, edge['id']
        row = matches[0]
        assert row['subject'] == edge['subject'] and row['object'] == edge['object']
        assert row['predicate'] == predicates.get(edge['predicate'], 'pathwaymech:' + edge['predicate'])
        assert row['description'] == edge.get('description', '')
        assert json.loads(row['evidence']) == edge['evidence']
        qualifiers = edge.get('endpoint_qualifiers', [])
        assert (json.loads(row['endpoint_qualifiers']) if row['endpoint_qualifiers'] else []) == qualifiers
        cited = sorted({e['reference_id'] for e in edge['evidence']} | {e['reference_id'] for q in qualifiers for e in q['evidence']})
        assert row['source_records'] == '|'.join(cited)
        assert json.loads(row['reference_metadata']) == [references[i] for i in cited]
        checked.append({'record_edge_id': edge['id'], 'exported_edge_id': row['id'], 'evidence': len(edge['evidence']), 'qualifiers': len(qualifiers), 'complete_claim_equal': True})
    contexts = []
    for collection, items in [('pathway', [{'label': record['label']}]), ('taxa', record['taxa']), ('participants', record['participants']), ('reactions', record['reactions'])]:
        for item in items:
            identifier = record['id'] if collection == 'pathway' else item['id']
            expected = {'record_id': record['id'], 'collection': collection, **item}
            actual = [r for r in json.loads(nodes[identifier]['source_contexts']) if r['record_id'] == record['id'] and r['collection'] == collection]
            assert actual == [expected], (identifier, actual, expected)
            contexts.append({'id': identifier, 'collection': collection, 'complete_context_equal': True})
    assert len(contexts) == 56
    old_body = subprocess.check_output(['git', 'show', BASE + ':pages/downloads/edges.tsv'], cwd=W)
    old_edges = rows(old_body)
    by_id = {r['id']: r for r in edges}
    assert len(by_id) == len(edges)
    assert all(by_id[r['id']] == r for r in old_edges)
    assert set(by_id) - {r['id'] for r in old_edges} == {r['id'] for r in selected}
    emit(CI / 'kgx-record-fidelity.json', {'observed_at': datetime.now(timezone.utc).isoformat(), 'record_sha256': sha(original), 'record_edges_checked': checked, 'named_contexts_checked': contexts, 'all_prior_edge_rows_exact': len(old_edges), 'added_edge_rows': len(selected), 'actual_cli_exports_equal_generated_downloads': True, 'outputs': [{'path': str(p), 'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size} for p in sorted(OUT.glob('*.tsv'))], 'scope': 'Complete direct YAML-to-TSV comparison for all76edges and56localnodecontexts, every qualifier/evidence/reference payload, plus exact preservation of every baseline edge row. This is export fidelity, not new scientific acceptance.'})
    print(json.dumps({'record_edges': len(checked), 'named_contexts': len(contexts), 'old_edges_preserved': len(old_edges), 'export_equals_generated': True}))


if __name__ == '__main__':
    main()
