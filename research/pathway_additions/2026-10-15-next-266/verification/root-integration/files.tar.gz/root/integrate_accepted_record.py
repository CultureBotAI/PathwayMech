"""Guarded integration of exact reviewed next266 record and identifier proposals."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import tempfile

import yaml

W = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
P = Path('/private/tmp/pathwaymech-next-266-integration-preparation')
A = Path('/private/tmp/pathwaymech-next-266-authority')
BASE = 'dd780ef273323efd638eacd63625963062e0b105'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def read(path):
    return json.loads(path.read_bytes())


def strict(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'))


def main():
    assert not (CI / 'maintained-record-integration.json').exists()
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert git('branch', '--show-current').decode().strip() == 'feat/pathway-next-266-20261015'
    approval = CI / 'independent-merged-successor-root-intake.json'
    approved = read(approval)
    assert approved['status'] == 'accepted bounded provenance correction'
    assert approved['issue'] == 590 and approved['new_findings'] == 0
    assert approved['source_successor_manifest_sha256'] == 'e6abf44f1e5d78731a282fbc860635498915b059b7fbb0a1ce6b52963a16c8f7'
    controls = [
        'authored-design-root-intake.json', 'independent-design-root-intake.json',
        'independent-authority-root-intake.json', 'independent-merged-discovery-root-intake.json',
        'independent-merged-successor-root-intake.json',
    ]
    bindings = [{'path': str(CI / n), 'sha256': sha((CI / n).read_bytes())} for n in controls]
    final_code = read(Path('/private/tmp/pathwaymech-next-266-independent-authority-review/final-integrity.json'))
    for row in final_code['all16_authored_files_unchanged']:
        body = (W / row['path']).read_bytes()
        assert sha(body) == row['sha256'] and len(body) == row['bytes'], row['path']
    names = sorted(n.decode() for n in git('ls-tree', '-rz', '--name-only', BASE, '--', 'data/pathways').split(b'\0') if n and n.decode().endswith('.yaml'))
    actual = sorted(str(p.relative_to(W)) for p in (W / 'data/pathways').rglob('*.yaml'))
    assert len(names) == 262 and names == actual
    old_records = []
    for name in names:
        current = W / name
        assert not current.is_symlink()
        body = git('show', BASE + ':' + name)
        assert current.read_bytes() == body
        old_records.append({'path': name, 'sha256': sha(body), 'bytes': len(body)})
    serialized = read(P / 'record-serialization.json')
    record = P / 'benzoyl-coa-degradation-ii-anaerobic.yaml'
    record_bytes = record.read_bytes()
    assert sha(record_bytes) == serialized['yaml_sha256'] == 'e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9'
    design_path = Path('/private/tmp/pathwaymech-next-266-design/provisional-record-design.json')
    assert sha(design_path.read_bytes()) == serialized['design_sha256']
    assert strict(yaml.safe_load(record_bytes)) == strict(read(design_path))
    record_target = 'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'
    assert not (W / record_target).exists()
    proposals = []
    for row in serialized['authority_proposals']:
        source = Path(row['source'])
        body = source.read_bytes()
        assert sha(body) == row['sha256'] and len(body) == row['bytes']
        destination = row['destination']
        baseline = git('show', BASE + ':' + destination)
        assert (W / destination).read_bytes() == baseline
        old, new = json.loads(baseline), json.loads(body)
        if destination.endswith('identifier_sources.json'):
            assert len(old) == 1322 and len(new) == 1354 and new[:len(old)] == old
        else:
            for field in ['sources', 'terms']:
                assert all(strict(new[field][k]) == strict(v) for k, v in old[field].items())
        proposals.append({'destination': destination, 'body': body, 'before_sha256': sha(baseline), 'source': str(source)})
    proposals.append({'destination': record_target, 'body': record_bytes, 'before_sha256': None, 'source': str(record)})
    changes = []
    for row in proposals:
        target = W / row['destination']
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.next266-integration-', delete=False) as stream:
            stream.write(row['body'])
            temporary = Path(stream.name)
        os.replace(temporary, target)
        assert target.read_bytes() == row['body']
        changes.append({k: v for k, v in row.items() if k != 'body'} | {'after_sha256': sha(row['body']), 'bytes': len(row['body'])})
    for row in old_records:
        assert sha((W / row['path']).read_bytes()) == row['sha256']
    assert len(list((W / 'data/pathways').rglob('*.yaml'))) == 263
    receipt = {
        'observed_at': datetime.now(timezone.utc).isoformat(),
        'base': BASE, 'branch': 'feat/pathway-next-266-20261015',
        'status': 'exact record and additive authority files integrated; production gates pending',
        'prerequisite_intakes': bindings, 'changes': changes,
        'all262_previous_record_bytes_preserved': old_records,
        'all_previous_registry_values_and_ordered_manifest_prefix_preserved': True,
        'scientific_design_strict_object_equality': True,
        'new_record_count': 263,
        'pending': ['complete evidence retention', 'native history', 'rendering', 'KGX comparison', 'production gates', 'canonical maintained-record reviews', 'PR publication and verified merge'],
    }
    with (CI / 'maintained-record-integration.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'record_count': 263, 'changes': changes, 'old_record_bytes_preserved': 262}, indent=2))


if __name__ == '__main__':
    main()
