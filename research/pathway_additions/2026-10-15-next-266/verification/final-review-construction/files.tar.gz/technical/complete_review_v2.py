from pathlib import Path
import json,hashlib,datetime,subprocess,os
import yaml
O=Path(__file__).parent;W=Path('/private/tmp/pathwaymech-next-266-20261015')
def h(b):return hashlib.sha256(b).hexdigest()
def utc():return datetime.datetime.now(datetime.UTC).isoformat().replace('+00:00','Z')
class AliasFreeDumper(yaml.SafeDumper):
 def ignore_aliases(self,data):return True
r=yaml.safe_load((O/'completed-review.yaml').read_text());r['finished_at']=utc();r['review_id']=datetime.datetime.now(datetime.UTC).strftime('%Y%m%dT%H%M%SZ')+'-next266-independent-technical'
r['notes'].append('The first external YAML validation rejected automatically generated aliases for reused target-ID lists. That attempt, its YAML and logs remain preserved. This explicit successor uses alias-free serialization; no target, assessment, evidence, source hash, finding or gate conclusion was changed. Native validation of the successor is recorded separately before root-owned maintained saving.')
path=O/'completed-review-v2.yaml';path.write_text(yaml.dump(r,Dumper=AliasFreeDumper,sort_keys=False,allow_unicode=True,width=96))
assert yaml.safe_load(path.read_text())==r
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','validate',str(path)];start=utc()
with (O/'native-review-validation-v2.stdout').open('x') as out,(O/'native-review-validation-v2.stderr').open('x') as err:p=subprocess.run(cmd,cwd=W,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'),stdout=out,stderr=err)
receipt={'started_at':start,'finished_at':utc(),'command':cmd,'cwd':str(W),'exit_code':p.returncode,'review_sha256':h(path.read_bytes()),'stdout_sha256':h((O/'native-review-validation-v2.stdout').read_bytes()),'stderr_sha256':h((O/'native-review-validation-v2.stderr').read_bytes()),'scope':'Explicit alias-free successor; native external review validation result. Root owns maintained save.','initial_attempt':{'yaml_sha256':h((O/'completed-review.yaml').read_bytes()),'receipt_sha256':h((O/'native-review-validation.json').read_bytes()),'cause':'Default PyYAML emitted aliases for reused target-ID lists; governed parser rejects aliases. Initial receipt scope labels the operation but exit_code=1 is authoritative; no successful initial validation is claimed.'}}
(O/'native-review-validation-v2.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));assert p.returncode==0
