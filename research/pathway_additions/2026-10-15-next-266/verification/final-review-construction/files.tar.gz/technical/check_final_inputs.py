from pathlib import Path
import json,hashlib,datetime,tarfile,stat,subprocess,difflib,os
import yaml
W=Path('/private/tmp/pathwaymech-next-266-20261015');O=Path(__file__).parent;PREP=Path('/private/tmp/pathwaymech-next-266-maintained-technical-review-preparation');P='research/pathway_additions/2026-10-15-next-266';CI=Path('/private/tmp/pathwaymech-next-266-ci')
def h(b):return hashlib.sha256(b).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:assert k not in d;d[k]=v
 return d
def j(b):return json.loads(b,object_pairs_hook=pairs)
def read(p):return j(p.read_bytes())
def files(p):
 found=[]
 for f in p.rglob('*'):
  assert stat.S_ISDIR(f.lstat().st_mode) or stat.S_ISREG(f.lstat().st_mode),str(f)
  if f.is_file():found.append(str(f.relative_to(p)))
 return set(found)
def verify(body,row):assert len(body)==row['bytes'] and h(body)==row['sha256']
start=datetime.datetime.now(datetime.UTC).isoformat();archive_results={};contents={}
for group,expected in [('final-gates',19),('maintained-review-preparation',224)]:
 d=W/P/'verification'/group;manifest=read(d/'artifact-manifest.json');assert files(d)=={r['path'] for r in manifest['files']}|{'artifact-manifest.json'}
 for row in manifest['files']:verify((d/row['path']).read_bytes(),row)
 sm=read(d/'source-file-manifest.json');byname={r['member']:r for r in sm['files']};assert len(byname)==len(sm['files'])==expected
 values={}
 with tarfile.open(d/'files.tar.gz','r:gz') as tar:
  members=tar.getmembers();assert len(members)==expected and {v.name for v in members}==set(byname)
  for v in members:
   assert v.isfile() and not Path(v.name).is_absolute() and '..' not in Path(v.name).parts
   b=tar.extractfile(v).read();verify(b,byname[v.name]);assert Path(byname[v.name]['source']).read_bytes()==b;values[v.name]=b
 if group=='final-gates':
  original=Path('/private/tmp/pathwaymech-next-266-checks-initial');assert files(original)=={n.removeprefix('full-gates/') for n in values if n.startswith('full-gates/')}
 else:
  for name,root,n in [('technical',PREP,92),('scientific',Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation'),131)]:
   expected_names={v.removeprefix(name+'/') for v in values if v.startswith(name+'/')};assert len(expected_names)==n and files(root)==expected_names
 archive_results[group]={'manifest_sha256':h((d/'artifact-manifest.json').read_bytes()),'archive_sha256':h((d/'files.tar.gz').read_bytes()),'source_manifest_sha256':h((d/'source-file-manifest.json').read_bytes()),'complete_exact_members':expected,'hidden_ignored_original_inventories_exact':True}
 contents[group]=values
f=contents['final-gates'];receipts=j(f['full-gates/receipts.json']);assert [r['command'] for r in receipts]==[['just','render-pages'],['just','validate'],['just','test'],['just','lint'],['git','diff','--check']]
for r in receipts:
 assert r['exit_code']==0 and r['cwd']==str(W);log=f['full-gates/'+Path(r['log_path']).name];assert h(log)==r['log_sha256']
preservation=j(f['full-gates/final-input-preservation.json']);tested=j(f['full-gates/tested-core-input-hashes.json']);assert preservation['all_unchanged'] and len(tested)==preservation['tested_core_files']==29503
changed=[];unchanged=[]
for name,digest in tested.items():
 now=h((W/name).read_bytes())
 if now!=digest:changed.append({'path':name,'tested_sha256':digest,'current_sha256':now})
 else:unchanged.append(name)
assert [r['path'] for r in changed]==[P+'/README.md'],changed
assert changed[0]['current_sha256']=='cb8ad4faf2e342c3b3947a156d6dfeb8e51b310b15efe23e11a50d5657784980'
# Enumerate actual current scope with the same cache exclusion; ignored/hidden paths are retained.
raw=subprocess.check_output(['git','-C',str(W),'ls-files','-co','-z','--',*preservation['scope']]);current={p.decode() for p in raw.split(b'\0') if p and (W/p.decode()).is_file() and not {'__pycache__','.pytest_cache','.ruff_cache'}&set(Path(p.decode()).parts)}
assert set(tested)<=current
additions=sorted(current-set(tested));expected_additions={P+'/verification/'+g+'/'+name for g in ['final-gates','maintained-review-preparation'] for name in ['README.md','artifact-manifest.json','source-file-manifest.json','files.tar.gz']}
history='history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml';expected_additions.add(history);assert set(additions)==expected_additions,additions
hr=read(CI/'report-final-gate-update.json');assert hr['exit_code']==0 and hr['previous_sha256']==changed[0]['tested_sha256'];assert hr['current_sha256']==changed[0]['current_sha256'];assert h((W/history).read_bytes())==hr['history']['sha256'];assert h(Path(hr['log']).read_bytes())==hr['log_sha256']
old=(PREP/'retention-integration/captured-new-context'/P/'README.md').read_text();new=(W/P/'README.md').read_text();assert h(old.encode())==changed[0]['tested_sha256']
(O/'final-report-update.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='tested-research-report',tofile='final-current-research-report')))
# Empty command cases are explained by actual source and hidden/ignored-inclusive directory inventory.
claude=sorted(str(p.relative_to(W)) for p in (W/'.claude').rglob('*'));commands=[n for n in claude if n.startswith('.claude/commands/') and n.endswith('.md')];skills=[n for n in claude if n.lower().endswith('/skill.md')];assert len(skills)==9 and not commands and not (W/'.claude/commands').exists()
assert b'5489 passed, 3 skipped, 7 warnings' in f['full-gates/just-test.log'];assert b'..sss' in f['full-gates/just-test.log']
# Reinspect final actual target and all prior contexts plus the new owners.
initial=read(PREP/'retention-integration/inspect-v2.json');target=initial['targets'][0];inputs={r['path'] for r in initial['source']['inputs'] if r['path']!=target['path']};inputs.update(additions);inputs.add('tests/test_skill_frontmatter.py');
(O/'final-targets.yaml').write_text(yaml.safe_dump({'targets':[target]},sort_keys=False))
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(O/'final-targets.yaml')]
for name in sorted(inputs):cmd+=['--input',name]
with (O/'final-inspect.json').open('x') as out,(O/'final-inspect.stderr').open('x') as err:r=subprocess.run(cmd,cwd=W,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1'),stdout=out,stderr=err)
assert r.returncode==0
result={'started_utc':start,'finished_utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'complete final input, archive and gate binding passed','archives':archive_results,'root_gate_receipts':receipts,'all_29503_tested_inputs_preserved_during_root_gates':preservation,'tested_inputs_unchanged_now':len(unchanged),'reviewed_post_gate_changes':changed,'reviewed_post_gate_additions':additions,'skipped_tests':{'count':3,'scope':'Three command-file parametrizations in tests/test_skill_frontmatter.py have no command files. Complete .claude walk includes hidden/ignored paths; nine skill files exist, command directory absent. Test log does not print individual skip reasons; attribution follows source and exact current discovery scope.','skill_count':len(skills),'command_count':len(commands)},'inspect_command':cmd,'inspect_exit_code':r.returncode,'inspect_sha256':h((O/'final-inspect.json').read_bytes()),'limits':['Full-gate executions are root-owned and were not rerun by this reviewer.','All 29,503 inputs were unchanged through the recorded gate window. Subsequently one reviewed report update and nine exact archive/history additions occurred; no code/data/registry/generated content changed.','Final review saving, targeted new report/history/review checks and staged-index validation remain root publication tasks.']}
(O/'final-input-assessment.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'tested_unchanged_now':len(unchanged),'reviewed_changes':len(changed),'reviewed_additions':len(additions),'final_input_count':len(inputs)+1}))
