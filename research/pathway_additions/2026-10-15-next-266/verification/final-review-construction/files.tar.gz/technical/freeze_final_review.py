from pathlib import Path
import json,hashlib,datetime,stat,subprocess
import yaml
O=Path(__file__).parent;W=Path('/private/tmp/pathwaymech-next-266-20261015')
def h(b):return hashlib.sha256(b).hexdigest()
def now():return datetime.datetime.now(datetime.UTC).isoformat().replace('+00:00','Z')
r=yaml.safe_load((O/'completed-review-v2.yaml').read_text());validation=json.loads((O/'native-review-validation-v2.json').read_text());assert validation['exit_code']==0 and h((O/'completed-review-v2.yaml').read_bytes())==validation['review_sha256'];assert r['completion']=='completed' and r['verdict']=='pass_with_limitations' and not r['scientific_review'] and r['findings']==[]
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD']).decode().strip()==r['source']['git_revision']
for row in r['source']['inputs']:assert h((W/row['path']).read_bytes())==row['sha256'],row['path']
(O/'final-input-integrity.json').write_text(json.dumps({'observed_at':now(),'source_git_revision':r['source']['git_revision'],'working_tree_inputs':len(r['source']['inputs']),'all_final_inspected_inputs_unchanged':True,'review_id':r['review_id'],'review_sha256':validation['review_sha256'],'native_validation_exit_code':0,'native_validation_stdout':'{"valid_reviews": 1}','native_validation_warning':'topClass is deprecated - use top_class','maintained_save_performed':False},indent=2)+'\n')
(O/'attempt-dispositions.json').write_text(json.dumps({'review_yaml_serialization':{'first_attempt':'completed-review.yaml','native_validation_exit_code':1,'reason':'Default PyYAML emitted aliases for reused target-ID lists; governed parser rejects aliases.','successor':'completed-review-v2.yaml','native_validation_exit_code_successor':0,'correction':'AliasFreeDumper, later review identity/finish time and explicit attempt note. No scientific, implementation, gate, target or source hash changed.','initial_inputs_and_logs_preserved':True},'exploratory_source_map_read':{'attempt':'Guessed packages/independent-authority-review/manifest.json path was absent.','recovery':'Ignored/hidden-inclusive rg inventory identified source-map.json and README.md. No absence finding or mutation relied on the guessed name.'}},indent=2)+'\n')
text=f'''# Final independent next266 technical review handoff

**Completed external technical review: pass with limitations; no actionable findings.**

The root should save **`completed-review-v2.yaml`**, review ID `{r['review_id']}`, SHA256 `{validation['review_sha256']}`. Native governed validation returned exit 0 and `{{"valid_reviews": 1}}`; the only stderr is the dependency's `topClass` deprecation notice. The earlier `completed-review.yaml` is an intentionally retained rejected serialization attempt, not the final review. No canonical YAML/Markdown bundle has been saved by this reviewer; root owns the sole maintained save and native Markdown rendering.

The review binds one complete maintained `MetaCyc:CENTBENZCOA-PWY` target and {len(r['source']['inputs'])} actual current inputs at working-tree base `{r['source']['git_revision']}`. The YAML target remains `e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9`; final research report remains `cb8ad4faf2e342c3b3947a156d6dfeb8e51b310b15efe23e11a50d5657784980`. Every final inspected input was rehashed unchanged immediately before freezing. The full prior technical preparation directory remains immutable and its complete layout is retained in the maintained preparation archive.

## Completed evidence and scope

The review preserves the independent 16-file authority implementation binding, complete strict additive registry comparisons and all 262 unchanged prior YAML records. Complete KGX/SVG checks cover every 76 new edge, 56 local context, 13,613 previous edge row, all previous node contexts/other node fields, all graph qualified display instances and local anchors. All seven generated outputs remain exact after final render. Three root screenshots were personally inspected; browser execution and prior 2,077 tests/66 probes are attributed to their actual executors.

Actual retained evidence checks include every 3,343 maintained payload file, 3,598 later verification occurrence, complete original 72/3,448/50-file review/author layouts, all 502 actual Git/current storage owners and exact whole-map correction of only 586 optional tree fields across 301 paths. All other 4,757 map-row values and 250 optional omissions remain unchanged. Source/compact decoder executions and scientific claims remain correctly attributed and scoped.

Final retained proof checks independently verify all 19 full-gate archive members and all 224 maintained-review-preparation members, including exact original hidden/ignored inventories (92 technical, 131 scientific and one helper). Root full gates passed: render, validate, 5,489 tests passed / three skipped / seven dependency warnings, lint and tracked working-tree whitespace. All 29,503 inputs remained unchanged during that execution. This reviewer then rehashed the entire 29,503-file inventory: 29,502 remain exact, with only the explicitly reviewed final report change; exactly nine subsequent additions are the two four-file proof packages and the native EDIT history. No code, pathway, authority or generated bytes changed. The three skips follow the three command-file parametrizations with an absent command directory; the complete hidden/ignored-inclusive `.claude` walk found nine skills and no command files. No new full tests were run.

The final report delta and fifth native history were explicitly read. Their dated statements distinguish passed full gates from still-subsequent canonical persistence and publication. The new final construction directory is retained separately and must not be claimed inside its own source manifest or the earlier frozen scientific cutoff.

## Limits and execution

This is a complementary technical review with `scientific_review: false`; biological acceptance belongs to the separate independent scientific review. It makes no licensing, source-exhaustion, PR, issue-closure or merge claim. Root retains ownership of maintained save, targeted validation of new report/history/review artifacts, actual staged-index validation and publication. A valid completed review does not authorize or prove those later actions.

The first native validation rejected YAML aliases; its original YAML, helper and logs remain unchanged. The explicit v2 uses alias-free serialization and validates. The final input-check session 65226 terminated successfully; no reviewer process remains live. Only this external directory was written. No maintained file, prior preparation, Git/GitHub state or shared runtime was changed. This handoff releases all live worktree reads.
'''
(O/'HANDOFF.md').write_text(text)
rows=[]
for p in sorted(O.rglob('*')):
 st=p.lstat();assert stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode),str(p)
 if p.is_file():rows.append({'path':str(p.relative_to(O)),'bytes':p.stat().st_size,'sha256':h(p.read_bytes())})
manifest={'scope':'Complete frozen final technical construction directory, hidden and ignored files included; only subsequently created artifact-manifest.json and freeze-proof.json excluded. Initial rejected serialization, explicit passing successor, all helpers, complete native logs and final input proof are retained.','files':rows}
(O/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
freeze={'observed_at':now(),'listed_files':len(rows),'physical_files':len(rows)+2,'manifest_sha256':h((O/'artifact-manifest.json').read_bytes()),'handoff_sha256':h((O/'HANDOFF.md').read_bytes()),'final_review_sha256':validation['review_sha256'],'review_id':r['review_id'],'all_inspected_inputs_unchanged':True,'native_validation_exit_code':0,'maintained_save_performed':False}
(O/'freeze-proof.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps(freeze))
