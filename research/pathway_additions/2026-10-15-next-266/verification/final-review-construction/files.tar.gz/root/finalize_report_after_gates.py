"""Record completed gates and append native research history before final review."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

REPO = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
CHECKS = Path('/private/tmp/pathwaymech-next-266-checks-initial')
REPORT = 'research/pathway_additions/2026-10-15-next-266/README.md'
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    receipt = CI / 'report-final-gate-update.json'
    assert not receipt.exists()
    gates = json.loads((CHECKS / 'receipts.json').read_text())
    assert len(gates) == 5 and all(row['exit_code'] == 0 for row in gates)
    assert json.loads((CHECKS / 'final-input-preservation.json').read_text())['all_unchanged']
    for name in ['final-gate-evidence-promotion.json', 'maintained-review-preparation-promotion.json']:
        assert (CI / name).is_file()
    report = REPO / REPORT
    previous = report.read_text()
    previous_sha = sha(report)
    old = '''This report and the [integration verification archive](verification/root-integration/README.md)
are present in the maintained worktree, alongside the corrected source
retention and complete technical retention-review evidence. The native
`just vendored-check` passed all 22 artifacts selected by the pinned canonical
manifest. Final production validation/tests/lint, canonical scientific/technical
review persistence, PR publication and verified merge remain pending. Earlier
source/design documents retain their historical pending statements; current
completion requires separately dated receipts. No global pathway-source
exhaustion is claimed.
'''
    assert previous.count(old) == 1
    now = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    new = f'''This report and the [integration verification archive](verification/root-integration/README.md)
are present in the maintained worktree, alongside the corrected source
retention and complete technical retention-review evidence. The native
`just vendored-check` passed all 22 artifacts selected by the pinned canonical
manifest.

As of this report's final gate update at **{now}**, the complete
`just render-pages`, `just validate`, `just test`, `just lint` and
`git diff --check` run has passed. The [full gate evidence](verification/final-gates/README.md)
retains every complete command log, receipt and exact tested-input inventory.
All declared inputs remained unchanged through that run and archive adoption.
The earlier wrapper prerequisite error occurred before any gate ran and is
preserved separately. Actual staged-index checks are a later publication step.

Both independent reviewers found no new actionable defect in their completed
preparation scopes. Their [complete maintained-record preparations](verification/maintained-review-preparation/README.md)
preserve all 92 technical and 131 scientific files, including current retained
source ownership, report, history and generated-output checks. Their original
pending statements remain historical. Canonical scientific and technical review
persistence, PR publication and verified merge are subsequent steps; this dated
report does not claim they have occurred. No global pathway-source exhaustion
is claimed.
'''
    with (CI / 'README.before-final-gate-update.md').open('x') as stream:
        stream.write(previous)
    report.write_text(previous.replace(old, new))
    command = [PYTHON, '-B', 'scripts/new_history_record.py',
        '--kind', 'other', '--slug', 'benzoyl-coa-anaerobic-research', '--path', REPORT,
        '--event', 'EDIT', '--outcome', 'changed', '--actor-name', 'Codex',
        '--actor-type', 'ai_agent', '--agent-tool', 'codex',
        '--summary', 'Retain complete production gates and independent maintained-record review preparations',
        '--details', 'Record the actual terminal render, validate, test, lint and working-tree whitespace results, with complete logs and tested-input preservation. Retain all 92 technical and 131 scientific preparation files, including the independently checked actual source retention, generated outputs and history. Both reviewers found no new actionable defects in their declared scopes. Preserve the earlier wrapper prerequisite failure as a separate pre-gate scheduling observation. No scientific, authority, code or generated-page content changed. The dated report explicitly leaves canonical review persistence, actual staging, PR publication and verified merge as subsequent observations; no global pathway-source exhaustion is claimed.']
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
        PYTHONPATH=str(REPO / 'src') + ':' + str(REPO))
    result = subprocess.run(command, cwd=REPO, env=env, text=True, capture_output=True)
    log = CI / 'native-history-final-gates.log'
    with log.open('x') as stream:
        stream.write(result.stdout)
        stream.write(result.stderr)
    record = {'observed_at': now, 'report': REPORT, 'previous_sha256': previous_sha,
        'current_sha256': sha(report), 'command': command, 'exit_code': result.returncode,
        'log': str(log), 'log_sha256': sha(log)}
    if result.returncode == 0:
        path = Path(result.stdout.strip().splitlines()[-1])
        if not path.is_absolute():
            path = REPO / path
        assert path.is_relative_to(REPO / 'history') and path.is_file()
        record['history'] = {'path': str(path.relative_to(REPO)), 'sha256': sha(path)}
    with receipt.open('x') as stream:
        json.dump(record, stream, indent=2)
        stream.write('\n')
    print(json.dumps(record), flush=True)
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
