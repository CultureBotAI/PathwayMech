"""Independently bind stable final inputs and preserved root-run gate evidence.

Read-only in the maintained worktree; all new outputs are external.
"""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path, PurePosixPath
import difflib
import gzip
import io
import json
import os
import subprocess
import tarfile
import yaml

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'finalization'
OUT.mkdir(exist_ok=False)
W = Path('/private/tmp/pathwaymech-next-266-20261015')
P = Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
R = 'research/pathway_additions/2026-10-15-next-266'
REPORT = R + '/README.md'
HISTORY = 'history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml'
REPORT_SHA = 'cb8ad4faf2e342c3b3947a156d6dfeb8e51b310b15efe23e11a50d5657784980'
HISTORY_SHA = 'c481e4bc95284a17d0059f90d1a6648a32c3b6ac1a9b3144b92e02c456d18f7d'
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'
START = datetime.now(timezone.utc).isoformat().replace('+00:00','Z')

def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')

def h(b):
    return sha256(b).hexdigest()

def write(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+'\n')

prior = json.loads((P/'retention-integration/inspect.stdout.json').read_text())
prior_inputs = {x['path']:x['sha256'] for x in prior['source']['inputs']}
paths = set(prior_inputs)
paths.add(HISTORY)
paths.add('tests/test_skill_frontmatter.py')
for package in ('final-gates','maintained-review-preparation'):
    paths.update(f'{R}/verification/{package}/{n}' for n in ('README.md','artifact-manifest.json','source-file-manifest.json','files.tar.gz'))
rows = []
changes = []
for rel in sorted(paths):
    p=W/rel
    assert p.is_file() and not p.is_symlink(), rel
    raw=p.read_bytes()
    row={'path':rel,'sha256':h(raw),'bytes':len(raw),'prior_sha256':prior_inputs.get(rel)}
    rows.append(row)
    if rel in prior_inputs and h(raw)!=prior_inputs[rel]:
        changes.append(row)
assert len(changes)==1 and changes[0]['path']==REPORT and changes[0]['sha256']==REPORT_SHA,changes
assert h((W/HISTORY).read_bytes())==HISTORY_SHA
write('captured-final-inputs.json',{'captured_at':now(),'prior_inputs':len(prior_inputs),'unchanged_prior_inputs':len(prior_inputs)-1,'explicit_changes':changes,'new_inputs':[r for r in rows if r['prior_sha256'] is None],'files':rows})
for rel in (REPORT,HISTORY):
    (OUT/('final-report.md' if rel==REPORT else 'final-history.yaml')).write_bytes((W/rel).read_bytes())
old=(P/'retention-integration/captured-new-context'/REPORT).read_text()
new=(W/REPORT).read_text()
(OUT/'final-report.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='prior inspected report',tofile='final dated report')))
(OUT/'targets.yaml').write_text(yaml.safe_dump({'targets':prior['targets']},sort_keys=False))
argv=[PYTHON,'-B','scripts/record_review.py','inspect','--targets',str(OUT/'targets.yaml')]
for rel in sorted(paths-{x['path'] for x in prior['targets']}):
    argv+=['--input',rel]
env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
beg=now(); result=subprocess.run(argv,cwd=W,env=env,capture_output=True)
(OUT/'inspect.stdout.json').write_bytes(result.stdout);(OUT/'inspect.stderr.txt').write_bytes(result.stderr)
write('inspect-receipt.json',{'started_at':beg,'finished_at':now(),'argv':argv,'cwd':str(W),'exit_code':result.returncode,'stdout_sha256':h(result.stdout),'stderr_sha256':h(result.stderr),'scope':'Fresh exact final input binding, read-only; not scientific acceptance.'})
assert result.returncode==0,result.stderr.decode()
inspected=json.loads(result.stdout)
assert {r['path']:r['sha256'] for r in inspected['source']['inputs']}=={r['path']:r['sha256'] for r in rows}

archives={}; archive_proof=[]
for package,expected_count,expected_sha in [('final-gates',19,'1c84c6bb66edc629f400878a90ec627e11692cb516f91a050247a5e4dc07bc84'),('maintained-review-preparation',224,'6d74786f8abcdbc5706a62f13220f2fbbbd56820e968cddf755dbc3b62e59a0e')]:
    base=W/R/'verification'/package
    source=json.loads((base/'source-file-manifest.json').read_text())
    raw=(base/'files.tar.gz').read_bytes()
    assert h(raw)==source['archive_sha256']==expected_sha
    assert len(raw)==source['archive_bytes']
    declared={r['member']:r for r in source['files']}
    assert len(declared)==len(source['files'])==expected_count
    contents={}
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
        for member in tar.getmembers():
            path=PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in contents and member.name in declared
            content=tar.extractfile(member).read()
            entry=declared[member.name]
            assert h(content)==entry['sha256'] and len(content)==entry['bytes']
            original=Path(entry['source']).read_bytes()
            assert content==original
            contents[member.name]=content
    assert set(contents)==set(declared)
    if package=='maintained-review-preparation':
        scientific={k.removeprefix('scientific/'):h(v) for k,v in contents.items() if k.startswith('scientific/')}
        prior_inventory=json.loads((ROOT/'draft/prior-preparation-inventory.json').read_text())
        assert scientific=={r['path']:r['sha256'] for r in prior_inventory['files']}
        assert len(scientific)==131
        assert sum(k.startswith('technical/') for k in contents)==92
    archives[package]=contents
    archive_proof.append({'package':package,'archive_repository_path':f'{R}/verification/{package}/files.tar.gz','archive_sha256':h(raw),'source_manifest_sha256':h((base/'source-file-manifest.json').read_bytes()),'member_count':len(contents),'all_members_regular_relative_unique':True,'all_members_exact_original_bytes':True,'members':source['files']})
write('final-archive-independent-verification.json',{'started_at':START,'finished_at':now(),'status':'pass','archives':archive_proof,'scope':'Complete independent byte comparison of both actual maintained archives, not only author helper success; prior 131 scientific files immutable.'})

gates=archives['final-gates']
receipts=json.loads(gates['full-gates/receipts.json'])
assert [r['command'] for r in receipts]==[['just','render-pages'],['just','validate'],['just','test'],['just','lint'],['git','diff','--check']]
for r in receipts:
    assert r['exit_code']==0 and r['cwd']==str(W)
    assert h(gates['full-gates/'+Path(r['log_path']).name])==r['log_sha256']
testlog=gates['full-gates/just-test.log'].decode()
assert '5489 passed, 3 skipped, 7 warnings in 969.95s' in testlog
assert 'tests/test_skill_frontmatter.py' in testlog
preservation=json.loads(gates['full-gates/final-input-preservation.json'])
assert preservation['all_unchanged'] is True and preservation['tested_core_files']==29503 and preservation['ignored_and_hidden_included'] is True
tested=json.loads(gates['full-gates/tested-core-input-hashes.json'])
assert len(tested)==29503
current_changes=[]
for rel,expected in tested.items():
    p=W/rel
    assert p.is_file() and not p.is_symlink(),rel
    digest=h(p.read_bytes())
    if digest!=expected:
        current_changes.append({'path':rel,'tested_sha256':expected,'current_sha256':digest})
assert len(current_changes)==1 and current_changes[0]['path']==REPORT and current_changes[0]['current_sha256']==REPORT_SHA,current_changes
# A directory walk includes hidden/ignored entries and follows no symlinks.
claude_paths=[]
for d,dirs,files in os.walk(W/'.claude',followlinks=False):
    for name in dirs+files:
        q=Path(d)/name
        assert not q.is_symlink(),str(q)
        claude_paths.append(q.relative_to(W).as_posix())
assert '.claude/commands' not in claude_paths
skills=[x for x in claude_paths if x.lower().endswith('/skill.md')]
assert len(skills)==9
write('terminal-gate-binding.json',{'checked_at':now(),'status':'pass','attribution':'Root executed the single complete production run; this independent reviewer read all logs and verified exact receipts, archive members, preserved inputs and current limited differences. No full gate was rerun.','receipts':receipts,'pytest':{'passed':5489,'skipped':3,'warnings':7,'elapsed_seconds':969.95},'skip_scope':'Three empty COMMAND_FILES parametrizations in test_skill_frontmatter.py; current unchanged source and complete hidden/ignored-inclusive .claude walk show 9 skills and no commands directory. No pathway scientific check was skipped.','warnings_scope':'One LinkML/SSSOM dataclass deprecation, one pandas copy_on_write deprecation and five SSSOM infer_objects(copy=False) warnings; original full text retained.','tested_files_rehashed':len(tested),'tested_files_unchanged_now':len(tested)-len(current_changes),'explicit_post_gate_report_change':current_changes,'final_additions':'Two four-file verification archives and one native history were added after the root run. Their exact bytes and prose are separately inspected; the original run is not misrepresented as testing future additions.','test_source_sha256':h((W/'tests/test_skill_frontmatter.py').read_bytes()),'hidden_ignored_included':True,'claude_walk':claude_paths,'failed_wrapper_observation':json.loads(gates['root/gate-wrapper-prerequisite-race.json'])})

# Reconfirm all 25 native/publication originals through actual retained owners.
cm=json.loads((W/R/'evidence-retention/content-map.json').read_text())
if 'contents' in cm:
    cm=cm['contents']
reference_rows=json.loads((P/'reference-original-assessment.json').read_text())['rows']
ref_proof=[]
for row in reference_rows:
    digest=row['original_sha256']; entry=cm[digest];storage=entry['storage']
    physical=(W/R/'evidence-retention'/storage['path']) if storage['kind']=='new_retention_object' else W/storage['path']
    raw=physical.read_bytes()
    assert h(raw)==storage['stored_sha256'] and len(raw)==storage['stored_bytes']
    for step in entry.get('decode_steps',[]):
        assert h(raw)==step['input_sha256'] and step['encoding']=='gzip'
        raw=gzip.decompress(raw)
        assert h(raw)==step['output_sha256'] and len(raw)==step['output_bytes']
    assert h(raw)==digest and len(raw)==entry['source_bytes']
    assert raw==Path(row['original']).read_bytes()
    ref_proof.append({'reference':row['reference'],'original_sha256':digest,'original_bytes':len(raw),'repository_storage_path':physical.relative_to(W).as_posix(),'storage':storage,'decode_steps':entry.get('decode_steps',[]),'identity_checks':row['identity_checks']})
write('final-reference-owner-bindings.json',{'accessed_at':now(),'count':len(ref_proof),'status':'pass','rows':ref_proof,'scope':'Fresh bounded byte recovery and owner binding for all 25 originals. Prior complete source readings and independent interpretation are explicitly reused; this is not a fresh human rereading of every paper.'})
for row in rows:
    assert h((W/row['path']).read_bytes())==row['sha256'],row['path']
write('final-stage-state.json',{'started_at':START,'finished_at':now(),'status':'ready for final scientific assessment and external canonical assembly','inspected_inputs':len(rows),'prior_inputs_unchanged_except_explicit_report':True,'all_final_inspected_inputs_still_exact':True,'maintained_writes':False,'runtime_mutations':False,'full_gate_rerun':False})
print(json.dumps({'status':'pass','inspected_inputs':len(rows),'archive_members':243,'prior_scientific_files':131,'tested_files_rehashed':29503,'only_post_gate_existing_file_change':REPORT,'reference_originals':25}))
