"""Preserve initial shape failure; create an explicit external format successor."""
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import json
import os
import shlex
import subprocess
import yaml

ROOT=Path(__file__).resolve().parent
F=ROOT/'finalization'
W=Path('/private/tmp/pathwaymech-next-266-20261015')
PYTHON='/private/tmp/pathwaymech-next-263-verified-venv/bin/python'
def now():return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def digest(b):return sha256(b).hexdigest()
def write(n,o):
    p=F/n;assert not p.exists();p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
source=F/'completed-review.yaml'
review=yaml.safe_load(source.read_text())
assert isinstance(review['notes'],str)
review['notes']=[review['notes'],'The first external draft failed shape validation because notes was serialized as a string rather than the schema list. That exact draft, command receipt and stderr remain retained. This successor changes only that shape, replaces an explicitly abbreviated inspect command with its exact recorded argv, and uses a new actual finish timestamp/review ID; scientific content and all maintained inputs are unchanged.']
inspect_receipt=json.loads((F/'inspect-receipt.json').read_text())
check=next(c for c in review['checks'] if c['check_id']=='check-final-inspection')
check['command']=shlex.join(inspect_receipt['argv'])
check['scope_note']='Exact actual argv is retained here and in finalization/inspect-receipt.json; the input proof confirms all 103 supplied target/context bindings.'
finish=datetime.now(timezone.utc)
review['finished_at']=finish.isoformat().replace('+00:00','Z')
review['review_id']=finish.strftime('%Y%m%dT%H%M%SZ')+'-centbenzcoa-pwy-scientific'
class Dumper(yaml.SafeDumper):
    def ignore_aliases(self,data):return True
out=F/'completed-review.final.yaml'
assert not out.exists()
out.write_text(yaml.dump(review,Dumper=Dumper,allow_unicode=True,sort_keys=False,width=100))
write('canonical-shape-successor.json',{'created_at':now(),'predecessor':source.name,'predecessor_sha256':digest(source.read_bytes()),'successor':out.name,'successor_sha256':digest(out.read_bytes()),'changes':['notes string wrapped as required list; explicit historical shape failure note appended','Abbreviated inspect display replaced with exact recorded full argv and truthful scope note','New actual finished_at and corresponding review_id'],'scientific_content_unchanged':True,'maintained_inputs_unchanged':True,'failure_receipt':'validate-receipt.json','failure_stderr':'validate.stderr.txt'})
env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
commands=[]
for action in ('validate','render'):
    argv=[PYTHON,'-B','scripts/record_review.py',action]+([str(out)] if action=='validate' else ['--content',str(out)])
    begin=now();p=subprocess.run(argv,cwd=W,env=env,capture_output=True)
    (F/(action+'.final.stdout'+('.json' if action=='validate' else '.md'))).write_bytes(p.stdout)
    (F/(action+'.final.stderr.txt')).write_bytes(p.stderr)
    receipt={'started_at':begin,'finished_at':now(),'argv':argv,'cwd':str(W),'exit_code':p.returncode,'stdout_sha256':digest(p.stdout),'stderr_sha256':digest(p.stderr),'review_sha256':digest(out.read_bytes())}
    write(action+'-final-receipt.json',receipt);commands.append(receipt)
    assert p.returncode==0,p.stderr.decode()
for row in review['source']['inputs']:
    assert digest((W/row['path']).read_bytes())==row['sha256'],row['path']
write('completed-review-preparation.json',{'finished_at':now(),'status':'validated external completed review; native save/check remain root-owned','review_id':review['review_id'],'review_path':str(out),'review_sha256':digest(out.read_bytes()),'preview_path':str(F/'render.final.stdout.md'),'preview_sha256':digest((F/'render.final.stdout.md').read_bytes()),'verdict':review['verdict'],'assessments':len(review['assessments']),'evidence':len(review['evidence']),'checks':len(review['checks']),'findings':len(review['findings']),'source_inputs':len(review['source']['inputs']),'all_inputs_rechecked_after_validation':True,'canonical_saved':False,'commands':commands})
print(json.dumps({'status':'native validate and render passed','review_id':review['review_id'],'sha256':digest(out.read_bytes()),'verdict':review['verdict'],'assessments':len(review['assessments']),'checks':len(review['checks']),'evidence':len(review['evidence']),'findings':0,'canonical_saved':False}))
