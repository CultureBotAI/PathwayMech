"""Assemble completed independent assessment after the stable final handoff.

This only writes external review content. The native saver is root-owned.
"""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import tarfile
import yaml

ROOT=Path(__file__).resolve().parent
F=ROOT/'finalization'
W=Path('/private/tmp/pathwaymech-next-266-20261015')
P=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
R='research/pathway_additions/2026-10-15-next-266'
TARGET='MetaCyc:CENTBENZCOA-PWY'
PREPARATION=f'{R}/verification/maintained-review-preparation/files.tar.gz'
GATES=f'{R}/verification/final-gates/files.tar.gz'
PYTHON='/private/tmp/pathwaymech-next-263-verified-venv/bin/python'

def load(p):
    return json.loads(p.read_text())

def now():
    return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')

def digest(b):
    return sha256(b).hexdigest()

def save(name,obj):
    p=F/name
    assert not p.exists(),p
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

stage=load(F/'final-stage-state.json')
assert stage['all_final_inspected_inputs_still_exact'] is True
inspect=load(F/'inspect.stdout.json')
for row in inspect['source']['inputs']:
    assert digest((W/row['path']).read_bytes())==row['sha256'],row['path']
gates=load(F/'terminal-gate-binding.json')
assert gates['status']=='pass' and all(r['exit_code']==0 for r in gates['receipts'])
archives=load(F/'final-archive-independent-verification.json')
accessed=archives['finished_at']
fragment=load(ROOT/'draft/review-content.fragment.json')
plan=load(ROOT/'draft/evidence-binding-plan.json')
evidence=[]
for p in plan['evidence']:
    evidence.append({'evidence_id':p['evidence_id'],'kind':p['kind'] if p['kind']=='validation' else 'prior_review','reference':PREPARATION,'locator':'TAR member scientific/'+p['prior_preparation_relative_path'],'accessed_at':accessed,'support':p['support'],'summary':p['summary']+' This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound.','snapshot_sha256':p['snapshot_sha256']})

def add_ev(eid,kind,reference,locator,summary,sha,when=accessed,support='supports'):
    evidence.append({'evidence_id':eid,'kind':kind,'reference':reference,'locator':locator,'accessed_at':when,'support':support,'summary':summary,'snapshot_sha256':sha})

def prep_ev(eid,rel,kind,summary,support='supports'):
    add_ev(eid,kind,PREPARATION,'TAR member scientific/'+rel,summary,digest((P/rel).read_bytes()),support=support)

refs=load(F/'final-reference-owner-bindings.json')
ref_ids={}
for i,row in enumerate(refs['rows'],1):
    reference=row['reference'];rid=reference['id'];eid=f'source-{i:02d}';ref_ids[rid]=eid
    decode='; '.join(f"gzip {s['input_sha256']} → {s['output_sha256']}" for s in row['decode_steps']) or 'identity storage'
    primary=rid.startswith('PMID:')
    add_ev(eid,'primary_source' if primary else 'database',row['repository_storage_path'],f"Original {rid}; content-map.json key {row['original_sha256']}; {decode}; public same-object/publication link {reference['url']}",reference['title']+'. Complete original source hash and issuing identity verified. '+('Primary claim support is limited to inspected assay/construct paragraphs; unacquired supplements are not treated as read.' if primary else 'Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database.'),row['original_sha256'],refs['accessed_at'])

edge_rows=load(ROOT/'draft/complete-edge-content-binding.json')['rows']
assessment_by_id={a['assessment_id']:a for a in fragment['assessments']}
def original_entries(obj):
    if isinstance(obj,dict):
        if 'reference_id' in obj:
            yield obj
        for v in obj.values():
            yield from original_entries(v)
    elif isinstance(obj,list):
        for v in obj:
            yield from original_entries(v)

for row in edge_rows:
    edge=row['actual_edge']; a=assessment_by_id['a-'+row['edge']]
    entries=list(original_entries(edge))
    assert len(entries)==row['prior_assessment']['evidence_count']
    linked=list(dict.fromkeys(ref_ids[e['reference_id']] for e in entries))
    a['evidence_ids']+=linked
    a['details']+=' Exact source locators: '+'; '.join(e['reference_id']+' '+e['source_locator'] for e in entries)+'.'
    a['dimensions']=[{'name':'evidence-tier','value':'; '.join(sorted({'inspected primary publication text' if e['reference_id'].startswith('PMID:') else 'issuing native structured assertion' for e in entries})),'definition':'Tier of the exact statements supporting this edge; source annotation, mutant/operon evidence, sequence identity and purified assays are not conflated.','evidence_ids':linked},{'name':'source-object','value':'; '.join(dict.fromkeys(e['reference_id'] for e in entries)),'definition':'Exact native/publication identifiers whose original source hashes are independently bound.','evidence_ids':linked}]
    if edge.get('endpoint_qualifiers'):
        a['dimensions'].append({'name':'taxon-condition-component-role','value':' | '.join(q['endpoint']+': '+q['kind']+': '+q['description'] for q in edge['endpoint_qualifiers']),'definition':'Actual maintained endpoint qualifications retained without broadening strain, construct or condition.','evidence_ids':linked})

prep_ev('ev-imodulon-original','imodulon-inputs/imodulondb-datasets-original.json','database','Complete dated public dataset response from https://imodulondb.org/api/datasets, accessed 2026-10-15T13:11:04.934782Z. Exact response is reused, not freshly fetched. The matching unmodified adapter and failed prior transport observations are retained in adjacent archive members.')
prep_ev('ev-initial-helper-failure','reference-check-initial-helper-failure.json','validation','Historical reviewer helper failure: public BioCyc object URL was incorrectly equated to native XML mirror acquisition URL. Corrected with separate identity checks; no record change. A display-only optional source_version KeyError is also recorded.','context_only')
prep_ev('ev-console-failure','imodulon-inputs/imodulondb-datasets-receipt.json','validation','Historical same-day console runner dependency failure; exact command, exit 1 and stderr retained. Subsequent dated successful response and unchanged adapter replay support applicability.','context_only')
prep_ev('ev-direct-adapter-failure','imodulon-inputs/imodulondb-direct-adapter-receipt.json','validation','Historical same-day direct adapter transport was unavailable due to DNS URLError. No runtime was repaired; later successful public response is distinct.','context_only')
with tarfile.open(W/GATES) as tar:
    gate_bytes={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
gate_labels={'just render-pages':'All 263 pathway pages rendered, 102.14 seconds.','just validate':'Validated 263 records, 20,455 evidence blocks and 493 histories; closed schema, identifiers and label policies, source/docs contracts and page currentness passed, 195.41 seconds.','just test':'5489 passed, 3 skipped, 7 warnings; pytest 969.95 seconds, wrapper 972.82 seconds. Three empty command-frontmatter parametrizations are explained by the unchanged test source and hidden/ignored-inclusive directory walk. Seven warnings are retained dependency deprecations.','just lint':'Ruff reported all checks passed, 0.41 seconds.','git diff --check':'Working-tree whitespace check returned zero with empty log, 0.66 seconds; this does not assert a later staged-index check.'}
checks=[]
for i,r in enumerate(gates['receipts'],1):
    command=' '.join(r['command']);member='full-gates/'+Path(r['log_path']).name;eid=f'ev-gate-{i}'
    add_ev(eid,'validation',GATES,'TAR member '+member,gate_labels[command]+' Root executed this command; independent reviewer read the complete log and verified its digest and receipt.',r['log_sha256'])
    checks.append({'check_id':f'check-gate-{i}','name':command,'status':'passed','required':True,'summary':gate_labels[command]+' Root-run full corpus result, independently bound.','target_ids':[TARGET],'command':command,'exit_code':0,'evidence_ids':[eid,'ev-gate-inputs','ev-terminal-receipts'],'scope_note':'Exact root run against 29,503 hidden/ignored-inclusive declared inputs. All remained unchanged during the run; current rehash differs only in the separately read dated report update. New verification archives and fifth native history were added after the run and are not retroactively called tested by it.'})
add_ev('ev-terminal-receipts','validation',GATES,'TAR member full-gates/receipts.json','All five root commands terminated with exit zero; real start times, elapsed durations and complete log hashes retained.',digest(gate_bytes['full-gates/receipts.json']))
add_ev('ev-gate-inputs','validation',GATES,'TAR members full-gates/tested-core-input-hashes.json and full-gates/final-input-preservation.json','Complete root before/after inventory: 29,503 files, hidden/ignored included, named runtime cache exclusions. Independent current rehash confirms 29,502 remain exact and only the read final report changed. Root run does not validate future additions.',digest(gate_bytes['full-gates/tested-core-input-hashes.json']))
add_ev('ev-root-prerequisite-failure','validation',GATES,'TAR member root/gate-wrapper-prerequisite-race.json','Earlier wrapper failed reading a pending prerequisite before any gate command ran or gate output directory existed. The subsequent single complete run is preserved separately; no failed test was hidden.',digest(gate_bytes['root/gate-wrapper-prerequisite-race.json']),support='context_only')
for name,eid in [('final-gates','ev-final-gate-archive'),('maintained-review-preparation','ev-complete-preparation')]:
    a=next(a for a in archives['archives'] if a['package']==name)
    add_ev(eid,'validation',a['archive_repository_path'],'Complete TAR membership bound by adjacent source-file-manifest.json',f"All {a['member_count']} unique relative regular-file members independently compared to every original byte. Source manifest SHA256 {a['source_manifest_sha256']}.",a['archive_sha256'])
report_path=R+'/README.md'
history_path='history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml'
add_ev('ev-final-report','record_content',report_path,'Verification and publication section; complete report read and explicit old/new diff inspected','Only the final dated verification paragraph changes. It accurately records terminal gates and retained preparation while leaving canonical persistence, publication, staged checks and merge as later observations. Scientific scope and all source limits remain unchanged.',digest((W/report_path).read_bytes()),stage['finished_at'])
add_ev('ev-final-history','record_content',history_path,'Complete native EDIT history','Fifth native history records actual 2026-10-15T17:49:57Z adoption of successful gates and complete preparation retention. It does not claim canonical save, PR publication or merge.',digest((W/history_path).read_bytes()),stage['finished_at'])
record_path=fragment['targets'][0]['path']
add_ev('ev-current-record','record_content',record_path,'Complete maintained YAML; all fields, 76 edges, endpoint qualifiers, 25 references and 117 evidence assertions','Complete actual YAML read during maintained review; current bytes remain exactly e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9. All scientific interpretation and current input hashes bind that same record.',digest((W/record_path).read_bytes()),stage['finished_at'])

def check(cid,name,status,required,summary,eids,command=None,exit_code=None,scope=None):
    d={'check_id':cid,'name':name,'status':status,'required':required,'summary':summary,'target_ids':[TARGET],'evidence_ids':eids}
    if command is not None:d['command']=command
    if exit_code is not None:d['exit_code']=exit_code
    if scope is not None:d['scope_note']=scope
    checks.append(d)

check('check-whole-science','Whole maintained record scientific assessment','passed',True,'Complete actual YAML and all 76 edges assessed. All 56 named identities, 25 exact source originals, 117 evidence locators, four quotations, seven selected steps and six joins retain their source-specific limits. No new actionable scientific defect.', ['ev-current-record','ev-scientific-assessment','ev-edge-matrix','ev-identities','ev-references','ev-locators'])
check('check-independent-replay','Independent exact source and route replay','passed',True,'All selected equations, coefficients, directions, protein/CDS bindings, activity dispositions and construct/composition limits replay successfully; interpretation remains separate from deterministic correspondence.', ['ev-replay','ev-route','ev-locators','ev-retained-sources'])
check('check-final-inspection','Governed final input inspect and explicit changed-input assessment','passed',True,'Fresh native inspect succeeds with 103 inputs. Of 93 prior inputs, 92 are unchanged and the final report is the sole explicitly read change. Ten added inputs include eight archive controls/payloads, fifth native history and the test source used to assess skips.', ['ev-current-record','ev-final-report','ev-final-history','ev-final-gate-archive','ev-complete-preparation'],command=PYTHON+' -B scripts/record_review.py inspect --targets <retained finalization/targets.yaml> --input <102 exact context inputs recorded in inspection receipt>',exit_code=0,scope='Exact actual argv is retained in finalization/inspect-receipt.json; this descriptive command is not offered as a runnable abbreviated reproduction.')
check('check-actual-retention','Complete final archive and scientific owner binding','passed',True,'All 243 new archive members match their originals; all 131 scientific preparation files remain immutable. All 25 source originals freshly recovered from actual maintained storage. Earlier complete retained payload and selected 421-occurrence checks remain explicitly bound.', ['ev-final-gate-archive','ev-complete-preparation','ev-retained-sources','ev-portable-retention'])
check('check-imodulon-offline','Exact shared adapter response reuse','passed',False,'Unmodified same-day adapter replay reproduces complete 20-organism/28-dataset listing; bounded applicability assessed without network or environment change.', ['ev-imodulon','ev-imodulon-original'])
check('check-imodulon-search','Source-taxon dataset search and hit summaries','not_applicable',False,'No matching source-taxon dataset in the complete dated listing. E. coli is the expression host; module membership is not route catalysis evidence.', ['ev-imodulon','ev-imodulon-original'])
check('check-historical-reference-helper','Historical initial reference helper attempt','failed',False,'Preserved failed public-link/mirror-URL equality assumption, corrected in a separate successful helper; no scientific record defect.', ['ev-initial-helper-failure','ev-references'],exit_code=1,scope='Historical non-gating reviewer operation, not an unresolved required check.')
console=load(P/'imodulon-inputs/imodulondb-datasets-receipt.json')
check('check-historical-console','Historical iModulon console attempt','failed',False,'Preserved same-day console dependency failure; later dated successful response and offline adapter replay are separate evidence.', ['ev-console-failure','ev-imodulon'],command=' '.join(console['command']),exit_code=1,scope='Reused root/source acquisition observation from 13:09 UTC; not rerun by this maintained review.')
check('check-historical-adapter','Historical direct iModulon adapter transport','unavailable',False,'Preserved DNS transport URLError from the earlier same-day acquisition; exact response and applicability subsequently obtained without claiming this attempt succeeded.', ['ev-direct-adapter-failure','ev-imodulon'])
check('check-historical-root-wrapper','Historical root wrapper prerequisite race','failed',False,'Wrapper exited before any gate command ran; subsequent unchanged wrapper completed all five gates successfully.', ['ev-root-prerequisite-failure','ev-terminal-receipts'],exit_code=1,scope='Root scheduling failure; no source/test failure and no overwritten result.')

fragment['assessments'].append({'assessment_id':'a-final-bindings','area':'provenance','topic':'Final archives, report, history and terminal gate attribution','outcome':'supported','summary':'Complete preparation and gate evidence are retained through verified maintained owners. All scientific/core/generated inputs remain exact. Only the post-gate report paragraph changes among the 29,503 tested files, and its new dated status is accurate. The fifth native history and two verification archives were read and independently bound; root-run gates are not relabeled as this reviewer’s execution.','target_ids':[TARGET],'evidence_ids':['ev-final-gate-archive','ev-complete-preparation','ev-final-report','ev-final-history','ev-gate-inputs','ev-terminal-receipts'],'details':'Full gate result: 5489 passed, three empty command-frontmatter parametrizations skipped, seven dependency warnings. The full logs and historical pre-gate wrapper failure remain retained. Canonical save/check and later staged/publication gates belong to root and are not claimed here.'})
fragment['source']=inspect['source']
fragment['checks']=checks
fragment['evidence']=evidence
fragment['summary']='The complete maintained CENTBENZCOA-PWY record is scientifically supported within its explicit source, taxon and construct limits. All seven selected steps, six formal joins, 76 edges, 56 named identities, 25 references and 117 evidence assertions were assessed; no actionable blocker, major or minor finding remains in this scope. Exact maintained evidence ownership and all required root-run corpus gates are bound. Putative/predicted lower-route enzymes, generic ferredoxin units, formal Oah constituents and unavailable historical/supplementary sources remain qualified. This completed scientific observation is external prepared content; canonical persistence and publication are separate root-owned steps.'
fragment['completion']='completed'
fragment['verdict']='pass_with_limitations'
fragment['native_verdict']='Whole seven-step pathway supported with explicit primary-source, native-annotation, taxon and construct limits; no actionable scientific findings.'
fragment['limitations'].extend([
    'The completed root production run precedes only the explicitly read final report paragraph, fifth native history and verification archive additions. Current rehash preserves every other tested file. Later native save/check, final documentation/history checks, actual staged-index checks, PR publication and verified merge remain separate root-owned observations.',
    'The three skipped tests are empty command-frontmatter parametrizations, and seven retained dependency deprecation warnings do not represent skipped pathway scientific checks. Historical console/DNS/helper and pre-gate wrapper failures remain recorded separately from later successful checks.',
    'Exploratory overbroad displays of input inventories were truncated and are not counted as full human source readings. Complete binary inventories were parsed and independently verified; complete target YAML, final report, test log, relevant prose and bounded original scientific contexts were read separately.'
])
fragment['notes']='Independent scientific review under the native review-yaml-record skill and CLAW-governed contract. Initial maintained inspect preceded assessment; authority formatting changes and final report additions received explicit successor inspections. Prior preparation and source packages remain immutable. All 76 positive edge assessments cite their exact original source objects, current locators and endpoint qualifications. Empty findings does not close earlier provenance issues or imply fleet-wide scientific approval. No maintained write, Git/GitHub mutation, runtime repair, fresh network query or duplicated full gate was performed by this reviewer.'
fragment['tags']=['scientific-review','whole-route','next266','source-scope','independent']
finish=datetime.now(timezone.utc)
fragment['finished_at']=finish.isoformat().replace('+00:00','Z')
fragment['review_id']=finish.strftime('%Y%m%dT%H%M%SZ')+'-centbenzcoa-pwy-scientific'
assert len(fragment['assessments'])==94
assert len(ref_ids)==25
assert len([a for a in fragment['assessments'] if a['assessment_id'].startswith('a-e')])==76
class NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self,data):
        return True
out=F/'completed-review.yaml'
assert not out.exists()
out.write_text(yaml.dump(fragment,Dumper=NoAliasDumper,allow_unicode=True,sort_keys=False,width=100))
env=os.environ.copy();env.update({'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
commands=[]
for action in ('validate','render'):
    argv=[PYTHON,'-B','scripts/record_review.py',action]+([str(out)] if action=='validate' else ['--content',str(out)])
    began=now();result=subprocess.run(argv,cwd=W,env=env,capture_output=True)
    (F/(action+'.stdout'+('.json' if action=='validate' else '.md'))).write_bytes(result.stdout)
    (F/(action+'.stderr.txt')).write_bytes(result.stderr)
    receipt={'started_at':began,'finished_at':now(),'argv':argv,'cwd':str(W),'exit_code':result.returncode,'stdout_sha256':digest(result.stdout),'stderr_sha256':digest(result.stderr),'review_sha256':digest(out.read_bytes())}
    save(action+'-receipt.json',receipt)
    commands.append(receipt)
    assert result.returncode==0,result.stderr.decode()
for row in inspect['source']['inputs']:
    assert digest((W/row['path']).read_bytes())==row['sha256'],row['path']
save('completed-review-preparation.json',{'finished_at':now(),'status':'validated external completed review; native save/check remain root-owned','review_id':fragment['review_id'],'review_path':str(out),'review_sha256':digest(out.read_bytes()),'preview_path':str(F/'render.stdout.md'),'preview_sha256':digest((F/'render.stdout.md').read_bytes()),'verdict':fragment['verdict'],'assessments':len(fragment['assessments']),'evidence':len(evidence),'checks':len(checks),'findings':0,'source_inputs':len(inspect['source']['inputs']),'all_inputs_rechecked_after_validation':True,'canonical_saved':False,'commands':commands})
print(json.dumps({'status':'validated external complete scientific review','review_id':fragment['review_id'],'sha256':digest(out.read_bytes()),'verdict':fragment['verdict'],'assessments':len(fragment['assessments']),'checks':len(checks),'evidence':len(evidence),'findings':0,'canonical_saved':False}))
