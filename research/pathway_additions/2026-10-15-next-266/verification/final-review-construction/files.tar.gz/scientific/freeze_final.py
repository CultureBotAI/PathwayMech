"""Freeze external review construction and its complete independent proof layout."""
from datetime import datetime,timezone
from hashlib import sha256
from pathlib import Path
import copy
import json
import yaml

ROOT=Path(__file__).resolve().parent
F=ROOT/'finalization'
W=Path('/private/tmp/pathwaymech-next-266-20261015')
P=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
def h(b):return sha256(b).hexdigest()
def now():return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def load(p):return json.loads(p.read_text())
def write(p,o):
    assert not p.exists(),p
    p.write_text(json.dumps(o,indent=2,ensure_ascii=False)+'\n')
assert not (ROOT/'artifact-manifest.json').exists()
review_path=F/'completed-review.final.yaml'
review=yaml.safe_load(review_path.read_text())
previous=yaml.safe_load((F/'completed-review.yaml').read_text())
old=copy.deepcopy(previous);new=copy.deepcopy(review)
for d in (old,new):
    for k in ('notes','review_id','finished_at'):d.pop(k)
    check=next(c for c in d['checks'] if c['check_id']=='check-final-inspection')
    for k in ('command','scope_note'):check.pop(k)
assert old==new
assert review['completion']=='completed' and review['verdict']=='pass_with_limitations'
assert review['findings']==[] and len(review['assessments'])==94
for name in ('validate-final-receipt.json','render-final-receipt.json'):
    receipt=load(F/name);assert receipt['exit_code']==0 and receipt['review_sha256']==h(review_path.read_bytes())
for row in review['source']['inputs']:
    assert h((W/row['path']).read_bytes())==row['sha256'],row['path']
old_inventory=load(ROOT/'draft/prior-preparation-inventory.json')['files']
assert {p.relative_to(P).as_posix() for p in P.rglob('*') if p.is_file()}=={r['path'] for r in old_inventory}
for row in old_inventory:
    b=(P/row['path']).read_bytes();assert h(b)==row['sha256'] and len(b)==row['bytes']
packages=[]
for package in ('final-gates','maintained-review-preparation'):
    base=W/'research/pathway_additions/2026-10-15-next-266/verification'/package
    m=load(base/'artifact-manifest.json')
    assert {p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}=={'artifact-manifest.json'}|{r['path'] for r in m['files']}
    for r in m['files']:
        b=(base/r['path']).read_bytes();assert h(b)==r['sha256'] and len(b)==r['bytes']
    packages.append({'package':package,'physical_files':4,'manifest_sha256':h((base/'artifact-manifest.json').read_bytes()),'all_declared_bytes_exact':True})
write(F/'final-integrity.json',{'checked_at':now(),'status':'pass','review_sha256':h(review_path.read_bytes()),'final_review_format_successor_only':True,'previous_preparation_files_preserved':len(old_inventory),'exact_current_source_inputs':len(review['source']['inputs']),'new_archive_physical_packages':packages,'all_independent_archive_member_checks':'final-archive-independent-verification.json','all_25_original_source_owner_checks':'final-reference-owner-bindings.json','canonical_saved':False,'no_further_same_directory_mutation_after_freeze':True})
handoff=f'''# Final independent scientific review — ready for root native save

The external completed review gives **pass_with_limitations** for the whole maintained `MetaCyc:CENTBENZCOA-PWY` record, with **0 blocker, 0 major and 0 minor findings**. This is scientific acceptance of the exact record within its explicit evidence limits. It does not claim canonical persistence, PR publication, staged-index acceptance, merge or GitHub issue closure.

Use **`finalization/completed-review.final.yaml`** as the sole native save input. Its SHA256 is `{h(review_path.read_bytes())}` and its review ID is `{review['review_id']}`. The native helper's external `validate` and `render` both returned zero. `finalization/render.final.stdout.md` is the helper-generated preview, not a separately authored verdict. Root remains the sole maintained saver; follow native save with the governed check and the separately planned final report/history/publication checks.

The completed content has **94 assessments, including all 76 individual edges**, **57 evidence entries**, **15 actual or explicitly historical checks**, and **103 exact source inputs**. All seven selected steps, 32 material occurrences over 19 frames, six formal joins, auxiliary Oah composite, 56 named identities, 25 references and 117 evidence assertions remain in scope. The actual record SHA256 is `e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9`. The native inspect binds working-tree inputs at base `dd780ef273323efd638eacd63625963062e0b105`.

The original independent whole-design scientific assessment is explicitly reused through strict full-edge/design equality, together with full current YAML reading and fresh bounded source, identity, locator, coefficient and construct checks. Exact original storage owners and claim-specific locators are preserved. The review does not relabel deterministic serialization, source hashes or schema success as biological evidence, and it does not claim another complete human reading of every historical original paper or source archive.

The final stage independently compared all **243 members** of the actual maintained final-gate and review-preparation archives with their originals, including all **131 immutable scientific preparation files** and 92 technical files. It rehashed all **29,503 tested files**: the only current change is the explicitly read final report paragraph, SHA256 `cb8ad4faf2e342c3b3947a156d6dfeb8e51b310b15efe23e11a50d5657784980`. The fifth native history, SHA256 `c481e4bc95284a17d0059f90d1a6648a32c3b6ac1a9b3144b92e02c456d18f7d`, and eight archive-package files are distinct post-gate additions. All 25 reference originals were freshly recovered through exact maintained storage and gzip-chain mappings. No large original body was copied again.

Root's complete run is accurately attributed: render, validate, test, lint and working-tree whitespace all passed. Pytest reports **5,489 passed, 3 skipped and 7 warnings**. The skips are the three empty command-frontmatter parametrizations; the unchanged test source and a complete hidden/ignored-inclusive `.claude` walk support that explanation. Dependency warnings and the earlier pre-gate wrapper scheduling failure remain preserved. No full gate was duplicated by this reviewer. The prior retained scientific/source/ownership checks remain bound through actual maintained archive members.

The qualifications remain material: coefficient two denotes generic ferredoxin one-electron cluster units, not whole two-cluster proteins or intrinsic BCR centers; retired Rhea 19100 is not automatically replaced; native directions and formal traversal differ; formal Oah constituents do not prove a free CPD-15900 intermediate or separately assayed catalysts; step 6 is putative without a catalyst; the real PimB native chain has predicted/operon scope, without an individual catalytic edge. Tags, strains, expression hosts, preparation-specific cofactors and historical annotation conflicts remain explicit. Historical full-text and supplement gaps remain disclosed. The dated iModulon response is reused through the exact unchanged adapter; no matching source-taxon dataset is not negative biology.

The initial external canonical shape attempt failed because `notes` was a string instead of the required list. The exact invalid predecessor, native failure receipt and stderr remain in `finalization/`. An explicit successor corrects that shape, substitutes the exact recorded inspect argv for an abbreviated display, and has a new actual finish timestamp/ID. Independent strict comparison proves that no scientific content changed. Final validate/render emit only the preserved LinkML `topClass` deprecation warning. Exploratory truncated inventory displays are not counted as full reading.

This complete external directory is frozen by `artifact-manifest.json` plus `freeze.json`; no subsequent same-directory mutations are authorized. All earlier frozen packages and the complete previous preparation remain immutable. Live worktree read dependencies are released. Preserve the exact source-owner and archive mappings during subsequent cleanup. Root may retain this complete final construction layout before the sole maintained save; adding that later archive does not alter the 103 reviewed inputs.
'''
(ROOT/'HANDOFF.md').write_text(handoff)
rows=[]
for p in sorted(ROOT.rglob('*')):
    assert not p.is_symlink(),p
    if p.is_file():
        b=p.read_bytes();rows.append({'path':p.relative_to(ROOT).as_posix(),'sha256':h(b),'bytes':len(b)})
write(ROOT/'artifact-manifest.json',{'files':rows,'scope':'Complete external final scientific review construction including draft, exact failed predecessor, explicit shape successor, independent proofs and native validated/rendered final content. No source body duplication.','count':len(rows)})
write(ROOT/'freeze.json',{'frozen_at':now(),'manifest_sha256':h((ROOT/'artifact-manifest.json').read_bytes()),'handoff_sha256':h((ROOT/'HANDOFF.md').read_bytes()),'review_sha256':h(review_path.read_bytes()),'listed_files':len(rows),'physical_files_including_manifest_and_freeze':len(rows)+2,'immutable':True,'canonical_saved':False})
print(json.dumps(load(ROOT/'freeze.json')))
