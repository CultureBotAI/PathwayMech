# Scientific review of benzoyl-CoA degradation II (anaerobic)

- Review: 20261015T175945Z-centbenzcoa-pwy-scientific
- Repository: CultureBotAI/PathwayMech
- Started UTC: 2026-10-15T16:40:08Z
- Finished UTC: 2026-10-15T17:59:45.408686Z
- Reviewer: Codex /root/next266_design_acceptance (independent)
- Completion: completed
- Verdict: pass_with_limitations
- Scientific review: true

## Summary

The complete maintained CENTBENZCOA-PWY record is scientifically supported within its explicit source, taxon and construct limits. All seven selected steps, six formal joins, 76 edges, 56 named identities, 25 references and 117 evidence assertions were assessed; no actionable blocker, major or minor finding remains in this scope. Exact maintained evidence ownership and all required root-run corpus gates are bound. Putative/predicted lower-route enzymes, generic ferredoxin units, formal Oah constituents and unavailable historical/supplementary sources remain qualified. This completed scientific observation is external prepared content; canonical persistence and publication are separate root-owned steps.

## Scope And Provenance

Whole maintained CENTBENZCOA-PWY YAML: all 76 edges, 56 named identities, 25 references, 117 evidence assertions, all seven selected steps and six formal joins, exact source/construct/taxon limits and retained ownership.

Selection: Exactly data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml, MetaCyc:CENTBENZCOA-PWY.
Coverage: full; 1 reviewed / 1 in the declared population.
Source: working_tree at Git base dd780ef273323efd638eacd63625963062e0b105.
Working-tree hashes do not imply those bytes were committed.

| Target | Path / selector | Kind | Label |
| --- | --- | --- | --- |
| MetaCyc:CENTBENZCOA-PWY | data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml | maintained | benzoyl-CoA degradation II (anaerobic) |

## Validation

| Check | Status | Required | Targets | Result |
| --- | --- | --- | --- | --- |
| just render-pages | passed | True | MetaCyc:CENTBENZCOA-PWY | All 263 pathway pages rendered, 102.14 seconds. Root-run full corpus result, independently bound. |
| just validate | passed | True | MetaCyc:CENTBENZCOA-PWY | Validated 263 records, 20,455 evidence blocks and 493 histories; closed schema, identifiers and label policies, source/docs contracts and page currentness passed, 195.41 seconds. Root-run full corpus result, independently bound. |
| just test | passed | True | MetaCyc:CENTBENZCOA-PWY | 5489 passed, 3 skipped, 7 warnings; pytest 969.95 seconds, wrapper 972.82 seconds. Three empty command-frontmatter parametrizations are explained by the unchanged test source and hidden/ignored-inclusive directory walk. Seven warnings are retained dependency deprecations. Root-run full corpus result, independently bound. |
| just lint | passed | True | MetaCyc:CENTBENZCOA-PWY | Ruff reported all checks passed, 0.41 seconds. Root-run full corpus result, independently bound. |
| git diff --check | passed | True | MetaCyc:CENTBENZCOA-PWY | Working-tree whitespace check returned zero with empty log, 0.66 seconds; this does not assert a later staged-index check. Root-run full corpus result, independently bound. |
| Whole maintained record scientific assessment | passed | True | MetaCyc:CENTBENZCOA-PWY | Complete actual YAML and all 76 edges assessed. All 56 named identities, 25 exact source originals, 117 evidence locators, four quotations, seven selected steps and six joins retain their source-specific limits. No new actionable scientific defect. |
| Independent exact source and route replay | passed | True | MetaCyc:CENTBENZCOA-PWY | All selected equations, coefficients, directions, protein/CDS bindings, activity dispositions and construct/composition limits replay successfully; interpretation remains separate from deterministic correspondence. |
| Governed final input inspect and explicit changed-input assessment | passed | True | MetaCyc:CENTBENZCOA-PWY | Fresh native inspect succeeds with 103 inputs. Of 93 prior inputs, 92 are unchanged and the final report is the sole explicitly read change. Ten added inputs include eight archive controls/payloads, fifth native history and the test source used to assess skips. |
| Complete final archive and scientific owner binding | passed | True | MetaCyc:CENTBENZCOA-PWY | All 243 new archive members match their originals; all 131 scientific preparation files remain immutable. All 25 source originals freshly recovered from actual maintained storage. Earlier complete retained payload and selected 421-occurrence checks remain explicitly bound. |
| Exact shared adapter response reuse | passed | False | MetaCyc:CENTBENZCOA-PWY | Unmodified same-day adapter replay reproduces complete 20-organism/28-dataset listing; bounded applicability assessed without network or environment change. |
| Source-taxon dataset search and hit summaries | not_applicable | False | MetaCyc:CENTBENZCOA-PWY | No matching source-taxon dataset in the complete dated listing. E. coli is the expression host; module membership is not route catalysis evidence. |
| Historical initial reference helper attempt | failed | False | MetaCyc:CENTBENZCOA-PWY | Preserved failed public-link/mirror-URL equality assumption, corrected in a separate successful helper; no scientific record defect. |
| Historical iModulon console attempt | failed | False | MetaCyc:CENTBENZCOA-PWY | Preserved same-day console dependency failure; later dated successful response and offline adapter replay are separate evidence. |
| Historical direct iModulon adapter transport | unavailable | False | MetaCyc:CENTBENZCOA-PWY | Preserved DNS transport URLError from the earlier same-day acquisition; exact response and applicability subsequently obtained without claiming this attempt succeeded. |
| Historical root wrapper prerequisite race | failed | False | MetaCyc:CENTBENZCOA-PWY | Wrapper exited before any gate command ran; subsequent unchanged wrapper completed all five gates successfully. |

## Scientific And Domain Assessments

### Exact CENTBENZCOA-PWY identity and finite duplicate context

identity: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The maintained YAML denotes the complete source-defined benzoyl-CoA degradation II (anaerobic) route. It is distinct from the nine-step P321 route and the accepted aerobic PWY-1361 record. Prior independent merged-baseline/source-follow acceptance is reused within its finite captured scope; no global absence claim is made.

### Complete selected route and formal joins

completeness: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

All seven selected reactions, 32 material occurrences over 19 frames and six shared-material joins are retained. The Oah net composite is an auxiliary eighth declared reaction, not an eighth selected step. No route subset is substituted.

### Generic ferredoxin cluster-unit stoichiometry

quantity: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

BCR uses coefficient two for generic native one-electron ferredoxin cluster units. Whole two-cluster polypeptides and intrinsic BCR iron-sulfur centers remain distinct. The retired Rhea 19100 chain is not an automatic replacement.

The small-molecule charge residual of minus two is compensated by two native one-electron cluster oxidations. Generic drawings do not identify a universal donor sequence or occupancy.

### Native directions and pathway traversal

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Every reaction retains its native direction independently of selected material traversal. The six provides_input_for edges express formal source ordering and a shared coefficient-one material; they do not assert physical channeling, a protein complex or measured complete-route flux.

### Oah composite and CPD-15900

scope: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The two formal Oah constituent equations sum exactly to the declared hydrolysis composite and cancel CPD-15900. They do not establish separately assayed constituent catalysts or a freely released or accumulating CPD-15900 intermediate.

### Putative step 6 and predicted operon-scoped PimB

scope: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Step 6 remains YES-PUTATIVE with exact formal materials and no assigned catalyst. Step 7 has a real native RXN-8032 → ENZRXN-26773 → MONOMER-20679/G-58826 → Q6N3H9 chain, explicitly predicted and lacking individual biochemical characterization. Operon/mutant context does not justify a single-protein enables or catalyzes edge.

Neither missing-backlink reasoning nor a fabricated lower-route Thauera enzyme is used. C4 assays, BadH/Hcd annotations, proteomics and apo structures do not establish the exact Thauera C7 catalyst. The native reaction name is not an individual PimB assay.

### Issuing identities, reference originals and coefficients

grounding: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

All 56 named identities and 25 reference originals have exact issuing identity checks. All 117 locators and four short quotations are valid; 19 chemical identities and 17 complete native/ChEBI structure pairs preserve source stereochemistry and charge. Stable identifiers do not substitute for functional evidence.

### Protein/CDS and assembly component scope

scope: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

All 21 native protein/CDS crosswalks and all 15 activity dispositions were examined, including excluded examples. The 13 assembly component edges preserve sequence identity and multiplicity without assigning isolated-subunit catalysis. The BcrA CDS bcrB qualifier conflict remains an explicit annotation conflict.

### BamR, BamA and BamQ construct-specific evidence

scope: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

BamR C-terminal His6 and BamA N-terminal His6 preparation qualifiers remain on assembly and component endpoints. Apparent oligomerization is not generalized to universal native assemblies. BamQ is the exact SYN_RS14210/WP_011418919.1 CDS with substrate-specific recombinant P13 assay support; P44 supports E. coli BL21/pET101, while unseen insert/tag details remain unknown.

### Had zinc and activity-specific cofactors

evidence: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The modern Had AAS result supports two zinc atoms per monomer for a C-terminal Strep-tagged wild-type, zinc-supplemented preparation. It does not establish historical native occupancy, mutant crystal identity or a physiological CoA-substrate assay. The separate native zinc statement remains uncited structured evidence; magnesium and intrinsic CPD-7 associations retain activity-specific scope.

### Taxa, historical strains and expression hosts

scope: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

All four taxon identities are exact. Source-defined route membership is not experimental closure of every step in each taxon. Syntrophus upper-route examples do not establish ATP-dependent BCR there. R. palustris BadDEFG genetic/sequence evidence remains enables. Deposited CGA009 proteins, original CGA604 cloning, Thauera K172, Azoarcus KB740 and recombinant E. coli remain separate.

### Structured assertions, primary evidence and bounded original access

evidence: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native XML statements are represented as source assertions at exact object locators, not quotations from papers cited by the database. Primary construct and assay claims remain tied to inspected original paragraphs. Public BioCyc links and retained native XML hashes serve explicitly different roles.

Unacquired original historical papers, erratum and supplementary files remain limitations; abstracts and bibliography leads are not promoted to read full text.

### Structured-source adapter applicability

evidence: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The dated complete iModulonDB listing has no source-taxon dataset for Thauera, Syntrophus or Rhodopseudomonas. E. coli coverage concerns the expression host and cannot establish foreign-route catalysis. Per-dataset source-pathway search and component summaries are not applicable to these observed taxa.

Same-day 2026-10-15T13:11:04.934782Z response reuse and offline exact adapter replay are explicit. Original console dependency and transport failures are preserved. Absence from this finite dataset list is not negative biology or a fresh live query.

### Specialized typed authority profiles and serialization successor

representation: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The unnamed heteromer, typed Protein coefficient reaction, generic ferredoxin classes, Oah composite and named RXN-8032 shapes retain specific bounded owners. Separate independent authority implementation/projection acceptance is attributed. Three registry formatting successors preserve full JSON meaning and baseline entries; earlier inspected hashes remain in history.

### Actual maintained scientific evidence and portable ownership

provenance: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The current retained payload preserves the complete assessed design and selected scientific originals, every actual reference original, the prior independent judgments and original operational failures. The independent reviewer decoded 421 selected occurrences/353 distinct contents and verified all 3343 payload files; broader complete logical and Git provenance checks retain separate reviewer/root attribution.

### Historical report and native stage accounting

ownership: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The inspected report, ownership READMEs and four native histories distinguish creation, later retention adoption and the then-pending canonical/production boundary. Issues 590 and 591 retain their original findings and separate accepted corrections; this review does not publish or close GitHub issues.

### Generated page and KGX preservation evidence

representation: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Separately bound root checks cover the whole record in generated page/KGX output and old-edge preservation. Browser retry, initial sandbox startup failure and root visual inspection retain their actual attribution. This scientific reviewer does not claim another browser execution or screenshot inspection.

### e001: MetaCyc:1.3.99.15-RXN produces CHEBI:57374

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[0]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e002: MetaCyc:1.3.99.15-RXN produces MetaCyc:Oxidized-ferredoxins

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. Native Protein-class cluster-unit names and comments support coefficient two; no whole-polypeptide or Rhea replacement equivalence is asserted.

Actual field mechanistic_edges[1]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e003: MetaCyc:1.3.99.15-RXN produces CHEBI:456216

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[2]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[3]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e004: MetaCyc:1.3.99.15-RXN produces CHEBI:43474

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[3]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/left[4]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e005: CHEBI:57369 consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[4]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e006: MetaCyc:Reduced-ferredoxins consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. Native Protein-class cluster-unit names and comments support coefficient two; no whole-polypeptide or Rhea replacement equivalence is asserted.

Actual field mechanistic_edges[5]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e007: CHEBI:30616 consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[6]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[3]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e008: CHEBI:15377 consumes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[7]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid='1.3.99.15-RXN']/right[4]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.3.99.15-RXN']/direction.

### e009: MetaCyc:1.3.99.15-RXN part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[8]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='1.3.99.15-RXN'].

### e010: MetaCyc:4.2.1.100-RXN produces CHEBI:57361

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[9]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:4.2.1.100-RXN /ptools-xml/Reaction[@frameid='4.2.1.100-RXN']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='4.2.1.100-RXN']/direction.

### e011: CHEBI:57374 consumes MetaCyc:4.2.1.100-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[10]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:4.2.1.100-RXN /ptools-xml/Reaction[@frameid='4.2.1.100-RXN']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='4.2.1.100-RXN']/direction.

### e012: CHEBI:15377 consumes MetaCyc:4.2.1.100-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[11]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:4.2.1.100-RXN /ptools-xml/Reaction[@frameid='4.2.1.100-RXN']/right[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='4.2.1.100-RXN']/direction.

### e013: MetaCyc:4.2.1.100-RXN part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[12]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='4.2.1.100-RXN'].

### e014: CHEBI:57361 consumes MetaCyc:HADTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[13]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid='HADTHAUERA-RXN']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='HADTHAUERA-RXN']/direction.

### e015: CHEBI:57540 consumes MetaCyc:HADTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[14]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid='HADTHAUERA-RXN']/left[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='HADTHAUERA-RXN']/direction.

### e016: MetaCyc:HADTHAUERA-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[15]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid='HADTHAUERA-RXN']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='HADTHAUERA-RXN']/direction.

### e017: MetaCyc:HADTHAUERA-RXN produces CHEBI:76526

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[16]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid='HADTHAUERA-RXN']/right[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='HADTHAUERA-RXN']/direction.

### e018: MetaCyc:HADTHAUERA-RXN produces CHEBI:57945

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[17]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid='HADTHAUERA-RXN']/right[3]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='HADTHAUERA-RXN']/direction.

### e019: MetaCyc:HADTHAUERA-RXN part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[18]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='HADTHAUERA-RXN'].

### e020: CHEBI:76526 consumes MetaCyc:RXN-15012

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[19]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15012 /ptools-xml/Reaction[@frameid='RXN-15012']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15012']/direction.

### e021: CHEBI:15377 consumes MetaCyc:RXN-15012

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[20]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15012 /ptools-xml/Reaction[@frameid='RXN-15012']/left[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15012']/direction.

### e022: MetaCyc:RXN-15012 produces CHEBI:76527

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[21]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15012 /ptools-xml/Reaction[@frameid='RXN-15012']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15012']/direction.

### e023: MetaCyc:RXN-15012 part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[22]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='RXN-15012'].

### e024: CHEBI:76527 consumes MetaCyc:RXN-15013

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[23]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid='RXN-15013']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15013']/direction.

### e025: CHEBI:15377 consumes MetaCyc:RXN-15013

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[24]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid='RXN-15013']/left[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15013']/direction.

### e026: MetaCyc:RXN-15013 produces CHEBI:57343

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[25]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid='RXN-15013']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15013']/direction.

### e027: MetaCyc:RXN-15013 produces CHEBI:15378

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently.

Actual field mechanistic_edges[26]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid='RXN-15013']/right[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-15013']/direction.

### e028: MetaCyc:RXN-15013 part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[27]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='RXN-15013'].

### e029: CHEBI:57343 consumes MetaCyc:1.1.1.259-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. YES-PUTATIVE and absent native enzyme backlink remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.

Actual field mechanistic_edges[28]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']/direction.

### e030: CHEBI:57540 consumes MetaCyc:1.1.1.259-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. YES-PUTATIVE and absent native enzyme backlink remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.

Actual field mechanistic_edges[29]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/left[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']/direction.

### e031: MetaCyc:1.1.1.259-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. YES-PUTATIVE and absent native enzyme backlink remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.

Actual field mechanistic_edges[30]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']/direction.

### e032: MetaCyc:1.1.1.259-RXN produces CHEBI:57945

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. YES-PUTATIVE and absent native enzyme backlink remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.

Actual field mechanistic_edges[31]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']/direction.

### e033: MetaCyc:1.1.1.259-RXN produces CHEBI:57350

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. YES-PUTATIVE and absent native enzyme backlink remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.

Actual field mechanistic_edges[32]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid='1.1.1.259-RXN']/right[3]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='1.1.1.259-RXN']/direction.

### e034: MetaCyc:1.1.1.259-RXN part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[33]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='1.1.1.259-RXN'].

### e035: CHEBI:57350 consumes MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. Real PimB native assignment exists but is excluded from causal catalysis/enables because current evidence is predicted function and operon scope.

Actual field mechanistic_edges[34]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/left[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']/direction.

### e036: CHEBI:57287 consumes MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. Real PimB native assignment exists but is excluded from causal catalysis/enables because current evidence is predicted function and operon scope.

Actual field mechanistic_edges[35]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/left[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']/direction.

### e037: MetaCyc:RXN-8032 produces CHEBI:57378

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. Real PimB native assignment exists but is excluded from causal catalysis/enables because current evidence is predicted function and operon scope.

Actual field mechanistic_edges[36]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/right[1]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']/direction.

### e038: MetaCyc:RXN-8032 produces CHEBI:57288

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native material slot, coefficient, exact identity crosswalk and pathway layout support the selected input/output orientation. Native reaction direction is retained independently. Real PimB native assignment exists but is excluded from causal catalysis/enables because current evidence is predicted function and operon scope.

Actual field mechanistic_edges[37]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid='RXN-8032']/right[2]; MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-layout[Reaction/@frameid='RXN-8032']/direction.

### e039: MetaCyc:RXN-8032 part_of MetaCyc:CENTBENZCOA-PWY

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit native membership supports selected-route inclusion, not experimental closure in every listed taxon.

Actual field mechanistic_edges[38]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-list/Reaction[@frameid='RXN-8032'].

### e040: MetaCyc:1.3.99.15-RXN provides_input_for MetaCyc:4.2.1.100-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native predecessor ordering and the same coefficient-one intermediate on adjacent traversed equations support a formal material join. Neither physical channeling nor measured complete-route flux is asserted.

Actual field mechanistic_edges[39]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-ordering[Reaction/@frameid='4.2.1.100-RXN']/predecessor-reactions/Reaction[@frameid='1.3.99.15-RXN'].

### e041: MetaCyc:4.2.1.100-RXN provides_input_for MetaCyc:HADTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native predecessor ordering and the same coefficient-one intermediate on adjacent traversed equations support a formal material join. Neither physical channeling nor measured complete-route flux is asserted.

Actual field mechanistic_edges[40]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-ordering[Reaction/@frameid='HADTHAUERA-RXN']/predecessor-reactions/Reaction[@frameid='4.2.1.100-RXN'].

### e042: MetaCyc:HADTHAUERA-RXN provides_input_for MetaCyc:RXN-15012

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native predecessor ordering and the same coefficient-one intermediate on adjacent traversed equations support a formal material join. Neither physical channeling nor measured complete-route flux is asserted.

Actual field mechanistic_edges[41]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-ordering[Reaction/@frameid='RXN-15012']/predecessor-reactions/Reaction[@frameid='HADTHAUERA-RXN'].

### e043: MetaCyc:RXN-15012 provides_input_for MetaCyc:RXN-15013

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native predecessor ordering and the same coefficient-one intermediate on adjacent traversed equations support a formal material join. Neither physical channeling nor measured complete-route flux is asserted.

Actual field mechanistic_edges[42]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-ordering[Reaction/@frameid='RXN-15013']/predecessor-reactions/Reaction[@frameid='RXN-15012'].

### e044: MetaCyc:RXN-15013 provides_input_for MetaCyc:1.1.1.259-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native predecessor ordering and the same coefficient-one intermediate on adjacent traversed equations support a formal material join. Neither physical channeling nor measured complete-route flux is asserted.

Actual field mechanistic_edges[43]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-ordering[Reaction/@frameid='1.1.1.259-RXN']/predecessor-reactions/Reaction[@frameid='RXN-15013'].

### e045: MetaCyc:1.1.1.259-RXN provides_input_for MetaCyc:RXN-8032

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native predecessor ordering and the same coefficient-one intermediate on adjacent traversed equations support a formal material join. Neither physical channeling nor measured complete-route flux is asserted.

Actual field mechanistic_edges[44]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid='CENTBENZCOA-PWY']/reaction-ordering[Reaction/@frameid='RXN-8032']/predecessor-reactions/Reaction[@frameid='1.1.1.259-RXN'].

### e046: CHEBI:76526 consumes MetaCyc:OAHTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native net Oah equation supports this material and coefficient in forward hydrolysis. Formal constituents and lack of free-intermediate evidence are kept separate.

Actual field mechanistic_edges[45]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid='OAHTHAUERA-RXN']/left[1].

### e047: CHEBI:15377 consumes MetaCyc:OAHTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native net Oah equation supports this material and coefficient in forward hydrolysis. Formal constituents and lack of free-intermediate evidence are kept separate.

Actual field mechanistic_edges[46]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid='OAHTHAUERA-RXN']/left[2].

### e048: MetaCyc:OAHTHAUERA-RXN produces CHEBI:15378

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native net Oah equation supports this material and coefficient in forward hydrolysis. Formal constituents and lack of free-intermediate evidence are kept separate.

Actual field mechanistic_edges[47]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid='OAHTHAUERA-RXN']/right[1].

### e049: MetaCyc:OAHTHAUERA-RXN produces CHEBI:57343

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete native net Oah equation supports this material and coefficient in forward hydrolysis. Formal constituents and lack of free-intermediate evidence are kept separate.

Actual field mechanistic_edges[48]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid='OAHTHAUERA-RXN']/right[2].

### e050: MetaCyc:RXN-15012 part_of MetaCyc:OAHTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit composite member and exact signed cancellation support formal constituent membership; the composite itself is not selected as an eighth pathway step.

Actual field mechanistic_edges[49]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid='OAHTHAUERA-RXN']/reaction-list/Reaction[@frameid='RXN-15012'].

### e051: MetaCyc:RXN-15013 part_of MetaCyc:OAHTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicit composite member and exact signed cancellation support formal constituent membership; the composite itself is not selected as an eighth pathway step.

Actual field mechanistic_edges[50]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid='OAHTHAUERA-RXN']/reaction-list/Reaction[@frameid='RXN-15013'].

### e052: MetaCyc:CPLX-1341 catalyzes MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Purified-protein native evidence joins the four-subunit Thauera BCR to ATP-dependent reductive dearomatization. Neither subunits nor natural donor are individually assigned this catalysis.

Actual field mechanistic_edges[51]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/*[self::enzyme or self::reaction or self::evidence].

### e053: MetaCyc:CPLX-1341 has_part UniProtKB:O87876

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[52]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid='CPLX-1341']/component[1].

### e054: MetaCyc:CPLX-1341 has_part UniProtKB:O87875

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[53]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid='CPLX-1341']/component[2].

### e055: MetaCyc:CPLX-1341 has_part UniProtKB:O87874

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[54]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid='CPLX-1341']/component[3].

### e056: MetaCyc:CPLX-1341 has_part UniProtKB:O87877

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[55]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid='CPLX-1341']/component[4].

### e057: MetaCyc:CPLX-1342 catalyzes MetaCyc:4.2.1.100-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native Dch activity and homodimer context support hydration. EV-EXP is retained rather than relabeled as a freshly read purified-protein experiment; missing full erratum remains a source limit.

Actual field mechanistic_edges[56]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1822 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1822']/*[self::enzyme or self::reaction or self::evidence].

### e058: MetaCyc:CPLX-1342 has_part UniProtKB:O87873

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[57]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1342 /ptools-xml/Protein[@frameid='CPLX-1342']/component[1].

### e059: MetaCyc:CPLX-1343 catalyzes MetaCyc:HADTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The native activity independently includes native-host purified-protein evidence, so the native complex edge does not require treating its second, recombinant preparation as unmodified native enzyme. Modern construct evidence remains separate.

Actual field mechanistic_edges[58]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1823 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1823']/*[self::enzyme or self::reaction or self::evidence].

### e060: MetaCyc:CPLX-1343 has_part UniProtKB:O87871

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[59]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1343 /ptools-xml/Protein[@frameid='CPLX-1343']/component[1].

### e061: MetaCyc:CPLX-1361 catalyzes MetaCyc:OAHTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Native-host purified Oah evidence supports the net hydrolysis only. REVERSIBLE is source metadata, not observed reverse ring formation; no constituent catalyst is asserted.

Actual field mechanistic_edges[60]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1841 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1841']/*[self::enzyme or self::reaction or self::evidence].

### e062: MetaCyc:CPLX-1361 has_part UniProtKB:O87872

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[61]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-1361 /ptools-xml/Protein[@frameid='CPLX-1361']/component[1].

### e063: MetaCyc:CPLX-8779 catalyzes MetaCyc:4.2.1.100-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Recombinant BamR catalytic evidence is explicitly C-terminal His6/E. coli qualified on the complex subject. The native component count does not claim a universally native tetramer.

Actual field mechanistic_edges[62]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-22282 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-22282']/*[self::enzyme or self::reaction or self::evidence]; MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid='CPLX-8779']/comment.

### e064: MetaCyc:CPLX-8779 has_part UniProtKB:Q2LXU6

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution. Both assembly and component endpoints retain the recombinant construct qualification.

Actual field mechanistic_edges[63]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 3 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid='CPLX-8779']/component[1]; MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid='CPLX-8779']/comment; MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid='CPLX-8779']/comment.

### e065: MetaCyc:CPLX-8780 catalyzes MetaCyc:OAHTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Recombinant BamA net-hydrolysis evidence is N-terminal His6/E. coli qualified. Apparent homohexamer is an experimental assembly inference; no CPD-15900 accumulation follows.

Actual field mechanistic_edges[64]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-22284 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-22284']/*[self::enzyme or self::reaction or self::evidence]; MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid='CPLX-8780']/comment.

### e066: MetaCyc:CPLX-8780 has_part UniProtKB:Q2LXU2

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution. Both assembly and component endpoints retain the recombinant construct qualification.

Actual field mechanistic_edges[65]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 3 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid='CPLX-8780']/component[1]; MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid='CPLX-8780']/comment; MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid='CPLX-8780']/comment.

### e067: MetaCyc:CPLX-883 enables MetaCyc:1.3.99.15-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The complete native assignment and retained genetic/sequence evidence support enables for the BadDEFG assembly. No purified catalysis or whole CENT route is claimed. The rejected benzoate-feeding wording error does not enter this edge.

Actual field mechanistic_edges[66]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1102 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1102']/*[self::enzyme or self::reaction or self::evidence].

### e068: MetaCyc:CPLX-883 has_part UniProtKB:O07460

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[67]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid='CPLX-883']/component[1].

### e069: MetaCyc:CPLX-883 has_part UniProtKB:O07461

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[68]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid='CPLX-883']/component[2].

### e070: MetaCyc:CPLX-883 has_part UniProtKB:O07462

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[69]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid='CPLX-883']/component[3].

### e071: MetaCyc:CPLX-883 has_part UniProtKB:O07463

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The exact native component slot, explicit multiplicity and issuing protein/CDS crosswalk support composition, without isolated-subunit catalytic attribution.

Actual field mechanistic_edges[70]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid='CPLX-883']/component[4].

### e072: MetaCyc:CPLX-1341 has_cofactor MetaCyc:CPD-7

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Exact native CPD-7 cofactor slot supports generic intrinsic iron-sulfur association. Historical citation is preserved without choosing cluster count, assigning subunit occupancy, or confusing the donor protein.

Actual field mechanistic_edges[71]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/cofactor[Compound/@frameid='CPD-7'].

### e073: MetaCyc:CPLX-1341 has_cofactor CHEBI:18420

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Exact native magnesium cofactor slot supports this activity context; no global essentiality or concentration is added.

Actual field mechanistic_edges[72]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1821']/cofactor[Compound/@frameid='MG+2'].

### e074: MetaCyc:CPLX-1343 has_cofactor CHEBI:29105

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Explicitly labeled uncited native Zn annotation is permissible as structured cofactor evidence. It is not represented as measured historical occupancy; modern AAS evidence has its own qualified edge.

Actual field mechanistic_edges[73]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 1 evidence entries are preserved in the exact current-edge binding. Exact source locators: MetaCyc:ENZRXN-1823 /ptools-xml/Enzymatic-Reaction[@frameid='ENZRXN-1823']/cofactor[Compound/@frameid='ZN+2'].

### e075: NCBIProtein:WP_011418919.1 catalyzes MetaCyc:HADTHAUERA-RXN

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The complete primary P13 paragraph directly confirms substrate-specific recombinant SYN_RS14210/BamQ activity. Exact genomic CDS translation binds WP_011418919.1. P44 supports pET101/E. coli BL21; unread supplemental insert/tag details are not invented.

Actual field mechanistic_edges[74]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 2 evidence entries are preserved in the exact current-edge binding. Exact source locators: PMID:30895699 HTML p#P13; PMID:30895699 HTML p#P44.

### e076: UniProtKB:O87871 has_cofactor CHEBI:29105

graph: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

The primary AAS statement and Methods support two Zn per recombinant Strep-tagged WT subunit under Zn-supplemented expression. This is not historical native occupancy, a full crystallographic construct identity assertion, or physiological CoA substrate activity.

Actual field mechanistic_edges[75]. Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits. Complete endpoint qualifiers, coefficients and all 3 evidence entries are preserved in the exact current-edge binding. Exact source locators: PMID:35557486 HTML (//p)[111]; PMID:35557486 HTML (//p)[205]; PMID:35557486 HTML (//p)[204].

### Final archives, report, history and terminal gate attribution

provenance: supported. Targets: MetaCyc:CENTBENZCOA-PWY.

Complete preparation and gate evidence are retained through verified maintained owners. All scientific/core/generated inputs remain exact. Only the post-gate report paragraph changes among the 29,503 tested files, and its new dated status is accurate. The fifth native history and two verification archives were read and independently bound; root-run gates are not relabeled as this reviewer’s execution.

Full gate result: 5489 passed, three empty command-frontmatter parametrizations skipped, seven dependency warnings. The full logs and historical pre-gate wrapper failure remain retained. Canonical save/check and later staged/publication gates belong to root and are not claimed here.

## Findings

No findings recorded within this review's declared scope.

## Recommended Actions And Acceptance Checks

## Category Boundaries


## Evidence

| Evidence | Reference / locator | Support | Observation |
| --- | --- | --- | --- |
| ev-scientific-assessment | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/ASSESSMENT.preparation.md | supports | Independent whole maintained-record assessment; all 76 edges, 56 named identities, 25 references, 117 evidence assertions and explicit source limits. Prior whole-design judgment is reused through exact complete-edge equality, with current full YAML reading and fresh bounded original checks. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-edge-matrix | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/maintained-edge-assessments.json | supports | One independent disposition for each of the 76 actual maintained edges. All complete edge objects strictly equal the previously independently reviewed design; fresh locator checks preserve claim and qualifier scope. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-route | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/route-replay.json | supports | All seven selected memberships, 32 material occurrences, 19 frames, six shared-material joins and auxiliary eighth reaction; exact native directions, coefficients and Oah constituent sum. Deterministic replay supports correspondence, not experimental proof. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-locators | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/evidence-locator-replay.json | supports | All 117 evidence locators and all four exact short quotations resolve to original source bodies with the stated scope; no database assertion relabeled a primary-paper quote. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-identities | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/named-identity-assessment.json | supports | All 56 named record, reaction, participant and taxon identities checked against exact issuing originals and selected maintained authority terms. Names, native types and stable accession scope are separately assessed from biochemical function. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-references | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/reference-original-assessment.json | supports | All 25 native-object/publication references, exact source hashes and issuing identities. Human-facing BioCyc links designate the same object; retained hashes bind explicitly identified native XML rather than public HTML. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-replay | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/scientific-replay-execution-observation.json | supports | Actual successful reviewer replay observations, including 15 activity dispositions, 21 protein/CDS bindings, 13 assembly components, 76 edges and 117 evidence assertions. This is not a replacement full-corpus gate. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-imodulon | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/imodulon-applicability-assessment.json | supports | Same-day dated complete public iModulon dataset listing and fresh offline unmodified adapter replay; 20 organisms and 28 datasets. No matching source-taxon dataset in that finite listing; E. coli is a heterologous expression host. Not a fresh live query or negative biology. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-formatting | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/formatting-successor-independent-comparison.json | supports | Explicit old/new capture of three authority registry serializations; strict whole-JSON equality, original values and insertion-order prefixes retained; unchanged scientific YAML. No silent input hash refresh. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-authority | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/separate-root-support-binding.json | supports | Separately authored independent authority implementation/projection acceptance bound to exact current implementation inputs; root-generated render/KGX/browser proofs retain root attribution and their limits. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-retention-assessment | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/retention-integration/ASSESSMENT.supplement.md | supports | Full current research report and ownership prose, four native histories and relevant root/independent retention receipts read. No new scientific or provenance defect; final canonical state remained explicitly pending. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-retained-sources | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/retention-integration/scientific-maintained-owner-bindings.json | supports | All 3343 maintained payload files rehashed; 421 selected source occurrences (353 distinct contents) independently decoded and compared to originals, including complete design and all 25 record reference originals. Whole design remains strictly equal to maintained YAML. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-portable-retention | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/retention-integration/portable-verification-ownership.json | supports | All 43 root-integration archive members plus 255 retention archive members and 3343 explicit shared maintained owners match originals; unique relative regular-file membership and exact stored bytes. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-history | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/retention-integration/root-execution-and-history-bindings.json | supports | Three root actual-copy physical/compact/provenance executions and four native history records are exactly bound. Actual native curation stage and review status are distinct. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| ev-prior-design-reuse | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/prior-scientific-assessment-reuse.json | supports | Explicit exact binding to this reviewer’s original independent whole-design scientific assessment; no claim that hashing or serializer equality itself establishes biochemical truth. This retained reviewer ledger is distinct from the original database/publication evidence, whose exact native objects and source hashes are separately bound. |
| source-01 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/29/293bd88390943dcd0e8faad75a7bc3eb6375d54c434d8c923a243d5fd866f68d.gz; Original MetaCyc:1.3.99.15-RXN; content-map.json key 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f; gzip 293bd88390943dcd0e8faad75a7bc3eb6375d54c434d8c923a243d5fd866f68d → 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=1.3.99.15-RXN | supports | MetaCyc 27.0 complete native Reaction: 1.3.99.15-RXN. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-02 | research/pathway_additions/2026-10-15-next-265/evidence-retention/objects/03/03037688642aae1a5fec0fe44b3e9c3b90c8bf5d67e3a38866d8bc7bfda3333b.gz; Original MetaCyc:CENTBENZCOA-PWY; content-map.json key 6e7327287b9c3361cb4a6d85c6c8c268eaab294dfb1d1ea39bfcd3287e022e75; gzip 03037688642aae1a5fec0fe44b3e9c3b90c8bf5d67e3a38866d8bc7bfda3333b → 6e7327287b9c3361cb4a6d85c6c8c268eaab294dfb1d1ea39bfcd3287e022e75; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CENTBENZCOA-PWY | supports | MetaCyc 27.0 complete native Pathway: CENTBENZCOA-PWY. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-03 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/34/34247622dd903f6b76600ece0d3ef58ff4169706b1ab12082e7fa23d27c8960f.gz; Original MetaCyc:4.2.1.100-RXN; content-map.json key 5daac95308148b39b603664c3db64a6a5abf39999e5eff134a27b147c461caa8; gzip 34247622dd903f6b76600ece0d3ef58ff4169706b1ab12082e7fa23d27c8960f → 5daac95308148b39b603664c3db64a6a5abf39999e5eff134a27b147c461caa8; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=4.2.1.100-RXN | supports | MetaCyc 27.0 complete native Reaction: 4.2.1.100-RXN. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-04 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/46/461f1dd8e4f428940f24a3b1d042372e339f1350c9ea1b87da03ff486eb486d6.gz; Original MetaCyc:HADTHAUERA-RXN; content-map.json key 9c77754858f6fcdd2ca928b66ff2dc6f809563b89532bf4557cb30b356acb231; gzip 461f1dd8e4f428940f24a3b1d042372e339f1350c9ea1b87da03ff486eb486d6 → 9c77754858f6fcdd2ca928b66ff2dc6f809563b89532bf4557cb30b356acb231; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=HADTHAUERA-RXN | supports | MetaCyc 27.0 complete native Reaction: HADTHAUERA-RXN. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-05 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/dd/dda53852dde6cf8756aa2978c6324d9adc53e2a3f1a69d1459c472281911b2d5.gz; Original MetaCyc:RXN-15012; content-map.json key 5134bb4c1a1fcaba2036bdf9969b15d0e3bfd02b1605479dbc7336a38d6884b1; gzip dda53852dde6cf8756aa2978c6324d9adc53e2a3f1a69d1459c472281911b2d5 → 5134bb4c1a1fcaba2036bdf9969b15d0e3bfd02b1605479dbc7336a38d6884b1; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=RXN-15012 | supports | MetaCyc 27.0 complete native Reaction: RXN-15012. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-06 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/33/338bcca037eeeb524772e0e36207cbedb0fffe82c6249e2713305796d9cd823f.gz; Original MetaCyc:RXN-15013; content-map.json key fcee22c95121a359d1b59a70a7d30ec76fa32e806211e079a3433e67fa8115d3; gzip 338bcca037eeeb524772e0e36207cbedb0fffe82c6249e2713305796d9cd823f → fcee22c95121a359d1b59a70a7d30ec76fa32e806211e079a3433e67fa8115d3; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=RXN-15013 | supports | MetaCyc 27.0 complete native Reaction: RXN-15013. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-07 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/6e/6eb3bdb826ebc4b1cf786fd27f536979d47a8b57a59740b161c4471fe83b2479.gz; Original MetaCyc:1.1.1.259-RXN; content-map.json key b6591668c106849c13141da28a39ee82a6364e085b0dbd4ac30692af9567c502; gzip 6eb3bdb826ebc4b1cf786fd27f536979d47a8b57a59740b161c4471fe83b2479 → b6591668c106849c13141da28a39ee82a6364e085b0dbd4ac30692af9567c502; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=1.1.1.259-RXN | supports | MetaCyc 27.0 complete native Reaction: 1.1.1.259-RXN. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-08 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0a/0ae4b6084e5cf61833f621ba836e344474d30d53587a9881dd4a5bb96b4f861b.gz; Original MetaCyc:RXN-8032; content-map.json key e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a; gzip 0ae4b6084e5cf61833f621ba836e344474d30d53587a9881dd4a5bb96b4f861b → e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=RXN-8032 | supports | MetaCyc 27.0 complete native Reaction: RXN-8032. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-09 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/3a/3a723bbeeeece34a994bebe59c4d975695ea5ca4ad3a91e0f35e75bc8c9fd7a5.gz; Original MetaCyc:OAHTHAUERA-RXN; content-map.json key d0f778f36235b004616c7414da4d894a5744fc6cb792e653a613e681c71b748a; gzip 3a723bbeeeece34a994bebe59c4d975695ea5ca4ad3a91e0f35e75bc8c9fd7a5 → d0f778f36235b004616c7414da4d894a5744fc6cb792e653a613e681c71b748a; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=OAHTHAUERA-RXN | supports | MetaCyc 27.0 complete native Reaction: OAHTHAUERA-RXN. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-10 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0b/0b97fe58423ed57a27d1cf8a115db4de9838ed9613155550757f21591fa4aec1.gz; Original MetaCyc:CPLX-8779; content-map.json key e44b86c2637cbeb66ec307461f9239e5f352ed2c281d8a85a01240399a2456c3; gzip 0b97fe58423ed57a27d1cf8a115db4de9838ed9613155550757f21591fa4aec1 → e44b86c2637cbeb66ec307461f9239e5f352ed2c281d8a85a01240399a2456c3; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-8779 | supports | MetaCyc 27.0 complete native Protein: CPLX-8779. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-11 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/59/594c970933e543ce614070c0623f0f818b5a0c522c4bb1e9e3397c09343c4e80.gz; Original MetaCyc:CPLX-8780; content-map.json key e86d177ba28e40d72c472e6432e033ce11ee2fef20154ef64143725f72495a51; gzip 594c970933e543ce614070c0623f0f818b5a0c522c4bb1e9e3397c09343c4e80 → e86d177ba28e40d72c472e6432e033ce11ee2fef20154ef64143725f72495a51; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-8780 | supports | MetaCyc 27.0 complete native Protein: CPLX-8780. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-12 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/76/76dda9d9f329d44836e9249eedf86aca68d824b33ce148ed60debd1c139f1908.gz; Original MetaCyc:ENZRXN-1821; content-map.json key fbb3bc99f1a1da7bd24e855e5ff55ae24c938a2c2d713689bade1e2b3054b7b6; gzip 76dda9d9f329d44836e9249eedf86aca68d824b33ce148ed60debd1c139f1908 → fbb3bc99f1a1da7bd24e855e5ff55ae24c938a2c2d713689bade1e2b3054b7b6; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-1821 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1821. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-13 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/69/697ac4ef824edc411da2be0b2ad5c558a01be6d147b6fb8f0fd642c718edb5fc.gz; Original MetaCyc:CPLX-1341; content-map.json key c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf; gzip 697ac4ef824edc411da2be0b2ad5c558a01be6d147b6fb8f0fd642c718edb5fc → c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-1341 | supports | MetaCyc 27.0 complete native Protein: CPLX-1341. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-14 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/12/126285f35ded35d1992d6991dffbd44f0272ec4949fb6e32f58ff1ab27fefef7.gz; Original MetaCyc:ENZRXN-1822; content-map.json key b83bf3492d5058a1f2caf915aedb8f778956111bc71f7dbcf079114af7ac2e1e; gzip 126285f35ded35d1992d6991dffbd44f0272ec4949fb6e32f58ff1ab27fefef7 → b83bf3492d5058a1f2caf915aedb8f778956111bc71f7dbcf079114af7ac2e1e; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-1822 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1822. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-15 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/54/54fd4387fb25c791518c49b32540ba76746ddfad9c7c345a89c1202c34c7abd5.gz; Original MetaCyc:CPLX-1342; content-map.json key 8d4fdbf51ffecf05502dcaacd5be10b2f0a5f679c4db3d579e98a845a874f9f0; gzip 54fd4387fb25c791518c49b32540ba76746ddfad9c7c345a89c1202c34c7abd5 → 8d4fdbf51ffecf05502dcaacd5be10b2f0a5f679c4db3d579e98a845a874f9f0; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-1342 | supports | MetaCyc 27.0 complete native Protein: CPLX-1342. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-16 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/bb/bbe0acac4d6a76144de079e868408ebe5b671f04ce3395103909e003d43a4d0e.gz; Original MetaCyc:ENZRXN-1823; content-map.json key 6c1117e747e08816d64e292182bb413b968d2e8c24e2ef141a3787fc29b80f5b; gzip bbe0acac4d6a76144de079e868408ebe5b671f04ce3395103909e003d43a4d0e → 6c1117e747e08816d64e292182bb413b968d2e8c24e2ef141a3787fc29b80f5b; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-1823 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1823. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-17 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0c/0c97f941357dc0d44a8faba3e80b39a2dbe7d666788132e204d1faa91d8cdf5d.gz; Original MetaCyc:CPLX-1343; content-map.json key 071749ead25f503e2d1aa49b8ca6379f74dd719b3f02714a7c2fee166d453411; gzip 0c97f941357dc0d44a8faba3e80b39a2dbe7d666788132e204d1faa91d8cdf5d → 071749ead25f503e2d1aa49b8ca6379f74dd719b3f02714a7c2fee166d453411; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-1343 | supports | MetaCyc 27.0 complete native Protein: CPLX-1343. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-18 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/6d/6d35e85b78a66c519123cf64cf7d30389ee7d36553e7bee12698e2fb23e9bdd3.gz; Original MetaCyc:ENZRXN-1841; content-map.json key d710e90791a9571c6d4fc662e498040d96726e81352431a71d284c427e6d276c; gzip 6d35e85b78a66c519123cf64cf7d30389ee7d36553e7bee12698e2fb23e9bdd3 → d710e90791a9571c6d4fc662e498040d96726e81352431a71d284c427e6d276c; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-1841 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1841. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-19 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/53/53f520ace30a5e62866f13f0652ef1ab1438f5d815a68eb9a914085227306237.gz; Original MetaCyc:CPLX-1361; content-map.json key f037b2e0584ae09f190b8df1c2431a29c1cead51a1d14fa94f4e52b19f4214a8; gzip 53f520ace30a5e62866f13f0652ef1ab1438f5d815a68eb9a914085227306237 → f037b2e0584ae09f190b8df1c2431a29c1cead51a1d14fa94f4e52b19f4214a8; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-1361 | supports | MetaCyc 27.0 complete native Protein: CPLX-1361. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-20 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0f/0f71b3d253c29a8e09791e4007593070c60f2ba46aa3d83502e823ad0b9d5bbc.gz; Original MetaCyc:ENZRXN-22282; content-map.json key b03a78cd1d72883ce8939411ae96c4a91a5c60a62c272a6d222bc946a3064eff; gzip 0f71b3d253c29a8e09791e4007593070c60f2ba46aa3d83502e823ad0b9d5bbc → b03a78cd1d72883ce8939411ae96c4a91a5c60a62c272a6d222bc946a3064eff; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-22282 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-22282. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-21 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/1a/1a981baf6d39753519ba608d30f6b4538f5ea59daab82d3dc5216d841ac4060d.gz; Original MetaCyc:ENZRXN-22284; content-map.json key f417bf5ae7463a824d0a9d0ddb7c1fc1c5b90f9aa8d3361d6c12c7310c645a29; gzip 1a981baf6d39753519ba608d30f6b4538f5ea59daab82d3dc5216d841ac4060d → f417bf5ae7463a824d0a9d0ddb7c1fc1c5b90f9aa8d3361d6c12c7310c645a29; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-22284 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-22284. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-22 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/6c/6c11611641fe2b4b1ff1174a84a10f0bb7687de285dfc0fc46a1b77dcf498f39.gz; Original MetaCyc:ENZRXN-1102; content-map.json key 861b31b7be3305955524f3acbc11915c8bba149a3fe232fd256dfc7dffe10121; gzip 6c11611641fe2b4b1ff1174a84a10f0bb7687de285dfc0fc46a1b77dcf498f39 → 861b31b7be3305955524f3acbc11915c8bba149a3fe232fd256dfc7dffe10121; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=ENZRXN-1102 | supports | MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1102. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-23 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/9e/9e52cbb5046b2c8052ee86898699104c242909332902d6262af1afba12206be3.gz; Original MetaCyc:CPLX-883; content-map.json key a79b3e4d3aa714e1b654fa42692cf0ac2e4831c90f166cfec6e5de5adf649ad1; gzip 9e52cbb5046b2c8052ee86898699104c242909332902d6262af1afba12206be3 → a79b3e4d3aa714e1b654fa42692cf0ac2e4831c90f166cfec6e5de5adf649ad1; public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&amp;object=CPLX-883 | supports | MetaCyc 27.0 complete native Protein: CPLX-883. Complete original source hash and issuing identity verified. Native structured assertions retain exact XML object/slot locators and native type; this is not a quotation from a paper cited by the database. |
| source-24 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/65/65dcd07b536f1442cc20513bb685de4a0fe2b92f66348ff20955519c1ad32b78.gz; Original PMID:30895699; content-map.json key c34a8d2aa9600fb9242b9d1f0d4d14366aed13e55cb84c2608467ccd1b498c4d; gzip 65dcd07b536f1442cc20513bb685de4a0fe2b92f66348ff20955519c1ad32b78 → c34a8d2aa9600fb9242b9d1f0d4d14366aed13e55cb84c2608467ccd1b498c4d; public same-object/publication link https://pmc.ncbi.nlm.nih.gov/articles/PMC6488403/ | supports | Syntrophus aciditrophicus uses the same enzymes in a reversible manner to degrade and synthesize aromatic and alicyclic acids.. Complete original source hash and issuing identity verified. Primary claim support is limited to inspected assay/construct paragraphs; unacquired supplements are not treated as read. |
| source-25 | research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/2f/2f264c0f43987081f9b1780b99afe5981918a58aa67efe96539f0c88b53ab1c6.gz; Original PMID:35557486; content-map.json key b8b1f8983425f98697bf834f109d6a1e01a9797ea2325f12c40560a771aadc44; gzip 2f264c0f43987081f9b1780b99afe5981918a58aa67efe96539f0c88b53ab1c6 → b8b1f8983425f98697bf834f109d6a1e01a9797ea2325f12c40560a771aadc44; public same-object/publication link https://pmc.ncbi.nlm.nih.gov/articles/PMC9400901/ | supports | Advanced Insights into Catalytic and Structural Features of the Zinc-Dependent Alcohol Dehydrogenase from Thauera aromatica.. Complete original source hash and issuing identity verified. Primary claim support is limited to inspected assay/construct paragraphs; unacquired supplements are not treated as read. |
| ev-imodulon-original | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/imodulon-inputs/imodulondb-datasets-original.json | supports | Complete dated public dataset response from https://imodulondb.org/api/datasets, accessed 2026-10-15T13:11:04.934782Z. Exact response is reused, not freshly fetched. The matching unmodified adapter and failed prior transport observations are retained in adjacent archive members. |
| ev-initial-helper-failure | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/reference-check-initial-helper-failure.json | context_only | Historical reviewer helper failure: public BioCyc object URL was incorrectly equated to native XML mirror acquisition URL. Corrected with separate identity checks; no record change. A display-only optional source_version KeyError is also recorded. |
| ev-console-failure | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/imodulon-inputs/imodulondb-datasets-receipt.json | context_only | Historical same-day console runner dependency failure; exact command, exit 1 and stderr retained. Subsequent dated successful response and unchanged adapter replay support applicability. |
| ev-direct-adapter-failure | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; TAR member scientific/imodulon-inputs/imodulondb-direct-adapter-receipt.json | context_only | Historical same-day direct adapter transport was unavailable due to DNS URLError. No runtime was repaired; later successful public response is distinct. |
| ev-gate-1 | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member full-gates/just-render-pages.log | supports | All 263 pathway pages rendered, 102.14 seconds. Root executed this command; independent reviewer read the complete log and verified its digest and receipt. |
| ev-gate-2 | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member full-gates/just-validate.log | supports | Validated 263 records, 20,455 evidence blocks and 493 histories; closed schema, identifiers and label policies, source/docs contracts and page currentness passed, 195.41 seconds. Root executed this command; independent reviewer read the complete log and verified its digest and receipt. |
| ev-gate-3 | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member full-gates/just-test.log | supports | 5489 passed, 3 skipped, 7 warnings; pytest 969.95 seconds, wrapper 972.82 seconds. Three empty command-frontmatter parametrizations are explained by the unchanged test source and hidden/ignored-inclusive directory walk. Seven warnings are retained dependency deprecations. Root executed this command; independent reviewer read the complete log and verified its digest and receipt. |
| ev-gate-4 | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member full-gates/just-lint.log | supports | Ruff reported all checks passed, 0.41 seconds. Root executed this command; independent reviewer read the complete log and verified its digest and receipt. |
| ev-gate-5 | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member full-gates/git-diff---check.log | supports | Working-tree whitespace check returned zero with empty log, 0.66 seconds; this does not assert a later staged-index check. Root executed this command; independent reviewer read the complete log and verified its digest and receipt. |
| ev-terminal-receipts | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member full-gates/receipts.json | supports | All five root commands terminated with exit zero; real start times, elapsed durations and complete log hashes retained. |
| ev-gate-inputs | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR members full-gates/tested-core-input-hashes.json and full-gates/final-input-preservation.json | supports | Complete root before/after inventory: 29,503 files, hidden/ignored included, named runtime cache exclusions. Independent current rehash confirms 29,502 remain exact and only the read final report changed. Root run does not validate future additions. |
| ev-root-prerequisite-failure | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; TAR member root/gate-wrapper-prerequisite-race.json | context_only | Earlier wrapper failed reading a pending prerequisite before any gate command ran or gate output directory existed. The subsequent single complete run is preserved separately; no failed test was hidden. |
| ev-final-gate-archive | research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz; Complete TAR membership bound by adjacent source-file-manifest.json | supports | All 19 unique relative regular-file members independently compared to every original byte. Source manifest SHA256 85aae7a83cf8468206008f0f8b9ced182b721fc7378e28970f236d4552abce2d. |
| ev-complete-preparation | research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz; Complete TAR membership bound by adjacent source-file-manifest.json | supports | All 224 unique relative regular-file members independently compared to every original byte. Source manifest SHA256 6b32a52ead40dec6442e0d0387a41b57bd689feb94f39b21d7f45d265f73b421. |
| ev-final-report | research/pathway_additions/2026-10-15-next-266/README.md; Verification and publication section; complete report read and explicit old/new diff inspected | supports | Only the final dated verification paragraph changes. It accurately records terminal gates and retained preparation while leaving canonical persistence, publication, staged checks and merge as later observations. Scientific scope and all source limits remain unchanged. |
| ev-final-history | history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml; Complete native EDIT history | supports | Fifth native history records actual 2026-10-15T17:49:57Z adoption of successful gates and complete preparation retention. It does not claim canonical save, PR publication or merge. |
| ev-current-record | data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml; Complete maintained YAML; all fields, 76 edges, endpoint qualifiers, 25 references and 117 evidence assertions | supports | Complete actual YAML read during maintained review; current bytes remain exactly e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9. All scientific interpretation and current input hashes bind that same record. |

## Limits And Additional Notes

- The seven-step native route is source-defined formal chemistry; the record does not experimentally close every step in every listed organism.
- Generic ferredoxin cluster-unit coefficient two is not whole-polypeptide stoichiometry, a universal donor identity or intrinsic BCR cluster occupancy. Retired Rhea 19100 is not automatically replaced.
- Oah constituent equations and CPD-15900 cancellation do not demonstrate separately assayed catalysts or a free accumulated intermediate; native reversible metadata does not establish physiological reverse flux.
- Step 6 remains putative without a catalyst; predicted individual PimB and operon-level evidence do not establish a lower-route enzyme assay. No lower-route Thauera enzyme is asserted.
- Strain, gene-annotation conflict, tag/construct, expression host and apparent assembly qualifiers remain material. Modern Had preparation zinc measurements are not universal native occupancy.
- Selected historical full texts and supplements remain unavailable or unread: Oah PMID 10406950 and 18312395 full original text/GST ambiguity, PMID 9490071 and 10903310 abstract-level scope, the 1998 hydratase erratum, Had Table S2, and unseen recombinant insert/tag details. A BoxB bibliography lead is not the cited BCR full paper.
- iModulonDB applicability uses a dated same-day complete dataset response with exact offline adapter replay, not a fresh live query. No matching source-taxon dataset in that finite listing is not negative biology.
- The prior independently authored whole-design scientific assessment is reused through exact complete object/edge bindings, current full maintained YAML reading and fresh bounded source checks. This is not another full human reading of every upstream paper or source archive.
- Finite captured merged-baseline duplicate/source-follow evidence does not establish global absence. Earlier provenance corrections retain their exact prior findings and accepted successors; this review does not close GitHub issues.
- Authority implementation, broad retention/Git provenance and root browser/render/KGX checks retain their separate authorship and scope. Hash/schema/serializer success alone is not scientific acceptance.
- The completed root production run precedes only the explicitly read final report paragraph, fifth native history and verification archive additions. Current rehash preserves every other tested file. Later native save/check, final documentation/history checks, actual staged-index checks, PR publication and verified merge remain separate root-owned observations.
- The three skipped tests are empty command-frontmatter parametrizations, and seven retained dependency deprecation warnings do not represent skipped pathway scientific checks. Historical console/DNS/helper and pre-gate wrapper failures remain recorded separately from later successful checks.
- Exploratory overbroad displays of input inventories were truncated and are not counted as full human source readings. Complete binary inventories were parsed and independently verified; complete target YAML, final report, test log, relevant prose and bounded original scientific contexts were read separately.
- Independent scientific review under the native review-yaml-record skill and CLAW-governed contract. Initial maintained inspect preceded assessment; authority formatting changes and final report additions received explicit successor inspections. Prior preparation and source packages remain immutable. All 76 positive edge assessments cite their exact original source objects, current locators and endpoint qualifications. Empty findings does not close earlier provenance issues or imply fleet-wide scientific approval. No maintained write, Git/GitHub mutation, runtime repair, fresh network query or duplicated full gate was performed by this reviewer.
- The first external draft failed shape validation because notes was serialized as a string rather than the schema list. That exact draft, command receipt and stderr remain retained. This successor changes only that shape, replaces an explicitly abbreviated inspect command with its exact recorded argv, and uses a new actual finish timestamp/review ID; scientific content and all maintained inputs are unchanged.

## Complete Structured Record

The sibling review.yaml is authoritative.

```yaml
schema_version: 1.0.0
kind: record
repository: CultureBotAI/PathwayMech
title: Scientific review of benzoyl-CoA degradation II (anaerobic)
started_at: '2026-10-15T16:40:08Z'
reviewer:
  identity: Codex /root/next266_design_acceptance
  kind: agent
  independence: independent
  independence_basis: Independent of the source-to-record design, authority implementation
    and maintained integration authors. This reviewer authored the prior scientific
    design review and its explicitly reused exact-source judgments; root alone curates
    and saves maintained content.
skill: .claude/skills/review-yaml-record/SKILL.md
scientific_review: true
scope:
  description: 'Whole maintained CENTBENZCOA-PWY YAML: all 76 edges, 56 named identities,
    25 references, 117 evidence assertions, all seven selected steps and six formal
    joins, exact source/construct/taxon limits and retained ownership.'
  selection: Exactly data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml, MetaCyc:CENTBENZCOA-PWY.
  coverage: full
  population_size: 1
  reviewed_target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  exclusions:
  - target: Other pathway records
    reason: Full-corpus deterministic gates and finite duplicate scans are separately
      attributed; no new scientific record-by-record review of the other 262 maintained
      pathways.
  - target: Unacquired historical full text and supplements
    reason: Claims remain bounded to original source text actually read and the explicit
      access limitations.
targets:
- target_id: MetaCyc:CENTBENZCOA-PWY
  path: data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml
  label: benzoyl-CoA degradation II (anaerobic)
  kind: maintained
  record_class: Pathway
  owner_paths:
  - repository: CultureBotAI/PathwayMech
    path: data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml
    role: maintained pathway YAML; source-grounded curation owner
assessments:
- assessment_id: a-identity
  area: identity
  topic: Exact CENTBENZCOA-PWY identity and finite duplicate context
  outcome: supported
  summary: The maintained YAML denotes the complete source-defined benzoyl-CoA degradation
    II (anaerobic) route. It is distinct from the nine-step P321 route and the accepted
    aerobic PWY-1361 record. Prior independent merged-baseline/source-follow acceptance
    is reused within its finite captured scope; no global absence claim is made.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-scientific-assessment
  - ev-prior-design-reuse
  - ev-identities
  - ev-retained-sources
- assessment_id: a-route
  area: completeness
  topic: Complete selected route and formal joins
  outcome: supported
  summary: All seven selected reactions, 32 material occurrences over 19 frames and
    six shared-material joins are retained. The Oah net composite is an auxiliary
    eighth declared reaction, not an eighth selected step. No route subset is substituted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-route
  - ev-edge-matrix
  - ev-scientific-assessment
  metrics:
  - name: selected route steps
    value: 7
    unit: steps
    definition: All native selected membership steps represented
    denominator: 7
  - name: material joins
    value: 6
    unit: joins
    definition: All selected successive shared-material links represented
    denominator: 6
- assessment_id: a-feredoxin
  area: quantity
  topic: Generic ferredoxin cluster-unit stoichiometry
  outcome: supported
  summary: BCR uses coefficient two for generic native one-electron ferredoxin cluster
    units. Whole two-cluster polypeptides and intrinsic BCR iron-sulfur centers remain
    distinct. The retired Rhea 19100 chain is not an automatic replacement.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-route
  - ev-locators
  - ev-scientific-assessment
  details: The small-molecule charge residual of minus two is compensated by two native
    one-electron cluster oxidations. Generic drawings do not identify a universal
    donor sequence or occupancy.
- assessment_id: a-direction
  area: graph
  topic: Native directions and pathway traversal
  outcome: supported
  summary: Every reaction retains its native direction independently of selected material
    traversal. The six provides_input_for edges express formal source ordering and
    a shared coefficient-one material; they do not assert physical channeling, a protein
    complex or measured complete-route flux.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-route
  - ev-edge-matrix
  - ev-scientific-assessment
- assessment_id: a-oah
  area: scope
  topic: Oah composite and CPD-15900
  outcome: supported
  summary: The two formal Oah constituent equations sum exactly to the declared hydrolysis
    composite and cancel CPD-15900. They do not establish separately assayed constituent
    catalysts or a freely released or accumulating CPD-15900 intermediate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-route
  - ev-locators
  - ev-scientific-assessment
- assessment_id: a-lower-route
  area: scope
  topic: Putative step 6 and predicted operon-scoped PimB
  outcome: supported
  summary: Step 6 remains YES-PUTATIVE with exact formal materials and no assigned
    catalyst. Step 7 has a real native RXN-8032 → ENZRXN-26773 → MONOMER-20679/G-58826
    → Q6N3H9 chain, explicitly predicted and lacking individual biochemical characterization.
    Operon/mutant context does not justify a single-protein enables or catalyzes edge.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-scientific-assessment
  - ev-replay
  - ev-locators
  details: Neither missing-backlink reasoning nor a fabricated lower-route Thauera
    enzyme is used. C4 assays, BadH/Hcd annotations, proteomics and apo structures
    do not establish the exact Thauera C7 catalyst. The native reaction name is not
    an individual PimB assay.
- assessment_id: a-identity-crosswalks
  area: grounding
  topic: Issuing identities, reference originals and coefficients
  outcome: supported
  summary: All 56 named identities and 25 reference originals have exact issuing identity
    checks. All 117 locators and four short quotations are valid; 19 chemical identities
    and 17 complete native/ChEBI structure pairs preserve source stereochemistry and
    charge. Stable identifiers do not substitute for functional evidence.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-identities
  - ev-references
  - ev-locators
  - ev-replay
- assessment_id: a-proteins
  area: scope
  topic: Protein/CDS and assembly component scope
  outcome: supported
  summary: All 21 native protein/CDS crosswalks and all 15 activity dispositions were
    examined, including excluded examples. The 13 assembly component edges preserve
    sequence identity and multiplicity without assigning isolated-subunit catalysis.
    The BcrA CDS bcrB qualifier conflict remains an explicit annotation conflict.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-replay
  - ev-scientific-assessment
  - ev-retained-sources
- assessment_id: a-constructs
  area: scope
  topic: BamR, BamA and BamQ construct-specific evidence
  outcome: supported
  summary: BamR C-terminal His6 and BamA N-terminal His6 preparation qualifiers remain
    on assembly and component endpoints. Apparent oligomerization is not generalized
    to universal native assemblies. BamQ is the exact SYN_RS14210/WP_011418919.1 CDS
    with substrate-specific recombinant P13 assay support; P44 supports E. coli BL21/pET101,
    while unseen insert/tag details remain unknown.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-scientific-assessment
  - ev-references
  - ev-locators
- assessment_id: a-had
  area: evidence
  topic: Had zinc and activity-specific cofactors
  outcome: supported
  summary: The modern Had AAS result supports two zinc atoms per monomer for a C-terminal
    Strep-tagged wild-type, zinc-supplemented preparation. It does not establish historical
    native occupancy, mutant crystal identity or a physiological CoA-substrate assay.
    The separate native zinc statement remains uncited structured evidence; magnesium
    and intrinsic CPD-7 associations retain activity-specific scope.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-scientific-assessment
  - ev-references
  - ev-locators
- assessment_id: a-taxa
  area: scope
  topic: Taxa, historical strains and expression hosts
  outcome: supported
  summary: All four taxon identities are exact. Source-defined route membership is
    not experimental closure of every step in each taxon. Syntrophus upper-route examples
    do not establish ATP-dependent BCR there. R. palustris BadDEFG genetic/sequence
    evidence remains enables. Deposited CGA009 proteins, original CGA604 cloning,
    Thauera K172, Azoarcus KB740 and recombinant E. coli remain separate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-scientific-assessment
  - ev-identities
  - ev-replay
- assessment_id: a-sources
  area: evidence
  topic: Structured assertions, primary evidence and bounded original access
  outcome: supported
  summary: Native XML statements are represented as source assertions at exact object
    locators, not quotations from papers cited by the database. Primary construct
    and assay claims remain tied to inspected original paragraphs. Public BioCyc links
    and retained native XML hashes serve explicitly different roles.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-references
  - ev-locators
  - ev-scientific-assessment
  details: Unacquired original historical papers, erratum and supplementary files
    remain limitations; abstracts and bibliography leads are not promoted to read
    full text.
- assessment_id: a-imodulon
  area: evidence
  topic: Structured-source adapter applicability
  outcome: supported
  summary: The dated complete iModulonDB listing has no source-taxon dataset for Thauera,
    Syntrophus or Rhodopseudomonas. E. coli coverage concerns the expression host
    and cannot establish foreign-route catalysis. Per-dataset source-pathway search
    and component summaries are not applicable to these observed taxa.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-imodulon
  details: Same-day 2026-10-15T13:11:04.934782Z response reuse and offline exact adapter
    replay are explicit. Original console dependency and transport failures are preserved.
    Absence from this finite dataset list is not negative biology or a fresh live
    query.
- assessment_id: a-authority
  area: representation
  topic: Specialized typed authority profiles and serialization successor
  outcome: supported
  summary: The unnamed heteromer, typed Protein coefficient reaction, generic ferredoxin
    classes, Oah composite and named RXN-8032 shapes retain specific bounded owners.
    Separate independent authority implementation/projection acceptance is attributed.
    Three registry formatting successors preserve full JSON meaning and baseline entries;
    earlier inspected hashes remain in history.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-authority
  - ev-formatting
  - ev-identities
- assessment_id: a-retention
  area: provenance
  topic: Actual maintained scientific evidence and portable ownership
  outcome: supported
  summary: The current retained payload preserves the complete assessed design and
    selected scientific originals, every actual reference original, the prior independent
    judgments and original operational failures. The independent reviewer decoded
    421 selected occurrences/353 distinct contents and verified all 3343 payload files;
    broader complete logical and Git provenance checks retain separate reviewer/root
    attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-retained-sources
  - ev-portable-retention
  - ev-retention-assessment
- assessment_id: a-history
  area: ownership
  topic: Historical report and native stage accounting
  outcome: supported
  summary: The inspected report, ownership READMEs and four native histories distinguish
    creation, later retention adoption and the then-pending canonical/production boundary.
    Issues 590 and 591 retain their original findings and separate accepted corrections;
    this review does not publish or close GitHub issues.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-history
  - ev-retention-assessment
- assessment_id: a-generated
  area: representation
  topic: Generated page and KGX preservation evidence
  outcome: supported
  summary: Separately bound root checks cover the whole record in generated page/KGX
    output and old-edge preservation. Browser retry, initial sandbox startup failure
    and root visual inspection retain their actual attribution. This scientific reviewer
    does not claim another browser execution or screenshot inspection.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-authority
  - ev-portable-retention
- assessment_id: a-e001
  area: graph
  topic: 'e001: MetaCyc:1.3.99.15-RXN produces CHEBI:57374'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[0]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e002
  area: graph
  topic: 'e002: MetaCyc:1.3.99.15-RXN produces MetaCyc:Oxidized-ferredoxins'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. Native Protein-class cluster-unit names and
    comments support coefficient two; no whole-polypeptide or Rhea replacement equivalence
    is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[1]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e003
  area: graph
  topic: 'e003: MetaCyc:1.3.99.15-RXN produces CHEBI:456216'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[2]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[3];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e004
  area: graph
  topic: 'e004: MetaCyc:1.3.99.15-RXN produces CHEBI:43474'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[3]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/left[4];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e005
  area: graph
  topic: 'e005: CHEBI:57369 consumes MetaCyc:1.3.99.15-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[4]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e006
  area: graph
  topic: 'e006: MetaCyc:Reduced-ferredoxins consumes MetaCyc:1.3.99.15-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. Native Protein-class cluster-unit names and
    comments support coefficient two; no whole-polypeptide or Rhea replacement equivalence
    is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[5]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e007
  area: graph
  topic: 'e007: CHEBI:30616 consumes MetaCyc:1.3.99.15-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[6]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[3];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e008
  area: graph
  topic: 'e008: CHEBI:15377 consumes MetaCyc:1.3.99.15-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-01
  - source-02
  details: 'Actual field mechanistic_edges[7]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.3.99.15-RXN /ptools-xml/Reaction[@frameid=''1.3.99.15-RXN'']/right[4];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.3.99.15-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-01
    - source-02
  - name: source-object
    value: MetaCyc:1.3.99.15-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-01
    - source-02
- assessment_id: a-e009
  area: graph
  topic: 'e009: MetaCyc:1.3.99.15-RXN part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[8]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''1.3.99.15-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e010
  area: graph
  topic: 'e010: MetaCyc:4.2.1.100-RXN produces CHEBI:57361'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-03
  - source-02
  details: 'Actual field mechanistic_edges[9]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:4.2.1.100-RXN /ptools-xml/Reaction[@frameid=''4.2.1.100-RXN'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''4.2.1.100-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-03
    - source-02
  - name: source-object
    value: MetaCyc:4.2.1.100-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-03
    - source-02
- assessment_id: a-e011
  area: graph
  topic: 'e011: CHEBI:57374 consumes MetaCyc:4.2.1.100-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-03
  - source-02
  details: 'Actual field mechanistic_edges[10]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:4.2.1.100-RXN /ptools-xml/Reaction[@frameid=''4.2.1.100-RXN'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''4.2.1.100-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-03
    - source-02
  - name: source-object
    value: MetaCyc:4.2.1.100-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-03
    - source-02
- assessment_id: a-e012
  area: graph
  topic: 'e012: CHEBI:15377 consumes MetaCyc:4.2.1.100-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-03
  - source-02
  details: 'Actual field mechanistic_edges[11]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:4.2.1.100-RXN /ptools-xml/Reaction[@frameid=''4.2.1.100-RXN'']/right[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''4.2.1.100-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-03
    - source-02
  - name: source-object
    value: MetaCyc:4.2.1.100-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-03
    - source-02
- assessment_id: a-e013
  area: graph
  topic: 'e013: MetaCyc:4.2.1.100-RXN part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[12]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''4.2.1.100-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e014
  area: graph
  topic: 'e014: CHEBI:57361 consumes MetaCyc:HADTHAUERA-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-04
  - source-02
  details: 'Actual field mechanistic_edges[13]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid=''HADTHAUERA-RXN'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''HADTHAUERA-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-04
    - source-02
  - name: source-object
    value: MetaCyc:HADTHAUERA-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-04
    - source-02
- assessment_id: a-e015
  area: graph
  topic: 'e015: CHEBI:57540 consumes MetaCyc:HADTHAUERA-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-04
  - source-02
  details: 'Actual field mechanistic_edges[14]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid=''HADTHAUERA-RXN'']/left[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''HADTHAUERA-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-04
    - source-02
  - name: source-object
    value: MetaCyc:HADTHAUERA-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-04
    - source-02
- assessment_id: a-e016
  area: graph
  topic: 'e016: MetaCyc:HADTHAUERA-RXN produces CHEBI:15378'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-04
  - source-02
  details: 'Actual field mechanistic_edges[15]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid=''HADTHAUERA-RXN'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''HADTHAUERA-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-04
    - source-02
  - name: source-object
    value: MetaCyc:HADTHAUERA-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-04
    - source-02
- assessment_id: a-e017
  area: graph
  topic: 'e017: MetaCyc:HADTHAUERA-RXN produces CHEBI:76526'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-04
  - source-02
  details: 'Actual field mechanistic_edges[16]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid=''HADTHAUERA-RXN'']/right[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''HADTHAUERA-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-04
    - source-02
  - name: source-object
    value: MetaCyc:HADTHAUERA-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-04
    - source-02
- assessment_id: a-e018
  area: graph
  topic: 'e018: MetaCyc:HADTHAUERA-RXN produces CHEBI:57945'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-04
  - source-02
  details: 'Actual field mechanistic_edges[17]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:HADTHAUERA-RXN /ptools-xml/Reaction[@frameid=''HADTHAUERA-RXN'']/right[3];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''HADTHAUERA-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-04
    - source-02
  - name: source-object
    value: MetaCyc:HADTHAUERA-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-04
    - source-02
- assessment_id: a-e019
  area: graph
  topic: 'e019: MetaCyc:HADTHAUERA-RXN part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[18]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''HADTHAUERA-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e020
  area: graph
  topic: 'e020: CHEBI:76526 consumes MetaCyc:RXN-15012'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-05
  - source-02
  details: 'Actual field mechanistic_edges[19]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15012 /ptools-xml/Reaction[@frameid=''RXN-15012'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15012'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-05
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15012; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-05
    - source-02
- assessment_id: a-e021
  area: graph
  topic: 'e021: CHEBI:15377 consumes MetaCyc:RXN-15012'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-05
  - source-02
  details: 'Actual field mechanistic_edges[20]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15012 /ptools-xml/Reaction[@frameid=''RXN-15012'']/left[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15012'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-05
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15012; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-05
    - source-02
- assessment_id: a-e022
  area: graph
  topic: 'e022: MetaCyc:RXN-15012 produces CHEBI:76527'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-05
  - source-02
  details: 'Actual field mechanistic_edges[21]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15012 /ptools-xml/Reaction[@frameid=''RXN-15012'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15012'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-05
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15012; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-05
    - source-02
- assessment_id: a-e023
  area: graph
  topic: 'e023: MetaCyc:RXN-15012 part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[22]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''RXN-15012''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e024
  area: graph
  topic: 'e024: CHEBI:76527 consumes MetaCyc:RXN-15013'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-06
  - source-02
  details: 'Actual field mechanistic_edges[23]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid=''RXN-15013'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15013'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-06
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15013; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-06
    - source-02
- assessment_id: a-e025
  area: graph
  topic: 'e025: CHEBI:15377 consumes MetaCyc:RXN-15013'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-06
  - source-02
  details: 'Actual field mechanistic_edges[24]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid=''RXN-15013'']/left[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15013'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-06
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15013; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-06
    - source-02
- assessment_id: a-e026
  area: graph
  topic: 'e026: MetaCyc:RXN-15013 produces CHEBI:57343'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-06
  - source-02
  details: 'Actual field mechanistic_edges[25]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid=''RXN-15013'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15013'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-06
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15013; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-06
    - source-02
- assessment_id: a-e027
  area: graph
  topic: 'e027: MetaCyc:RXN-15013 produces CHEBI:15378'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-06
  - source-02
  details: 'Actual field mechanistic_edges[26]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-15013 /ptools-xml/Reaction[@frameid=''RXN-15013'']/right[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-15013'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-06
    - source-02
  - name: source-object
    value: MetaCyc:RXN-15013; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-06
    - source-02
- assessment_id: a-e028
  area: graph
  topic: 'e028: MetaCyc:RXN-15013 part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[27]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''RXN-15013''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e029
  area: graph
  topic: 'e029: CHEBI:57343 consumes MetaCyc:1.1.1.259-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. YES-PUTATIVE and absent native enzyme backlink
    remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-07
  - source-02
  details: 'Actual field mechanistic_edges[28]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-07
    - source-02
  - name: source-object
    value: MetaCyc:1.1.1.259-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-07
    - source-02
- assessment_id: a-e030
  area: graph
  topic: 'e030: CHEBI:57540 consumes MetaCyc:1.1.1.259-RXN'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. YES-PUTATIVE and absent native enzyme backlink
    remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-07
  - source-02
  details: 'Actual field mechanistic_edges[29]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/left[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-07
    - source-02
  - name: source-object
    value: MetaCyc:1.1.1.259-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-07
    - source-02
- assessment_id: a-e031
  area: graph
  topic: 'e031: MetaCyc:1.1.1.259-RXN produces CHEBI:15378'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. YES-PUTATIVE and absent native enzyme backlink
    remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-07
  - source-02
  details: 'Actual field mechanistic_edges[30]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-07
    - source-02
  - name: source-object
    value: MetaCyc:1.1.1.259-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-07
    - source-02
- assessment_id: a-e032
  area: graph
  topic: 'e032: MetaCyc:1.1.1.259-RXN produces CHEBI:57945'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. YES-PUTATIVE and absent native enzyme backlink
    remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-07
  - source-02
  details: 'Actual field mechanistic_edges[31]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-07
    - source-02
  - name: source-object
    value: MetaCyc:1.1.1.259-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-07
    - source-02
- assessment_id: a-e033
  area: graph
  topic: 'e033: MetaCyc:1.1.1.259-RXN produces CHEBI:57350'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. YES-PUTATIVE and absent native enzyme backlink
    remain explicit; this is formal route chemistry, not a demonstrated exact catalyst.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-07
  - source-02
  details: 'Actual field mechanistic_edges[32]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:1.1.1.259-RXN /ptools-xml/Reaction[@frameid=''1.1.1.259-RXN'']/right[3];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''1.1.1.259-RXN'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-07
    - source-02
  - name: source-object
    value: MetaCyc:1.1.1.259-RXN; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-07
    - source-02
- assessment_id: a-e034
  area: graph
  topic: 'e034: MetaCyc:1.1.1.259-RXN part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[33]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''1.1.1.259-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e035
  area: graph
  topic: 'e035: CHEBI:57350 consumes MetaCyc:RXN-8032'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. Real PimB native assignment exists but is
    excluded from causal catalysis/enables because current evidence is predicted function
    and operon scope.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-08
  - source-02
  details: 'Actual field mechanistic_edges[34]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid=''RXN-8032'']/left[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-08
    - source-02
  - name: source-object
    value: MetaCyc:RXN-8032; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-08
    - source-02
- assessment_id: a-e036
  area: graph
  topic: 'e036: CHEBI:57287 consumes MetaCyc:RXN-8032'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. Real PimB native assignment exists but is
    excluded from causal catalysis/enables because current evidence is predicted function
    and operon scope.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-08
  - source-02
  details: 'Actual field mechanistic_edges[35]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid=''RXN-8032'']/left[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-08
    - source-02
  - name: source-object
    value: MetaCyc:RXN-8032; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-08
    - source-02
- assessment_id: a-e037
  area: graph
  topic: 'e037: MetaCyc:RXN-8032 produces CHEBI:57378'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. Real PimB native assignment exists but is
    excluded from causal catalysis/enables because current evidence is predicted function
    and operon scope.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-08
  - source-02
  details: 'Actual field mechanistic_edges[36]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid=''RXN-8032'']/right[1];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-08
    - source-02
  - name: source-object
    value: MetaCyc:RXN-8032; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-08
    - source-02
- assessment_id: a-e038
  area: graph
  topic: 'e038: MetaCyc:RXN-8032 produces CHEBI:57288'
  outcome: supported
  summary: Complete native material slot, coefficient, exact identity crosswalk and
    pathway layout support the selected input/output orientation. Native reaction
    direction is retained independently. Real PimB native assignment exists but is
    excluded from causal catalysis/enables because current evidence is predicted function
    and operon scope.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-08
  - source-02
  details: 'Actual field mechanistic_edges[37]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:RXN-8032 /ptools-xml/Reaction[@frameid=''RXN-8032'']/right[2];
    MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-layout[Reaction/@frameid=''RXN-8032'']/direction.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-08
    - source-02
  - name: source-object
    value: MetaCyc:RXN-8032; MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-08
    - source-02
- assessment_id: a-e039
  area: graph
  topic: 'e039: MetaCyc:RXN-8032 part_of MetaCyc:CENTBENZCOA-PWY'
  outcome: supported
  summary: Explicit native membership supports selected-route inclusion, not experimental
    closure in every listed taxon.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[38]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-list/Reaction[@frameid=''RXN-8032''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e040
  area: graph
  topic: 'e040: MetaCyc:1.3.99.15-RXN provides_input_for MetaCyc:4.2.1.100-RXN'
  outcome: supported
  summary: Native predecessor ordering and the same coefficient-one intermediate on
    adjacent traversed equations support a formal material join. Neither physical
    channeling nor measured complete-route flux is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[39]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-ordering[Reaction/@frameid=''4.2.1.100-RXN'']/predecessor-reactions/Reaction[@frameid=''1.3.99.15-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e041
  area: graph
  topic: 'e041: MetaCyc:4.2.1.100-RXN provides_input_for MetaCyc:HADTHAUERA-RXN'
  outcome: supported
  summary: Native predecessor ordering and the same coefficient-one intermediate on
    adjacent traversed equations support a formal material join. Neither physical
    channeling nor measured complete-route flux is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[40]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-ordering[Reaction/@frameid=''HADTHAUERA-RXN'']/predecessor-reactions/Reaction[@frameid=''4.2.1.100-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e042
  area: graph
  topic: 'e042: MetaCyc:HADTHAUERA-RXN provides_input_for MetaCyc:RXN-15012'
  outcome: supported
  summary: Native predecessor ordering and the same coefficient-one intermediate on
    adjacent traversed equations support a formal material join. Neither physical
    channeling nor measured complete-route flux is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[41]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-ordering[Reaction/@frameid=''RXN-15012'']/predecessor-reactions/Reaction[@frameid=''HADTHAUERA-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e043
  area: graph
  topic: 'e043: MetaCyc:RXN-15012 provides_input_for MetaCyc:RXN-15013'
  outcome: supported
  summary: Native predecessor ordering and the same coefficient-one intermediate on
    adjacent traversed equations support a formal material join. Neither physical
    channeling nor measured complete-route flux is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[42]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-ordering[Reaction/@frameid=''RXN-15013'']/predecessor-reactions/Reaction[@frameid=''RXN-15012''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e044
  area: graph
  topic: 'e044: MetaCyc:RXN-15013 provides_input_for MetaCyc:1.1.1.259-RXN'
  outcome: supported
  summary: Native predecessor ordering and the same coefficient-one intermediate on
    adjacent traversed equations support a formal material join. Neither physical
    channeling nor measured complete-route flux is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[43]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-ordering[Reaction/@frameid=''1.1.1.259-RXN'']/predecessor-reactions/Reaction[@frameid=''RXN-15013''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e045
  area: graph
  topic: 'e045: MetaCyc:1.1.1.259-RXN provides_input_for MetaCyc:RXN-8032'
  outcome: supported
  summary: Native predecessor ordering and the same coefficient-one intermediate on
    adjacent traversed equations support a formal material join. Neither physical
    channeling nor measured complete-route flux is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-02
  details: 'Actual field mechanistic_edges[44]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CENTBENZCOA-PWY /ptools-xml/Pathway[@frameid=''CENTBENZCOA-PWY'']/reaction-ordering[Reaction/@frameid=''RXN-8032'']/predecessor-reactions/Reaction[@frameid=''1.1.1.259-RXN''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-02
  - name: source-object
    value: MetaCyc:CENTBENZCOA-PWY
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-02
- assessment_id: a-e046
  area: graph
  topic: 'e046: CHEBI:76526 consumes MetaCyc:OAHTHAUERA-RXN'
  outcome: supported
  summary: Complete native net Oah equation supports this material and coefficient
    in forward hydrolysis. Formal constituents and lack of free-intermediate evidence
    are kept separate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-09
  details: 'Actual field mechanistic_edges[45]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid=''OAHTHAUERA-RXN'']/left[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-09
  - name: source-object
    value: MetaCyc:OAHTHAUERA-RXN
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-09
- assessment_id: a-e047
  area: graph
  topic: 'e047: CHEBI:15377 consumes MetaCyc:OAHTHAUERA-RXN'
  outcome: supported
  summary: Complete native net Oah equation supports this material and coefficient
    in forward hydrolysis. Formal constituents and lack of free-intermediate evidence
    are kept separate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-09
  details: 'Actual field mechanistic_edges[46]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid=''OAHTHAUERA-RXN'']/left[2].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-09
  - name: source-object
    value: MetaCyc:OAHTHAUERA-RXN
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-09
- assessment_id: a-e048
  area: graph
  topic: 'e048: MetaCyc:OAHTHAUERA-RXN produces CHEBI:15378'
  outcome: supported
  summary: Complete native net Oah equation supports this material and coefficient
    in forward hydrolysis. Formal constituents and lack of free-intermediate evidence
    are kept separate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-09
  details: 'Actual field mechanistic_edges[47]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid=''OAHTHAUERA-RXN'']/right[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-09
  - name: source-object
    value: MetaCyc:OAHTHAUERA-RXN
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-09
- assessment_id: a-e049
  area: graph
  topic: 'e049: MetaCyc:OAHTHAUERA-RXN produces CHEBI:57343'
  outcome: supported
  summary: Complete native net Oah equation supports this material and coefficient
    in forward hydrolysis. Formal constituents and lack of free-intermediate evidence
    are kept separate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-09
  details: 'Actual field mechanistic_edges[48]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid=''OAHTHAUERA-RXN'']/right[2].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-09
  - name: source-object
    value: MetaCyc:OAHTHAUERA-RXN
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-09
- assessment_id: a-e050
  area: graph
  topic: 'e050: MetaCyc:RXN-15012 part_of MetaCyc:OAHTHAUERA-RXN'
  outcome: supported
  summary: Explicit composite member and exact signed cancellation support formal
    constituent membership; the composite itself is not selected as an eighth pathway
    step.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-09
  details: 'Actual field mechanistic_edges[49]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid=''OAHTHAUERA-RXN'']/reaction-list/Reaction[@frameid=''RXN-15012''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-09
  - name: source-object
    value: MetaCyc:OAHTHAUERA-RXN
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-09
- assessment_id: a-e051
  area: graph
  topic: 'e051: MetaCyc:RXN-15013 part_of MetaCyc:OAHTHAUERA-RXN'
  outcome: supported
  summary: Explicit composite member and exact signed cancellation support formal
    constituent membership; the composite itself is not selected as an eighth pathway
    step.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-09
  details: 'Actual field mechanistic_edges[50]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:OAHTHAUERA-RXN /ptools-xml/Reaction[@frameid=''OAHTHAUERA-RXN'']/reaction-list/Reaction[@frameid=''RXN-15013''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-09
  - name: source-object
    value: MetaCyc:OAHTHAUERA-RXN
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-09
- assessment_id: a-e052
  area: graph
  topic: 'e052: MetaCyc:CPLX-1341 catalyzes MetaCyc:1.3.99.15-RXN'
  outcome: supported
  summary: Purified-protein native evidence joins the four-subunit Thauera BCR to
    ATP-dependent reductive dearomatization. Neither subunits nor natural donor are
    individually assigned this catalysis.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-12
  details: 'Actual field mechanistic_edges[51]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/*[self::enzyme
    or self::reaction or self::evidence].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-12
  - name: source-object
    value: MetaCyc:ENZRXN-1821
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-12
- assessment_id: a-e053
  area: graph
  topic: 'e053: MetaCyc:CPLX-1341 has_part UniProtKB:O87876'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-13
  details: 'Actual field mechanistic_edges[52]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid=''CPLX-1341'']/component[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-13
  - name: source-object
    value: MetaCyc:CPLX-1341
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-13
- assessment_id: a-e054
  area: graph
  topic: 'e054: MetaCyc:CPLX-1341 has_part UniProtKB:O87875'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-13
  details: 'Actual field mechanistic_edges[53]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid=''CPLX-1341'']/component[2].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-13
  - name: source-object
    value: MetaCyc:CPLX-1341
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-13
- assessment_id: a-e055
  area: graph
  topic: 'e055: MetaCyc:CPLX-1341 has_part UniProtKB:O87874'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-13
  details: 'Actual field mechanistic_edges[54]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid=''CPLX-1341'']/component[3].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-13
  - name: source-object
    value: MetaCyc:CPLX-1341
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-13
- assessment_id: a-e056
  area: graph
  topic: 'e056: MetaCyc:CPLX-1341 has_part UniProtKB:O87877'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-13
  details: 'Actual field mechanistic_edges[55]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1341 /ptools-xml/Protein[@frameid=''CPLX-1341'']/component[4].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-13
  - name: source-object
    value: MetaCyc:CPLX-1341
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-13
- assessment_id: a-e057
  area: graph
  topic: 'e057: MetaCyc:CPLX-1342 catalyzes MetaCyc:4.2.1.100-RXN'
  outcome: supported
  summary: Native Dch activity and homodimer context support hydration. EV-EXP is
    retained rather than relabeled as a freshly read purified-protein experiment;
    missing full erratum remains a source limit.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-14
  details: 'Actual field mechanistic_edges[56]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1822 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1822'']/*[self::enzyme
    or self::reaction or self::evidence].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-14
  - name: source-object
    value: MetaCyc:ENZRXN-1822
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-14
- assessment_id: a-e058
  area: graph
  topic: 'e058: MetaCyc:CPLX-1342 has_part UniProtKB:O87873'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-15
  details: 'Actual field mechanistic_edges[57]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1342 /ptools-xml/Protein[@frameid=''CPLX-1342'']/component[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-15
  - name: source-object
    value: MetaCyc:CPLX-1342
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-15
- assessment_id: a-e059
  area: graph
  topic: 'e059: MetaCyc:CPLX-1343 catalyzes MetaCyc:HADTHAUERA-RXN'
  outcome: supported
  summary: The native activity independently includes native-host purified-protein
    evidence, so the native complex edge does not require treating its second, recombinant
    preparation as unmodified native enzyme. Modern construct evidence remains separate.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-16
  details: 'Actual field mechanistic_edges[58]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1823 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1823'']/*[self::enzyme
    or self::reaction or self::evidence].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-16
  - name: source-object
    value: MetaCyc:ENZRXN-1823
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-16
- assessment_id: a-e060
  area: graph
  topic: 'e060: MetaCyc:CPLX-1343 has_part UniProtKB:O87871'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-17
  details: 'Actual field mechanistic_edges[59]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1343 /ptools-xml/Protein[@frameid=''CPLX-1343'']/component[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-17
  - name: source-object
    value: MetaCyc:CPLX-1343
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-17
- assessment_id: a-e061
  area: graph
  topic: 'e061: MetaCyc:CPLX-1361 catalyzes MetaCyc:OAHTHAUERA-RXN'
  outcome: supported
  summary: Native-host purified Oah evidence supports the net hydrolysis only. REVERSIBLE
    is source metadata, not observed reverse ring formation; no constituent catalyst
    is asserted.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-18
  details: 'Actual field mechanistic_edges[60]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1841 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1841'']/*[self::enzyme
    or self::reaction or self::evidence].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-18
  - name: source-object
    value: MetaCyc:ENZRXN-1841
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-18
- assessment_id: a-e062
  area: graph
  topic: 'e062: MetaCyc:CPLX-1361 has_part UniProtKB:O87872'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-19
  details: 'Actual field mechanistic_edges[61]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-1361 /ptools-xml/Protein[@frameid=''CPLX-1361'']/component[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-19
  - name: source-object
    value: MetaCyc:CPLX-1361
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-19
- assessment_id: a-e063
  area: graph
  topic: 'e063: MetaCyc:CPLX-8779 catalyzes MetaCyc:4.2.1.100-RXN'
  outcome: supported
  summary: Recombinant BamR catalytic evidence is explicitly C-terminal His6/E. coli
    qualified on the complex subject. The native component count does not claim a
    universally native tetramer.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-20
  - source-10
  details: 'Actual field mechanistic_edges[62]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-22282 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-22282'']/*[self::enzyme
    or self::reaction or self::evidence]; MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid=''CPLX-8779'']/comment.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-20
    - source-10
  - name: source-object
    value: MetaCyc:ENZRXN-22282; MetaCyc:CPLX-8779
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-20
    - source-10
  - name: taxon-condition-component-role
    value: 'subject: experimental_construct: C-terminal His6 BamR expressed in Escherichia
      coli; apparent oligomeric assignment applies to this recombinant preparation.'
    definition: Actual maintained endpoint qualifications retained without broadening
      strain, construct or condition.
    evidence_ids:
    - source-20
    - source-10
- assessment_id: a-e064
  area: graph
  topic: 'e064: MetaCyc:CPLX-8779 has_part UniProtKB:Q2LXU6'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
    Both assembly and component endpoints retain the recombinant construct qualification.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-10
  details: 'Actual field mechanistic_edges[63]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 3 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid=''CPLX-8779'']/component[1];
    MetaCyc:CPLX-8779 /ptools-xml/Protein[@frameid=''CPLX-8779'']/comment; MetaCyc:CPLX-8779
    /ptools-xml/Protein[@frameid=''CPLX-8779'']/comment.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-10
  - name: source-object
    value: MetaCyc:CPLX-8779
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-10
  - name: taxon-condition-component-role
    value: 'subject: experimental_construct: C-terminal His6 BamR expressed in Escherichia
      coli; apparent oligomeric assignment applies to this recombinant preparation.
      | object: experimental_construct: C-terminal His6 BamR expressed in Escherichia
      coli; apparent oligomeric assignment applies to this recombinant preparation.'
    definition: Actual maintained endpoint qualifications retained without broadening
      strain, construct or condition.
    evidence_ids:
    - source-10
- assessment_id: a-e065
  area: graph
  topic: 'e065: MetaCyc:CPLX-8780 catalyzes MetaCyc:OAHTHAUERA-RXN'
  outcome: supported
  summary: Recombinant BamA net-hydrolysis evidence is N-terminal His6/E. coli qualified.
    Apparent homohexamer is an experimental assembly inference; no CPD-15900 accumulation
    follows.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-21
  - source-11
  details: 'Actual field mechanistic_edges[64]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-22284 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-22284'']/*[self::enzyme
    or self::reaction or self::evidence]; MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid=''CPLX-8780'']/comment.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-21
    - source-11
  - name: source-object
    value: MetaCyc:ENZRXN-22284; MetaCyc:CPLX-8780
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-21
    - source-11
  - name: taxon-condition-component-role
    value: 'subject: experimental_construct: N-terminal His6 BamA expressed in Escherichia
      coli; apparent homohexamer inferred from the recombinant preparation.'
    definition: Actual maintained endpoint qualifications retained without broadening
      strain, construct or condition.
    evidence_ids:
    - source-21
    - source-11
- assessment_id: a-e066
  area: graph
  topic: 'e066: MetaCyc:CPLX-8780 has_part UniProtKB:Q2LXU2'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
    Both assembly and component endpoints retain the recombinant construct qualification.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-11
  details: 'Actual field mechanistic_edges[65]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 3 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid=''CPLX-8780'']/component[1];
    MetaCyc:CPLX-8780 /ptools-xml/Protein[@frameid=''CPLX-8780'']/comment; MetaCyc:CPLX-8780
    /ptools-xml/Protein[@frameid=''CPLX-8780'']/comment.'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-11
  - name: source-object
    value: MetaCyc:CPLX-8780
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-11
  - name: taxon-condition-component-role
    value: 'subject: experimental_construct: N-terminal His6 BamA expressed in Escherichia
      coli; apparent homohexamer inferred from the recombinant preparation. | object:
      experimental_construct: N-terminal His6 BamA expressed in Escherichia coli;
      apparent homohexamer inferred from the recombinant preparation.'
    definition: Actual maintained endpoint qualifications retained without broadening
      strain, construct or condition.
    evidence_ids:
    - source-11
- assessment_id: a-e067
  area: graph
  topic: 'e067: MetaCyc:CPLX-883 enables MetaCyc:1.3.99.15-RXN'
  outcome: supported
  summary: The complete native assignment and retained genetic/sequence evidence support
    enables for the BadDEFG assembly. No purified catalysis or whole CENT route is
    claimed. The rejected benzoate-feeding wording error does not enter this edge.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-22
  details: 'Actual field mechanistic_edges[66]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1102 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1102'']/*[self::enzyme
    or self::reaction or self::evidence].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-22
  - name: source-object
    value: MetaCyc:ENZRXN-1102
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-22
- assessment_id: a-e068
  area: graph
  topic: 'e068: MetaCyc:CPLX-883 has_part UniProtKB:O07460'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-23
  details: 'Actual field mechanistic_edges[67]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid=''CPLX-883'']/component[1].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-23
  - name: source-object
    value: MetaCyc:CPLX-883
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-23
- assessment_id: a-e069
  area: graph
  topic: 'e069: MetaCyc:CPLX-883 has_part UniProtKB:O07461'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-23
  details: 'Actual field mechanistic_edges[68]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid=''CPLX-883'']/component[2].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-23
  - name: source-object
    value: MetaCyc:CPLX-883
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-23
- assessment_id: a-e070
  area: graph
  topic: 'e070: MetaCyc:CPLX-883 has_part UniProtKB:O07462'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-23
  details: 'Actual field mechanistic_edges[69]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid=''CPLX-883'']/component[3].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-23
  - name: source-object
    value: MetaCyc:CPLX-883
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-23
- assessment_id: a-e071
  area: graph
  topic: 'e071: MetaCyc:CPLX-883 has_part UniProtKB:O07463'
  outcome: supported
  summary: The exact native component slot, explicit multiplicity and issuing protein/CDS
    crosswalk support composition, without isolated-subunit catalytic attribution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-23
  details: 'Actual field mechanistic_edges[70]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:CPLX-883 /ptools-xml/Protein[@frameid=''CPLX-883'']/component[4].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-23
  - name: source-object
    value: MetaCyc:CPLX-883
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-23
- assessment_id: a-e072
  area: graph
  topic: 'e072: MetaCyc:CPLX-1341 has_cofactor MetaCyc:CPD-7'
  outcome: supported
  summary: Exact native CPD-7 cofactor slot supports generic intrinsic iron-sulfur
    association. Historical citation is preserved without choosing cluster count,
    assigning subunit occupancy, or confusing the donor protein.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-12
  details: 'Actual field mechanistic_edges[71]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/cofactor[Compound/@frameid=''CPD-7''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-12
  - name: source-object
    value: MetaCyc:ENZRXN-1821
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-12
- assessment_id: a-e073
  area: graph
  topic: 'e073: MetaCyc:CPLX-1341 has_cofactor CHEBI:18420'
  outcome: supported
  summary: Exact native magnesium cofactor slot supports this activity context; no
    global essentiality or concentration is added.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-12
  details: 'Actual field mechanistic_edges[72]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1821 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1821'']/cofactor[Compound/@frameid=''MG+2''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-12
  - name: source-object
    value: MetaCyc:ENZRXN-1821
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-12
- assessment_id: a-e074
  area: graph
  topic: 'e074: MetaCyc:CPLX-1343 has_cofactor CHEBI:29105'
  outcome: supported
  summary: Explicitly labeled uncited native Zn annotation is permissible as structured
    cofactor evidence. It is not represented as measured historical occupancy; modern
    AAS evidence has its own qualified edge.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-16
  details: 'Actual field mechanistic_edges[73]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 1 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: MetaCyc:ENZRXN-1823 /ptools-xml/Enzymatic-Reaction[@frameid=''ENZRXN-1823'']/cofactor[Compound/@frameid=''ZN+2''].'
  dimensions:
  - name: evidence-tier
    value: issuing native structured assertion
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-16
  - name: source-object
    value: MetaCyc:ENZRXN-1823
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-16
- assessment_id: a-e075
  area: graph
  topic: 'e075: NCBIProtein:WP_011418919.1 catalyzes MetaCyc:HADTHAUERA-RXN'
  outcome: supported
  summary: The complete primary P13 paragraph directly confirms substrate-specific
    recombinant SYN_RS14210/BamQ activity. Exact genomic CDS translation binds WP_011418919.1.
    P44 supports pET101/E. coli BL21; unread supplemental insert/tag details are not
    invented.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-24
  details: 'Actual field mechanistic_edges[74]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 2 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: PMID:30895699 HTML p#P13; PMID:30895699 HTML p#P44.'
  dimensions:
  - name: evidence-tier
    value: inspected primary publication text
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-24
  - name: source-object
    value: PMID:30895699
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-24
  - name: taxon-condition-component-role
    value: 'subject: experimental_construct: SYN_RS14210 expressed in E. coli BL21
      using pET101; supplementary construct sequence/tag details were not read and
      are not inferred.'
    definition: Actual maintained endpoint qualifications retained without broadening
      strain, construct or condition.
    evidence_ids:
    - source-24
- assessment_id: a-e076
  area: graph
  topic: 'e076: UniProtKB:O87871 has_cofactor CHEBI:29105'
  outcome: supported
  summary: The primary AAS statement and Methods support two Zn per recombinant Strep-tagged
    WT subunit under Zn-supplemented expression. This is not historical native occupancy,
    a full crystallographic construct identity assertion, or physiological CoA substrate
    activity.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-edge-matrix
  - ev-locators
  - ev-scientific-assessment
  - source-25
  details: 'Actual field mechanistic_edges[75]. Prior independently authored scientific
    assessment reused on exact unchanged complete edge; current full YAML reading
    and fresh source replay confirm retained limits. Complete endpoint qualifiers,
    coefficients and all 3 evidence entries are preserved in the exact current-edge
    binding. Exact source locators: PMID:35557486 HTML (//p)[111]; PMID:35557486 HTML
    (//p)[205]; PMID:35557486 HTML (//p)[204].'
  dimensions:
  - name: evidence-tier
    value: inspected primary publication text
    definition: Tier of the exact statements supporting this edge; source annotation,
      mutant/operon evidence, sequence identity and purified assays are not conflated.
    evidence_ids:
    - source-25
  - name: source-object
    value: PMID:35557486
    definition: Exact native/publication identifiers whose original source hashes
      are independently bound.
    evidence_ids:
    - source-25
  - name: taxon-condition-component-role
    value: 'subject: experimental_construct: C-terminal Strep-tagged recombinant WT
      ThaADH, produced in Zn-supplemented E. coli BL21(DE3); distinct from crystal
      constructs and historical native preparation.'
    definition: Actual maintained endpoint qualifications retained without broadening
      strain, construct or condition.
    evidence_ids:
    - source-25
- assessment_id: a-final-bindings
  area: provenance
  topic: Final archives, report, history and terminal gate attribution
  outcome: supported
  summary: Complete preparation and gate evidence are retained through verified maintained
    owners. All scientific/core/generated inputs remain exact. Only the post-gate
    report paragraph changes among the 29,503 tested files, and its new dated status
    is accurate. The fifth native history and two verification archives were read
    and independently bound; root-run gates are not relabeled as this reviewer’s execution.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-final-gate-archive
  - ev-complete-preparation
  - ev-final-report
  - ev-final-history
  - ev-gate-inputs
  - ev-terminal-receipts
  details: 'Full gate result: 5489 passed, three empty command-frontmatter parametrizations
    skipped, seven dependency warnings. The full logs and historical pre-gate wrapper
    failure remain retained. Canonical save/check and later staged/publication gates
    belong to root and are not claimed here.'
findings: []
actions: []
limitations:
- The seven-step native route is source-defined formal chemistry; the record does
  not experimentally close every step in every listed organism.
- Generic ferredoxin cluster-unit coefficient two is not whole-polypeptide stoichiometry,
  a universal donor identity or intrinsic BCR cluster occupancy. Retired Rhea 19100
  is not automatically replaced.
- Oah constituent equations and CPD-15900 cancellation do not demonstrate separately
  assayed catalysts or a free accumulated intermediate; native reversible metadata
  does not establish physiological reverse flux.
- Step 6 remains putative without a catalyst; predicted individual PimB and operon-level
  evidence do not establish a lower-route enzyme assay. No lower-route Thauera enzyme
  is asserted.
- Strain, gene-annotation conflict, tag/construct, expression host and apparent assembly
  qualifiers remain material. Modern Had preparation zinc measurements are not universal
  native occupancy.
- 'Selected historical full texts and supplements remain unavailable or unread: Oah
  PMID 10406950 and 18312395 full original text/GST ambiguity, PMID 9490071 and 10903310
  abstract-level scope, the 1998 hydratase erratum, Had Table S2, and unseen recombinant
  insert/tag details. A BoxB bibliography lead is not the cited BCR full paper.'
- iModulonDB applicability uses a dated same-day complete dataset response with exact
  offline adapter replay, not a fresh live query. No matching source-taxon dataset
  in that finite listing is not negative biology.
- The prior independently authored whole-design scientific assessment is reused through
  exact complete object/edge bindings, current full maintained YAML reading and fresh
  bounded source checks. This is not another full human reading of every upstream
  paper or source archive.
- Finite captured merged-baseline duplicate/source-follow evidence does not establish
  global absence. Earlier provenance corrections retain their exact prior findings
  and accepted successors; this review does not close GitHub issues.
- Authority implementation, broad retention/Git provenance and root browser/render/KGX
  checks retain their separate authorship and scope. Hash/schema/serializer success
  alone is not scientific acceptance.
- The completed root production run precedes only the explicitly read final report
  paragraph, fifth native history and verification archive additions. Current rehash
  preserves every other tested file. Later native save/check, final documentation/history
  checks, actual staged-index checks, PR publication and verified merge remain separate
  root-owned observations.
- The three skipped tests are empty command-frontmatter parametrizations, and seven
  retained dependency deprecation warnings do not represent skipped pathway scientific
  checks. Historical console/DNS/helper and pre-gate wrapper failures remain recorded
  separately from later successful checks.
- Exploratory overbroad displays of input inventories were truncated and are not counted
  as full human source readings. Complete binary inventories were parsed and independently
  verified; complete target YAML, final report, test log, relevant prose and bounded
  original scientific contexts were read separately.
notes:
- Independent scientific review under the native review-yaml-record skill and CLAW-governed
  contract. Initial maintained inspect preceded assessment; authority formatting changes
  and final report additions received explicit successor inspections. Prior preparation
  and source packages remain immutable. All 76 positive edge assessments cite their
  exact original source objects, current locators and endpoint qualifications. Empty
  findings does not close earlier provenance issues or imply fleet-wide scientific
  approval. No maintained write, Git/GitHub mutation, runtime repair, fresh network
  query or duplicated full gate was performed by this reviewer.
- The first external draft failed shape validation because notes was serialized as
  a string rather than the schema list. That exact draft, command receipt and stderr
  remain retained. This successor changes only that shape, replaces an explicitly
  abbreviated inspect command with its exact recorded argv, and uses a new actual
  finish timestamp/review ID; scientific content and all maintained inputs are unchanged.
source:
  git_revision: dd780ef273323efd638eacd63625963062e0b105
  state: working_tree
  inputs:
  - path: .claude/skills/add-pathway/SKILL.md
    sha256: f0d394f29cad1a1cd6a004abceb5f59f8e567d6b885cd6c4ff07c629c4d6db7a
    role: context
  - path: .claude/skills/review-yaml-record/SKILL.md
    sha256: 6a57ac6065171e35499578522a38c576e7bf7b6213286487d6cc0947fc477f3f
    role: context
  - path: CLAUDE.md
    sha256: c067d99547f9e9e9a6edb892d71126b6765239348d0021b907f3102907a4cf00
    role: context
  - path: conf/identifier_sources.json
    sha256: 1341614e5e3f32aacbb8944c072f2c0e32f7c7a96dd3a1b2c81c0b5d7b6808c3
    role: context
  - path: conf/record_review.yaml
    sha256: a2d6578719a7d080eadc9520695ea7203618b0a7b274ee78fb25dbc17794876b
    role: context
  - path: data/identifier_authorities/ontology.json
    sha256: e501a8e36a50b033a38c0c9fdae10ebc723b47900ca003c5c6e8fc97da660400
    role: context
  - path: data/identifier_authorities/sources.json
    sha256: 3e46be7991c9b77597eb078a40e7bd388d102dcca9adadea8152faae14d93c62
    role: context
  - path: data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml
    sha256: e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9
    role: target
  - path: docs/CAUSAL_GRAPHS.md
    sha256: 4f3f46d1f4b8ebafa9b2d04d9700510df18b6ec6f881856fda521879f494d153
    role: context
  - path: docs/CURATION.md
    sha256: 408f7c7705b4e6d667b513920e4c39612162d549e0c2666d85bfd53b2c2687f7
    role: context
  - path: docs/HARMONIZATION.md
    sha256: 072884773d626ea909bd1e4f275901f0a6053f660d5e68a294ee54149b6496b0
    role: context
  - path: docs/IDENTIFIERS.md
    sha256: 4f8cdd6b715730f8aff7008b37a7eb4ecc9ff760ffc49a26f874ab464757ad42
    role: context
  - path: docs/record-review-profile.md
    sha256: f3f00eebb7841e9d5ac891271e269f45e926995e16856b8e9a885436570c7819
    role: context
  - path: docs/record-reviews.md
    sha256: 452a19ab688276747b7c4308523a14d4d99c1c39ef6909ae8a90b85b7a9b3e9b
    role: context
  - path: history/infrastructure/benzoyl-authority-profiles/2026-10-15T164014Z-Codex-4285be.yaml
    sha256: 8f0d80bdd9a070b5b792cc8c7699a64a09d3a66312143d2a4a282fa55d9c0d7e
    role: context
  - path: history/other/benzoyl-coa-anaerobic-research/2026-10-15T170721Z-Codex-55569c.yaml
    sha256: b286cdd15429087fd1c9207ef1db528e08369335eb0021a2267cb65bd3f5110f
    role: context
  - path: history/other/benzoyl-coa-anaerobic-research/2026-10-15T172500Z-Codex-6ffbf7.yaml
    sha256: 6a7debba7aa3a41d37671f694cf87b68177c97f3dd7d6b5602a13f6a13c653ed
    role: context
  - path: history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml
    sha256: c481e4bc95284a17d0059f90d1a6648a32c3b6ac1a9b3144b92e02c456d18f7d
    role: context
  - path: history/records/benzoyl-coa-degradation-ii-anaerobic/2026-10-15T164011Z-Codex-82ce66.yaml
    sha256: befef7f955704d8839d3ea45963bde16f2520346894862be9132e3ce9e097f90
    role: context
  - path: justfile
    sha256: 6d3df7c8fb17835c316a5f37a59c0ff7e61541bbb0781d4dd62ee6ec5fce7df2
    role: context
  - path: pages/browse.html
    sha256: f5d2fae8591075a444fdd478b82c60d1cce8df96c58aec4c57edaee41f610361
    role: context
  - path: pages/downloads/edges.tsv
    sha256: 55e0530c196ded6f0305ea823f05e55785c0788a47b3dd50a9bf3ba2b49b999f
    role: context
  - path: pages/downloads/manifest.json
    sha256: 16e59b5350023206dbbadc4dd1d174d06e9475f1a6bc3f2b6acb4fb78d0bf07f
    role: context
  - path: pages/downloads/nodes.tsv
    sha256: 4956148879a8a5a66bd2e70656df0cf2dbc74abf1b9f8e9b1243a179ae39304d
    role: context
  - path: pages/index.html
    sha256: a7870eceddd059e44b23cf7142e8ef47741641e8ee61b217c14461f2a7e5c8a8
    role: context
  - path: pages/pathway_index.json
    sha256: bf15b9c7302a41c5adfe2aa72ab586a11cd39df3276fecb61fc77ce6b5d1bf05
    role: context
  - path: pages/records/MetaCyc_CENTBENZCOA-PWY.html
    sha256: 6789b560b92bb439230cccd31a4d6493633241edc944bb3effb3e990cfc659d4
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/README.md
    sha256: cb8ad4faf2e342c3b3947a156d6dfeb8e51b310b15efe23e11a50d5657784980
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/README.md
    sha256: e061640b459645fbb23aa9a927c4f1976cb4e51f898fa28415ecc3f497ecdcaa
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/artifact-manifest.json
    sha256: 424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/content-map.json
    sha256: 9a793f865aa7c683e3b756907378afa7120cf6feeb2603738f37817b8b9d53d5
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/decode_retained.py
    sha256: 7c0ffd8a73a478c4c9a9b408fa9dc59268e6a08135a99fd2871ff523808807fe
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/existing-owner-verification.json
    sha256: 6c6da95f7b4ef1d8863789334cb0a384b2e637a1a61c2104c9186a59633c2130
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/explicit-package-compact-audit.json
    sha256: a89161b6171c10c951d63fc651ff733096b156bbe2cd1fc015d0bf49c5c14c2e
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/logical-originals.json
    sha256: 81e802013929292b032ebd118d02a49af97f6b101e3f068b6c5762de8fe97202
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/merged-baseline-binding.json
    sha256: d27cba06baa62dc01058f8ee5681ad01ec9570e387a51ab4fc087e58cbe3a36d
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/authority-implementation/source-map.json
    sha256: 9e29c82f9af2ad48c7d163163cc8370b3248fd2183b2c3b67534c72bc4b40feb
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/authority/source-map.json
    sha256: 6d93bf1a2063af9e6cb87757abfda4fd2a8f6f0440b007974cc294f0964c3b8b
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/chemistry/source-map.json
    sha256: 2b21b58accfd2a1b378969faf2a8cc9bcf7758bddb06ffa3f78f21e04ed97853
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/design/source-map.json
    sha256: 4bb2209b5f0619019063aedc0e4fb94892341dc9ce8373e6843ab09da1a5a65d
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/discovery/source-map.json
    sha256: a9e0460556b43487327d3980341883710ca7483d91d0065d60d399d1143ebe9c
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-authority-review/source-map.json
    sha256: a73e2c197042e57e6b4ab89f40cfc71e01c6920841a56c984ff3963dacad4940
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-chemistry-review/source-map.json
    sha256: 4cba98777c33ac4d02f99892b44966cc8c11203eb69e4c00c48cc5ee14f542ac
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-design-review/source-map.json
    sha256: 5b003021c7e66c35776a442dbb5173d0f88cfdd9cf6127afabc9cab15e94a73c
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-discovery-review/source-map.json
    sha256: 4ef4588dc3a230830f3751c2c40eafa1f7a50b90b3e87bac064cd4f396a83da6
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-merged-discovery-review/source-map.json
    sha256: 005c29a4b06284429269fa67da3cfa29d1191053c3383761fe61598fad0a7cc3
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-merged-successor-review/source-map.json
    sha256: 2238635de8fab92f61db1501805e3bec4e9e1883eea02880748bcbaddc0fcf59
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-native-review/source-map.json
    sha256: 22e07ac2a55bc22fb0e2a1cfbc8776d646a364266197b9200d8870c8542f9d52
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-primary-review/source-map.json
    sha256: 5a8e1153a37d718f211c19f96fe596d03453faf07479dbc96ac56f5748ff5724
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/merged-discovery-successor/source-map.json
    sha256: 184c4a9f7809840949b110feb59d81fa1480e2c704548f2efc2c5c4b437e9fc3
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/merged-discovery/source-map.json
    sha256: 4f03acf532594d67ab887b531a656df918933676c4f6074491dcc827b58c9ce6
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/native/source-map.json
    sha256: e8da0d81b99b42b04d27ba66e2db3a4e3b63e381a5ba9a993130dd937f865356
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/primary/source-map.json
    sha256: 4f2e7f6bbf7a6b5590523c0b890bfcfbd7abbc19afe4794a268ba1b09ef9e2e1
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/plan_promotion.py
    sha256: c5def95236b65786be4d71a830248a5b903cac6ccef747ab4d1e6dad77e219e9
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/correction.json
    sha256: abda74ffe26515d08790dd2faa4aee77d0128685abf0f22b37d704b7e3924b5c
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/generator-replay-proof.json
    sha256: f67e47bdb1e9cae7c1ca8f73627c4d96df06caf1c4ce325bb0985e3131d72da4
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/predecessor-map.json
    sha256: 1b4d83b8f5f878efeb3a48274905ae0c7528a7da422f1eed1e70e3bd0d1ae75e
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/prepare_retention_corrected.py.txt
    sha256: d6b34f1141aeac6745289a2bebc5487973c7b604bd6024f585f2f2895f695d76
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/reconstruct_predecessor.py
    sha256: 71fc1a367bc418e3fdd9730e688734c797632f1b37ac7337bffe914db9b503b1
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/source-package-inventory.json
    sha256: 2ac23170ae253980039e6c039beb8cd717e2f8c8fc5479733130a8245f6454b0
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/source-specification.json
    sha256: 1e03d4a9c5cb408c7169c501f7e9d140196e2290cb4ceefe8ac1713faa4bfffc
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/verified-compact-pairs.json
    sha256: 6a53dd595aac851dc2ae462c09a610a0bf13be3c24d1854e118cf224cc4b17fc
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/verify_compact.py
    sha256: 0420dad87fca3442282d3eca7750b1e368145a3b867a76f5a81c8371193e63aa
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/evidence-retention/verify_inherited_provenance.py
    sha256: 4793c9cf1016caf2083876f089a3656161e2c6c91df7196dc11abc198d3d8bf6
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/final-gates/README.md
    sha256: c1b34b7102931226c4434f9a309d35c9f1ec020b42553dfca98f0063174ae449
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/final-gates/artifact-manifest.json
    sha256: 1c2da8332249f9a62c21c36ffa97181292de89afc43894a0d76a7081ba6eedbb
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
    sha256: 1c84c6bb66edc629f400878a90ec627e11692cb516f91a050247a5e4dc07bc84
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/final-gates/source-file-manifest.json
    sha256: 85aae7a83cf8468206008f0f8b9ced182b721fc7378e28970f236d4552abce2d
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/README.md
    sha256: 2dcb03cc92282a0452eed24ab1933c40eacf3b08550040d853bd4136964bd5f0
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/artifact-manifest.json
    sha256: 80bdf3c111d572076d2f7faa084c77f09d3edd339b397a12eb16a89bc5bd5db1
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
    sha256: 6d74786f8abcdbc5706a62f13220f2fbbbd56820e968cddf755dbc3b62e59a0e
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/source-file-manifest.json
    sha256: 6b32a52ead40dec6442e0d0387a41b57bd689feb94f39b21d7f45d265f73b421
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/retention/README.md
    sha256: bfbf371d2acbb3d2a2c7c4129488dc84eeb2caf94449579e545962aa3e55e451
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/retention/artifact-manifest.json
    sha256: d66263131dfd0c5f802fc73e3665f6663e461f7822c75b9df84ad8dc97bc6b61
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/retention/files.tar.gz
    sha256: 2c06aefdd4fd268d0022afadae0e923d8fab20eb002724d673455d1692a808af
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/retention/source-file-manifest.json
    sha256: 2608f3ef459cda26c191cfacd3bc7a4db9b4e161944a49607e1f423b82e63517
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/root-integration/README.md
    sha256: 61eac358eeb48d5c307d75bb1b1f023d99594e0006d339be1e889d9bd9e937f8
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/root-integration/artifact-manifest.json
    sha256: 90302cafec273afaa74f2d35b8550423492d50c08e28fe05c7766bc71110a93f
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/root-integration/files.tar.gz
    sha256: 212b949aa4389e4ebe6f6416b8a424f313bbb7017e21893406229240dc0c57d9
    role: context
  - path: research/pathway_additions/2026-10-15-next-266/verification/root-integration/source-file-manifest.json
    sha256: 844deaacb02c1d61def862cdaf63eb50b877c3fd98c3babae46ac789880690a8
    role: context
  - path: schema/record_review.yaml
    sha256: 229baf9b69118a1fe318e4c31085c0820e4e3d1365e7b04d6ace451b7c35f9bb
    role: context
  - path: scripts/build_source_identifier_snapshot.py
    sha256: 3df369e92b52ec21a07fd2a284467cc40c9e53314c8e0ca131b73caa9df47363
    role: context
  - path: scripts/record_review.py
    sha256: 95a4ec41e38ec47ba3578e76838c46a0adbf47e49ad3636524735d08cfcb1c4d
    role: context
  - path: scripts/validate_id_label_correspondence.py
    sha256: b5ff41bb52d24f5d7819fb12769e216440f75ec3fb3df3e3cb2c5082fffb40e0
    role: context
  - path: src/pathwaymech/biocyc_benzoyl.py
    sha256: a5cc54963510351113c2470587f0bf270c49e403e261f681837d7281c3862367
    role: context
  - path: src/pathwaymech/graph_view.py
    sha256: 45bbedd4459f21d4189e3eeb35504ff71ba664e975f4cdde7250a61e9ae3215b
    role: context
  - path: src/pathwaymech/identifiers.py
    sha256: 904c961666a639cc53ce33b031b89d442f827224e648e3aeffd9d0b2a50011ab
    role: context
  - path: src/pathwaymech/kgx.py
    sha256: 4419ba74ee3949ac84a1ca1bb3cde3bf3ce73a5c975ebeab81ec1ef09dcdf3f9
    role: context
  - path: src/pathwaymech/schema.py
    sha256: bd99c1e6ca1f6eec5c82c58aa1ae3f43f696d30be66fbe0977dcace81292e0b8
    role: context
  - path: src/pathwaymech/schema/pathwaymech.yaml
    sha256: c66be7d0ae830e5041608eb6b2ce9755c601ed596ec9df5fb3567d41b202478b
    role: context
  - path: tests/fixtures/benzoyl_authority/1.3.99.15-RXN.xml
    sha256: 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f
    role: context
  - path: tests/fixtures/benzoyl_authority/CPLX-1341.xml
    sha256: c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf
    role: context
  - path: tests/fixtures/benzoyl_authority/OAHTHAUERA-RXN.xml
    sha256: d0f778f36235b004616c7414da4d894a5744fc6cb792e653a613e681c71b748a
    role: context
  - path: tests/fixtures/benzoyl_authority/Oxidized-ferredoxins.xml
    sha256: fc1a3ef82b82913d0c408cabf3e7ca04e81757842d7dcf88cfbb22d3589ba4e0
    role: context
  - path: tests/fixtures/benzoyl_authority/README.md
    sha256: 8bedae9fd4bd466bbddb8e3c04d95f6600c0ff9f607ff3b3029cf4af0a2692c2
    role: context
  - path: tests/fixtures/benzoyl_authority/RXN-15012.xml
    sha256: 5134bb4c1a1fcaba2036bdf9969b15d0e3bfd02b1605479dbc7336a38d6884b1
    role: context
  - path: tests/fixtures/benzoyl_authority/RXN-15013.xml
    sha256: fcee22c95121a359d1b59a70a7d30ec76fa32e806211e079a3433e67fa8115d3
    role: context
  - path: tests/fixtures/benzoyl_authority/RXN-8032.xml
    sha256: e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a
    role: context
  - path: tests/fixtures/benzoyl_authority/Reduced-ferredoxins.xml
    sha256: 8a2567b37766a24b0cc8c184ba662fd6eea555322207753484744c6e6713ed71
    role: context
  - path: tests/fixtures/benzoyl_authority/acquisition.json
    sha256: abbd3da561afd89d83c08911e8f43e2f9e6a1e8d880164e4afe7ca7df93b6a3c
    role: context
  - path: tests/fixtures/benzoyl_authority/manifest.json
    sha256: 1b2e516a944e3221c2a71e702077eaa0f9192e4f653a1d451806e7b11c6c2b1a
    role: context
  - path: tests/test_benzoyl_authority.py
    sha256: 36e43195e4c4f5b55c54c36ba083de390f5ceb52459da0cfa20ca964b7213c5e
    role: context
  - path: tests/test_skill_frontmatter.py
    sha256: a1252211fbdec1a4a36f8138b9a60617d69e9fa6c5c3f589d15846a783d77569
    role: context
checks:
- check_id: check-gate-1
  name: just render-pages
  status: passed
  required: true
  summary: All 263 pathway pages rendered, 102.14 seconds. Root-run full corpus result,
    independently bound.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  command: just render-pages
  exit_code: 0
  evidence_ids:
  - ev-gate-1
  - ev-gate-inputs
  - ev-terminal-receipts
  scope_note: Exact root run against 29,503 hidden/ignored-inclusive declared inputs.
    All remained unchanged during the run; current rehash differs only in the separately
    read dated report update. New verification archives and fifth native history were
    added after the run and are not retroactively called tested by it.
- check_id: check-gate-2
  name: just validate
  status: passed
  required: true
  summary: Validated 263 records, 20,455 evidence blocks and 493 histories; closed
    schema, identifiers and label policies, source/docs contracts and page currentness
    passed, 195.41 seconds. Root-run full corpus result, independently bound.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  command: just validate
  exit_code: 0
  evidence_ids:
  - ev-gate-2
  - ev-gate-inputs
  - ev-terminal-receipts
  scope_note: Exact root run against 29,503 hidden/ignored-inclusive declared inputs.
    All remained unchanged during the run; current rehash differs only in the separately
    read dated report update. New verification archives and fifth native history were
    added after the run and are not retroactively called tested by it.
- check_id: check-gate-3
  name: just test
  status: passed
  required: true
  summary: 5489 passed, 3 skipped, 7 warnings; pytest 969.95 seconds, wrapper 972.82
    seconds. Three empty command-frontmatter parametrizations are explained by the
    unchanged test source and hidden/ignored-inclusive directory walk. Seven warnings
    are retained dependency deprecations. Root-run full corpus result, independently
    bound.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  command: just test
  exit_code: 0
  evidence_ids:
  - ev-gate-3
  - ev-gate-inputs
  - ev-terminal-receipts
  scope_note: Exact root run against 29,503 hidden/ignored-inclusive declared inputs.
    All remained unchanged during the run; current rehash differs only in the separately
    read dated report update. New verification archives and fifth native history were
    added after the run and are not retroactively called tested by it.
- check_id: check-gate-4
  name: just lint
  status: passed
  required: true
  summary: Ruff reported all checks passed, 0.41 seconds. Root-run full corpus result,
    independently bound.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  command: just lint
  exit_code: 0
  evidence_ids:
  - ev-gate-4
  - ev-gate-inputs
  - ev-terminal-receipts
  scope_note: Exact root run against 29,503 hidden/ignored-inclusive declared inputs.
    All remained unchanged during the run; current rehash differs only in the separately
    read dated report update. New verification archives and fifth native history were
    added after the run and are not retroactively called tested by it.
- check_id: check-gate-5
  name: git diff --check
  status: passed
  required: true
  summary: Working-tree whitespace check returned zero with empty log, 0.66 seconds;
    this does not assert a later staged-index check. Root-run full corpus result,
    independently bound.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  command: git diff --check
  exit_code: 0
  evidence_ids:
  - ev-gate-5
  - ev-gate-inputs
  - ev-terminal-receipts
  scope_note: Exact root run against 29,503 hidden/ignored-inclusive declared inputs.
    All remained unchanged during the run; current rehash differs only in the separately
    read dated report update. New verification archives and fifth native history were
    added after the run and are not retroactively called tested by it.
- check_id: check-whole-science
  name: Whole maintained record scientific assessment
  status: passed
  required: true
  summary: Complete actual YAML and all 76 edges assessed. All 56 named identities,
    25 exact source originals, 117 evidence locators, four quotations, seven selected
    steps and six joins retain their source-specific limits. No new actionable scientific
    defect.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-current-record
  - ev-scientific-assessment
  - ev-edge-matrix
  - ev-identities
  - ev-references
  - ev-locators
- check_id: check-independent-replay
  name: Independent exact source and route replay
  status: passed
  required: true
  summary: All selected equations, coefficients, directions, protein/CDS bindings,
    activity dispositions and construct/composition limits replay successfully; interpretation
    remains separate from deterministic correspondence.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-replay
  - ev-route
  - ev-locators
  - ev-retained-sources
- check_id: check-final-inspection
  name: Governed final input inspect and explicit changed-input assessment
  status: passed
  required: true
  summary: Fresh native inspect succeeds with 103 inputs. Of 93 prior inputs, 92 are
    unchanged and the final report is the sole explicitly read change. Ten added inputs
    include eight archive controls/payloads, fifth native history and the test source
    used to assess skips.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-current-record
  - ev-final-report
  - ev-final-history
  - ev-final-gate-archive
  - ev-complete-preparation
  command: /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B scripts/record_review.py
    inspect --targets /private/tmp/pathwaymech-next-266-final-scientific-review/finalization/targets.yaml
    --input .claude/skills/add-pathway/SKILL.md --input .claude/skills/review-yaml-record/SKILL.md
    --input CLAUDE.md --input conf/identifier_sources.json --input conf/record_review.yaml
    --input data/identifier_authorities/ontology.json --input data/identifier_authorities/sources.json
    --input docs/CAUSAL_GRAPHS.md --input docs/CURATION.md --input docs/HARMONIZATION.md
    --input docs/IDENTIFIERS.md --input docs/record-review-profile.md --input docs/record-reviews.md
    --input history/infrastructure/benzoyl-authority-profiles/2026-10-15T164014Z-Codex-4285be.yaml
    --input history/other/benzoyl-coa-anaerobic-research/2026-10-15T170721Z-Codex-55569c.yaml
    --input history/other/benzoyl-coa-anaerobic-research/2026-10-15T172500Z-Codex-6ffbf7.yaml
    --input history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml
    --input history/records/benzoyl-coa-degradation-ii-anaerobic/2026-10-15T164011Z-Codex-82ce66.yaml
    --input justfile --input pages/browse.html --input pages/downloads/edges.tsv --input
    pages/downloads/manifest.json --input pages/downloads/nodes.tsv --input pages/index.html
    --input pages/pathway_index.json --input pages/records/MetaCyc_CENTBENZCOA-PWY.html
    --input research/pathway_additions/2026-10-15-next-266/README.md --input research/pathway_additions/2026-10-15-next-266/evidence-retention/README.md
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/artifact-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/content-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/decode_retained.py
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/existing-owner-verification.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/explicit-package-compact-audit.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/logical-originals.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/merged-baseline-binding.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/authority-implementation/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/authority/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/chemistry/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/design/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/discovery/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-authority-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-chemistry-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-design-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-discovery-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-merged-discovery-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-merged-successor-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-native-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/independent-primary-review/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/merged-discovery-successor/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/merged-discovery/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/native/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/packages/primary/source-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/plan_promotion.py
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/correction.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/generator-replay-proof.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/predecessor-map.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/provenance-successor/prepare_retention_corrected.py.txt
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/reconstruct_predecessor.py
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/source-package-inventory.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/source-specification.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/verified-compact-pairs.json
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/verify_compact.py
    --input research/pathway_additions/2026-10-15-next-266/evidence-retention/verify_inherited_provenance.py
    --input research/pathway_additions/2026-10-15-next-266/verification/final-gates/README.md
    --input research/pathway_additions/2026-10-15-next-266/verification/final-gates/artifact-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
    --input research/pathway_additions/2026-10-15-next-266/verification/final-gates/source-file-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/README.md
    --input research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/artifact-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
    --input research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/source-file-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/retention/README.md
    --input research/pathway_additions/2026-10-15-next-266/verification/retention/artifact-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/retention/files.tar.gz
    --input research/pathway_additions/2026-10-15-next-266/verification/retention/source-file-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/root-integration/README.md
    --input research/pathway_additions/2026-10-15-next-266/verification/root-integration/artifact-manifest.json
    --input research/pathway_additions/2026-10-15-next-266/verification/root-integration/files.tar.gz
    --input research/pathway_additions/2026-10-15-next-266/verification/root-integration/source-file-manifest.json
    --input schema/record_review.yaml --input scripts/build_source_identifier_snapshot.py
    --input scripts/record_review.py --input scripts/validate_id_label_correspondence.py
    --input src/pathwaymech/biocyc_benzoyl.py --input src/pathwaymech/graph_view.py
    --input src/pathwaymech/identifiers.py --input src/pathwaymech/kgx.py --input
    src/pathwaymech/schema.py --input src/pathwaymech/schema/pathwaymech.yaml --input
    tests/fixtures/benzoyl_authority/1.3.99.15-RXN.xml --input tests/fixtures/benzoyl_authority/CPLX-1341.xml
    --input tests/fixtures/benzoyl_authority/OAHTHAUERA-RXN.xml --input tests/fixtures/benzoyl_authority/Oxidized-ferredoxins.xml
    --input tests/fixtures/benzoyl_authority/README.md --input tests/fixtures/benzoyl_authority/RXN-15012.xml
    --input tests/fixtures/benzoyl_authority/RXN-15013.xml --input tests/fixtures/benzoyl_authority/RXN-8032.xml
    --input tests/fixtures/benzoyl_authority/Reduced-ferredoxins.xml --input tests/fixtures/benzoyl_authority/acquisition.json
    --input tests/fixtures/benzoyl_authority/manifest.json --input tests/test_benzoyl_authority.py
    --input tests/test_skill_frontmatter.py
  exit_code: 0
  scope_note: Exact actual argv is retained here and in finalization/inspect-receipt.json;
    the input proof confirms all 103 supplied target/context bindings.
- check_id: check-actual-retention
  name: Complete final archive and scientific owner binding
  status: passed
  required: true
  summary: All 243 new archive members match their originals; all 131 scientific preparation
    files remain immutable. All 25 source originals freshly recovered from actual
    maintained storage. Earlier complete retained payload and selected 421-occurrence
    checks remain explicitly bound.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-final-gate-archive
  - ev-complete-preparation
  - ev-retained-sources
  - ev-portable-retention
- check_id: check-imodulon-offline
  name: Exact shared adapter response reuse
  status: passed
  required: false
  summary: Unmodified same-day adapter replay reproduces complete 20-organism/28-dataset
    listing; bounded applicability assessed without network or environment change.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-imodulon
  - ev-imodulon-original
- check_id: check-imodulon-search
  name: Source-taxon dataset search and hit summaries
  status: not_applicable
  required: false
  summary: No matching source-taxon dataset in the complete dated listing. E. coli
    is the expression host; module membership is not route catalysis evidence.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-imodulon
  - ev-imodulon-original
- check_id: check-historical-reference-helper
  name: Historical initial reference helper attempt
  status: failed
  required: false
  summary: Preserved failed public-link/mirror-URL equality assumption, corrected
    in a separate successful helper; no scientific record defect.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-initial-helper-failure
  - ev-references
  exit_code: 1
  scope_note: Historical non-gating reviewer operation, not an unresolved required
    check.
- check_id: check-historical-console
  name: Historical iModulon console attempt
  status: failed
  required: false
  summary: Preserved same-day console dependency failure; later dated successful response
    and offline adapter replay are separate evidence.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-console-failure
  - ev-imodulon
  command: /private/tmp/pathwaymech-next-263-verified-venv/bin/python -B /Users/marcin/Documents/VIMSS/ontology/KG-Hub/KG-Microbe/culturebotai-claw/.venv/bin/kg-microbe-sources
    imodulondb --timeout 30 datasets
  exit_code: 1
  scope_note: Reused root/source acquisition observation from 13:09 UTC; not rerun
    by this maintained review.
- check_id: check-historical-adapter
  name: Historical direct iModulon adapter transport
  status: unavailable
  required: false
  summary: Preserved DNS transport URLError from the earlier same-day acquisition;
    exact response and applicability subsequently obtained without claiming this attempt
    succeeded.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-direct-adapter-failure
  - ev-imodulon
- check_id: check-historical-root-wrapper
  name: Historical root wrapper prerequisite race
  status: failed
  required: false
  summary: Wrapper exited before any gate command ran; subsequent unchanged wrapper
    completed all five gates successfully.
  target_ids:
  - MetaCyc:CENTBENZCOA-PWY
  evidence_ids:
  - ev-root-prerequisite-failure
  - ev-terminal-receipts
  exit_code: 1
  scope_note: Root scheduling failure; no source/test failure and no overwritten result.
evidence:
- evidence_id: ev-scientific-assessment
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/ASSESSMENT.preparation.md
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Independent whole maintained-record assessment; all 76 edges, 56 named
    identities, 25 references, 117 evidence assertions and explicit source limits.
    Prior whole-design judgment is reused through exact complete-edge equality, with
    current full YAML reading and fresh bounded original checks. This retained reviewer
    ledger is distinct from the original database/publication evidence, whose exact
    native objects and source hashes are separately bound.
  snapshot_sha256: 85aa82a52c9f20329ffd520175d259fb8ad7485e7e740889941f1a1e58db9538
- evidence_id: ev-edge-matrix
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/maintained-edge-assessments.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: One independent disposition for each of the 76 actual maintained edges.
    All complete edge objects strictly equal the previously independently reviewed
    design; fresh locator checks preserve claim and qualifier scope. This retained
    reviewer ledger is distinct from the original database/publication evidence, whose
    exact native objects and source hashes are separately bound.
  snapshot_sha256: db35db1c0ef4d58b9da02e663eeee44980d2aff43eb5d8ab1fd75324ad937b91
- evidence_id: ev-route
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/route-replay.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All seven selected memberships, 32 material occurrences, 19 frames, six
    shared-material joins and auxiliary eighth reaction; exact native directions,
    coefficients and Oah constituent sum. Deterministic replay supports correspondence,
    not experimental proof. This retained reviewer ledger is distinct from the original
    database/publication evidence, whose exact native objects and source hashes are
    separately bound.
  snapshot_sha256: 824a2d1153eb360f3c11f6dddcc84f7b788154e4c078ccdc3e59774180d82a7b
- evidence_id: ev-locators
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/evidence-locator-replay.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 117 evidence locators and all four exact short quotations resolve to
    original source bodies with the stated scope; no database assertion relabeled
    a primary-paper quote. This retained reviewer ledger is distinct from the original
    database/publication evidence, whose exact native objects and source hashes are
    separately bound.
  snapshot_sha256: 15aa6dc3e06ac46e83cacdab36622c28767533a208d2afb11880805fcd49e00f
- evidence_id: ev-identities
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/named-identity-assessment.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 56 named record, reaction, participant and taxon identities checked
    against exact issuing originals and selected maintained authority terms. Names,
    native types and stable accession scope are separately assessed from biochemical
    function. This retained reviewer ledger is distinct from the original database/publication
    evidence, whose exact native objects and source hashes are separately bound.
  snapshot_sha256: d4d694e95701238f072efcd097f3b2dcf40cb69b463e54ed51573500a7ed2e2e
- evidence_id: ev-references
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/reference-original-assessment.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 25 native-object/publication references, exact source hashes and issuing
    identities. Human-facing BioCyc links designate the same object; retained hashes
    bind explicitly identified native XML rather than public HTML. This retained reviewer
    ledger is distinct from the original database/publication evidence, whose exact
    native objects and source hashes are separately bound.
  snapshot_sha256: aa57ee10c028680dc8cbcecfc6fededf91f73ad9454554967fd50d677832049f
- evidence_id: ev-replay
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/scientific-replay-execution-observation.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Actual successful reviewer replay observations, including 15 activity dispositions,
    21 protein/CDS bindings, 13 assembly components, 76 edges and 117 evidence assertions.
    This is not a replacement full-corpus gate. This retained reviewer ledger is distinct
    from the original database/publication evidence, whose exact native objects and
    source hashes are separately bound.
  snapshot_sha256: 89121b4ba2f181eaf57879607ff7c8bd807d8386d5dc674507250f2734529459
- evidence_id: ev-imodulon
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/imodulon-applicability-assessment.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Same-day dated complete public iModulon dataset listing and fresh offline
    unmodified adapter replay; 20 organisms and 28 datasets. No matching source-taxon
    dataset in that finite listing; E. coli is a heterologous expression host. Not
    a fresh live query or negative biology. This retained reviewer ledger is distinct
    from the original database/publication evidence, whose exact native objects and
    source hashes are separately bound.
  snapshot_sha256: b6ea49a62a2face465d6caee5670b65cee8e713c8dbb119079af084bc205600e
- evidence_id: ev-formatting
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/formatting-successor-independent-comparison.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Explicit old/new capture of three authority registry serializations; strict
    whole-JSON equality, original values and insertion-order prefixes retained; unchanged
    scientific YAML. No silent input hash refresh. This retained reviewer ledger is
    distinct from the original database/publication evidence, whose exact native objects
    and source hashes are separately bound.
  snapshot_sha256: f6c64145a70c33eb221dfd0cdb05fa0c4b62b244dbf982845129a4b668cbfb14
- evidence_id: ev-authority
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/separate-root-support-binding.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Separately authored independent authority implementation/projection acceptance
    bound to exact current implementation inputs; root-generated render/KGX/browser
    proofs retain root attribution and their limits. This retained reviewer ledger
    is distinct from the original database/publication evidence, whose exact native
    objects and source hashes are separately bound.
  snapshot_sha256: 8d2cb1ca86a0b839f1920499b0f425e09ad07770794ae0354f06e999d1d1710f
- evidence_id: ev-retention-assessment
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/retention-integration/ASSESSMENT.supplement.md
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Full current research report and ownership prose, four native histories
    and relevant root/independent retention receipts read. No new scientific or provenance
    defect; final canonical state remained explicitly pending. This retained reviewer
    ledger is distinct from the original database/publication evidence, whose exact
    native objects and source hashes are separately bound.
  snapshot_sha256: c6522772cd6ae8842697b94bcc772544a3a8b7be137c5f9c817ef65686d524b2
- evidence_id: ev-retained-sources
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/retention-integration/scientific-maintained-owner-bindings.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 3343 maintained payload files rehashed; 421 selected source occurrences
    (353 distinct contents) independently decoded and compared to originals, including
    complete design and all 25 record reference originals. Whole design remains strictly
    equal to maintained YAML. This retained reviewer ledger is distinct from the original
    database/publication evidence, whose exact native objects and source hashes are
    separately bound.
  snapshot_sha256: 50a3c25f5d62efafefd43559a40561d1168aac3e6567fe9024ea18e8104a5155
- evidence_id: ev-portable-retention
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/retention-integration/portable-verification-ownership.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 43 root-integration archive members plus 255 retention archive members
    and 3343 explicit shared maintained owners match originals; unique relative regular-file
    membership and exact stored bytes. This retained reviewer ledger is distinct from
    the original database/publication evidence, whose exact native objects and source
    hashes are separately bound.
  snapshot_sha256: d23cf1100aa1f474a5739f2d810d117e6990921879a49fca2afefee8ec46e9bf
- evidence_id: ev-history
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/retention-integration/root-execution-and-history-bindings.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Three root actual-copy physical/compact/provenance executions and four
    native history records are exactly bound. Actual native curation stage and review
    status are distinct. This retained reviewer ledger is distinct from the original
    database/publication evidence, whose exact native objects and source hashes are
    separately bound.
  snapshot_sha256: 00fe0978e9d5d86a9ecca5a433b6d1d68b8b00509465538681010a21e8da023c
- evidence_id: ev-prior-design-reuse
  kind: prior_review
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/prior-scientific-assessment-reuse.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Explicit exact binding to this reviewer’s original independent whole-design
    scientific assessment; no claim that hashing or serializer equality itself establishes
    biochemical truth. This retained reviewer ledger is distinct from the original
    database/publication evidence, whose exact native objects and source hashes are
    separately bound.
  snapshot_sha256: abb40b7f7a189cbe80f0e1fbfcc20ea7a32731509fb1b634055c1d59a532e483
- evidence_id: source-01
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/29/293bd88390943dcd0e8faad75a7bc3eb6375d54c434d8c923a243d5fd866f68d.gz
  locator: Original MetaCyc:1.3.99.15-RXN; content-map.json key 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f;
    gzip 293bd88390943dcd0e8faad75a7bc3eb6375d54c434d8c923a243d5fd866f68d → 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=1.3.99.15-RXN
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: 1.3.99.15-RXN. Complete original
    source hash and issuing identity verified. Native structured assertions retain
    exact XML object/slot locators and native type; this is not a quotation from a
    paper cited by the database.'
  snapshot_sha256: 898b952a5047011d8bca9b3f20e70af5aa12e5fbee2148bc3551deaae65fad9f
- evidence_id: source-02
  kind: database
  reference: research/pathway_additions/2026-10-15-next-265/evidence-retention/objects/03/03037688642aae1a5fec0fe44b3e9c3b90c8bf5d67e3a38866d8bc7bfda3333b.gz
  locator: Original MetaCyc:CENTBENZCOA-PWY; content-map.json key 6e7327287b9c3361cb4a6d85c6c8c268eaab294dfb1d1ea39bfcd3287e022e75;
    gzip 03037688642aae1a5fec0fe44b3e9c3b90c8bf5d67e3a38866d8bc7bfda3333b → 6e7327287b9c3361cb4a6d85c6c8c268eaab294dfb1d1ea39bfcd3287e022e75;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CENTBENZCOA-PWY
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Pathway: CENTBENZCOA-PWY. Complete original
    source hash and issuing identity verified. Native structured assertions retain
    exact XML object/slot locators and native type; this is not a quotation from a
    paper cited by the database.'
  snapshot_sha256: 6e7327287b9c3361cb4a6d85c6c8c268eaab294dfb1d1ea39bfcd3287e022e75
- evidence_id: source-03
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/34/34247622dd903f6b76600ece0d3ef58ff4169706b1ab12082e7fa23d27c8960f.gz
  locator: Original MetaCyc:4.2.1.100-RXN; content-map.json key 5daac95308148b39b603664c3db64a6a5abf39999e5eff134a27b147c461caa8;
    gzip 34247622dd903f6b76600ece0d3ef58ff4169706b1ab12082e7fa23d27c8960f → 5daac95308148b39b603664c3db64a6a5abf39999e5eff134a27b147c461caa8;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=4.2.1.100-RXN
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: 4.2.1.100-RXN. Complete original
    source hash and issuing identity verified. Native structured assertions retain
    exact XML object/slot locators and native type; this is not a quotation from a
    paper cited by the database.'
  snapshot_sha256: 5daac95308148b39b603664c3db64a6a5abf39999e5eff134a27b147c461caa8
- evidence_id: source-04
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/46/461f1dd8e4f428940f24a3b1d042372e339f1350c9ea1b87da03ff486eb486d6.gz
  locator: Original MetaCyc:HADTHAUERA-RXN; content-map.json key 9c77754858f6fcdd2ca928b66ff2dc6f809563b89532bf4557cb30b356acb231;
    gzip 461f1dd8e4f428940f24a3b1d042372e339f1350c9ea1b87da03ff486eb486d6 → 9c77754858f6fcdd2ca928b66ff2dc6f809563b89532bf4557cb30b356acb231;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=HADTHAUERA-RXN
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: HADTHAUERA-RXN. Complete original
    source hash and issuing identity verified. Native structured assertions retain
    exact XML object/slot locators and native type; this is not a quotation from a
    paper cited by the database.'
  snapshot_sha256: 9c77754858f6fcdd2ca928b66ff2dc6f809563b89532bf4557cb30b356acb231
- evidence_id: source-05
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/dd/dda53852dde6cf8756aa2978c6324d9adc53e2a3f1a69d1459c472281911b2d5.gz
  locator: Original MetaCyc:RXN-15012; content-map.json key 5134bb4c1a1fcaba2036bdf9969b15d0e3bfd02b1605479dbc7336a38d6884b1;
    gzip dda53852dde6cf8756aa2978c6324d9adc53e2a3f1a69d1459c472281911b2d5 → 5134bb4c1a1fcaba2036bdf9969b15d0e3bfd02b1605479dbc7336a38d6884b1;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=RXN-15012
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: RXN-15012. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: 5134bb4c1a1fcaba2036bdf9969b15d0e3bfd02b1605479dbc7336a38d6884b1
- evidence_id: source-06
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/33/338bcca037eeeb524772e0e36207cbedb0fffe82c6249e2713305796d9cd823f.gz
  locator: Original MetaCyc:RXN-15013; content-map.json key fcee22c95121a359d1b59a70a7d30ec76fa32e806211e079a3433e67fa8115d3;
    gzip 338bcca037eeeb524772e0e36207cbedb0fffe82c6249e2713305796d9cd823f → fcee22c95121a359d1b59a70a7d30ec76fa32e806211e079a3433e67fa8115d3;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=RXN-15013
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: RXN-15013. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: fcee22c95121a359d1b59a70a7d30ec76fa32e806211e079a3433e67fa8115d3
- evidence_id: source-07
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/6e/6eb3bdb826ebc4b1cf786fd27f536979d47a8b57a59740b161c4471fe83b2479.gz
  locator: Original MetaCyc:1.1.1.259-RXN; content-map.json key b6591668c106849c13141da28a39ee82a6364e085b0dbd4ac30692af9567c502;
    gzip 6eb3bdb826ebc4b1cf786fd27f536979d47a8b57a59740b161c4471fe83b2479 → b6591668c106849c13141da28a39ee82a6364e085b0dbd4ac30692af9567c502;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=1.1.1.259-RXN
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: 1.1.1.259-RXN. Complete original
    source hash and issuing identity verified. Native structured assertions retain
    exact XML object/slot locators and native type; this is not a quotation from a
    paper cited by the database.'
  snapshot_sha256: b6591668c106849c13141da28a39ee82a6364e085b0dbd4ac30692af9567c502
- evidence_id: source-08
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0a/0ae4b6084e5cf61833f621ba836e344474d30d53587a9881dd4a5bb96b4f861b.gz
  locator: Original MetaCyc:RXN-8032; content-map.json key e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a;
    gzip 0ae4b6084e5cf61833f621ba836e344474d30d53587a9881dd4a5bb96b4f861b → e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=RXN-8032
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: RXN-8032. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: e1ae388ee617e1141cd3db06844ec55f0ab8c8b8f1f7b6559cb667ae491e144a
- evidence_id: source-09
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/3a/3a723bbeeeece34a994bebe59c4d975695ea5ca4ad3a91e0f35e75bc8c9fd7a5.gz
  locator: Original MetaCyc:OAHTHAUERA-RXN; content-map.json key d0f778f36235b004616c7414da4d894a5744fc6cb792e653a613e681c71b748a;
    gzip 3a723bbeeeece34a994bebe59c4d975695ea5ca4ad3a91e0f35e75bc8c9fd7a5 → d0f778f36235b004616c7414da4d894a5744fc6cb792e653a613e681c71b748a;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=OAHTHAUERA-RXN
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Reaction: OAHTHAUERA-RXN. Complete original
    source hash and issuing identity verified. Native structured assertions retain
    exact XML object/slot locators and native type; this is not a quotation from a
    paper cited by the database.'
  snapshot_sha256: d0f778f36235b004616c7414da4d894a5744fc6cb792e653a613e681c71b748a
- evidence_id: source-10
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0b/0b97fe58423ed57a27d1cf8a115db4de9838ed9613155550757f21591fa4aec1.gz
  locator: Original MetaCyc:CPLX-8779; content-map.json key e44b86c2637cbeb66ec307461f9239e5f352ed2c281d8a85a01240399a2456c3;
    gzip 0b97fe58423ed57a27d1cf8a115db4de9838ed9613155550757f21591fa4aec1 → e44b86c2637cbeb66ec307461f9239e5f352ed2c281d8a85a01240399a2456c3;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-8779
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-8779. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: e44b86c2637cbeb66ec307461f9239e5f352ed2c281d8a85a01240399a2456c3
- evidence_id: source-11
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/59/594c970933e543ce614070c0623f0f818b5a0c522c4bb1e9e3397c09343c4e80.gz
  locator: Original MetaCyc:CPLX-8780; content-map.json key e86d177ba28e40d72c472e6432e033ce11ee2fef20154ef64143725f72495a51;
    gzip 594c970933e543ce614070c0623f0f818b5a0c522c4bb1e9e3397c09343c4e80 → e86d177ba28e40d72c472e6432e033ce11ee2fef20154ef64143725f72495a51;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-8780
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-8780. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: e86d177ba28e40d72c472e6432e033ce11ee2fef20154ef64143725f72495a51
- evidence_id: source-12
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/76/76dda9d9f329d44836e9249eedf86aca68d824b33ce148ed60debd1c139f1908.gz
  locator: Original MetaCyc:ENZRXN-1821; content-map.json key fbb3bc99f1a1da7bd24e855e5ff55ae24c938a2c2d713689bade1e2b3054b7b6;
    gzip 76dda9d9f329d44836e9249eedf86aca68d824b33ce148ed60debd1c139f1908 → fbb3bc99f1a1da7bd24e855e5ff55ae24c938a2c2d713689bade1e2b3054b7b6;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-1821
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1821. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: fbb3bc99f1a1da7bd24e855e5ff55ae24c938a2c2d713689bade1e2b3054b7b6
- evidence_id: source-13
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/69/697ac4ef824edc411da2be0b2ad5c558a01be6d147b6fb8f0fd642c718edb5fc.gz
  locator: Original MetaCyc:CPLX-1341; content-map.json key c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf;
    gzip 697ac4ef824edc411da2be0b2ad5c558a01be6d147b6fb8f0fd642c718edb5fc → c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-1341
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-1341. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: c2abb4f9eadf54d94362122fa4bf439450e106eca606d68f06adae59f6b48cdf
- evidence_id: source-14
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/12/126285f35ded35d1992d6991dffbd44f0272ec4949fb6e32f58ff1ab27fefef7.gz
  locator: Original MetaCyc:ENZRXN-1822; content-map.json key b83bf3492d5058a1f2caf915aedb8f778956111bc71f7dbcf079114af7ac2e1e;
    gzip 126285f35ded35d1992d6991dffbd44f0272ec4949fb6e32f58ff1ab27fefef7 → b83bf3492d5058a1f2caf915aedb8f778956111bc71f7dbcf079114af7ac2e1e;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-1822
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1822. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: b83bf3492d5058a1f2caf915aedb8f778956111bc71f7dbcf079114af7ac2e1e
- evidence_id: source-15
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/54/54fd4387fb25c791518c49b32540ba76746ddfad9c7c345a89c1202c34c7abd5.gz
  locator: Original MetaCyc:CPLX-1342; content-map.json key 8d4fdbf51ffecf05502dcaacd5be10b2f0a5f679c4db3d579e98a845a874f9f0;
    gzip 54fd4387fb25c791518c49b32540ba76746ddfad9c7c345a89c1202c34c7abd5 → 8d4fdbf51ffecf05502dcaacd5be10b2f0a5f679c4db3d579e98a845a874f9f0;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-1342
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-1342. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: 8d4fdbf51ffecf05502dcaacd5be10b2f0a5f679c4db3d579e98a845a874f9f0
- evidence_id: source-16
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/bb/bbe0acac4d6a76144de079e868408ebe5b671f04ce3395103909e003d43a4d0e.gz
  locator: Original MetaCyc:ENZRXN-1823; content-map.json key 6c1117e747e08816d64e292182bb413b968d2e8c24e2ef141a3787fc29b80f5b;
    gzip bbe0acac4d6a76144de079e868408ebe5b671f04ce3395103909e003d43a4d0e → 6c1117e747e08816d64e292182bb413b968d2e8c24e2ef141a3787fc29b80f5b;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-1823
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1823. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: 6c1117e747e08816d64e292182bb413b968d2e8c24e2ef141a3787fc29b80f5b
- evidence_id: source-17
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0c/0c97f941357dc0d44a8faba3e80b39a2dbe7d666788132e204d1faa91d8cdf5d.gz
  locator: Original MetaCyc:CPLX-1343; content-map.json key 071749ead25f503e2d1aa49b8ca6379f74dd719b3f02714a7c2fee166d453411;
    gzip 0c97f941357dc0d44a8faba3e80b39a2dbe7d666788132e204d1faa91d8cdf5d → 071749ead25f503e2d1aa49b8ca6379f74dd719b3f02714a7c2fee166d453411;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-1343
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-1343. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: 071749ead25f503e2d1aa49b8ca6379f74dd719b3f02714a7c2fee166d453411
- evidence_id: source-18
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/6d/6d35e85b78a66c519123cf64cf7d30389ee7d36553e7bee12698e2fb23e9bdd3.gz
  locator: Original MetaCyc:ENZRXN-1841; content-map.json key d710e90791a9571c6d4fc662e498040d96726e81352431a71d284c427e6d276c;
    gzip 6d35e85b78a66c519123cf64cf7d30389ee7d36553e7bee12698e2fb23e9bdd3 → d710e90791a9571c6d4fc662e498040d96726e81352431a71d284c427e6d276c;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-1841
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1841. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: d710e90791a9571c6d4fc662e498040d96726e81352431a71d284c427e6d276c
- evidence_id: source-19
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/53/53f520ace30a5e62866f13f0652ef1ab1438f5d815a68eb9a914085227306237.gz
  locator: Original MetaCyc:CPLX-1361; content-map.json key f037b2e0584ae09f190b8df1c2431a29c1cead51a1d14fa94f4e52b19f4214a8;
    gzip 53f520ace30a5e62866f13f0652ef1ab1438f5d815a68eb9a914085227306237 → f037b2e0584ae09f190b8df1c2431a29c1cead51a1d14fa94f4e52b19f4214a8;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-1361
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-1361. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: f037b2e0584ae09f190b8df1c2431a29c1cead51a1d14fa94f4e52b19f4214a8
- evidence_id: source-20
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/0f/0f71b3d253c29a8e09791e4007593070c60f2ba46aa3d83502e823ad0b9d5bbc.gz
  locator: Original MetaCyc:ENZRXN-22282; content-map.json key b03a78cd1d72883ce8939411ae96c4a91a5c60a62c272a6d222bc946a3064eff;
    gzip 0f71b3d253c29a8e09791e4007593070c60f2ba46aa3d83502e823ad0b9d5bbc → b03a78cd1d72883ce8939411ae96c4a91a5c60a62c272a6d222bc946a3064eff;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-22282
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-22282. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: b03a78cd1d72883ce8939411ae96c4a91a5c60a62c272a6d222bc946a3064eff
- evidence_id: source-21
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/1a/1a981baf6d39753519ba608d30f6b4538f5ea59daab82d3dc5216d841ac4060d.gz
  locator: Original MetaCyc:ENZRXN-22284; content-map.json key f417bf5ae7463a824d0a9d0ddb7c1fc1c5b90f9aa8d3361d6c12c7310c645a29;
    gzip 1a981baf6d39753519ba608d30f6b4538f5ea59daab82d3dc5216d841ac4060d → f417bf5ae7463a824d0a9d0ddb7c1fc1c5b90f9aa8d3361d6c12c7310c645a29;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-22284
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-22284. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: f417bf5ae7463a824d0a9d0ddb7c1fc1c5b90f9aa8d3361d6c12c7310c645a29
- evidence_id: source-22
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/6c/6c11611641fe2b4b1ff1174a84a10f0bb7687de285dfc0fc46a1b77dcf498f39.gz
  locator: Original MetaCyc:ENZRXN-1102; content-map.json key 861b31b7be3305955524f3acbc11915c8bba149a3fe232fd256dfc7dffe10121;
    gzip 6c11611641fe2b4b1ff1174a84a10f0bb7687de285dfc0fc46a1b77dcf498f39 → 861b31b7be3305955524f3acbc11915c8bba149a3fe232fd256dfc7dffe10121;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=ENZRXN-1102
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Enzymatic-Reaction: ENZRXN-1102. Complete
    original source hash and issuing identity verified. Native structured assertions
    retain exact XML object/slot locators and native type; this is not a quotation
    from a paper cited by the database.'
  snapshot_sha256: 861b31b7be3305955524f3acbc11915c8bba149a3fe232fd256dfc7dffe10121
- evidence_id: source-23
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/9e/9e52cbb5046b2c8052ee86898699104c242909332902d6262af1afba12206be3.gz
  locator: Original MetaCyc:CPLX-883; content-map.json key a79b3e4d3aa714e1b654fa42692cf0ac2e4831c90f166cfec6e5de5adf649ad1;
    gzip 9e52cbb5046b2c8052ee86898699104c242909332902d6262af1afba12206be3 → a79b3e4d3aa714e1b654fa42692cf0ac2e4831c90f166cfec6e5de5adf649ad1;
    public same-object/publication link https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object=CPLX-883
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: 'MetaCyc 27.0 complete native Protein: CPLX-883. Complete original source
    hash and issuing identity verified. Native structured assertions retain exact
    XML object/slot locators and native type; this is not a quotation from a paper
    cited by the database.'
  snapshot_sha256: a79b3e4d3aa714e1b654fa42692cf0ac2e4831c90f166cfec6e5de5adf649ad1
- evidence_id: source-24
  kind: primary_source
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/65/65dcd07b536f1442cc20513bb685de4a0fe2b92f66348ff20955519c1ad32b78.gz
  locator: Original PMID:30895699; content-map.json key c34a8d2aa9600fb9242b9d1f0d4d14366aed13e55cb84c2608467ccd1b498c4d;
    gzip 65dcd07b536f1442cc20513bb685de4a0fe2b92f66348ff20955519c1ad32b78 → c34a8d2aa9600fb9242b9d1f0d4d14366aed13e55cb84c2608467ccd1b498c4d;
    public same-object/publication link https://pmc.ncbi.nlm.nih.gov/articles/PMC6488403/
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: Syntrophus aciditrophicus uses the same enzymes in a reversible manner
    to degrade and synthesize aromatic and alicyclic acids.. Complete original source
    hash and issuing identity verified. Primary claim support is limited to inspected
    assay/construct paragraphs; unacquired supplements are not treated as read.
  snapshot_sha256: c34a8d2aa9600fb9242b9d1f0d4d14366aed13e55cb84c2608467ccd1b498c4d
- evidence_id: source-25
  kind: primary_source
  reference: research/pathway_additions/2026-10-15-next-266/evidence-retention/objects/2f/2f264c0f43987081f9b1780b99afe5981918a58aa67efe96539f0c88b53ab1c6.gz
  locator: Original PMID:35557486; content-map.json key b8b1f8983425f98697bf834f109d6a1e01a9797ea2325f12c40560a771aadc44;
    gzip 2f264c0f43987081f9b1780b99afe5981918a58aa67efe96539f0c88b53ab1c6 → b8b1f8983425f98697bf834f109d6a1e01a9797ea2325f12c40560a771aadc44;
    public same-object/publication link https://pmc.ncbi.nlm.nih.gov/articles/PMC9400901/
  accessed_at: '2026-10-15T17:55:43.710338Z'
  support: supports
  summary: Advanced Insights into Catalytic and Structural Features of the Zinc-Dependent
    Alcohol Dehydrogenase from Thauera aromatica.. Complete original source hash and
    issuing identity verified. Primary claim support is limited to inspected assay/construct
    paragraphs; unacquired supplements are not treated as read.
  snapshot_sha256: b8b1f8983425f98697bf834f109d6a1e01a9797ea2325f12c40560a771aadc44
- evidence_id: ev-imodulon-original
  kind: database
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/imodulon-inputs/imodulondb-datasets-original.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Complete dated public dataset response from https://imodulondb.org/api/datasets,
    accessed 2026-10-15T13:11:04.934782Z. Exact response is reused, not freshly fetched.
    The matching unmodified adapter and failed prior transport observations are retained
    in adjacent archive members.
  snapshot_sha256: 155607e7023efdead5ebab3919279a0776d5665a7de9e28b67f02f8f521b0693
- evidence_id: ev-initial-helper-failure
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/reference-check-initial-helper-failure.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: context_only
  summary: 'Historical reviewer helper failure: public BioCyc object URL was incorrectly
    equated to native XML mirror acquisition URL. Corrected with separate identity
    checks; no record change. A display-only optional source_version KeyError is also
    recorded.'
  snapshot_sha256: da213f2a68c534e0f5036216ab0c932b42b5eed2829db63e9f7d953b84829d8c
- evidence_id: ev-console-failure
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/imodulon-inputs/imodulondb-datasets-receipt.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: context_only
  summary: Historical same-day console runner dependency failure; exact command, exit
    1 and stderr retained. Subsequent dated successful response and unchanged adapter
    replay support applicability.
  snapshot_sha256: cd656fa3c907b021927284d4588aa2f3ff67cb24e4b9e76dc3f2934966fbd38c
- evidence_id: ev-direct-adapter-failure
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: TAR member scientific/imodulon-inputs/imodulondb-direct-adapter-receipt.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: context_only
  summary: Historical same-day direct adapter transport was unavailable due to DNS
    URLError. No runtime was repaired; later successful public response is distinct.
  snapshot_sha256: 511a0481f4e3e080e61ab78f71e54d56dce660f4d7e46bd798daf28aa8ee5961
- evidence_id: ev-gate-1
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member full-gates/just-render-pages.log
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 263 pathway pages rendered, 102.14 seconds. Root executed this command;
    independent reviewer read the complete log and verified its digest and receipt.
  snapshot_sha256: f9eda99f35512a5c6ee738b032fba00cc29cde20db72bf7047f4cb6914cf7f2d
- evidence_id: ev-gate-2
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member full-gates/just-validate.log
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Validated 263 records, 20,455 evidence blocks and 493 histories; closed
    schema, identifiers and label policies, source/docs contracts and page currentness
    passed, 195.41 seconds. Root executed this command; independent reviewer read
    the complete log and verified its digest and receipt.
  snapshot_sha256: 25513eb3c5afbbf71f5bbac1e09866824501fb65eed07872338571ca6ed7a6ad
- evidence_id: ev-gate-3
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member full-gates/just-test.log
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: 5489 passed, 3 skipped, 7 warnings; pytest 969.95 seconds, wrapper 972.82
    seconds. Three empty command-frontmatter parametrizations are explained by the
    unchanged test source and hidden/ignored-inclusive directory walk. Seven warnings
    are retained dependency deprecations. Root executed this command; independent
    reviewer read the complete log and verified its digest and receipt.
  snapshot_sha256: 8fef5fc4789ee375e228746bd44a783b7c42c04b48a3125b919dd3e16b1314f0
- evidence_id: ev-gate-4
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member full-gates/just-lint.log
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Ruff reported all checks passed, 0.41 seconds. Root executed this command;
    independent reviewer read the complete log and verified its digest and receipt.
  snapshot_sha256: df1116f359e834afd6a034defcde34a9a565e53ff21243185301623b334dcb41
- evidence_id: ev-gate-5
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member full-gates/git-diff---check.log
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: Working-tree whitespace check returned zero with empty log, 0.66 seconds;
    this does not assert a later staged-index check. Root executed this command; independent
    reviewer read the complete log and verified its digest and receipt.
  snapshot_sha256: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- evidence_id: ev-terminal-receipts
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member full-gates/receipts.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All five root commands terminated with exit zero; real start times, elapsed
    durations and complete log hashes retained.
  snapshot_sha256: 3bf72612b0a7832ebb14e0bbe916d5ef80ad0d629a3ef4a2e5ec0ffe7dfc3460
- evidence_id: ev-gate-inputs
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR members full-gates/tested-core-input-hashes.json and full-gates/final-input-preservation.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: 'Complete root before/after inventory: 29,503 files, hidden/ignored included,
    named runtime cache exclusions. Independent current rehash confirms 29,502 remain
    exact and only the read final report changed. Root run does not validate future
    additions.'
  snapshot_sha256: 315f56abaae09ba2f0452287e5df3d0c5f53b8750a844a2112eff5cec7a0d3c0
- evidence_id: ev-root-prerequisite-failure
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: TAR member root/gate-wrapper-prerequisite-race.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: context_only
  summary: Earlier wrapper failed reading a pending prerequisite before any gate command
    ran or gate output directory existed. The subsequent single complete run is preserved
    separately; no failed test was hidden.
  snapshot_sha256: d15da5e6fdaecc97e4ff76e3d6996bf8ceb72fbbabbbba217b858d7054a9e41e
- evidence_id: ev-final-gate-archive
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/final-gates/files.tar.gz
  locator: Complete TAR membership bound by adjacent source-file-manifest.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 19 unique relative regular-file members independently compared to every
    original byte. Source manifest SHA256 85aae7a83cf8468206008f0f8b9ced182b721fc7378e28970f236d4552abce2d.
  snapshot_sha256: 1c84c6bb66edc629f400878a90ec627e11692cb516f91a050247a5e4dc07bc84
- evidence_id: ev-complete-preparation
  kind: validation
  reference: research/pathway_additions/2026-10-15-next-266/verification/maintained-review-preparation/files.tar.gz
  locator: Complete TAR membership bound by adjacent source-file-manifest.json
  accessed_at: '2026-10-15T17:55:24.977819Z'
  support: supports
  summary: All 224 unique relative regular-file members independently compared to
    every original byte. Source manifest SHA256 6b32a52ead40dec6442e0d0387a41b57bd689feb94f39b21d7f45d265f73b421.
  snapshot_sha256: 6d74786f8abcdbc5706a62f13220f2fbbbd56820e968cddf755dbc3b62e59a0e
- evidence_id: ev-final-report
  kind: record_content
  reference: research/pathway_additions/2026-10-15-next-266/README.md
  locator: Verification and publication section; complete report read and explicit
    old/new diff inspected
  accessed_at: '2026-10-15T17:55:43.891732Z'
  support: supports
  summary: Only the final dated verification paragraph changes. It accurately records
    terminal gates and retained preparation while leaving canonical persistence, publication,
    staged checks and merge as later observations. Scientific scope and all source
    limits remain unchanged.
  snapshot_sha256: cb8ad4faf2e342c3b3947a156d6dfeb8e51b310b15efe23e11a50d5657784980
- evidence_id: ev-final-history
  kind: record_content
  reference: history/other/benzoyl-coa-anaerobic-research/2026-10-15T174957Z-Codex-d39747.yaml
  locator: Complete native EDIT history
  accessed_at: '2026-10-15T17:55:43.891732Z'
  support: supports
  summary: Fifth native history records actual 2026-10-15T17:49:57Z adoption of successful
    gates and complete preparation retention. It does not claim canonical save, PR
    publication or merge.
  snapshot_sha256: c481e4bc95284a17d0059f90d1a6648a32c3b6ac1a9b3144b92e02c456d18f7d
- evidence_id: ev-current-record
  kind: record_content
  reference: data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml
  locator: Complete maintained YAML; all fields, 76 edges, endpoint qualifiers, 25
    references and 117 evidence assertions
  accessed_at: '2026-10-15T17:55:43.891732Z'
  support: supports
  summary: Complete actual YAML read during maintained review; current bytes remain
    exactly e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9. All
    scientific interpretation and current input hashes bind that same record.
  snapshot_sha256: e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9
summary: The complete maintained CENTBENZCOA-PWY record is scientifically supported
  within its explicit source, taxon and construct limits. All seven selected steps,
  six formal joins, 76 edges, 56 named identities, 25 references and 117 evidence
  assertions were assessed; no actionable blocker, major or minor finding remains
  in this scope. Exact maintained evidence ownership and all required root-run corpus
  gates are bound. Putative/predicted lower-route enzymes, generic ferredoxin units,
  formal Oah constituents and unavailable historical/supplementary sources remain
  qualified. This completed scientific observation is external prepared content; canonical
  persistence and publication are separate root-owned steps.
completion: completed
verdict: pass_with_limitations
native_verdict: Whole seven-step pathway supported with explicit primary-source, native-annotation,
  taxon and construct limits; no actionable scientific findings.
tags:
- scientific-review
- whole-route
- next266
- source-scope
- independent
finished_at: '2026-10-15T17:59:45.408686Z'
review_id: 20261015T175945Z-centbenzcoa-pwy-scientific
```
