"""Assemble already completed scientific content; never produce a final verdict.

Writes only beside this helper. No subprocess, network, maintained write or saver.
The result is intentionally not a RecordReview until separately reassessed final
inputs, terminal gate evidence and actual final timing are supplied.
"""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import yaml

HERE = Path(__file__).resolve().parent
PREP = Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
TARGET = 'MetaCyc:CENTBENZCOA-PWY'
REPOSITORY = 'CultureBotAI/PathwayMech'
RECORD_SHA = 'e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9'
NOW = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')

def read(name):
    return json.loads((PREP / name).read_text())

def write(name, value):
    p = HERE / name
    if p.exists():
        raise RuntimeError(f'Refusing to overwrite {p}')
    p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

inventory = []
for p in sorted(PREP.rglob('*')):
    if p.is_symlink():
        raise RuntimeError(f'Unexpected symlink {p}')
    if p.is_file():
        b = p.read_bytes()
        inventory.append({'path': p.relative_to(PREP).as_posix(), 'sha256': sha256(b).hexdigest(), 'bytes': len(b)})
assert len(inventory) == 131, len(inventory)
write('prior-preparation-inventory.json', {'read_at': NOW, 'root': str(PREP), 'files': inventory, 'count': len(inventory), 'scope': 'All files, including hidden and ignored paths; inventory only, no claim of fresh whole-source human rereading.'})

inspection = read('retention-integration/inspect.stdout.json')
record = yaml.safe_load((PREP / 'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_bytes())
assert sha256((PREP / 'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_bytes()).hexdigest() == RECORD_SHA
edge_rows = read('maintained-edge-assessments.json')['rows']
refs = read('reference-original-assessment.json')['rows']
assert len(edge_rows) == len(record['mechanistic_edges']) == 76
assert len(refs) == len(record['references']) == 25

evidence_plan = []
def planned_evidence(eid, path, kind, summary, support='supports'):
    raw = (PREP / path).read_bytes()
    evidence_plan.append({'evidence_id': eid, 'kind': kind, 'prior_preparation_relative_path': path, 'snapshot_sha256': sha256(raw).hexdigest(), 'bytes': len(raw), 'support': support, 'summary': summary, 'binding_pending': 'Resolve exact maintained preparation archive member and verified access time after final stable handoff. This object is not yet a ReviewEvidence.'})

planned_evidence('ev-scientific-assessment', 'ASSESSMENT.preparation.md', 'prior_review', 'Independent whole maintained-record assessment; all 76 edges, 56 named identities, 25 references, 117 evidence assertions and explicit source limits. Prior whole-design judgment is reused through exact complete-edge equality, with current full YAML reading and fresh bounded original checks.')
planned_evidence('ev-edge-matrix', 'maintained-edge-assessments.json', 'prior_review', 'One independent disposition for each of the 76 actual maintained edges. All complete edge objects strictly equal the previously independently reviewed design; fresh locator checks preserve claim and qualifier scope.')
planned_evidence('ev-route', 'route-replay.json', 'validation', 'All seven selected memberships, 32 material occurrences, 19 frames, six shared-material joins and auxiliary eighth reaction; exact native directions, coefficients and Oah constituent sum. Deterministic replay supports correspondence, not experimental proof.')
planned_evidence('ev-locators', 'evidence-locator-replay.json', 'validation', 'All 117 evidence locators and all four exact short quotations resolve to original source bodies with the stated scope; no database assertion relabeled a primary-paper quote.')
planned_evidence('ev-identities', 'named-identity-assessment.json', 'database', 'All 56 named record, reaction, participant and taxon identities checked against exact issuing originals and selected maintained authority terms. Names, native types and stable accession scope are separately assessed from biochemical function.')
planned_evidence('ev-references', 'reference-original-assessment.json', 'database', 'All 25 native-object/publication references, exact source hashes and issuing identities. Human-facing BioCyc links designate the same object; retained hashes bind explicitly identified native XML rather than public HTML.')
planned_evidence('ev-replay', 'scientific-replay-execution-observation.json', 'validation', 'Actual successful reviewer replay observations, including 15 activity dispositions, 21 protein/CDS bindings, 13 assembly components, 76 edges and 117 evidence assertions. This is not a replacement full-corpus gate.')
planned_evidence('ev-imodulon', 'imodulon-applicability-assessment.json', 'database', 'Same-day dated complete public iModulon dataset listing and fresh offline unmodified adapter replay; 20 organisms and 28 datasets. No matching source-taxon dataset in that finite listing; E. coli is a heterologous expression host. Not a fresh live query or negative biology.')
planned_evidence('ev-formatting', 'formatting-successor-independent-comparison.json', 'validation', 'Explicit old/new capture of three authority registry serializations; strict whole-JSON equality, original values and insertion-order prefixes retained; unchanged scientific YAML. No silent input hash refresh.')
planned_evidence('ev-authority', 'separate-root-support-binding.json', 'prior_review', 'Separately authored independent authority implementation/projection acceptance bound to exact current implementation inputs; root-generated render/KGX/browser proofs retain root attribution and their limits.')
planned_evidence('ev-retention-assessment', 'retention-integration/ASSESSMENT.supplement.md', 'prior_review', 'Full current research report and ownership prose, four native histories and relevant root/independent retention receipts read. No new scientific or provenance defect; final canonical state remained explicitly pending.')
planned_evidence('ev-retained-sources', 'retention-integration/scientific-maintained-owner-bindings.json', 'validation', 'All 3343 maintained payload files rehashed; 421 selected source occurrences (353 distinct contents) independently decoded and compared to originals, including complete design and all 25 record reference originals. Whole design remains strictly equal to maintained YAML.')
planned_evidence('ev-portable-retention', 'retention-integration/portable-verification-ownership.json', 'validation', 'All 43 root-integration archive members plus 255 retention archive members and 3343 explicit shared maintained owners match originals; unique relative regular-file membership and exact stored bytes.')
planned_evidence('ev-history', 'retention-integration/root-execution-and-history-bindings.json', 'validation', 'Three root actual-copy physical/compact/provenance executions and four native history records are exactly bound. Actual native curation stage and review status are distinct.')
planned_evidence('ev-prior-design-reuse', 'prior-scientific-assessment-reuse.json', 'prior_review', 'Explicit exact binding to this reviewer’s original independent whole-design scientific assessment; no claim that hashing or serializer equality itself establishes biochemical truth.')

assessments = []
def assessment(aid, area, topic, summary, evidence, details=None, dimensions=(), metrics=()):
    a = {'assessment_id': aid, 'area': area, 'topic': topic, 'outcome': 'supported', 'summary': summary, 'target_ids': [TARGET], 'evidence_ids': list(evidence)}
    if details:
        a['details'] = details
    if dimensions:
        a['dimensions'] = list(dimensions)
    if metrics:
        a['metrics'] = list(metrics)
    assessments.append(a)

assessment('a-identity', 'identity', 'Exact CENTBENZCOA-PWY identity and finite duplicate context', 'The maintained YAML denotes the complete source-defined benzoyl-CoA degradation II (anaerobic) route. It is distinct from the nine-step P321 route and the accepted aerobic PWY-1361 record. Prior independent merged-baseline/source-follow acceptance is reused within its finite captured scope; no global absence claim is made.', ['ev-scientific-assessment','ev-prior-design-reuse','ev-identities','ev-retained-sources'])
assessment('a-route', 'completeness', 'Complete selected route and formal joins', 'All seven selected reactions, 32 material occurrences over 19 frames and six shared-material joins are retained. The Oah net composite is an auxiliary eighth declared reaction, not an eighth selected step. No route subset is substituted.', ['ev-route','ev-edge-matrix','ev-scientific-assessment'], metrics=[{'name':'selected route steps','value':7,'unit':'steps','definition':'All native selected membership steps represented','denominator':7},{'name':'material joins','value':6,'unit':'joins','definition':'All selected successive shared-material links represented','denominator':6}])
assessment('a-feredoxin', 'quantity', 'Generic ferredoxin cluster-unit stoichiometry', 'BCR uses coefficient two for generic native one-electron ferredoxin cluster units. Whole two-cluster polypeptides and intrinsic BCR iron-sulfur centers remain distinct. The retired Rhea 19100 chain is not an automatic replacement.', ['ev-route','ev-locators','ev-scientific-assessment'], 'The small-molecule charge residual of minus two is compensated by two native one-electron cluster oxidations. Generic drawings do not identify a universal donor sequence or occupancy.')
assessment('a-direction', 'graph', 'Native directions and pathway traversal', 'Every reaction retains its native direction independently of selected material traversal. The six provides_input_for edges express formal source ordering and a shared coefficient-one material; they do not assert physical channeling, a protein complex or measured complete-route flux.', ['ev-route','ev-edge-matrix','ev-scientific-assessment'])
assessment('a-oah', 'scope', 'Oah composite and CPD-15900', 'The two formal Oah constituent equations sum exactly to the declared hydrolysis composite and cancel CPD-15900. They do not establish separately assayed constituent catalysts or a freely released or accumulating CPD-15900 intermediate.', ['ev-route','ev-locators','ev-scientific-assessment'])
assessment('a-lower-route', 'scope', 'Putative step 6 and predicted operon-scoped PimB', 'Step 6 remains YES-PUTATIVE with exact formal materials and no assigned catalyst. Step 7 has a real native RXN-8032 → ENZRXN-26773 → MONOMER-20679/G-58826 → Q6N3H9 chain, explicitly predicted and lacking individual biochemical characterization. Operon/mutant context does not justify a single-protein enables or catalyzes edge.', ['ev-scientific-assessment','ev-replay','ev-locators'], 'Neither missing-backlink reasoning nor a fabricated lower-route Thauera enzyme is used. C4 assays, BadH/Hcd annotations, proteomics and apo structures do not establish the exact Thauera C7 catalyst. The native reaction name is not an individual PimB assay.')
assessment('a-identity-crosswalks', 'grounding', 'Issuing identities, reference originals and coefficients', 'All 56 named identities and 25 reference originals have exact issuing identity checks. All 117 locators and four short quotations are valid; 19 chemical identities and 17 complete native/ChEBI structure pairs preserve source stereochemistry and charge. Stable identifiers do not substitute for functional evidence.', ['ev-identities','ev-references','ev-locators','ev-replay'])
assessment('a-proteins', 'scope', 'Protein/CDS and assembly component scope', 'All 21 native protein/CDS crosswalks and all 15 activity dispositions were examined, including excluded examples. The 13 assembly component edges preserve sequence identity and multiplicity without assigning isolated-subunit catalysis. The BcrA CDS bcrB qualifier conflict remains an explicit annotation conflict.', ['ev-replay','ev-scientific-assessment','ev-retained-sources'])
assessment('a-constructs', 'scope', 'BamR, BamA and BamQ construct-specific evidence', 'BamR C-terminal His6 and BamA N-terminal His6 preparation qualifiers remain on assembly and component endpoints. Apparent oligomerization is not generalized to universal native assemblies. BamQ is the exact SYN_RS14210/WP_011418919.1 CDS with substrate-specific recombinant P13 assay support; P44 supports E. coli BL21/pET101, while unseen insert/tag details remain unknown.', ['ev-scientific-assessment','ev-references','ev-locators'])
assessment('a-had', 'evidence', 'Had zinc and activity-specific cofactors', 'The modern Had AAS result supports two zinc atoms per monomer for a C-terminal Strep-tagged wild-type, zinc-supplemented preparation. It does not establish historical native occupancy, mutant crystal identity or a physiological CoA-substrate assay. The separate native zinc statement remains uncited structured evidence; magnesium and intrinsic CPD-7 associations retain activity-specific scope.', ['ev-scientific-assessment','ev-references','ev-locators'])
assessment('a-taxa', 'scope', 'Taxa, historical strains and expression hosts', 'All four taxon identities are exact. Source-defined route membership is not experimental closure of every step in each taxon. Syntrophus upper-route examples do not establish ATP-dependent BCR there. R. palustris BadDEFG genetic/sequence evidence remains enables. Deposited CGA009 proteins, original CGA604 cloning, Thauera K172, Azoarcus KB740 and recombinant E. coli remain separate.', ['ev-scientific-assessment','ev-identities','ev-replay'])
assessment('a-sources', 'evidence', 'Structured assertions, primary evidence and bounded original access', 'Native XML statements are represented as source assertions at exact object locators, not quotations from papers cited by the database. Primary construct and assay claims remain tied to inspected original paragraphs. Public BioCyc links and retained native XML hashes serve explicitly different roles.', ['ev-references','ev-locators','ev-scientific-assessment'], 'Unacquired original historical papers, erratum and supplementary files remain limitations; abstracts and bibliography leads are not promoted to read full text.')
assessment('a-imodulon', 'evidence', 'Structured-source adapter applicability', 'The dated complete iModulonDB listing has no source-taxon dataset for Thauera, Syntrophus or Rhodopseudomonas. E. coli coverage concerns the expression host and cannot establish foreign-route catalysis. Per-dataset source-pathway search and component summaries are not applicable to these observed taxa.', ['ev-imodulon'], 'Same-day 2026-10-15T13:11:04.934782Z response reuse and offline exact adapter replay are explicit. Original console dependency and transport failures are preserved. Absence from this finite dataset list is not negative biology or a fresh live query.')
assessment('a-authority', 'representation', 'Specialized typed authority profiles and serialization successor', 'The unnamed heteromer, typed Protein coefficient reaction, generic ferredoxin classes, Oah composite and named RXN-8032 shapes retain specific bounded owners. Separate independent authority implementation/projection acceptance is attributed. Three registry formatting successors preserve full JSON meaning and baseline entries; earlier inspected hashes remain in history.', ['ev-authority','ev-formatting','ev-identities'])
assessment('a-retention', 'provenance', 'Actual maintained scientific evidence and portable ownership', 'The current retained payload preserves the complete assessed design and selected scientific originals, every actual reference original, the prior independent judgments and original operational failures. The independent reviewer decoded 421 selected occurrences/353 distinct contents and verified all 3343 payload files; broader complete logical and Git provenance checks retain separate reviewer/root attribution.', ['ev-retained-sources','ev-portable-retention','ev-retention-assessment'])
assessment('a-history', 'ownership', 'Historical report and native stage accounting', 'The inspected report, ownership READMEs and four native histories distinguish creation, later retention adoption and the then-pending canonical/production boundary. Issues 590 and 591 retain their original findings and separate accepted corrections; this review does not publish or close GitHub issues.', ['ev-history','ev-retention-assessment'])
assessment('a-generated', 'representation', 'Generated page and KGX preservation evidence', 'Separately bound root checks cover the whole record in generated page/KGX output and old-edge preservation. Browser retry, initial sandbox startup failure and root visual inspection retain their actual attribution. This scientific reviewer does not claim another browser execution or screenshot inspection.', ['ev-authority','ev-portable-retention'])

edge_to_refs = []
for i, (row, edge) in enumerate(zip(edge_rows, record['mechanistic_edges']), 1):
    assert row['edge'] == f'e{i:03d}'
    assert (row['subject'], row['predicate'], row['object']) == (edge['subject'], edge['predicate'], edge['object'])
    assert row['actual_yaml_full_edge_equals_independently_reviewed_design'] is True
    assert row['fresh_locator_result'] == 'pass'
    evidences = edge.get('evidence', [])
    edge_to_refs.append({'edge': row['edge'], 'field_path': f'mechanistic_edges[{i-1}]', 'actual_edge': edge, 'prior_assessment': row})
    assessment('a-' + row['edge'], 'graph', f"{row['edge']}: {row['subject']} {row['predicate']} {row['object']}", row['assessment'], ['ev-edge-matrix','ev-locators','ev-scientific-assessment'], f"Actual field mechanistic_edges[{i-1}]. {row['judgment_basis']} Complete endpoint qualifiers, coefficients and all {row['evidence_count']} evidence entries are preserved in the exact current-edge binding.", dimensions=[{'name':'evidence-tier','value':'Claim-specific structured or primary evidence as declared in the unchanged complete edge','definition':'No uniform experimental tier is assigned across unlike claims; consult the exact edge and source locator matrix.','evidence_ids':['ev-edge-matrix','ev-locators']},{'name':'source-object-and-qualifiers','value':f'mechanistic_edges[{i-1}] and row {row["edge"]} of maintained-edge-assessments.json','definition':'Exact source objects, taxon/condition qualifiers and component roles remain in the whole actual edge object.','evidence_ids':['ev-edge-matrix','ev-locators']}])

limitations = [
    'The seven-step native route is source-defined formal chemistry; the record does not experimentally close every step in every listed organism.',
    'Generic ferredoxin cluster-unit coefficient two is not whole-polypeptide stoichiometry, a universal donor identity or intrinsic BCR cluster occupancy. Retired Rhea 19100 is not automatically replaced.',
    'Oah constituent equations and CPD-15900 cancellation do not demonstrate separately assayed catalysts or a free accumulated intermediate; native reversible metadata does not establish physiological reverse flux.',
    'Step 6 remains putative without a catalyst; predicted individual PimB and operon-level evidence do not establish a lower-route enzyme assay. No lower-route Thauera enzyme is asserted.',
    'Strain, gene-annotation conflict, tag/construct, expression host and apparent assembly qualifiers remain material. Modern Had preparation zinc measurements are not universal native occupancy.',
    'Selected historical full texts and supplements remain unavailable or unread: Oah PMID 10406950 and 18312395 full original text/GST ambiguity, PMID 9490071 and 10903310 abstract-level scope, the 1998 hydratase erratum, Had Table S2, and unseen recombinant insert/tag details. A BoxB bibliography lead is not the cited BCR full paper.',
    'iModulonDB applicability uses a dated same-day complete dataset response with exact offline adapter replay, not a fresh live query. No matching source-taxon dataset in that finite listing is not negative biology.',
    'The prior independently authored whole-design scientific assessment is reused through exact complete object/edge bindings, current full maintained YAML reading and fresh bounded source checks. This is not another full human reading of every upstream paper or source archive.',
    'Finite captured merged-baseline duplicate/source-follow evidence does not establish global absence. Earlier provenance corrections retain their exact prior findings and accepted successors; this review does not close GitHub issues.',
    'Authority implementation, broad retention/Git provenance and root browser/render/KGX checks retain their separate authorship and scope. Hash/schema/serializer success alone is not scientific acceptance.',
]
fragment = {'schema_version':'1.0.0', 'kind':'record', 'repository':REPOSITORY, 'title':'Scientific review of benzoyl-CoA degradation II (anaerobic)', 'started_at':'2026-10-15T16:40:08Z', 'reviewer':{'identity':'Codex /root/next266_design_acceptance','kind':'agent','independence':'independent','independence_basis':'Independent of the source-to-record design, authority implementation and maintained integration authors. This reviewer authored the prior scientific design review and its explicitly reused exact-source judgments; root alone curates and saves maintained content.'}, 'skill':'.claude/skills/review-yaml-record/SKILL.md', 'scientific_review':True, 'scope':{'description':'Whole maintained CENTBENZCOA-PWY YAML: all 76 edges, 56 named identities, 25 references, 117 evidence assertions, all seven selected steps and six formal joins, exact source/construct/taxon limits and retained ownership.','selection':'Exactly data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml, MetaCyc:CENTBENZCOA-PWY.','coverage':'full','population_size':1,'reviewed_target_ids':[TARGET],'exclusions':[{'target':'Other pathway records','reason':'Full-corpus deterministic gates and finite duplicate scans are separately attributed; no new scientific record-by-record review of the other 262 maintained pathways.'},{'target':'Unacquired historical full text and supplements','reason':'Claims remain bounded to original source text actually read and the explicit access limitations.'}]}, 'targets':inspection['targets'], 'assessments':assessments, 'findings':[], 'actions':[], 'limitations':limitations, 'notes':'Draft scientific content only. Final input inspect, stable report/history/preparation ownership, terminal-gate binding, final verdict/timestamp and governed validation/persistence are deliberately absent. No maintained write or canonical save has occurred.'}
assert len(assessments) == 93
assert all(k not in fragment for k in ('completion','verdict','finished_at','review_id','source','checks','evidence','summary'))
write('review-content.fragment.json', fragment)
write('evidence-binding-plan.json', {'created_at':NOW,'status':'pending final stable maintained ownership and exact terminal gate binding','evidence':evidence_plan,'record_reference_originals':refs,'no_final_verdict':True})
write('complete-edge-content-binding.json', {'record_sha256':RECORD_SHA,'rows':edge_to_refs,'count':76,'scope':'Small exact derived matrix for canonical assessment assembly; original evidence files are not copied.'})
write('DRAFT-STATE.json', {'created_at':NOW,'status':'draft only; not a governed complete or partial review','previous_preparation_files':131,'assessments':93,'whole_edge_assessments':76,'planned_evidence_items':len(evidence_plan),'required_late_fields':['review_id','finished_at','completion','verdict','source','checks','evidence','summary'],'required_next_steps':['Root stable maintained final gate/preparation archives and final report/native history handoff','Independently compare changed and added inputs; preserve prior inspection history','Bind terminal gate receipts and tested/current input preservation with explicit root attribution','Resolve every evidence item to an exact retained owner, then fresh governed inspect','Write completed external content with actual UTC finish; native validate only after all requirements are met','Root sole maintained governed save and subsequent review check'],'root_terminal_message_observed':'Root reports all required gates terminal zero; not yet accepted as stable final review evidence.'})
print(json.dumps({'status':'draft prepared','assessments':len(assessments),'edge_assessments':76,'planned_evidence':len(evidence_plan),'prior_files':len(inventory),'final_verdict_omitted':True}))
