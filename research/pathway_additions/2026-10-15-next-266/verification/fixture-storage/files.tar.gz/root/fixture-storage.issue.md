Finding: P266-FIXTURE-STORAGE-R01. Severity: minor publication packaging defect.

The actual staged `git diff --cached --check` failed on six of the eight new complete MetaCyc XML fixtures under `tests/fixtures/benzoyl_authority/`: `1.3.99.15-RXN.xml`, `CPLX-1341.xml`, `Oxidized-ferredoxins.xml`, `Reduced-ferredoxins.xml`, `RXN-15012.xml`, and `RXN-15013.xml`. Each contains trailing whitespace in an upstream contributor biography. The earlier working-tree-only check did not include these new untracked files. No commit or PR has been created for this candidate.

The source bytes and their provenance hashes must remain exact. Store all eight fixtures with deterministic lossless gzip, preserve their logical decoded XML paths and original manifest/acquisition bytes, and make the fixture loader verify both stored and decoded bytes before staging temporary XML inputs.

Acceptance criteria:

- Every compressed fixture decodes to its accepted original length and SHA-256; no XML whitespace is trimmed.
- Original `manifest.json` and `acquisition.json` are unchanged; a separate storage map describes compressed ownership.
- All existing authority tests continue to exercise the complete original XML and their adversarial mutations.
- The complete affected module and lint pass; independent review verifies the bounded change.
- The actual staged whitespace check passes before commit; prior failed receipts and reviews remain preserved.

This is distinct from #493, which concerns the separate THIO research dossier and its 23 source originals. Evidence: `/private/tmp/pathwaymech-next-266-ci/actual-staged-whitespace.json`, observed 2026-10-15T18:11:13.252660Z (exit 2), and the original reviewed candidate input manifest. These artifacts will accompany the maintained correction evidence.
