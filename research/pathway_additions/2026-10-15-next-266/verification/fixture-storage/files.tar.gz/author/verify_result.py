"""Bind the exact bounded edit and prove original-byte/protected-input preservation."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess

ROOT = Path('/private/tmp/pathwaymech-next-266-20261015')
OUT = Path(__file__).resolve().parent
FIXTURE = ROOT / 'tests/fixtures/benzoyl_authority'


def sha(body):
    return hashlib.sha256(body).hexdigest()


def inventory(paths):
    result = []
    for path in sorted(paths):
        if path.is_file():
            body = path.read_bytes()
            result.append({'path': str(path.relative_to(ROOT)), 'bytes': len(body), 'sha256': sha(body)})
    return result


before = json.loads((OUT / 'initial-inventory.json').read_text())
after = inventory(list(FIXTURE.rglob('*')) + [ROOT / 'tests/test_benzoyl_authority.py'])
protected_after = inventory(path for name in ['src', 'data', 'conf', 'pages', 'reviews'] for path in (ROOT / name).rglob('*'))
assert protected_after == before['protected_files']
assert sha(Path(before['git_index']['path']).read_bytes()) == before['git_index']['sha256']
old = {row['path']: row for row in before['bounded_files']}
new = {row['path']: row for row in after}
changed = sorted(name for name in old.keys() & new.keys() if old[name] != new[name])
removed = sorted(old.keys() - new.keys())
added = sorted(new.keys() - old.keys())
assert changed == ['tests/fixtures/benzoyl_authority/README.md', 'tests/test_benzoyl_authority.py']
assert len(removed) == 8 and all(name.endswith('.xml') for name in removed)
assert len(added) == 9 and sum(name.endswith('.xml.gz') for name in added) == 8
for name in ('manifest.json', 'acquisition.json'):
    assert (FIXTURE / name).read_bytes() == (OUT / 'before/tests/fixtures/benzoyl_authority' / name).read_bytes()
storage = json.loads((FIXTURE / 'storage.json').read_text())
assert storage['version'] == 1 and storage['encoding'] == 'gzip' and storage['mtime'] == 0
rows = json.loads((FIXTURE / 'manifest.json').read_text())
assert set(storage['files']) == {row['entry']['path'] for row in rows}
recovery = []
for row in rows:
    name = row['entry']['path']
    stored = storage['files'][name]
    body = (FIXTURE / stored['path']).read_bytes()
    assert len(body) == stored['bytes'] and sha(body) == stored['sha256']
    decoded = gzip.decompress(body)
    original = (OUT / 'before/tests/fixtures/benzoyl_authority' / name).read_bytes()
    assert decoded == original
    assert len(decoded) == stored['original']['bytes'] == row['original']['bytes']
    assert sha(decoded) == stored['original']['sha256'] == row['original']['sha256'] == row['entry']['sha256']
    repeat = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=repeat, mode='wb', compresslevel=9, mtime=0) as gz:
        gz.write(original)
    assert repeat.getvalue() == body
    assert body[3] == 0 and body[4:8] == b'\x00' * 4
    recovery.append({'logical_path': name, 'compressed': {k: stored[k] for k in ('path', 'bytes', 'sha256')}, 'decoded': stored['original'], 'byte_identical_to_initial_original': True, 'deterministic_recompression_equal': True, 'mtime_zero_and_no_embedded_filename': True})
check = subprocess.run(['git', 'check-ignore', '--stdin'], input='\n'.join(added) + '\n', cwd=ROOT, text=True, capture_output=True)
assert check.returncode == 1 and not check.stdout and not check.stderr
for row in after:
    source = ROOT / row['path']
    target = OUT / 'after' / row['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
diff = subprocess.run(['git', 'diff', '--', 'tests/test_benzoyl_authority.py', 'tests/fixtures/benzoyl_authority'], cwd=ROOT, capture_output=True, check=True)
(OUT / 'working-tree.patch').write_bytes(diff.stdout)
result = {
    'issue': 'https://github.com/CultureBotAI/PathwayMech/issues/593',
    'before': before['bounded_files'], 'after': after,
    'change_scope': {'modified': changed, 'removed': removed, 'added': added},
    'lossless_recovery': recovery,
    'protected_inventory_unchanged': {'files': len(protected_after), 'roots': ['src', 'data', 'conf', 'pages', 'reviews'], 'sha256': sha(json.dumps(protected_after, sort_keys=True, separators=(',', ':')).encode())},
    'git_index_unchanged': before['git_index'],
    'new_files_are_not_ignored': True,
    'preserved_original_failure': {'path': 'actual-staged-whitespace.json', 'sha256': sha((OUT / 'actual-staged-whitespace.json').read_bytes()), 'source_unchanged': (OUT / 'actual-staged-whitespace.json').read_bytes() == Path('/private/tmp/pathwaymech-next-266-ci/actual-staged-whitespace.json').read_bytes()},
    'enumeration_scope': 'Path.rglob includes hidden and ignored files. No raw XML remains within the bounded fixture directory; the retained before snapshot and eight exact gzip objects preserve every original byte.',
    'publication_limit': 'No staging or GitHub mutation. git diff --check passed for the working-tree diff. The actual staged index still contains the earlier originals and must be updated and checked by root before commit.',
}
(OUT / 'result-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': 'exact bounded proof passed', 'recovered_originals': len(recovery), 'protected_files_unchanged': len(protected_after), 'index_unchanged': True, 'new_files_not_ignored': True}))
