"""Lossless deterministic packaging of the eight existing XML originals."""
from pathlib import Path
import gzip
import hashlib
import io
import json

ROOT = Path('/private/tmp/pathwaymech-next-266-20261015')
OUT = Path(__file__).resolve().parent
FIXTURE = ROOT / 'tests/fixtures/benzoyl_authority'


def sha(body):
    return hashlib.sha256(body).hexdigest()


rows = json.loads((FIXTURE / 'manifest.json').read_text())
logical = {row['entry']['path'] for row in rows}
assert len(logical) == len(rows) == 8
assert {p.name for p in FIXTURE.rglob('*.xml')} == logical
preserved = {name: (FIXTURE / name).read_bytes() for name in ('manifest.json', 'acquisition.json')}
storage = {'version': 1, 'encoding': 'gzip', 'mtime': 0, 'files': {}}
for row in rows:
    name = row['entry']['path']
    source = FIXTURE / name
    body = source.read_bytes()
    assert body == (OUT / 'before/tests/fixtures/benzoyl_authority' / name).read_bytes()
    assert len(body) == row['original']['bytes']
    assert sha(body) == row['original']['sha256'] == row['entry']['sha256']
    target = source.with_suffix('.xml.gz')
    assert not target.exists()
    compressed = io.BytesIO()
    with gzip.GzipFile(filename='', fileobj=compressed, mode='wb', compresslevel=9, mtime=0) as gz:
        gz.write(body)
    result = compressed.getvalue()
    assert result[3] == 0 and result[4:8] == b'\x00' * 4
    assert gzip.decompress(result) == body
    target.write_bytes(result)
    storage['files'][name] = {'path': target.name, 'bytes': len(result), 'sha256': sha(result), 'original': row['original']}
assert not (FIXTURE / 'storage.json').exists()
(FIXTURE / 'storage.json').write_text(json.dumps(storage, indent=2) + '\n')
for name in logical:
    source = FIXTURE / name
    assert gzip.decompress((FIXTURE / storage['files'][name]['path']).read_bytes()) == source.read_bytes()
    source.unlink()
for name, body in preserved.items():
    assert (FIXTURE / name).read_bytes() == body
print(json.dumps({'converted': len(rows), 'decoded_bytes': sum(row['original']['bytes'] for row in rows), 'compressed_bytes': sum(row['bytes'] for row in storage['files'].values()), 'provenance_files_preserved': list(preserved)}))
