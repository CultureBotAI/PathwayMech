"""Run only the affected test module, repository lint, and working-tree diff check."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/private/tmp/pathwaymech-next-266-20261015')
OUT = Path(__file__).resolve().parent
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', PYTHONPATH=f'{ROOT}/src:{ROOT}')
commands = [
    ('affected-tests', [PYTHON, '-B', '-m', 'pytest', 'tests/test_benzoyl_authority.py', '-q', '-p', 'no:cacheprovider', '--basetemp=/private/tmp/pathwaymech-next-266-fixture-storage-test-tmp']),
    ('lint', [PYTHON, '-B', '-m', 'ruff', 'check', '.', '--no-cache']),
    ('working-tree-diff-check', ['git', 'diff', '--check']),
]
receipts = []
for name, command in commands:
    assert not (OUT / f'{name}.stdout').exists()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    timer = time.monotonic()
    with (OUT / f'{name}.stdout').open('wb') as stdout, (OUT / f'{name}.stderr').open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    receipt = {'name': name, 'command': command, 'cwd': str(ROOT), 'environment': {k: env[k] for k in ('PYTHONDONTWRITEBYTECODE', 'PYTHONNOUSERSITE', 'PYTHONPATH')}, 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'elapsed_seconds': round(time.monotonic() - timer, 3), 'exit_code': result.returncode}
    for stream in ('stdout', 'stderr'):
        body = (OUT / f'{name}.{stream}').read_bytes()
        receipt[stream] = {'path': f'{name}.{stream}', 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
    receipts.append(receipt)
    (OUT / 'command-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(json.dumps({'name': name, 'exit_code': result.returncode, 'elapsed_seconds': receipt['elapsed_seconds']}), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
