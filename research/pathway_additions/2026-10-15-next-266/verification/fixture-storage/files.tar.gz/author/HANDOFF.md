# Lossless benzoyl fixture storage fix

Issue: https://github.com/CultureBotAI/PathwayMech/issues/593

The concrete fix is implemented in `/private/tmp/pathwaymech-next-266-20261015` and ready for root's independent review and staging.

All eight exact XML fixture files under `tests/fixtures/benzoyl_authority` are now deterministic gzip objects (compression level 9, modification time zero, no embedded filename). The 106,540 decoded bytes are identical to the initial XML originals; compressed storage totals 22,555 bytes. No XML whitespace was stripped. The new `storage.json` maps each logical original name to its compressed path, size and SHA-256, and the decoded original size and SHA-256. The existing `manifest.json` and `acquisition.json` are byte-exact.

`tests/test_benzoyl_authority.py` now verifies compressed size/hash, decodes and verifies raw size/hash against both storage metadata and the original manifest, and materializes the original XML names in pytest's temporary directory. Its two direct fixture comparisons use decoded, verified originals. Existing mutation/adversarial test behavior is preserved. The fixture README explains storage and decoding.

Validation completed with the established safe runtime and required environment:

- Full affected module: **234 passed in 7.65s** (`affected-tests.stdout`).
- Full repository Ruff: **passed** (`lint.stdout`), equivalent to the lint recipe's Ruff invocation without dependency synchronization.
- `git diff --check`: **passed for the working-tree diff**.
- Exact roundtrip and deterministic recompression: **8/8 passed**.
- All **979** files under `src`, `data`, `conf`, `pages` and `reviews` remain unchanged.
- The Git index remains unchanged; all nine new gzip/storage files are not ignored.

`initial-inventory.json`, the complete 12-file `before/` snapshot, the complete 13-file `after/` snapshot and `result-proof.json` bind the precise change. The only modifications are the test module and fixture README; eight raw fixture paths are removed and eight gzip paths plus `storage.json` are added. The proof enumerations include hidden and ignored files. `command-receipts.json` records exact commands, environment, exit codes, timing and log hashes. The original failing `actual-staged-whitespace.json` is preserved verbatim and its source remains unchanged. `working-tree.patch` captures tracked edits; the full after snapshot and inventory also cover new files omitted by ordinary unstaged diff.

No production code, records, registries, pages, reviews or native history were changed. No Git staging, commits or GitHub operations were performed. The actual staged index still contains the previous raw originals; root must stage the bounded replacement and rerun the actual staged whitespace check before commit. The full suite was not rerun.

The proof packet deliberately preserves raw originals with their trailing spaces in `before/`; use the established portable archive plus manifest approach if retaining this packet in the repository, rather than introducing those raw snapshots as new text files.
