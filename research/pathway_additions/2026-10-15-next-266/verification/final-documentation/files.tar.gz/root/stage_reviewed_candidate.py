"""Stage the exact reviewed candidate and verify actual index bytes."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
CHECKS = Path('/private/tmp/pathwaymech-next-266-checks-final-documentation')
BASE = 'dd780ef273323efd638eacd63625963062e0b105'
BRANCH = 'feat/pathway-next-266-20261015'
REPORT = 'research/pathway_additions/2026-10-15-next-266/'


def run(*args, **kwargs):
    return subprocess.run(list(args), cwd=ROOT, capture_output=True, check=True, **kwargs)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def main():
    receipt = CI / 'reviewed-candidate-stage.json'
    assert not receipt.exists()
    assert run('git', 'rev-parse', 'HEAD', text=True).stdout.strip() == BASE
    assert run('git', 'branch', '--show-current', text=True).stdout.strip() == BRANCH
    assert json.loads((CHECKS / 'final-input-preservation.json').read_text())['all_unchanged']
    assert all(row['exit_code'] == 0 for row in json.loads((CHECKS / 'receipts.json').read_text()))
    checked = json.loads((CHECKS / 'checked-input-hashes.json').read_text())
    for name, digest in checked.items():
        assert sha(ROOT / name) == digest, name
    run('git', 'diff', '--cached', '--quiet')
    changed = {p.decode() for p in run('git', 'diff', '--name-only', '-z', BASE).stdout.split(b'\0') if p}
    untracked = {p.decode() for p in run('git', 'ls-files', '--others', '--exclude-standard', '-z').stdout.split(b'\0') if p}
    paths = sorted(changed | untracked)
    archival_additions = {REPORT + 'verification/final-documentation/' + name for name in
                         ['README.md', 'files.tar.gz', 'source-file-manifest.json', 'artifact-manifest.json']}
    assert set(paths) - set(checked) == archival_additions
    final_archive = ROOT / REPORT / 'verification/final-documentation'
    for row in json.loads((final_archive / 'artifact-manifest.json').read_text())['files']:
        assert sha(final_archive / row['path']) == row['sha256']
    exact = {
        'conf/identifier_sources.json', 'data/identifier_authorities/ontology.json',
        'data/identifier_authorities/sources.json', 'docs/IDENTIFIERS.md',
        'scripts/build_source_identifier_snapshot.py', 'src/pathwaymech/identifiers.py',
        'src/pathwaymech/biocyc_benzoyl.py', 'tests/test_benzoyl_authority.py',
        'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml',
        'pages/browse.html', 'pages/index.html', 'pages/pathway_index.json',
        'pages/downloads/edges.tsv', 'pages/downloads/nodes.tsv', 'pages/downloads/manifest.json',
        'pages/records/MetaCyc_CENTBENZCOA-PWY.html',
    }
    prefixes = (
        REPORT, 'tests/fixtures/benzoyl_authority/',
        'history/infrastructure/benzoyl-authority-profiles/',
        'history/other/benzoyl-coa-anaerobic-research/',
        'history/records/benzoyl-coa-degradation-ii-anaerobic/',
    )
    reviews = json.loads((CHECKS / 'final-input-preservation.json').read_text())['review_bundles']
    assert len(reviews) == 2
    exact.update(folder + '/' + name for folder in reviews for name in ['review.yaml', 'review.md'])
    assert all(p in exact or p.startswith(prefixes) for p in paths)
    assert exact <= set(paths), sorted(exact - set(paths))
    all_report_files = set()
    for parent, dirs, files in os.walk(ROOT / REPORT, followlinks=False):
        for name in dirs:
            assert not (Path(parent) / name).is_symlink()
        for name in files:
            p = Path(parent) / name
            assert p.is_file() and not p.is_symlink()
            all_report_files.add(str(p.relative_to(ROOT)))
    assert all_report_files <= set(paths), sorted(all_report_files - set(paths))
    rows = []
    for name in paths:
        p = ROOT / name
        assert p.is_file() and not p.is_symlink()
        data = p.read_bytes()
        assert len(data) < 100 * 1024 * 1024, name
        rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                     'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
    pathspec = CI / 'reviewed-candidate-pathspec.nul'
    with pathspec.open('xb') as stream:
        stream.write(b''.join(name.encode() + b'\0' for name in paths))
    write(CI / 'reviewed-candidate-inputs.json', {'base': BASE, 'branch': BRANCH, 'files': rows,
          'all_report_files_including_hidden_ignored': len(all_report_files)})
    command = ['git', '--literal-pathspecs', 'add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul']
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    write(CI / 'stage-command.json', {'observed_at': datetime.now(timezone.utc).isoformat(),
        'command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, result.stderr
    staged = {p.decode() for p in run('git', 'diff', '--cached', '--name-only', '-z', BASE).stdout.split(b'\0') if p}
    assert staged == set(paths)
    index = {}
    for raw in run('git', 'ls-files', '--stage', '-z').stdout.split(b'\0'):
        if not raw:
            continue
        metadata, name = raw.split(b'\t', 1)
        name = name.decode()
        if name in staged:
            mode, oid, stage = metadata.decode().split()
            assert stage == '0' and mode in ('100644', '100755'), name
            index[name] = oid
    assert len(index) == len(paths)
    for row in rows:
        assert index[row['path']] == row['git_blob']
        assert sha(ROOT / row['path']) == row['sha256']
    whitespace = subprocess.run(['git', 'diff', '--cached', '--check'], cwd=ROOT, text=True, capture_output=True)
    write(CI / 'actual-staged-whitespace.json', {'observed_at': datetime.now(timezone.utc).isoformat(),
        'command': ['git', 'diff', '--cached', '--check'], 'exit_code': whitespace.returncode,
        'stdout': whitespace.stdout, 'stderr': whitespace.stderr})
    assert whitespace.returncode == 0, whitespace.stdout
    run('git', 'diff', '--quiet')
    tree = run('git', 'write-tree', text=True).stdout.strip()
    write(receipt, {'observed_at': datetime.now(timezone.utc).isoformat(), 'base': BASE, 'branch': BRANCH,
        'staged_files': len(paths), 'index_tree': tree, 'all_index_bytes_match_reviewed_files': True,
        'staged_whitespace_exit_code': 0, 'largest_blob_bytes': max(r['bytes'] for r in rows),
        'total_staged_file_bytes': sum(r['bytes'] for r in rows),
        'inputs_manifest_sha256': sha(CI / 'reviewed-candidate-inputs.json')})
    print(receipt.read_text(), flush=True)


if __name__ == '__main__':
    main()
