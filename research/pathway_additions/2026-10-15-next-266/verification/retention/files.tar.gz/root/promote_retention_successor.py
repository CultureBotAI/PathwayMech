"""Adopt only the exact independently accepted retention successor payload."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

REPO = Path('/private/tmp/pathwaymech-next-266-20261015')
CI = Path('/private/tmp/pathwaymech-next-266-ci')
STAGE = Path('/private/tmp/pathwaymech-next-266-retention-successor/payload')
DEST = REPO / 'research/pathway_additions/2026-10-15-next-266/evidence-retention'
PYTHON = '/private/tmp/pathwaymech-next-263-verified-venv/bin/python'
PIN = '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98'


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def bind(path):
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def save(path, document):
    with path.open('x') as handle:
        json.dump(document, handle, indent=2)
        handle.write('\n')


def main():
    accepted_path = CI / 'independent-retention-successor-root-intake.json'
    accepted = json.loads(accepted_path.read_text())
    assert accepted['status'] == 'accepted bounded retention provenance successor'
    assert accepted['new_findings'] == 0 and accepted['issue'] == 591
    for key in ['manifest', 'handoff', 'assessment', 'freeze']:
        row = accepted[key]
        assert digest(Path(row['path'])) == row['sha256']
    assert digest(STAGE / 'artifact-manifest.json') == PIN
    assert not os.path.lexists(DEST)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == 'dd780ef273323efd638eacd63625963062e0b105'
    assert subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'feat/pathway-next-266-20261015'
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1')
    plan_command = [PYTHON, '-B', str(STAGE / 'plan_promotion.py'), '--stage', str(STAGE), '--expected-stage-manifest-sha256', PIN, '--target-repo', str(REPO)]
    plan_stdout = CI / 'retention-successor-actual-plan.json'
    plan_stderr = CI / 'retention-successor-actual-plan.stderr'
    with plan_stdout.open('x') as output, plan_stderr.open('x') as errors:
        result = subprocess.run(plan_command, cwd=REPO, env=env, stdout=output, stderr=errors)
    save(CI / 'retention-successor-actual-plan-execution.json', {'command': plan_command, 'exit_code': result.returncode, 'stdout': bind(plan_stdout), 'stderr': bind(plan_stderr)})
    assert result.returncode == 0
    plan = json.loads(plan_stdout.read_text())
    assert Path(plan['destination']) == DEST and plan['stage_manifest_sha256'] == PIN
    rows = plan['copy_exact_relative_paths']
    assert len(rows) == 3343 and len({row['path'] for row in rows}) == len(rows)
    for row in rows:
        name = Path(row['path'])
        assert not name.is_absolute() and '..' not in name.parts
        assert not (STAGE / name).is_symlink() and (STAGE / name).is_file()
        assert row['bytes'] < 100 * 1024 * 1024
    ignored = subprocess.run(['git', 'check-ignore', '--no-index', '-z', '--stdin'], cwd=REPO, capture_output=True,
        input=b''.join(str((DEST / row['path']).relative_to(REPO)).encode() + b'\0' for row in rows))
    assert ignored.returncode == 1 and not ignored.stdout
    copied = []
    started = datetime.now(timezone.utc).isoformat()
    for row in rows:
        source, target = STAGE / row['path'], DEST / row['path']
        assert digest(source) == row['sha256'] and source.stat().st_size == row['bytes']
        target.parent.mkdir(parents=True, exist_ok=True)
        assert target.resolve().is_relative_to(REPO.resolve())
        with source.open('rb') as input_handle, target.open('xb') as output:
            while block := input_handle.read(1024 * 1024):
                output.write(block)
        assert digest(target) == row['sha256'] and target.stat().st_size == row['bytes']
        copied.append({'path': str(target.relative_to(REPO)), 'sha256': row['sha256'], 'bytes': row['bytes']})
    save(CI / 'retention-successor-actual-copy.json', {'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(), 'acceptance': bind(accepted_path), 'plan': bind(plan_stdout), 'copied': copied})
    commands = [
        ('physical', [PYTHON, '-B', str(DEST / 'decode_retained.py'), '--root', str(DEST), '--repo', str(REPO), '--verify-all', '--working-tree-owners']),
        ('compact', [PYTHON, '-B', str(DEST / 'verify_compact.py'), '--root', str(DEST), '--repo', str(REPO), '--verify-all']),
        ('provenance', [PYTHON, '-B', str(DEST / 'verify_inherited_provenance.py'), '--root', str(DEST), '--repo', str(REPO)]),
    ]
    observations = []
    for label, argv in commands:
        stdout = CI / f'maintained-retention-{label}.json'
        stderr = CI / f'maintained-retention-{label}.stderr'
        clock = time.monotonic()
        with stdout.open('x') as output, stderr.open('x') as errors:
            result = subprocess.run(argv, cwd=REPO, env=env, stdout=output, stderr=errors)
        item = {'name': label, 'argv': argv, 'exit_code': result.returncode, 'seconds': round(time.monotonic() - clock, 2), 'stdout': bind(stdout), 'stderr': bind(stderr)}
        save(CI / f'maintained-retention-{label}-execution.json', item)
        assert result.returncode == 0
        assert json.loads(stdout.read_text())['status'] == 'passed'
        observations.append(item)
        print(json.dumps(item), flush=True)
    expected = {row['path'] for row in rows}
    assert {p.relative_to(DEST).as_posix() for p in DEST.rglob('*') if p.is_file()} == expected
    for row in rows:
        assert digest(DEST / row['path']) == row['sha256']
    integration = json.loads((CI / 'maintained-record-integration.json').read_text())
    for row in integration['all262_previous_record_bytes_preserved']:
        assert digest(REPO / row['path']) == row['sha256']
    receipt = {'observed_at': datetime.now(timezone.utc).isoformat(), 'status': 'accepted retention successor promoted and actual maintained physical/compact/provenance checks passed', 'issue': 591, 'source_manifest_sha256': PIN, 'destination': str(DEST.relative_to(REPO)), 'copied_files': len(rows), 'copy_proof': bind(CI / 'retention-successor-actual-copy.json'), 'acceptance': bind(accepted_path), 'checks': observations, 'all262_previous_record_bytes_preserved': True, 'scope': 'Actual create-only3343file adoption and full maintained reader replay. Issue closure requires later verified publication; full production gates and canonical reviews remain separate.'}
    save(CI / 'retention-successor-promotion.json', receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k != 'checks'}), flush=True)


if __name__ == '__main__':
    main()
