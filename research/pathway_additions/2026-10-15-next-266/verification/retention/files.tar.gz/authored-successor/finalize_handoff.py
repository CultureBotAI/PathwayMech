"""Check exact successor scope and freeze the external handoff after rehearsal."""

import copy
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path("/private/tmp/pathwaymech-next-266-retention-successor")
OLD = Path("/private/tmp/pathwaymech-next-266-retention-preparation")


def sha(body):
    return hashlib.sha256(body).hexdigest()


def dump(path, value):
    with path.open("x") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + "\n")


def inventory(root):
    paths = list(root.rglob("*"))
    assert not any(p.is_symlink() for p in paths)
    return {str(p.relative_to(root)): p for p in paths if p.is_file()}


def main():
    payload = ROOT / "payload"
    freeze = json.loads((ROOT / "payload-freeze.json").read_bytes())
    manifest = (payload / "artifact-manifest.json").read_bytes()
    assert sha(manifest) == freeze["payload_manifest_sha256"]
    expected = {r["path"]: r for r in json.loads(manifest)["files"]}
    assert set(inventory(payload)) == set(expected) | {"artifact-manifest.json"}
    for path, row in expected.items():
        body = (payload / path).read_bytes()
        assert sha(body) == row["sha256"] and len(body) == row["bytes"]
    original_rows = json.loads((ROOT / "original-preparation-inventory.json").read_bytes())["files"]
    assert set(inventory(OLD)) == {r["path"] for r in original_rows}
    for row in original_rows:
        body = (OLD / row["path"]).read_bytes()
        assert sha(body) == row["sha256"] and len(body) == row["bytes"]
    changed = []
    retained = []
    for path, original in sorted(inventory(OLD / "payload").items()):
        body = original.read_bytes()
        current = (payload / path).read_bytes()
        row = {
            "path": path,
            "original_sha256": sha(body),
            "original_bytes": len(body),
            "successor_sha256": sha(current),
            "successor_bytes": len(current),
        }
        (changed if body != current else retained).append(row)
    assert {r["path"] for r in changed} == {
        "README.md",
        "artifact-manifest.json",
        "content-map.json",
        "plan_promotion.py",
    }
    old_content = json.loads((OLD / "payload/content-map.json").read_bytes())
    new_content = json.loads((payload / "content-map.json").read_bytes())
    reverse = copy.deepcopy(new_content)
    corrections = json.loads((payload / "provenance-successor/correction.json").read_bytes())
    for row in corrections["changed_fields"]:
        reverse[row["source_sha256"]]["storage"]["git_tree"] = row["before"]
    assert old_content == reverse
    rehearsal = json.loads((ROOT / "guarded-copy-and-reconstruction.json").read_bytes())
    assert rehearsal["status"] == "passed"
    assert rehearsal["payload_manifest_sha256"] == sha(manifest)
    assert sum(r["physical_files"] for r in rehearsal["physical_reconstruction"]) == 7337
    assert (
        sum(r["logical_occurrences"] for r in rehearsal["compact_only_logical_reconstruction"])
        == 1334
    )
    predecessor = json.loads((ROOT / "copied-predecessor-reconstruction.stdout").read_bytes())
    assert predecessor["complete_original_preparation_files"] == 3357
    assert "All checks passed!" in (ROOT / "ruff-final-check.stdout").read_text()
    assert "already formatted" in (ROOT / "ruff-final-format.stdout").read_text()
    dump(
        ROOT / "final-scope-verification.json",
        {
            "status": "passed",
            "original_preparation_files_still_exact": len(original_rows),
            "unchanged_original_payload_files": retained,
            "changed_original_payload_files": changed,
            "all_scientific_source_content_and_metadata_unchanged_except_586_tree_fields": True,
            "new_payload_files": sorted(set(inventory(payload)) - set(inventory(OLD / "payload"))),
            "original_to_successor_full_history_map": (
                "payload/provenance-successor/predecessor-map.json"
            ),
            "scientific_source_occurrences": 7337,
            "logical_only_original_occurrences": 1334,
            "compact_rows": 4339,
            "packages": 17,
            "selected_snapshots": 28,
            "complete_predecessor_reconstruction": predecessor,
            "promotion_performed": False,
            "independent_acceptance_pending": True,
        },
    )
    (ROOT / "HANDOFF.md").write_text((ROOT / "HANDOFF-template.md").read_text())
    rows = []
    for relative, path in sorted(inventory(ROOT).items()):
        assert relative not in ("artifact-manifest.json", "freeze-proof.json")
        body = path.read_bytes()
        rows.append({"path": relative, "sha256": sha(body), "bytes": len(body)})
    dump(
        ROOT / "artifact-manifest.json",
        {
            "scope": "Every physical outer successor file, including hidden and ignored files, "
            "except this self-manifest and final freeze proof.",
            "files": rows,
        },
    )
    dump(
        ROOT / "freeze-proof.json",
        {
            "status": "frozen",
            "timestamp": datetime.now(UTC).isoformat(),
            "artifact_manifest_sha256": sha((ROOT / "artifact-manifest.json").read_bytes()),
            "listed_artifacts": len(rows),
            "physical_artifacts": len(rows) + 2,
            "payload_manifest_sha256": sha(manifest),
            "payload_physical_files": len(expected) + 1,
            "issue": "https://github.com/CultureBotAI/PathwayMech/issues/591",
            "originals_modified": False,
            "maintained_promotion_performed": False,
            "independent_successor_acceptance_pending": True,
        },
    )


if __name__ == "__main__":
    main()
