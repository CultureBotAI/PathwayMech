"""Freeze the completed independent original-retention assessment."""
import hashlib
import json
import os
import stat
from datetime import UTC, datetime
from pathlib import Path

root = Path('/private/tmp/pathwaymech-next-266-independent-retention-review')
assert not (root / 'artifact-manifest.json').exists()
assert not (root / 'freeze-proof.json').exists()
assert json.loads((root / 'independent-full-audit.json').read_bytes())['status'] == 'passed'
assert json.loads((root / 'independent-helper-probes.json').read_bytes())['status'] == 'passed'
assert json.loads((root / 'independent-materialization-controls.json').read_bytes())['status'] == 'passed'
assert len(json.loads((root / 'review-status.json').read_bytes())['findings']) == 1
rows = []
for current, dirs, names in os.walk(root, followlinks=False):
    for name in dirs + names:
        path = Path(current) / name
        mode = path.lstat().st_mode
        assert stat.S_ISDIR(mode) or stat.S_ISREG(mode)
        if stat.S_ISREG(mode):
            b = path.read_bytes()
            rows.append({'path': path.relative_to(root).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
rows.sort(key=lambda r: r['path'])
manifest = {'scope': 'Every physical independent review artifact including hidden/ignored files, except this self-manifest and final freeze proof.', 'files': rows}
(root / 'artifact-manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
proof = {'status': 'frozen', 'timestamp': datetime.now(UTC).isoformat(), 'artifact_manifest_sha256': hashlib.sha256((root / 'artifact-manifest.json').read_bytes()).hexdigest(), 'listed_artifacts': len(rows), 'physical_artifacts': len(rows) + 2, 'handoff_sha256': hashlib.sha256((root / 'HANDOFF.md').read_bytes()).hexdigest(), 'assessment_sha256': hashlib.sha256((root / 'ASSESSMENT.md').read_bytes()).hexdigest(), 'complete_original_byte_retention_verified': True, 'findings': ['N266-RET-PROV-01'], 'promotion_accepted': False, 'pending': 'Explicit provenance successor and independent acceptance; maintained adoption and later production workflow remain separate.', 'source_or_maintained_mutations': False}
(root / 'freeze-proof.json').write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
print(json.dumps({**proof, 'freeze_sha256': hashlib.sha256((root / 'freeze-proof.json').read_bytes()).hexdigest()}, indent=2))
