"""Independent negative probes of exact frozen live helpers in isolated copies."""
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

OUT = Path('/private/tmp/pathwaymech-next-266-independent-retention-review')
SOURCE = Path('/private/tmp/pathwaymech-next-266-retention-preparation/payload')
REPO = Path('/private/tmp/pathwaymech-next-266-20261015')
TMP = Path(tempfile.mkdtemp(prefix='next266-independent-retention-probes-', dir='/private/tmp'))
PYTHON = sys.executable
results = []


def sha(b):
    return hashlib.sha256(b).hexdigest()


def run(name, argv, expected=0, outbytes=None):
    result = subprocess.run([PYTHON, '-B', *map(str, argv)], capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'})
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    assert (result.returncode == 0) == (expected == 0), (name, result.returncode, result.stderr.decode())
    if outbytes is not None:
        assert result.stdout == outbytes
    results.append({'name': name, 'command': [PYTHON, '-B', *map(str, argv)], 'exit_code': result.returncode, 'expected': 'success' if expected == 0 else 'reject', 'stdout_sha256': sha(result.stdout), 'stderr_sha256': sha(result.stderr)})


# Execute the real unmodified helpers over the complete real package first.
run('physical-cli-independent', [SOURCE / 'decode_retained.py', '--root', SOURCE, '--repo', REPO, '--verify-all', '--compare-originals'])
run('compact-cli-independent', [SOURCE / 'verify_compact.py', '--root', SOURCE, '--repo', REPO, '--verify-all'])
run('planner-cli-independent', [SOURCE / 'plan_promotion.py', '--stage', SOURCE, '--target-repo', REPO, '--expected-stage-manifest-sha256', '7240d8b0ea50e77018330a3ff67c3d7acda65878c23d33b034fe6ff7aaaa49ae'])
print('All three complete unmodified helper commands passed', flush=True)

# Copy all bytes, without hard links, before mutating only our private transient input.
copy = TMP / 'payload'
shutil.copytree(SOURCE, copy)
expected = {p.relative_to(SOURCE).as_posix(): sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()}
assert {p.relative_to(copy).as_posix(): sha(p.read_bytes()) for p in copy.rglob('*') if p.is_file()} == expected
mapping = json.loads((copy / 'content-map.json').read_bytes())
source_map_path = copy / 'packages/root-intake-and-issue-evidence/source-map.json'
source_map_bytes = source_map_path.read_bytes()
source_map = json.loads(source_map_bytes)
selected = next(r for r in source_map['source_occurrences'] if mapping[r['sha256']]['storage']['kind'] == 'new_retention_object')
common = [copy / 'decode_retained.py', '--root', copy, '--repo', REPO]
read = [*common, '--package', 'root-intake-and-issue-evidence', '--artifact', selected['path']]
run('selected-artifact-control', read, outbytes=Path(selected['source']).read_bytes())
endpoint = copy / mapping[selected['sha256']]['storage']['path']
original = endpoint.read_bytes()
endpoint.write_bytes(original[:-1] + bytes([original[-1] ^ 1]))
run('negative-corrupt-endpoint', read, expected=1)
endpoint.write_bytes(original)
content_bytes = (copy / 'content-map.json').read_bytes()
changed = json.loads(content_bytes)
changed[selected['sha256']]['source_bytes'] += 1
(copy / 'content-map.json').write_text(json.dumps(changed))
run('negative-decoded-length', read, expected=1)
(copy / 'content-map.json').write_bytes(content_bytes)
run('negative-package-traversal', [*common, '--package', '../../outside', '--artifact', 'missing'], expected=1)
run('negative-absolute-package', [*common, '--package', '/private/tmp', '--artifact', 'missing'], expected=1)
run('negative-existing-materialization-target', [*common, '--package', 'root-intake-and-issue-evidence', '--materialize', TMP], expected=1)
run('negative-outside-materialization-target', [*common, '--package', 'root-intake-and-issue-evidence', '--materialize', '/var/tmp/next266-no-write'], expected=1)
# source-map path traversal cannot escape new external reconstruction root.
changed_map = json.loads(source_map_bytes)
changed_map['source_occurrences'][0]['path'] = '../must-not-exist'
source_map_path.write_text(json.dumps(changed_map))
run('negative-source-path-traversal', [*common, '--package', 'root-intake-and-issue-evidence', '--materialize', TMP / 'traversal-output'], expected=1)
assert not (TMP / 'must-not-exist').exists()
source_map_path.write_bytes(source_map_bytes)
# An escaped storage symlink must be rejected before reading it.
endpoint.unlink()
endpoint.symlink_to(SOURCE / mapping[selected['sha256']]['storage']['path'])
run('negative-storage-symlink-escape', read, expected=1)
endpoint.unlink()
endpoint.write_bytes(original)
run('negative-planner-wrong-manifest', [copy / 'plan_promotion.py', '--stage', copy, '--target-repo', REPO, '--expected-stage-manifest-sha256', '0' * 64], expected=1)
extra = copy / '.hidden-unlisted-input'
extra.write_bytes(b'unlisted')
run('negative-planner-hidden-extra', [copy / 'plan_promotion.py', '--stage', copy, '--target-repo', REPO, '--expected-stage-manifest-sha256', '7240d8b0ea50e77018330a3ff67c3d7acda65878c23d33b034fe6ff7aaaa49ae'], expected=1)
extra.unlink()
# Exact declared pair population must survive duplicates, omissions and row drift.
pairfile = copy / 'verified-compact-pairs.json'
pairbytes = pairfile.read_bytes()
pairs = json.loads(pairbytes)
compact = [copy / 'verify_compact.py', '--root', copy, '--repo', REPO, '--verify-all']
for name, mutation in [('missing-pair', pairs[:-1]), ('duplicate-pair', pairs + [pairs[0]])]:
    pairfile.write_text(json.dumps(mutation))
    run('negative-compact-' + name, compact, expected=1)
pairs[0]['declared_row']['sha256'] = '0' * 64
pairfile.write_text(json.dumps(pairs))
run('negative-compact-declared-row-drift', compact, expected=1)
pairfile.write_bytes(pairbytes)
# Existing destination should fail without any writes to the actual checkout.
# This is exercised by targeting a minimal isolated Git worktree substitute only through mocked git output? No: avoid simulation.
# The code's exact destination existence check was inspected; no fake repository claim is made here.
assert {p.relative_to(copy).as_posix(): sha(p.read_bytes()) for p in copy.rglob('*') if p.is_file()} == expected
assert {p.relative_to(SOURCE).as_posix(): sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()} == expected
receipt = {'status': 'passed', 'full_payload_copy_files': len(expected), 'source_files_unchanged_after_probes': True, 'commands': results, 'transient_owned_root': str(TMP), 'transient_copy_cleanup': 'Removed only this process-created isolated temporary root after complete hash restoration and proof.', 'limitations': 'The helpers assume trusted manifest/content-map metadata and ordinary Python without -O. This audit independently derived normalized compact rows; it does not claim general hostile-input hardening.'}
(OUT / 'independent-helper-probes.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
shutil.rmtree(TMP)
print('Independent helper controls and negative probes passed', flush=True)
