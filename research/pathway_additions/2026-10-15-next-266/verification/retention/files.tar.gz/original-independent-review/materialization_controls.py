"""Independently exercise one complete physical and one compact-only logical layout."""
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

source = Path('/private/tmp/pathwaymech-next-266-retention-preparation/payload')
repo = Path('/private/tmp/pathwaymech-next-266-20261015')
out = Path('/private/tmp/pathwaymech-next-266-independent-retention-review')
tmp = Path(tempfile.mkdtemp(prefix='next266-retention-materialization-', dir='/private/tmp'))
results = []
for name, helper, mode in [('independent-native-review', 'decode_retained.py', '--materialize'), ('merged-discovery-successor', 'verify_compact.py', '--materialize-logical')]:
    target = tmp / name
    command = [sys.executable, '-B', str(source / helper), '--root', str(source), '--repo', str(repo), '--package', name, mode, str(target)]
    r = subprocess.run(command, capture_output=True)
    (out / ('materialize-' + name + '.stdout')).write_bytes(r.stdout)
    (out / ('materialize-' + name + '.stderr')).write_bytes(r.stderr)
    assert r.returncode == 0, (name, r.stderr)
    if mode == '--materialize':
        rows = json.loads((source / 'packages' / name / 'source-map.json').read_bytes())['source_occurrences']
        expected = {r['path']: (r['sha256'], r['bytes']) for r in rows}
    else:
        rows = [r for r in json.loads((source / 'logical-originals.json').read_bytes()) if r['package'] == name]
        expected = {r['original_path']: (r['original_sha256'], r['original_bytes']) for r in rows}
    observed = {}
    for path in target.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            b = path.read_bytes()
            observed[path.relative_to(target).as_posix()] = (hashlib.sha256(b).hexdigest(), len(b))
    assert observed == expected
    results.append({'package': name, 'mode': mode, 'command': command, 'exit_code': r.returncode, 'materialized_files': len(observed), 'all_paths_hashes_sizes_exact': True})
(out / 'independent-materialization-controls.json').write_text(json.dumps({'status': 'passed', 'results': results, 'scope': 'Two complete selected layouts actually written and verified. Every source and logical byte across the entire retention was separately reconstructed in memory by the full independent audit.', 'transient_cleanup': str(tmp)}, indent=2) + '\n')
shutil.rmtree(tmp)
print('Both independent materialization controls passed')
