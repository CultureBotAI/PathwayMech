"""Independent byte-level audit of frozen next266 retention; source reads only."""
import collections
import gzip
import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

PREP = Path('/private/tmp/pathwaymech-next-266-retention-preparation')
ROOT = Path('/private/tmp/pathwaymech-next-266-retention-successor/payload')
OUT = Path('/private/tmp/pathwaymech-next-266-independent-retention-successor-review')
REPO = Path('/private/tmp/pathwaymech-next-266-20261015')
BASE = 'dd780ef273323efd638eacd63625963062e0b105'
TREE = '93edcbf621df2ca0551830151be39eed5ce21232'
DEST = 'research/pathway_additions/2026-10-15-next-266/evidence-retention'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def unique(pairs):
    obj = {}
    for key, value in pairs:
        assert key not in obj, ('duplicate JSON key', key)
        obj[key] = value
    return obj


def js(b):
    return json.loads(b, object_pairs_hook=unique)


def write(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def inventory(root):
    files = {}
    for current, dirs, names in os.walk(root, followlinks=False):
        for name in dirs + names:
            p = Path(current) / name
            mode = p.lstat().st_mode
            assert stat.S_ISDIR(mode) or stat.S_ISREG(mode), ('nonregular source', str(p), mode)
            if stat.S_ISREG(mode):
                files[p.relative_to(root).as_posix()] = p
    return files


def check(b, digest, size):
    assert sha(b) == digest and len(b) == size, (digest, size, sha(b), len(b))


def safe(root, relative):
    p = Path(relative)
    assert not p.is_absolute() and '..' not in p.parts
    result = root / p
    assert result.resolve().is_relative_to(root.resolve())
    return result


def manifest(root, name, digest, array, extras):
    b = (root / name).read_bytes()
    assert sha(b) == digest
    obj = js(b)
    rows = obj[array]
    paths = {r['path'] for r in rows}
    assert len(paths) == len(rows)
    files = inventory(root)
    assert set(files) == paths | set(extras), (str(root), set(files) ^ (paths | set(extras)))
    for row in rows:
        check(safe(root, row['path']).read_bytes(), row['sha256'], row['bytes'])
    return files


outer = manifest(PREP, 'artifact-manifest.json', '85aba0de3c3702eefc5f48d46f5e9b2ca6f0e3297ebcca9ae0c56b524bcf5d02', 'files', ['artifact-manifest.json', 'freeze-proof.json'])
payload = manifest(ROOT, 'artifact-manifest.json', '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98', 'files', ['artifact-manifest.json'])
assert len(outer) == 3357 and len(payload) == 3343
assert sha((PREP / 'HANDOFF.md').read_bytes()) == 'aa62e305ed3156da23811eeb10e56f45fe3a7f1900223ede4dffc3b23133d5a8'
assert sha((PREP / 'freeze-proof.json').read_bytes()) == 'fa5ca5938834d87ed92cc5512084c6a60467c1fbad7cf0f8007cab9dc7c426ea'
assert sha((PREP / 'promotion-files.json').read_bytes()) == '83bff987cc58fbb8981c4891c101ef5592184aa53d19e4f2dc9a40f83dc95d93'
print('Complete outer and payload inventory/hash verification passed', flush=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

assert git('rev-parse', BASE + '^{tree}').decode().strip() == TREE
subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, 'HEAD'], cwd=REPO, check=True)
current_head = git('rev-parse', 'HEAD').decode().strip()
# A single pinned object reader avoids mutable source capture and repeated processes.
batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
git_cache = {}
git_ids = {}

def git_body(path):
    if path not in git_cache:
        assert '\n' not in path and '\r' not in path
        safe(REPO, path)
        batch.stdin.write((BASE + ':' + path + '\n').encode())
        batch.stdin.flush()
        head = batch.stdout.readline().split()
        assert len(head) == 3 and head[1] == b'blob', (path, head)
        b = batch.stdout.read(int(head[2]))
        assert batch.stdout.read(1) == b'\n'
        assert hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest() == head[0].decode()
        git_cache[path] = b
        git_ids[path] = head[0].decode()
    return git_cache[path]

for row in js((PREP / 'baseline-capture.json').read_bytes())['files']:
    b = git_body(row['path'])
    check(b, row['sha256'], row['bytes'])
    assert b == (PREP / 'baseline' / row['path']).read_bytes()
    assert row['git_commit'] == BASE

inherited = {}
for kind in ['evidence-retention', 'evidence-extension']:
    prefix = 'research/pathway_additions/2026-10-15-next-265/' + kind
    owner_map = js(git_body(prefix + '/content-map.json'))
    for digest, row in owner_map.items():
        endpoint = dict(row['storage'])
        if endpoint['kind'] == 'new_retention_object':
            endpoint['path'] = prefix + '/' + endpoint['path']
        else:
            assert endpoint['kind'] == 'existing_repository'
        endpoint['kind'] = 'existing_repository'
        endpoint['git_commit'] = BASE
        inherited.setdefault(digest, (endpoint, row['decode_steps'], prefix + '/content-map.json'))
    for row in js(git_body(prefix + '/artifact-manifest.json'))['files']:
        endpoint = {'kind': 'existing_repository', 'path': prefix + '/' + row['path'], 'git_commit': BASE, 'stored_sha256': row['sha256'], 'stored_bytes': row['bytes']}
        inherited.setdefault(row['sha256'], (endpoint, [], prefix + '/artifact-manifest.json'))
for name in ['decode_retained.py']:
    assert (ROOT / name).read_bytes() == git_body('research/pathway_additions/2026-10-15-next-265/evidence-retention/' + name)

content = js((ROOT / 'content-map.json').read_bytes())
endpoints = {}
source_bytes = {}
for digest, row in content.items():
    assert digest == row['source_sha256']
    storage = row['storage']
    key = (storage['kind'], storage['path'])
    if key not in endpoints:
        if storage['kind'] == 'new_retention_object':
            b = safe(ROOT, storage['path']).read_bytes()
            assert storage['path'] == f"objects/{storage['stored_sha256'][:2]}/{storage['stored_sha256']}.gz"
            assert b.startswith(b'\x1f\x8b')
        else:
            assert storage['kind'] == 'existing_repository' and storage['git_commit'] == BASE
            b = git_body(storage['path'])
            assert safe(REPO, storage['path']).read_bytes() == b
        endpoints[key] = b
    b = endpoints[key]
    check(b, storage['stored_sha256'], storage['stored_bytes'])
    if storage['kind'] == 'existing_repository':
        if 'inherited_binding' in row:
            original_expected = inherited[digest]
            expected_endpoint = dict(original_expected[0])
            if 'git_tree' in expected_endpoint:
                expected_endpoint['git_tree'] = TREE
            expected = (expected_endpoint, *original_expected[1:])
            assert (storage, row['decode_steps'], row['inherited_binding']) == expected
        else:
            assert 'reuse' in row and row['decode_steps']
            compact_owner = content[row['decode_steps'][-1]['input_sha256']]
            assert storage == compact_owner['storage']
            assert row['decode_steps'][:-1] == compact_owner['decode_steps']
    for step in row['decode_steps']:
        assert step['encoding'] == 'gzip' and sha(b) == step['input_sha256']
        b = gzip.decompress(b)
        check(b, step['output_sha256'], step['output_bytes'])
    check(b, digest, row['source_bytes'])
    source_bytes[digest] = b
assert len(content) == 4757
assert sum(k[0] == 'existing_repository' for k in endpoints) == 502
assert sum(k[0] == 'new_retention_object' for k in endpoints) == 3141
assert {k[1] for k in endpoints if k[0] == 'new_retention_object'} == {p for p in payload if p.startswith('objects/')}
print('All distinct contents decoded; 502 Git and working-tree storage owners verified', flush=True)

owners = js((ROOT / 'existing-owner-verification.json').read_bytes())
assert len(owners) == 502 and len({r['path'] for r in owners}) == 502
for row in owners:
    check(git_body(row['path']), row['sha256'], row['bytes'])
    assert row['git_blob'] == git_ids[row['path']] and row['git_commit'] == BASE and row['git_tree'] == TREE
assert {r['path'] for r in owners} == {k[1] for k in endpoints if k[0] == 'existing_repository'}
write('captured-repository-read-dependencies.json', {'head': current_head, 'pinned_base': BASE, 'tree': TREE, 'owners': owners, 'live_worktree_owner_bytes_equal_pinned_git': True, 'live_owner_reads_released': True})

spec = js((ROOT / 'source-specification.json').read_bytes())
assert spec == js((PREP / 'source-specification.final.json').read_bytes())
assert len(spec['packages']) == 17 and len(spec['selected_root_snapshots']) == 28 and not spec['pending_packages']
observations = []
physical = {}
all_occurrences = []
manifest_candidates = []
for package in spec['packages']:
    name = package['name']
    origin = Path(package['source_root'])
    files = manifest(origin, package['manifest'], package['manifest_sha256'], package['manifest_array'], package['explicit_physical_extras'])
    assert len(files) == package['physical_artifacts']
    mapping = js((ROOT / 'packages' / name / 'source-map.json').read_bytes())
    rows = mapping['source_occurrences']
    assert len({r['path'] for r in rows}) == len(rows) and {r['path'] for r in rows} == set(files)
    assert mapping['source_manifest_sha256'] == package['manifest_sha256']
    physical[name] = {r['path']: r for r in rows}
    for row in rows:
        b = source_bytes[row['sha256']]
        check(b, row['sha256'], row['bytes'])
        assert Path(row['source']) == origin / row['path'] and b == files[row['path']].read_bytes()
        all_occurrences.append(row)
        if row['path'].endswith('.json'):
            try:
                obj = js(b)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if isinstance(obj, dict):
                arrays = [key for key, vals in obj.items() if isinstance(vals, list) and vals and isinstance(vals[0], dict) and any(k in vals[0] for k in ['gzip_path', 'stored_path', 'stored'])]
                if arrays:
                    manifest_candidates.append({'package': name, 'path': row['path'], 'arrays': arrays, 'declared_owner_map': row['path'] in {m['path'] for m in package['compact_maps']}})
    observations.append({'package': name, 'physical_files': len(rows), 'bytes': sum(r['bytes'] for r in rows), 'manifest_sha256': package['manifest_sha256'], 'all_current_originals_exact': True})
    print('Source layout and original-byte equality:', name, len(rows), flush=True)
extra = js((ROOT / 'packages/root-intake-and-issue-evidence/source-map.json').read_bytes())['source_occurrences']
assert extra == spec['selected_root_snapshots'] == js((ROOT / 'selected-extra-inputs.json').read_bytes())
for row in extra:
    assert source_bytes[row['sha256']] == Path(row['source']).read_bytes()
    check(source_bytes[row['sha256']], row['sha256'], row['bytes'])
all_occurrences.extend(extra)
assert len(all_occurrences) == 7337 and sum(r['bytes'] for r in all_occurrences) == 790042247
assert {r['sha256'] for r in all_occurrences} == set(content)
write('complete-source-layout-audit.json', {'packages': observations, 'selected_root_snapshots': extra, 'occurrences': len(all_occurrences), 'bytes': sum(r['bytes'] for r in all_occurrences), 'hidden_and_ignored_included': True, 'symlinks_and_nonregular_entries': 0})
write('all-depth-compact-map-candidate-audit.json', manifest_candidates)

pairs = js((ROOT / 'verified-compact-pairs.json').read_bytes())
index = {}
for pair in pairs:
    key = (pair['package'], pair['compact_map'], pair.get('array'), pair['index'])
    assert key not in index
    index[key] = pair
seen = set()
logical = []
map_results = []
for package in spec['packages']:
    for binding in package['compact_maps']:
        body = source_bytes[physical[package['name']][binding['path']]['sha256']]
        check(body, binding['sha256'], binding['bytes'])
        obj = js(body)
        assert sorted(obj) == binding['top_level_keys']
        arrays = [(binding['array'], binding['expected_rows'], binding['row_key_sets'])] + [(a['array'], a['expected_rows'], a['row_key_sets']) for a in binding['auxiliary_arrays']]
        for array, count, key_sets in arrays:
            rows = obj[array]
            assert len(rows) == count and sorted({tuple(sorted(r)) for r in rows}) == [tuple(x) for x in key_sets]
            for i, declared in enumerate(rows):
                key = (package['name'], binding['path'], None if array == binding['array'] else array, i)
                pair = index[key]
                seen.add(key)
                assert pair['declared_row'] == declared and pair['compact_map_sha256'] == binding['sha256']
                # Normalize from original key shape, independently of authored normalized rows.
                if array == 'already_compressed_originals':
                    names = ('path', 'sha256', 'bytes', 'path', 'sha256', 'bytes')
                    encoding = 'identity'
                elif 'gzip_path' in declared:
                    names = ('path', 'sha256', 'bytes', 'gzip_path', 'gzip_sha256', 'gzip_bytes')
                    encoding = 'gzip'
                elif 'original' in declared:
                    names = ('original', 'raw_sha256', 'raw_bytes', 'stored', 'stored_sha256', 'stored_bytes')
                    encoding = declared.get('encoding', 'gzip')
                else:
                    names = ('original_path', 'original_sha256', 'original_bytes', 'stored_path', 'stored_sha256', 'stored_bytes')
                    encoding = declared.get('encoding', declared.get('codec'))
                keys = ('original_path', 'original_sha256', 'original_bytes', 'stored_path', 'stored_sha256', 'stored_bytes')
                expected = dict(zip(keys, [declared[n] for n in names]))
                assert all(pair[k] == v for k, v in expected.items()) and pair['encoding'] == encoding
                owner = physical[package['name']][expected['stored_path']]
                stored = source_bytes[owner['sha256']]
                check(stored, expected['stored_sha256'], expected['stored_bytes'])
                assert encoding in ['identity', 'gzip']
                original = gzip.decompress(stored) if encoding == 'gzip' else stored
                check(original, expected['original_sha256'], expected['original_bytes'])
                present = expected['original_path'] in physical[package['name']]
                assert present == pair['original_physically_present']
                if present:
                    assert original == source_bytes[physical[package['name']][expected['original_path']]['sha256']]
                else:
                    logical.append(pair)
                for hkey, sizekey in [('existing_gzip_decoded_sha256', 'existing_gzip_decoded_bytes'), ('original_gzip_inner_decoded_sha256', 'original_gzip_inner_decoded_bytes'), ('original_inner_decoded_sha256', 'original_inner_decoded_bytes')]:
                    if hkey in declared:
                        check(gzip.decompress(original), declared[hkey], declared[sizekey])
                if 'decoded_sha256' in declared:
                    inner = gzip.decompress(original) if declared.get('existing_gzip_preserved') or array == 'already_compressed_originals' else original
                    assert sha(inner) == declared['decoded_sha256']
                    if 'decoded_bytes' in declared:
                        assert len(inner) == declared['decoded_bytes']
                for p in pair['preserved_original_gzip_payloads']:
                    check(gzip.decompress(original), p['sha256'], p['bytes'])
        map_results.append({'package': package['name'], 'path': binding['path'], 'rows_including_auxiliary': sum(n for _, n, _ in arrays), 'all_declarations_and_original_bytes_exact': True})
assert seen == set(index) and len(index) == 4339 and len(logical) == 1334
assert logical == js((ROOT / 'logical-originals.json').read_bytes())
write('independent-compact-audit.json', {'maps': map_results, 'rows': len(index), 'compact_only_rows': len(logical), 'compact_only_by_package': dict(collections.Counter(p['package'] for p in logical)), 'normalization_rederived_from_original_declarations': True, 'all_originals_and_inner_payloads_exact': True})

gzip_records = js((ROOT / 'gzip-payload-verification.json').read_bytes())
assert len({r['source_sha256'] for r in gzip_records}) == len(gzip_records) == 3086
assert {r['source_sha256'] for r in gzip_records} == {digest for digest, b in source_bytes.items() if b.startswith(b'\x1f\x8b')}
for row in gzip_records:
    b = source_bytes[row['source_sha256']]
    assert len(b) == row['source_bytes']
    steps = []
    while b.startswith(b'\x1f\x8b'):
        h = sha(b)
        b = gzip.decompress(b)
        steps.append({'input_sha256': h, 'encoding': 'gzip', 'output_sha256': sha(b), 'output_bytes': len(b)})
        assert len(steps) < 16
    assert steps == row['decode_steps']

promotion = js((ROOT.parent / 'promotion-files.json').read_bytes())
assert promotion['payload_manifest_sha256'] == '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98'
ops = promotion['operations']
assert len(ops) == len(payload) and len({r['destination'] for r in ops}) == len(ops)
assert {str(Path(r['source']).relative_to(ROOT)) for r in ops} == set(payload)
for row in ops:
    rel = Path(row['source']).relative_to(ROOT).as_posix()
    assert row['operation'] == 'create_new_no_overwrite' and row['destination'] == DEST + '/' + rel
    check(payload[rel].read_bytes(), row['sha256'], row['bytes'])
    assert row['bytes'] < 100 * 1024 * 1024
ignored = subprocess.run(['git', 'check-ignore', '--no-index', '-z', '--stdin'], cwd=REPO, input=b'\0'.join(r['destination'].encode() for r in ops) + b'\0', capture_output=True)
assert ignored.returncode == 1 and not ignored.stdout and not ignored.stderr
new = [b for k, b in endpoints.items() if k[0] == 'new_retention_object']
assert sum(map(len, new)) == 339264576 and max(map(len, new)) == 46024886
write('promotion-format-size-ignore-audit.json', {'operations': len(ops), 'complete_create_only_mapping': True, 'actual_git_ignore_exit': ignored.returncode, 'ignored_paths': [], 'max_payload_file_bytes': max(p.stat().st_size for p in payload.values()), 'new_endpoint_bytes': sum(map(len, new)), 'all_below_100_MiB': True, 'merged_baseline': BASE, 'current_head_observed': current_head})
batch.stdin.close()
assert batch.wait() == 0
write('independent-full-audit.json', {'status': 'passed', 'original_preparation_outer_listed': 3355, 'original_preparation_outer_physical': len(outer), 'payload_physical': len(payload), 'frozen_packages': 17, 'root_snapshots': 28, 'physical_source_occurrences': len(all_occurrences), 'distinct_source_contents': len(source_bytes), 'compact_map_versions': len(map_results), 'compact_rows': len(index), 'logical_only_occurrences': len(logical), 'existing_git_owners': 502, 'new_endpoints': 3141, 'source_gzip_representations_verified': len(gzip_records), 'current_originals_byte_equal': True, 'no_source_mutations': True})
print('Independent full audit passed', flush=True)
