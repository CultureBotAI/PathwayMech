"""Independent exact successor scope, history reconstruction and promotion audit."""
import copy
import difflib
import gzip
import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

NEW = Path('/private/tmp/pathwaymech-next-266-retention-successor')
OLD = Path('/private/tmp/pathwaymech-next-266-retention-preparation')
PRIOR = Path('/private/tmp/pathwaymech-next-266-independent-retention-review')
OUT = Path('/private/tmp/pathwaymech-next-266-independent-retention-successor-review')
REPO = Path('/private/tmp/pathwaymech-next-266-20261015')
ROOT = NEW / 'payload'
BASE = 'dd780ef273323efd638eacd63625963062e0b105'
TREE = '93edcbf621df2ca0551830151be39eed5ce21232'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def unique(pairs):
    o = {}
    for k, v in pairs:
        assert k not in o
        o[k] = v
    return o


def load(path):
    return json.loads(path.read_bytes(), object_pairs_hook=unique)


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def inv(root):
    d = {}
    for current, dirs, names in os.walk(root, followlinks=False):
        for name in dirs + names:
            p = Path(current) / name
            mode = p.lstat().st_mode
            assert stat.S_ISDIR(mode) or stat.S_ISREG(mode)
            if stat.S_ISREG(mode):
                d[p.relative_to(root).as_posix()] = p
    return d


def verify(root, digest, extra):
    m = root / 'artifact-manifest.json'
    assert sha(m.read_bytes()) == digest
    rows = load(m)['files']
    actual = inv(root)
    assert len({r['path'] for r in rows}) == len(rows)
    assert set(actual) == {r['path'] for r in rows} | set(extra)
    for row in rows:
        b = actual[row['path']].read_bytes()
        assert sha(b) == row['sha256'] and len(b) == row['bytes']
    return actual


newfiles = verify(NEW, 'a36faf523f60133a19a350dc0d2503efab91f147eb9bd0c3d075d149b834737a', ['artifact-manifest.json', 'freeze-proof.json'])
payload = verify(ROOT, '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98', ['artifact-manifest.json'])
oldfiles = verify(OLD, '85aba0de3c3702eefc5f48d46f5e9b2ca6f0e3297ebcca9ae0c56b524bcf5d02', ['artifact-manifest.json', 'freeze-proof.json'])
priorfiles = verify(PRIOR, 'c40e6aebaa78ece2254d3d574a9e71564c669a8f355b02944c737508e9134279', ['artifact-manifest.json', 'freeze-proof.json'])
assert len(newfiles) == 3448 and len(payload) == 3343 and len(oldfiles) == 3357 and len(priorfiles) == 72
for name, expected in [('HANDOFF.md', 'b8ff4c12271c577206bdf0035422c3c610550cd27b3a89b745b665405f44753f'), ('final-scope-verification.json', 'a37502a5b4ed98f9965766836fa047f9c767f8f2514de5511012fe38f441d533'), ('guarded-copy-and-reconstruction.json', '482e897b6a84b29c94227852f56e2f4657a857fab103ba6e4d181cd58aa92a01')]:
    assert sha((NEW / name).read_bytes()) == expected
original_payload = inv(OLD / 'payload')
assert set(original_payload).issubset(payload)
changed = {rel for rel, path in original_payload.items() if path.read_bytes() != payload[rel].read_bytes()}
assert changed == {'README.md', 'content-map.json', 'plan_promotion.py', 'artifact-manifest.json'}
additions = sorted(set(payload) - set(original_payload))
assert len(additions) == 109
assert all(r.startswith('provenance-successor/') or r in ['verify_inherited_provenance.py', 'reconstruct_predecessor.py'] for r in additions)
scope = load(NEW / 'final-scope-verification.json')
assert {r['path'] for r in scope['changed_original_payload_files']} == changed
assert set(scope['new_payload_files']) == set(additions)
for row in scope['changed_original_payload_files'] + scope['unchanged_original_payload_files']:
    for prefix, root in [('original', OLD / 'payload'), ('successor', ROOT)]:
        b = (root / row['path']).read_bytes()
        assert sha(b) == row[prefix + '_sha256'] and len(b) == row[prefix + '_bytes']
assert len(scope['unchanged_original_payload_files']) == 3230
oldmap, newmap = load(OLD / 'payload/content-map.json'), load(ROOT / 'content-map.json')
assert set(oldmap) == set(newmap)
expected = copy.deepcopy(oldmap)
changes = []
for digest, row in expected.items():
    s = row['storage']
    if s['kind'] == 'existing_repository' and 'git_tree' in s:
        assert s['git_commit'] == BASE and s['git_tree'] == 'e5c455667499283021774a6c3d5138cc8293f28e'
        changes.append({'source_sha256': digest, 'storage_path': s['path'], 'before': s['git_tree'], 'after': TREE})
        s['git_tree'] = TREE
assert expected == newmap and len(changes) == 586 and len({r['storage_path'] for r in changes}) == 301
correction = load(ROOT / 'provenance-successor/correction.json')
assert correction['changed_fields'] == changes
assert (ROOT / 'provenance-successor/finding-N266-RET-PROV-01.json').read_bytes() == (PRIOR / 'finding-N266-RET-PROV-01.json').read_bytes()
assert subprocess.check_output(['git', 'rev-parse', BASE + '^{tree}'], cwd=REPO).decode().strip() == TREE

oldcode = (OLD / 'prepare_retention.py').read_text()
newcode = (NEW / 'prepare_retention_corrected.py').read_text()
needle = '            endpoint["git_commit"] = BASE\n'
assert oldcode.count(needle) == 1
assert newcode == oldcode.replace(needle, needle + '            if "git_tree" in endpoint:\n                endpoint["git_tree"] = TREE\n')
assert newcode.encode() == (ROOT / 'provenance-successor/prepare_retention_corrected.py.txt').read_bytes()
(OUT / 'verified-generator-diff.patch').write_text(''.join(difflib.unified_diff(oldcode.splitlines(True), newcode.splitlines(True), fromfile='frozen-original-generator', tofile='corrected-successor-generator')))
replay = load(NEW / 'generator-replay-proof.json')
assert replay['status'] == 'passed' and replay['replayed_files'] == len(replay['files']) == 3198
assert len({r['path'] for r in replay['files']}) == 3198
for row in replay['files']:
    expected_owner = NEW / 'payload/content-map.json' if row['path'] == 'content-map.json' else NEW / 'prepare_retention_corrected.py' if row['path'] == 'proof/prepare_retention.py.txt' else OLD / 'payload' / row['path']
    assert Path(row['expected_owner']) == expected_owner
    b = expected_owner.read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
assert (ROOT / 'provenance-successor/generator-replay-proof.json').read_bytes() == (NEW / 'generator-replay-proof.json').read_bytes()

history = load(ROOT / 'provenance-successor/predecessor-map.json')
rows = history['files']
assert len(rows) == 3357 and len({r['original_path'] for r in rows}) == 3357
assert {r['original_path'] for r in rows} == set(oldfiles)
counts = {'identity': 0, 'gzip': 0}
for row in rows:
    rel = Path(row['retained_path'])
    assert not rel.is_absolute() and '..' not in rel.parts
    b = (ROOT / rel).read_bytes()
    assert sha(b) == row['stored_sha256'] and len(b) == row['stored_bytes']
    assert row['encoding'] in counts
    counts[row['encoding']] += 1
    if row['encoding'] == 'gzip':
        b = gzip.decompress(b)
    assert sha(b) == row['original_sha256'] and len(b) == row['original_bytes']
    assert b == oldfiles[row['original_path']].read_bytes()
assert counts == {'identity': 3230, 'gzip': 127}
assert len({r['retained_path'] for r in rows if r['encoding'] == 'gzip'}) == 71
for ledger, pathkey, source_root in [('author-observations.json', 'original_path', NEW), ('issue-591.json', 'source', None)]:
    obj = load(ROOT / 'provenance-successor' / ledger)
    entries = obj['root_inputs'] if isinstance(obj, dict) else obj
    for row in entries:
        b = (ROOT / row['retained_path']).read_bytes()
        assert sha(b) == row['stored_sha256'] and len(b) == row['stored_bytes']
        original = gzip.decompress(b)
        assert sha(original) == row['original_sha256'] and len(original) == row['original_bytes']
        assert original == ((source_root / row[pathkey]) if source_root else Path(row[pathkey])).read_bytes()

promotion = load(NEW / 'promotion-files.json')
assert promotion['create_only'] is True and promotion['destination_root'] == 'research/pathway_additions/2026-10-15-next-266/evidence-retention/'
assert promotion['payload_manifest_sha256'] == '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98'
assert len(promotion['files']) == len(payload) and {r['path'] for r in promotion['files']} == set(payload)
for row in promotion['files']:
    b = payload[row['path']].read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes'] < 100 * 1024 * 1024
paths = [promotion['destination_root'] + r['path'] for r in promotion['files']]
r = subprocess.run(['git', 'check-ignore', '--no-index', '-z', '--stdin'], cwd=REPO, input=b'\0'.join(p.encode() for p in paths) + b'\0', capture_output=True)
assert r.returncode == 1 and not r.stdout and not r.stderr
assert (REPO / 'research/pathway_additions/2026-10-15-next-266/README.md').is_file()
assert not (REPO / promotion['destination_root']).exists()
dump('independent-scope-and-history.json', {'status': 'passed', 'successor_outer_files': len(newfiles), 'successor_payload_files': len(payload), 'unchanged_original_payload_files': 3230, 'changed_original_paths': sorted(changed), 'additions': additions, 'content_map_only_changed_fields': changes, 'changed_field_count': len(changes), 'complete_predecessor_files_recovered': len(rows), 'history_counts': counts, 'history_gzip_endpoints': 71, 'corrected_generator_change': 'Exactly one conditional tree rebinding, two added lines.', 'author_generator_replay_rows_independently_bound': 3198, 'independent_fresh_generator_execution': False, 'all_proposed_paths_unignored': True, 'all_payload_files_below_100_MiB': True, 'original_review_fully_reverified': True, 'research_report_present_and_retention_destination_absent': True})
print('Complete bounded scope, history recovery and promotion inventory passed', flush=True)
