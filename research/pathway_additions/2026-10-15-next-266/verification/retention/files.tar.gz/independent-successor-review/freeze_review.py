"""Freeze bounded independent successor acceptance with complete physical inventory."""
import hashlib
import json
import os
import stat
from datetime import UTC, datetime
from pathlib import Path

root = Path('/private/tmp/pathwaymech-next-266-independent-retention-successor-review')
assert not (root / 'artifact-manifest.json').exists()
assert not (root / 'freeze-proof.json').exists()
for name in ['independent-full-audit.json', 'independent-scope-and-history.json', 'independent-successor-helper-probes.json']:
    assert json.loads((root / name).read_bytes())['status'] == 'passed'
status = json.loads((root / 'review-status.json').read_bytes())
assert status['new_findings'] == [] and status['worktree_read_dependencies_released']
rows = []
for current, dirs, names in os.walk(root, followlinks=False):
    for name in dirs + names:
        p = Path(current) / name
        mode = p.lstat().st_mode
        assert stat.S_ISDIR(mode) or stat.S_ISREG(mode)
        if stat.S_ISREG(mode):
            b = p.read_bytes()
            rows.append({'path': p.relative_to(root).as_posix(), 'sha256': hashlib.sha256(b).hexdigest(), 'bytes': len(b)})
rows.sort(key=lambda r: r['path'])
(root / 'artifact-manifest.json').write_text(json.dumps({'scope': 'All independent successor review physical files, including hidden and ignored paths, except this manifest and final freeze proof.', 'files': rows}, indent=2, sort_keys=True) + '\n')
proof = {'status': 'frozen; bounded successor accepted', 'timestamp': datetime.now(UTC).isoformat(), 'artifact_manifest_sha256': hashlib.sha256((root / 'artifact-manifest.json').read_bytes()).hexdigest(), 'listed_artifacts': len(rows), 'physical_artifacts': len(rows) + 2, 'handoff_sha256': hashlib.sha256((root / 'HANDOFF.md').read_bytes()).hexdigest(), 'assessment_sha256': hashlib.sha256((root / 'ASSESSMENT.md').read_bytes()).hexdigest(), 'accepted_payload_manifest_sha256': '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98', 'resolved_finding': 'N266-RET-PROV-01', 'issue': 591, 'new_findings': [], 'complete_source_bytes_unchanged': True, 'complete_original_preparation_recoverable': True, 'pending': 'Root guarded maintained adoption, later production verification and publication; issue closure awaits verified publication.', 'maintained_or_frozen_mutations': False}
(root / 'freeze-proof.json').write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
print(json.dumps({**proof, 'freeze_sha256': hashlib.sha256((root / 'freeze-proof.json').read_bytes()).hexdigest()}, indent=2))
