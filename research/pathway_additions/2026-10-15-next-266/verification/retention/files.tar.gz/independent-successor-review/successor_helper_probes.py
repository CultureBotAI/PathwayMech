"""Independently exercise corrected provenance guards with a valid tampered manifest."""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SOURCE = Path('/private/tmp/pathwaymech-next-266-retention-successor/payload')
OLD = Path('/private/tmp/pathwaymech-next-266-retention-preparation')
REPO = Path('/private/tmp/pathwaymech-next-266-20261015')
OUT = Path('/private/tmp/pathwaymech-next-266-independent-retention-successor-review')
TMP = Path(tempfile.mkdtemp(prefix='next266-independent-successor-guard-', dir='/private/tmp'))
commands = []


def sha(b):
    return hashlib.sha256(b).hexdigest()


def run(name, args, success=True, required_error=None):
    argv = [sys.executable, '-B', *map(str, args)]
    r = subprocess.run(argv, capture_output=True, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1'})
    (OUT / (name + '.stdout')).write_bytes(r.stdout)
    (OUT / (name + '.stderr')).write_bytes(r.stderr)
    assert (r.returncode == 0) == success, (name, r.stderr)
    if required_error:
        assert required_error.encode() in r.stderr
    commands.append({'name': name, 'command': argv, 'exit_code': r.returncode, 'expected': 'pass' if success else 'reject', 'stdout_sha256': sha(r.stdout), 'stderr_sha256': sha(r.stderr)})
    return r


run('successor-provenance-control', [SOURCE / 'verify_inherited_provenance.py', '--root', SOURCE, '--repo', REPO])
plan = run('successor-planner-control', [SOURCE / 'plan_promotion.py', '--stage', SOURCE, '--expected-stage-manifest-sha256', '424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98', '--target-repo', REPO])
verified = json.loads(plan.stdout)
assert verified['inherited_commit_tree_and_blob_check']['inherited_content_rows'] == 836
assert verified['inherited_commit_tree_and_blob_check']['rows_with_optional_tree'] == 586
assert verified['working_tree_owner_and_all_artifact_check']['source_occurrences'] == 7337
assert len(verified['copy_exact_relative_paths']) == 3343
run('successor-predecessor-recovery-control', [SOURCE / 'reconstruct_predecessor.py', '--root', SOURCE, '--compare-original', OLD])
print('Three full corrected helper controls passed; actual working-tree owner reads released', flush=True)
(OUT / 'actual-owner-reads-released.json').write_text(json.dumps({'status': 'released', 'full_actual_worktree_plan_passed': True, 'head': verified['observed_target_head'], 'payload_manifest_sha256': verified['stage_manifest_sha256'], 'inherited_rows': 836, 'owners': 502, 'working_tree_and_full_source_fidelity': verified['working_tree_owner_and_all_artifact_check']}, indent=2) + '\n')
copy = TMP / 'payload'
shutil.copytree(SOURCE, copy)
original_hashes = {p.relative_to(SOURCE).as_posix(): sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()}
assert {p.relative_to(copy).as_posix(): sha(p.read_bytes()) for p in copy.rglob('*') if p.is_file()} == original_hashes
mapfile, manifestfile = copy / 'content-map.json', copy / 'artifact-manifest.json'
mapbytes, manifestbytes = mapfile.read_bytes(), manifestfile.read_bytes()
obj = json.loads(mapbytes)
key = next(k for k, r in obj.items() if r['storage'].get('git_tree'))
obj[key]['storage']['git_tree'] = 'e5c455667499283021774a6c3d5138cc8293f28e'
mapfile.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')
manifest = json.loads(manifestbytes)
for row in manifest['files']:
    if row['path'] == 'content-map.json':
        row.update(sha256=sha(mapfile.read_bytes()), bytes=mapfile.stat().st_size)
manifestfile.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
negative_manifest = sha(manifestfile.read_bytes())
assert {p.relative_to(copy).as_posix() for p in copy.rglob('*') if p.is_file()} == {r['path'] for r in manifest['files']} | {'artifact-manifest.json'}
for row in manifest['files']:
    b = (copy / row['path']).read_bytes()
    assert sha(b) == row['sha256'] and len(b) == row['bytes']
run('negative-valid-manifest-stale-tree-guard', [copy / 'verify_inherited_provenance.py', '--root', copy, '--repo', REPO], success=False, required_error='stale inherited tree')
run('negative-valid-manifest-stale-tree-planner', [copy / 'plan_promotion.py', '--stage', copy, '--expected-stage-manifest-sha256', negative_manifest, '--target-repo', REPO], success=False, required_error='verify_inherited_provenance.py')
mapfile.write_bytes(mapbytes)
manifestfile.write_bytes(manifestbytes)
proof = copy / 'existing-owner-verification.json'
proofbytes = proof.read_bytes()
obj = json.loads(proofbytes)
obj[0]['git_blob'] = '0' * 40
proof.write_text(json.dumps(obj))
run('negative-wrong-Git-blob-owner', [copy / 'verify_inherited_provenance.py', '--root', copy, '--repo', REPO], success=False, required_error='AssertionError')
proof.write_bytes(proofbytes)
history = json.loads((copy / 'provenance-successor/predecessor-map.json').read_bytes())
entry = next(r for r in history['files'] if r['encoding'] == 'gzip')
endpoint = copy / entry['retained_path']
endpointbytes = endpoint.read_bytes()
endpoint.write_bytes(endpointbytes[:-1] + bytes([endpointbytes[-1] ^ 1]))
run('negative-corrupt-predecessor-control', [copy / 'reconstruct_predecessor.py', '--root', copy, '--compare-original', OLD], success=False, required_error='AssertionError')
endpoint.write_bytes(endpointbytes)
assert {p.relative_to(copy).as_posix(): sha(p.read_bytes()) for p in copy.rglob('*') if p.is_file()} == original_hashes
assert {p.relative_to(SOURCE).as_posix(): sha(p.read_bytes()) for p in SOURCE.rglob('*') if p.is_file()} == original_hashes
receipt = {'status': 'passed', 'commands': commands, 'valid_mutated_manifest_sha256': negative_manifest, 'stale_tree_mutated_source_content': key, 'all_negative_manifest_rows_and_inventory_independently_valid': True, 'stale_tree_rejected_by_direct_guard_and_planner': True, 'copied_files': 3343, 'all_copied_bytes_restored': True, 'frozen_successor_unchanged': True, 'owned_temporary_cleanup': str(TMP)}
(OUT / 'independent-successor-helper-probes.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
shutil.rmtree(TMP)
print('All independent successor helper and valid-manifest regression probes passed', flush=True)
