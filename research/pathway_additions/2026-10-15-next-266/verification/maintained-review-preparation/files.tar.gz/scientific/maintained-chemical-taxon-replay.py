"""Additional direct identity checks and independently authored edge dispositions."""
from pathlib import Path
import hashlib,json,yaml
from lxml import etree
P=Path('/private/tmp/pathwaymech-next-266-design');O=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
d=yaml.safe_load((O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_text());nodes=read(P/'candidate-node-ledger.json')
identities=[]
for r in nodes:
    if not r['id'].startswith('CHEBI:'):continue
    p=P/r['identity_source']
    if p.suffix=='.xml':p=P/'sources/native/issuer-originals'/('ChEBI-'+r['id'].split(':')[1]+'.json')
    c=read(p);assert r['id']==c['chebi_accession'] and r['proposed_label']==c['ascii_name']
    row={'id':r['id'],'issuing_ascii_name':c['ascii_name'],'issuing_unicode_name':c['name'],'source':str(p.relative_to(P)),'source_sha256':sha(p),'formula':c['chemical_data']['formula'],'charge':c['chemical_data']['charge']}
    if r.get('native_source'):
        np=P/r['native_source'];t=etree.parse(str(np));n=t.xpath('/ptools-xml/Compound')[0]
        assert n.findtext('inchi')==c['default_structure']['standard_inchi']
        assert n.findtext('inchi-key').removeprefix('InChIKey=')==c['default_structure']['standard_inchi_key']
        assert r['formula']==row['formula'] and r['charge']==row['charge']
        row.update({'native_source':str(np.relative_to(P)),'native_source_sha256':sha(np),'full_native_issuing_inchi_equal':True,'full_native_issuing_inchikey_equal':True})
    identities.append(row)
assert len(identities)==19
taxa=[]
for r in d['taxa']:
    n=next(x for x in nodes if x['id']==r['id']);p=P/n['identity_source'];t=etree.parse(str(p))
    hits=t.xpath('//Taxon[TaxId=$id]',id=r['id'].split(':')[1]);assert len(hits)==1
    x=hits[0];assert x.findtext('ScientificName')==r['label']
    taxa.append({'id':r['id'],'label':r['label'],'rank':x.findtext('Rank'),'source':str(p.relative_to(P)),'source_sha256':sha(p),'locator':t.getpath(x),'scope':n['scope']})
save('chemical-and-taxon-identity-replay.json',{'status':'pass','chemicals':identities,'taxa':taxa,'limits':'Full issuing/native InChI and key comparisons are fresh. No new RDKit/CML or 4 GB SQL rebuild; those are accepted upstream finite evidence, not rerun claims.'})


print(json.dumps({'status':'pass','chemicals':len(identities),'taxa':len(taxa)}))
