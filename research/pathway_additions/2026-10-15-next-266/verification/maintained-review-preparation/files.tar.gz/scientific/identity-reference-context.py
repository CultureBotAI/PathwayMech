"""Independent identity/reference correspondence and preserved edge assessments."""
from pathlib import Path
import datetime, hashlib, json, re, unicodedata
import yaml
from lxml import etree, html

O=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
P=Path('/private/tmp/pathwaymech-next-266-design')
R=Path('/private/tmp/pathwaymech-next-266-independent-design-review')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def norm(s):return ' '.join(unicodedata.normalize('NFKC',s).split()).casefold()
def plain(s):return html.fromstring('<div>'+s+'</div>').text_content()
def xml(p):return etree.parse(str(p),etree.XMLParser(resolve_entities=False,no_network=True))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
record=O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'
d=yaml.safe_load(record.read_text()); assert d==read(P/'provisional-record-design.json')
ledger={r['id']:r for r in read(P/'candidate-node-ledger.json')}
ledger[d['id']]={'identity_source':'sources/native/originals/META-CENTBENZCOA-PWY.xml'}
authorities=[read(O/'captured-v3/data/identifier_authorities'/f) for f in ['sources.json','ontology.json']]
identities=[]
for section,nodes in [('record',[d])]+[(k,d[k]) for k in ['taxa','participants','reactions']]:
    for n in nodes:
        id=n['id'];matches=[(a,a['terms'][id]) for a in authorities if id in a['terms']];assert len(matches)==1,id
        a,term=matches[0]; owner=a['sources'][term['source']]
        assert any(norm(n['label'])==norm(s) for s in [term['label']]+term.get('synonyms',[])),id
        source=P/ledger[id]['identity_source'];nodeproof={}
        if id.startswith('CHEBI:'):
            if source.suffix=='.xml':source=P/'sources/native/issuer-originals'/('ChEBI-'+id.split(':')[1]+'.json')
            c=read(source); assert c['chebi_accession']==id and n['label']==c['ascii_name']
            nodeproof={'source_kind':'issuing ChEBI JSON','id_field':'chebi_accession','name_field':'ascii_name','charge':c['chemical_data']['charge']}
        elif id.startswith('UniProtKB:'):
            c=read(source); assert c['primaryAccession']==id.split(':')[1]
            desc=c['proteinDescription'];names=[]
            def walk(v):
                if isinstance(v,dict):
                    for k,x in v.items():
                        if k=='fullName': names.append(x['value'])
                        else:walk(x)
                elif isinstance(v,list):
                    for x in v:walk(x)
            walk(desc);assert any(norm(n['label'])==norm(x) for x in names)
            nodeproof={'source_kind':'issuing UniProt JSON','id_field':'primaryAccession','name_field':'proteinDescription/fullName','organism_taxon':c['organism']['taxonId'],'sequence_length':len(c['sequence']['value'])}
        elif id.startswith('NCBIProtein:'):
            t=xml(source);assert t.findtext('.//GBSeq_accession-version')==id.split(':')[1]
            assert t.findtext('.//GBSeq_definition')==n['label']
            nodeproof={'source_kind':'issuing NCBI Protein XML','id_field':'GBSeq_accession-version','name_field':'GBSeq_definition'}
        elif id.startswith('NCBITaxon:'):
            t=xml(source);x=t.xpath('//Taxon[TaxId=$i]',i=id.split(':')[1]);assert len(x)==1 and x[0].findtext('ScientificName')==n['label']
            nodeproof={'source_kind':'issuing NCBI Taxonomy XML','locator':t.getpath(x[0]),'rank':x[0].findtext('Rank')}
        else:
            t=xml(source);frame=id.split(':')[1];roots=t.xpath('/ptools-xml/*[@ID=$i]',i='META:'+frame);assert len(roots)==1
            x=roots[0];assert x.get('orgid')=='META' and x.get('frameid')==frame and t.find('metadata/PGDB').get('version')=='27.0'
            assert t.findtext('metadata/query')=='META:'+frame
            if term.get('label_kind')=='source_context':
                assert section=='reactions' and n['category']=='molecular_activity' and term['entity_type']=='reaction' and n['label']==frame
                labelscope='native frame identity; typed reaction contextual display, not inferred canonical function'
            else:
                names=x.findall('common-name')+x.findall('synonym')
                if not x.findall('common-name') and n.get('category')=='complex':names=x.findall('catalyzes/Enzymatic-Reaction/common-name')
                assert any(norm(n['label'])==norm(plain(z.text or '')) for z in names),(id,n['label'])
                labelscope='direct native name/alias or exact linked activity name for unnamed assembly'
            if 'native_benzoyl' in owner:
                doc=owner['native_benzoyl']['document'];assert doc['id']==id
                assert doc['original_xml'].encode('utf-8')==source.read_bytes()
                assert sha(source)==owner['sha256']
            nodeproof={'source_kind':'native MetaCyc XML','native_type':x.tag,'native_class':x.get('class')=='true','version':'27.0','label_scope':labelscope}
        identities.append({'section':section,'id':id,'label':n['label'],'category':n.get('category'),'authority_term':term,'owner_provenance':{k:owner[k] for k in ['url','version','sha256','sha256_scope','kind'] if k in owner},'independent_original':str(source),'original_sha256':sha(source),'source_checks':nodeproof})
assert len(identities)==56
save('named-identity-assessment.json',{'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'pass','record_sha256':sha(record),'count':56,'rows':identities,'limits':'Fresh exact issuing identity/name correspondence plus actual selected authority labels/placement. Complete ontology SQL extraction and implementation tests are separately reviewed root-owned proofs, not rerun here. Issuing annotation is not biochemical evidence.'})

copied=read(P/'copied-original-source-bindings.json')['files']; byhash={r['sha256']:P/r['path'] for r in copied}
references=[]
for ref in d['references']:
    source=byhash[ref['source_sha256']];assert sha(source)==ref['source_sha256']
    if ref['id'].startswith('MetaCyc:'):
        frame=ref['id'].split(':')[1];t=xml(source);roots=t.xpath('/ptools-xml/*[@ID=$i]',i='META:'+frame)
        assert len(roots)==1 and roots[0].get('frameid')==frame and roots[0].get('orgid')=='META'
        assert t.findtext('metadata/query')=='META:'+frame and t.find('metadata/PGDB').get('version')=='27.0'
        assert ref['url']=='https://biocyc.org/META/NEW-IMAGE?type=OBJECT&object='+frame
        assert 'XML' in ref['citation'] and 'structured' in ref['citation']
        assert '27.0' in ref['source_version']
        check={'native_root':roots[0].tag,'native_identity':roots[0].get('ID'),'PGDB':'META','version':'27.0','original_xml_base':t.getroot().get('{http://www.w3.org/XML/1998/namespace}base'),'public_link_scope':'BioCyc human-facing same-object link; digest explicitly binds retained native XML, not public HTML','evidence_scope':'structured source assertion, not a verbatim publication quote'}
    else:
        t=html.parse(str(source));pmid=t.xpath('//meta[@name="citation_pmid"]/@content');assert pmid==[ref['id'].split(':')[1]]
        check={'pmid':pmid[0],'doi':t.xpath('//meta[@name="citation_doi"]/@content')[0],'title':t.xpath('//meta[@name="citation_title"]/@content')[0],'evidence_scope':'primary full-text HTML; separately unread supplement details are not inferred'}
    references.append({'reference':ref,'original':str(source),'original_sha256':sha(source),'identity_checks':check})
assert len(references)==25
save('reference-original-assessment.json',{'status':'pass','rows':references,'all_117_locators_and_four_quotes':'evidence-locator-replay.json'})

prior=read(R/'edge-review.json');assert len(prior['rows'])==76
fresh=read(O/'evidence-locator-replay.json')['rows'];assessments=[]
for edge,row in zip(d['mechanistic_edges'],prior['rows'],strict=True):
    for k in ['subject','predicate','object']:assert edge[k]==row[k]
    assert edge['id']==row['edge']
    current=[e for e in fresh if e['edge']==edge['id']];assert len(current)==row['evidence_count']
    original=next(e for e in read(P/'provisional-record-design.json')['mechanistic_edges'] if e['id']==edge['id']);assert original==edge
    assessments.append({**row,'actual_yaml_full_edge_equals_independently_reviewed_design':True,'fresh_locator_count':len(current),'fresh_locator_result':'pass','judgment_basis':'Prior independently authored scientific assessment reused on exact unchanged complete edge; current full YAML reading and fresh source replay confirm retained limits.'})
save('maintained-edge-assessments.json',{'status':'supported within stated source and construct limits','record_sha256':sha(record),'prior_edge_assessment_sha256':sha(R/'edge-review.json'),'rows':assessments,'coverage':'Every 76 maintained edge including all endpoint qualifier evidence; no selected-route subset.'})
save('scientific-replay-execution-observation.json',{'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'replays':[{'helper':'maintained-replay.py','helper_sha256':sha(O/'maintained-replay.py'),'exit_code':0,'observed_stdout':{'status':'pass','record_sha256':sha(record),'strict_design_object_equal':True,'evidence':117,'edges':76,'activities':15,'protein_rows':21,'components':13}},{'helper':'maintained-chemical-taxon-replay.py','helper_sha256':sha(O/'maintained-chemical-taxon-replay.py'),'exit_code':0,'observed_stdout':{'status':'pass','chemicals':19,'taxa':4}}],'scope':'Transcription of tool-returned execution observations; not fabricated start/end timing or a raw shell log.'})
print(json.dumps({'status':'pass','named_identities':len(identities),'reference_originals':len(references),'edge_assessments':len(assessments)}))
