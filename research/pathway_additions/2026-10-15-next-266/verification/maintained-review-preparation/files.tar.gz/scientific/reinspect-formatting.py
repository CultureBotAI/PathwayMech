from pathlib import Path
import datetime, hashlib, json, os, subprocess

O=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
W=Path('/private/tmp/pathwaymech-next-266-20261015')
S=Path('/private/tmp/pathwaymech-next-266-registry-formatting-successor')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def unique(pairs):
    d={}
    for k,v in pairs:
        assert k not in d, k
        d[k]=v
    return d
def decode(b): return json.loads(b,object_pairs_hook=unique)
def read(p): return decode(p.read_bytes())
def save(name,obj): (O/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
started=now()
assert sha(S/'artifact-manifest.json')=='0255d78cb9a82d39ae64c0596457403642f7335546bb69439a1ea598f83a208a'
m=read(S/'artifact-manifest.json')
for r in m['files']:
    assert sha(S/r['path'])==r['sha256'] and (S/r['path']).stat().st_size==r['bytes']
assert {str(p.relative_to(S)) for p in S.rglob('*') if p.is_file()}=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze-proof.json'}
proof=read(S/'proof.json'); comparisons=[]
for r in proof['files']:
    p=r['path']; old=O/'captured'/p; new=S/'proposed'/p; live=W/p
    assert sha(old)==r['accepted_proposal_sha256']
    assert sha(new)==sha(live)==r['successor_sha256']
    a,b=read(old),read(new)
    assert a==b
    baseline=subprocess.run(['git','show','dd780ef273323efd638eacd63625963062e0b105:'+p],cwd=W,capture_output=True,check=True).stdout
    assert hashlib.sha256(baseline).hexdigest()==r['baseline_sha256']
    previous=decode(baseline)
    assert (json.dumps(previous,indent=2,ensure_ascii=False)+'\n').encode()==baseline
    if isinstance(previous,list):
        assert b[:len(previous)]==previous
    else:
        for k,v in previous.items():
            if isinstance(v,dict):
                assert all(b[k].get(key)==value for key,value in v.items())
                assert list(b[k])[:len(v)]==list(v)
            elif isinstance(v,list): assert b[k][:len(v)]==v
            else: assert b[k]==v
        assert list(b)[:len(previous)]==list(previous)
    destination=O/'captured-v3'/p; destination.parent.mkdir(parents=True,exist_ok=True); destination.write_bytes(new.read_bytes())
    comparisons.append({**r,'duplicate_json_keys_rejected':True,'independent_whole_object_equal':True,'independent_existing_values_and_order_prefix_preserved':True,'copy':str(destination.relative_to(O))})
capture=read(O/'capture-v2.json')
for r in capture['files']:
    new=next((x for x in comparisons if x['path']==r['path']),None)
    if new: r.update(sha256=new['successor_sha256'],bytes=new['successor_bytes'],copy=new['copy'])
    assert sha(W/r['path'])==r['sha256'] and sha(O/r['copy'])==r['sha256']
capture['captured_at_v3']=now();capture['phase']='Formatting-only authority successor explicitly compared; unchanged YAML and other inputs; scientific assessment ongoing, full gates pending.'
save('capture-v3.json',capture)
save('formatting-successor-independent-comparison.json',{'started_at':started,'finished_at':now(),'status':'pass','successor_manifest_sha256':sha(S/'artifact-manifest.json'),'compared_files':comparisons,'scope':'Independent complete object comparison with duplicate-key rejection, immutable baseline values/order and serialization check. Not biological evidence or a fresh producer/consumer test.'})
argv=read(O/'inspect-v2-invocation.json')['argv']
runstart=now();p=subprocess.run(argv,cwd=W,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True,text=True)
(O/'inspect-v3.stdout.json').write_text(p.stdout);(O/'inspect-v3.stderr.txt').write_text(p.stderr)
save('inspect-v3-invocation.json',{'started_at':runstart,'finished_at':now(),'argv':argv,'exit_code':p.returncode,'cwd':str(W),'reason':'Three formatting-only authority hashes changed; prior inspect results retained.'})
assert p.returncode==0
inspection=json.loads(p.stdout)
for r in capture['files']: assert sha(W/r['path'])==r['sha256']
print(json.dumps({'status':'pass','formatting_files':len(comparisons),'inspect_inputs':len(capture['files']),'record_sha256':capture['files'][0]['sha256']}))
