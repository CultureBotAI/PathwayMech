# Independent authority implementation assessment

**Qualified acceptance of the exact final next266 authority implementation; no supported blocking defect found.** This is an independent implementation review by `/root/next266_authority_adversarial`, not an author self-review. The author receipt SHA-256 is `f16a1d7bce965547be16b44d98d2dc03ee64b2d26e36a9f17234324d7ceef04e`. All sixteen changed files match that receipt. The merged baseline is `dd780ef273323efd638eacd63625963062e0b105`.

This review does not approve a maintained scientific record, a duplicate/source-follow assessment, final record review, production gates, or publication. Those remain root-owned tasks. The accepted frozen scientific design is an input defining the required shapes; this implementation review does not repeat its full scientific review.

## Exact sources and implementation

I read the complete new `biocyc_benzoyl.py`, complete new test module, producer and consumer changes with their surrounding selection/placement logic, documentation changes, relevant existing context/provenance helpers, and the scientific authority design and independent design assessment. The author's complete report inventory was verified, including hidden and ignored files. Its seven listed files plus manifest/freeze are exact. All sixteen changed worktree paths are separately rebound before and after execution.

All eight fixture XML files equal four separately located originals byte for byte: the fixture, copied frozen design original, original native packet, and root's fresh literal acquisition body. Exact acquisition URLs, lengths, hashes and reviewed-source bindings agree. Six are typed objects; two are the full ordinary Oah constituent originals. These checks verify source fidelity. They do not turn a hash into authentication of an arbitrary newly supplied replacement source.

The five new kinds are separate from the prior profiles. The new module enforces a MetaCyc 27.0 literal native request, complete metadata envelope, object identity, explicit native type/class, required top-level slot inventory, and source-body hash. Every original XML byte is retained in metadata. Consumer reconstruction re-parses that body and compares the complete projected document using canonical JSON, so integer coefficients and boolean class/explicitness flags cannot be interchanged. Native context not promoted to a selected term remains in the exact body and therefore in conflict comparison.

The six typed object requirements are satisfied:

1. CPLX-1341 retains four distinct Bcr coefficient-one components, species context, and exact activity-enzyme-reaction links. Its canonical label comes from its actual linked activity. The older homomer fallback remains unchanged.
2. 1.3.99.15-RXN retains PHYSIOL-RIGHT-TO-LEFT, exact two-unit Protein-class carriers, ATP/ADP/phosphate/water coefficients, both embedded activities and ordinary EC-1.3.7.8 context. No whole-polypeptide coefficient conversion is introduced. RXN-21320's previous profile is unchanged.
3. Both full ferredoxin classes retain their generic cluster-unit names, exact parent and redox-state relationships, typed class members, and complete native context. The Thioredoxin/Hydride-Acceptors profiles remain separate.
4. Oah retains its reversible two-water net equation, both complete constituent bodies and independent provenance, exact ordered constituent IDs and backlinks. I separately summed the original XML equations without calling the implementation's relation helper: CPD-15900 cancels and the remaining signed sum equals the original composite. The composite has no selected-pathway membership. The previous acyl-transfer profile remains unchanged.
5. RXN-8032 retains its direct canonical reaction name, complete equation, and linked native predicted PimB activity. Label acceptance makes no new catalytic evidence claim. The original unnamed adapter still rejects direct names.

## Adversarial behavior and regression coverage

The final implementation passed **2,077 tests in 75.70 seconds** across the new module and nine relevant existing regression modules. This is an independent run of the exact final files, with pytest's cache disabled and all temporary outputs outside the worktree. It includes the author's later strict numeric JSON and companion-provenance tests; it is not the earlier 2,064-test author run.

The tests meaningfully modify actual native bodies, metadata, source ordering and selected identities. They exercise complete-original reconstruction, missing and contradictory source context, exact component/activity links, equation/coefficients/type/direction, class and state definitions, Oah cancellation and companions, canonical naming, category placement, coherent and conflicting duplicate owners, and unselected conflicts in both source orders. They do not merely compare the implementation with itself: inputs are independently bound actual originals, and negatives alter explicit scientific or provenance constraints.

I also wrote and executed **66 independent negative consumer probes**, all rejected. These cover integer substitution for class booleans, altered original body without its hash, loss of category and label-kind metadata, stripped projection, empty license, extra unprojected metadata, and four supported competing request URI forms for every protected identity when no typed owner or selected term is present. Six positive typed controls and a full eight-object ordinary builder/consumer control passed. Strict integer coefficient cases and both source-order conflict cases are additionally covered by the independently executed regression tests.

Canonical reaction naming now runs before namespace contextual-label exemptions; unchanged source-context reactions retain their allowed contextual displays. Existing complex and carrier category/name gates remain effective. Both source-request identities and parsed body/term identities are checked before selection, while first coherent selected owners remain unchanged. Companion owners must retain exact URL, release and original-byte hash.

## Complete proposal, owner retention and SQL binding

Using the exact final worktree code, I independently rebuilt all 33 selected source owners from the prepared complete source manifest/cache. The result strictly equals the earlier prepared projection. I compared the proposed merged registries and manifest against actual Git objects at the merged baseline, not merely against a prior success receipt:

- All 3,153 old source terms and 1,141 old source owners remain exact; 32 terms and 32 owners are added. This includes preservation of the existing CPD-7 owner.
- All 2,179 old ontology terms and all five old ontology owners remain exact; 11 terms are added and no source owner is replaced.
- All 1,322 prior manifest rows remain an exact ordered prefix; 32 rows are appended, for 1,354 total.
- All 262 baseline record files equal their actual Git blobs. The external proposal contributes the one provisional next266 record. The final identifier consumer accepts all **263 records**, with no errors.

I separately queried both ontology databases read-only. All 19 selected ChEBI terms, four selected NCBITaxon terms, and all **551 complete selected-subject statement rows** reproduce the retained source ledgers and selected projection. Both source metadata objects equal their original baseline owners. Database inode, byte count and modification time equal the root's freshly whole-hashed binding and remain unchanged after queries. This is a fresh complete selected-subject replay, **not a new independent hash of the full 4.1 GB and 14.1 GB databases**. Root's existing fresh whole-database hash evidence remains the stated dependency.

## Findings, limits and execution

No supported blocking implementation defect was found; `findings.json` is empty. There is no requested GitHub issue or implementation correction from this review. Acceptance is specific to the sixteen hashes in `input-integrity.json` and `final-integrity.json`; later functional changes require an appropriate successor assessment.

The source builder and consumer prove exact identity/provenance consistency and the bounded native shapes. They do not establish purified-enzyme turnover, a physiological whole-protein carrier count, a released Oah intermediate, an eighth selected route step, or whole-pathway presence in every named taxon. The independent scientific design's qualifications remain required in integration.

Only this new review directory was written. No maintained source/data, frozen input, original checkout, Git/GitHub state or shared runtime was changed. No network fetch or runtime install occurred. Helpers and successful logs are retained. Exploratory reads that were truncated were followed by narrower reads; a guessed helper filename was absent and the actual helper was then found with an ignored/hidden-inclusive search. These exploratory command failures did not execute or modify the implementation.

The initial report-packaging helper stopped on a deliberate nonregular file created by a regression test, before any cleanup or freeze writes. That failure is retained in `initial-freeze-failure.json` and the original `finish.py`; the append-only `finish_v2.py` records such special files with `lstat` without opening them. This was a reporting-inventory correction, not an implementation defect.

Generated pytest case directories were temporary execution outputs, not new scientific inputs. After the terminal successful result, their complete hidden/ignored-inclusive regular-file hashes and symlink inventory were saved in `transient-tests-inventory.json.gz`, and those disposable directories were removed from this reviewer-owned output. The exact author fixtures, independent probe inputs, final source projection, and all principal results remain retained. The final report manifest inventories every remaining regular file; no report file is omitted.

This task is complete and releases its live next266 worktree dependency. Frozen author, design, source-acquisition and ontology evidence remain dependencies by exact path/hash. Preserve them, or their exact archived equivalents, through publication and cleanup.
