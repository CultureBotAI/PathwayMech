"""Independent finite design replay; source packages and maintained worktree are read-only."""
from pathlib import Path
import collections
import hashlib
import json
import re
import yaml
import subprocess
from lxml import etree, html

P = Path('/private/tmp/pathwaymech-next-266-design')
O = Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
W = Path('/private/tmp/pathwaymech-next-266-20261015')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def save(name, data): (O/name).write_text(json.dumps(data, indent=2, ensure_ascii=False)+'\n')
def xml(p): return etree.parse(str(p), etree.XMLParser(resolve_entities=False,no_network=True))

manifest=read(P/'artifact-manifest.json')
inventory=[]
for row in manifest['files']:
    p=P/row['path']
    assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256'], row['path']
    inventory.append(row)
actual={str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()}
assert actual=={r['path'] for r in inventory}|{'artifact-manifest.json','freeze.json'}
assert sha(P/'artifact-manifest.json')=='a4133cedc2edb6308c8a01ad76b9a767d9904bd1bc37c844780f15dfe1d45981'
assert sha(P/'provisional-record-design.json')=='83776647c1cf9ad609294c576ae48e625cf5908f5fee43e55d2e6e93286d4fdf'
binding=read(P/'source-packet-bindings.json'); packages={r['package']:Path(r['root']) for r in binding['packages']}
for r in binding['packages']: assert sha(Path(r['root'])/r['manifest'])==r['sha256']
for r in binding['copies']:
    assert sha(P/r['stored'])==sha(Path(r['source']))==r['sha256']
copied=read(P/'copied-original-source-bindings.json')['files']
for r in copied:
    assert sha(P/r['path'])==sha(packages[r['source_package']]/r['source_path'])==r['sha256']
save('input-integrity.json',{'status':'pass','inventory_includes_ignored_and_hidden':True,
    'design_manifest_sha256':sha(P/'artifact-manifest.json'),'design_files':len(inventory),
    'total_design_files':len(actual),'copied_originals':len(copied),'bound_packages':binding['packages'],
    'selected_ledger_copies':len(binding['copies']),
    'scope':'All design package files and exact selected source copies; not a whole rebuild of six upstream archives.'})

d=yaml.safe_load((O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_text()); assert d==read(P/'provisional-record-design.json'); edges=d['mechanistic_edges']; byid={e['id']:e for e in edges}
refs={r['id']:r for r in d['references']}; byhash={r['sha256']:P/r['path'] for r in copied}
evidence=[]
for e in edges:
    groups=[('edge',e['evidence'])]+[(q['endpoint']+' qualifier',q['evidence']) for q in e.get('endpoint_qualifiers',[])]
    for kind,es in groups:
        for v in es:
            p=byhash[refs[v['reference_id']]['source_sha256']];loc=v['source_locator']
            assert sha(p)==refs[v['reference_id']]['source_sha256']
            if loc.startswith('/ptools-xml/'):
                chosen=xml(p).xpath(loc)
            else:
                tree=html.parse(str(p))
                chosen=tree.xpath('//p[@id=$i]',i=loc[7:]) if loc.startswith('HTML p#') else tree.xpath(loc[5:])
            assert chosen,(e['id'],loc)
            if 'quote' in v: assert any(v['quote'] in ''.join(x.itertext()) for x in chosen)
            evidence.append({'edge':e['id'],'scope':kind,'reference':v['reference_id'],
                'source':str(p.relative_to(P)),'source_sha256':sha(p),'locator':loc,'matched':len(chosen),
                'quote_exact':'quote' in v,
                'selected_xml_or_text_sha256':[hashlib.sha256(etree.tostring(x)).hexdigest() for x in chosen]})
assert len(evidence)==117 and sum(x['quote_exact'] for x in evidence)==4
save('evidence-locator-replay.json',{'status':'pass','rows':evidence,'scope':'Every edge and endpoint-qualifier locator and exact quotation; interpretation separately in edge-review.json.'})

nodes=read(P/'candidate-node-ledger.json'); mapped={r['native_frame']:r['id'] for r in nodes if r.get('native_frame')}
path=xml(P/'sources/native/originals/META-CENTBENZCOA-PWY.xml').xpath('/ptools-xml/Pathway')[0]
members=[x.get('frameid') for x in path.findall('reaction-list/Reaction')]
native_members={e['subject'].split(':',1)[1] for e in edges if e['predicate']=='part_of' and e['object']==d['id']}
assert set(members)==native_members and len(members)==7
layout={x.find('Reaction').get('frameid'):x.findtext('direction') for x in path.findall('reaction-layout')}
reactions={}; occurrences=[]; net=collections.Counter()
for rid in members+['OAHTHAUERA-RXN']:
    r=xml(P/f'sources/native/originals/META-{rid}.xml').xpath('/ptools-xml/Reaction')[0]
    selected=layout.get(rid,'L2R'); signed=collections.Counter(); material=[]
    for side in ['left','right']:
        for ordinal,x in enumerate(r.findall(side),1):
            n=[n for n in x if n.tag in ('Compound','Protein')][0]; frame=n.get('frameid')
            coefficient=int(x.findtext('coefficient','1')); explicit=x.find('coefficient') is not None
            is_input=(side=='left')==(selected=='L2R'); sign=-1 if is_input else 1
            signed[frame]+=sign*coefficient
            target=mapped[frame]; subject,obj=(target,'MetaCyc:'+rid) if is_input else ('MetaCyc:'+rid,target)
            ee=[e for e in edges if e['subject']==subject and e['object']==obj and e['predicate']==('consumes' if is_input else 'produces')]
            assert len(ee)==1,(rid,frame)
            assert re.search(r'[Cc]oefficient '+str(coefficient)+r'\b',ee[0]['description'])
            material.append({'edge':ee[0]['id'],'frame':frame,'id':target,'side':side,'ordinal':ordinal,
                'role':'input' if is_input else 'output','coefficient':coefficient,'explicit':explicit,
                'native_type':n.tag,'native_class':n.get('class')=='true'})
    direction=r.findtext('reaction-direction')
    recordr=next(x for x in d['reactions'] if x['id']=='MetaCyc:'+rid)
    assert recordr['direction']=={'REVERSIBLE':'reversible','PHYSIOL-RIGHT-TO-LEFT':'right_to_left','PHYSIOL-LEFT-TO-RIGHT':'left_to_right'}[direction]
    reactions[rid]={'native_direction':direction,'selected_traversal':selected,'signed':dict(signed),'materials':material}
    if rid in members: net.update(signed);occurrences.extend(material)
assert len(occurrences)==32 and len({r['frame'] for r in occurrences})==19
author_occ=read(P/'selected-material-occurrences.json')
for r in author_occ:
    rr=next(x for x in occurrences if x['edge']==r['edge_id'])
    for a,b in [('frame','frame'),('selected_id','id'),('coefficient','coefficient'),('coefficient_explicit','explicit'),('native_type','native_type'),('native_class','native_class')]: assert r[a]==rr[b],r
ordering={(x.find('predecessor-reactions/Reaction').get('frameid'),x.find('Reaction').get('frameid')) for x in path.findall('reaction-ordering')}
graph_joins={(e['subject'].split(':',1)[1],e['object'].split(':',1)[1]) for e in edges if e['predicate']=='provides_input_for'}
assert ordering==graph_joins and len(ordering)==6
joins=[]
for a,b in sorted(ordering):
    common={k for k,v in reactions[a]['signed'].items() if v>0}&{k for k,v in reactions[b]['signed'].items() if v<0}
    assert len(common)==1
    c=common.pop();assert reactions[a]['signed'][c]==1 and reactions[b]['signed'][c]==-1
    joins.append({'upstream':a,'downstream':b,'material':c,'coefficient':1})
oah=collections.Counter(reactions['RXN-15012']['signed']);oah.update(reactions['RXN-15013']['signed'])
assert {k:v for k,v in oah.items() if v}==reactions['OAHTHAUERA-RXN']['signed']
assert oah['CPD-15900']==0
assert not any(e['subject']=='MetaCyc:OAHTHAUERA-RXN' and e['object']==d['id'] for e in edges)
chemical=read(P/'inputs/chemistry/chemical-identity-closure.json')['molecular_identities']
balances={}
for rid,r in reactions.items():
    atoms=collections.Counter();charge=0
    for frame,co in r['signed'].items():
        if frame in chemical:
            c=chemical[frame];charge+=co*c['charge']
            for el,n in c['elements'].items(): atoms[el]+=co*n
    assert not any(atoms.values()),(rid,atoms)
    assert charge==(-2 if rid=='1.3.99.15-RXN' else 0),(rid,charge)
    balances[rid]={'small_molecule_element_residual':dict(atoms),'small_molecule_charge_residual':charge}
save('route-replay.json',{'status':'pass','members':members,'reactions':reactions,'joins':joins,
    'selected_net':{k:v for k,v in sorted(net.items()) if v},'balances':balances,
    'interpretation':'Native carrier coefficient 2 is cluster-unit bookkeeping. Two carrier oxidations compensate -2 small-molecule charge. Oah is auxiliary and its formal CPD-15900 cancels.'})

identity=read(P/'inputs/native/identity-replay.final.json'); proteinrows=[]
for row in identity['native_identities']:
    accession=row['uniprot'];nr=packages['native'];up=nr/f'issuer-originals/UniProt-{accession}.json'
    np=nr/f'issuer-originals/NCBI-protein-{row["protein_id"]}.xml'
    u=read(up);t=xml(np);seq=t.findtext('.//GBSeq_sequence').upper()
    assert seq==u['sequence']['value']
    native=xml(nr/f'originals/META-{row["frame"]}.xml').xpath('/ptools-xml/Protein')[0]
    uniprot_links=[x.findtext('dblink-oid') for x in native.findall('dblink') if x.findtext('dblink-db')=='UNIPROT']
    if uniprot_links: assert accession in uniprot_links
    cds_results=[]
    for b in row['cds_bindings']:
        f=nr/b['source'];assert sha(f)==b['sha256'];feature=xml(f).xpath(b['locator'])[0]
        q={x.findtext('GBQualifier_name'):x.findtext('GBQualifier_value') for x in feature.findall('GBFeature_quals/GBQualifier')}
        assert q['translation']==seq and q['protein_id']==row['protein_id']
        cds_results.append({'source':str(f),'sha256':sha(f),'locator':b['locator'],'gene':q.get('gene'),
            'product':q.get('product'),'locus_tag':q.get('locus_tag'),'exact_translation_string':True})
    proteinrows.append({'frame':row['frame'],'uniprot':accession,'protein_accession':row['protein_id'],
        'sequence_length':len(seq),'sequence_sha256':hashlib.sha256(seq.encode()).hexdigest(),
        'issuer_sequence_match':True,'native_uniprot_link':uniprot_links,'cds':cds_results,
        'source_conflict':row.get('source_conflict')})
assert len(proteinrows)==21
bam=next(r for r in identity['cds_translation_checks'] if r['protein_id']=='WP_011418919.1')
f=packages['native']/bam['source'];assert sha(f)==bam['source_sha256']
feature=xml(f).xpath(bam['locator'])[0];q={x.findtext('GBQualifier_name'):x.findtext('GBQualifier_value') for x in feature.findall('GBFeature_quals/GBQualifier')}
bam_seq=xml(P/'sources/native/issuer-originals/NCBI-protein-WP_011418919.1.xml').findtext('.//GBSeq_sequence').upper()
assert q['locus_tag']=='SYN_RS14210' and q['protein_id']=='WP_011418919.1' and q['translation']==bam_seq
save('protein-identity-replay.json',{'status':'pass','native_rows':proteinrows,'bamq':{'source':str(f),'source_sha256':sha(f),
    'locator':bam['locator'],'locus_tag':q['locus_tag'],'protein':q['protein_id'],'exact_translation_string':True},
    'scope':'Fresh comparison of complete issuer protein sequences and exact deposited CDS translation strings. No new nucleotide translation or unseen recombinant insert-sequence proof; those wider upstream checks remain separately bound.'})

activity=[]
for row in read(P/'all-fifteen-activity-design-dispositions.json'):
    aid=row['activity'];f=packages['native']/f'originals/META-{aid}.xml';a=xml(f).xpath('/ptools-xml/Enzymatic-Reaction')[0]
    enzyme=a.find('enzyme/Protein').get('frameid');reaction=a.find('reaction/Reaction').get('frameid')
    codes=[x.get('frameid') for x in a.findall('evidence/Evidence-Code')]
    if isinstance(row['design'],dict):
        de=row['design'];assert de['enzyme']==enzyme and de['reaction']==reaction and de['evidence_codes']==codes
        e=byid[de['edge_id']];assert e['subject']=='MetaCyc:'+enzyme and e['object']=='MetaCyc:'+reaction and e['predicate']==de['predicate']
    activity.append({'activity':aid,'source':str(f),'source_sha256':sha(f),'enzyme':enzyme,'reaction':reaction,
        'evidence_codes':codes,'disposition':row['design']})
assert len(activity)==15
save('activity-disposition-replay.json',{'status':'pass','rows':activity})

component=[]
for e in edges:
    if e['predicate']!='has_part': continue
    ev=e['evidence'][0];f=byhash[refs[ev['reference_id']]['source_sha256']];c=xml(f).xpath(ev['source_locator'])[0]
    frame=c.find('Protein').get('frameid');i=next(r for r in proteinrows if r['frame']==frame)
    assert e['object']=='UniProtKB:'+i['uniprot']
    coeff=int(c.findtext('coefficient','1'));assert f'multiplicity {coeff};' in e['description']
    component.append({'edge':e['id'],'complex':e['subject'],'native_component':frame,'issuing_component':e['object'],
        'multiplicity':coeff,'qualified_endpoints':[q['endpoint'] for q in e.get('endpoint_qualifiers',[])]})
assert len(component)==13
save('component-replay.json',{'status':'pass','rows':component})

cof=[]
for e in edges:
    if e['predicate']=='has_cofactor':cof.append({'edge':e['id'],'subject':e['subject'],'object':e['object'],'claim':e['description'],'qualified':bool(e.get('endpoint_qualifiers'))})
assert {e['id'] for e in edges if e['predicate'] in ['catalyzes','enables'] and e['object'] in ['MetaCyc:1.1.1.259-RXN','MetaCyc:RXN-8032']}==set()
assert not any('O88151' in e['subject']+e['object'] for e in edges)
save('scope-checks.json',{'status':'pass','cofactors':cof,'step6_catalyst_edges':0,'step7_catalyst_edges':0,
    'exact_donor_edges':0,'selected_steps':7,'auxiliary_composites':1,'participants':len(d['participants']),
    'taxa':len(d['taxa']),'edges':len(edges),'references':len(refs),'evidence':len(evidence),
    'formerly_pending_design_authority_shapes_now_separately_reviewed_and_integrated':['unnamed BCR heteromer','BCR Protein-carrier coefficient reaction','Ferredoxins classes','Oah composite','named RXN-8032'],
    'not_run_in_this_scientific_replay':['closed LinkML','authority producer/consumer','SQL binding','duplicate search','render/export','production gates'],'note':'Separate accepted authority and merged-discovery evidence are bound later; root full production gate proof remains pending.'})


print(json.dumps({'status':'pass','record_sha256':sha(O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'),'strict_design_object_equal':True,'evidence':len(evidence),'edges':len(edges),'activities':len(activity),'protein_rows':len(proteinrows),'components':len(component)},indent=2))
