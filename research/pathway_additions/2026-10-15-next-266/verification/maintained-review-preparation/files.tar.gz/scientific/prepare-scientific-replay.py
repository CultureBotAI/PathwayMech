"""Derive a fresh maintained-record replay from this reviewer's frozen prior proof.

This is finite scientific-source checking, not the deferred full repository gates.
"""
from pathlib import Path
import hashlib,json

P=Path('/private/tmp/pathwaymech-next-266-independent-design-review')
O=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'artifact-manifest.json')=='c01340c871f90ed8ef7fdc9a9953cf6e1ed19d11f9ad7b46b967951f8922ab1d'
m=json.loads((P/'artifact-manifest.json').read_text())
for r in m['files']:
    assert sha(P/r['path'])==r['sha256'] and (P/r['path']).stat().st_size==r['bytes']
text=(P/'replay.py.txt').read_text()
text=text[:text.index("save('baseline-read-binding.json'")]
text=text.replace("O = Path('/private/tmp/pathwaymech-next-266-independent-design-review')",f"O = Path('{O}')")
text=text.replace('import re\n','import re\nimport yaml\n')
text=text.replace("d=read(P/'provisional-record-design.json'); edges=", "d=yaml.safe_load((O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_text()); assert d==read(P/'provisional-record-design.json'); edges=")
text=text.replace("'pending_authority_shapes':", "'formerly_pending_design_authority_shapes_now_separately_reviewed_and_integrated':")
text=text.replace("'not_run':['closed LinkML','authority producer/consumer','SQL binding','duplicate search','render/export','production gates']", "'not_run_in_this_scientific_replay':['closed LinkML','authority producer/consumer','SQL binding','duplicate search','render/export','production gates'],'note':'Separate accepted authority and merged-discovery evidence are bound later; root full production gate proof remains pending.'")
text += "\nprint(json.dumps({'status':'pass','record_sha256':sha(O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'),'strict_design_object_equal':True,'evidence':len(evidence),'edges':len(edges),'activities':len(activity),'protein_rows':len(proteinrows),'components':len(component)},indent=2))\n"
(O/'maintained-replay.py').write_text(text)
follow=(P/'finish-review.py.txt').read_text()
follow=follow[:follow.index('notes={')]
follow=follow.replace('import hashlib,json','import hashlib,json,yaml')
follow=follow.replace("O=Path('/private/tmp/pathwaymech-next-266-independent-design-review')",f"O=Path('{O}')")
follow=follow.replace("d=read(P/'provisional-record-design.json');nodes=", "d=yaml.safe_load((O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_text());nodes=")
follow+="\nprint(json.dumps({'status':'pass','chemicals':len(identities),'taxa':len(taxa)}))\n"
(O/'maintained-chemical-taxon-replay.py').write_text(follow)
(O/'prior-scientific-assessment-reuse.json').write_text(json.dumps({'reviewer':'/root/next266_design_acceptance','prior_root':str(P),'manifest_sha256':sha(P/'artifact-manifest.json'),'all_prior_listed_files_rehashed':len(m['files']),'prior_assessment_sha256':sha(P/'ASSESSMENT.md'),'prior_handoff_sha256':sha(P/'HANDOFF.md'),'prior_edge_review_sha256':sha(P/'edge-review.json'),'prior_replay_sha256':sha(P/'replay.py.txt'),'scope':'Reuse the previously independent whole design scientific judgment with strict complete actual YAML/design semantic binding. Fresh maintained replay rechecks all sources/locators/quotes, route/coefficient/topology, protein/CDS identities and dispositions. A hash or serializer comparison alone is not scientific acceptance. Current human reading covers full actual YAML and bounded source contexts; previous whole original evidence reading remains explicitly prior, not repeated.'},indent=2)+'\n')
print('Prepared two finite source replay helpers; no full gate or maintained save invoked.')
