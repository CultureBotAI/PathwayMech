"""Bind separately executed authority/render/export checks; no gate is rerun."""
from pathlib import Path
import datetime,hashlib,json,yaml
O=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
W=Path('/private/tmp/pathwaymech-next-266-20261015')
C=Path('/private/tmp/pathwaymech-next-266-ci')
A=Path('/private/tmp/pathwaymech-next-266-independent-authority-review')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
assert sha(A/'artifact-manifest.json')=='9c23d73e5bd6becb32e703adb460439d9ee75ef34190e1968b211835dc9e7aeb'
manifest=read(A/'artifact-manifest.json')
for row in manifest['files']:
    p=A/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
integrity=read(A/'final-integrity.json');current=[]
for row in integrity['all16_authored_files_unchanged']:
    p=W/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'];current.append(row)
bound=[]
for root,files in [(A,['artifact-manifest.json','HANDOFF.md','ASSESSMENT.md','final-integrity.json']),(C,['independent-authority-root-intake.json','render-pages-receipt.json','kgx-export-receipt.json','kgx-record-fidelity.json','browser-retry/browser-cdp-result.json'])]:
    for name in files:
        p=root/name;dest=O/'root-support-inputs'/root.name/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());bound.append({'source':str(p),'sha256':sha(p),'copy':str(dest.relative_to(O))})
d=yaml.safe_load((O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_text());fid=read(C/'kgx-record-fidelity.json')
assert fid['record_sha256']==sha(O/'captured/data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml')
assert len(fid['record_edges_checked'])==76
for e,r in zip(d['mechanistic_edges'],fid['record_edges_checked'],strict=True):
    assert e['id']==r['record_edge_id'] and r['complete_claim_equal']
    assert len(e['evidence'])==r['evidence'] and len(e.get('endpoint_qualifiers',[]))==r['qualifiers']
assert len(fid['named_contexts_checked'])==56 and all(r['complete_context_equal'] for r in fid['named_contexts_checked'])
for row in fid['outputs']:assert sha(Path(row['path']))==row['sha256'] and Path(row['path']).stat().st_size==row['bytes']
render=read(C/'render-pages-receipt.json');assert render['exit_code']==0 and render['records']==263
assert sha(Path(render['new_page']))==render['new_page_sha256'];assert sha(Path(render['log']))==render['log_sha256']
browser=read(C/'browser-retry/browser-cdp-result.json');assert browser['page_sha256']==render['new_page_sha256'] and browser['runtime_errors']==[]
for row in browser['captures']:assert sha(Path(row['path']))==row['sha256']
save('separate-root-support-binding.json',{'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'bound; required production gates still pending','authority':{'independent_reviewer':'/root/next266_authority_adversarial','manifest_sha256':sha(A/'artifact-manifest.json'),'all_listed_report_files_rehashed':len(manifest['files']),'actual_current_implementation_files':current,'scope':'Read whole independent implementation assessment/handoff and independently rehash its exact current 16 inputs. Reuse its 2077 regressions, 66 probes, 33-owner producer/consumer and selected SQL-row findings with attribution; these are not tests rerun by this scientific reviewer.'},'render_export_browser':{'record_sha256':fid['record_sha256'],'generated_page_sha256':render['new_page_sha256'],'root_reported_complete_edge_comparisons':76,'root_reported_complete_named_contexts':56,'root_reported_prior_export_rows_preserved':fid['all_prior_edge_rows_exact'],'output_files_and_page_rehashed':True,'browser_result_bound':True,'scope':'Root executed rendering, complete KGX comparison and browser smoke check. This reviewer checks report identifiers/counts and output digests, without claiming a separate browser run, screenshot visual assessment or full TSV semantic replay.'},'inputs':bound,'pending':['Final production validate/test/lint/diff-check proofs','Independent retained evidence-owner acceptance and canonical final input binding']})
print(json.dumps({'status':'pass','authority_inputs_current':len(current),'root_generated_edges_bound':76,'root_generated_nodes_bound':56,'required_production_gates':'pending'}))
