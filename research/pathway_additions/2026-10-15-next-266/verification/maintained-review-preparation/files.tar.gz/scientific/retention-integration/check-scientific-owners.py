"""Exact maintained owners for this review's scientific dependencies, without copies."""
from pathlib import Path, PurePosixPath
import datetime,gzip,hashlib,json,tarfile
import yaml
W=Path('/private/tmp/pathwaymech-next-266-20261015')
P=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
O=P/'retention-integration';R=W/'research/pathway_additions/2026-10-15-next-266';E=R/'evidence-retention'
def read(p):return json.loads(p.read_text())
def digest(b):return hashlib.sha256(b).hexdigest()
def sha(p):return digest(p.read_bytes())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
assert sha(E/'artifact-manifest.json')=='424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98'
manifest=read(E/'artifact-manifest.json');physical=[]
for path in E.rglob('*'):
    assert not path.is_symlink(),str(path)
    if path.is_file():physical.append(str(path.relative_to(E)))
    else:assert path.is_dir()
assert set(physical)=={r['path'] for r in manifest['files']}|{'artifact-manifest.json'} and len(physical)==3343
for row in manifest['files']:
    q=E/row['path'];assert sha(q)==row['sha256'] and q.stat().st_size==row['bytes']
mapping=read(E/'content-map.json');cache={}
def recover(h):
    if h in cache:return cache[h]
    r=mapping[h];s=r['storage'];root=W if s['kind']=='existing_repository' else E
    assert s['kind'] in ['existing_repository','new_retention_object']
    q=root/s['path'];assert q.is_file() and not q.is_symlink()
    b=q.read_bytes();assert digest(b)==s['stored_sha256'] and len(b)==s['stored_bytes']
    if s['kind']=='existing_repository':
        assert s['git_commit']=='dd780ef273323efd638eacd63625963062e0b105'
        if 'git_tree' in s:assert s['git_tree']=='93edcbf621df2ca0551830151be39eed5ce21232'
    for step in r['decode_steps']:
        assert step['encoding']=='gzip' and digest(b)==step['input_sha256'];b=gzip.decompress(b)
        assert digest(b)==step['output_sha256'] and len(b)==step['output_bytes']
    assert digest(b)==h==r['source_sha256'] and len(b)==r['source_bytes'];cache[h]=b;return b
spec=read(E/'source-specification.json');source_maps={p['name']:read(E/'packages'/p['name']/'source-map.json') for p in spec['packages']}
by_source={r['source']:r for m in source_maps.values() for r in m['source_occurrences']}
selected={}
def add(r,role):selected.setdefault(r['source'],{'row':r,'roles':[]})['roles'].append(role)
for name in ['design','independent-design-review','independent-merged-discovery-review','independent-merged-successor-review']:
    for r in source_maps[name]['source_occurrences']:add(r,'complete '+name+' physical package')
for item in spec['packages']:
    name=item['name'];m=source_maps[name];accepted=item['manifest']
    for r in m['source_occurrences']:
        if r['path'] in {accepted,'HANDOFF.final.md' if name=='independent-native-review' else 'HANDOFF.md','ASSESSMENT.md'}:add(r,'accepted package control: '+name)
protein=read(P/'protein-identity-replay.json')
for row in protein['native_rows']:
    native=Path('/private/tmp/pathwaymech-next-266-native')
    for f in [native/'originals'/('META-'+row['frame']+'.xml'),native/'issuer-originals'/('UniProt-'+row['uniprot']+'.json'),native/'issuer-originals'/('NCBI-protein-'+row['protein_accession']+'.xml')]:add(by_source[str(f)],'fresh protein sequence/source dependency')
    for cds in row['cds']:add(by_source[cds['source']],'fresh exact CDS translation dependency')
add(by_source[protein['bamq']['source']],'fresh BamQ exact CDS dependency')
for r in read(P/'activity-disposition-replay.json')['rows']:add(by_source[r['source']],'all fifteen native activity dispositions')
bound=[]
for src,item in sorted(selected.items()):
    row=item['row'];b=recover(row['sha256']);assert len(b)==row['bytes'] and b==Path(src).read_bytes()
    owner=mapping[row['sha256']]
    bound.append({'original_source':src,'source_sha256':row['sha256'],'source_bytes':row['bytes'],'roles':item['roles'],'actual_owner':owner['storage'],'decode_steps':owner['decode_steps'],'exact_original_equal':True})
assert sum('complete design physical package' in x['roles'] for x in bound)==245
record=yaml.safe_load((W/'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml').read_text())
assert sha(W/'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml')=='e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9'
design=json.loads(recover('83776647c1cf9ad609294c576ae48e625cf5908f5fee43e55d2e6e93286d4fdf'));assert design==record
for ref in record['references']:assert ref['source_sha256'] in cache
save('scientific-maintained-owner-bindings.json',{'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'pass','payload_manifest_sha256':sha(E/'artifact-manifest.json'),'complete_physical_payload_files_hashed':len(physical),'actual_record_sha256':sha(W/'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'),'retained_design_object_equals_actual_yaml':True,'complete_design_files':245,'selected_source_occurrences':len(bound),'distinct_recovered_contents':len(cache),'rows':bound,'scope':'Independently rehash all physical maintained payload files. Independently decode every original in complete design and this reviewer\'s three frozen assessments, all named accepted package controls, all actual reference originals, and additional native protein/CDS/activity dependencies used in fresh scientific replay. No copies of recovered scientific bodies are written. Broader complete source/compact/reconstruction/provenance checks remain separately attributed to the independent retention review and root actual-copy executions.'})

archives=[]
for name in ['root-integration','retention']:
    q=R/'verification'/name;sm=read(q/'source-file-manifest.json');archive=q/'files.tar.gz'
    assert sha(archive)==sm['archive']['sha256'] and archive.stat().st_size==sm['archive']['bytes']
    with tarfile.open(archive,'r:gz') as t:
        members=t.getmembers();assert len({m.name for m in members})==len(members)
        for m in members:assert m.isfile() and not PurePosixPath(m.name).is_absolute() and '..' not in PurePosixPath(m.name).parts
        expected=set();shared=0
        for r in sm['files']:
            if name=='root-integration':member=r['member'];expected.add(member);b=t.extractfile(member).read()
            elif r['storage']['kind']=='archive_member':member=r['storage']['member'];expected.add(member);b=t.extractfile(member).read()
            else:
                assert r['storage']['kind']=='exact_maintained_payload_file';b=(W/r['storage']['repository_path']).read_bytes();shared+=1
            assert digest(b)==r['sha256'] and len(b)==r['bytes'] and b==Path(r['source']).read_bytes()
        assert {m.name for m in members}==expected
    archives.append({'package':name,'source_manifest_sha256':sha(q/'source-file-manifest.json'),'archive_sha256':sha(archive),'regular_members':len(members),'exact_shared_maintained_files':shared,'complete_source_occurrences':len(sm['files']),'all_original_bytes_equal':True})
save('portable-verification-ownership.json',{'status':'pass','rows':archives,'scope':'All actual portable archive members plus every explicit shared maintained payload owner compared with exact source bytes. No archive extracted into the maintained worktree.'})

C=Path('/private/tmp/pathwaymech-next-266-ci');receipts=[]
for name in ['maintained-retention-physical-execution.json','maintained-retention-compact-execution.json','maintained-retention-provenance-execution.json','independent-retention-successor-root-intake.json','native-integration-history.json','native-research-history.json','native-retention-history.json']:
    src=C/name;data=read(src);dest=O/'root-receipts'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(src.read_bytes())
    if 'exit_code' in data:assert data['exit_code']==0
    for k in ['stdout','stderr']:
        if k in data:assert sha(Path(data[k]['path']))==data[k]['sha256']
    histories=data.get('records',[]) if name=='native-integration-history.json' else ([data] if name in ['native-research-history.json','native-retention-history.json'] else [])
    for h in histories:assert sha(W/h['path'])==h['sha256']
    receipts.append({'source':str(src),'sha256':sha(src),'copy':str(dest.relative_to(O))})
save('root-execution-and-history-bindings.json',{'status':'pass','receipts':receipts,'scope':'Actual root-run physical/compact/provenance receipts and four native history hashes; not claimed as fresh independent executions. Complete history prose read with historical pending boundaries preserved.'})
for r in read(O/'current-context-inputs.json')['files']:assert sha(W/r['path'])==r['sha256']
for r in read(O/'prior-preparation-preservation.json')['files']:assert sha(P/r['path'])==r['sha256']
print(json.dumps({'status':'pass','payload_files':len(physical),'scientific_source_occurrences':len(bound),'distinct_scientific_contents':len(cache),'portable_archives':archives,'prior_preparation_files_preserved':len(read(O/'prior-preparation-preservation.json')['files'])},indent=2))
