# Scientific preparation supplement: actual retained evidence and report

The actual maintained retention successor and report preserve the scientific assessment of `MetaCyc:CENTBENZCOA-PWY`. No new scientific or provenance defect was identified. This supplements the earlier preparation without changing any of its files. **The final canonical review remains pending exact terminal full-gate evidence, final report binding and maintained archival ownership of the review preparation.** No completed review or production approval is claimed.

I read the complete current research report, all three current ownership READMEs, the full independent retention-successor assessment and handoff, the technical review's retention-integration supplement, the relevant root execution receipts and all four native history records. The report retains the seven selected steps, 32 material occurrences, 19 material frames, six joins, auxiliary Oah composite, all 76 edges, 25 references and 117 evidence items. Generic ferredoxin cluster units, native versus pathway direction, formal CPD-15900 cancellation, step 6's putative chemistry, real predicted/operon-scoped PimB chain, tagged preparations, source/strain conflicts and primary-access gaps remain explicit. No complete-organism demonstration, missing-backlink claim or invented lower-route enzyme appears. The new report's retention and verification statements do not change scientific scope.

## Exact current inputs and source ownership

The actual YAML is still SHA256 `e43e6ad5563c38af738e8f1c7b733510072b531196ce435395896b62951c6ab9`. Every one of the 20 previously inspected inputs remains unchanged. I created a new governed inspect with **93 exact inputs including the one maintained target**, adding current implementation, report, history, generated products, all seventeen package source maps, retained manifests and controls, and both portable verification archives. Inspect returned exit 0. This is a fresh input binding, not scientific acceptance by the helper.

I independently walked the complete actual `evidence-retention` directory, including hidden and ignored paths, rejected symlinks/nonregular entries, and rehashed all **3,343 physical files**. The complete inventory and bytes equal the accepted payload manifest `424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98`.

Using an independent in-memory reader of the content map and its exact gzip chains, I recovered **421 selected scientific source occurrences, representing 353 distinct contents**, and compared each with its complete external original. These include:

- All 245 physical files of the accepted source-to-record design, including all 115 copied original sources and complete edge/identity/route/qualifier ledgers.
- Every file of this reviewer's frozen independent design, merged-discovery and merged-successor assessments.
- Each named accepted source/reviewer package's manifest and relevant handoff/assessment controls, including the final independent-native controls.
- All native protein/issuer/CDS and activity source dependencies used in the fresh maintained scientific replay, including excluded protein examples and the exact BamQ CDS binding.

All 25 actual record reference originals resolve through these verified maintained owners. The recovered complete design object strictly equals the actual maintained YAML. Each binding retains its exact physical storage owner, stored digest/length and decode steps. No recovered source bodies were copied into this supplement. Existing repository owner paths were read from the actual maintained worktree and checked against their stored hashes; present tree fields match the corrected dd780ef tree. The broader 502 actual Git-blob/owner comparisons, 7,337 physical-source and 4,339 compact-declaration recovery, 1,334 logical-only originals and predecessor reconstruction remain explicitly attributed to the independent retention assessment and root actual-copy executions. I do not relabel them as new scientific experiments or a fresh whole-source human rereading.

The current retention README is a frozen author artifact whose original independent-acceptance/publication boundary remains historical. The current research report and dated adoption evidence accurately state the later independently accepted and performed integration. Issue 591's correction changes exactly the inherited tree provenance; no scientific body changes. Issue 590's original finding, corrected controls and separate independent acceptance are retained. Neither issue is declared published or closed by this review.

## Portable verification and native history

I independently checked every regular archive member and every explicit shared maintained owner against its original bytes:

- `verification/root-integration/files.tar.gz`: all **43** members, exact archive SHA256 `212b949aa4389e4ebe6f6416b8a424f313bbb7017e21893406229240dc0c57d9`.
- `verification/retention/files.tar.gz`: all **255** members plus **3,343** exact shared maintained payload files, covering all **3,598** source occurrences. Archive SHA256 `2c06aefdd4fd268d0022afadae0e923d8fab20eb002724d673455d1692a808af`.

Each archive has exactly its declared relative regular-file membership; no symlink, special file, duplicate name or traversal member was accepted. The complete original retention review, authored successor and independent acceptance remain represented, including failed probes, old controls and scope corrections. Root's browser launch failure and successful retry remain separate observations. Render/export/browser checks retain root attribution and their actual limits. The earlier independently bound page/KGX outputs remain exact current inputs; no extra browser or visual check was performed in this supplement.

Root's three actual maintained physical/compact/provenance execution receipts have zero exits and exact stdout/stderr hashes. The four native history records match their native-helper receipts. Their timestamps describe real creation/adoption stages; the earlier CREATE honestly leaves retention pending, and the later EDIT records its subsequent adoption while leaving final production checks and publication pending. No scientific status promotion was invented.

## Remaining boundary and execution

The root reports that the current full run has completed rendering and validation and is still running tests. This supplement does not turn partial progress into terminal pass evidence. Required next inputs are the terminal complete run, preservation of its tested inputs, final gate archive and updated report, then explicit reinspection before governed scientific review creation. Root is the sole maintained writer and saver.

All 84 files inventoried before this new stage remain byte-identical. Only the explicit external successor preparation was written. No maintained data, source archive, runtime, Git or GitHub state was changed. Exploratory directory and map displays were overbroad and truncated; those displays are not claimed as complete reading. The exact inventories and bounded source/ownership comparisons above were subsequently parsed and verified in full by the retained helper. That helper exited 0. The full current report and relevant prose were read without truncation.

Live worktree read dependencies are released after exact capture. The supplement is ready for retention; finalization must recheck changed inputs rather than refresh their hashes silently. Previous frozen source/design/review packages remain immutable, and canonical persistence is deferred until the root's stable maintained archive handoff.
