"""Create a new preparation stage without altering preceding review files."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess
P=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
O=P/'retention-integration';W=Path('/private/tmp/pathwaymech-next-266-20261015')
T=Path('/private/tmp/pathwaymech-next-266-maintained-technical-review-preparation/retention-integration')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
assert not O.exists();O.mkdir()
previous=[{'path':str(p.relative_to(P)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(P.rglob('*')) if p.is_file() and O not in p.parents]
save('prior-preparation-preservation.json',{'observed_at':now(),'scope':'All existing preparation regular files before creating this explicit successor stage; no prior file is changed.','files':previous})
prior=read(P/'capture-v3.json')
for r in prior['files']:assert sha(W/r['path'])==r['sha256']
technical=read(T/'inspect-v2-receipt.json')['command']; paths={technical[i+1] for i,x in enumerate(technical) if x=='--input'}
paths.update(r['path'] for r in prior['files'])
root='research/pathway_additions/2026-10-15-next-266/evidence-retention'
spec=read(W/root/'source-specification.json')
for pack in spec['packages']:paths.add(root+'/packages/'+pack['name']+'/source-map.json')
bindings=[]
for p in sorted(paths):
    f=W/p; row={'path':p,'sha256':sha(f),'bytes':f.stat().st_size}
    if p.startswith('history/') or p.endswith('README.md') or p.endswith('/source-map.json'):
        q=O/'captured-new-context'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes());row['copy']=str(q.relative_to(O))
    bindings.append(row)
save('current-context-inputs.json',{'captured_at':now(),'prior_20_inputs_unchanged':True,'files':bindings,'record_sha256':prior['files'][0]['sha256'],'phase':'exact current retention/report context captured before successor assessment; terminal full gate results pending'})
(O/'targets.yaml').write_bytes((P/'targets.yaml').read_bytes())
args=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(O/'targets.yaml')]
for p in sorted(paths-{prior['files'][0]['path']}):args+=['--input',p]
start=now();run=subprocess.run(args,cwd=W,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},capture_output=True)
(O/'inspect.stdout.json').write_bytes(run.stdout);(O/'inspect.stderr.txt').write_bytes(run.stderr)
save('inspect-receipt.json',{'started_at':start,'finished_at':now(),'argv':args,'cwd':str(W),'exit_code':run.returncode,'stdout_sha256':sha(O/'inspect.stdout.json'),'stderr_sha256':sha(O/'inspect.stderr.txt'),'scope':'One actual maintained scientific target; exact same prior record/contracts/registries plus new report/history/retained source controls and generated context. This is inspection only.'})
assert run.returncode==0
for r in bindings:assert sha(W/r['path'])==r['sha256']
print(json.dumps({'status':'pass','prior_files_preserved':len(previous),'current_inspected_inputs_including_target':len(bindings),'required_terminal_gates':'pending'}))
