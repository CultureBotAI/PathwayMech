"""No-network replay and bounded applicability of the retained same-day response."""
from pathlib import Path
import dataclasses, datetime, hashlib, importlib.util, json, sys
O=Path('/private/tmp/pathwaymech-next-266-maintained-scientific-review-preparation')
P=Path('/private/tmp/pathwaymech-next-265-canonical-scientific-preparation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
expected={'imodulondb-datasets-original.json':'155607e7023efdead5ebab3919279a0776d5665a7de9e28b67f02f8f521b0693','imodulondb-datasets-normalized.json':'3197d6c3d82308e41112f84cf2df9368fcc653766a8325e8eb12cccc364b82bb','imodulondb-datasets-success-receipt.json':'ac562587337b45e19b5c0f3c2ca61445497ff98c900bbf4cdfb41911e755931e'}
context=list(expected)+['imodulondb-datasets-receipt.json','imodulondb-direct-adapter-receipt.json','imodulondb-datasets.stdout','imodulondb-datasets.stderr','imodulondb-datasets-response.headers']
rows=[]
for name in context:
    p=P/name
    if name in expected:assert sha(p)==expected[name]
    dest=O/'imodulon-inputs'/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes(p.read_bytes())
    rows.append({'source':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'copy':str(dest.relative_to(O))})
receipt=read(P/'imodulondb-datasets-success-receipt.json')
adapter=Path(receipt['adapter_source']);assert sha(adapter)==receipt['adapter_sha256']
dest=O/'imodulon-inputs/imodulondb.py.txt';dest.write_bytes(adapter.read_bytes())
spec=importlib.util.spec_from_file_location('next266_readonly_imodulondb',adapter);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
raw=read(P/'imodulondb-datasets-original.json');requested=[]
def retained_transport(url):
    assert url=='https://imodulondb.org/api/datasets';requested.append(url);return raw
normalized=json.loads(json.dumps([dataclasses.asdict(x) for x in module.ImodulonDBClient(transport=retained_transport).organism_datasets()]))
assert normalized==read(P/'imodulondb-datasets-normalized.json')==receipt['rows']
assert len(normalized)==20 and sum(len(r['datasets']) for r in normalized)==28
searches=[]
for query in ['Thauera','Thauera aromatica','Syntrophus','Syntrophus aciditrophicus','Rhodopseudomonas','Rhodopseudomonas palustris','Rhodobacter palustris','CGA009','K172']:
    hits=[r for r in normalized if query.casefold() in json.dumps(r).casefold()];assert not hits
    searches.append({'query':query,'rows':hits})
ecoli=[r for r in normalized if r['organism_id']=='e_coli'];assert len(ecoli)==1
priorfail=read(P/'imodulondb-datasets-receipt.json');assert priorfail['exit_code']==1
assert sha(P/'imodulondb-datasets.stdout')==priorfail['stdout_sha256'] and sha(P/'imodulondb-datasets.stderr')==priorfail['stderr_sha256']
save('imodulon-applicability-assessment.json',{'reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'complete bounded applicability assessment','source_accessed_at':receipt['accessed_at'],'source':receipt['source'],'reused_dated_response_not_fresh_query':True,'adapter_source':str(adapter),'adapter_sha256':sha(adapter),'unmodified_adapter_offline_replay_equal':True,'transport_calls':requested,'organisms':20,'datasets':28,'whole_finite_listing_search':searches,'expression_host_row':ecoli[0],'disposition':'No taxon in the actual pathway record is represented in this complete dated dataset listing. Per-dataset pathway search and hit-table summaries are not applicable within this observed listing. E. coli is a heterologous expression host in primary assays, not a source organism for the selected route or assayed donor proteins; its expression modules cannot establish these foreign constructs or their catalysis. No membership, coexpression or experimental edge is inferred.','limits':'No current live request, database-wide biological absence claim, experiment, locus mapping or iModulon-hit result is asserted. Existing console dependency and direct transport failures are retained alongside subsequent successful public response and exact adapter replay.','inputs':rows,'failed_console_receipt_sha256':sha(P/'imodulondb-datasets-receipt.json'),'failed_direct_receipt_sha256':sha(P/'imodulondb-direct-adapter-receipt.json'),'upstream_complete_compact_map':{'path':str(P/'compact-retention-manifest.json'),'sha256':sha(P/'compact-retention-manifest.json'),'scope':'Hash-bound contextual inventory; this review selected exact named dataset/receipt artifacts and does not claim fresh full reading of that package.'}})
print(json.dumps({'status':'pass','organisms':20,'datasets':28,'actual_taxon_dataset_hits':0,'expression_host_ecoli_retained':True,'network_calls':0}))
