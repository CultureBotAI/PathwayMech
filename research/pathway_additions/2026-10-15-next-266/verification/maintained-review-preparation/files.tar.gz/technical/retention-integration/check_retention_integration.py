from pathlib import Path
import json,hashlib,datetime,tarfile,stat,subprocess,collections,copy
W=Path('/private/tmp/pathwaymech-next-266-20261015'); O=Path(__file__).parent; P='research/pathway_additions/2026-10-15-next-266'; E=W/P/'evidence-retention'; V=W/P/'verification/retention'; CI=Path('/private/tmp/pathwaymech-next-266-ci')
def h(b):return hashlib.sha256(b).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:
  assert k not in d,('duplicate',k);d[k]=v
 return d
def j(b):return json.loads(b,object_pairs_hook=pairs)
def read(p):return j(p.read_bytes())
def canonical(v):return json.dumps(v,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':'))
def files(root):
 found=[]
 for p in root.rglob('*'):
  st=p.lstat();assert stat.S_ISDIR(st.st_mode) or stat.S_ISREG(st.st_mode),str(p)
  if p.is_file():found.append(str(p.relative_to(root)))
 return set(found)
def check(p,row):
 b=p.read_bytes();assert h(b)==row['sha256'] and len(b)==row['bytes'],str(p);return b
start=datetime.datetime.now(datetime.UTC).isoformat();manifest=E/'artifact-manifest.json';assert h(manifest.read_bytes())=='424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98'
m=read(manifest);expect={r['path']:r for r in m['files']};assert len(expect)==len(m['files'])
assert files(E)==set(expect)|{'artifact-manifest.json'}
for path,row in expect.items():check(E/path,row)
assert len(expect)+1==3343
# Exact corrected map independently derived from the frozen original; all other fields must remain equal.
old=read(Path('/private/tmp/pathwaymech-next-266-retention-preparation/payload/content-map.json'));cur=read(E/'content-map.json');wanted=copy.deepcopy(old);changed=[];missing=[]
base='dd780ef273323efd638eacd63625963062e0b105';tree=subprocess.check_output(['git','-C',str(W),'rev-parse',base+'^{tree}']).decode().strip();assert tree=='93edcbf621df2ca0551830151be39eed5ce21232'
for digest,row in wanted.items():
 s=row['storage']
 if s['kind']=='existing_repository':
  assert s['git_commit']==base
  if 'git_tree' in s:changed.append((digest,s['path']));s['git_tree']=tree
  else:missing.append(digest)
assert canonical(wanted)==canonical(cur);assert len(changed)==586 and len({p for _,p in changed})==301 and len(missing)==250
owners=read(E/'existing-owner-verification.json');assert len(owners)==502 and len({r['path'] for r in owners})==502
q=''.join(r['git_commit']+':'+r['path']+'\n' for r in owners).encode();raw=subprocess.run(['git','-C',str(W),'cat-file','--batch'],input=q,capture_output=True,check=True).stdout;offset=0
for r in owners:
 assert r['git_commit']==base and r['git_tree']==tree
 pos=raw.index(b'\n',offset);a=raw[offset:pos].split();assert len(a)==3 and a[1]==b'blob' and a[0].decode()==r['git_blob'];size=int(a[2]);b=raw[pos+1:pos+1+size];assert size==r['bytes'] and h(b)==r['sha256'];assert (W/r['path']).read_bytes()==b;offset=pos+size+2;assert raw[offset-1:offset]==b'\n'
assert offset==len(raw)
vm=read(V/'artifact-manifest.json');assert files(V)=={r['path'] for r in vm['files']}|{'artifact-manifest.json'}
for row in vm['files']:check(V/row['path'],row)
sm=read(V/'source-file-manifest.json');assert len(sm['files'])==3598;archive=V/'files.tar.gz';check(archive,sm['archive']);bylogical={r['original_path']:r for r in sm['files']};assert len(bylogical)==len(sm['files'])
archives={r['storage']['member']:r for r in sm['files'] if r['storage']['kind']=='archive_member'};shared=[r for r in sm['files'] if r['storage']['kind']=='exact_maintained_payload_file'];assert len(archives)==255 and len(shared)==3343
assert {r['storage']['repository_path'] for r in shared}=={str((E/p).relative_to(W)) for p in files(E)}
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(archives) and {v.name for v in members}==set(archives)
 for v in members:
  assert v.isfile() and not Path(v.name).is_absolute() and '..' not in Path(v.name).parts
  b=tar.extractfile(v).read();row=archives[v.name];assert len(b)==row['bytes'] and h(b)==row['sha256'];assert Path(row['source']).read_bytes()==b
for row in shared:
 b=check(W/row['storage']['repository_path'],row);assert b==Path(row['source']).read_bytes()
counts=collections.Counter(n.split('/',1)[0] for n in bylogical)
for group,n in sm['complete_package_counts'].items():
 assert counts[group]==n
 roots={Path(r['source']).parents[len(Path(r['original_path']).parts)-2] for r in sm['files'] if r['original_path'].startswith(group+'/')}
 assert len(roots)==1,(group,roots)
 original_root=roots.pop();original_names=files(original_root);assert original_names=={str(Path(n).relative_to(group)) for n in bylogical if n.startswith(group+'/')}
# Bind both root adoption receipts and their actual command results without repeating runs.
promotion=read(CI/'retention-successor-promotion.json');assert promotion['source_manifest_sha256']==h(manifest.read_bytes());check(Path(promotion['acceptance']['path']),promotion['acceptance']);check(Path(promotion['copy_proof']['path']),promotion['copy_proof'])
for c in promotion['checks']:
 assert c['exit_code']==0
 for k in ['stdout','stderr']:check(Path(c[k]['path']),c[k])
# All initial technical implementation, record and registries remain equal; report/history are separately captured successors.
oldcap=read(O.parent/'capture-receipt.json');unchanged=[]
for row in oldcap['files']:
 p=row['path']
 if p.startswith(('src/','tests/','conf/','data/','docs/IDENTIFIERS')):
  check(W/p,row);unchanged.append(p)
newcontexts=[str((W/P/'README.md').relative_to(W)),str((V/'README.md').relative_to(W)),str((V/'artifact-manifest.json').relative_to(W)),str((V/'source-file-manifest.json').relative_to(W)),str((V/'files.tar.gz').relative_to(W))]
for receiptname in ['native-research-history.json','native-retention-history.json']:
 r=read(CI/receiptname);assert r['exit_code']==0 and h((W/r['path']).read_bytes())==r['sha256'];newcontexts.append(r['path'])
rows=[]
for name in newcontexts:
 b=(W/name).read_bytes();rows.append({'path':name,'sha256':h(b),'bytes':len(b)})
 if not name.endswith('.gz'):
  dest=O/'captured-new-context'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
out={'started_utc':start,'finished_utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'independent actual retention integration checks passed','payload_manifest_sha256':h(manifest.read_bytes()),'all_3343_physical_files_bound':True,'hidden_ignored_included':True,'symlinks_nonregular_rejected':True,'full_map_rows':len(cur),'exact_tree_field_corrections':len(changed),'corrected_owner_paths':len({p for _,p in changed}),'optional_tree_omissions_preserved':len(missing),'all_other_map_values_unchanged':True,'actual_git_owners_and_working_bytes_checked':len(owners),'verification_source_occurrences':len(bylogical),'archive_members_checked':len(archives),'shared_payload_owners_checked':len(shared),'complete_original_layout_counts':dict(counts),'unchanged_initial_core_inputs':unchanged,'new_context_inputs':rows,'limits':['Read and byte-bound earlier independent retention acceptance and root actual maintained verifier executions; do not claim fresh full source decoder or all compact-map semantic executions in this integration review.','Full production gates and canonical final review remain pending root handoff.','No maintained, Git/GitHub or runtime mutation occurred.']}
(O/'actual-retention-integration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['unchanged_initial_core_inputs','new_context_inputs']},indent=2))
