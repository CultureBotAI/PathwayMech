# Actual retention integration and final-render supplement

The corrected retained evidence is now present in the actual maintained worktree and passes this reviewer's independent integration checks. No new technical defect was found. This supplements, without replacing, the original preparation observations. **Final native validation/tests/lint and exact final candidate bindings remain pending; no completed canonical review is claimed.**

## Actual source and review retention

I read the complete independent retention-successor assessment and handoff, current retained README, new provenance guard and changed promotion-planner logic. Its earlier independent full byte/compact reconstruction and adversarial probes are explicitly attributed to that reviewer. I then checked the actual maintained payload myself:

- The payload manifest has exact accepted SHA256 `424d94315d50f163ea1962aacfc88f74bdc93f7b7937e9c187a7693a3c3b2b98`. All 3,343 physical file hashes, byte lengths and complete hidden/ignored-inclusive inventory match it. Symlinks and nonregular files are rejected.
- From the frozen original complete content map, I independently derived the exact expected successor by changing only the 586 present optional tree fields. Strict whole-object comparison covers every value in all 4,757 rows. These changes affect 301 owner paths; all 250 inherited rows without an optional tree retain that omission. Every other source, storage, decode and role field is unchanged.
- All 502 inherited storage owners independently match their actual pinned Git blob identity, hash, length and current working-tree bytes. Their tree matches actual `dd780ef273323efd638eacd63625963062e0b105^{tree}` (`93edcbf621df2ca0551830151be39eed5ce21232`).
- The separate maintained verification package preserves all 3,598 scoped source occurrences: exactly 255 regular tar members and 3,343 exact shared maintained payload owners. Every occurrence matches the external original byte for byte. Complete original package inventories independently equal the source manifest: original independent review 72 files, authored successor 3,448 files, independent successor acceptance 50 files, plus the explicitly selected root/helper/vendor observations. No hidden/ignored source entry is omitted within those exact named package layouts.
- The root's actual maintained physical, compact and provenance execution receipts have zero exit codes and exact stdout/stderr bindings. They check 7,337 physical source occurrences, 4,339 compact declarations including 1,334 logical-only originals, and 502 actual Git owners. These are root executions; my additional new checks are the complete maintained-byte, map, archive, source-layout and actual Git-owner comparisons described above.

The issue 591 correction therefore exists in the actual maintained evidence. The original finding, failed probes, original generator/map and both independent assessments remain preserved. The historical retained author README still accurately says independent acceptance was pending at its own freeze time; current research README and separate dated adoption evidence describe the later accepted and performed adoption. No frozen history was rewritten. Publication and issue closure are separate observations.

## Report, history and rendered outputs

I read the full report delta against the original captured report. It updates only retention correction/adoption and actual 22-artifact vendored gate status, preserving scientific claims and limitations. Both new native report-history records were read and bound to the native-helper receipts. The earlier CREATE describes then-pending retention; the later EDIT records actual adoption and accurately leaves production gates/publication pending. I found no invented curation timestamp or scientific-status promotion.

The final root `just render-pages` completed successfully for 263 records. All seven initially captured generated artifacts—record page, browse/index, pathway index, both KGX tables and download manifest—remain byte-identical after this render. The existing complete KGX/SVG comparisons and personally inspected screenshots therefore bind the current exact outputs. No extra browser run or duplicate export run is claimed.

Native `record_review.py inspect` v2 succeeded with one resolved maintained target and 73 exact context inputs, including implementation, all registries, current generated products, complete retention manifests/maps/helpers, review verification archive, current report and native history. It is an inspection only. The final one-record technical review will explicitly exclude fresh scientific interpretation and retain evidence attribution.

## Execution boundary

Only this new external supplement directory was written. Initial preparation files remain unchanged. The retention integration helper (session 7633) terminated successfully; the subsequent final-context inspection returned exit 0 directly. The guessed independent-successor directory ordering was corrected using the exact path provided by the root intake; no absence claim or mutation was based on that exploratory read error. Root's separate gate-wrapper prerequisite race occurred before any gate execution and remains honestly preserved in its own receipt.

Required next evidence is the terminal validate/test/lint/diff result, full tested-input preservation, persisted final gate evidence and exact final candidate binding. Final review persistence is not authorized by this preparatory supplement alone.
