from pathlib import Path
import json,hashlib,datetime,subprocess,os
import yaml
W=Path('/private/tmp/pathwaymech-next-266-20261015');O=Path(__file__).parent;ROOT=O.parent;P='research/pathway_additions/2026-10-15-next-266';rec='data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'
def h(b):return hashlib.sha256(b).hexdigest()
old=json.loads((ROOT/'capture-receipt.json').read_text());current=[]
for r in old['files']:
 if r['path'].startswith('pages/'):
  b=(W/r['path']).read_bytes();assert h(b)==r['sha256'],r['path'];current.append({'path':r['path'],'sha256':h(b),'same_as_initial_captured_page':True})
receipts=json.loads(Path('/private/tmp/pathwaymech-next-266-checks-initial/receipts.json').read_text());render=[r for r in receipts if r['command']==['just','render-pages']];assert len(render)==1 and render[0]['exit_code']==0;assert h(Path(render[0]['log_path']).read_bytes())==render[0]['log_sha256']
(O/'current-render-binding.json').write_text(json.dumps({'observed_at':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'All seven initially captured generated page/index/download artifacts remain byte-identical after final native render. Earlier complete KGX/graph and screenshot assessment therefore binds these current outputs; no new browser or export execution claimed.','render_receipt':render[0],'files':current},indent=2)+'\n')
target={'target_id':'MetaCyc:CENTBENZCOA-PWY','path':rec,'label':'benzoyl-CoA degradation II (anaerobic)','kind':'maintained','ownership_note':'The complete maintained pathway YAML owns record claims; code, registries, generated products and retained research inputs are assessed as technical context. Scientific correctness is separately adjudicated.'}
(O/'targets-v2.yaml').write_text(yaml.safe_dump({'targets':[target]},sort_keys=False))
inputs={r['path'] for r in old['files'] if r['path']!=rec}
inputs.update(r['path'] for r in json.loads((O/'actual-retention-integration.json').read_text())['new_context_inputs'])
inputs.update(P+'/evidence-retention/'+name for name in ['artifact-manifest.json','README.md','content-map.json','source-specification.json','source-package-inventory.json','explicit-package-compact-audit.json','verified-compact-pairs.json','logical-originals.json','existing-owner-verification.json','merged-baseline-binding.json','decode_retained.py','verify_compact.py','verify_inherited_provenance.py','plan_promotion.py','reconstruct_predecessor.py','provenance-successor/correction.json','provenance-successor/predecessor-map.json','provenance-successor/generator-replay-proof.json','provenance-successor/prepare_retention_corrected.py.txt'])
inputs.update(['src/pathwaymech/kgx.py','src/pathwaymech/graph_view.py','.claude/skills/review-yaml-record/SKILL.md','.claude/skills/add-pathway/SKILL.md','CLAUDE.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md'])
assert all((W/p).is_file() for p in inputs)
cmd=['/private/tmp/pathwaymech-next-263-verified-venv/bin/python','-B','scripts/record_review.py','inspect','--targets',str(O/'targets-v2.yaml')]
for p in sorted(inputs):cmd.extend(['--input',p])
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');start=datetime.datetime.now(datetime.UTC).isoformat()
with (O/'inspect-v2.json').open('x') as out,(O/'inspect-v2.stderr').open('x') as err:r=subprocess.run(cmd,cwd=W,env=env,stdout=out,stderr=err)
receipt={'started_utc':start,'finished_utc':datetime.datetime.now(datetime.UTC).isoformat(),'command':cmd,'exit_code':r.returncode,'stdout_sha256':h((O/'inspect-v2.json').read_bytes()),'stderr_sha256':h((O/'inspect-v2.stderr').read_bytes()),'scope':'One-record native technical review route with complete implementation/registry/generated/retention context; inspection only, not a saved or completed review.'}
(O/'inspect-v2-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');assert r.returncode==0
print(json.dumps({'generated_files_unchanged':len(current),'context_inputs':len(inputs),'native_inspect_exit':r.returncode}))
