from pathlib import Path
import hashlib,json,datetime
O=Path(__file__).parent
def h(b):return hashlib.sha256(b).hexdigest()
def emit(name,obj):
 p=O/name
 with p.open('x') as f:json.dump(obj,f,indent=2);f.write('\n')
now=datetime.datetime.now(datetime.UTC).isoformat()
prior=Path('/private/tmp/pathwaymech-next-266-independent-authority-review');m=json.loads((prior/'artifact-manifest.json').read_text());verified=[]
assert h((prior/'artifact-manifest.json').read_bytes())=='9c23d73e5bd6becb32e703adb460439d9ee75ef34190e1968b211835dc9e7aeb'
for row in m['files']:
 b=(prior/row['path']).read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256'];verified.append(row)
actual={str(p.relative_to(prior)) for p in prior.rglob('*') if p.is_file()}
assert actual=={r['path'] for r in m['files']}|{'artifact-manifest.json','freeze.json'}
receipt=json.loads((O/'capture-receipt.json').read_text());captured={r['path']:r['sha256'] for r in receipt['files']};auth=json.loads(Path('/private/tmp/pathwaymech-next-266-authority-implementation/implementation-receipt.json').read_text())
assert all(captured[r['path']]==r['sha256'] for r in auth['files'])
emit('prior-authority-review-intake.json',{'observed_at':now,'manifest_sha256':h((prior/'artifact-manifest.json').read_bytes()),'all_listed_files':verified,'all_physical_files':len(actual),'hidden_ignored_included':True,'final_implementation_files_bound':16,'test_provenance':'The 2,077 tests and 66 additional adversarial probes were run by the earlier independent authority reviewer; this technical reviewer read its complete assessment and verified its entire frozen package and exact final implementation binding, without claiming those executions as new runs.'})
B=Path('/private/tmp/pathwaymech-next-266-ci/browser-retry');res=json.loads((B/'browser-cdp-result.json').read_text());screens=[]
for row in res['captures']:
 p=Path(row['path']);assert h(p.read_bytes())==row['sha256'];screens.append({'name':p.name,'sha256':row['sha256']})
emit('independent-visual-assessment.json',{'observed_at':now,'reviewer':'/root/next266_technical_acceptance','scope':'Personally inspected all three exact screenshots using view_image; did not launch or operate this browser session. Root execution and screenshots are retained in the bound 43-member integration archive.','page_sha256':res['page_sha256'],'screenshots':screens,'observations':['Desktop overview shows a dense complete graph with 60 display nodes and 76 relationships; labels at 21 percent are small and require focus/zoom.','Focused desktop selection is legible at 100 percent; selected reaction and connected relationships are highlighted while other content is dimmed. The graph viewport intentionally shows a portion of the larger graph and has horizontal/vertical scrollbars.','Mobile selected reaction fits the graph viewport and remains legible; surrounding nodes extend beyond the scroll viewport. The component table below extends horizontally; screenshot alone does not establish a new responsive defect.','Controls and legend are visible in desktop overview. This is a three-screenshot visual assessment, not a cross-browser, keyboard, screen-reader or exhaustive accessibility audit.'],'root_runtime_evidence':{'runtime_errors':res['runtime_errors'],'selected_connected_relationships':12,'mechanism_edges':res['desktop']['graphEdges'],'all_graph_relationships':76},'initial_startup_failure':'First sandboxed root Chrome launch failed before any page evaluation; separate retry succeeded. This is not represented as a failed page behavior.'})
print(json.dumps({'prior_review_files':len(verified),'screenshots':len(screens)}))
