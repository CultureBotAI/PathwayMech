from pathlib import Path
import csv,io,json,hashlib,tarfile,datetime,collections,re
from html.parser import HTMLParser
import yaml
O=Path(__file__).parent; C=O/'captured'; B=O/'baseline'; R='data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'; P='research/pathway_additions/2026-10-15-next-266'
def h(b):return hashlib.sha256(b).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:
  assert k not in d,('duplicate-key',k)
  d[k]=v
 return d
def j(b):return json.loads(b,object_pairs_hook=pairs)
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def eq(a,b):return canon(a)==canon(b)
def readjson(p):return j(p.read_bytes())
def rows(p):return list(csv.DictReader(io.StringIO(p.read_text()),delimiter='\t'))
result={'observed_at':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'Independent technical comparison of captured actual integration; no new scientific interpretation and no fresh production validator execution.'}
reg={}
for p in ['data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json','conf/identifier_sources.json']:
 cur=readjson(C/p);old=readjson(B/p);proposal=readjson(Path('/private/tmp/pathwaymech-next-266-authority/complete-proposal-v2/proposed')/p)
 assert eq(cur,proposal)
 if isinstance(old,list):
  assert eq(cur[:len(old)],old);reg[p]={'old_rows':len(old),'new_rows':len(cur)-len(old),'ordered_prefix_preserved':True}
 else:
  assert set(cur)==set(old)
  counts={}
  for k,v in old.items():
   if isinstance(v,dict):
    assert set(v)<=set(cur[k]);assert all(eq(cur[k][name],value) for name,value in v.items());counts[k]={'old':len(v),'added':len(cur[k])-len(v)}
   else:assert eq(cur[k],v)
  reg[p]=counts
result['registry_objects']=reg
receipt=readjson(Path('/private/tmp/pathwaymech-next-266-authority-implementation/implementation-receipt.json'))
for r in receipt['files']:
 b=(C/r['path']).read_bytes();assert len(b)==r['bytes'] and h(b)==r['sha256']
result['final_implementation_bound']=len(receipt['files'])
A=C/P/'verification/root-integration';m=readjson(A/'source-file-manifest.json');archive=A/'files.tar.gz'
assert h(archive.read_bytes())==m['archive']['sha256']
expected={r['member']:r for r in m['files']}; extracted={}
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected) and len({v.name for v in members})==len(members)
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  data=tar.extractfile(member).read();r=expected[member.name];assert len(data)==r['bytes'] and h(data)==r['sha256'];extracted[member.name]=data
result['root_integration_archive']={'members':len(extracted),'all_bytes_verified':True,'no_links_or_unsafe_paths':True}
record=yaml.safe_load((C/R).read_bytes());reference={r['id']:r for r in record['references']};edges=record['mechanistic_edges']
assert len(edges)==len({e['id'] for e in edges})==76
nodes={record['id']}|{n['id'] for key in ['participants','reactions','taxa'] for n in record[key]}
assert all(e['subject'] in nodes and e['object'] in nodes for e in edges)
export=rows(C/'pages/downloads/edges.tsv');baseline=rows(B/'pages/downloads/edges.tsv');byid={r['id']:r for r in export};assert len(byid)==len(export)
assert all(byid[r['id']]==r for r in baseline)
new=[r for r in export if r['id'] not in {v['id'] for v in baseline}];assert len(new)==76
mapped={'part_of':'BFO:0000050','has_part':'BFO:0000051','occurs_in':'BFO:0000066','located_in':'RO:0001025','provides_input_for':'RO:0002413','has_input':'RO:0002233','has_output':'RO:0002234','causally_upstream_of':'RO:0002411'}
unused=list(new)
for edge in edges:
 refids=sorted({e['reference_id'] for e in edge['evidence']}|{e['reference_id'] for q in edge.get('endpoint_qualifiers',[]) for e in q['evidence']})
 expected={'subject':edge['subject'],'object':edge['object'],'predicate':mapped.get(edge['predicate'],'pathwaymech:'+edge['predicate']),'description':edge.get('description',''),'source_records':'|'.join(refids),'category':'biolink:Association','primary_knowledge_source':'infores:pathwaymech','knowledge_level':'knowledge_assertion','agent_type':'manual_validation_of_automated_agent'}
 matches=[r for r in unused if all(r[k]==v for k,v in expected.items()) and eq(j(r['evidence']),edge['evidence']) and eq(j(r['reference_metadata']),[reference[x] for x in refids]) and eq(j(r['endpoint_qualifiers']) if r['endpoint_qualifiers'] else [],edge.get('endpoint_qualifiers',[]))]
 assert len(matches)==1,edge['id'];unused.remove(matches[0])
assert not unused
newnodes={r['id']:r for r in rows(C/'pages/downloads/nodes.tsv')};oldnodes={r['id']:r for r in rows(B/'pages/downloads/nodes.tsv')}; assert len(newnodes)==len(rows(C/'pages/downloads/nodes.tsv'))
contextcount=0
for field,items in [('pathway',[{'label':record['label']}]),('participants',record['participants']),('reactions',record['reactions']),('taxa',record['taxa'])]:
 for n in items:
  ident=record['id'] if field=='pathway' else n['id'];expected={'record_id':record['id'],'collection':field,**n}
  observed=[v for v in j(newnodes[ident]['source_contexts']) if v['record_id']==record['id'] and v['collection']==field]
  assert len(observed)==1 and eq(expected,observed[0]);contextcount+=1
nodechanges=[]
for ident,r in oldnodes.items():
 assert ident in newnodes
 before=j(r['source_contexts']);after=j(newnodes[ident]['source_contexts']);assert all(any(eq(v,x) for x in after) for v in before)
 # This records all display aggregate changes; each is assessed after execution.
 diff={k:{'before':v,'after':newnodes[ident][k]} for k,v in r.items() if k!='source_contexts' and v!=newnodes[ident][k]}
 if diff:nodechanges.append({'id':ident,'changes':diff})
result['kgx']={'old_edge_rows_preserved':len(baseline),'complete_new_edges':len(new),'complete_new_contexts':contextcount,'all_old_contexts_preserved':True,'other_old_node_field_changes':nodechanges,'new_node_ids':len(newnodes)-len(oldnodes)}
class Page(HTMLParser):
 def __init__(self):super().__init__(convert_charrefs=True);self.ids=set();self.links=[];self.graph=[];self.graphnodes=[]
 def handle_starttag(self,tag,attrs):
  d=dict(attrs);classes=d.get('class','').split()
  if d.get('id'):self.ids.add(d['id'])
  if tag=='a' and 'href' in d:self.links.append(d['href'])
  if tag=='a' and 'graph-edge' in classes:self.graph.append(d)
  if tag=='a' and 'graph-node' in classes:self.graphnodes.append(d)
page=Page();page.feed((C/'pages/records/MetaCyc_CENTBENZCOA-PWY.html').read_text())
assert len(page.graph)==76
for num,(edge,d) in enumerate(zip(edges,page.graph,strict=True),1):
 assert d['data-predicate']==edge['predicate'] and d['href']==f'#mechanism-edge-{num}' and d['href'][1:] in page.ids
 for endpoint in ['subject','object']:
  q=[x for x in edge.get('endpoint_qualifiers',[]) if x['endpoint']==endpoint]
  assert d['data-'+endpoint]==(f'qualified-endpoint-{num}-{endpoint}' if q else edge[endpoint])
  assert edge[endpoint] in d['aria-label']
assert len(page.graphnodes)==60
broken=[v for v in page.links if v.startswith('#') and v[1:] not in page.ids];assert not broken,broken
result['graph']={'edges':len(page.graph),'display_nodes':len(page.graphnodes),'all_endpoint_qualifier_display_instances_exact':True,'all_local_anchor_links_resolve':True,'context_edges':sum('graph-edge-context' in d['class'] for d in page.graph)}
for p in ['pages/pathway_index.json','pages/downloads/manifest.json']:
 readjson(C/p)
result['limitations']=['Production gates and final source retention successor are pending; this is not completed canonical review.','No full scientific re-review or new browser execution. Root browser logs and screenshots are bound evidence.']
(O/'integration-checks-v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
