from pathlib import Path
import json,hashlib,datetime,subprocess
O=Path(__file__).parent; V=Path('/private/tmp/pathwaymech-next-266-vendored-check'); W=Path('/private/tmp/pathwaymech-next-266-20261015')
def h(b):return hashlib.sha256(b).hexdigest()
r=json.loads((V/'receipt.json').read_text()); s=json.loads((V/'complete-governed-scope.json').read_text());assert r['exit_code']==0
assert h((V/'vendored-check.log').read_bytes())==r['log_sha256'];assert h((V/'receipt.json').read_bytes())==s['original_native_receipt_sha256']
rows=s['current_targets'];assert len(rows)==s['actual_artifact_count']==22
for row in rows:
 b=(W/row['path']).read_bytes();assert len(b)==row['bytes'] and h(b)==row['sha256']
 old=subprocess.check_output(['git','-C',str(W),'show','dd780ef273323efd638eacd63625963062e0b105:'+row['path']]);assert old==b
out={'observed_at':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'Reviewed root executed native vendored check and its explicit original-wrapper scope clarification; independently rebound all 22 actual canonical manifest targets to current files and base Git blobs. No new gate execution.','command':r['command'],'recorded_exit_code':r['exit_code'],'log_sha256':r['log_sha256'],'full_scope_receipt_sha256':h((V/'complete-governed-scope.json').read_bytes()),'canonical_manifest_sha256':s['canonical_manifest_sha256'],'canonical_pin':s['canonical_pin'],'all_actual_governed_targets_unchanged':rows}
(O/'vendored-intake.json').write_text(json.dumps(out,indent=2)+'\n');print('22 actual governed targets exact and unchanged')
