from pathlib import Path
import subprocess,hashlib,json,datetime,shutil
import yaml
W=Path('/private/tmp/pathwaymech-next-266-20261015'); O=Path('/private/tmp/pathwaymech-next-266-maintained-technical-review-preparation'); B='dd780ef273323efd638eacd63625963062e0b105'
def git(*a):return subprocess.check_output(['git','-C',str(W),*a])
def h(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==B
paths=set(r['path'] for r in json.loads(Path('/private/tmp/pathwaymech-next-266-authority-implementation/implementation-receipt.json').read_text())['files'])
paths.update(git('diff','--name-only',B).decode().splitlines())
paths.update(['data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml','pages/records/MetaCyc_CENTBENZCOA-PWY.html','research/pathway_additions/2026-10-15-next-266/README.md'])
paths.update(str(p.relative_to(W)) for p in (W/'research/pathway_additions/2026-10-15-next-266/verification/root-integration').rglob('*') if p.is_file())
paths.update(str(p.relative_to(W)) for root in ['history/records/benzoyl-coa-degradation-ii-anaerobic','history/infrastructure/benzoyl-authority-profiles'] for p in (W/root).rglob('*') if p.is_file())
paths.update(['schema/record_review.yaml','conf/record_review.yaml','docs/record-reviews.md','docs/record-review-profile.md','src/pathwaymech/schema.py','src/pathwaymech/render.py','src/pathwaymech/graph.py','scripts/record_review.py','justfile'])
# Explicit optional implementation module spellings are discovered from tracked tree, not assumed absent.
tracked=set(git('ls-tree','-r','--name-only',B).decode().splitlines()); paths={p for p in paths if (W/p).is_file()}
rows=[]
for p in sorted(paths):
 b=(W/p).read_bytes();d=O/'captured'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 old=git('show',B+':'+p) if p in tracked else None
 if old is not None:
  q=O/'baseline'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(old)
 rows.append({'path':p,'bytes':len(b),'sha256':h(b),'base_sha256':h(old) if old is not None else None})
oldpaths=sorted(p for p in tracked if p.startswith('data/pathways/') and p.endswith('.yaml'))
current=sorted(str(p.relative_to(W)) for p in (W/'data/pathways').rglob('*.yaml'))
oldrecords=[]
for p in oldpaths:
 b=git('show',B+':'+p);assert (W/p).read_bytes()==b
 oldrecords.append({'path':p,'sha256':h(b)})
assert len(oldrecords)==262 and set(current)-set(oldpaths)=={'data/pathways/benzoyl-coa-degradation-ii-anaerobic.yaml'}
receipt={'started_at':datetime.datetime.now(datetime.UTC).isoformat(),'base_commit':B,'base_tree':git('rev-parse',B+'^{tree}').decode().strip(),'files':rows,'previous_records':oldrecords,'current_record_count':len(current),'scope':'Actual current changed implementation/registries/record/generated products/root integration archive/report/history plus review contract and schema; later source retention and final gates not yet reviewed.'}
(O/'capture-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
targets=[]
for p in sorted(paths):
 if p in {'schema/record_review.yaml','conf/record_review.yaml','docs/record-reviews.md','docs/record-review-profile.md','src/pathwaymech/schema.py','scripts/record_review.py','justfile'}:continue
 targets.append({'target_id':'technical:'+p,'path':p,'label':p,'kind':'generated' if p.startswith('pages/') else 'maintained','ownership_note':'Generated pages/downloads are owned by maintained pathway YAML and native renderer/exporter; other selected paths are their maintained owners.'})
(O/'targets-v1.yaml').write_text(yaml.safe_dump({'targets':targets},sort_keys=False))
print(json.dumps({'captured_files':len(rows),'targets':len(targets),'old_records':len(oldrecords),'new_records':len(current),'capture_sha256':h((O/'capture-receipt.json').read_bytes())}))
