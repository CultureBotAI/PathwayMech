"""Bind239 inputs and semantic deltas into the reviewed238 preparation flow."""
import ast,json
from pathlib import Path
H=Path(__file__).parent
SLUG='s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii'
def edit(n,fn):
 p=H/n;s=fn(p.read_text());ast.parse(s);p.write_text(s)
def capture(s):
 s=s.replace('a3c44b644e540faf713849b91126141a4fd540df113a0adf8cdae039896031b2','1e66867ec9eb4041e97ba03744f2891f1812ee653a40c17f2c28600152b8e7c8')
 a=s.index('    selected = [');b=s.index('    for src, rel, digest in selected:',a)
 s=s[:a]+'''    selected = [
        (Path('/private/tmp/pathwaymech-next-239-author-20261012/draft/'''+SLUG+'''.yaml'), 'data/pathways/'''+SLUG+'''.yaml', '60750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa'),
        (BUILD/'sources.json', 'data/identifier_authorities/sources.json', '90ef29ec10d1a04569df9c9983d14e9329035de267345a608e49a564a947c5f5'),
        (BUILD/'ontology.json', 'data/identifier_authorities/ontology.json', 'f155aeff12118e7aa7176c58f32ea231ad61fa25cd43a1c90aa6ff6f383ef9e2'),
    ]
'''+s[b:]
 s=s.replace('len(old_science) == 238','len(old_science) == 239').replace('/private/tmp/pathwaymech-next-238-root-postcommit-acceptance-20261012.json','/private/tmp/pathwaymech-next-238-root-local-commit-20261012/completion.json')
 s=s.replace('["scientific", "design", "canonical-execution"]','["scientific", "design", "implementation-successor", "canonical-execution"]')
 s=s.replace('manifest874','manifest887');return s
edit('capture.py',capture)
def package(s):
 s=s.replace('"authority-design",\n', '"authority-design",\n        "authority-design-independent-review",\n        "adapter-implementation",\n        "adapter-independent-review",\n        "preselection-successor",\n        "preselection-independent-review",\n')
 s=s.replace('assert len(scientific) == scientific_binding["complete_originals"] == 40','assert len(scientific) == 98')
 a=s.index('    native_originals = [');b=s.index('    groups = {}',a)
 s=s[:a]+'''    native_originals = [
        {"role": "whole_pathway_XML", "whole_original": native["pathway_XML"]},
        {"role": "whole_HTML", "whole_original": native["pathway_HTML"]["whole_original"]},
        *native["six_native_protein_assemblies_and_chains"],
    ]
    # Every complete receipt descriptor is kept, including archive parents and
    # inherited lineage; descriptor traversal does not reinterpret the science.
    receipt_descriptors = {}
    def bind_receipts(value):
        if isinstance(value, dict):
            if {"path", "bytes", "sha256"} <= set(value) and "/requests/" in value["path"]:
                receipt_descriptors[value["path"]] = value
            for child in value.values(): bind_receipts(child)
        elif isinstance(value, list):
            for child in value: bind_receipts(child)
    bind_receipts(scientific)
    for row in receipt_descriptors.values():
        standalone.append(store.owner(row["path"], row))
'''+s[b:]
 s=s.replace('== 873','== 886').replace('== 40','== 98').replace('== 6','== 8').replace('== 42','== 93').replace('": 42','": 93')
 s=s.replace('No current238','No current239').replace('Earlier237','Earlier238').replace('earlier committed bodies','earlier committed bodies')
 return s
edit('package_evidence.py',package)
def prepare(s):
 s=s.replace('len(oldmanifest) == 869 and len(newmanifest) == 874','len(oldmanifest) == 874 and len(newmanifest) == 887').replace('newmanifest[:869]','newmanifest[:874]')
 s=s.replace('"manifest_prefix_rows": 869','"manifest_prefix_rows": 874').replace('"manifest_after_rows": 874','"manifest_after_rows": 887')
 s=s.replace('    expected_delta = []\n    assert aggregate == expected_delta','    accepted = c.load("/private/tmp/pathwaymech-next-239-root-canonical-output-acceptance-20261012.json")\n    expected_delta = [{"id": r["id"], "fields": r["fields"]} for r in accepted["exact_aggregate_changes"]]\n    assert {r["id"]: r["fields"] for r in aggregate} == {r["id"]: r["fields"] for r in expected_delta}\n    assert [r["id"] for r in an if r["id"] in oldnodes] == list(oldnodes)')
 s=s.replace('len(changes) == additions == 14','len(changes) == additions == 21').replace('(4297, 11987, 4303, 12008)','(4303, 12008, 4320, 12052)').replace('len(oldss) == 32','len(oldss) == 42').replace('len(added) == len(newss) == 10','len(added) == len(newss) == 20')
 a=s.index('        "aggregate_display_scope":');b=s.index('        "old_authority_object_exceptions"',a)
 s=s[:a]+'''        "aggregate_display_scope": "Only CHEBI:17908 and CHEBI:17513 gain the accepted Protein|SmallMolecule category unions. Every old context and edge remains exact; no donor specificity or physiological inference is added.",
'''+s[b:]
 a=s.index('    stages = json.loads(')
 s=s[:a]+'''    stages = c.load(OLD / 'stages.json')
    raw = json.dumps(stages).replace('pathwaymech-next-238', 'pathwaymech-next-239').replace('5-prime-deoxyadenosine-degradation-i', 'SLUG').replace('PWY-8130', 'PWY-8132')
    stages = json.loads(raw)
    stages['history_before_first_render']['required_infrastructure_event'].update(owner='scripts/build_source_identifier_snapshot.py', description='Accepted276-file carrier/preselection runtime,887-row manifest and actual snapshots; original rejected controls and closed local finding retained.', issue_lineage=[{'local_key':'mar239-protected-identity-preselection','status':'resolved_in_accepted_successor','public_issue':None}])
    def history(kind,slug,owner,event,summary,details):
        return [PY,'-B','scripts/new_history_record.py','--kind',kind,'--slug',slug,*owner,'--event',event,'--outcome','changed','--summary',summary,'--details',details,'--actor-name','codex','--agent-tool','codex','--model','gpt-6']
    stages['history_commands'] = [
        history('record','SLUG',['--target-root','data/pathways'],'CREATE','Add complete evidence-backed S-methyl-5-thio-alpha-D-ribose 1-phosphate degradation III.', 'Exact accepted MetaCyc:PWY-8132:21 paragraphs,44 edges,7 qualifications,38 IDs,93 references and20 mappings; all five events,22 sides and whole Mar nested assembly retained. Formal ferredoxin chemistry does not identify physiological donor or ATP stoichiometry; native R2L reduction lacks a named cellular catalyst. Construct/kinetic/source limits and98 whole scientific originals remain in research/pathway_additions/2026-10-12-next-239. Actual maintained gates/native review remain pending.'),
        history('infrastructure','mar239-native-authority',['--path','scripts/build_source_identifier_snapshot.py'],'EDIT','Integrate reviewed protein-carrier authority profile and accepted actual snapshots.', 'Adopt exact276-file runtime with preselection successor,887-row manifest retaining874 old entries, and whole actual snapshots. Preserve original rejected adapter controls and local finding mar239-protected-identity-preselection plus accepted disposition; no public issue was created. All old authority objects, first owners, graph edges and contexts remain exact. Only two approved generic ferredoxin aggregate category unions change. Both histories precede SSSOM/render; maintained gates and reviews remain pending.')]
    stages['after_gates'] = [
        'Inspect actual PWY-8132 page/graph and all21 paragraphs,44 edges,7 qualifiers,38 IDs,93 references and20 mappings against exact accepted science and stated limits.',
        'Save independent scientific and technical native reviews after current inputs are inspected; preserve author/reviewer roles and inherited versus fresh source reading.',
        'Preserve239 prior records/pages,122 review pairs,406 histories, every whole old authority object/order and all12008 old KGX edge/context payloads. Only two exact ferredoxin aggregate category unions are accepted; old node encounter order is exact.',
        'Native SSSOM retains42 old full rows and relative order, plus20 exact target rows as a whole-row multiset for62 total. Native subject sorting is accepted.',
        'Recheck800 cache identities and complete hidden/ignored checkout outside exact primary/dossier/history/generated/review scope; no publication.']
    stages['before_first_render_after_history'][0].update(reason='Export20 target mappings after both histories and before renderer/tests.', preservation='All42 old rows/cells/order/header exact;20 added whole rows and62 total. Compare additions by whole-row multiplicity, not input-list order.')
    interfaces=stages['native_review_interfaces']
    interfaces['inherited_science_handoff']=c.pin('/private/tmp/pathwaymech-next-239-science-review-20261012/handoff.json')
    interfaces['actual_native_review_handoff']=c.pin('/private/tmp/pathwaymech-next-239-canonical-output-independent-review-20261012/handoff.json')
    interfaces['save_template']=[PY,'-B','scripts/record_review.py','--repo-root',str(c.ROOT),'save','--content','<independently-reviewed-completed-review.json>']
    interfaces['check_after_save']=[PY,'-B','scripts/record_review.py','--repo-root',str(c.ROOT),'check','--require-reviews','--base',c.BASE]
    stages['preservation_counts']={k:semantic[k] for k in ['old_records','old_review_yaml','old_review_markdown','old_history_yaml']}
    assert stages['preservation_counts']=={'old_records':239,'old_review_yaml':122,'old_review_markdown':122,'old_history_yaml':406}
    c.write_new(H/'stages.json',stages)
    DOS.mkdir(parents=True,exist_ok=True)
    c.write_new(DOS/'local-integration-decision.json', {'baseline_commit':c.BASE,'tree':c.TREE,'branch':c.BRANCH,'baseline_kind':'Clean committed238 local branch; not merged main','primary_owners':len(c.PRIMARY),'local_only':True,'publication_authorized':False,'shared_cache_mutation':False,'scientific_target':c.pin(PAY/'data/pathways/SLUG.yaml'),'actual_native_acceptance':c.pin('/private/tmp/pathwaymech-next-239-root-canonical-output-acceptance-20261012.json'),'baseline_postcommit_acceptance':c.pin('/private/tmp/pathwaymech-next-238-root-local-commit-20261012/completion.json'),'local_finding':'mar239-protected-identity-preselection; original rejected controls and accepted successor preserved','remaining':['root concrete preparation check','guarded local adoption','two histories before SSSOM/render','native gates','actual page and independent native reviews','preservation and local commit'],'source_exhaustion':False,'licensing':'Public-release licensing remains deferred; publication not authorized.'})
    print(json.dumps({k:semantic[k] for k in ['old_records','old_review_yaml','old_history_yaml','old_KGX','actual_after_KGX','exact_aggregate_changes']},indent=2))
    print('SSSOM planned additions',len(added))

if __name__=='__main__':main()
'''.replace('SLUG',SLUG)
 return s
edit('prepare_plan.py',prepare)
print('Configured239 capture/whole-source packaging/semantic stages; no helper execution or maintained writes.')
