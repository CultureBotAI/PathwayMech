"""Capture clean239 target and derive only the accepted runtime/config bridge."""
import ast,datetime,difflib,hashlib,json,subprocess
from pathlib import Path
H=Path(__file__).parent;OLD=Path('/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012');R=Path('/private/tmp/pathwaymech-next-239-local-20261012');PRE=Path('/private/tmp/pathwaymech-next-239-canonical-preparation-20261012');BUILD=Path('/private/tmp/pathwaymech-next-239-canonical-build-20261012')
SLUG='s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii'
BASE='12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449';TREE='67408fa8b7c7f46cf9014455d9b66c7a2458ebf5';BRANCH='feat/pathway-next-239-local-20261012'
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):
 with (H/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==BASE and git('rev-parse','HEAD^{tree}')==TREE and git('branch','--show-current')==BRANCH and not git('status','--porcelain=v1','--untracked-files=all')
write('root-target.json',{'target':str(R),'commit':BASE,'tree':TREE,'branch':BRANCH,'clean':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'captured_by':'Codex /root/aceto236_design_acceptance_review after root-authorized worktree creation','root_local_commit':pin(Path('/private/tmp/pathwaymech-next-238-root-local-commit-20261012/completion.json')),'worktree_tool_provenance':{'start':'9aaa8d','session':86076,'completion':'e04f83','exit_code':0}})
inputs=json.loads((PRE/'input-bindings.json').read_bytes());plan=json.loads((PRE/'execution-plan.json').read_bytes());overrides={'conf/identifier_sources.json':BUILD/'manifest.json','conf/rhea_identifier_updates.json':BUILD/'rhea-updates.json'}
for key,arg in [('source_builder','--manifest'),('ontology_builder','--rhea-updates')]:
 argv=plan['commands'][key];assert Path(argv[argv.index(arg)+1]) in overrides.values()
rows=[]
for row in inputs['runtime']:
 rel=str(Path(row['staged']['path']).relative_to(PRE/'runtime'));actual=BUILD/'runtime'/rel
 for d in [row['origin'],row['staged']]:assert (pin(Path(d['path']))['bytes'],pin(Path(d['path']))['sha256'])==(d['bytes'],d['sha256'])
 assert pin(actual)['sha256']==row['origin']['sha256'];effective=overrides.get(rel,actual);before=pin(R/rel) if (R/rel).exists() else None;bound=pin(effective)
 rows.append({'relative_path':rel,'accepted':row['origin'],'effective_preparation':pin(Path(row['staged']['path'])),'actual_runtime':pin(actual),'effective_integration':bound,'override_reason':'Exact explicit configuration consumed by accepted native CLI' if rel in overrides else None,'before':before,'changed':before is None or before['sha256']!=bound['sha256']})
assert len(rows)==276
changed=sorted(r['relative_path'] for r in rows if r['changed']);assert 'conf/identifier_sources.json' in changed and 'conf/rhea_identifier_updates.json' not in changed
primary=sorted(changed+['data/pathways/'+SLUG+'.yaml','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json'])
write('runtime-owner-map.json',{'runtime':rows,'runtime_count':len(rows),'changed_runtime':len(changed),'primary':primary,'explicit_native_configuration_inputs':{k:pin(v) for k,v in overrides.items()}})
def rebase(s):
 for a,b in [('pathwaymech-next-238','__CURRENT__'),('pathwaymech-next-237','pathwaymech-next-238'),('__CURRENT__','pathwaymech-next-239'),('2026-10-12-next-238','2026-10-12-next-239'),('feat/pathway-next-238','feat/pathway-next-239'),('5d3198b18a4a0f82175a65df48dd8a63664cd32d',BASE),('6ddc309c10e03cf9437ad0bdf13cead66b37606c',TREE),('deoxy238','mar239'),('5-prime-deoxyadenosine-degradation-i',SLUG),('PWY-8130','PWY-8132')]:s=s.replace(a,b)
 return s
lineage=[];patch=[]
for name in ['common.py','adopt.py','verify_portable.py','split_archive.py','run_step.py','test_controls.py','archive_controls.py','capture.py','package_evidence.py','prepare_plan.py']:
 original=(OLD/name).read_text();s=rebase(original)
 if name=='common.py':
  tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PRIMARY' for t in n.targets));lines=s.splitlines(True);lines[n.lineno-1:n.end_lineno]=['PRIMARY = frozenset('+repr(primary)+')\n'];s=''.join(lines)
 ast.parse(s)
 with (H/name).open('x') as f:f.write(s)
 lineage.append({'name':name,'predecessor':pin(OLD/name),'initial_rebased':pin(H/name)})
 patch.extend(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='238/'+name,tofile='239/'+name))
write('initial-helper-lineage.json',lineage);(H/'initial-rebase.patch').write_text(''.join(patch))
print(json.dumps({'runtime':276,'changed_runtime':changed,'primary_owners':len(primary),'primary':primary},indent=2))
