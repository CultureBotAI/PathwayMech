"""Format long literals without changing any parsed helper behavior or string value."""
import ast
import io
import json
import subprocess
import tokenize
from pathlib import Path

H = Path(__file__).parent
names = ['common.py','adopt.py','verify_portable.py','split_archive.py','capture.py','package_evidence.py','prepare_plan.py','finish.py','run_step.py','test_controls.py','archive_controls.py']
proof = []
for name in names:
    path = H / name
    before = path.read_text()
    body = before
    lines = body.splitlines(keepends=True)
    offsets = [0]
    for line in lines:
        offsets.append(offsets[-1] + len(line))
    edits = []
    for token in tokenize.generate_tokens(io.StringIO(body).readline):
        if token.type != tokenize.STRING or token.start[0] != token.end[0]:
            continue
        try:
            value = ast.literal_eval(token.string)
        except (ValueError, SyntaxError):
            continue
        if not isinstance(value, str) or len(token.string) < 80:
            continue
        replacement = '(' + '\n'.join(repr(value[i:i+65]) for i in range(0,len(value),65)) + ')'
        edits.append((offsets[token.start[0]-1]+token.start[1], offsets[token.end[0]-1]+token.end[1], replacement))
    for start, end, text in reversed(edits):
        body = body[:start] + text + body[end:]
    body = body.replace('# Preserve complete acquisition descriptors and receipt bodies in addition to all whole originals.', '# Preserve complete acquisition descriptors, receipt bodies and whole originals.')
    assert ast.dump(ast.parse(before)) == ast.dump(ast.parse(body)), name
    path.write_text(body)
    result = subprocess.run(['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python','-B','-m','ruff','format','--no-cache','--config','/private/tmp/pathwaymech-next-239-local-20261012/pyproject.toml',str(path)], capture_output=True,check=True)
    assert ast.dump(ast.parse(before)) == ast.dump(ast.parse(path.read_text())), name
    proof.append({'helper':name,'AST_and_all_string_values_unchanged':True,'formatter_stdout':result.stdout.decode(),'formatter_stderr':result.stderr.decode()})
(H/'formatting-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
