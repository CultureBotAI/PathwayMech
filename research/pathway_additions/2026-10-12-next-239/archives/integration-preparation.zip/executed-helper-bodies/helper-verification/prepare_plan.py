"Compare complete accepted deltas and prepare concrete root-owned native stages."

import csv
import io
import json
import re
from collections import Counter
from pathlib import Path

import yaml

import common as c

H = c.HERE
PAY = H / "payload"
DOS = PAY / c.DOSSIER
BUILD = Path("/private/tmp/pathwaymech-next-239-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-239-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012")
PY = "/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python"
RID = "MetaCyc:PWY-8132"


def stable(v):
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def rows(p):
    return list(csv.DictReader(io.StringIO(c.regular_bytes(p).decode()), delimiter="\t"))


def main():
    native = {}
    for name in ["sources", "ontology"]:
        rel = f"data/identifier_authorities/{name}.json"
        before, after = c.load(c.ROOT / rel), c.load(PAY / rel)
        assert list(before) == list(after)
        sections = {}
        for key, old in before.items():
            new = after[key]
            if isinstance(old, dict):
                assert [k for k in new if k in old] == list(old)
                for ident, value in old.items():
                    assert stable(value) == stable(new[ident]), (name, key, ident)
                sections[key] = {
                    "before": len(old),
                    "after": len(new),
                    "added": [k for k in new if k not in old],
                    "all_old_whole_objects_and_nested_order_exact": True,
                }
            else:
                assert stable(old) == stable(new)
        native[name] = {
            "before": c.pin(c.ROOT / rel),
            "actual_after": c.pin(PAY / rel),
            "sections": sections,
        }
    oldmanifest = c.load(c.ROOT / "conf/identifier_sources.json")
    newmanifest = c.load(PAY / "conf/identifier_sources.json")
    assert len(oldmanifest) == 874 and len(newmanifest) == 887
    assert stable(newmanifest[:874]) == stable(oldmanifest)
    assert c.regular_bytes(c.ROOT / "conf/rhea_identifier_updates.json") == c.regular_bytes(
        BUILD / "rhea-updates.json"
    )
    bn, an = rows(c.ROOT / "output/kgx/nodes.tsv"), rows(BUILD / "actual-kgx/nodes.tsv")
    be, ae = rows(c.ROOT / "output/kgx/edges.tsv"), rows(BUILD / "actual-kgx/edges.tsv")
    oldedges = {r["id"]: r for r in be}
    assert [r for r in ae if r["id"] in oldedges] == be
    oldnodes, newnodes = {r["id"]: r for r in bn}, {r["id"]: r for r in an}
    changes, aggregate = [], []
    contexts = additions = 0
    for ident, old in oldnodes.items():
        new = newnodes[ident]
        prior = json.loads(old["source_contexts"])
        current = json.loads(new["source_contexts"])
        assert [v for v in current if v["record_id"] != RID] == prior
        delta_contexts = [v for v in current if v["record_id"] == RID]
        contexts += len(prior)
        additions += len(delta_contexts)
        delta = {
            key: {"before": value, "after": new[key]}
            for key, value in old.items()
            if key != "source_contexts" and value != new[key]
        }
        if delta:
            aggregate.append({"id": ident, "fields": delta})
        if old != new:
            changes.append({"id": ident, "before": old, "after": new})
    accepted = c.load(
        ("/private/tmp/pathwaymech-next-239-root-canonical-output-acceptance-20261012.json")
    )
    expected_delta = [
        {"id": r["id"], "fields": r["fields"]} for r in accepted["exact_aggregate_changes"]
    ]
    assert {r["id"]: r["fields"] for r in aggregate} == {
        r["id"]: r["fields"] for r in expected_delta
    }
    assert [r["id"] for r in an if r["id"] in oldnodes] == list(oldnodes)
    assert len(changes) == additions == 21
    assert (len(bn), len(be), len(an), len(ae)) == (4303, 12008, 4320, 12052)
    record = yaml.safe_load(
        c.regular_bytes(
            PAY / "data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml"
        )
    )
    oldtext = c.regular_bytes(c.ROOT / "output/sssom/source_mappings.sssom.tsv").decode()
    header = [x for x in oldtext.splitlines() if x.startswith("#")]
    oldss = list(
        csv.DictReader(
            io.StringIO("\n".join(x for x in oldtext.splitlines() if not x.startswith("#"))),
            delimiter="\t",
        )
    )
    cols = [
        "subject_id",
        "subject_label",
        "predicate_id",
        "object_id",
        "object_label",
        "mapping_justification",
        "confidence",
        "comment",
    ]
    newss = []
    for mapping in record.get("source_mappings", []):
        row = {k: mapping[k] for k in cols if k != "comment"}
        row["comment"] = (
            f"source_pathway_id={mapping['source_pathway_id']}; "
            f"source_element_id={mapping['source_element_id']}"
        )
        newss.append({k: re.sub(r"[\t\r\n]+", " ", str(row[k])).strip() for k in cols})
    existing = Counter(stable(r) for r in oldss)
    assert len(oldss) == 42 and all(n == 1 for n in existing.values())
    added = [r for r in newss if stable(r) not in existing]
    assert len(added) == len(newss) == 20
    files = c.load(H / "baseline-files.json")

    def count(prefix, suffix):
        return sum(r["path"].startswith(prefix) and r["path"].endswith(suffix) for r in files)

    semantic = {
        "status": "fresh_baseline_and_accepted_actual_delta_compared_no_maintained_regeneration",
        "old_files": len(files),
        "old_records": count("data/pathways/", ".yaml"),
        "old_review_yaml": count("reviews/", ".yaml"),
        "old_review_markdown": count("reviews/", ".md"),
        "old_history_yaml": count("history/", ".yaml"),
        "native_authorities": native,
        "manifest_prefix_rows": 874,
        "manifest_after_rows": 887,
        "all_old_manifest_fields_order_exact": True,
        "old_KGX": {"nodes": len(bn), "edges": len(be), "contexts": contexts},
        "actual_after_KGX": {"nodes": len(an), "edges": len(ae)},
        "old_edges_payload_relative_order_exact": True,
        "old_node_context_payloads_order_multiplicity_exact": True,
        "old_node_row_positions_may_move_by_native_first_encounter": False,
        "old_node_encounter_relative_order_exact": True,
        "changed_old_nodes": changes,
        "existing_node_added_contexts": additions,
        "exact_aggregate_changes": aggregate,
        "aggregate_display_scope": (
            "Only CHEBI:17908 and CHEBI:17513 gain the accepted Protein|SmallM"
            "olecule category unions. Every old context and edge remains exact"
            "; no donor specificity or physiological inference is added."
        ),
        "old_authority_object_exceptions": [],
        "planning_decisions": [c.pin(PRE / "graph-planning-decision.json")],
        "actual_native_KGX": [c.pin(BUILD / "actual-kgx" / p) for p in ["nodes.tsv", "edges.tsv"]],
        "SSSOM": {
            "before": c.pin(c.ROOT / "output/sssom/source_mappings.sssom.tsv"),
            "exact_header_lines": header,
            "old_rows": len(oldss),
            "target_mappings": len(newss),
            "expected_added_rows": added,
            "expected_total_rows": len(oldss) + len(added),
            "all_old_rows_cells_multiplicity_must_remain": True,
        },
    }
    c.write_new(H / "semantic-preservation.json", semantic)
    stages = c.load(OLD / "stages.json")
    raw = (
        json.dumps(stages)
        .replace("pathwaymech-next-238", "pathwaymech-next-239")
        .replace(
            "5-prime-deoxyadenosine-degradation-i",
            "s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii",
        )
        .replace("PWY-8130", "PWY-8132")
    )
    stages = json.loads(raw)
    stages["history_before_first_render"]["required_infrastructure_event"].update(
        owner="scripts/build_source_identifier_snapshot.py",
        description=(
            "Accepted276-file carrier/preselection runtime,887-row manifest an"
            "d actual snapshots; original rejected controls and closed local f"
            "inding retained."
        ),
        issue_lineage=[
            {
                "local_key": "mar239-protected-identity-preselection",
                "status": "resolved_in_accepted_successor",
                "public_issue": None,
            }
        ],
    )

    def history(kind, slug, owner, event, summary, details):
        return [
            PY,
            "-B",
            "scripts/new_history_record.py",
            "--kind",
            kind,
            "--slug",
            slug,
            *owner,
            "--event",
            event,
            "--outcome",
            "changed",
            "--summary",
            summary,
            "--details",
            details,
            "--actor-name",
            "codex",
            "--agent-tool",
            "codex",
            "--model",
            "gpt-6",
        ]

    stages["history_commands"] = [
        history(
            "record",
            "s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii",
            ["--target-root", "data/pathways"],
            "CREATE",
            (
                "Add complete evidence-backed S-methyl-5-thio-alpha-D-ribose 1-pho"
                "sphate degradation III."
            ),
            (
                "Exact accepted MetaCyc:PWY-8132:21 paragraphs,44 edges,7 qualific"
                "ations,38 IDs,93 references and20 mappings; all five events,22 si"
                "des and whole Mar nested assembly retained. Formal ferredoxin che"
                "mistry does not identify physiological donor or ATP stoichiometry"
                "; native R2L reduction lacks a named cellular catalyst. Construct"
                "/kinetic/source limits and98 whole scientific originals remain in"
                " research/pathway_additions/2026-10-12-next-239. Actual maintaine"
                "d gates/native review remain pending."
            ),
        ),
        history(
            "infrastructure",
            "mar239-native-authority",
            ["--path", "scripts/build_source_identifier_snapshot.py"],
            "EDIT",
            ("Integrate reviewed protein-carrier authority profile and accepted actual snapshots."),
            (
                "Adopt exact276-file runtime with preselection successor,887-row m"
                "anifest retaining874 old entries, and whole actual snapshots. Pre"
                "serve original rejected adapter controls and local finding mar239"
                "-protected-identity-preselection plus accepted disposition; no pu"
                "blic issue was created. All old authority objects, first owners, "
                "graph edges and contexts remain exact. Only two approved generic "
                "ferredoxin aggregate category unions change. Both histories prece"
                "de SSSOM/render; maintained gates and reviews remain pending."
            ),
        ),
    ]
    stages["after_gates"] = [
        (
            "Inspect actual PWY-8132 page/graph and all21 paragraphs,44 edges,"
            "7 qualifiers,38 IDs,93 references and20 mappings against exact ac"
            "cepted science and stated limits."
        ),
        (
            "Save independent scientific and technical native reviews after cu"
            "rrent inputs are inspected; preserve author/reviewer roles and in"
            "herited versus fresh source reading."
        ),
        (
            "Preserve239 prior records/pages,122 review pairs,406 histories, e"
            "very whole old authority object/order and all12008 old KGX edge/c"
            "ontext payloads. Only two exact ferredoxin aggregate category uni"
            "ons are accepted; old node encounter order is exact."
        ),
        (
            "Native SSSOM retains42 old full rows and relative order, plus20 e"
            "xact target rows as a whole-row multiset for62 total. Native subj"
            "ect sorting is accepted."
        ),
        (
            "Recheck800 cache identities and complete hidden/ignored checkout "
            "outside exact primary/dossier/history/generated/review scope; no "
            "publication."
        ),
    ]
    stages["before_first_render_after_history"][0].update(
        reason="Export20 target mappings after both histories and before renderer/tests.",
        preservation=(
            "All42 old rows/cells/order/header exact;20 added whole rows and62"
            " total. Compare additions by whole-row multiplicity, not input-li"
            "st order."
        ),
    )
    interfaces = stages["native_review_interfaces"]
    interfaces["inherited_science_handoff"] = c.pin(
        "/private/tmp/pathwaymech-next-239-science-review-20261012/handoff.json"
    )
    interfaces["actual_native_review_handoff"] = c.pin(
        (
            "/private/tmp/pathwaymech-next-239-canonical-output-independent-re"
            "view-20261012/handoff.json"
        )
    )
    interfaces["save_template"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "save",
        "--content",
        "<independently-reviewed-completed-review.json>",
    ]
    interfaces["check_after_save"] = [
        PY,
        "-B",
        "scripts/record_review.py",
        "--repo-root",
        str(c.ROOT),
        "check",
        "--require-reviews",
        "--base",
        c.BASE,
    ]
    stages["preservation_counts"] = {
        k: semantic[k]
        for k in ["old_records", "old_review_yaml", "old_review_markdown", "old_history_yaml"]
    }
    assert stages["preservation_counts"] == {
        "old_records": 239,
        "old_review_yaml": 122,
        "old_review_markdown": 122,
        "old_history_yaml": 406,
    }
    c.write_new(H / "stages.json", stages)
    DOS.mkdir(parents=True, exist_ok=True)
    c.write_new(
        DOS / "local-integration-decision.json",
        {
            "baseline_commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "baseline_kind": "Clean committed238 local branch; not merged main",
            "primary_owners": len(c.PRIMARY),
            "local_only": True,
            "publication_authorized": False,
            "shared_cache_mutation": False,
            "scientific_target": c.pin(
                PAY
                / "data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml"
            ),
            "actual_native_acceptance": c.pin(
                ("/private/tmp/pathwaymech-next-239-root-canonical-output-acceptance-20261012.json")
            ),
            "baseline_postcommit_acceptance": c.pin(
                "/private/tmp/pathwaymech-next-238-root-local-commit-20261012/completion.json"
            ),
            "local_finding": (
                "mar239-protected-identity-preselection; original rejected control"
                "s and accepted successor preserved"
            ),
            "remaining": [
                "root concrete preparation check",
                "guarded local adoption",
                "two histories before SSSOM/render",
                "native gates",
                "actual page and independent native reviews",
                "preservation and local commit",
            ],
            "source_exhaustion": False,
            "licensing": "Public-release licensing remains deferred; publication not authorized.",
        },
    )
    print(
        json.dumps(
            {
                k: semantic[k]
                for k in [
                    "old_records",
                    "old_review_yaml",
                    "old_history_yaml",
                    "old_KGX",
                    "actual_after_KGX",
                    "exact_aggregate_changes",
                ]
            },
            indent=2,
        )
    )
    print("SSSOM planned additions", len(added))


if __name__ == "__main__":
    main()
