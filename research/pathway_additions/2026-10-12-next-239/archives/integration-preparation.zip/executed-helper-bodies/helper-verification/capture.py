"Read-only clean-target baseline capture and accepted external payload copies."

import datetime
from pathlib import Path

import common as c

H = c.HERE
BUILD = Path("/private/tmp/pathwaymech-next-239-canonical-build-20261012")
PRE = Path("/private/tmp/pathwaymech-next-239-canonical-preparation-20261012")
OLD = Path("/private/tmp/pathwaymech-next-238-local-integration-preparation-20261012")
ACCEPT = Path(("/private/tmp/pathwaymech-next-239-root-canonical-output-acceptance-20261012.json"))


def main():
    assert (
        c.pin(ACCEPT)["sha256"]
        == "1e66867ec9eb4041e97ba03744f2891f1812ee653a40c17f2c28600152b8e7c8"
    )
    accepted = c.load(ACCEPT)
    c.verify(accepted["actual_output"]["handoff"])
    c.verify(accepted["actual_output"]["manifest"])
    c.verify(accepted["independent_review"]["handoff"])
    c.verify(accepted["independent_review"]["manifest"])
    c.git_check(True)
    files, dirs = c.inventory(c.ROOT, exclude_git=True)
    c.write_new(H / "baseline-files.json", files)
    c.write_new(H / "baseline-directories.json", dirs)
    c.write_new(H / "cache-baseline.json", c.load(OLD / "cache-baseline.json"))
    c.cache_check()
    before = {r["path"]: r for r in files}
    owners = c.load(H / "runtime-owner-map.json")
    for row in owners["runtime"]:
        for key in ["accepted", "effective_preparation", "actual_runtime", "effective_integration"]:
            c.verify(row[key])
        if row["before"] is not None:
            c.verify(row["before"])
        if row["changed"]:
            dest = H / "payload" / row["relative_path"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(c.regular_bytes(row["effective_integration"]["path"]))
            dest.chmod(0o755 if before.get(row["relative_path"], {}).get("executable") else 0o644)
    selected = [
        (
            Path(
                (
                    "/private/tmp/pathwaymech-next-239-author-20261012/draft/s-methyl-"
                    "5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml"
                )
            ),
            "data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml",
            "60750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa",
        ),
        (
            BUILD / "sources.json",
            "data/identifier_authorities/sources.json",
            "90ef29ec10d1a04569df9c9983d14e9329035de267345a608e49a564a947c5f5",
        ),
        (
            BUILD / "ontology.json",
            "data/identifier_authorities/ontology.json",
            "f155aeff12118e7aa7176c58f32ea231ad61fa25cd43a1c90aa6ff6f383ef9e2",
        ),
    ]
    for src, rel, digest in selected:
        assert c.pin(src)["sha256"] == digest
        dest = H / "payload" / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(c.regular_bytes(src))
        dest.chmod(0o644)
    assert {r["path"] for r in c.inventory(H / "payload")[0]} == c.PRIMARY
    old_science = [
        r for r in files if r["path"].startswith("data/pathways/") and r["path"].endswith(".yaml")
    ]
    assert len(old_science) == 239
    for row in old_science:
        assert c.pin(BUILD / "corpus" / Path(row["path"]).name)["sha256"] == row["sha256"]
    inputs = [
        ACCEPT,
        H / "root-target.json",
        Path("/private/tmp/pathwaymech-next-238-root-local-commit-20261012/completion.json"),
    ] + [
        Path("/private/tmp") / f"pathwaymech-next-239-root-{name}-acceptance-20261012.json"
        for name in ["scientific", "design", "implementation-successor", "canonical-execution"]
    ]
    c.write_new(H / "accepted-inputs.json", [c.pin(p) for p in inputs])
    c.write_new(
        H / "baseline-receipt.json",
        {
            "at": datetime.datetime.now(datetime.UTC).isoformat(),
            "target": str(c.ROOT),
            "commit": c.BASE,
            "tree": c.TREE,
            "branch": c.BRANCH,
            "git_clean": True,
            "files": len(files),
            "directories": len(dirs),
            "hidden_ignored_included": True,
            "cache_entries": 800,
            "exact_primary_owners": len(c.PRIMARY),
            "old_real_records": len(old_science),
            "all_old_science_matches_accepted_actual_corpus": True,
            "actual_native_acceptance": c.pin(ACCEPT),
            "configuration": (
                "Use exact explicit accepted native manifest887; unchanged inherited "
                "Rhea config remains outside payload. No stale runtime831 config "
                "adoption."
            ),
        },
    )
    print(c.load(H / "baseline-receipt.json"))


if __name__ == "__main__":
    main()
