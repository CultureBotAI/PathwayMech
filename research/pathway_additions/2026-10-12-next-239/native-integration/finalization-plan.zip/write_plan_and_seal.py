"""Close one concrete local239 evidence adoption/native-save plan; no maintained I/O."""
import ast
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path

H = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/pathwaymech-next-239-local-20261012')
BASE = '12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449'
PY = '/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
WRAPPER = '/private/tmp/pathwaymech-next-239-run-local-step-20261012.py'

def pin(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    body = path.read_bytes()
    return {'path': str(path), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def load(name):
    return json.loads((H / name).read_bytes())

def write(name, value):
    (H / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

assert not (H / 'handoff.json').exists()
science_acceptance = Path('/private/tmp/pathwaymech-next-239-root-scientific-review-acceptance-20261012.json')
assert pin(science_acceptance)['sha256'] == '8349e3cbf26ef68645059ee4de640c7ad65ba554698341a51ae2cdfb245fb981'
(H / 'scientific-review-acceptance.json').write_bytes(science_acceptance.read_bytes())
bindings = load('input-bindings.json')
bindings['root_scientific_review_acceptance'] = pin(science_acceptance)
bindings['root_scientific_review_acceptance_exact_copy'] = pin(H / 'scientific-review-acceptance.json')
write('input-bindings.json', bindings)
lineage = load('helper-lineage.json')
for row in lineage:
    source = Path(row['predecessor']['path'])
    target = H / row['helper']
    assert pin(source) == row['predecessor']
    row['prepared'] = pin(target)
    row['exact_byte_identity'] = source.read_bytes() == target.read_bytes()
    if not row['exact_byte_identity']:
        diff = ''.join(difflib.unified_diff(source.read_text().splitlines(True), target.read_text().splitlines(True), fromfile=str(source), tofile=str(target)))
        (H / (row['helper'] + '.diff')).write_text(diff)
        row['exact_diff'] = pin(H / (row['helper'] + '.diff'))
write('helper-lineage.json', lineage)
assert lineage[0]['exact_byte_identity']
syntax = []
for name in ['prepare.py', 'adopt_evidence.py', 'finalize_native_inputs.py', 'save_reviews.py', 'retain_finalization.py', 'write_plan_and_seal.py']:
    ast.parse((H / name).read_bytes(), filename=str(H / name))
    syntax.append(pin(H / name))
write('helper-syntax.json', {'status': 'all_six_helper_sources_parse', 'helpers': syntax, 'bytecode_or_cache_written': False})

copy = load('copy-plan.json')
refs = load('evidence-reference-bindings.json')
drafts = load('native-draft-bindings.json')
assert (copy['original_owners'], copy['gzip_owners']) == (235, 43)
direct_refs = sum(bool(row.get('whole_body_identity_copy')) for row in refs)
durable = 'research/pathway_additions/2026-10-12-next-239/native-integration'
approval_flags = ['--root-acceptance', '<ROOT_ACCEPTANCE_PATH>', '--root-acceptance-sha256', '<ROOT_ACCEPTANCE_SHA256>']
def step(name, helper, args):
    return {'name': name, 'argv': [PY, '-B', WRAPPER, '/private/tmp/pathwaymech-next-239-' + name + '-20261012', PY, '-B', str(H / helper), *args]}
steps = [
    step('evidence-adoption-execution', 'adopt_evidence.py', approval_flags),
    step('native-finalization-execution', 'finalize_native_inputs.py', ['--root', str(ROOT), '--draft-directory', '/private/tmp/pathwaymech-next-239-finalization-execution-inputs-20261012', '--output', '/private/tmp/pathwaymech-next-239-root-native-finalized-20261012']),
    step('native-review-save-execution', 'save_reviews.py', approval_flags),
    step('finalization-preservation-execution', 'retain_finalization.py', []),
]
plan = {
    'status': 'prepared_only_pending_exact_root_acceptance', 'target': str(ROOT), 'base_commit': BASE,
    'base_tree': '67408fa8b7c7f46cf9014455d9b66c7a2458ebf5', 'branch': 'feat/pathway-next-239-local-20261012',
    'local_only': True, 'publication_authorized': False, 'maintained_writes_performed': False,
    'scope': 'Adopt complete accepted independent scientific and root technical/maintained QA evidence losslessly; fresh inspect extends original native inputs; validate/save two unchanged reviews; verify append-only/currentness and retain actual execution evidence.',
    'approval_contract': {'target': str(ROOT), 'base_commit': BASE, 'local_only': True, 'publication_authorized': False, 'finalization_handoff': 'Exact path/bytes/sha256 pin of this sealed handoff.json. Approval itself is pinned by CLI digest and copied durably.'},
    'source_packets': bindings, 'drafts': drafts, 'copy_plan': pin(H / 'copy-plan.json'), 'storage_ledger': pin(H / 'storage-ledger.json'),
    'storage': {'original_qa_owners': 235, 'deterministic_gzip_python_owners': 43, 'identity_owners': 192, 'stored_qa_bytes': sum(r['bytes'] for r in copy['files']), 'additional_owners': ['maintained-review-acceptance.json', 'scientific-review-acceptance.json', 'storage-ledger.json', 'finalization-plan.zip', 'README.md', 'root-storage-map.json'], 'total_pre_save_adopted_owners': 241, 'durable_prefix': durable, 'direct_evidence_reference_occurrences_bound': direct_refs, 'original_paths_hashes_sizes_modes_and_stored_paths_explicit': True, 'complete_decoded_original_packet_closures_verified': True},
    'commands_in_order': steps,
    'guards': ['Exact approval, current base/tree/branch and empty index; complete original packet closure including hidden/ignored/literal types.', 'Before first maintained write, complete old physical owner/directory scope and 800 cache entries; all 276 accepted runtime bodies; all original SCI41/TECH35 native descriptors current.', 'Every planned whole original decoded and compared; all 241 new bodies preloaded and absent destinations verified. All existing owners/cache preserved after copy.', 'Fresh shared native inspect includes adopted evidence; every original input descriptor, target, other source field, reviewer, judgment, timestamp and review ID unchanged; native validate before save.', 'Two native shared serializer saves only; append-only review check against 238 base, bounded no-cache Ruff and unstaged diff check. Only four review files/two directories may be added; 122 old pairs exact,124 total.', 'Retain exact actual helper/command/stream evidence losslessly; all saved input hashes current, full physical changed-file inventory including ignored/hidden equals Git candidates,800 cache exact.'],
    'expected_corpus': {'records': 240, 'history_events': 408, 'review_pairs_before': 122, 'review_pairs_after': 124},
    'science_role': 'This preparer authored the scientific draft; no new independent scientific judgment is asserted here. Nitrate independently reviewed the record science, with earlier same-day whole-primary reading explicitly inherited in its maintained review. Root independently reviewed the technical changes.',
    'preserved_failures': ['Actual vendored sandbox DNS failure and first public read-only retry BrokenPipeError; final successor passed.', 'SCI two preparation guard failures plus separate native serializer guard failure; original proposal remains unchanged.', 'This preparation original rich-manifest descriptor equality assertion; corrected reader only, exact captured original/helper/streams retained.', 'Root SCI intake generic artifacts-key KeyError, recorded in exact root acceptance; direct whole files-manifest closure subsequently passed.'],
    'inheritance': 'Complete native gates, scientific source reading, root whole target/checkout preservation and accepted runtime regressions are inherited from pinned actual receipts. This preparation freshly verified packet/storage closure, whole native copy, original current input bodies, accepted runtime files and draft identity; no broad suite, builder or full source-paper reread.',
    'local_commit_followup': ['After actual native save/preservation succeeds, provide exact NUL pathspec and complete changed-file pins plus saved pair pins to root.', 'Stage only exact reviewed inventory when root authorizes. Retain full staged whitespace-check result; any immutable original-byte warnings require exact source/path appraisal, never source normalization or repository-wide exemptions.', 'Verify every staged index blob/mode/content against the concrete inventory, write local commit, verify exact commit/tree/parent and clean checkout. Prepare a small local PR description; no network/public operations.'],
    'not_executed': ['evidence adoption', 'native input extension', 'native review saves', 'staging', 'commit', 'publication'],
}
write('plan.json', plan)
(H / 'REPORT.md').write_text(f'''# 239 local native-review finalization preparation

Prepared one concrete local evidence adoption and native-save sequence for `{ROOT}` at `{BASE}`. Nothing in the maintained checkout was written by this preparation. Root acceptance of this exact handoff is required by the executor; no public operation is included.

The two complete accepted QA packets contain 235 originals: root 44+2 and SCI 187+2. SCI includes the complete actual native 92+2 packet. All originals and directory/type closure were freshly checked, including hidden and ignored content. Exactly 43 Python audit originals are stored as deterministic lossless `.py.gz`; the other 192 owners, original seals and every directly cited JSON body retain identity storage. The ledger binds original and stored paths, sizes, SHA-256 and executable modes. All decoded originals reconstruct the original packets. There are {direct_refs} direct copied evidence-reference occurrences bound; repeated references are not counted as distinct files.

Six additional owners retain the root execution acceptance, the existing scientific acceptance, storage ledger, entire sealed preparation ZIP, explanation and actual storage map: 241 pre-save adopted owners in total. The root scientific acceptance is the exact 2155-byte `8349e3cb…` body. All whole bodies are checked before the first maintained write. External Python originals are compressed or inside the archive; no Ruff exemption or source normalization is introduced.

The SCI proposal preserves 72 assessments,21 checks,41 original native inputs; TECH preserves 16 assessments,14 checks,35 original inputs. Together these bind 58 distinct current bodies. The shared finalizer is byte-identical to 238 (SHA `313422118bfc726ca607ce2fb184bbbf34f998ae63507719967fcd72db2497a4`). It freshly inspects the copied evidence and validates both extended documents. The saver checks every old descriptor and every other field, including reviewer, target, source base, judgments and timestamps, before using the native serializer. It runs the append-only review check, no-cache Ruff and unstaged diff check, verifies only four new native files, and preserves all122 old review pairs and800 cache entries. Expected totals remain240 records,408 histories and124 review pairs. Actual later counts and outputs will be recorded, not presumed complete here.

This preparer authored the scientific draft. Independent SCI judgments belong to nitrate; independent TECH judgments belong to root. No fresh paper reading or new scientific assessment is claimed here. The accepted same-day primary reading and root whole maintained/graph/source checks are inherited transparently. Fresh preparation covers exact whole packet/storage/draft closure, original native-input currentness, accepted276 runtime bodies, and helper syntax. No broad suite or builder was rerun. Later executor guards recheck current whole owner/cache scope before writes and native currentness before saves.

All failures remain visible: two actual fetch failures before successful native completion; SCI two preparation failures plus one serializer guard failure; root's SCI manifest-key reader failure in its acceptance; and this preparation's initial rich-descriptor equality assumption (`c34b1b/1`) followed by a reader-only correction (`5b9dd4/session72746 → 280d0f/0`). The original helper, command/streams, correction and successful execution are retained. These are distinct from product defects. All nine actual gates ultimately passed;4581 tests passed,3 skipped,3 warnings, without a broad rerun.

Read `plan.json`, the complete four execution helpers, `helper-lineage.json` and exact predecessor diffs, `copy-plan.json`, `storage-ledger.json`, `native-draft-bindings.json` and `preparation-checks.json`. `plan.json` supplies the root receipt contract and exact wrapper commands. After execution, `retain_finalization.py` produces a full ignored-inclusive changed-file inventory and NUL pathspec for root's staged diff/whitespace appraisal and authorized local commit. No staging or commit is performed by these prepared commands. Licensing/access and visual/scientific limitations remain exactly those in the accepted reviews.
''')

rows, dirs = [], []
for base, names, files in os.walk(H, followlinks=False):
    names.sort(); files.sort()
    assert all(not (Path(base) / name).is_symlink() for name in names)
    for name in names:
        dirs.append((Path(base) / name).relative_to(H).as_posix())
    for name in files:
        path = Path(base) / name
        assert not path.is_symlink() and path.is_file()
        rows.append({**pin(path), 'relative_path': path.relative_to(H).as_posix(), 'file_type': 'regular', 'executable': bool(path.stat().st_mode & 0o111)})
rows.sort(key=lambda row: row['relative_path'])
write('artifact-manifest.json', {'root': str(H), 'artifacts': rows, 'directories': sorted(dirs), 'inventory_scope': 'Complete literal walk including hidden and ignored files; no links or special objects.'})
write('handoff.json', {'status': 'sealed_local_review_finalization_preparation_pending_root_execution_acceptance', 'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'target': str(ROOT), 'base_commit': BASE, 'manifest': pin(H / 'artifact-manifest.json'), 'artifacts': len(rows), 'seals': 2, 'directories': len(dirs), 'plan': pin(H / 'plan.json'), 'report': pin(H / 'REPORT.md'), 'copy_plan': pin(H / 'copy-plan.json'), 'storage_ledger': pin(H / 'storage-ledger.json'), 'scientific_acceptance': pin(H / 'scientific-review-acceptance.json'), 'native_drafts': pin(H / 'native-draft-bindings.json'), 'entry_points': ['REPORT.md', 'plan.json', 'adopt_evidence.py', 'finalize_native_inputs.py', 'save_reviews.py', 'retain_finalization.py', 'helper-lineage.json'], 'maintained_writes': 0, 'native_saves': 0, 'publication_authorized': False})
print(json.dumps({'handoff': pin(H / 'handoff.json'), 'manifest': pin(H / 'artifact-manifest.json'), 'artifacts': len(rows), 'directories': len(dirs), 'pre_save_evidence_owners': 241}))
