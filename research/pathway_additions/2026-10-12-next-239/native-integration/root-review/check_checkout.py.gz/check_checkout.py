"""Verify complete physical preservation after native gates, before review adoption."""
import sys,json,datetime,hashlib
from pathlib import Path
prep=Path('/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012')
sys.path.insert(0,str(prep))
import common as c
root=c.ROOT
out=Path(__file__).parent
plan=c.load(prep/'plan.json');stages=c.load(prep/'stages.json')
baseline=c.load(prep/'baseline-files.json');before={r['path']:r for r in baseline}
after,dirs=c.inventory(root,exclude_git=True);by={r['path']:r for r in after}
changes={r['destination']:r for r in plan['changes']}
generated=set(stages['allowed_generated_paths'])
new_histories={p for p in by if p.startswith('history/') and p.endswith('.yaml') and p not in before}
assert len(new_histories)==2
assert set(by)==set(before)|set(changes)|generated|new_histories
for p,row in before.items():
 if p not in changes and p not in generated:assert by[p]==row,p
for p,row in changes.items():
 expected={'path':p,'type':'regular','bytes':row['payload']['bytes'],'sha256':row['payload']['sha256'],'executable':row['executable']}
 assert by[p]==expected,p
old_dirs=set(c.load(prep/'baseline-directories.json'))
expected_dirs=set(old_dirs)
for path in set(changes)|generated|new_histories:
 expected_dirs.update(str(p) for p in Path(path).parents if str(p)!='.')
# c.inventory omits the root itself; preserve that existing representation.
assert set(dirs)==expected_dirs,(sorted(set(dirs)-expected_dirs),sorted(expected_dirs-set(dirs)))
c.cache_check()
receipts=Path('/private/tmp/pathwaymech-next-239-local-native-execution-20261012')
history=c.load(receipts/'history-and-generation/completion.json')
remaining=c.load(receipts/'remaining-offline-gates/completion.json')
network=c.load(receipts/'network-resumption-successor/completion.json')
assert all(x['status']=='phase_passed' for x in [history,remaining,network])
assert [r['name'] for r in remaining['receipts']]==['validate','tests','lint','kgx']
assert [r['name'] for r in network['receipts']]==['vendored','diff-check','site-current']
for failed in ['vendored-gate','network-resumption']:
 r=c.load(receipts/failed/'vendored.execution.json')
 assert r['exit_code'] != 0
 c.verify(r['stdout']);c.verify(r['stderr'])
hr=[r for r in history['receipts'] if r['name'].startswith('history-')]
render=next(r for r in history['receipts'] if r['name']=='render')
sssom=next(r for r in history['receipts'] if r['name']=='sssom')
assert len(hr)==2 and all(r['exit_code']==0 and r['finished_at']<sssom['started_at']<render['started_at'] for r in hr)
all_receipts=history['receipts']+remaining['receipts']+network['receipts']
assert all(r['exit_code']==0 for r in all_receipts)
for r in all_receipts:
 c.verify(r['stdout']);c.verify(r['stderr'])
for a,b in zip(all_receipts,all_receipts[1:]):assert a['finished_at']<=b['started_at']
value={'status':'complete_checkout_preservation_after_native_gates_passed','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_files':len(before),'current_files':len(by),'baseline_directories':len(old_dirs),'current_directories':len(dirs),'whole_old_owners_preserved_outside_exact_plan':True,'hidden_and_ignored_included':True,'git_metadata_excluded':True,'cache_entries_unchanged':800,'new_histories':[by[p] for p in sorted(new_histories)],'history_completed_before_first_render':True,'adopted_owners':len(changes),'allowed_generated_paths':sorted(generated)}
with (out/'checkout-preservation.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in value.items() if k not in ['new_histories','allowed_generated_paths']}))
