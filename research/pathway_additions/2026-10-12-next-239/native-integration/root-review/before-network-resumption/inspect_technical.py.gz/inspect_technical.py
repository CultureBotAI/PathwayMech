"""Capture current native review inputs only after all 239 gates complete."""
import datetime
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

H = Path(__file__).parent
R = Path('/private/tmp/pathwaymech-next-239-local-20261012')
P = Path('/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012')
N = Path('/private/tmp/pathwaymech-next-239-local-native-execution-20261012')
PY = '/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'


def pin(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


for phase in ('history-and-generation', 'remaining-offline-gates', 'vendored-gate', 'final-gates'):
    result = json.loads((N / phase / 'completion.json').read_bytes())
    assert result['status'] == 'phase_passed'
    assert all(row['exit_code'] == 0 for row in result['receipts'])
for name in ('target.execution.json', 'checkout.execution.json'):
    assert json.loads((H / name).read_bytes())['exit_code'] == 0

plan = json.loads((P / 'plan.json').read_bytes())
paths = [r['destination'] for r in plan['changes']
         if not r['destination'].startswith(('data/pathways/', 'research/'))]
assert len(paths) == 11
targets = [
    {'target_id': 'owner-' + str(i), 'path': path, 'label': path,
     'kind': 'maintained',
     'ownership_note': 'Exact adopted source configuration, reviewed runtime/fixture/test, or native authority snapshot. Generated snapshots require rebuilding from maintained configuration and adapters.'}
    for i, path in enumerate(paths, 1)
]
with (H / 'technical-targets.json').open('x') as f:
    json.dump({'targets': targets}, f, indent=2)
    f.write('\n')
inputs = [r['destination'] for r in plan['changes'] if r['destination'] not in paths]
inputs += [
    'docs/record-reviews.md', 'docs/record-review-profile.md', 'schema/record_review.yaml',
    '.claude/skills/review-yaml-record/SKILL.md', 'src/pathwaymech/schema.py',
    'scripts/build_ontology_identifier_snapshot.py', 'conf/identifier_policy.yaml',
    'conf/rhea_identifier_updates.json', 'pages/records/MetaCyc_PWY-8132.html',
    'output/sssom/source_mappings.sssom.tsv', 'output/kgx/nodes.tsv', 'output/kgx/edges.tsv',
]
inputs = list(dict.fromkeys(inputs))
assert all((R / p).is_file() for p in inputs)
cmd = [PY, '-B', 'scripts/record_review.py', '--repo-root', str(R), 'inspect', '--targets', str(H / 'technical-targets.json')]
for path in inputs:
    cmd += ['--input', path]
env = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'UV_NO_SYNC': '1'}
start = datetime.datetime.now(datetime.UTC).isoformat()
tick = time.monotonic()
with (H / 'technical-inspect.stdout').open('xb') as out, (H / 'technical-inspect.stderr').open('xb') as err:
    result = subprocess.run(cmd, cwd=R, env={**os.environ, **env}, stdout=out, stderr=err)
receipt = {'command': cmd, 'cwd': str(R), 'environment': env, 'started_at': start,
           'finished_at': datetime.datetime.now(datetime.UTC).isoformat(), 'seconds': time.monotonic()-tick,
           'exit_code': result.returncode, 'helper': pin(Path(__file__)),
           'targets': pin(H / 'technical-targets.json'), 'stdout': pin(H / 'technical-inspect.stdout'),
           'stderr': pin(H / 'technical-inspect.stderr')}
with (H / 'technical-inspect.execution.json').open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps(receipt))
raise SystemExit(result.returncode)
