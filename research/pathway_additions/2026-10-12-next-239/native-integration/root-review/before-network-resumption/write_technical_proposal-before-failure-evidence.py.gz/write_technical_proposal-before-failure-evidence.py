"""Root technical judgments, executed only after current maintained checks."""
import datetime
import hashlib
import json
import re
import shlex
import shutil
from pathlib import Path

H = Path(__file__).parent
R = Path('/private/tmp/pathwaymech-next-239-local-20261012')
N = Path('/private/tmp/pathwaymech-next-239-local-native-execution-20261012')
PREFIX = 'research/pathway_additions/2026-10-12-next-239/native-integration/'


def load(p):
    return json.loads(Path(p).read_bytes())


def pin(p):
    p = Path(p)
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


now = datetime.datetime.now(datetime.UTC)
finished = now.strftime('%Y-%m-%dT%H:%M:%SZ')
inspection = load(H / 'technical-inspect.stdout')
assert inspection['status'] == 'inspection_only'
for row in inspection['source']['inputs']:
    assert pin(R / row['path'])['sha256'] == row['sha256'], row['path']

for source, dest in [
    ('/private/tmp/pathwaymech-next-239-root-canonical-output-acceptance-20261012.json', 'canonical-acceptance.json'),
    ('/private/tmp/pathwaymech-next-239-root-integration-acceptance-20261012.json', 'integration-acceptance.json'),
    ('/private/tmp/pathwaymech-next-239-root-implementation-successor-acceptance-20261012.json', 'implementation-acceptance.json'),
]:
    assert not (H / dest).exists()
    shutil.copyfile(source, H / dest)

target_ids = [t['target_id'] for t in inspection['targets']]
assert len(target_ids) == 11
evidence = []
checks = []


def ev(eid, path, reference, summary, kind='validation'):
    evidence.append({'evidence_id': eid, 'kind': kind, 'reference': reference,
                     'accessed_at': finished, 'support': 'supports', 'summary': summary,
                     'snapshot_sha256': pin(path)['sha256']})


for phase in ['history-and-generation', 'remaining-offline-gates', 'network-resumption-successor']:
    completion = load(N / phase / 'completion.json')
    assert completion['status'] == 'phase_passed'
    for receipt in completion['receipts']:
        assert receipt['exit_code'] == 0
        for stream in ('stdout', 'stderr'):
            assert pin(receipt[stream]['path'])['sha256'] == receipt[stream]['sha256']
        eid = 'native-' + receipt['name']
        path = N / phase / (receipt['name'] + '.execution.json')
        ev(eid, path, PREFIX + 'independent-qa/actual-native/' + phase + '/' + path.name,
           'Actual recorded native command and complete original streams verified. Executed by integration agent; root did not rerun it.')
        checks.append({'check_id': eid, 'name': 'Actual native ' + receipt['name'],
                       'status': 'passed', 'required': not receipt['name'].startswith('history-'),
                       'summary': 'Actual recorded process exited0; scientific interpretation is separately reviewed.',
                       'target_ids': target_ids, 'command': shlex.join(receipt['argv']),
                       'exit_code': 0, 'expected_exit_code': 0, 'evidence_ids': [eid]})
        if receipt['name'] == 'tests':
            test_text = Path(receipt['stdout']['path']).read_text()
            matches = re.findall(r'(\d+) passed, (\d+) skipped, (\d+) warnings?', test_text)
            assert len(matches) == 1
            passed, skipped, warnings = map(int, matches[0])

for name in ('target', 'checkout'):
    receipt = load(H / (name + '.execution.json'))
    assert receipt['exit_code'] == 0
    ev('root-' + name, H / (name + '.execution.json'), PREFIX + 'root-review/' + name + '.execution.json',
       'Root personally executed complete current target/render/export or physical checkout/cache checks after native gates completed.')
    checks.append({'check_id': 'root-' + name, 'name': 'Root maintained ' + name + ' QA',
                   'status': 'passed', 'required': True, 'summary': 'Whole maintained check passed after all native gates.',
                   'target_ids': target_ids, 'command': shlex.join(receipt['argv']),
                   'exit_code': 0, 'expected_exit_code': 0, 'evidence_ids': ['root-' + name]})

for eid, name, summary, kind in [
    ('canonical', 'canonical-acceptance.json', 'Accepted whole native source/ontology outputs and independent old-object/order/KGX preservation review; no fresh scientific reinterpretation.', 'prior_review'),
    ('integration', 'integration-acceptance.json', 'Root reviewed exact23 destinations,12primary owners, full helper logic and native stages; fresh entire hidden/ignored baseline,800cache entries and sealed payload checked. Portable2746-body replay is inherited from preparer.', 'prior_review'),
    ('implementation', 'implementation-acceptance.json', 'Accepted carrier/preselection successor preserves original local finding mar239-protected-identity-preselection and its rejected evidence. Prior independent adversarial tests are inherited; full maintained regression is fresh.', 'prior_review'),
    ('target-results', 'target-qa.json', 'Whole current YAML,44arrows,42display nodes,7qualifiers,38identities,93references and complete evidence tables checked; whole authorities/exports equal actual accepted native bodies;42old+20new mappings.', 'validation'),
    ('checkout-results', 'checkout-preservation.json', 'All old physical owners outside exact changes/generated outputs preserved, including239records/pages,122review pairs,406histories and800cache entries. Two native histories precede SSSOM/render.', 'validation'),
    ('visual', 'visual-assessment.json', 'Root personally viewed full light raster; whole current graph and assets match the inspected preview. Dense junctions, truncated labels, small whole-image text and tall blank canvas remain limits.', 'validation'),
]:
    ev(eid, H / name, PREFIX + 'root-review/' + name, summary, kind)

assessments = []


def assess(aid, area, topic, summary, ids, evs):
    assessments.append({'assessment_id': aid, 'area': area, 'topic': topic, 'outcome': 'supported',
                        'summary': summary, 'target_ids': ids, 'evidence_ids': evs})


for target in inspection['targets']:
    assess(target['target_id'], 'ownership', target['path'],
           'Whole maintained owner equals its accepted runtime/configuration/native-output payload. Source adapter changes and fixture/test contracts were independently reviewed upstream; this review verifies their exact maintained integration and fresh full regression. Future snapshot corrections require rebuilding from their maintained owners.',
           [target['target_id']], ['canonical', 'implementation', 'root-target', 'integration'])
assess('prior-preservation', 'provenance', 'Whole authority and checkout preservation',
       'All prior nested authority objects and encounter order survive;887manifest entries retain all874old rows exactly. Old239records/pages,122review pairs and406histories remain exact. Two actual histories precede SSSOM and first rendering.',
       target_ids, ['canonical', 'checkout-results', 'native-history-1', 'native-history-2'])
assess('graph-exports', 'graph', 'Whole graph and current page',
       'All44edges,42display nodes,7qualifiers,93references and38identities resolve. Current KGX is4320nodes/12052edges and preserves all12008old edges and prior node contexts/order. Twenty-one old nodes gain target contexts. Only CHEBI:17908 and CHEBI:17513 gain the reviewed Protein|SmallMolecule category unions, retaining existing contexts; this adds no physiological donor or ATP stoichiometry assertion.',
       target_ids, ['canonical', 'target-results', 'visual'])
assess('mapping-export', 'representation', 'Complete source mappings',
       'Native SSSOM preserves the full header and42old rows including every cell, multiplicity and relative order, and adds20exact target rows for62total. New rows follow native subject sorting.',
       target_ids, ['native-sssom', 'target-results'])
assess('native-gates', 'schema', 'Fresh maintained validation',
       f'All nine native gates passed for240records: {passed} tests passed, {skipped} skipped and {warnings} warnings retained. Render,skills,validation,lint,KGX,vendored,diff and site-current evidence is complete. This does not replace scientific review.',
       target_ids, ['native-validate', 'native-tests', 'native-lint', 'native-kgx', 'native-vendored', 'native-diff-check', 'native-site-current'])
assess('portable-evidence', 'completeness', 'Whole evidence provenance',
       'Accepted preparation contains2746whole decoded bodies,1771reused committed owners and975new bodies. All98scientific originals and93reference hashes remain bound. Original rejected adapter controls and resolved local finding remain available. This review inherits scientific source readings and portable replay; no new original acquisition or prior unread supplement claim.',
       target_ids, ['integration', 'implementation', 'root-target', 'checkout-results'])

started = datetime.datetime.fromisoformat(load(H / 'technical-inspect.execution.json')['started_at']).astimezone(datetime.UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
value = {
    'schema_version': '1.0.0', 'review_id': now.strftime('%Y%m%dT%H%M%SZ') + '-mar239-technical',
    'kind': 'repository', 'repository': 'CultureBotAI/PathwayMech',
    'title': 'Technical review of DHAP-ethylene shunt maintained integration',
    'started_at': started, 'finished_at': finished,
    'reviewer': {'identity': 'Codex /root', 'kind': 'agent', 'independence': 'independent',
                 'independence_basis': 'Root did not author the record, production adapter implementation, canonical preparation or maintained adoption. Root authored diagnostic/review helpers, found the original preselection defect and accepted its independently reviewed correction. This role is independent maintained-integration review; prior scientific judgments and implementation reviews remain explicit.'},
    'skill': '.claude/skills/review-yaml-record/SKILL.md', 'completion': 'completed',
    'verdict': 'pass_with_limitations', 'scientific_review': False,
    'summary': 'Eleven exact technical owners pass current integration review. Old objects/files/cache, complete mappings, current graph and fresh native gates are preserved. The two reviewed ferredoxin category unions and resolved preselection finding are explicit. Science and static layout limits remain separately documented.',
    'source': inspection['source'],
    'scope': {'description': 'Eleven runtime/configuration/fixture/test/authority owners after completed239gates, with complete maintained context.',
              'selection': 'All11technical primary owners at238baseline12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449; no sampling.',
              'coverage': 'full', 'population_size': 11, 'reviewed_target_ids': target_ids,
              'exclusions': [{'target': 'New primary scientific judgment', 'reason': 'Separate maintained scientific review.'},
                             {'target': 'Publication and full browser interaction', 'reason': 'Not performed; public push remains blocked and browser interaction unavailable.'}]},
    'targets': inspection['targets'], 'checks': checks, 'evidence': evidence,
    'assessments': assessments, 'findings': [], 'actions': [],
    'limitations': [
        'Scientific interpretation, prior implementation adversarial tests, canonical-build acceptance and portable replay are inherited with exact inputs; current integration and complete repository gates are freshly checked.',
        'Only a static light graph was personally viewed. Dense junctions, label truncation and tall blank canvas remain; no interactive,responsive,keyboard,dark-mode or print claim.',
        f'Actual regression retains{skipped}skips and{warnings}warnings with{passed}passes.',
        'Evidence references name concrete planned dossier destinations. Native save requires exact evidence adoption and current-input recheck; this external proposal is not itself a saved native review.',
    ],
    'notes': ['Native inspection followed all gates and root maintained QA; all captured current inputs were rechecked before this proposal.',
              'The original local preselection finding and its rejection evidence are preserved separately from the successor disposition; no GitHub issue is claimed.',
              'No public push, PR, merge, branch deletion, issue closure or licensing clearance is implied.'],
    'links': [], 'tags': ['dhap-ethylene-shunt', 'technical-review', 'local-only'],
}
with (H / 'technical-proposal.json').open('x') as f:
    json.dump(value, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps({'proposal': pin(H / 'technical-proposal.json'), 'targets': len(target_ids),
                  'assessments': len(assessments), 'checks': len(checks), 'inputs': len(inspection['source']['inputs'])}))
