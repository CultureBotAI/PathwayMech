import datetime,hashlib,json,os,stat
from pathlib import Path
H=Path(__file__).parent;N=Path('/private/tmp/pathwaymech-next-239-local-native-execution-20261012')
def pin(p):
 assert p.is_file() and not p.is_symlink(),p
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'file_type':'regular','link_text':None,'resolved_path':str(p.resolve())}
def write(name,v):
 with (H/name).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def walk(p):
 files=[];dirs=[]
 for base,children,names in os.walk(p,followlinks=False):
  dirs.append(str(Path(base).relative_to(p)))
  assert not any((Path(base)/c).is_symlink() for c in children)
  for name in names:
   f=Path(base)/name;assert stat.S_ISREG(f.lstat().st_mode);files.append(f)
 return sorted(files),sorted(dirs)
native=json.loads((N/'artifact-manifest.json').read_bytes());files,dirs=walk(N)
assert pin(N/'handoff.json')['sha256']=='ece82f35077cb4a317c0960ca437ac3069f84a8414490087b50658a4d27c5f43'
assert pin(N/'artifact-manifest.json')['sha256']=='07ba4d437d3e80a887c87de3e3e5aa37e24549fe177620b8932ba9ba2eff7727'
assert set(files)=={Path(r['path']) for r in native['files']}|{N/'handoff.json',N/'artifact-manifest.json'}
assert set(dirs)==set(native['directories'])|{'.'}
for row in native['files']:
 a=pin(Path(row['path']));assert a['sha256']==row['sha256'] and a['bytes']==row['bytes']
write('native-execution-intake.json',{'at':datetime.datetime.now(datetime.UTC).isoformat(),'handoff':pin(N/'handoff.json'),'manifest':pin(N/'artifact-manifest.json'),'whole_fresh_closure':True,'artifacts':len(native['files']),'directories':len(dirs),'hidden_ignored_included':True})
assert json.loads((H/'technical-validate.execution.json').read_bytes())['exit_code']==0
assert json.loads((H/'target.execution.json').read_bytes())['exit_code']==0
assert json.loads((H/'checkout.execution.json').read_bytes())['exit_code']==0
write('actual-root-tools.json',{'target_after_gates': '7974d6/session51401→7ac1c6/0', 'checkout_after_gates': '8866bd/session30075→2fe558/0', 'visual_binding': 'e21db1/0; personally viewed preview at23:02:38, current complete SVG/CSS/JS equality checked', 'technical_inspect': '9fadb7/session3201→49df1a/0', 'technical_proposal': '01dcba/0', 'technical_validate': '19f5d0/session42821→741b22/0; shared topClass deprecation message', 'root_record_or_product_edits': False, 'native_review_saved': False})
(H/'REPORT.md').write_text('Root maintained QA passed after all actual239 native gates. The complete scientific record equals accepted60750cb…; all21paragraphs,44edges,7qualifiers,38identities,93references and local anchors agree with the current page. Whole current SVG and both graph assets match the personally viewed light preview. Dense junctions, crossing return paths, truncated qualifiers, small whole-image text and tall blank canvas remain limitations. No browser interaction, responsive, dark, keyboard or print verification is claimed.\n\nWhole current source/ontology authorities and both CLI/download KGX bodies equal the accepted actual native outputs:4320nodes/12052edges. SSSOM preserves all42old rows, every cell and order, adding20target rows. All239old records/pages,122review pairs and406history YAMLs remain exact; two histories preceded SSSOM and rendering. The full physical inventory, including hidden and ignored files, checks12888baseline files to12909current,2037to2042directories,23exact adopted destinations and only declared generated/history changes. All800cache identities/bodies remain unchanged.\n\nThe complete92+2 native execution packet was freshly closed. All12required commands and nine gates passed; the single maintained test run reports4581passed,3skipped,3warnings. Vendored initially failed on sandbox DNS, then Broken pipe; both exact failed attempts are preserved. A later read-only retry passed, followed by diff and site-current. No passing broad gate was repeated. QA helpers were updated before execution to use the actual passing successor phase while preserving/verifying both failed attempts. The earlier prototype history-shape correction remains retained and never claimed a product failure.\n\nRoot captured fresh native technical inspection for11maintained technical owners and24context inputs after all gates and rootQA. All35current input hashes were rechecked. The technical proposal has16positive assessments,14checks,no findings and pass_with_limitations with scientific_review:false. It explicitly retains the original local protected-identity preselection finding/correction, prior complete preservation judgments and both failed public fetch attempts. Native validate passed with the shared topClass deprecation diagnostic. Scientific interpretation has a separate maintained reviewer; root did not author scientific content or production adapter.\n\nEvidence paths name concrete planned dossier destinations. Native save still requires exact-byte evidence adoption and current-input verification. This externally serialized proposal is not yet a saved review or commit. No public push,PR,merge,branch deletion or license clearance occurred.\n')
files,dirs=walk(H);rows=[pin(p) for p in files]
write('artifact-manifest.json',{'artifacts':rows,'directories':dirs,'hidden_ignored_included':True})
write('handoff.json',{'status':'root_maintained_qa_and_native_technical_proposal_passed_pending_guarded_adoption_and_save','at':datetime.datetime.now(datetime.UTC).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(rows),'report':pin(H/'REPORT.md'),'technical_proposal':pin(H/'technical-proposal.json'),'technical_native_validation':pin(H/'technical-validate.execution.json'),'scientific_review':False,'native_review_saved':False,'publication_authorized':False})
files2,dirs2=walk(H);assert set(files2)==set(files)|{H/'artifact-manifest.json',H/'handoff.json'} and dirs2==dirs
for row in rows:assert pin(Path(row['path']))==row
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(rows),'directories':len(dirs)}))
