import csv,datetime,gzip,hashlib,io,json,re,subprocess,sys
from pathlib import Path
from collections import Counter,defaultdict
from lxml import html
import yaml
ROOT=Path('/private/tmp/pathwaymech-next-239-local-20261012'); OUT=Path(__file__).parent
P='data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml'
PAGE='pages/records/MetaCyc_PWY-8132.html'; BASE='12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449'
checks=[]
def check(name, condition, detail=None):
 checks.append({'name':name,'passed':bool(condition),'detail':detail})
 if not condition: raise AssertionError((name,detail))
def sha(b):return hashlib.sha256(b).hexdigest()
def j(v):return json.dumps(v,ensure_ascii=False,sort_keys=True)
def norm(v):return re.sub(r'[\t\r\n]+',' ',str(v)).strip()
def text(el):return ''.join(el.itertext())
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def gitbody(p):return subprocess.check_output(['git','show',f'{BASE}:{p}'],cwd=ROOT)
def tsv(b):return list(csv.DictReader(io.StringIO('\n'.join(line for line in b.decode().splitlines() if not line.startswith('#'))),delimiter='\t'))
def main():
 d=yaml.safe_load((ROOT/P).read_bytes()); rid=d['id']; refs={x['id']:x for x in d['references']}
 check('exact accepted scientific draft',sha((ROOT/P).read_bytes())=='60750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa')
 science=Path('/private/tmp/pathwaymech-next-239-science-review-20261012')
 review={'paragraphs':json.loads((science/'paragraph-appraisal.json').read_bytes()),'edges':json.loads((science/'edge-appraisal.json').read_bytes())}
 author=Path('/private/tmp/pathwaymech-next-239-author-20261012/draft/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml')
 check('complete maintained YAML equals accepted scientific author',author.read_bytes()==(ROOT/P).read_bytes())
 pars=d['description'].split('\n\n');check('paragraph count',len(pars)==len(review['paragraphs'])==21)
 for p,a in zip(pars,review['paragraphs']):check('inherited full paragraph '+str(a['paragraph_1based']),sha(p.encode())==a['paragraph_sha256'])
 check('edge count',len(review['edges'])==len(d['mechanistic_edges'])==44)
 for e,a in zip(d['mechanistic_edges'],review['edges']):
  check('inherited edge disposition '+e['id'],e['id']==a['edge_id'] and all(e[k]==a[k] for k in ('subject','predicate','object')))
 idx=json.loads(gzip.decompress((ROOT/'research/pathway_additions/2026-10-12-next-239/evidence-index.json.gz').read_bytes()))
 for ref in refs.values():check('reference portable binding '+ref['id'],ref['source_sha256'] in idx['body_lookup'])
 prep=Path('/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012')
 baseline=json.loads((prep/'baseline-files.json').read_bytes());counts=Counter()
 for row in baseline:
  rel=row['path']; group=next((g for g in ('data/pathways/','pages/records/','history/','reviews/structured/') if rel.startswith(g)),None)
  if group and row['type']=='regular':
   check('baseline preserved '+rel,pin(ROOT/rel)['sha256']==row['sha256']);counts[group]+=1
 check('239 old records',sum(r['path'].startswith('data/pathways/') and r['path'].endswith('.yaml') for r in baseline)==239)
 check('239 old pages',counts['pages/records/']==239)
 check('122 old review pairs',counts['reviews/structured/']==244)
 # Every graph arrow, table row, node, reference, qualifier and local anchor.
 dom=html.fromstring((ROOT/PAGE).read_bytes()); ids=dom.xpath('//*[@id]/@id');check('unique HTML ids',len(ids)==len(set(ids)))
 for href in dom.xpath('//*[@href]/@href'):
  if href.startswith('#'):check('local HTML link '+href,href[1:] in ids)
 graph=dom.xpath('//a[contains(concat(" ",@class," ")," graph-edge ")]');check('44 graph arrows',len(graph)==44)
 alltext=text(dom)
 for i,(edge,arrow) in enumerate(zip(d['mechanistic_edges'],graph),1):
  anchor=f'mechanism-edge-{i}'; row=dom.get_element_by_id(anchor); cells=row.findall('td');check(anchor+' shape',len(cells)==4)
  check(anchor+' source',cells[0].find('code').text==edge['subject']);check(anchor+' target',cells[2].find('code').text==edge['object'])
  check(anchor+' predicate',cells[1].text==edge['predicate']);check(anchor+' description',cells[1].find('p').text==edge['description'])
  check(anchor+' graph predicate',arrow.get('data-predicate')==edge['predicate']);check(anchor+' graph link',arrow.get('href')=='#'+anchor)
  expectedends={'subject':edge['subject'],'object':edge['object']}
  for q in edge.get('endpoint_qualifiers',[]):
   role=q['endpoint'];expectedends[role]=f'qualified-endpoint-{i}-{role}';qd=dom.get_element_by_id(f'{anchor}-qualifier-{role}')
   check(anchor+' qualifier text',q['description'] in text(qd));check(anchor+' original endpoint',arrow.get('data-'+role+'-id')==edge[role])
   for ev in q['evidence']:
    for k in ('quote','source_assertion','source_locator'):
     if k in ev:check(anchor+' qualifier '+k,ev[k] in text(qd))
  for role,value in expectedends.items():check(anchor+' graphical '+role,arrow.get('data-'+role)==value)
  lis=cells[3].xpath('./ul/li');check(anchor+' evidence count',len(lis)==len(edge['evidence']))
  for ev,li in zip(edge['evidence'],lis):
   check(anchor+' evidence ref',li.find('a').text==ev['reference_id'])
   check(anchor+' evidence target',li.find('a').get('href')=='#reference-'+str(list(refs).index(ev['reference_id'])+1))
   for k in ('quote','source_assertion','source_locator'):
    if k in ev:check(anchor+' '+k,ev[k] in text(li))
 nodes=dom.xpath('//a[contains(concat(" ",@class," ")," graph-node ")]');check('42 graph nodes:35 non-taxon identities plus7 qualified endpoints',len(nodes)==42)
 named=[{'id':rid,'label':d['label']}]+[n for c in ('taxa','participants','reactions') for n in d[c]]
 check('38 named identities',len(named)==38)
 for n in named:
  if n['id'] in {v['id'] for v in d['taxa']}:
   check('unconnected taxon retained in component table',n['id'] in alltext);continue
  matches=[x for x in nodes if x.get('data-node-id')==n['id']];check('graph node '+n['id'],len(matches)==1 and matches[0].get('data-node-label')==n['label'])
 for i,ref in enumerate(d['references'],1):
  li=dom.get_element_by_id('reference-'+str(i));s=text(li)
  for k in ('id','title','source_version'):check('rendered reference '+ref['id']+' '+k,ref[k] in s)
  check('reference issuing URL '+ref['id'],ref['url'] in li.xpath('.//a/@href'))
 check('whole description rendered',d['description'] in alltext)

 preview=html.fromstring(Path('/private/tmp/pathwaymech-next-239-graph-preview-20261012/records/MetaCyc_PWY-8132.html').read_bytes())
 actual_svg=dom.xpath('//svg[@class="pathway-network-svg"]')[0]
 prior_svg=preview.xpath('//svg[@class="pathway-network-svg"]')[0]
 check('actual graph equals statically inspected preview',html.tostring(actual_svg)==html.tostring(prior_svg))
 histories=list((ROOT/'history/records/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii').glob('*.yaml'))
 check('actual curation history rendered',len(histories)==1 and yaml.safe_load(histories[0].read_bytes())['summary'] in alltext)
 actual_build=Path('/private/tmp/pathwaymech-next-239-canonical-build-20261012')
 for n in ['sources.json','ontology.json']:
  check('actual authority body '+n,(ROOT/'data/identifier_authorities'/n).read_bytes()==(actual_build/n).read_bytes())
 for n in ['nodes.tsv','edges.tsv']:
  check('actual downloaded whole KGX '+n,(ROOT/'pages/downloads'/n).read_bytes()==(actual_build/'actual-kgx'/n).read_bytes())
  check('actual CLI whole KGX '+n,(ROOT/'output/kgx'/n).read_bytes()==(actual_build/'actual-kgx'/n).read_bytes())
 for row in json.loads((prep/'plan.json').read_bytes())['changes']:
  check('exact adopted owner '+row['destination'],pin(ROOT/row['destination'])['sha256']==row['payload']['sha256'])
 erows=tsv((ROOT/'pages/downloads/edges.tsv').read_bytes());nrows=tsv((ROOT/'pages/downloads/nodes.tsv').read_bytes())
 check('actual KGX counts',len(nrows)==4320 and len(erows)==12052)
 oldbody=gitbody('output/sssom/source_mappings.sssom.tsv');newbody=(ROOT/'output/sssom/source_mappings.sssom.tsv').read_bytes()
 semantic=json.loads((prep/'semantic-preservation.json').read_bytes())['SSSOM'];oldrows=tsv(oldbody);newrows=tsv(newbody)
 headers=lambda b:[line for line in b.decode().splitlines() if line.startswith('#')]+[next(line for line in b.decode().splitlines() if not line.startswith('#'))]
 check('SSSOM exact header lines',headers(oldbody)==headers(newbody))
 oldset=Counter(j(r) for r in oldrows);added=Counter(j(r) for r in semantic['expected_added_rows'])
 check('SSSOM42old20new62total',len(oldrows)==42 and sum(added.values())==20 and len(newrows)==62)
 check('SSSOM all cells and multiplicities',Counter(j(r) for r in newrows)==oldset+added)
 check('SSSOM prior row relative order',[r for r in newrows if j(r) in oldset]==oldrows)

 return {'status':'all_actual_maintained_target_and_preservation_checks_passed','finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Fresh maintained integration and complete rendered graph/table/evidence checks. Full scientific interpretations inherited from accepted reviews and compared to whole current target; no fresh paper reading.','counts':dict(counts),'graph_nodes':len(nodes),'graph_edges':len(graph),'named_identities':len(named),'references':len(refs),'qualifiers':sum(len(e.get('endpoint_qualifiers',[])) for e in d['mechanistic_edges']),'kgx_nodes':len(nrows),'kgx_edges':len(erows),'inputs':[pin(ROOT/p) for p in [P,PAGE,'pages/downloads/nodes.tsv','pages/downloads/edges.tsv']],'checks':checks}
try:
 report=main()
 with (OUT/'target-qa.json').open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False);f.write('\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ('checks','inputs')},indent=2))
except BaseException as e:
 with (OUT/'target-qa-failed.json').open('x') as f:json.dump({'error':repr(e),'checks':checks},f,indent=2,ensure_ascii=False);f.write('\n')
 raise
