"""Prepare inherited scientific appraisals; final native inspection waits for gates."""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import zipfile
import yaml

H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-239-local-20261012')
A=Path('/private/tmp/pathwaymech-next-239-author-20261012')
S=Path('/private/tmp/pathwaymech-next-239-science-review-20261012')
D='research/pathway_additions/2026-10-12-next-239'
TARGET='data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml'
PY='/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python'
def pin(p):
    p=Path(p);assert stat.S_ISREG(p.lstat().st_mode),p
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(Path(p).read_text())
def write(name,x):(H/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def check(x):
    a=pin(x['path']);assert all(a[k]==x[k] for k in ['bytes','sha256']),x;return a
at=datetime.datetime.now(datetime.timezone.utc).isoformat()
target=pin(R/TARGET);assert target['sha256']=='60750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa'
assert target['bytes']==107271 and (R/TARGET).read_bytes()==(A/'draft'/Path(TARGET).name).read_bytes()
d=yaml.safe_load((R/TARGET).read_bytes())
root=Path('/private/tmp/pathwaymech-next-239-root-scientific-acceptance-20261012.json')
assert pin(root)['sha256']=='46fcc97d3a76138cb791d458bea2a00d0a5855c98f328480da2623bfa209dd09'
accepted=load(root);closed=[]
for name,base in [('author',A),('independent_review',S)]:
    check(accepted[name]['handoff']);check(accepted[name]['manifest'])
    manifest=load(base/'artifact-manifest.json');files=set();dirs=set()
    for x in manifest['artifacts']:
        q=base/x['relative_path'];assert x.get('file_type','regular')=='regular';check({'path':str(q),**{k:x[k] for k in ['bytes','sha256']}})
    for b,ds,fs in os.walk(base,followlinks=False):
        for n in ds:assert not (Path(b)/n).is_symlink();dirs.add(str((Path(b)/n).relative_to(base)))
        for n in fs:files.add(str((Path(b)/n).relative_to(base)))
    assert files=={x['relative_path'] for x in manifest['artifacts']}|{'handoff.json','artifact-manifest.json'}
    # The author manifest explicitly includes its root '.', whereas the reviewer
    # manifest lists only descendants. Both inventories retain exact descendants.
    assert dirs==set(manifest['directories'])-{'.'}
    closed.append({'kind':name,'handoff':pin(base/'handoff.json'),'manifest':pin(base/'artifact-manifest.json'),'artifacts':len(manifest['artifacts']),'seals':2})

# Retrieve only exact scientific bodies/receipts from maintained portable owners.
index_path=R/D/'evidence-index.json.gz';index_pin=pin(index_path)
index=json.loads(gzip.decompress(index_path.read_bytes()));assert index['format']=='lossless-content-addressed-evidence-v1'
lookup=index['body_lookup'];owners={str(index_path):index_pin};archives={}
def owner(rel):
    q=Path(rel);assert not q.is_absolute() and '..' not in q.parts
    p=R/q
    if str(p) not in owners:owners[str(p)]=pin(p)
    return p
def retrieve(sha):
    loc=lookup[sha];assert loc['sha256']==sha
    if loc['kind']=='repository_file':body=owner(loc['repository_relative_path']).read_bytes()
    else:
        assert loc['kind'] in {'repository_zip_member','repository_chunked_zip_member'}
        rel=loc['repository_relative_path'];assert loc['member']=='blobs/'+sha
        if rel not in archives:
            if loc['kind']=='repository_chunked_zip_member':
                parts=loc['archive_parts'];assert len(parts)==len({p['repository_relative_path'] for p in parts})
                chunks=[]
                for row in parts:
                    p=owner(row['repository_relative_path']);assert all(owners[str(p)][k]==row[k] for k in ['bytes','sha256']);chunks.append(p.read_bytes())
                archive_body=b''.join(chunks)
            else:archive_body=owner(rel).read_bytes()
            assert (len(archive_body),hashlib.sha256(archive_body).hexdigest())==(loc['archive_bytes'],loc['archive_sha256'])
            z=zipfile.ZipFile(io.BytesIO(archive_body));assert len(z.namelist())==len(set(z.namelist()))
            assert not any(stat.S_ISLNK(x.external_attr>>16) for x in z.infolist())
            archives[rel]=(z,loc['archive_sha256'])
        z,archive_sha=archives[rel];assert archive_sha==loc['archive_sha256'];body=z.read(loc['member'])
    assert (len(body),hashlib.sha256(body).hexdigest())==(loc['bytes'],sha)
    return body,loc
sources=load(A/'source-bindings.json')['sources'];originals=[];receipts={}
portable_science={x['portable_body']['sha256'] for x in index['original_groups']['whole_scientific_originals']}
for row in sources:
    original=check(row['original']);body,loc=retrieve(original['sha256'])
    assert body==Path(original['path']).read_bytes() and original['sha256'] in portable_science
    receipt=row.get('receipt');receipt_binding=None
    if receipt:
        rb=check(receipt);receipt_body,receipt_loc=retrieve(rb['sha256'])
        assert receipt_body==Path(rb['path']).read_bytes()
        receipts[rb['path']]={'original':rb,'portable_location':receipt_loc}
        receipt_binding=receipts[rb['path']]
    originals.append({'original':original,'portable_location':loc,'receipt':receipt_binding,'source_context':row})
assert len(originals)==98 and len(receipts)==96
reference_ledger=load(A/'reference-ledger.json');assert len(reference_ledger)==93
assert [r['reference'] for r in reference_ledger]==d['references']
for row in reference_ledger:
    b,loc=retrieve(row['reference']['source_sha256']);assert len(b)==row['complete_original']['bytes']
for bound in owners.values():check(bound)
write('whole-source-closure.json',{'at':at,'status':'whole_originals_and_receipts_unchanged','originals':originals,'unique_receipts':list(receipts.values()),'source_count':98,'receipt_count':96,'reference_count':93,'portable_index':index_pin,'maintained_portable_owners':list(owners.values()),'new_full_paper_reading':False,'reading_basis':'Inherited exact earlier independent full scientific reading; whole bodies are newly byte-compared to those originals and maintained portable representations.'})
paras=load(S/'paragraph-appraisal.json');text=d['description'].split('\n\n');assert len(paras)==len(text)==21
for p,t in zip(paras,text,strict=True):
    assert hashlib.sha256(t.encode()).hexdigest()==p['paragraph_sha256']
    p['current_text']=t;p['current_reassessment']='Earlier complete scientific judgment applies to unchanged whole paragraph and exact unchanged whole source bodies; no new scientific scope added during maintained adoption.'
write('paragraph-appraisals.json',paras)
edges=load(S/'edge-appraisal.json');assert len(edges)==len(d['mechanistic_edges'])==44
for p,e in zip(edges,d['mechanistic_edges'],strict=True):
    assert hashlib.sha256(json.dumps(e,ensure_ascii=False,sort_keys=True).encode()).hexdigest()==p['edge_sha256']
    p['current_edge']=e;p['current_reassessment']='Exact whole edge, evidence and qualifiers match the earlier independently assessed scientific object. Final maintained DOM/export equivalence remains pending.'
write('edge-appraisals.json',edges)
identity=load(S/'replayed-author-checks/identity-ledger.json');assert len(identity['nodes'])==38
write('identity-appraisals.json',{'earlier_reviewed_whole_ledger':pin(S/'replayed-author-checks/identity-ledger.json'),'identities':identity,'current_scope':'All current target IDs/labels/categories remain byte-identical to the reviewed record; whole issuing originals are freshly bound. Authority implementation technical acceptance is separate.'})
write('reference-appraisals.json',reference_ledger)
write('read-coverage.json',{'stage':'provisional scientific preparation; final native inspect and gate/DOM/export assessment pending','at':at,'earlier_complete_review':pin(S/'read-coverage.json'),'earlier_report':pin(S/'REPORT.md'),'prior_review_full_reading':load(S/'read-coverage.json'),'fresh_now':['Complete current narrative and all21 prior appraisals reread; all44 endpoint/predicate/qualifier appraisals checked against exact whole current edges.','Complete current target compared byte-for-byte with accepted107271-byte draft.','All98 whole source bodies and96 acquisition receipts rehashed and compared to maintained portable decoded originals.','All84+2 author and46+2 independent review artifacts freshly closed, including hidden/ignored files and no alias traversal.'],'not_repeated':['Unchanged full papers, scientific native-frame interpretations and original figure readings are inherited from this agent’s earlier full scientific review; no fictitious fresh rereading.','Authority builders, runtime implementation acceptance, whole-corpus gates and cache/history preservation are separate root/peer technical evidence.'],'prior_role':'Independent of239 scientific draft/preflight authorship. Authored earlier independent scientific review, then authority design, adapter/accepted preselection successor and canonical preparation. This review cannot independently certify those self-authored technical changes; root/other reviewer owns TECH.'})
contracts=['.claude/skills/review-yaml-record/SKILL.md','.claude/skills/add-pathway/SKILL.md','docs/record-reviews.md','docs/record-review-profile.md','docs/CURATION.md','docs/HARMONIZATION.md','docs/CAUSAL_GRAPHS.md','CLAUDE.md','justfile','schema/record_review.yaml','scripts/record_review.py','src/pathwaymech/schema.py','src/pathwaymech/schema/pathwaymech.yaml']
spec={'targets':[{'target_id':d['id'],'path':TARGET,'label':d['label'],'record_class':'PathwayRecord','kind':'maintained','owner_paths':[{'repository':'CultureBotAI/PathwayMech','path':TARGET,'role':'maintained scientific record'}]}]}
(H/'targets.yaml').write_text(yaml.safe_dump(spec,sort_keys=False,allow_unicode=True))
inputs=list(dict.fromkeys(['pages/records/MetaCyc_PWY-8132.html','pages/assets/pathway-network.css','pages/assets/pathway-network.js','src/pathwaymech/graph_view.py','src/pathwaymech/cli.py','conf/identifier_policy.yaml','conf/identifier_sources.json','data/identifier_authorities/sources.json','data/identifier_authorities/ontology.json','output/kgx/nodes.tsv','output/kgx/edges.tsv','output/sssom/source_mappings.sssom.tsv']+contracts+[str(Path(p).relative_to(R)) for p in owners]))
prefix=[PY,'-B',str(R/'scripts/record_review.py'),'--repo-root',str(R),'--schema',str(R/'schema/record_review.yaml')]
argv=prefix+['inspect','--targets',str(H/'targets.yaml')]
for p in inputs:argv+=['--input',p]
write('planned-native-commands.json',{'status':'NOT_EXECUTED_PENDING_ALL_GATES','cwd':str(R),'environment':{'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','UV_NO_SYNC':'1','PYTHONPATH':str(R/'src')+':'+str(R)},'inspect':argv,'validate':prefix+['validate',str(H/'completed-review.yaml')],'save_interface_only':prefix+['save','--content',str(H/'completed-review.yaml')],'save_status':'Not authorized by this task and not executed. Root coordinates final maintained evidence adoption and native save.','final_generated_inputs_bound':False})
write('preparation-results.json',{'status':'scientific_preparation_complete_final_native_phase_pending','at':at,'target_at_preparation':target,'root_science_acceptance':pin(root),'earlier_packets_closed':closed,'source_bodies':len(originals),'receipts':len(receipts),'paragraphs':len(paras),'edges':len(edges),'named_ids':38,'references':len(reference_ledger),'qualifiers':7,'mappings':20,'contracts':[pin(R/p) for p in contracts],'native_inspect_run':False,'gates_asserted_complete':False,'maintained_mutations':False,'actual_reading_limits':'Earlier full primary/native reading retained transparently; final DOM/static/current exports/gate origins remain to assess after exact completion notice.','initial_lookup_failure':'b71520/1 attempted guessed earlier whole-source-closure.json; actual full closure is within input-bindings.json and original-preservation.json, discovered by ignored/hidden-inclusive inventory. No absence claim was made.','truncated_helper_read':'Overlong238 helper/appraisal output was not treated as full fresh reading; complete prior239 rationales were recovered in bounded narrative/edge calls.'})
print(json.dumps(load(H/'preparation-results.json'),indent=2))
