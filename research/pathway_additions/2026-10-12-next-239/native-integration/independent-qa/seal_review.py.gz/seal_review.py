"""Seal a complete external review with original execution and source bindings."""
import datetime,hashlib,json,os,stat
from pathlib import Path
import yaml
H=Path(__file__).resolve().parent
R=Path('/private/tmp/pathwaymech-next-239-local-20261012')
Q=Path('/private/tmp/pathwaymech-next-239-root-maintained-qa-20261012')
def pin(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(n,v):(H/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def read(n):return json.loads((H/n).read_text())
assert read('native-validation.execution.json')['exit_code']==0
proposal=H/'completed-review.yaml';assert pin(proposal)==read('native-validation.execution.json')['proposal_at_start']
(H/'completed-review-ready.yaml').write_bytes(proposal.read_bytes())
x=yaml.safe_load(proposal.read_text())
for v in x['source']['inputs']:assert pin(R/v['path'])['sha256']==v['sha256']
for v in x['evidence']:
 pref='research/pathway_additions/2026-10-12-next-239/native-integration/'
 path=v['reference']
 if path.startswith(pref+'independent-qa/'):p=H/path.removeprefix(pref+'independent-qa/')
 elif path.startswith(pref+'root-review/'):p=Q/path.removeprefix(pref+'root-review/')
 else:p=R/path
 assert pin(p)['sha256']==v['snapshot_sha256'],path
execution_rows=[]
for p in sorted((H/'executions').glob('*/completion.json')):
 d=json.loads(p.read_text())
 for k in ['preserved_executed_helper','stdout','stderr']:
  b=pin(Path(d[k]['path']));assert b==d[k]
 assert d['executed_helper']['sha256']==d['preserved_executed_helper']['sha256']
 execution_rows.append({'receipt':pin(p),'exit_code':d['exit_code'],'executed_helper_hash':d['executed_helper']['sha256']})
for row in read('actual-native-copy.json')['files']:
 for k in ['source','destination']:assert pin(Path(row[k]['path']))==row[k]
assert len(read('actual-native-copy.json')['files'])==94
dump('sealing-currentness.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_native_inputs_still_exact':len(x['source']['inputs']),'durable_evidence_whole_hashes':len(x['evidence']),'executed_helper_bodies_and_streams':execution_rows,'all94_native_original_and_copy_bytes_unchanged':True,'no_native_save':True})
dump('actual-tool-provenance.json',{'preparation_success':'d3f051/session92109 →206cc0/0; initial guard failures ea5ca4/1,a034fb/session80359→dcd2b8/1 retained','final_native_inspection':'6f7bfc/session86597→2bd2de/0','maintained_DOM':'90c4bb/session86217→6a17cf/0','maintained_exports':'f0cbb9/session43851→2e7570/0','full_static_image':'functions.exec view_image whole maintained-graph-light.png; personally inspected','CUA':'mcp__cua_repl.js getState returned apps:[],browsers:[]','serialization_failure':'414a42/1 root manifest artifacts/files shape mismatch; original helper and streams retained','serialization_success':'a4c0c5/session55803→9e1711/0','native_validation':'40eca7/session6694→334309/0; shared topClass deprecation only','read_only_inspection_failures':'15ab14 system python lacks PyYAML;2c9129 evidence key id corrected to evidence_id;049280 succeeded','unchanged_initial_plan':True,'no_native_save_or_maintained_mutation':True})
report='''The exact maintained MetaCyc:PWY-8132 record passes scientific review with explicit limits. All21 narrative paragraphs,44 whole edges,7 endpoint qualifiers,38 issuer identities,93 references and20 source mappings retain the independently accepted scientific content. The current record remains107,271bytes/SHA25660750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa. No supported scientific finding or required product edit was identified.

Fresh complete page/graph checks pass21 paragraphs,42visual nodes,44edges,7qualifiers,93references and every local anchor. Full qualifiers and evidence payloads are present. The38 target node contexts,44 whole KGX edge rows and20 SSSOM rows match the current native exports. All38 identities have authority terms. All41 original native inspection inputs remained exact through validation and sealing. The ignored/hidden-inclusive native review search checked all122 prior structured YAML reviews and found no exact target predecessor.

All98 complete scientific original bodies and96 acquisition receipts are byte-identical to the earlier independent science review and their maintained portable decoded representations. Whole-source closure includes the two complete supplementary archive members. The prior author84+2 and science46+2 closures are recorded. Earlier same-day full six-paper/native reading is transparently inherited: complete main texts,54page2020Science manuscript+SI,10page2025SI,2017 scientific SI pages1–18, six material figure/table pages,56 native frames/847slots and269locators were read/checked in that earlier review. The current narrative and all individual edge appraisals were reconciled; unchanged papers were not misleadingly reported as freshly reread. Original access and raw-data limitations remain.

The five-event boundary,22 native sides, native right-to-left aldehyde-reduction axis, unspecified reductase/donor, generic ferredoxin protein classes, whole MarH2/(DK)2 assembly, tagged2025host constructs, alternative Co/Ni states, automated Oah PLP annotation and native kinetic/source artifacts remain qualified. Proposed carbide/channels/ancestral roles are not established native facts. No physical channeling, ATP budget, obligatory donor or expanded direct regulon is inferred.

This reviewer did not author the scientific draft/preflight. After the earlier independent scientific review, the reviewer authored authority design, adapter/preselection successor and canonical preparation. SCI does not independently certify those technical changes. Root’s separate44+2 QA/TECH packet was freshly closed and its full report read; root owns whole-checkout/cache preservation and independent technical judgments.

All9native gates ultimately passed, with4581tests/3skips/3warnings from one maintained test run.12 successful native commands and both prior failed read-only vendored attempts are preserved in an exact92+2 whole-file actual-native copy, with original seals, receipt paths and streams unchanged. The successful final vendored/diff/site-current phase is network-resumption-successor. The original preparatory command plan was retained and the native inspect argv ran unchanged only after final gates. No gate was rerun for this review.

The full current static light image was personally inspected. All five reactions, nested assembly and separately qualified states are visible; dense crossings, small text, long truncated labels and a tall blank canvas limit readability. Complete text is checked in DOM. CUA returned no apps/browsers; no interactive, dark, responsive, keyboard, hover or print QA is claimed.

The external native proposal has72assessments,21checks,36evidence rows and41inputs. Native validation passed with only the shared topClass deprecation diagnostic. Three actual local guard failures remain: root-directory normalization, inherited receipt-lineage counting, and serializer use of the native packet files key for a root packet with artifacts. Corrected successful helpers preserve full original evidence. Two incidental read-only template inspection failures are separately disclosed. Every executed helper body, receipt and stream remains retained; REPORT-preparation.md and preparatory JSON preserve their original pending-state wording, superseded by final currentness/DOM/export receipts.

Evidence references use the concrete future independent-qa and root-review durable paths. completed-review-ready.yaml is byte-identical to the validated completed-review.yaml. Later evidence adoption may losslessly store audit .py bodies as .py.gz under explicit decoded-path/hash bindings; cited JSON paths and original source judgments/timestamps must remain exact. Native save still requires root-authorized adoption and current-input verification. No maintained product, cache, history, native review, Git or GitHub mutation was performed here.
'''
(H/'REPORT.md').write_text(report)
files=[];dirs=[]
for base,ds,fs in os.walk(H,followlinks=False):
 for name in ds:
  p=Path(base)/name;assert stat.S_ISDIR(p.lstat().st_mode);dirs.append(str(p.relative_to(H)))
 for name in fs:
  p=Path(base)/name;assert stat.S_ISREG(p.lstat().st_mode)
  if p.name in ['handoff.json','artifact-manifest.json'] and p.parent==H:continue
  files.append(pin(p)|{'relative_path':str(p.relative_to(H)),'kind':'regular_file'})
files.sort(key=lambda x:x['relative_path']);dirs.sort()
dump('artifact-manifest.json',{'files':files,'directories':dirs,'walk':'literal os.walk, hidden and ignored included, no aliases or specials'})
dump('handoff.json',{'status':'maintained_scientific_review_pass_with_limitations_externally_validated_not_saved','sealed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':pin(H/'artifact-manifest.json'),'artifacts':len(files),'directories':len(dirs),'proposal':pin(H/'completed-review-ready.yaml'),'validated_proposal':pin(proposal),'native_validation':pin(H/'native-validation.execution.json'),'target_sha256':'60750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa','root_QA':pin(Q/'handoff.json'),'native_packet_original_handoff':pin(H/'actual-native/handoff.json'),'evidence_destination':'research/pathway_additions/2026-10-12-next-239/native-integration/independent-qa','native_save_performed':False,'required_findings':[]})
for x in files:assert pin(Path(x['path']))['sha256']==x['sha256']
print(json.dumps({'handoff':pin(H/'handoff.json'),'manifest':pin(H/'artifact-manifest.json'),'proposal':pin(H/'completed-review-ready.yaml'),'artifacts':len(files),'directories':len(dirs)},indent=2))
