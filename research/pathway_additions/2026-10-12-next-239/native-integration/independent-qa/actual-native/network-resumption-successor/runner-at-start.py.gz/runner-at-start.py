"""Execute the inspected native local integration stages and retain actual receipts."""

import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

PREP = Path("/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012")
ROOT = Path("/private/tmp/pathwaymech-next-239-local-20261012")
OUT = Path("/private/tmp/pathwaymech-next-239-local-native-execution-20261012")
EXPECTED_STAGE = '331e58003f7b0aaa815d5a64e4bca24aaab4696bfc21a4cecfc0eefbdb2dde6d'
EXPECTED_HANDOFF = '42bee2933949204e81887e4837403145075cfa7f8b217c709134f682ce528906'
EXPECTED_PLAN = '7594bed46ec4cb485713b09813fb8e9d810cc9d773f2db10b8101539fa1e5d85'
EXPECTED_SEMANTIC = '395a5a6413b93fedbda1f0e7b483ec222f354756d844449551d65c0950ba27e2'
EXPECTED_APPROVAL = "cad2d88ea48fe6681d92a1e3c428313cbd5bc61625cdb4f97c97141a3c72daef"
EXPECTED_BASELINE = 'cfd07ba5082e32d0c6461e9a82bb6ef140fdddd1fa30c6625aacefc7f9d58dab'
PHASES = ("network-resumption-successor",)
ORIGINAL_RUNNER = Path("/private/tmp/pathwaymech-next-239-root-run-native-20261012.py")
ORIGINAL_RUNNER_SHA = "4062c883278e7c2e525c6aedf374ec6e0e289ad7db3ded6a405697fa5466516a"


def pin(path):
    assert not path.is_symlink() and path.is_file(), path
    body = path.read_bytes()
    return {"path": str(path), "bytes": len(body), "sha256": hashlib.sha256(body).hexdigest()}


def write(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def check_histories(expected_count):
    assert pin(PREP / "baseline-files.json")["sha256"] == EXPECTED_BASELINE
    baseline = json.loads((PREP / "baseline-files.json").read_bytes())
    old = {
        r["path"]: r
        for r in baseline
        if r["path"].startswith("history/") and r["path"].endswith(".yaml")
    }
    assert len(old) == 406
    current = {p.relative_to(ROOT).as_posix(): pin(p) for p in (ROOT / "history").rglob("*.yaml")}
    assert len(current) == expected_count
    for name, row in old.items():
        assert (current[name]["bytes"], current[name]["sha256"]) == (row["bytes"], row["sha256"])
    return {
        "old_histories": 406,
        "total_histories": len(current),
        "old_whole_history_bytes_exact": True,
        "new_histories": [row for name, row in sorted(current.items()) if name not in old],
    }


def verify_sssom(old_body, actual_body, semantic):
    import csv
    from collections import Counter

    assert hashlib.sha256(old_body).hexdigest() == semantic["before"]["sha256"]
    old_lines, actual = old_body.decode().splitlines(), actual_body.decode().splitlines()
    assert [line for line in actual if line.startswith("#")] == semantic["exact_header_lines"]

    def rows(lines):
        reader = csv.DictReader(
            [line for line in lines if not line.startswith("#")], delimiter="\t"
        )
        result = list(reader)
        return reader.fieldnames, [tuple(row[k] for k in reader.fieldnames) for row in result]

    keys, old_order = rows(old_lines)
    new_keys, new_order = rows(actual)
    before, after = Counter(old_order), Counter(new_order)
    expected = Counter(tuple(row[k] for k in keys) for row in semantic["expected_added_rows"])
    assert keys == new_keys and after == before + expected
    assert sum(before.values()) == 42 and sum(expected.values()) == 20 and sum(after.values()) == 62
    assert not (before & expected)
    assert [row for row in new_order if row in before] == old_order
    return {
        "old_rows": 42,
        "added_rows": 20,
        "total_rows": 62,
        "all_headers_cells_multiplicities_exact": True,
        "old_row_relative_order_exact": True,
        "whole_bytes_expected_to_change": True,
    }


def main():
    assert len(sys.argv) == 2 and sys.argv[1] in PHASES
    phase = sys.argv[1]
    assert len(EXPECTED_APPROVAL) == 64, "Exact root acceptance remains pending"
    runner_at_start = pin(Path(__file__))
    runner_body = Path(__file__).read_bytes()
    assert hashlib.sha256(runner_body).hexdigest() == runner_at_start["sha256"]
    assert pin(PREP / "stages.json")["sha256"] == EXPECTED_STAGE
    assert pin(PREP / "handoff.json")["sha256"] == EXPECTED_HANDOFF
    assert pin(PREP / "plan.json")["sha256"] == EXPECTED_PLAN
    assert pin(PREP / "semantic-preservation.json")["sha256"] == EXPECTED_SEMANTIC
    stages = json.loads((PREP / "stages.json").read_bytes())
    plan = json.loads((PREP / "plan.json").read_bytes())
    adoption = Path("/private/tmp/pathwaymech-next-239-local-adoption-20261012/receipt.json")
    adoption_at_start = pin(adoption)
    state = json.loads(adoption.read_bytes())
    assert state["status"] == "local_adoption_complete_no_history_gates_or_publication"
    assert state["target"] == str(ROOT) and state["publication_performed"] is False
    assert len(state["changes"]) == 23
    assert state["changes"] == [row["destination"] for row in plan["changes"]]
    assert state["handoff"] == pin(PREP / "handoff.json")
    approval = Path(state["approval"]["path"])
    assert pin(approval) == state["approval"]
    accepted = json.loads(approval.read_bytes())
    assert accepted["status"] == "accepted_exact_mar239_local_integration_for_adoption"
    assert state["approval"]["sha256"] == (EXPECTED_APPROVAL)
    assert accepted["handoff"] == pin(PREP / "handoff.json")
    assert accepted["target"] == str(ROOT)
    assert accepted["commit"] == state["baseline_commit"]
    assert accepted["tree"] == state["baseline_tree"]
    assert accepted["publication_authorized"] is False and accepted["local_only"] is True
    assert (
        subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
        == "12bc8c721fa8b8d824bcb8cea8b0bfa0ffbc0449"
    )
    records = list((ROOT / "data/pathways").rglob("*.yaml"))
    assert len(records) == 240 and all(not p.is_symlink() for p in records)
    assert pin(ROOT / "data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml")["sha256"] == (
        "60750cb046b847a5d52458cff6eab771be2a9200755c259cfe8d87c4808e95fa"
    )
    history_before = check_histories(408)
    env = {**os.environ, **stages["environment"]}
    original = pin(ORIGINAL_RUNNER)
    assert original["sha256"] == ORIGINAL_RUNNER_SHA
    previous_path = OUT / "remaining-offline-gates/completion.json"
    prior = json.loads(previous_path.read_bytes())
    assert prior["status"] == "phase_passed" and prior["runner"] == original
    assert prior["adoption"] == adoption_at_start
    assert prior["stage_plan"] == pin(PREP / "stages.json")
    assert [(r["name"], r["exit_code"]) for r in prior["receipts"]] == [
        ("validate", 0), ("tests", 0), ("lint", 0), ("kgx", 0)]
    failed_path = OUT / "vendored-gate/failure.json"
    failed = json.loads(failed_path.read_bytes())
    assert failed["status"] == "phase_failed"
    assert [(r["name"], r["exit_code"]) for r in failed["receipts"]] == [("vendored", 1)]
    assert "nodename nor servname provided" in (
        OUT / "vendored-gate/vendored.stderr").read_text()
    retained_origins = [pin(previous_path), pin(failed_path), original]
    for group, phase_folder in [(prior, "remaining-offline-gates"), (failed, "vendored-gate")]:
        phase_path = OUT / phase_folder / "phase-start.json"
        phase_pin = pin(phase_path)
        phase_state = json.loads(phase_path.read_bytes())
        assert phase_state["runner"] == original and phase_state["adoption"] == adoption_at_start
        assert phase_state["stage_plan"] == pin(PREP / "stages.json")
        assert (OUT / phase_folder / "runner-at-start.py").read_bytes() == ORIGINAL_RUNNER.read_bytes()
        retained_origins.extend([phase_pin, pin(OUT / phase_folder / "runner-at-start.py")])
        for receipt in group["receipts"]:
            assert receipt["runner_at_start"] == original and receipt["phase_start"] == phase_pin
            receipt_path = OUT / phase_folder / (receipt["name"] + ".execution.json")
            assert json.loads(receipt_path.read_bytes()) == receipt
            origin = pin(receipt_path)
            if "receipt_origins" in group:
                assert origin in group["receipt_origins"]
            retained_origins.append(origin)
            for stream in ("stdout", "stderr"):
                assert pin(Path(receipt[stream]["path"])) == receipt[stream]
                retained_origins.append(receipt[stream])
    second_folder = OUT / "network-resumption"
    second_failure = json.loads((second_folder / "failure.json").read_bytes())
    assert [(r["name"], r["exit_code"]) for r in second_failure["receipts"]] == [("vendored", 1)]
    assert "Broken pipe" in (second_folder / "vendored.stderr").read_text()
    assert pin(Path("/private/tmp/pathwaymech-next-239-resume-gates-20261012.py"))["sha256"] == (
        "86dfb406af8b18a2e55c90da2293676e87addf2ad095e5e2ad98e923dfe72d29")
    for name in ("phase-start.json", "runner-at-start.py", "failure.json", "vendored.execution.json", "vendored.stdout", "vendored.stderr"):
        retained_origins.append(pin(second_folder / name))
    second_receipt = second_failure["receipts"][0]
    assert json.loads((second_folder / "vendored.execution.json").read_bytes()) == second_receipt
    assert pin(Path(second_receipt["phase_start"]["path"])) == second_receipt["phase_start"]
    assert second_receipt["runner_at_start"]["sha256"] == "86dfb406af8b18a2e55c90da2293676e87addf2ad095e5e2ad98e923dfe72d29"
    for stream in ("stdout", "stderr"):
        assert pin(Path(second_receipt[stream]["path"])) == second_receipt[stream]
    commands = stages["nine_fresh_gates"][6:]
    assert [r["name"] for r in commands] == ["vendored", "diff-check", "site-current"]
    OUT.mkdir(exist_ok=True)
    folder = OUT / phase
    folder.mkdir(exist_ok=False)
    with (folder / "runner-at-start.py").open("xb") as stream:
        stream.write(runner_body)
    phase_start = {
        "phase": phase,
        "started_at": datetime.datetime.now(datetime.UTC).isoformat(),
        "runner": runner_at_start,
        "retained_runner": pin(folder / "runner-at-start.py"),
        "adoption": adoption_at_start,
        "stage_plan": pin(PREP / "stages.json"),
        "plan": pin(PREP / "plan.json"),
        "commands": commands,
        "retained_prior_origins": retained_origins,
        "record_count": len(records),
        "history_before_phase": history_before,
        "cwd": str(ROOT),
        "environment": stages["environment"],
    }
    write(folder / "phase-start.json", phase_start)
    phase_origin = pin(folder / "phase-start.json")
    receipts = []
    receipt_origins = []
    for item in commands:
        name, argv = item["name"], item["argv"]
        assert pin(Path(__file__)) == runner_at_start
        start = datetime.datetime.now(datetime.UTC).isoformat()
        clock = time.monotonic()
        with (
            (folder / (name + ".stdout")).open("xb") as stdout,
            (folder / (name + ".stderr")).open("xb") as stderr,
        ):
            proc = subprocess.run(
                argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False
            )
        receipt = {
            "name": name,
            "argv": argv,
            "cwd": str(ROOT),
            "environment": stages["environment"],
            "started_at": start,
            "finished_at": datetime.datetime.now(datetime.UTC).isoformat(),
            "seconds": time.monotonic() - clock,
            "exit_code": proc.returncode,
            "stdout": pin(folder / (name + ".stdout")),
            "stderr": pin(folder / (name + ".stderr")),
            "runner_at_start": runner_at_start,
            "phase_start": phase_origin,
        }
        write(folder / (name + ".execution.json"), receipt)
        receipt_origins.append(pin(folder / (name + ".execution.json")))
        receipts.append(receipt)
        print(
            json.dumps({"name": name, "exit_code": proc.returncode, "seconds": receipt["seconds"]}),
            flush=True,
        )
        if proc.returncode:
            write(
                folder / "failure.json",
                {"status": "phase_failed", "receipts": receipts, "remaining_not_run": True},
            )
            raise SystemExit(proc.returncode)
        if name == "history-2":
            history_after = check_histories(408)
            assert len(history_after["new_histories"]) == 2
            write(folder / "histories-before-generation.json", history_after)
        if name == "sssom":
            semantic = json.loads((PREP / "semantic-preservation.json").read_bytes())["SSSOM"]
            old_body = subprocess.check_output(
                ["git", "show", "HEAD:output/sssom/source_mappings.sssom.tsv"], cwd=ROOT
            )
            path = ROOT / "output/sssom/source_mappings.sssom.tsv"
            result = verify_sssom(old_body, path.read_bytes(), semantic)
            write(folder / "sssom-preservation.json", {"actual": pin(path), **result})
    assert pin(Path(__file__)) == runner_at_start
    check_histories(408)
    for origin in retained_origins:
        assert pin(Path(origin["path"])) == origin
    assert pin(adoption) == adoption_at_start
    assert pin(approval) == state["approval"]
    assert pin(PREP / "stages.json")["sha256"] == EXPECTED_STAGE
    assert pin(folder / "phase-start.json") == phase_origin
    assert (folder / "runner-at-start.py").read_bytes() == runner_body
    for receipt, origin in zip(receipts, receipt_origins, strict=True):
        assert pin(Path(origin["path"])) == origin
        assert pin(Path(receipt["stdout"]["path"])) == receipt["stdout"]
        assert pin(Path(receipt["stderr"]["path"])) == receipt["stderr"]
    write(
        folder / "completion.json",
        {
            "status": "phase_passed",
            "phase": phase,
            "receipts": receipts,
            "adoption": adoption_at_start,
            "stage_plan": pin(PREP / "stages.json"),
            "runner": runner_at_start,
            "phase_start": phase_origin,
            "receipt_origins": receipt_origins,
            "retained_prior_origins": retained_origins,
            "prior_failure": pin(failed_path),
            "prior_network_failure": pin(second_folder / "failure.json"),
            "finished_at": datetime.datetime.now(datetime.UTC).isoformat(),
        },
    )


if __name__ == "__main__":
    main()
