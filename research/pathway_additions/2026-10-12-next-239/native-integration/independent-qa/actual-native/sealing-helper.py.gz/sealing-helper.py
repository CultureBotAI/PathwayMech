"""Seal completed native execution evidence without rerunning any gate."""
import datetime
import hashlib
import json
import os
import re
from pathlib import Path

OUT = Path('/private/tmp/pathwaymech-next-239-local-native-execution-20261012')
ROOT = Path('/private/tmp/pathwaymech-next-239-local-20261012')
PREP = Path('/private/tmp/pathwaymech-next-239-local-integration-preparation-20261012')
RUNNER = Path('/private/tmp/pathwaymech-next-239-root-run-native-20261012.py')
PHASES = ('history-and-generation', 'remaining-offline-gates', 'network-resumption-successor')
RETRY = Path('/private/tmp/pathwaymech-next-239-resume-gates-successor-20261012.py')
FIRST_RETRY = Path('/private/tmp/pathwaymech-next-239-resume-gates-20261012.py')

def pin(p):
    assert p.is_file() and not p.is_symlink(), p
    body = p.read_bytes()
    return {'path': str(p), 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}

def write(p, value):
    with p.open('x') as s:
        json.dump(value, s, indent=2)
        s.write('\n')

def main():
    assert pin(RUNNER)['sha256'] == '4062c883278e7c2e525c6aedf374ec6e0e289ad7db3ded6a405697fa5466516a'
    assert pin(RETRY)['sha256'] == '929ce00e2145f3a767b7c8b8767a4f7a30315e085ecded06286c2c2bd7b7f214'
    assert pin(FIRST_RETRY)['sha256'] == '86dfb406af8b18a2e55c90da2293676e87addf2ad095e5e2ad98e923dfe72d29'
    summary = []
    all_receipts = []
    completion_pins = []
    for phase in PHASES:
        folder = OUT / phase
        phase_runner = RETRY if phase == 'network-resumption-successor' else RUNNER
        completion = json.loads((folder / 'completion.json').read_bytes())
        assert completion['status'] == 'phase_passed' and completion['phase'] == phase
        assert completion['runner'] == pin(phase_runner)
        assert completion['stage_plan'] == pin(PREP / 'stages.json')
        assert pin(Path(completion['phase_start']['path'])) == completion['phase_start']
        assert (folder / 'runner-at-start.py').read_bytes() == phase_runner.read_bytes()
        for receipt, origin in zip(completion['receipts'], completion['receipt_origins'], strict=True):
            assert receipt['exit_code'] == 0 and receipt['runner_at_start'] == pin(phase_runner)
            assert receipt['phase_start'] == completion['phase_start']
            assert pin(Path(origin['path'])) == origin
            assert json.loads(Path(origin['path']).read_bytes()) == receipt
            for stream in ('stdout', 'stderr'):
                assert pin(Path(receipt[stream]['path'])) == receipt[stream]
            summary.append({key: receipt[key] for key in ('name', 'started_at', 'finished_at', 'seconds', 'exit_code')})
            all_receipts.append(receipt)
        completion_pins.append(pin(folder / 'completion.json'))
    assert [row['name'] for row in summary] == ['history-1', 'history-2', 'sssom', 'render', 'skills', 'validate', 'tests', 'lint', 'kgx', 'vendored', 'diff-check', 'site-current']
    for first, second in zip(summary, summary[1:], strict=False):
        assert datetime.datetime.fromisoformat(first['finished_at']) <= datetime.datetime.fromisoformat(second['started_at'])
    histories = []
    for receipt in all_receipts[:2]:
        relative = Path(receipt['stdout']['path']).read_text().strip()
        assert relative.startswith('history/') and relative.endswith('.yaml')
        histories.append(pin(ROOT / relative))
    sssom = json.loads((OUT / 'history-and-generation/sssom-preservation.json').read_bytes())
    assert sssom['old_row_relative_order_exact'] is True
    assert sssom['actual'] == pin(ROOT / 'output/sssom/source_mappings.sssom.tsv')
    assert (sssom['old_rows'], sssom['added_rows'], sssom['total_rows']) == (42, 20, 62)
    tests_body = (OUT / 'remaining-offline-gates/tests.stdout').read_text()
    test_summaries = [line for line in tests_body.splitlines() if re.search(r'\d+ passed', line)]
    assert len(test_summaries) == 1 and 'failed' not in test_summaries[0]
    histories_receipt = json.loads((OUT / 'history-and-generation/histories-before-generation.json').read_bytes())
    assert histories_receipt['old_histories'] == 406 and histories_receipt['total_histories'] == 408
    assert histories_receipt['old_whole_history_bytes_exact'] is True
    assert sorted(histories_receipt['new_histories'], key=lambda r:r['path']) == sorted(histories,key=lambda r:r['path'])
    failed_folder = OUT / 'vendored-gate'
    failure = json.loads((failed_folder / 'failure.json').read_bytes())
    assert [(r['name'], r['exit_code']) for r in failure['receipts']] == [('vendored', 1)]
    assert 'nodename nor servname provided' in (failed_folder / 'vendored.stderr').read_text()
    for receipt in failure['receipts']:
        assert receipt['runner_at_start'] == pin(RUNNER)
        assert json.loads((failed_folder / (receipt['name'] + '.execution.json')).read_bytes()) == receipt
        assert pin(Path(receipt['phase_start']['path'])) == receipt['phase_start']
        for stream in ('stdout', 'stderr'):
            assert pin(Path(receipt[stream]['path'])) == receipt[stream]
    resumed = json.loads((OUT / 'network-resumption-successor/completion.json').read_bytes())
    assert resumed['prior_failure'] == pin(failed_folder / 'failure.json')
    second_failed = OUT / 'network-resumption'
    second_failure = json.loads((second_failed / 'failure.json').read_bytes())
    assert [(r['name'], r['exit_code']) for r in second_failure['receipts']] == [('vendored', 1)]
    assert 'Broken pipe' in (second_failed / 'vendored.stderr').read_text()
    assert resumed['prior_network_failure'] == pin(second_failed / 'failure.json')
    for receipt in second_failure['receipts']:
        assert receipt['runner_at_start'] == pin(FIRST_RETRY)
        assert json.loads((second_failed / (receipt['name'] + '.execution.json')).read_bytes()) == receipt
        assert pin(Path(receipt['phase_start']['path'])) == receipt['phase_start']
        for stream in ('stdout', 'stderr'):
            assert pin(Path(receipt[stream]['path'])) == receipt[stream]
    for origin in resumed['retained_prior_origins']:
        assert pin(Path(origin['path'])) == origin
    wrappers = OUT / 'outer-tool-streams'
    wrappers.mkdir()
    wrapper_bindings = []
    for phase in (*PHASES[:2], 'vendored-gate', 'network-resumption', 'network-resumption-successor'):
        phase_runner = RETRY if phase == 'network-resumption-successor' else RUNNER
        if phase == 'network-resumption': phase_runner = FIRST_RETRY
        source_root = Path('/private/tmp/pathwaymech-next-239-native-phase-execution-20261012') / phase
        invocation = json.loads((source_root / 'execution.json').read_bytes())
        assert invocation['exit_code'] == (1 if phase in ('vendored-gate', 'network-resumption') else 0)
        assert invocation['helper_at_start'] == pin(phase_runner)
        assert invocation['argv'] == ['/private/tmp/pathwaymech-next-195-20261011/.venv/bin/python', '-B', str(phase_runner), phase]
        assert (source_root / 'helper-at-start.py').read_bytes() == phase_runner.read_bytes()
        assert pin(Path(invocation['runner']['path'])) == invocation['runner']
        for stream in ['stdout','stderr']:
            assert pin(source_root / stream) == invocation[stream]
        destination_root = wrappers / phase
        destination_root.mkdir()
        for name in ['execution.json','helper-at-start.py','stdout','stderr']:
            source = source_root / name
            destination = destination_root / name
            destination.write_bytes(source.read_bytes())
            wrapper_bindings.append({'source':pin(source),'retained':pin(destination)})
    wrapper = Path('/private/tmp/pathwaymech-next-239-run-local-step-20261012.py')
    (wrappers / 'capture-wrapper.py').write_bytes(wrapper.read_bytes())
    provenance_source = Path('/private/tmp/pathwaymech-next-239-native-tool-provenance-20261012.json')
    provenance = json.loads(provenance_source.read_bytes())
    assert len(provenance['phase_invocations']) == 5
    assert [x['exit_code'] for x in provenance['phase_invocations']] == [0, 0, 1, 1, 0]
    (OUT / 'actual-tool-provenance.json').write_bytes(provenance_source.read_bytes())
    (OUT / 'sealing-helper.py').write_bytes(Path(__file__).read_bytes())
    copied = OUT / 'input-receipts'
    copied.mkdir()
    bindings = []
    for name, source in [
        ('runner-lineage.json', Path('/private/tmp/pathwaymech-next-239-native-runner-preparation-20261012/lineage.json')),
        ('root-acceptance.json', Path('/private/tmp/pathwaymech-next-239-root-integration-acceptance-20261012.json')),
        ('adoption.json', Path('/private/tmp/pathwaymech-next-239-local-adoption-20261012/receipt.json')),
        ('stages.json', PREP / 'stages.json'),
        ('network-resumption-successor.py', RETRY),
        ('network-resumption.py', FIRST_RETRY),
        ('network-retry-successor.patch', Path('/private/tmp/pathwaymech-next-239-native-runner-preparation-20261012/network-retry-successor.patch')),
        ('network-resumption.patch', Path('/private/tmp/pathwaymech-next-239-native-runner-preparation-20261012/network-resumption.patch')),
    ]:
        destination = copied / name
        destination.write_bytes(source.read_bytes())
        bindings.append({'source': pin(source), 'retained': pin(destination)})
    result = {
        'status': 'all_nine_native_gates_passed_after_recorded_fetch_retries',
        'sealed_at': datetime.datetime.now(datetime.UTC).isoformat(),
        'runner': pin(RUNNER), 'resumption_runner': pin(RETRY), 'retained_DNS_failure': pin(failed_folder / 'failure.json'), 'retained_network_failure': pin(second_failed / 'failure.json'), 'completions': completion_pins, 'commands': summary,
        'tests_summary': test_summaries[0], 'histories': histories, 'SSSOM': sssom,
        'input_bindings': bindings, 'outer_wrapper_bindings': wrapper_bindings,
        'histories_before_generation': histories_receipt,
        'outputs': [pin(ROOT / relative) for relative in ['data/pathways/s-methyl-5-thio-alpha-d-ribose-1-phosphate-degradation-iii.yaml', 'pages/records/MetaCyc_PWY-8132.html', 'output/kgx/nodes.tsv', 'output/kgx/edges.tsv']],
        'fresh_command_receipts_and_streams_exact': True,
        'history_before_SSSOM_and_render': True,
        'native_review_save_performed': False, 'git_commit_performed': False,
        'publication_performed': False, 'whole_checkout_QA_pending_separate_owner': True,
    }
    write(OUT / 'execution-summary.json', result)
    lines = ['The exact authorized 239 native stages completed in three successful phases after separate retained sandbox DNS and network broken-pipe failures. Only the read-only vendored fetch was retried twice with network permission; tests and all other gates ran once. All nine gates and both history commands ultimately passed. The two histories were created before SSSOM and rendering; the SSSOM output retains all 42 prior rows, exact cells/header/multiplicity and relative order and adds the 20 accepted mappings (62 total rows). Its whole bytes change as expected.', '', test_summaries[0], '', 'Actual commands, start/end times, durations, helper bodies and stdout/stderr are retained. Fresh final evidence checks compare every execution receipt to its first-created origin hash and every stream to its recorded bytes. The exact acceptance/adoption/stages and runner preparation are bound, and outer tool invocation provenance is recorded separately. No gate is rerun by this seal.', '', 'This is execution evidence, not an independent maintained scientific or technical review. Whole checkout/cache and complete target interpretation belong to the separate actual maintained QA. No native review was authored or saved, no commit was created, and no public action occurred in this stage. Scientific evidence coverage remains inherited from the accepted scientific and actual-output reviews; no fresh whole-primary-paper reading is claimed here.', '', 'See actual-tool-provenance.json for any execution or inspection limitations and original failures. Native source and evidence bytes were not normalized. The runner reuses the accepted 238 phase orchestration with only exact pins, paths, role and concrete counts rebased. Its seven isolated mapping controls are inherited, not newly executed. Root authorized the exact histories and nine gates in the single integration acceptance. Separate integration-preparation packaging and formatting diagnostics remain retained in that earlier packet.', '']
    (OUT / 'REPORT.md').write_text('\n'.join(lines))
    rows = []
    directories = []
    for current, dirs, files in os.walk(OUT, followlinks=False):
        for name in dirs:
            p = Path(current) / name
            assert not p.is_symlink()
            directories.append(str(p.relative_to(OUT)))
        for name in files:
            p = Path(current) / name
            assert name not in ('artifact-manifest.json', 'handoff.json')
            row = pin(p); row['relative_path'] = str(p.relative_to(OUT)); row['kind'] = 'regular_file'
            rows.append(row)
    rows.sort(key=lambda row: row['relative_path'])
    write(OUT / 'artifact-manifest.json', {'files': rows, 'directories': sorted(directories), 'walk': 'literal os.walk, ignored/hidden included, symlinks rejected'})
    write(OUT / 'handoff.json', {'status': result['status'], 'runner': pin(RUNNER), 'manifest': pin(OUT / 'artifact-manifest.json'), 'summary': pin(OUT / 'execution-summary.json'), 'artifacts': len(rows), 'directories': len(directories), 'native_review_and_commit_pending': True, 'publication_performed': False})
    print(json.dumps({'handoff': pin(OUT / 'handoff.json'), 'manifest': pin(OUT / 'artifact-manifest.json'), 'summary': pin(OUT / 'execution-summary.json'), 'tests': test_summaries[0], 'artifacts': len(rows)}, indent=2))

if __name__ == '__main__':
    main()
